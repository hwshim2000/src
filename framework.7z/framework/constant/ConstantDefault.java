package com.bicns.ocps.framework.constant;

import com.bicns.ocps.framework.config.ConfigHelper;

public class ConstantDefault {
	protected static ConfigHelper configHelper = ConfigHelper.getInstance();
	// System REAL,STAGE,LOCAL status    
    public static final String SYSTEM_TARGET = configHelper.getValue("system.target");
    public static final String DEFAULT_DATABASE_TYPE = configHelper.getValue("default.database.type");
    
    public static final String JSP_JSON_RESULT_TYPE = configHelper.getValue("jsp.json.resultType");
    public static final String JSP_JQERYI_UI_RESULT_NAME = configHelper.getValue("jsp.jqueryui.resultname");
    public static final String JSP_JQERYI_UI_PAGINATION_TOTALRECORDS = configHelper.getValue("jsp.jqueryui.pagination.iTotalRecords");
    public static final String JSP_JQERYI_UI_PAGINATION_TOTALDISPLAYRECORDS = configHelper.getValue("jsp.jqueryui.pagination.iTotalDisplayRecords");
    
    public static final String SERVICE_MODE_LIST = configHelper.getValue("service.mode.list");
    public static final String SERVICE_MODE_DETAIL = configHelper.getValue("service.mode.detail");
    public static final String SERVICE_MODE_INSERT = configHelper.getValue("service.mode.insert");
    public static final String SERVICE_MODE_UPDATE = configHelper.getValue("service.mode.update");
    public static final String SERVICE_MODE_DELETE = configHelper.getValue("service.mode.delete");
    public static final String SERVICE_MODE_COUNT = configHelper.getValue("service.mode.count");
    public static final String SERVICE_MODE_TOTAL_COUNT = configHelper.getValue("service.mode.total_count");
    public static final String SERVICE_MODE_EXCEL_LIST = configHelper.getValue("service.mode.excel.list");
    
    public static final String DEV_FILE_UPLOAD_DIR = configHelper.getValue("dev.file.upload.dir");
    public static final String REAL_FILE_UPLOAD_DIR = configHelper.getValue("real.file.upload.dir");
    
    public static final String WEBARGMENTRESOLVER_LOG = configHelper.getValue("webArgmentResolver.log");

	public static final String URL_ADMIN_LOGIN = configHelper.getValue("url.admin.login");
    public static final String URL_WEB_LOGIN = configHelper.getValue("url.web.login");
    public static final String URL_MOBILE_LOGIN = configHelper.getValue("url.mobile.login");
    
    public static final String DEFAULT_TOKEN_KEY = configHelper.getValue("default.token.key");;
    
    //IMAGE SIZE
    public static final String IMG_RESIZE_EXT = configHelper.getValue("image.resize.ext");
    public static final String IMG_RESIZE_THUMBNAIL_WITH_MAX = configHelper.getValue("image.resize.thumbnail.with.max");
    public static final String IMG_RESIZE_THUMBNAIL_HEIGHT_MAX = configHelper.getValue("image.resize.thumbnail.height.max");
    public static final String IMG_RESIZE_MOBILE_WITH_MAX = configHelper.getValue("image.resize.mobile.with.max");
    public static final String IMG_RESIZE_MOBILE_HEIGHT_MAX = configHelper.getValue("image.resize.mobile.height.max");
    public static final String IMG_RESIZE_ADD_WITH_MAX = configHelper.getValue("image.resize.add.with.max");
    public static final String IMG_RESIZE_ADD_HEIGHT_MAX = configHelper.getValue("image.resize.add.height.max");

    public static final String IMG_RESIZE_THUMBNAIL_WITH_FIXED = configHelper.getValue("image.resize.thumbnail.with.fixed");
    public static final String IMG_RESIZE_THUMBNAIL_HEIGHT_FIXED = configHelper.getValue("image.resize.thumbnail.height.fixed");
    public static final String IMG_RESIZE_MOBILE_WITH_FIXED = configHelper.getValue("image.resize.mobile.with.fixed");
    public static final String IMG_RESIZE_MOBILE_HEIGHT_FIXED = configHelper.getValue("image.resize.mobile.height.fixed");
    public static final String IMG_RESIZE_ADD_WITH_FIXED = configHelper.getValue("image.resize.add.with.fixed");
    public static final String IMG_RESIZE_ADD_HEIGHT_FIXED = configHelper.getValue("image.resize.add.height.fixed");
}
