package com.bicns.ocps.framework.support.web;
 
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.bicns.ocps.admin.system.login.domain.UserDataDomain;
import com.bicns.ocps.common.constant.OcpsConstant;
import com.bicns.ocps.common.domain.SessionUserDomain;
import com.bicns.ocps.framework.domain.CommonMap;

 
public class RestfulHandlerMethodArgumentResolver implements HandlerMethodArgumentResolver {

    private final static Logger logger = LoggerFactory.getLogger(RestfulHandlerMethodArgumentResolver.class);
  

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return CommonMap.class.isAssignableFrom(parameter.getParameterType());
    }

    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
    	CommonMap cMap = new CommonMap();
    	
    	HttpServletRequest request = (HttpServletRequest) webRequest.getNativeRequest();
    	
    	for(Iterator<String> iterator = webRequest.getParameterNames(); iterator.hasNext();){
    		String key = iterator.next();
    		if(!"undefined".equals(webRequest.getParameter(key)) && webRequest.getParameter(key) != null){
    			cMap.put(key, webRequest.getParameter(key));
    		} 
    	}
    	Device device = DeviceUtils.getCurrentDevice(request); 
		 
		/* Device 확인 */
    	//if("MOBILE".equals(cMap.get("DEVICE_TYPE"))){
    	if(!device.isNormal()){
    		logger.debug("DEVICE_TYPE MOBILE");                 
            HttpSession hsSession = request.getSession();
            
            if(cMap.get("LOCALE_XD") != null && !"".equals(cMap.get("LOCALE_XD"))){
                // 화면에서 넘어온 parameter 사용
                hsSession.setAttribute("LOCALE_XD", cMap.get("LOCALE_XD"));
            }
            
            UserDataDomain cUserData = null;
            
            if(hsSession != null){
            	SessionUserDomain sSession = (SessionUserDomain)hsSession.getAttribute("sessionData");
                if(sSession != null){
                    cUserData = sSession.getUserDataDomain();
                }
            }
            // 모든 화면에서 공통으로 사용하게 될 세션변수 값을 파라미터맵에 추가한다.
            // common parameter start
            if(cUserData != null){
            	cMap.put("VENDOR_ID", cUserData.getVENDOR_ID());
                cMap.put("FST_INSERT_UID", cUserData.getU_ID());
                cMap.put("LST_UPDATE_UID", cUserData.getU_ID());
                if(hsSession.getAttribute("LOCALE_XD") == null || "".equals(hsSession.getAttribute("LOCALE_XD"))){
                    hsSession.setAttribute("LOCALE_XD", cUserData.getLOCALE_XD());
                }
                cMap.put("U_ID", cUserData.getU_ID());
                cMap.put("LOGIN_ID", cUserData.getLOGIN_ID());
            	logger.debug("FST_INSERT_UID[" + cUserData.getU_ID() + "]");
            	logger.debug("U_ID[" + cUserData.getU_ID() + "]");
            	logger.debug("LOGIN_ID[" + cUserData.getLOGIN_ID() + "]");
            	logger.debug("LOCALE_XD[" + cUserData.getLOCALE_XD() + "]");
            	logger.debug("SYSTEM_ROLE_ID[" + cUserData.getSYSTEM_ROLE_ID() + "]");
            }
            // common paramater end

            //세션에도 없고 parameter에도 없고 userData정보에도 없을 경우 기본으로 한국어 지정
            if(hsSession.getAttribute("LOCALE_XD") == null || "".equals(hsSession.getAttribute("LOCALE_XD"))){
            	//default
			    cMap.put("LOCALE_XD", "ko_KR");
            } else {
			    cMap.put("LOCALE_XD", hsSession.getAttribute("LOCALE_XD"));
            }

        	logger.debug("hsSession LOCALE_XD[" + hsSession.getAttribute("LOCALE_XD") + "]");
        	logger.debug("cMap LOCALE_XD[" + cMap.get("LOCALE_XD") + "]");
		    if( "REAL".equals(OcpsConstant.SYSTEM_TARGET) )	cMap.put("ATTACH_DEFAULT_PATH", OcpsConstant.REAL_FILE_UPLOAD_DIR);	
		    else											cMap.put("ATTACH_DEFAULT_PATH", OcpsConstant.DEV_FILE_UPLOAD_DIR);
		    
            // 페이징 관련으로  공통으로 사용하게 될 세션변수 값을 파라미터맵에 추가한다.
            // page start
            int iStartNum = 0 ;
            int iEndNum = 0 ;
            
            logger.debug("iDisplayStart[" + cMap.get("iDisplayStart") + "]iDisplayLength[" + cMap.get("iDisplayLength") + "]");
            if(cMap.get("iDisplayStart") != null && !"".equals(cMap.get("iDisplayStart"))){
                iStartNum = Integer.parseInt(cMap.get("iDisplayStart").toString());
            }
            if(cMap.get("iDisplayLength") != null && !"".equals(cMap.get("iDisplayLength"))){
                iEndNum = Integer.parseInt(cMap.get("iDisplayLength").toString());
            }
            cMap.put("PAGE_START_NUM", iStartNum+1);
            cMap.put("PAGE_END_NUM", iStartNum + iEndNum);
            logger.debug("PAGE_START_NUM[" + iStartNum + "]PAGE_END_NUM[" + (iStartNum + iEndNum) + "]");
            logger.debug("UI_SORT_COLUMN[" + cMap.get("UI_SORT_COLUMN") + "]UI_SORT_DIR[" + cMap.get("UI_SORT_DIR") + "]");                
           
    	} else {
            logger.debug("DEVICE_TYPE PC");
            HttpSession hsSession = request.getSession();
            if(cMap.get("LOCALE_XD") != null && !"".equals(cMap.get("LOCALE_XD"))){
                // 화면에서 넘어온 parameter 사용
                hsSession.setAttribute("LOCALE_XD", cMap.get("LOCALE_XD"));
            }
            
//            UserDataDomain cUserData = new UserDataDomain();
            UserDataDomain cUserData = null;
            
            if(hsSession != null){
            	SessionUserDomain sSession = (SessionUserDomain)hsSession.getAttribute("sessionData");
                if(sSession != null){
                    cUserData = sSession.getUserDataDomain();
                }
            }
            // 모든 화면에서 공통으로 사용하게 될 세션변수 값을 파라미터맵에 추가한다.
            // common parameter start
            if(cUserData != null){
            	cMap.put("VENDOR_ID", cUserData.getVENDOR_ID());
                cMap.put("FST_INSERT_UID", cUserData.getU_ID());
                cMap.put("LST_UPDATE_UID", cUserData.getU_ID());
                if(hsSession.getAttribute("LOCALE_XD") == null || "".equals(hsSession.getAttribute("LOCALE_XD"))){
                    hsSession.setAttribute("LOCALE_XD", cUserData.getLOCALE_XD());
                }
                cMap.put("U_ID", cUserData.getU_ID());
                cMap.put("LOGIN_ID", cUserData.getLOGIN_ID());
            	logger.debug("VENDOR_ID[" + cUserData.getVENDOR_ID() + "]");
            	logger.debug("FST_INSERT_UID[" + cUserData.getU_ID() + "]");
            	logger.debug("U_ID[" + cUserData.getU_ID() + "]");
            	logger.debug("LOGIN_ID[" + cUserData.getLOGIN_ID() + "]");
            	logger.debug("LOCALE_XD[" + cUserData.getLOCALE_XD() + "]");
            	logger.debug("SYSTEM_ROLE_ID[" + cUserData.getSYSTEM_ROLE_ID() + "]");
            }
            // common paramater end

            //세션에도 없고 parameter에도 없고 userData정보에도 없을 경우 기본으로 한국어 지정
            if(hsSession.getAttribute("LOCALE_XD") == null || "".equals(hsSession.getAttribute("LOCALE_XD"))){
            	//default
			    cMap.put("LOCALE_XD", "ko_KR");
            } else {
			    cMap.put("LOCALE_XD", hsSession.getAttribute("LOCALE_XD"));
            }
		    
		    if( "REAL".equals(OcpsConstant.SYSTEM_TARGET) ) { cMap.put("ATTACH_DEFAULT_PATH", OcpsConstant.REAL_FILE_UPLOAD_DIR);}	
		    else											{ cMap.put("ATTACH_DEFAULT_PATH", OcpsConstant.DEV_FILE_UPLOAD_DIR);}
		    
            // 페이징 관련으로  공통으로 사용하게 될 세션변수 값을 파라미터맵에 추가한다.
            // page start
            int iStartNum = 0 ;
            int iEndNum = 0 ;
            
            logger.debug("iDisplayStart[" + cMap.get("iDisplayStart") + "]iDisplayLength[" + cMap.get("iDisplayLength") + "]");
            if(cMap.get("iDisplayStart") != null && !"".equals(cMap.get("iDisplayStart"))){
                iStartNum = Integer.parseInt(cMap.get("iDisplayStart").toString());
            }
            if(cMap.get("iDisplayLength") != null && !"".equals(cMap.get("iDisplayLength"))){
                iEndNum = Integer.parseInt(cMap.get("iDisplayLength").toString());
            }
            cMap.put("PAGE_START_NUM", iStartNum+1);
            cMap.put("PAGE_END_NUM", iStartNum + iEndNum);
            logger.debug("PAGE_START_NUM[" + iStartNum + "]PAGE_END_NUM[" + (iStartNum + iEndNum) + "]");
            logger.debug("UI_SORT_COLUMN[" + cMap.get("UI_SORT_COLUMN") + "]UI_SORT_DIR[" + cMap.get("UI_SORT_DIR") + "]");                
        } 

        return cMap;
    } 
}