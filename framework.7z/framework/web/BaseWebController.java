package com.bicns.ocps.framework.web;

import org.springframework.stereotype.Controller;

@Controller
public abstract class BaseWebController {
 
	
}