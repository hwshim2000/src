package com.bicns.ocps.framework.dao;

import java.sql.SQLException;

public interface CommonWriteDao {
	//@SuppressWarnings("rawtypes")
	//public List selectList(String statement, Object paramMap) throws SQLException;
	
	//@SuppressWarnings("rawtypes")
	//public List selectList(String statement) throws SQLException;
	
	//public int selectCount(String statement, Object paramMap) throws SQLException;
	
	//public Object selectOne(String statement, Object paramMap) throws SQLException;
	
	//public Object selectOne(String statement) throws SQLException;
	
	//public String selectOneNum(String statement) throws SQLException;
	
	public int insert(String statement, Object paramMap) throws SQLException;
	
	public int update(String statement, Object paramMap) throws SQLException;
	
	public int delete(String statement, Object paramMap) throws SQLException;
	
}
