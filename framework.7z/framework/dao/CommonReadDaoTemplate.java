package com.bicns.ocps.framework.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Qualifier;

//public class CommonReadDaoTemplate extends BaseDaoTemplate {
public class CommonReadDaoTemplate implements CommonReadDao {
	@Qualifier(value ="sqlSessionFactoryMaria")
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	/**
	 * @param statement Mybatis Statement
	 * 공통 INSERT
	 * @param parameter Parameter Object
	 * @return insert 성공 횟수
	 */
//	@Override
//	public int insert(String statement, Object paramMap) throws SQLException {
//		return sqlSession.insert(statement, paramMap);
//	}

	/**
	 * 공통 SELECT(LIST)
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return SELECT한 List
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public List selectList(String statement, Object paramMap) throws SQLException {
		return sqlSession.selectList(statement, paramMap);
	}
	
	/**
	 * 공통 SELECT(LIST)
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return SELECT한 List
	 */
	@Override
	@SuppressWarnings("rawtypes")
	public List selectList(String statement) throws SQLException {
		return sqlSession.selectList(statement);
	}	
	
	/**
	 * 공통 SELECT(Object)
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return SELECT한 Object
	 */
	@Override
	public int selectCount(String statement, Object paramMap) throws SQLException {
		return sqlSession.selectOne(statement, paramMap);
	}

	/**
	 * 공통 SELECT(Object)
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return SELECT한 Object
	 */
	@Override
	public Object selectOne(String statement, Object paramMap) throws SQLException {
		return sqlSession.selectOne(statement, paramMap);
	}
	
	/**
	 * 공통 SELECT(Object)
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return SELECT한 Object
	 */
	@Override
	public Object selectOne(String statement) throws SQLException {
		return sqlSession.selectOne(statement);
	}
	
	/**
	 * 공통 SELECT(String)
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return SELECT한 Object
	 */
	@Override
	public String selectOneNum(String statement) throws SQLException {
		return sqlSession.selectOne(statement);
	}

	/**
	 * 공통 UPDATE
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return UPDATE 성공한 횟수
	 */
//	@Override
//	public int update(String statement, Object paramMap) throws SQLException {
//		return sqlSession.update(statement, paramMap);
//	}

	/**
	 * 공통 DELETE
	 * @param statement Mybatis Statement
	 * @param parameter 파라미터 Object
	 * @return DELETE 성공한 횟수
	 */
//	@Override
//	public int delete(String statement, Object paramMap) throws SQLException {
//		return sqlSession.delete(statement, paramMap);
//	}

}
