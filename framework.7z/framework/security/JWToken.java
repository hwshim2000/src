package com.bicns.ocps.framework.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.compression.CompressionCodecs;
import java.security.Key;
import java.util.Date;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bicns.ocps.framework.constant.ConstantDefault;

public class JWToken {
	// default_tokent_key 
	private static String apiKey = ConstantDefault.DEFAULT_TOKEN_KEY;
	private static final Logger logger = LoggerFactory.getLogger(JWToken.class);
	
	// JWT(iss:토큰발급자, sub:주체로 토큰이 갖는 문맥, exp:만료)
	public String createJWT(String uid, String issuer, String subject, long ttlMillis) {

		// The JWT signature algorithm we will be using to sign the token
		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);
	 
		// We will sign our JWT with our ApiKey secret
		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(apiKey);
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

		// 토큰 설정
		JwtBuilder builder = Jwts.builder()
				.compressWith(CompressionCodecs.GZIP)
				.setHeaderParam("typ", "JWT") 
				.setId(uid)
				.setIssuedAt(now)
				.setSubject(subject)
				.setIssuer(issuer)
				.signWith(signatureAlgorithm, signingKey);
		
		 // 토큰 말료 추가함.
		if (ttlMillis >= 0) {
		    long expMillis = nowMillis + ttlMillis;
		    Date exp = new Date(expMillis);
		    builder.setExpiration(exp);
		} 
		
		return builder.compact();
	}

	public JSONObject parseJWT(String jwt, String uId) throws JSONException { 
		JSONObject json = new JSONObject();
		json.put("success", true); 
		try {
			Claims claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(apiKey)).parseClaimsJws(jwt).getBody();
			String ID = claims.getId();
			String Subject = claims.getSubject();
			String Issuer = claims.getIssuer();
			//웹뷰마다 토큰 키를 네이티브에 저장하는 것은 힘들다함.
			//Long NotBefore = claims.getNotBefore().getTime();
			//Long Expiration = claims.getExpiration().getTime();
			if(uId.equals(ID)){
				json.put("code", "0000");  
				//if (new Date().getTime() > Expiration) {
				//	json.put("code", "1005");
				//	json.put("message", SentExceptionMsg._1005);
				//	json.put("success", false);
				//} else {
				// 토큰 재발행
				//	json.put("jwt", createJWT(ID, EmspConstant.YAPCRM_TOKEN_ISSURE, EmspConstant.YAPCRM_TOKEN_SUBJECT, EmspConstant.YAPCRM_TOKEN_EXPIRE_TIME));
					json.put("aud", ID);
					json.put("subject", Subject);
					json.put("user", Issuer);
					json.put("success", true);
				//}
				return json;
			} else {
				json.put("code", "1006");
				json.put("message", "Token error.");
				json.put("success", false);
				return json;
			} 
		} catch (Exception e) {
			json.put("code", "1005");
			json.put("message", "Token expired.");
			json.put("success", false);
			logger.error("Exception ---> " +e.getMessage());
			return json;
		}
	} 
}