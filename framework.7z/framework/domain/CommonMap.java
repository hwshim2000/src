package com.bicns.ocps.framework.domain;

import java.util.HashMap;
import java.util.Map;

public class CommonMap {
	Map map = new HashMap();

	public String get(String key) {
		return (String) map.get(key);
	}

	public void put(String key, String value) {
		map.put(key, value);
	}
	
	public void put(String key, Object value) {
		map.put(key, value);
	}
	
	public String toString() {
		return map.toString();
	}
}