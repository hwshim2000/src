package com.bicns.ocps.framework.config;
  
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.MessageSourceAccessor;
 
public class ConfigHelper { 
	private static final Logger logger = LoggerFactory.getLogger(ConfigHelper.class);
    private volatile static ConfigHelper INSTANCE;
    private MessageSourceAccessor messageSourceAccessor;

    private final String CONFIG_CONTEXT_FILE = "portal-config-context.xml";
    private final String BEAN_CONFIG_ACCESSOR = "configSourceAccessor";

    public ConfigHelper() {
        messageSourceAccessor = (MessageSourceAccessor) new ClassPathXmlApplicationContext(new String[] { CONFIG_CONTEXT_FILE }).getBean(BEAN_CONFIG_ACCESSOR);
    }

    /**
     * 설정 헬퍼의 인스턴스를 얻는다.
     * @return ConfigHelper
     */
    public static ConfigHelper getInstance() {
        if (INSTANCE == null) {
            synchronized (ConfigHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new ConfigHelper();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * key에 해당하는 값을 반환한다.
     * @param key
     * @return String
     */
    public String getValue(String key) {
        String result = "";
        try {
            result = messageSourceAccessor.getMessage(key);
        }
        catch (NoSuchMessageException e) {
            logger.info(key + " Key에 대한 값을 찾을 수 없습니다.");
        }
        return result;
    }
}
