package net.forecs.coconut.freemarker;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

import com.google.common.base.Preconditions;

import freemarker.cache.URLTemplateLoader;


class FtlLoader extends URLTemplateLoader {
    //static final Logger LOG = Logger.getLogger(FtlLoader.class.getName());

    private final URL baseUrl;

    FtlLoader(URL baseUrl) {
        Preconditions.checkNotNull(baseUrl);
        this.baseUrl = baseUrl;
    }

    @Override
    public URL getURL(String templateName) {
        Preconditions.checkNotNull(templateName);
        try {
            URL url = new URL(baseUrl, templateName);
            URLConnection connection = url.openConnection();
            try {
            	connection.connect();
                return url;
            } catch (IOException e) {
                return null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}