package net.forecs.coconut.email;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import net.forecs.coconut.common.Logger;

import javax.inject.Singleton;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import net.forecs.coconut.common.CommonProperty;

import org.apache.commons.lang.StringUtils;

@Singleton
public class MailUtil {
	private static final Logger LOG = Logger.getLogger(MailUtil.class.getName());

	/**
	 * Server에 Deploy 시에 사용할 send 함수 
	 * @param toAddress
	 * @param title
	 * @param htmlMessage
	 */
	public static void send(String toEmail, String subject, String body) {
		if (StringUtils.isBlank(toEmail) || StringUtils.isBlank(subject) || StringUtils.isBlank(body)) { return; }
		send(toEmail, null, subject, body);
	}
	private static void send(String toEmail, String toName, String subject, String body) {
		Map<String, String> recvMap = new HashMap<String, String>();
		recvMap.put(toEmail, null);
		send(recvMap, subject, body);
	}
	public static void send(List<String> toEmalList, String subject, String body) {
		Map<String, String> recvMap = new HashMap<String, String>();
		for(String toEmail : toEmalList) {
			recvMap.put(toEmail, null);
		}
		send(recvMap, subject, body);
	}
	private static void send(Map<String, String> recvMap, String subject, String body) {
    	try {
	        // 발신, 수신 정보
	        final String fromEmail = CommonProperty.SENDER_NOREPLY_EMAIL;
    		final String fromName = CommonProperty.SENDER_NOREPLY_NAME;
	    	final String password = CommonProperty.SENDER_NOREPLY_PSWD;
//	    	final String fromEmail = CommonProperty.SENDER_MANAGER_EMAIL;
//    		final String fromName = CommonProperty.SENDER_MANAGER_NAME;
//	    	final String password = CommonProperty.SENDER_MANAGER_PSWD;
	    	
	        Properties props = new Properties();
	        //SSL 사용하는 경우
	        //props.put("mail.transport.protocol","smtp");
	        props.put("mail.smtp.starttls.enable", "true"); //enable STARTTLS
	        props.put("mail.smtp.host", "smtp.gmail.com"); //SMTP Host
//	        props.put("mail.smtp.socketFactory.port", "465"); //SSL Port
//	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory"); //SSL Factory Class
	        props.put("mail.smtp.auth", "true"); //Enabling SMTP Authentication
	        props.put("mail.smtp.port", "587"); //SMTP Port
	        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
	        //props.put("mail.smtp.timeout", 1000);
	        
	        // TLS 사용하는 경우
//	        props.put("mail.smtp.host", "smtp.gmail.com"); //SMTP Host
//	        props.put("mail.smtp.port", "587"); //TLS Port
//	        props.put("mail.smtp.auth", "true"); //enable authentication
//	        props.put("mail.smtp.starttls.enable", "true"); //enable STARTTLS
	         
	        // 인증
//	        @SuppressWarnings("unused")
//			Authenticator auth = new Authenticator() {
//	            protected PasswordAuthentication getPasswordAuthentication() {
//	                return new PasswordAuthentication(fromEmail, password);
//	            }
//	        };
	         
	        // 메일 세션
	       // Session session = Session.getInstance(props, auth);
	        Session session = Session.getDefaultInstance(props, null);
	        MimeMessage msg = new MimeMessage(session);
	        
	        //set message headers
	        msg.addHeader("Content-type", "text/html; charset="+CommonProperty.UTF_8);
	        //msg.addHeader("Content-type", "text/plain; charset="+CommonProperty.UTF_8);
	        msg.addHeader("format", "flowed");
	        //msg.addHeader("Content-Transfer-Encoding", "8bit");
	         
	        msg.setFrom(new InternetAddress(fromEmail, fromName));
	        msg.setReplyTo(InternetAddress.parse(fromEmail, false));
	 
	        msg.setSubject(subject, CommonProperty.UTF_8);
	        //msg.setText(body, CommonProperty.UTF_8);
	        msg.setContent(body, "text/html; charset="+CommonProperty.UTF_8);
	        //msg.setContent(body, "text/plain; charset="+CommonProperty.UTF_8);
	        msg.setSentDate(new Date());
	        for (Map.Entry<String, String> entry : recvMap.entrySet()) {
	        	msg.addRecipient(Message.RecipientType.TO, new InternetAddress(entry.getKey(), entry.getValue()));
//	            if (entry.getValue()==null) {
//		        	msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(entry.getKey(), false));
//		        } else {
//		        	msg.addRecipient(Message.RecipientType.TO, new InternetAddress(entry.getKey(), entry.getValue()));
//		        }
	            
//	            LOG.info("Message has been sent to " + entry.getKey());
	        }
	        //Transport.send(msg);  
	        Transport transport = session.getTransport("smtp");
	        //transport.connect("smtp.gmail.com", 465, fromEmail, password);
	        transport.connect("smtp.gmail.com", fromEmail, password);
	        transport.sendMessage(msg, msg.getAllRecipients());
	        
	        transport.close();
     
	    } catch (AddressException e) {
	    	LOG.warning("Can't send email : " + e.getMessage());
        } catch (MessagingException e) {
        	LOG.warning("Can't send email : " + e.getMessage());
        } catch (UnsupportedEncodingException e) {
        	LOG.warning("Can't send email : " + e.getMessage());
        }
    }
    
	//final static String fromAddress = "coconut.forecs.net";
	
//	public static MailSendResult send(String receiver, String receiverName, String sender, String senderName, String subject, String msgBody) {
//		Properties props = new Properties();
//        Session session = Session.getDefaultInstance(props, null);
//        MailSendResult result = new MailSendResult(true, null);
//        
//        try {
//            Message msg = new MimeMessage(session);
//            msg.setFrom(new InternetAddress(sender, senderName));
//            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(receiver, receiverName));
//            msg.setSentDate(new Date());
//            msg.setSubject(subject);
//            msg.setText(msgBody);
//            Transport.send(msg);
//
//        } catch (AddressException e) {
//        	result.setResult(false);
//            result.setMessage(e.getMessage());
//        } catch (MessagingException e) {
//        	result.setResult(false);
//        	result.setMessage(e.getMessage());
//        } catch (UnsupportedEncodingException e) {
//        	result.setResult(false);
//        	result.setMessage(e.getMessage());
//        }
//        return result;
//	}
	
//	public static MailSendResult send(Map<String, String> receiverMap, String sender, String senderName, String subject, String msgBody) {
//		Properties props = new Properties();
//        Session session = Session.getDefaultInstance(props, null);
//        MailSendResult result = new MailSendResult(true, null);
//        
//        try {
//            Message msg = new MimeMessage(session);
//            msg.setFrom(new InternetAddress(sender, senderName));
//            
//            for (Map.Entry<String, String> entry : receiverMap.entrySet()) {
//	            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(entry.getKey(), entry.getValue()));
//            }
//            
////            List<InternetAddress> receiverList = new ArrayList<InternetAddress>();
////            for (Map.Entry<Email, String> entry : receiverMap.entrySet()) {
////            	receiverList.add(new InternetAddress(entry.getKey().getEmail(), entry.getValue()));
////            }
////            msg.setRecipients(Message.RecipientType.TO, (InternetAddress[])receiverList.toArray());
//            
//            msg.setSentDate(new Date());
//            msg.setSubject(subject);
//            msg.setText(msgBody);
//            Transport.send(msg);
//        } catch (AddressException e) {
//        	result.setResult(false);
//            result.setMessage(e.getMessage());
//        } catch (MessagingException e) {
//        	result.setResult(false);
//            result.setMessage(e.getMessage());
//        } catch (UnsupportedEncodingException e) {
//        	result.setResult(false);
//            result.setMessage(e.getMessage());
//        }
//        return result;
//	}
	
	
}
