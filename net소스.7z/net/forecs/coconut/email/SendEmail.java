package net.forecs.coconut.email;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.routines.EmailValidator;

import com.google.appengine.api.mail.MailService;
import com.google.appengine.api.mail.MailServiceFactory;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;

import com.google.appengine.api.datastore.Text;		// for mail contents


@Singleton
public class SendEmail {
    private static final Logger LOG = Logger.getLogger(SendEmail.class.getName());
    public final static Set<String> smtpTargets = new HashSet<String>();
	static {
		smtpTargets.add("v-one.co.kr".toLowerCase());
		smtpTargets.add("mail.v-one.co.kr".toLowerCase());
	}
	
    private final String fromAddress;
    private final String site;

    @Inject
    public SendEmail(@Named(FLD.admin_email) String fromAddress, @Named(FLD.social_site) String site) {
        this.fromAddress = fromAddress;
        this.site = site;
    }
    
    private Map<Boolean, List<String>> splitSmtpTargets(List<String> toAddress) {
    	Map<Boolean, List<String>> targets = new HashMap<Boolean, List<String>>();
    	List<String> mailServiceTarget = new ArrayList<String>();
    	List<String> smtpTarget = new ArrayList<String>();
    	
    	for (String address : toAddress) {
    		if (!EmailValidator.getInstance(false).isValid(address)) { continue; }
    		String host = address.substring(address.indexOf("@")+1);
    		if (StringUtils.isNotBlank(host) && smtpTargets.contains(host.toLowerCase())) {
    			smtpTarget.add(address);
    		} else {
    			mailServiceTarget.add(address);
    		}
    	}
    	
    	targets.put(true, smtpTarget);
    	targets.put(false, mailServiceTarget);
    	
    	return targets;
    }
    
    private boolean isSmtpTarget(String toAddress) {
//    	if (!EmailValidator.getInstance(false).isValid(toAddress)) { return false; }
    	String host = toAddress.substring(toAddress.indexOf("@")+1);
		if (StringUtils.isNotBlank(host) && smtpTargets.contains(host.toLowerCase())) {
			return true;
		}
		return false;
    }
    public void send(String toAddress, String title, String htmlMessage) {
    	if (!EmailValidator.getInstance(false).isValid(toAddress)) { return; }
    	
	    if (!isSmtpTarget(toAddress) && StringUtils.isNotEmpty(this.site) && "live".equals(site)) {
	        MailService service = MailServiceFactory.getMailService();
	        MailService.Message message = new MailService.Message();
	        message.setSender(fromAddress);
	        message.setReplyTo(fromAddress);
	        message.setTo(toAddress);
	        message.setSubject(title);
	        message.setHtmlBody(htmlMessage);
	        
	        try {
	            service.send(message);
//	            LOG.warning("[INFO-MAILSERVICE] Message has been sent to " + toAddress);
	        } catch (IOException e) {
	            LOG.warning("[WARN-MAILSERVICE] Can't send email to " + toAddress + " about " + title + " : " + e.getMessage());
	        }
	    } else {
	    	MailUtil.send(toAddress, title, htmlMessage);
	    	LOG.warning("[INFO-SMTP] Message has been sent to " + toAddress);
	    }
    }
	public void send(List<String> toAddress, String title, String htmlMessage) {
		if (StringUtils.isNotEmpty(this.site) && "live".equals(site)) {
			Map<Boolean, List<String>> targets = splitSmtpTargets(toAddress);
			List<String> mailServiceTarget = targets.get(false);
	    	List<String> smtpTarget = targets.get(true);
	    	
	    	if (mailServiceTarget.size() > 0) {
				MailService service = MailServiceFactory.getMailService();
				MailService.Message message = new MailService.Message();
				message.setSender(fromAddress);
				message.setReplyTo(fromAddress);
				message.setTo(mailServiceTarget);
				message.setSubject(title);
				message.setHtmlBody(htmlMessage);
				try {
					service.send(message);
//					LOG.info("[INFO-MAILSERVICE] message has been sent to " + mailServiceTarget);
				} catch (IOException e) {
					LOG.warning("[WARN-MAILSERVICE] Can't send email to " + mailServiceTarget + " about " + title
							+ ": " + e.getMessage());
				}
	    	}
	    	if (smtpTarget.size() > 0) {
	    		MailUtil.send(smtpTarget, title, htmlMessage);
	    		LOG.warning("[INFO-SMTP] Message has been sent to " + smtpTarget);
	    	}
		} else {
			MailUtil.send(toAddress, title, htmlMessage);
			LOG.warning("[INFO-SMTP] Message has been sent to " + toAddress);
		}
	}

	@Deprecated
    public void sendOld(String toAddress, String title, String htmlMessage) {
	    if (StringUtils.isNotEmpty(this.site) && "live".equals(site)) {
	        MailService service = MailServiceFactory.getMailService();
	        MailService.Message message = new MailService.Message();
	        message.setSender(fromAddress);
	        message.setTo(toAddress);
	        message.setSubject(title);
	        message.setHtmlBody(htmlMessage);
	        try {
	            service.send(message);
	            LOG.warning("[INFO] Message has been sent to " + toAddress);
	        } catch (IOException e) {
	            LOG.warning("Can't send email to " + toAddress + " about " + title + " : " + e.getMessage());
	        }
	    } else {
	    	MailUtil.send(toAddress, title, htmlMessage);
	    }
    }
	@Deprecated
	public void sendOld(List<String> toAddress, String title, String htmlMessage) {
		if (StringUtils.isNotEmpty(this.site) && "live".equals(site)) {
			MailService service = MailServiceFactory.getMailService();
			MailService.Message message = new MailService.Message();
			message.setSender(fromAddress);
			message.setTo(toAddress);
			message.setSubject(title);
			message.setHtmlBody(htmlMessage);
			try {
				service.send(message);
				LOG.info("message has been sent to " + toAddress);
			} catch (IOException e) {
				LOG.warning("Can't send email to " + toAddress + " about " + title
						+ ": " + e.getMessage());
			}
		} else {
			MailUtil.send(toAddress, title, htmlMessage);
		}
	}

	public void send(List<String> toAddressList, String subject, String body, byte[] attachmentBytes, String attachmentName, String mimeType){
		MailService mailService = MailServiceFactory.getMailService();
		MailService.Message message = new MailService.Message();
		message.setSender(fromAddress);
		message.setSubject(subject);
		message.setTo(toAddressList);
		message.setHtmlBody("<HTML>" + body + "</HTML>");
		if (attachmentName == null) {
			attachmentName = "no-name";
		}
		if (attachmentBytes != null) {
			MailService.Attachment attachment = new MailService.Attachment(
					attachmentName, attachmentBytes);
			message.setAttachments(attachment);
		}
		try {
			mailService.send(message);
		} catch (IOException e) {
			LOG.severe("Could not send email with attachment");
		}
	}
	public static void sendEmailQueue(String email, String subject, String body, String queueName) {
		try {
			Queue queue = QueueFactory.getQueue(queueName);
			TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.DEFAULT_EMAIL_SEND_URL);
			taskOptions = taskOptions
					.param(PARAM.EMAIL, email)
					.param(PARAM.SUBJECT,  subject)
					.param(PARAM.BODY, body);
			taskOptions = taskOptions.method(Method.POST);
			queue.add(taskOptions);
		} finally {}
	}
	
	public static void sendEmailQueue(List<String> emailList, String subject, String body, String queueName) {
		try {
			Queue queue = QueueFactory.getQueue(queueName);
			TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.DEFAULT_EMAIL_SEND_URL);
			
			taskOptions = taskOptions
					.param(PARAM.SUBJECT, subject)
					.param(PARAM.BODY, body);
			for (String email : emailList) {
				taskOptions = taskOptions.param(PARAM.EMAIL, email);
			}
			taskOptions = taskOptions.method(Method.POST);
			queue.add(taskOptions);
		} finally {}
	}
	
	public static void sendNoticeEmailQueue(List<String> emailList, String subject, Text body, String queueName) {		
		try {
			Queue queue = QueueFactory.getQueue(queueName);
			TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.DEFAULT_EMAIL_SEND_URL);
			
//			LOG.warning("sendNoticeEmailQueue - body:" + body.getValue() );		// body is Text Object..toString()은 70바이트까지만 보여주게 되어있음
			taskOptions = taskOptions
					.param(PARAM.TEMPLATENAME2, CommonProperty.SEND_ADMIN_NOTICE_EMAIL_TEMPLATE)
					.param(PARAM.SUBJECT, subject)
					.param(PARAM.BODY, body.getValue());
			for (String email : emailList) {
				taskOptions = taskOptions.param(PARAM.EMAIL, email);
			}
			taskOptions = taskOptions.method(Method.POST);
			queue.add(taskOptions);
		} finally {}
	}
}