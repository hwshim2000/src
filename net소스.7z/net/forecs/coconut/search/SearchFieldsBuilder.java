package net.forecs.coconut.search;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import net.forecs.coconut.common.util.CalendarUtil;

import org.apache.commons.lang.StringUtils;

public class SearchFieldsBuilder {
	private StringBuilder andBuilder = null;
	private StringBuilder orBuilder = null;
	private StringBuilder notBuilder = null;
	private final String dateFormat = "yyyy-MM-dd";
	
	public SearchFieldsBuilder and(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return and(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder and(String field, String value) {
		if (StringUtils.isNotBlank(value)) {
			value = getValidValue(value);
			if (andBuilder == null) {
				andBuilder = new StringBuilder();
				andBuilder.append(String.format("%s=\"%s\"", field, value));
			} else {
				andBuilder.append(String.format(" AND %s=\"%s\"", field, value));
			}
		}
		
		return this;
	}
	
	public SearchFieldsBuilder and(String field, Collection<String> values) {
		if (values != null && values.size() > 0) {
			if (values.size() == 1) { return and(field, values.iterator().next()); } 
			List<String> newValueList = new ArrayList<String>();
			for (String value: values) {
				value = getValidValue(value);
				newValueList.add(String.format("\"%s\"", value));
			}
			if (andBuilder == null) {
				andBuilder = new StringBuilder();
				andBuilder.append(String.format("(%s=%s)", field, StringUtils.join(newValueList, " OR ")));
			} else {
				andBuilder.append(String.format(" AND (%s=%s)", field, StringUtils.join(newValueList, " OR ")));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder or(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return or(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder or(String field, String value) {
		if (StringUtils.isNotBlank(value)) {
			value = getValidValue(value);
			String newValue = parseValue(value);
			if (orBuilder == null) {
				orBuilder = new StringBuilder();
				orBuilder.append(String.format("(%s=%s)", field, newValue));
			} else {
				orBuilder.append(String.format(" OR (%s=%s)", field, newValue));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder or(String field, Collection<String> values) {
		if (values != null && values.size() > 0) {
			if (values.size() == 1) { return or(field, values.iterator().next()); } 
			List<String> newValueList = new ArrayList<String>();
			for (String value: values) {
				value = getValidValue(value);
				newValueList.add(String.format("\"%s\"", value));
			}
			
			if (orBuilder == null) {
				orBuilder = new StringBuilder();
				orBuilder.append(String.format("(%s=%s)", field, StringUtils.join(newValueList, " OR ")));
			} else {
				orBuilder.append(String.format(" OR (%s=%s)", field, StringUtils.join(newValueList, " OR ")));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder andBetween(String field, Date startDate, Date endDate) {
		try {
			if (startDate != null && endDate !=null) {
				String formattedStartDate = CalendarUtil.toString(startDate, dateFormat);
				String formattedEndDate = CalendarUtil.toString(endDate, dateFormat);
				
				return andBetween(field, formattedStartDate, formattedEndDate);
			} else if (startDate != null) {
				return andGE(field, startDate);
			} else {
				return andLE(field, endDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	
	public SearchFieldsBuilder orBetween(String field, Date startDate, Date endDate) {
		try {
			if (startDate != null && endDate !=null) {
				String formattedStartDate = CalendarUtil.toString(startDate, dateFormat);
				String formattedEndDate = CalendarUtil.toString(endDate, dateFormat);
				
				return orBetween(field, formattedStartDate, formattedEndDate);
			} else if (startDate != null) {
				return orGE(field, startDate);
			} else {
				return orLE(field, endDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	
	public SearchFieldsBuilder andBetween(String field, String startDate, String endDate) {
		if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if (andBuilder == null) {
				andBuilder = new StringBuilder();
				andBuilder.append(String.format("(%s>=%s AND %s<=%s)", field, startDate, field, endDate));
			} else {
				andBuilder.append(String.format(" AND (%s>=%s AND %s<=%s)",  field, startDate, field, endDate));
			}
		} else if (StringUtils.isNotBlank(startDate)) {
			return andGE(field, startDate);
		} else {
			return andLE(field, endDate);
		}
		return this;
	}
	
	public SearchFieldsBuilder orBetween(String field, String startDate, String endDate) {
		if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate)) {
			if (orBuilder == null) {
				orBuilder = new StringBuilder();
				orBuilder.append(String.format("(%s>=%s AND %s<=%s)", field, startDate, field, endDate));
			} else {
				orBuilder.append(String.format(" OR (%s>=%s AND %s<=%s)",  field, startDate, field, endDate));
			}
		} else if (StringUtils.isNotBlank(startDate)) {
			return orGE(field, startDate);
		} else {
			return orLE(field, endDate);
		}
		return this;
	}
	public SearchFieldsBuilder andGE(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return andGE(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder andGE(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (andBuilder == null) {
				andBuilder = new StringBuilder();
				andBuilder.append(String.format("(%s>=%s)", field, date));
			} else {
				andBuilder.append(String.format(" AND (%s>=%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder andGT(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return andGT(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder andGT(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (andBuilder == null) {
				andBuilder = new StringBuilder();
				andBuilder.append(String.format("(%s>%s)", field, date));
			} else {
				andBuilder.append(String.format(" AND (%s>%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder andLE(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return andLE(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder andLE(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (andBuilder == null) {
				andBuilder = new StringBuilder();
				andBuilder.append(String.format("(%s<=%s)", field, date));
			} else {
				andBuilder.append(String.format(" AND (%s<=%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder andLT(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return andLT(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder andLT(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (andBuilder == null) {
				andBuilder = new StringBuilder();
				andBuilder.append(String.format("(%s<%s)", field, date));
			} else {
				andBuilder.append(String.format(" AND (%s<%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder orGE(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return orGE(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder orGE(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (orBuilder == null) {
				orBuilder = new StringBuilder();
				orBuilder.append(String.format("(%s>=%s)", field, date));
			} else {
				orBuilder.append(String.format(" OR (%s>=%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder orGT(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return orGT(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder orGT(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (orBuilder == null) {
				orBuilder = new StringBuilder();
				orBuilder.append(String.format("(%s>%s)", field, date));
			} else {
				orBuilder.append(String.format(" OR (%s>%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder orLE(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return orLE(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder orLE(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (orBuilder == null) {
				orBuilder = new StringBuilder();
				orBuilder.append(String.format("(%s<=%s)", field, date));
			} else {
				orBuilder.append(String.format(" OR (%s<=%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder orLT(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return orLT(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder orLT(String field, String date) {
		if (StringUtils.isNotBlank(date)) {
			if (orBuilder == null) {
				orBuilder = new StringBuilder();
				orBuilder.append(String.format("(%s<%s)", field, date));
			} else {
				orBuilder.append(String.format(" OR (%s<%s)",  field, date));
			}
		}
		return this;
	}
	
	public SearchFieldsBuilder not(String field, Date date) {
		try {
			if (date != null) {
				String formattedDate = CalendarUtil.toString(date, dateFormat);
				return not(field, formattedDate);
			}
		} catch (Exception ex) {}
		return this;
	}
	public SearchFieldsBuilder not(String field, String value) {
		if (StringUtils.isNotBlank(value)) {
			value = this.getValidValue(value);
			if (notBuilder == null) {
				notBuilder = new StringBuilder();
			}
			notBuilder.append(String.format(" NOT %s=\"%s\"", field, value));
		}
		return this;
	}
	
	public SearchFieldsBuilder not(String field, Collection<String> values) {
		if (values != null && values.size() > 0) {
			if (values.size() == 1) { return not(field, values.iterator().next()); } 
			List<String> newValueList = new ArrayList<String>();
			for (String value: values) {
				value = getValidValue(value);
				newValueList.add(String.format("\"%s\"", value));
			}
			if (notBuilder == null) {
				notBuilder = new StringBuilder();
			}
			notBuilder.append(String.format(" NOT (%s=%s)", field, StringUtils.join(newValueList, " OR ")));
		}
		return this;
	}
	
	public String build() {
		StringBuilder fieldsBuilder = null;
		
		if (andBuilder != null) {
			fieldsBuilder = new StringBuilder();
			fieldsBuilder.append(andBuilder);
		}
		
		if (orBuilder != null) {
			if (fieldsBuilder != null) {
				fieldsBuilder.append(" AND")
					.append(" (")
					.append(orBuilder)
					.append(") ");
			} else {
				fieldsBuilder = new StringBuilder();
				fieldsBuilder
					.append(" (")
					.append(orBuilder)
					.append(") ");
			}
		}
		
		if (notBuilder != null) {
			fieldsBuilder.append(notBuilder);
		}
		
		return fieldsBuilder!=null?fieldsBuilder.toString():null;
	}
	
	private String getValidValue(String value) {
		return value.trim().replaceAll("[~\"]", "");
	}

	private String parseValue(String value) {
		if (StringUtils.isBlank(value)) {
			return null;
		}
		
		String newValue = getValidValue(value);
				
		String[] valArr = newValue.split("[, ]");
		List<String> valList = new ArrayList<String>();
		for (String val : valArr) {
			if (StringUtils.isNotBlank(val)) {
				//valList.add(String.format("\"%s\"", val));
				valList.add(String.format("\"~%s\"", val));
			}
		}
		if (valList.size()==0) { return null; }
		else { return StringUtils.join(valList, " OR "); }
		//else { return StringUtils.join(valList, " AND "); }
	}
	
//	private String parseValue(String value) {
//		value = value.replaceAll("[~=:, ]", "");
//				
//		String[] vals = value.split(" ");
//		List<String> valList = new ArrayList<String>(Arrays.asList(vals));
//		if (valList != null && valList.size()> 0) {
//			while(true) {
//				if ("AND".equals(valList.get(valList.size()-1)) || "OR".equals(valList.get(valList.size()-1))) {
//					valList.remove(valList.size()-1);
//				} else {
//					break;
//				}
//			}
//			
//			while(true) {
//				if ("AND".equals(valList.get(0)) || "OR".equals(valList.get(0))) {
//					valList.remove(0);
//				} else {
//					break;
//				}
//			}
//		}
//		
//		if (valList.size()==0) { return null; }
//		
//		if (valList.contains("AND")) {
//			return StringUtils.join(valList, " AND ");
//		} else {
//			return StringUtils.join(valList, " OR ");
//		}
//	}
}

