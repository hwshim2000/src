package net.forecs.coconut.search;

import lombok.Getter;
import lombok.Setter;

public class IndexUsage {
	@Getter @Setter
	private String indexName;
	@Getter @Setter
	private long usage;
	@Getter @Setter
	private long limit;
	@Getter @Setter
	private long count;
	
	public IndexUsage(String indexName, long usage, long limit, long count) {
		this.indexName = indexName;
		this.usage = usage;
		this.limit = limit;
		this.count = count;
	}
}
