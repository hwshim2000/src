package net.forecs.coconut.search.index;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.CreateLetterIndexUtil;
import net.forecs.coconut.entity.workspace.TaskChecklists;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;

@Deprecated
public class ChecklistIndex implements Serializable {

	private static final long serialVersionUID = 7617294050500650513L;
	
	public ChecklistIndex() {}
	public ChecklistIndex(TaskChecklists taskChecklists) {
		this.key = taskChecklists.getKey();
		this.domainId = taskChecklists.getDomainId();
		this.boardId = taskChecklists.getBoardId();
		this.taskId = taskChecklists.getTaskId();
		this.taskChecklistId = taskChecklists.getTaskChecklistId();
		this.title = CreateLetterIndexUtil.createLetterIndex(taskChecklists.getTitle());
		this.description = CreateLetterIndexUtil.createLetterIndex(taskChecklists.getDescription());
		this.creator = taskChecklists.getCreator();
	}
	
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;
	@Getter @Setter
	private String domainId;
	@Getter @Setter
	private String boardId;
	@Getter @Setter
	private String taskId;
	@Getter @Setter
	private String taskChecklistId;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String title;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text description;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public void setDescription(Text description) {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		this.description = description;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getDescription() {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		return description;
	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String creator;
	
	@Getter @Setter
	private String nextPageToken;
}
