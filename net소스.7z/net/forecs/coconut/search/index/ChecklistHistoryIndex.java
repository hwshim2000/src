package net.forecs.coconut.search.index;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.CreateLetterIndexUtil;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;

@Deprecated
public class ChecklistHistoryIndex  implements Serializable {

	private static final long serialVersionUID = -7033595682321750841L;
	
	public ChecklistHistoryIndex() {}
	
	public ChecklistHistoryIndex(TaskChecklistHistories taskChecklistHistory) {
		this.key = taskChecklistHistory.getKey();
		this.domainId = taskChecklistHistory.getDomainId();
		this.boardId = taskChecklistHistory.getBoardId();
		this.taskId = taskChecklistHistory.getTaskId();
		this.taskChecklistHistoryId = taskChecklistHistory.getTaskChecklistHistoryId();
		this.activityType = taskChecklistHistory.getActivityType().toString();
		this.title = taskChecklistHistory.getTitle();
		//this.title = CreateLetterIndexUtil.createLetterIndex(taskChecklistHistory.getTitle());
		this.description = this.resolveSearchDescription(taskChecklistHistory.getTaskChecklists());
		//this.searchDescription = this.resolveSearchDescription(taskChecklistHistory.getTaskChecklists());
		this.created = taskChecklistHistory.getCreated();
		this.creator = taskChecklistHistory.getCreator();
	}
	
	private Text resolveSearchDescription(List<TaskChecklists> taskChecklists) {
		StringBuilder sb = new StringBuilder();
		if (taskChecklists != null) {
			for (TaskChecklists taskChecklist : taskChecklists) {
				if (StringUtils.isNotBlank(taskChecklist.getTitle())) {
					sb.append(taskChecklist.getTitle());
					sb.append(" ");
				}
				if (StringUtils.isNotBlank(taskChecklist.getDescription().getValue())) {
					sb.append(taskChecklist.getDescription().getValue());
					sb.append(" ");
				}
			}
		}
		
		return new Text(CreateLetterIndexUtil.createLetterIndex(sb.toString()));
	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;
	@Getter @Setter
	private String domainId;
	@Getter @Setter
	private String boardId;
	@Getter @Setter
	private String taskId;
	@Getter @Setter
	private String checklistId;
	@Getter @Setter
	private String taskChecklistHistoryId;
	@Getter @Setter
	private String activityType;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String title;

	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text description;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public void setDescription(Text description) {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		this.description = description;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getDescription() {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		return description;
	}

//	@JsonIgnore
//	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
//	private Text searchDescription;
//	@JsonIgnore
//	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
//	public void setSearchDescription(Text searchDescription) {
//		if ((searchDescription == null) || (searchDescription.getValue() == null)) searchDescription = new Text("");
//		this.searchDescription = searchDescription;
//	}
//	@JsonIgnore
//	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
//	public Text getSearchDescription() {
//		if ((searchDescription == null) || (searchDescription.getValue() == null)) searchDescription = new Text("");
//		return searchDescription;
//	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String creator;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date created;
	
	@Getter @Setter
	private String nextPageToken;
}
