package net.forecs.coconut.search.index;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.CreateLetterIndexUtil;
import net.forecs.coconut.entity.calendar.Events;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;

public class EventIndex implements Serializable {

	private static final long serialVersionUID = -2545454026421455361L;
	
	public EventIndex() {}
	public EventIndex(Events event) {
		this.key = event.getKey();
		this.domainId = event.getDomainId();
		this.boardId = event.getBoardId();
		this.taskId = event.getTaskId();
		this.eventId = event.getEventId();
		this.eventType = event.getEventType().toString();
		this.title = CreateLetterIndexUtil.createLetterIndex(event.getTitle());
		this.description = CreateLetterIndexUtil.createLetterIndex(event.getDescription());
		this.archiveYN = event.getArchiveYN();
		this.creator = event.getCreator();
	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;
	@Getter @Setter
	private String domainId;
	@Getter @Setter
	private String boardId;
	@Getter @Setter
	private String taskId;
	@Getter @Setter
	private String eventId;
	@Getter @Setter
	private String eventType;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String title;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text description;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public void setDescription(Text description) {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		this.description = description;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getDescription() {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		return description;
	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String archiveYN;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String creator;
	
	@Getter @Setter
	private String nextPageToken;
}
