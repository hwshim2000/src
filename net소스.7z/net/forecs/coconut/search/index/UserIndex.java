package net.forecs.coconut.search.index;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.SearchUtil;
import net.forecs.coconut.entity.user.Users;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;

@Deprecated
public class UserIndex implements Serializable {

	private static final long serialVersionUID = -5951146816837476810L;
	
	public UserIndex() {}
	
	public UserIndex(Users user) {
		this.key = user.getKey();
		this.id = user.getId();
		this.email = user.getEmail();
		this.userName = user.getUserName();
		this.nickName = user.getNickName();
		this.userId = user.getUserId();
		this.isActive = Boolean.toString(user.isActive());
		this.isValid = Boolean.toString(user.isValid());
		
		Set<String> splitSet = new HashSet<String>();
		
		if (StringUtils.isNotBlank(this.id)) { splitSet.addAll(SearchUtil.split(this.id)); }
		if (StringUtils.isNotBlank(this.email)) { splitSet.addAll(SearchUtil.split(user.getEmail(), "[.@]")); }
		if (StringUtils.isNotBlank(this.userName)) { splitSet.addAll(SearchUtil.split(user.getUserName())); }
		if (StringUtils.isNotBlank(this.nickName)) { splitSet.addAll(SearchUtil.split(user.getNickName())); }
		
		this.indexStr = StringUtils.join(splitSet, " ");
	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;
	@Getter @Setter
	private String id;
	@Getter @Setter
	private String userId;
	@Getter @Setter
	private String email;
	@Getter @Setter
	private String userName;
	@Getter @Setter
	private String nickName;
	@Getter @Setter
	private String isActive;
	@Getter @Setter
	private String isValid;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String indexStr;
	
	@Getter @Setter
	private String nextPageToken;
}
