package net.forecs.coconut.search.index;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.entity.domain.Stages;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;

public class TaskIndex implements Serializable {
	private static final long serialVersionUID = -4699979572767662499L;

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;
	@Getter @Setter
	private String domainId;
	@Getter @Setter
	private String boardId;
	@Deprecated
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String tasklistId;
	@Getter @Setter
	private String taskId;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String title;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text description;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public void setDescription(Text description) {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		this.description = description;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getDescription() {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		return description;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text wiki;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public void setWiki(Text wiki) {
		if ((wiki == null) || (wiki.getValue() == null)) wiki = new Text("");
		this.wiki = wiki;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getWiki() {
		if ((wiki == null) || (wiki.getValue() == null)) wiki = new Text("");
		return wiki;
	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String assignMembers;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String assignUserIds;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String checklists;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String archiveYN;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date created;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String creator;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date modified;
	
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String importance;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date dueDate;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date completeDate;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String subscriptionMembers;
	
//	@Getter @Setter
//	@JsonIgnore
//	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
//	private String taskStage;
	
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Integer stageOrdinal;

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String boardTitle;

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date boardCreated;
	
	@Getter @Setter
	private String nextPageToken;
	
	@Getter @Setter
	private Stages stage;
	
	public String getTaskStage() {
		if (stage != null) {
			return stage.getTaskStage();
		}
		return null;
//		if (stageOrdinal != null) {
//			return TaskStage.values()[stageOrdinal];
//		} else if (StringUtils.isNotBlank(tasklistId)) {
//			return TaskStage.valueOf(KeyFactory.stringToKey(tasklistId).getName());
//		}
//		return null;
	}
}
