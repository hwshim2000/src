package net.forecs.coconut.search.index;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.CreateLetterIndexUtil;
import net.forecs.coconut.common.util.SearchUtil;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;


public class AttachmentIndex implements Serializable {

	private static final long serialVersionUID = -7791228469164104524L;

	public AttachmentIndex() {
	}

	public AttachmentIndex(Attachments attachment, AttachmentsMap attachmentMap) {
		this.setKey(attachmentMap.getKey());
		setDomainId(attachment.getDomainId());
		this.setTitle(attachment.getTitle());
		this.setKindId(attachmentMap.getKindId());
		this.setAttachmentId(attachmentMap.getAttachmentId());
		this.setArchiveYN(attachmentMap.getArchiveYN());
		this.setCreated(attachmentMap.getCreated());
		this.setCreator(attachment.getCreator());
		this.setModified(attachmentMap.getModified());

		setFileName(getIndexStringForFileName(attachment.getFileName()));
		setMimeType(attachment.getMimeType());
	}

	private String getIndexStringForFileName(String filename) {
		String attachmentIndexStr = null;
		HashSet<String> splitSet = new HashSet<String>();
		if (StringUtils.isNotBlank(filename)) { splitSet.addAll(SearchUtil.split(filename, "[\\[\\]\\(\\)\\{\\}\\<\\>\\.\\| :_-]")); }
		if (splitSet.size() > 0) {
			attachmentIndexStr = CreateLetterIndexUtil.createLetterIndex(splitSet);
		}
		
		return attachmentIndexStr;
	}
	
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;
	@Getter @Setter
	private String domainId;
	@Getter @Setter
	private String boardId;
	@Getter @Setter
	private String taskId;
	@Getter @Setter
	private String title;
	@Getter @Setter
	private String kind;
	@Getter @Setter
	private String kindId;
	@Getter @Setter
	private String attachmentId;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String archiveYN;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date created;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String creator;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date modified;

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String fileName;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String mimeType;
	
	@Getter @Setter
	private String nextPageToken;
}
