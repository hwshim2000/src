package net.forecs.coconut.search.index;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.CreateLetterIndexUtil;
import net.forecs.coconut.common.util.JSONUtil;
import net.forecs.coconut.entity.workspace.TaskTimelines;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;

public class TimelineIndex implements Serializable {
	
	private static final long serialVersionUID = 6976808641840280417L;
	
	public TimelineIndex() {}
	public TimelineIndex(TaskTimelines taskTimeline) {
		this.key = taskTimeline.getKey();
		this.domainId = taskTimeline.getDomainId();
		this.boardId = taskTimeline.getBoardId();
		this.taskId = taskTimeline.getTaskId();
		this.taskTimelineId = taskTimeline.getTaskTimelineId();		
		this.title = CreateLetterIndexUtil.createLetterIndex(taskTimeline.getTitle());
		this.description = CreateLetterIndexUtil.createLetterIndex(taskTimeline.getDescription());
		this.links = CreateLetterIndexUtil.createLetterIndex(JSONUtil.toIndexingValues(taskTimeline.getLinks(), true));
		this.creator = taskTimeline.getCreator();
		this.created = taskTimeline.getCreated();
		this.lastCommented = taskTimeline.getLastCommented();
	}
	
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;
	@Getter @Setter
	private String domainId;
	@Getter @Setter
	private String boardId;
	@Getter @Setter
	private String taskId;
	@Getter @Setter
	private String taskTimelineId;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String title;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text description;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public void setDescription(Text description) {
		if (description == null || StringUtils.isBlank(description.getValue())) description = new Text("");
		this.description = description;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getDescription() {
		if (description == null || StringUtils.isBlank(description.getValue())) description = new Text("");
		return description;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text links;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public void setLinks(Text links) {
		if (links == null || StringUtils.isBlank(links.getValue())) links = new Text("");
		this.links = links;
	}
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getLinks() {
		if (links == null || StringUtils.isBlank(links.getValue())) links = new Text("");
		return links;
	}

	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String creator;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date created;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String attachments;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String assignMembers;
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Date lastCommented;
	
	@Getter @Setter
	private String nextPageToken;
}
