package net.forecs.coconut.search;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class SearchStorageUsage {
	@Getter @Setter
	private String domainName;
	@Getter @Setter
	private long storageUsage;
	@Getter @Setter
	private long storageLimit;
	@Getter @Setter
	private long indexCount;
	
	private List<IndexUsage> indexUsageList;
	public void setIndexUsageList(List<IndexUsage> indexUsageList) {
		if (indexUsageList == null) { indexUsageList = new ArrayList<IndexUsage>(); }
		this.indexUsageList = indexUsageList;
	}
	public List<IndexUsage> getIndexUsageList() {
		if (indexUsageList == null) { indexUsageList = new ArrayList<IndexUsage>(); }
		return indexUsageList;
	}
	
	public void append(String indexName, long usage, long limit, long count) {
		this.storageUsage += usage;
		this.storageLimit += limit;
		this.indexCount += count;
		this.getIndexUsageList().add(new IndexUsage(indexName, usage, limit, count));
	}
}
