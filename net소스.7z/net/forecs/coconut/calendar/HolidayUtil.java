package net.forecs.coconut.calendar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.LocaleUtil;
import net.forecs.coconut.endpoint.setting.UserSettingService;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.setting.UserSetting;

import org.apache.commons.lang.StringUtils;

public final class HolidayUtil {
//	private static final Logger LOG = Logger.getLogger(HolidayUtil.class);
	private static final String Y = "Y";
	private static final String N = "N";
	
	private final static Map<String, Holiday> holidayMap = new HashMap<String, Holiday>();
	
	static {
		// 24절기 + @
		// 참고 URL : http://lifesci.net/pod/plugin/eclon24/
		//------------------------------------------------------------------------------------------------------
		// 중요!!!!!!!!!!!!!!!!!!!!!!!
		// 같은 절기일 경우 둘중의 하나는 exceptionDate외의 중복적으로 나타나는것을 막기 위해 untilDate가 반드시 있어야 하며, untilYear는 중복이 발생하지 않는 범위를 설정
		//------------------------------------------------------------------------------------------------------
		// 등록방법1 (Example)
		// title, year, date, untilYear, exceptionYears, solarType, dayOffYN, startDateOffset, endDateOffset, leap, recurrenceYN
		addHoliday(new Holiday("소한", "1970", "0105", null, "2015,2016,2019,2020", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("소한", "2015", "0106", "2021", "2017,2018,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("대한", "1970", "0120", null, "2016", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("대한", "2015", "0121", "2021", "2015,2017,2018,2019,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		// 또는  반복없이 2016년에만 한번 발생시킴, addHoliday(new Holiday("대한", "2016", "0121", null, null, SolarType.SOLAR, N, 0, 0, 0, N));
		
		addHoliday(new Holiday("입춘", "2015", "0203", "2021", "2015,2016,2017,2018,2019,2020", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("입춘", "1970", "0204", null, "2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("우수", "2015", "0218", "2021", "2015,2016,2018,2019,2020", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("우수", "1970", "0219", null, "2017,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("경칩", "1970", "0305", null, "2016,2018,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("경칩", "2015", "0306", "2021", "2015,2017,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("춘분", "1970", "0320", null, "2015,2018,2019,", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("춘분", "2015", "0321", "2021", "2016,2017,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("청명", "1970", "0404", null, "2015,2018,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("청명", "2015", "0405", "2021", "2016,2017,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("곡우", "1970", "0420", null, "2020", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("곡우", "2015", "0419", "2021", "2015,2016,2017,2018,2019,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("입하", "1970", "0505", null, "2015,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("입하", "2015", "0506", "2021", "2016,2017,2018,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("소만", "1970", "0521", null, "2016,2020", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("소만", "2015", "0520", "2021", "2015,2017,2018,2019,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("망종", "1970", "0605", null, "2015,2018", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("망종", "2015", "0606", "2021", "2016,2017,2019,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("하지", "1970", "0621", null, "2015,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("하지", "2015", "0622", "2021", "2016,2017,2018,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("소서", "1970", "0707", null, "2024", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("소서", "2015", "0706", "2021", "2015,2016,2017,2018,2019,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("대서", "1970", "0723", null, "2016,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("대서", "2015", "0722", "2021", "2015,2017,2018,2019", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("입추", "1970", "0807", null, "2015,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("입추", "2015", "0808", "2021", "2016,2017,2018,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("처서", "1970", "0823", null, "2028", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("처서", "2015", "0822", "2021", "2015,2016,2017,2018,2019,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("백로", "1970", "0907", null, "2015,2018,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("백로", "2015", "0908", "2021", "2016,2017,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("추분", "1970", "0923", null, "2016,2020", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("추분", "2015", "0922", "2021", "2015,2017,2018,2019,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("한로", "1970", "1008", null, "2048", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("한로", "2015", "1007", "2021", "2015,2016,2017,2018,2019,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("상강", "1970", "1023", null, "2015,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("상강", "2015", "1024", "2021", "2016,2017,2018,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("입동", "1970", "1107", null, "2015,2019", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("입동", "2015", "1108", "2021", "2016,2017,2018,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("소설", "1970", "1122", null, "2015", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("소설", "2015", "1123", "2021", "2016,2017,2018,2019,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("대설", "1970", "1207", null, "2028", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("대설", "2015", "1206", "2021", "2015,2016,2017,2018,2019,2020,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		addHoliday(new Holiday("동지", "1970", "1222", null, "2016,2020", SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("동지", "2015", "1221", "2021", "2015,2017,2018,2019,2021", SolarType.SOLAR, N, 0, 0, 0));
		
		// 한식은 절기가 아니다.
		// 등록방법 2 (Example)
		//addHoliday(new Holiday("한식", "1970", "0406", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHolidays("한식", "2016,2017,2020,2021,2024,2025", "0405", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("한식", "2015,2018,2019,2022,2023", "0406", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		
		// 초복/중복은 24절기가 아님
		addHolidays("초복", "2021", "0711", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2017", "0712", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2015", "0713", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2024,2028,2030", "0714", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2026", "0715", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2020,2022", "0716", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2016,2018", "0717", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2029", "0719", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2025,2027", "0720", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2023", "0721", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("초복", "2019", "0722", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		
		addHolidays("중복", "2021", "0721", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("중복", "2017", "0722", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("중복", "2015", "0723", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("중복", "2024,2028,2030", "0724", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("중복", "2026", "0725", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("중복", "2020,2022", "0726", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("중복", "2016,2018", "0727", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("중복", "2029", "0729", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("중복", "2025,2027", "0730", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("중복", "2023", "0731", null, null, SolarType.SOLAR, N, 0, 0, 0, N);
		addHolidays("중복", "2019", "0801", null, null, SolarType.SOLAR, N, 0, 0, 0,N);

		addHolidays("말복", "2029", "0808", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2025,2027", "0809", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2021,2023", "0810", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2017,2019", "0811", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2015", "0812", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2028,2030", "0813", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2024,2026", "0814", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2020,2022", "0815", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		addHolidays("말복", "2016,2018", "0816", null, null, SolarType.SOLAR, N, 0, 0, 0,N);
		
		// 양력 기념일
		addHoliday(new Holiday("신정", "1970", "0101", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		addHoliday(new Holiday("발렌타인데이", "1970", "0214", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("삼일절", "1970", "0301", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		addHoliday(new Holiday("납세자의날", "1970", "0301", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("화이트데이", "1970", "0314", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("상공의날", "1970", "0318", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("황토예비군의날", "1970", "0403", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("식목일", "1970", "0405", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("보건의날", "1970", "0407", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("과학의날", "1970", "0421", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("정보통신의날", "1970", "0422", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("지구의날", "1970", "0422", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("근로자의날", "1970", "0501", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("어린이날", "1970", "0505", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		addHoliday(new Holiday("어버이날", "1970", "0508", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("스승의날", "1970", "0515", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("5.18민주화운동기념일", "1970", "0518", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("성년의날", "1970", "0518", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("부부의날", "1970", "0518", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("의병의날", "1970", "0601", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("현충일", "1970", "0606", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		addHoliday(new Holiday("6.25한국전쟁", "1970", "0625", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("제헌절", "1970", "0717", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("광복절", "1970", "0815", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		addHoliday(new Holiday("철도의날", "1970", "0918", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("국군의날", "1970", "1001", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("노인의날", "1970", "1002", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("개천절", "1970", "1003", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		addHoliday(new Holiday("재향군인의날", "1970", "1008", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("한글날", "1970", "1009", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		addHoliday(new Holiday("중양절", "1970", "1021", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("무역의날", "1970", "1205", null, null, SolarType.SOLAR, N, 0, 0, 0));
		addHoliday(new Holiday("성탄절", "1970", "1225", null, null, SolarType.SOLAR, Y, 0, 0, 0));
		
		// 음력 기념일
		addHoliday(new Holiday("설날", "1970", "0101", null, null, SolarType.LUNAR, Y, -1, 1, 0));
		addHoliday(new Holiday("정월대보름", "1970", "0115", null, null, SolarType.LUNAR, N, 0, 0, 0));
		addHoliday(new Holiday("부처님오신날", "1970", "0408", null, null, SolarType.LUNAR, Y, 0, 0, 0));
		addHoliday(new Holiday("단오", "1970", "0505", null, null, SolarType.LUNAR, N, 0, 0, 0));
		addHoliday(new Holiday("칠석", "1970", "0707", null, null, SolarType.LUNAR, N, 0, 0, 0));
		addHoliday(new Holiday("추석", "1970", "0815", null, null, SolarType.LUNAR, Y, -1, 1, 0));
	}
	
	private static String createKey(Holiday holiday) {
		return String.format("%s-%s-%s-%s", holiday.getSolarType(), holiday.getTitle(), holiday.getYear(), holiday.getDate());
	}
	
	private static void addHoliday(Holiday holiday) {
			holidayMap.put(createKey(holiday), holiday);
	}
	/**
	 * years의 값이 배열값일 경우 반복을 하지 않는다.
	 * @param title
	 * @param years
	 * @param date
	 * @param untilYear
	 * @param exceptionYears
	 * @param solarType
	 * @param dayOffYN
	 * @param startDateOffset
	 * @param endDateOffset
	 * @param leap
	 * @param recurrenceYN
	 */
	private static void addHolidays(String title, String years, String date, String untilYear, String exceptionYears, SolarType solarType, String dayOffYN, int startDateOffset, int endDateOffset, int leap, String recurrenceYN) {
		if (StringUtils.isNotBlank(years)) {
			String[] yearsArr = years.split(",");
			if (yearsArr.length > 1) {
				recurrenceYN = N;
				untilYear = null;
				exceptionYears = null;
			}
			
			for (String year : yearsArr) {
				addHoliday(new Holiday(title, year.trim(), date, untilYear, exceptionYears, solarType, dayOffYN, startDateOffset, endDateOffset, leap, recurrenceYN));
			}
		}
	}
	
	private static List<Events> getHolidayEvents(String title, String years, String date, String untilYear, String exceptionYears, SolarType solarType, String dayOffYN, int startDateOffset, int endDateOffset, int leap, String recurrenceYN) {
		List<Events> eventList = new ArrayList<Events>();
		
		if (StringUtils.isNotBlank(years)) {
			String[] yearsArr = years.split(",");
			if (yearsArr.length > 1) {
				recurrenceYN = N;
				untilYear = null;
				exceptionYears = null;
			}
			
			for (String year : yearsArr) {
				Holiday holiday = new Holiday(title, year.trim(), date, untilYear, exceptionYears, solarType, dayOffYN, startDateOffset, endDateOffset, leap, recurrenceYN);
				Events event = (Events)holiday;
				eventList.add(event);
			}
		}
		return eventList;
	}
	
	public static List<Events> createHolidayEventList() {
		List<Events> eventList = new ArrayList<Events>();
		for (Map.Entry<String, Holiday> entry : holidayMap.entrySet()) {
			Events event = (Events)entry.getValue();
//			event.setDomainId(domainId);
//			event.setBoardId(boardId);
			
			event.setKey(KeyUtil.createEventKey(entry.getKey()));
			event.setEventGroupId(event.getEventId());
			if (StringUtils.isEmpty(event.getUid())) {
				event.setUid(event.getEventId());
			}
			
			eventList.add(event);
		}

		return eventList;
	}
	public static List<Events> createHolidayEventList(String userId) {
		UserSetting userSetting = null;
		if (StringUtils.isNotBlank(userId)) {
			userSetting = UserSettingService.getUserLocaleSetting(userId);
		}
		return createHolidayEventList(userSetting);
	}
	public static List<Events> createHolidayEventList(UserSetting userSetting) {
		Locale locale = LocaleUtil.getUserLocale(userSetting);
		return createHolidayEventList(locale);
	}
	public static List<Events> createHolidayEventList(Locale locale) {
		List<Events> eventList = new ArrayList<Events>();
		
		Properties pro = CalendarProperties.readProperties(locale);
		
		for (Map.Entry<Object, Object> entry : pro.entrySet()) {
			String[] strArr = StringUtils.split((String)entry.getValue(), '|');
			
			//String title, String years, String date, String untilYear, String exceptionYears, SolarType solarType,
			//String dayOffYN, int startDateOffset, int endDateOffset, int leap, String recurrenceYN
			
			String title = strArr[0];
			String years = strArr[1];
			String date = strArr[2];
			String untilYear = strArr[3];
			String exceptionYears = strArr[4];
			SolarType solarType = SolarType.valueOf(strArr[5]);
			String dayOffYN = strArr[6];
			int startDateOffset = Integer.parseInt(strArr[7]);
			int endDateOffset = Integer.parseInt(strArr[8]);
			int leap = Integer.parseInt(strArr[9]);
			String recurrenceYN = strArr[10];
			
			if (StringUtils.isBlank(untilYear) || "null".equals(untilYear.toLowerCase())) { untilYear = null; }
			if (StringUtils.isBlank(exceptionYears) || "null".equals(exceptionYears.toLowerCase())) { exceptionYears = null; }
			
			List<Events> events = getHolidayEvents(title, years, date, untilYear, exceptionYears, solarType, dayOffYN, startDateOffset, endDateOffset, leap, recurrenceYN);
			eventList.addAll(events);
//			LOG.warning(key + ":" + pro.get(key));
		}

		return eventList;
	}
/*	
	public static void main(String[] args) {
		List<Events> eventList = createHolidayEventList(Locale.KOREAN);
		
		for (Events event : eventList) {
			LOG.warning(event.getTitle());
		}
	}*/
}

