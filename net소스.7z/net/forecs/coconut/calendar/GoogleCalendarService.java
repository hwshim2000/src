package net.forecs.coconut.calendar;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.security.OAuthUtils;

import com.google.api.client.googleapis.batch.BatchRequest;
import com.google.api.client.googleapis.batch.json.JsonBatchCallback;
import com.google.api.client.googleapis.json.GoogleJsonError;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.Lists;
import com.google.api.services.calendar.model.Calendar;
import com.google.api.services.calendar.model.CalendarList;
import com.google.api.services.calendar.model.CalendarListEntry;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventDateTime;
import com.google.api.services.calendar.model.Events;


public class GoogleCalendarService {
	private static final Logger LOG = Logger.getLogger(GoogleCalendarService.class);
	static final java.util.List<Calendar> addedCalendarsUsingBatch = Lists.newArrayList();

	public static CalendarList listCalendars() throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		return googleCalendar.calendarList().list().execute();
	}
	
	/** test */
	public static void showCalendars() throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		header("Show Calendars");
		CalendarList calendarList = googleCalendar.calendarList().list().execute();
		display(calendarList, googleCalendar);
	}

	public static void addCalendarsUsingBatch(Calendar myCalendar) throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		//header("Add Calendars using Batch");
		BatchRequest batch = googleCalendar.batch();

		// Create the callback.
		JsonBatchCallback<Calendar> callback = new JsonBatchCallback<Calendar>() {
			@Override
			public void onSuccess(Calendar calendar, HttpHeaders responseHeaders) {
				display(calendar);
				addedCalendarsUsingBatch.add(calendar);
			}

			@Override
			public void onFailure(GoogleJsonError e, HttpHeaders responseHeaders) {
				LOG.warning("Error Message: " + e.getMessage());
			}
		};

		googleCalendar.calendars().insert(myCalendar).queue(batch, callback);
		
//		// Create 2 Calendar Entries to insert.
//		Calendar entry1 = new Calendar().setSummary("Calendar for Testing 1");
//		googleCalendar.calendars().insert(entry1).queue(batch, callback);
//
//		Calendar entry2 = new Calendar().setSummary("Calendar for Testing 2");
//		googleCalendar.calendars().insert(entry2).queue(batch, callback);

		batch.execute();
	}

	public static Calendar addCalendar(Calendar calendar) throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		//header("Add Calendar");
		
		Calendar result = googleCalendar.calendars().insert(calendar).execute();
		//display(result);
		return result;
	}

	public static Calendar updateCalendar(Calendar calendar) throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		//header("Update Calendar");
		
		//calendar.setSummary("Updated Calendar for Testing");
		Calendar result = googleCalendar.calendars().patch(calendar.getId(), calendar).execute();
		//display(result);
		return result;
	}

	/** test */
	public static Event addEvent(Calendar calendar, Event event) throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		//header("Add Event");
		Event result = googleCalendar.events().insert(calendar.getId(), event).execute();
		//display(result);
		
		return result;
	}

	/** test */
	public static Event newEvent() {
		Event event = new Event();
		event.setSummary("New Event");
		Date startDate = new Date();
		Date endDate = new Date(startDate.getTime() + 3600000);
		DateTime start = new DateTime(startDate, TimeZone.getTimeZone("UTC"));
		event.setStart(new EventDateTime().setDateTime(start));
		DateTime end = new DateTime(endDate, TimeZone.getTimeZone("UTC"));
		event.setEnd(new EventDateTime().setDateTime(end));
		return event;
	}

	public static void showEvents(Calendar calendar) throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		//header("Show Events");
		Events events = googleCalendar.events().list(calendar.getId()).execute();
		display(events);
	}

	public static void deleteCalendarsUsingBatch(List<Calendar> calendarList) throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		//header("Delete Calendars Using Batch");
		BatchRequest batch = googleCalendar.batch();
		//for (Calendar calendar : addedCalendarsUsingBatch) {
		for (Calendar calendar : calendarList) {
			googleCalendar.calendars().delete(calendar.getId()).queue(batch, new JsonBatchCallback<Void>() {
				@Override
				public void onSuccess(Void content,	HttpHeaders responseHeaders) {
					LOG.warning("Delete is successful!");
				}

				@Override
				public void onFailure(GoogleJsonError e, HttpHeaders responseHeaders) {
					LOG.warning("Error Message: "+ e.getMessage());
				}
			});
		}

		batch.execute();
	}

	public static void deleteCalendar(Calendar calendar) throws IOException {
		com.google.api.services.calendar.Calendar googleCalendar = OAuthUtils.loadCalendarClient();
		//header("Delete Calendar");
		googleCalendar.calendars().delete(calendar.getId()).execute();
	}
	
	static void header(String name) {
		LOG.warning("============== " + name + " ==============");
	}

	static void display(CalendarList calendarList, com.google.api.services.calendar.Calendar googleCalendar) {
		if (calendarList.getItems() != null) {
			for (CalendarListEntry calendar : calendarList.getItems()) {
				display(calendar, googleCalendar);
			}
		}
	}

	static void display(Events events) {
		if (events.getItems() != null) {
			for (Event event : events.getItems()) {
				display(event);
			}
		}
	}

	static void display(CalendarListEntry calendar, com.google.api.services.calendar.Calendar googleCalendar) {
		LOG.warning("ID: " + calendar.getId());
		LOG.warning("Summary: " + calendar.getSummary());
		if (calendar.getDescription() != null) {
			LOG.warning("Description: " + calendar.getDescription());
		}
	}

	static void display(Calendar entry) {
		LOG.warning("ID: " + entry.getId());
		LOG.warning("Summary: " + entry.getSummary());
		if (entry.getDescription() != null) {
			LOG.warning("Description: " + entry.getDescription());
		}
	}

	static void display(Event event) {
		if (event.getStart() != null) {
			LOG.warning("Start Time: " + event.getStart());
		}
		if (event.getEnd() != null) {
			LOG.warning("End Time: " + event.getEnd());
		}
	}
}
