package net.forecs.coconut.calendar;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.AlarmTriggerType;
import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.calendar.Recurrence;

public class Anniversary extends Events {
	private static final long serialVersionUID = -5888398420448831578L;

	Anniversary(String userId, String title, Date anniversaryDate, AnniversaryType anniversaryType, SolarType solarType, int leap) {
		if (solarType == null) { solarType = SolarType.SOLAR; }
		
		setTitle(title);
		try {
			setYear(CalendarUtil.toString(anniversaryDate, "yyyy"));
			setDate(CalendarUtil.toString(anniversaryDate, "MMdd"));
		} catch (Exception ex) {}
		
		setSolarType(solarType);
		setLeap(leap);
		setEventType(EventType.PRIVATE_ANNIVERSARY);
		setAnniversaryType(anniversaryType);
		setEditableYN(N);
		setOwner(userId);
		setCreator(userId);
		setAllDayYN(Y);
		
		try {
			if (SolarType.SOLAR.equals(getSolarType())) {
				//Date solarDate = CalendarUtil.toDate(year+date, "yyyyMMdd");
				//setStartDate(solarDate);
				//setEndDate(solarDate);
				setStartDate(anniversaryDate);
				setEndDate(anniversaryDate);
				setLunarStartDate(CalendarUtil.toLunar(getStartDate()));
				setLunarEndDate(CalendarUtil.toLunar(getEndDate()));
				setLeap((int)CalendarUtil.toLunarWithLeap(anniversaryDate).get("leap"));
				
//				setStartDate(CalendarUtil.getStartDateOfDay(solarDate));
//				setEndDate(CalendarUtil.getEndDateOfDay(solarDate));
//				setLunarStartDate(CalendarUtil.getStartDateOfDay(CalendarUtil.toLunar(getStartDate())));
//				setLunarEndDate(CalendarUtil.getEndDateOfDay(CalendarUtil.toLunar(getEndDate())));
				//setLeap((int)CalendarUtil.toLunarWithLeap(solarDate).get("leap"));
			} else {
				//Date lunarDate = CalendarUtil.toDate(year+date, "yyyyMMdd");
				//Date solarDate = CalendarUtil.toSolarWithLeap(lunarDate, getLeap());
				Date solarDate = CalendarUtil.toSolarWithLeap(anniversaryDate, getLeap());
				setStartDate(solarDate);
				setEndDate(solarDate);
				setLunarStartDate(CalendarUtil.toLunar(getStartDate()));
				setLunarEndDate(CalendarUtil.toLunar(getEndDate()));
				
//				setStartDate(CalendarUtil.getStartDateOfDay(solarDate));
//				setEndDate(CalendarUtil.getEndDateOfDay(solarDate));
//				setLunarStartDate(CalendarUtil.getStartDateOfDay(CalendarUtil.toLunar(getStartDate())));
//				setLunarEndDate(CalendarUtil.getEndDateOfDay(CalendarUtil.toLunar(getEndDate())));
			}
			
			setRecurrenceId(getStartDate().getTime());
			setRecurrenceDate(getStartDate());
			setLunarRecurrenceDate(getLunarStartDate());
			
			Recurrence recurrence = new Recurrence();
			recurrence.setFrequency(Frequency.YEARLY);
			recurrence.setUntil(null);
			recurrence.setInterval(1);
			
			setRecurrence(recurrence);
			setRecurrenceYN(Y);

			// 해당 기념일 오전 9시일 경우 Event시작시간에서 (24-12)즉 12시간을 뺀 시각에 알람이 발생한다.
			// 기념일의 시작은 00시부터 23:59까지(즉 하루 종일)
			setAlarmTriggerType(AlarmTriggerType.HOUR);
			setAlarmTriggerValue(24-12);
			setAlarmYN(Y);
			RecurrenceUtil.estimateAlarmDateTime((Events)this);
		} catch (Exception ex) {}
	}
	
	@Getter @Setter
	private String year;
	@Getter @Setter
	private String date;
}
