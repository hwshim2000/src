package net.forecs.coconut.calendar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.AlarmTriggerType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.calendar.Recurrence;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

public class Holiday extends Events {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5169546422681720408L;
	
	@Transient
	@Getter @Setter
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String year;
	@Transient
	@Getter @Setter
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private String date;
	
	Holiday(String title, String year, String date, String untilYear, String exceptionYears, SolarType solarType, String dayOffYN, int startDateOffset, int endDateOffset, int leap) {
		this(title, year, date, untilYear, exceptionYears, solarType, dayOffYN, startDateOffset, endDateOffset, leap, Y);
	}
	Holiday(String title, String year, String date, String untilYear, String exceptionYears, SolarType solarType, String dayOffYN, int startDateOffset, int endDateOffset, int leap, String recurrenceYN) {
		if (solarType == null) { solarType = SolarType.SOLAR; }
		
		setTitle(title);
		setYear(year);
		setDate(date);
		setSolarType(solarType);
		setLeap(leap);
		setEventType(EventType.SYSTEM_HOLIDAY);
		setEditableYN(N);
		setDayOffYN(dayOffYN);
		setStartDateOffset(startDateOffset);
		setEndDateOffset(endDateOffset);
		setAllDayYN(Y);
		
		try {
			if (SolarType.SOLAR.equals(getSolarType())) {
				Date solarDate = CalendarUtil.toDate(getYear()+getDate(), "yyyyMMdd");
				setStartDate(solarDate);
				setEndDate(solarDate);
				setLunarStartDate(CalendarUtil.toLunar(getStartDate()));
				setLunarEndDate(CalendarUtil.toLunar(getEndDate()));

//				setStartDate(CalendarUtil.getStartDateOfDay(solarDate));
//				setEndDate(CalendarUtil.getEndDateOfDay(solarDate));
//				setLunarStartDate(CalendarUtil.getStartDateOfDay(CalendarUtil.toLunar(getStartDate())));
//				setLunarEndDate(CalendarUtil.getEndDateOfDay(CalendarUtil.toLunar(getEndDate())));
				setLeap((int)CalendarUtil.toLunarWithLeap(solarDate).get("leap"));
			} else {
				Date lunarDate = CalendarUtil.toDate(getYear()+getDate(), "yyyyMMdd");
				Date solarDate = CalendarUtil.toSolarWithLeap(lunarDate, getLeap());

				setStartDate(solarDate);
				setEndDate(solarDate);
				setLunarStartDate(CalendarUtil.toLunar(getStartDate()));
				setLunarEndDate(CalendarUtil.toLunar(getEndDate()));
				
//				setStartDate(CalendarUtil.getStartDateOfDay(solarDate));
//				setEndDate(CalendarUtil.getEndDateOfDay(solarDate));
//				setLunarStartDate(CalendarUtil.getStartDateOfDay(CalendarUtil.toLunar(getStartDate())));
//				setLunarEndDate(CalendarUtil.getEndDateOfDay(CalendarUtil.toLunar(getEndDate())));
			}
			
			setRecurrenceId(getStartDate().getTime());
			setRecurrenceDate(getStartDate());
			setLunarRecurrenceDate(getLunarStartDate());
			
			Recurrence recurrence = null;
			if (StringUtils.isNotBlank(recurrenceYN) && Y.equals(recurrenceYN)) {
				recurrence = new Recurrence();
				recurrence.setFrequency(Frequency.YEARLY);
				recurrence.setUntil(getUntilDate(untilYear, date));
				recurrence.setInterval(1);
				recurrence.setExceptionDates(getExceptionDate(exceptionYears, date));
			}
			
			setRecurrence(recurrence);
			setRecurrenceYN(recurrenceYN);
			
			setAlarmTriggerType(AlarmTriggerType.DAY);
			setAlarmTriggerValue(1);
			setAlarmYN(N);
			RecurrenceUtil.estimateAlarmDateTime((Events)this);
		} catch (Exception ex) {}
	}
	
	private List<Date> getExceptionDate(String exceptionYears, String monthday) {
		List<Date> exceptionDate = null;
		
		try {
			exceptionDate = new ArrayList<Date>();
			
			if (StringUtils.isNotBlank(exceptionYears)) {
				for (String year : exceptionYears.split(",")) {
					exceptionDate.add(CalendarUtil.toDate(year.trim()+monthday, "yyyyMMdd"));
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return exceptionDate;
	}
	
	private Date getUntilDate(String untilYear, String monthday) {
		Date untilDate = null;
		try {
			if (StringUtils.isNotBlank(untilYear)) {
				untilDate = CalendarUtil.getEndDateOfDay(CalendarUtil.toDate(untilYear+monthday, "yyyyMMdd"));
			}
			
		} catch (Exception ex) { ex.printStackTrace(); }
		
		return untilDate;
	}
}
