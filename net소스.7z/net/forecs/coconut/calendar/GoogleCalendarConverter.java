package net.forecs.coconut.calendar;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.calendar.Recurrence;
import net.fortuna.ical4j.model.property.RRule;

import org.apache.commons.lang.StringUtils;

import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventDateTime;
import com.google.appengine.api.datastore.Text;

/**
 * 
Dependencies for all Platforms

The following are the jars from the libs folder required for applications on all platforms:
google-api-client-1.19.1.jar
google-oauth-client-1.19.0.jar
google-http-client-1.19.0.jar
jsr305-1.3.9.jar
google-http-client-gson-1.19.0.jar (when using GSON)
gson-2.1.jar
google-http-client-jackson2-1.19.0.jar (when using Jackson 2)
jackson-core-$2.1.3.jar
google-http-client-jdo-1.19.0.jar (when using JDO)
jdo2-api-2.3-eb.jar


Google App Engine Dependencies

The following are the jars from the libs folder required for Google App Engine applications or a newer compatible version of each dependency:
google-api-client-appengine-1.19.1.jar
google-api-client-servlet-1.19.1.jar
google-oauth-client-appengine-1.19.0.jar
google-oauth-client-servlet-1.19.0.jar
google-http-client-appengine-1.19.0.jar
transaction-api-1.1.jar
Please see the GoogleAppEngine wiki for the Google App Engine Developer's Guide.
 * @author 현우
 *
 */
public class GoogleCalendarConverter {
	private static final Logger LOG = Logger.getLogger(GoogleCalendarConverter.class.getName());
	private static final String Y = "Y";
	private static final String N = "N";
	
	@SuppressWarnings("unused")
	private static void addEventToCalendar(Calendar calendar, String calendarId, List<Events> eventList) throws Exception  {
		for (Events coconutEvent : eventList) {
			Event googleEvent = convertToGoogleEvent(coconutEvent);
			
			calendar.events().insert(calendarId, googleEvent).execute();
		}
	}
	
	public static Event convertToGoogleEvent(Events coconutEvent) throws Exception {
		Event googleEvent = new Event();
		
		try {
			googleEvent.setICalUID(coconutEvent.getUid());
			googleEvent.setSummary(coconutEvent.getTitle());
			DateTime startDate = new DateTime(coconutEvent.getStartDate(), TimeZone.getTimeZone("UTC"));
			DateTime endDate = new DateTime(coconutEvent.getEndDate(), TimeZone.getTimeZone("UTC"));
			EventDateTime startEventDate = null;
			EventDateTime endEventDate = null;
			
			if (Y.equals(coconutEvent.getAllDayYN())) {
				startEventDate = new EventDateTime().setDate(startDate);
				//endEventDate = new EventDateTime().setDate(endDate);
			} else {
				startEventDate = new EventDateTime().setDateTime(startDate);
				endEventDate = new EventDateTime().setDateTime(endDate);
			}
			
			googleEvent.setStart(startEventDate);
			googleEvent.setEnd(endEventDate);
			
			if (coconutEvent.getDescription() != null) {
				googleEvent.setDescription(coconutEvent.getDescription().getValue());
			}
			googleEvent.setLocation(coconutEvent.getLocation());
			googleEvent.setSequence(coconutEvent.getSequence());
			googleEvent.setVisibility(coconutEvent.getVisibility());
			
			if (coconutEvent.getRecurrence() != null && Y.equals(coconutEvent.getRecurrenceYN())) {
				RRule rrule = RecurrenceUtil.getRRule(coconutEvent.getRecurrence());
				List<String> recurrenceList = new ArrayList<String>();
				recurrenceList.add(rrule.toString());
				googleEvent.setRecurrence(recurrenceList);
			}
		} catch (Exception ex) {
			throw ex;
		}
		
		return googleEvent;
	}
	
	public static List<Events> listEventsFromCalendar(String domainId, String boardId, String userId, com.google.api.services.calendar.model.Events googleEvents) throws IOException, ParseException, Exception {
		List<Events> coconutEventList = new ArrayList<Events>();
		
		try {
			if (googleEvents.getItems() != null) {
				for (Event googleEvent : googleEvents.getItems()) {
					Events coconutEvent = convertEventFromGoogle(googleEvent);
					
					if (coconutEvent != null) {
						coconutEvent.setDomainId(domainId);
						coconutEvent.setBoardId(boardId);
						coconutEvent.setCreator(userId);
						
						coconutEventList.add(coconutEvent);
					}
				}
			}
		} catch (IOException ex) {
			throw ex;
		} catch (ParseException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		
		return coconutEventList;
	}
	
	private static Events convertEventFromGoogle(Event googleEvent) throws ParseException, Exception  {
		Events coconutEvent = new Events();
		
		try {
			String id = googleEvent.getId();
			if (StringUtils.isBlank(id)) { id = KeyUtil.UUID(); }
			coconutEvent.setUid(googleEvent.getICalUID());
			coconutEvent.setKey(KeyUtil.createEventKey(id));
			coconutEvent.setSequence(googleEvent.getSequence());
			coconutEvent.setVisibility(googleEvent.getVisibility());
			
			EventDateTime startDate = googleEvent.getStart(); 
			EventDateTime endDate = googleEvent.getEnd();
			if (startDate != null && endDate != null) {
				if (startDate.getDate() != null && startDate.getDate().isDateOnly()) {
					coconutEvent.setAllDayYN(Y);
					coconutEvent.setStartDate(new Date(startDate.getDate().getValue()));
					coconutEvent.setEndDate(new Date(endDate.getDate().getValue()));
				} else {
					coconutEvent.setStartDate(new Date(startDate.getDateTime().getValue()));
					coconutEvent.setEndDate(new Date(endDate.getDateTime().getValue()));
				}
				
//				System.out.println(googleEvent.toPrettyString());
			} else {
//				System.out.println("[=============================================");
//				System.out.println(googleEvent.toPrettyString());
//				System.out.println("=============================================]");
			}
			
			coconutEvent.setTitle(googleEvent.getSummary());
			coconutEvent.setDescription(new Text(googleEvent.getDescription()));
			coconutEvent.setLocation(googleEvent.getLocation());
			coconutEvent.setHtmlLink(googleEvent.getHtmlLink()); /** 구글의 캘린더에서만 가져온다. 만일, google calendar 로 입력할 경우라면 이값은 제외하고 넣어야 한다. */
			//////////////////////////////////////////////////////////////////////////////////////////////////
			// TODO
			//////////////////////////////////////////////////////////////////////////////////////////////////
			// 외부에서 가져온 일정의 이벤트 타입은 무엇으로 결정해야하는지 고민됨
			// Holiday는 아니지만, Anniversary와 Appointment의 값중에서 결정하기가 쉽지 않다.
			// 기본값으로는 APPOINTMENT로 잡는것이 옳은듯
			coconutEvent.setEventType(EventType.PRIVATE); ////////////////////////////////////////////////
			coconutEvent.setAlarmYN(N);
			coconutEvent.setEditableYN(N);
			
			Recurrence recurrence = getRecurrence(googleEvent.getRecurrence());	
			if (recurrence != null) {
				coconutEvent.setRecurrence(recurrence);
				coconutEvent.setRecurrenceYN(Y);
			}
		} catch (ParseException ex) {
			throw ex;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		}
		
		return coconutEvent;
	}
	
	private static Recurrence getRecurrence(List<String> recurrenceList) throws ParseException {
		String rruleStr = null;
		RRule rrule = null;
		Recurrence recurrence = null;
		
		try {
			
			// TODO
			// 아래의 문자열을 Parsing 하는 또다른 방법이 있을듯.. 조사 필요성
			
			// EXDATE;TZID=Asia/Seoul:20150125T090000
			// EXDATE;TZID=Asia/Seoul:20150125T090000,20150125T090000,20150125T090000,20150125T090000
			if (recurrenceList != null && recurrenceList.size() > 0) {
				//String recurStr = googleEvent.getRecurrence().get(0);
				List<Date> exceptionDateList = new ArrayList<Date>();
				for (String recurStr : recurrenceList) {
					if (recurStr.indexOf("RRULE:") == 0) {
						rruleStr = recurStr.replaceFirst("RRULE:", "");
						rrule = new RRule(rruleStr);
					} else  {
						exceptionDateList.addAll(parseExceptionDates(recurStr));
					}
				} 
				
				if (rrule != null) {
					recurrence = RecurrenceUtil.getRecurrence(rrule);
				}
				
				if (exceptionDateList != null && exceptionDateList.size() > 0) {
					if (recurrence == null) { recurrence = new Recurrence(); }
					
					recurrence.setExceptionDates(exceptionDateList);
				}
			}
		} catch (ParseException ex) {
			throw ex;
		}
		return recurrence;
	}
	
	private static List<Date> parseExceptionDates(String recurStr) {
		List<Date> exceptionDateList = new ArrayList<Date>();;
		
		if (recurStr.indexOf("EXDATE") == 0){
			String[] recurProps = recurStr.split(":");
			
			if (recurProps.length == 2) {
				String exdateProps = recurProps[0];
				String datelistProps = recurProps[1];
				
				String timezone = getTimeZone(exdateProps);
				
				exceptionDateList.addAll(getExceptionDateList(datelistProps, timezone));
			}
		}
		
		return exceptionDateList;
	}
	
	private static List<Date> getExceptionDateList(String datelistProps, String timeZone) {
		List<Date> exceptionDateList = new ArrayList<Date>();;
		
		if (datelistProps != null && datelistProps.length() > 0) {
			String[] exDateStrList = datelistProps.split(",");
			
			for (String exDateStr : exDateStrList) {
				try {
					Date exDate = CalendarUtil.toDate(exDateStr, "yyyyMMdd'T'HHmmss");
					if (!exceptionDateList.contains(exDate)) {
						exceptionDateList.add(exDate);
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					LOG.warning(ex.getMessage());
				}
			}
		}
		
		return exceptionDateList;
	}
	
	private static String getTimeZone(String exdateProps) {
		String[] timezoneProps = exdateProps.split(";");
		String timezone = null;
		if (timezoneProps.length == 2 && timezoneProps[1].indexOf("TZID=")==0) {
			String[] timezoneArr = timezoneProps[1].split("=");
			
			if (timezoneArr.length==2) { timezone = timezoneArr[1].trim(); }
		} 
		return timezone;
	}
}
