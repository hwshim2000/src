package net.forecs.coconut.calendar;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import net.forecs.coconut.common.code.CalendarVisibility;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.calendar.Recurrence;
import net.fortuna.ical4j.data.CalendarBuilder;
import net.fortuna.ical4j.data.ParserException;
import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.Component;
import net.fortuna.ical4j.model.DateList;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Parameter;
import net.fortuna.ical4j.model.TimeZoneRegistry;
import net.fortuna.ical4j.model.TimeZoneRegistryFactory;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.Clazz;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.DtEnd;
import net.fortuna.ical4j.model.property.DtStart;
import net.fortuna.ical4j.model.property.ExDate;
import net.fortuna.ical4j.model.property.Location;
import net.fortuna.ical4j.model.property.Method;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.RRule;
import net.fortuna.ical4j.model.property.Sequence;
import net.fortuna.ical4j.model.property.Summary;
import net.fortuna.ical4j.model.property.Uid;
import net.fortuna.ical4j.model.property.Version;
import net.fortuna.ical4j.model.property.XProperty;
import net.fortuna.ical4j.util.UidGenerator;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.Text;

public class CalendarConverter {
	private static final String Y = "Y";
	private static final String N = "N";
	
	public static Calendar convertEventToCalendar(List<Events> eventList, String calendarId) throws Exception {
		Calendar calendar = new Calendar();
		
		//calendar.getProductId().setValue("-//Google Inc//Google Calendar 70.9054//EN");
		calendar.getProperties().add(new ProdId("-//Google Inc//Google Calendar 70.9054//EN"));
		//calendar.getProperties().add(new ProdId("-//Ben Fortuna//iCal4j 1.0//EN"));
		//calendar.getProperties().add(new ProdId("-//Events Calendar//iCal4j 1.0//EN"));
		//calendar.getVersion().setValue(Version.VERSION_2_0.getValue());
		calendar.getProperties().add(Version.VERSION_2_0);
		calendar.getProperties().add(CalScale.GREGORIAN);
		calendar.getProperties().add(Method.PUBLISH);
		
		calendar.getProperties().add(new XProperty("X-WR-CALNAME", calendarId));
		calendar.getProperties().add(new XProperty("X-WR-TIMEZONE", "Asia/Seoul"));
		TimeZoneRegistry registry = TimeZoneRegistryFactory.getInstance().createRegistry();
		VTimeZone tz = registry.getTimeZone("Asia/Seoul").getVTimeZone();
//		calendar.getComponents().add(tz);
		
		for (Events event : eventList) {
			if (EventType.HOLIDAY.equals(event.getEventType()) || EventType.ANNIVERSARY.equals(event.getEventType())) { continue; }
			if (event.getStartDate() == null || event.getEndDate() == null) { continue; }
			DateTime dtStart = new DateTime(event.getStartDate());
			DateTime dtEnd = new DateTime(event.getEndDate());
			
			RRule rrule = null;
			Recurrence recurrence = event.getRecurrence();
			
			VEvent vEvent = null;
			
			if (N.equals(event.getAllDayYN())) {
				vEvent = new VEvent(dtStart, dtEnd, event.getTitle());
			} else {
				// All day event
				// LocalTime으로 하면 안된다. 그래서 날짜를 스트링으로 변경하여 사용.
				// 다른 방법으로는 현재 localTime을 UTC or GMT 타임으로 벼경한 다음 사용. 
				//CalendarUtil.getStartDateOfDay(dtStart, TimeZone.getTimeZone("UTC"));
				vEvent = new VEvent(new net.fortuna.ical4j.model.Date(CalendarUtil.toString(dtStart, "yyyyMMdd")), event.getTitle());
			}

			if (StringUtils.isNotEmpty(event.getUid())) {
				vEvent.getProperties().add(new Uid(event.getUid()));
			} else {
				UidGenerator uidGenerator = new UidGenerator("1");
				vEvent.getProperties().add(uidGenerator.generateUid());
			}
//			vEvent.getProperties().add(new DtStart(dtStart));
//			vEvent.getProperties().add(new DtEnd(dtEnd));
			if (StringUtils.isNotEmpty(event.getTitle())) {
				Summary summary = new Summary(new String(event.getTitle().getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
				vEvent.getProperties().add(summary);
			}
			vEvent.getProperties().add(new Location(event.getLocation()));
			vEvent.getProperties().add(new Sequence(event.getSequence()));
			
			if (event.getDescription()!=null && event.getDescription().getValue() != null) {
				vEvent.getProperties().add(new Description(event.getDescription().getValue()));
			}
			
			vEvent.getProperties().add(CalendarVisibility.visibilityToICalClazz(event.getVisibility())); // OR PUBLIC OR CONFIDENTIAL
			//vEvent.getProperties().add(new DateStamp(event.getCreated());
			//vEvent.getCreated().setDate(new DateTime(event.getCreated()));
			//vEvent.getSequence().setValue("0");
			
			if (recurrence != null) {
				rrule = RecurrenceUtil.getRRule(recurrence);
				if (rrule!=null) { vEvent.getProperties().add(rrule); }
				
				if (recurrence.getExceptionDates() != null && !recurrence.getExceptionDates().isEmpty()) {
					DateList dateList = new DateList();
					for (Date date : recurrence.getExceptionDates()) {
						dateList.add(new DateTime(date));
					}
					vEvent.getProperties().add(new ExDate(dateList));
					vEvent.getProperties().add(tz.getTimeZoneId());
				}
			}
			
			calendar.getComponents().add(vEvent);
		}

		return calendar;
	}
	
	public static List<Events> convertEventFromCalendar(String eventsStream, EventType eventType) throws Exception {
		return convertEventFromCalendar(parseCalendarString(eventsStream), eventType);
	}
	
	@SuppressWarnings("unchecked")
	private static List<Events> convertEventFromCalendar(Calendar calendar, EventType eventType) throws Exception {
		List<Events> eventList = new ArrayList<Events>();
		
		for (Object obj : calendar.getComponents(Component.VEVENT)) {
			VEvent vEvent = (VEvent)obj;
			
			Uid uid = vEvent.getUid();
			RRule rrule = (RRule)vEvent.getProperties().getProperty(RRule.RRULE);
			DtStart dtStart = vEvent.getStartDate();
			DtEnd dtEnd = vEvent.getEndDate();
			Summary summary = vEvent.getSummary();
			ExDate exDate = (ExDate)vEvent.getProperties().getProperty(ExDate.EXDATE);
			Location location = vEvent.getLocation();
			Description description = vEvent.getDescription();
			Parameter allDayParam = dtStart.getParameter(Parameter.VALUE);
			Sequence sequence = vEvent.getSequence();
			Clazz clazz = vEvent.getClassification();
			Events event = new Events();
			
			String sequenceStr = "0";
			if (sequence != null && sequence.getValue() != null) { sequenceStr = sequence.getValue(); }
			
			event.setKey(KeyUtil.createEventKey(uid, sequenceStr));
			event.setEventType(eventType);
			event.setUid(uid.getValue());
			event.setSequence(Integer.valueOf(sequenceStr));
			event.setVisibility(CalendarVisibility.iCalClazzToVisibility(clazz));
			
			event.setStartDate(new Date(dtStart.getDate().getTime()));
			event.setEndDate(new Date(dtEnd.getDate().getTime()));
			
			if (allDayParam != null && "DATE".equals(allDayParam.getValue())) {
				event.setAllDayYN(Y);
			}
			
			if (summary!=null) { event.setSummary(summary.getValue()); }
			if (location!=null) { event.setLocation(location.getValue()); }
			if (description!=null && description.getValue() != null) { event.setDescription(new Text(description.getValue())); }
			
			if (rrule != null) {
				Recurrence recurrence = RecurrenceUtil.getRecurrence(rrule);
				List<Date> exceptionDateList = null;
				if (exDate != null) {
					exceptionDateList = new ArrayList<Date>();
					for (Iterator<DateTime> i = exDate.getDates().iterator(); i.hasNext();) {
						exceptionDateList.add(new Date(i.next().getTime()));
					}
				}
				
				recurrence.setExceptionDates(exceptionDateList);
				event.setRecurrence(recurrence);
				event.setRecurrenceYN(Y);
			}
			
			eventList.add(event);
		}
		
		return eventList;
	}
	
	@SuppressWarnings("unused")
	private static Calendar parseCalendarFile(String path) throws IOException, ParserException {
		Calendar calendar = null;
		try {
			FileInputStream fin = new FileInputStream(path);
			CalendarBuilder builder = new CalendarBuilder();
	
			calendar = builder.build(fin);
		} catch (IOException ex) {
			throw ex;
		} catch (ParserException ex) {
			throw ex;
		}
		
		return calendar;
	}
	
	private static Calendar parseCalendarString(String str) throws IOException, ParserException {
		Calendar calendar = null;
		try {
			StringReader sin = new StringReader(str);
			CalendarBuilder builder = new CalendarBuilder();
	
			calendar = builder.build(sin);
		} catch (IOException ex) {
			throw ex;
		} catch (ParserException ex) {
			throw ex;
		}
		
		return calendar;
	}
}
