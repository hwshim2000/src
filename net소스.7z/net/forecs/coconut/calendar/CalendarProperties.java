package net.forecs.coconut.calendar;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;

import net.forecs.coconut.common.util.LocaleUtil;

public class CalendarProperties {
//	private static final Logger LOG = Logger.getLogger(CalendarProperties.class);
	private final static String DEFAULT_FILENAME_PREFIX = "META-INF/calendars/calendar";
	
	private static String getFilename(Locale locale) {
		if (locale == null) {
			return String.format("%s_%s.properties", DEFAULT_FILENAME_PREFIX, LocaleUtil.DEFAULT_LOCALE);
		}
		
		return String.format("%s_%s.properties", DEFAULT_FILENAME_PREFIX, locale);
	}
	public static Properties readProperties(Locale locale) {
		Properties pro = new Properties();
		
		InputStream inputStream = CalendarProperties.class.getClassLoader().getResourceAsStream(getFilename(locale));
		if (inputStream == null) { inputStream = CalendarProperties.class.getClassLoader().getResourceAsStream(getFilename(null)); }
		
		try {
			pro.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) { 
				e.printStackTrace();
			}
		}
		return pro;
	} 
//	public static Properties readProperties(Locale locale) {
//		Properties pro = new Properties();
//		FileInputStream fis = null;
//		String filename = getFilename(locale);
//		File file = new File(filename);
//		if (!file.exists()) { filename = getFilename(null); }
//		try {
//			fis = new FileInputStream(filename); 
//			pro.load(new InputStreamReader(fis));
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				fis.close();
//			} catch (IOException e) { 
//				e.printStackTrace();
//			}
//		}
//		return pro;
//	} 

/*	public static void main(String[] args) {

		Properties pro = new Properties();

		String jsonStr = "{\"general\":{\"language\":{\"code\":\"ko_KR\",\"title\":\"Korean\"},\"defaultBoard\":{\"type\":\"lastBoard\",\"boardId\":\"\",\"title\":\"\"}},\"board\":{\"fixMember\":true,\"fixCalendar\":false,\"showMemberBirthday\":false,\"showKoreanHoliday\":false},\"calendar\":{\"showKoreanHoliday\":true,\"showMemberBirthday\":true},\"chatting\":{\"showBadge\":true,\"font\":{\"type\":\"Arial Black\",\"size\":10,\"color\":\"black\"}},\"notification\":{\"web\":{\"recieve\":\"Y\",\"schedule\":{\"type\":\"event\",\"title\":\"건별\"}},\"email\":{\"recieve\":\"Y\",\"schedule\":{\"type\":\"HOUR\",\"title\":\"시간별\"}}}}";
		Locale locale = LocaleUtil.parseLocale(jsonStr);
		pro = readProperties(locale);
		pro.values();
		
		for (Map.Entry<Object, Object> entry : pro.entrySet()) {
			System.out.println(entry.getKey() + ":" + (String)entry.getValue());
		}
	}*/
}
