package net.forecs.coconut.calendar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import net.forecs.coconut.common.code.AlarmTriggerType;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.code.StartDayOfWeek;
import net.forecs.coconut.common.code.WeekDayType;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.calendar.Recurrence;
import net.fortuna.ical4j.model.DateList;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.PeriodList;
import net.fortuna.ical4j.model.Recur;
import net.fortuna.ical4j.model.WeekDay;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.property.DtEnd;
import net.fortuna.ical4j.model.property.DtStart;
import net.fortuna.ical4j.model.property.ExDate;
import net.fortuna.ical4j.model.property.RRule;
import net.fortuna.ical4j.model.property.Summary;

import org.datanucleus.util.StringUtils;

import com.ibm.icu.util.Calendar;

public class RecurrenceUtil {
	private static final String N = "N";
	/**
	 * @Description : 예외일 설정
	 *              : 현재 Event에서 예외시키고자 하는 날짜를 입력값으로 받는다.
	 *              : (중요!!!. 예외날짜는 Instance를 발생시키는 기준으로 하기때문에 인스턴스 발생 기준인 StartDate의 값과 일치되어야 한다.)
	 *              : (따라서, startDate의 값중에 예외시키고자 하는 날짜의 정확한 값을 넣어주어야 한다.->recurrenceDate가 필요)
	 * @Method      : addExDate
	 * @param event
	 * @param exDate
	 * @throws Exception
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	public static void addExDate(Events event, Date exDate) throws Exception {
		if (event.getRecurrence()==null) { event.setRecurrence(new Recurrence()); }
		
		if (event.getRecurrence().getExceptionDates() == null) {
			event.getRecurrence().setExceptionDates(new ArrayList<Date>());
		}
		
		event.getRecurrence().getExceptionDates().add(exDate);
		
//		Calendar cal = Calendar.getInstance();
//		cal.setTime(exDate);
//		
//		Calendar exceptCal = Calendar.getInstance();
//		exceptCal.setTime(event.getStartDate());
//		exceptCal.set(Calendar.YEAR, cal.get(Calendar.YEAR));
//		exceptCal.set(Calendar.MONTH, cal.get(Calendar.MONTH));
//		exceptCal.set(Calendar.DATE, cal.get(Calendar.DATE));
//		// 반복 기준을 시간단위까지 할 경우
//		exceptCal.set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR_OF_DAY));
//		// 반복 기준을 분 단위까지 할경우
//		exceptCal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE));
//		// 반복 기준을 초단위까지 할경우
//		exceptCal.set(Calendar.SECOND, cal.get(Calendar.SECOND));
//		
//		event.getRecurrence().getExceptionDates().add(exceptCal.getTime());
	}
	
	/**
	 * @Description : Event를 divideDate로 분리한다.
	 * @Method      : divideRecurrence
	 * @param event
	 * @param divideDate
	 * @throws Exception
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	public static void divideRecurrence(Events event, Date recurrenceDate) throws Exception {
		//event.getRecurrence().setUntil(recurrenceId.substring(0, 9) + event.getStart().substring(9));
		
		Calendar divideCal = Calendar.getInstance();
		divideCal.setTime(recurrenceDate);
		
		/** 만약 나누고자 하는 이벤트 시점을 포함시키고자 한다면 아래 코드를 제거 */
		divideCal.add(Calendar.MILLISECOND, -1);
		
//		Calendar untilCal = Calendar.getInstance();
//		untilCal.setTime(event.getStartDate());
//		untilCal.set(Calendar.YEAR, divideCal.get(Calendar.YEAR));
//		untilCal.set(Calendar.MONTH, divideCal.get(Calendar.MONTH));
//		untilCal.set(Calendar.DATE, divideCal.get(Calendar.DATE));
//		// 반복 기준을 시간단위까지 할 경우
//		untilCal.set(Calendar.HOUR_OF_DAY, divideCal.get(Calendar.HOUR_OF_DAY));
//		// 반복 기준을 분 단위까지 할경우
//		untilCal.set(Calendar.MINUTE, divideCal.get(Calendar.MINUTE));
//		// 반복 기준을 초단위까지 할경우
//		untilCal.set(Calendar.SECOND, divideCal.get(Calendar.SECOND));
		
		Recurrence recurrence = (Recurrence)CopyUtil.copyDeeply(event.getRecurrence());
		//CopyUtil.copy(recurrence, event.getRecurrence());
		recurrence.setUntil(divideCal.getTime());
		recurrence.setCount(null);
		event.setRecurrence(recurrence);
		
//		event.getRecurrence().setUntil(endCal.getTime());
//		event.getRecurrence().setCount(null);
//		event.getRecurrence().setRecurrenceType(RecurrenceType.CUSTOM);
	}
	/**
	 * @Description : coconut recurrence 를 icalendar 형식의 RRule(recurrence rule)로 변경한다.
	 * @Method      : getRRule
	 * @param recurrence
	 * @return RRule
	 * @throws Exception
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	static RRule getRRule(Recurrence recurrence) throws Exception {
		Recur recur = new Recur();
		/** 반복 주기. writable */
		recur.setFrequency(recurrence.getFrequency().toString());
		
		/** 마지막 반복 instance의 일시. Optional. writable */
		if (recurrence.getUntil() != null) {
			recur.setUntil(new DateTime(recurrence.getUntil()));
		} else if (recurrence.getCount() != null) {
			/** 반복 횟수. Optional. writable */
			recur.setCount(recurrence.getCount());
		}
		/** 반복 간격. Optional. (RFC5545의 “INTERVAL”) writable */
		if (recurrence.getInterval() != null) {
			recur.setInterval(recurrence.getInterval());
		}
		/** 반복 대상 주중 요일 목록. Optional. writable */
		if (recurrence.getByDays() != null) {
			for (WeekDayType byDay : recurrence.getByDays()) {
				recur.getDayList().add(new WeekDay(byDay.toString()));
			}
		}
		/** 반복 대상 월중 일 목록. Optional. writable */
		if (recurrence.getByMonthDays() != null) {
			for (Integer byMonthDay : recurrence.getByMonthDays()) {
				recur.getMonthDayList().add(byMonthDay);
			}
		}
		/** 반복 대상 연중 일 목록. Optional. writable */
		if (recurrence.getByYearDays() != null) {
			for (Integer byYearDay : recurrence.getByYearDays()) {
				recur.getYearDayList().add(byYearDay);
			}
		}
		/** 반복 대상 연중 주 목록. Optional. writable */
		if (recurrence.getByWeekNumbers() != null) {
			for (Integer byWeekNumber : recurrence.getByWeekNumbers()) {
				recur.getWeekNoList().add(byWeekNumber);
			}
		}
		/** 반복 대상 연중 월 목록. Optional. writable */
		if (recurrence.getByMonths() != null) {
			for (Integer byMonth : recurrence.getByMonths()) {
				recur.getMonthList().add(byMonth);
			}
		}
		/** 반복 단위 내의 대상 위치 목록. Optional. writable */
		if (recurrence.getBySetPositions() != null) {
			for (Integer bySetPosition : recurrence.getBySetPositions()) {
				recur.getSetPosList().add(bySetPosition);
			}
		}
		/** 주중 근무 시작요일. Optional. default=”MO”. writable */
		if (recurrence.getStartDayOfWeek() != null) {
			recur.setWeekStartDay(recurrence.getStartDayOfWeek().toString());
		}
		return new RRule(recur);
	}
	
	/**
	 * @Description : icalendar이 RRule을 coconut의 recurrence로 변경한다.
	 * @Method      : getRecurrence
	 * @param rrule
	 * @return Recurrence
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	@SuppressWarnings("unchecked")
	static Recurrence getRecurrence(RRule rrule) {
		Recur recur = rrule.getRecur();
		Recurrence recurrence = new Recurrence();
		/** 반복 주기. writable */
		recurrence.setFrequency(Frequency.valueOf(recur.getFrequency()));
		
		/** 마지막 반복 instance의 일시. Optional. writable */
		if (recur.getUntil() != null) {
			recurrence.setUntil(new Date(recur.getUntil().getTime()));
		} else {
			/** 반복 횟수. Optional. writable */
			recurrence.setCount(recur.getCount());
		}
		/** 반복 간격. Optional. (RFC5545의 “INTERVAL”) writable */
		recurrence.setInterval(recur.getInterval());
		
		/** 반복 대상 주중 요일 목록. Optional. writable */
		if (recur.getDayList() != null) {
			if (recurrence.getByDays() == null) { recurrence.setByDays(new ArrayList<WeekDayType>()); }
			for (Iterator<WeekDay> i = recur.getDayList().iterator(); i.hasNext();) {
				WeekDay weekday = (WeekDay)i.next();
				recurrence.getByDays().add(WeekDayType.valueOf(weekday.getDay()));
			}
		}
		/** 반복 대상 월중 일 목록. Optional. writable */
		if (recur.getMonthDayList() != null) {
			if (recurrence.getByMonthDays() == null) { recurrence.setByMonthDays(new ArrayList<Integer>()); }
			for (Iterator<Integer> i = recur.getMonthDayList().iterator(); i.hasNext();) {
				recurrence.getByMonthDays().add(new Integer(i.next()));
			}
		}
		/** 반복 대상 연중 일 목록. Optional. writable */
		if (recur.getYearDayList() != null) {
			if (recurrence.getByYearDays() == null) { recurrence.setByYearDays(new ArrayList<Integer>()); }
			for (Iterator<Integer> i = recur.getYearDayList().iterator(); i.hasNext();) {
				recurrence.getByYearDays().add(new Integer(i.next()));
			}
		}
		/** 반복 대상 연중 주 목록. Optional. writable */
		if (recur.getWeekNoList() != null) {
			if (recurrence.getByWeekNumbers() == null) { recurrence.setByWeekNumbers(new ArrayList<Integer>()); }
			for (Iterator<Integer> i = recur.getWeekNoList().iterator(); i.hasNext();) {
				recurrence.getByWeekNumbers().add(new Integer(i.next()));
			}
		}
		/** 반복 대상 연중 월 목록. Optional. writable */
		if (recur.getMonthList() != null) {
			if (recurrence.getByMonths() == null) { recurrence.setByMonths(new ArrayList<Integer>()); }
			for (Iterator<Integer> i = recur.getMonthList().iterator(); i.hasNext();) {
				recurrence.getByMonths().add(new Integer(i.next()));
			}
		}
		/** 반복 단위 내의 대상 위치 목록. Optional. writable */
		if (recur.getSetPosList() != null) {
			if (recurrence.getBySetPositions() == null) { recurrence.setBySetPositions(new ArrayList<Integer>()); }
			for (Iterator<Integer> i = recur.getSetPosList().iterator(); i.hasNext();) {
				recurrence.getBySetPositions().add(new Integer(i.next()));
			}
		}
		/** 주중 근무 시작요일. Optional. default=”MO”. writable */
		if (recur.getWeekStartDay() != null) {
			recurrence.setStartDayOfWeek(StartDayOfWeek.valueOf(recur.getWeekStartDay()));
		}

		return recurrence;
	}

	/**
	 * @Description : 반복되는 Event의 instance를 조회시간내에서 계산하여 리턴한다.
	 *              : (recurrenceId값은 그자체로 UTC time format을 가지고 있다.)
	 * @Method      : getInstances
	 * @param event
	 * @param queryStart
	 * @param queryEnd
	 * @return List<Events>
	 * @throws Exception
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	@SuppressWarnings("unchecked")
	public static List<Events> getInstances(Events event, Date queryStart, Date queryEnd) throws Exception  {
		List<Events> instances = new ArrayList<Events>();
		Recurrence recurrence = event.getRecurrence();
		
		// 조회 시작 시간이 없으면 event의 시작시간으로 설정
		if (queryStart==null) { queryStart = event.getStartDate(); }
		// 조회 끝 시간이 없으면 event의 끝 시간으로 설정
		if (queryEnd==null) { queryEnd = event.getEndDate(); }
		
		// 이벤트의 시작일이 조회의 마지막일자보다도 클 경우에는 빈값을 리턴(조회가 무의미)
		if (event.getStartDate().compareTo(queryEnd) > 0) {
			return instances;
		}
		// recurrence가 없으면 해당 이벤트를 담아서 리턴
		if (recurrence == null || StringUtils.isEmpty(event.getRecurrenceYN()) || N.equals(event.getRecurrenceYN())) {
			// event의 시작일이 조회 범위에 있거나, envent의 종료일이 조회 범위에 있으면 instace를 하나 생성해서 리턴한다.
			if ((event.getStartDate().compareTo(queryStart) >=0 && event.getStartDate().compareTo(queryEnd) <=0)
					|| (event.getEndDate().compareTo(queryStart) >=0 && event.getEndDate().compareTo(queryEnd) <=0)) {
				
				translateInstance(event);
				instances.add(event);
			} 
			return instances;
		}

//		if (event.getStartDate().compareTo(queryStart) > 0) {
//			queryStart = event.getStartDate();
//		}
		
//		String start = event.getStart();
//		String end = event.getEnd();
//		
//		TimeZoneRegistry registry = TimeZoneRegistryFactory.getInstance().createRegistry();
//		TimeZone timezone = registry.getTimeZone(timeZoneId);
//		java.util.Calendar calendar = java.util.Calendar.getInstance(timezone);
//		
//		calendar.setTimeInMillis(TimeZoneUtil.convertMilliseconds(queryStart));
//		DateTime dtQueryStart = new DateTime(calendar.getTime());
//		dtQueryStart.setTimeZone(timezone);
//		
//		calendar.setTimeInMillis(TimeZoneUtil.convertMilliseconds(queryEnd));
//		if (dtQueryStart.getTime() == calendar.getTimeInMillis()) {
//			calendar.add(Calendar.YEAR, 1);
//		}
//		DateTime dtQueryEnd = new DateTime(calendar.getTime());
//		dtQueryEnd.setTimeZone(timezone);
//		
//		calendar.setTimeInMillis(TimeZoneUtil.convertMilliseconds(start));
//		DateTime dtStart = new DateTime(calendar.getTime());
//		dtStart.setTimeZone(timezone);
//		
//		calendar.setTimeInMillis(TimeZoneUtil.convertMilliseconds(end));
//		DateTime dtEnd = new DateTime(calendar.getTime());
//		dtEnd.setTimeZone(timezone);
		
		DateTime dtStart = new DateTime(event.getStartDate());
		DateTime dtEnd = new DateTime(event.getEndDate());
		
		DateTime dtQueryStart = new DateTime(queryStart);
		DateTime dtQueryEnd = new DateTime(queryEnd);
		
		RRule rrule = getRRule(recurrence);
		
		/** 반복 인스턴스를 생성하기 위해 VEvent 등록 */
		VEvent vEvent = new VEvent();
		vEvent.getProperties().add(rrule);
		vEvent.getProperties().add(new Summary(event.getSummary()));
		vEvent.getProperties().add(new DtStart(dtStart));
		vEvent.getProperties().add(new DtEnd(dtEnd));

		/** 반복 제외 일자 목록을 VEvent에 등록한다. */
		if (recurrence.getExceptionDates() != null && !recurrence.getExceptionDates().isEmpty()) {
			DateList dateList = new DateList();
			for (Date date : recurrence.getExceptionDates()) {
			 dateList.add(new DateTime(date));
			}
			vEvent.getProperties().add(new ExDate(dateList));
		}

		// Query Calendar Start and End Dates.
		/** 조회 시작과 끝 시간 범위안에 있는  VEvent의 반복 일정 정보를 조회 */ 
		PeriodList periods = vEvent.calculateRecurrenceSet(new Period(dtQueryStart, dtQueryEnd));
		 
		/** 반복일정의 시간정보를 이용하여 Event의 instance를 생성 */
		for (Iterator<Period> i = periods.iterator(); i.hasNext();) {
			Period period = (Period)i.next();
			Events instance = (Events)CopyUtil.copyDeeply(event);
			instance.setStartDate(period.getStart());
			instance.setEndDate(period.getEnd());
			instance.setRecurrenceId(period.getStart().getTime());
			instance.setRecurrenceDate(period.getStart());
			estimateAlarmDateTime(instance);
			instances.add(instance);
		}

		return instances;
	}
	
	/**
	 * @Description : Lunar 가포함된 Event의 반복 instance 조회
	 *              : (EventType이 LUNAR일 경우에는 조회 시작과 끝 시간을 해당년도의 음력값으로 변경하여 조회)
	 *              : (Lunar로 조회된 경우, translation 과정에서 음력값을 양력값으로 변환)
	 * @Method      : getInstancesWithLunar
	 * @param event
	 * @param queryStart
	 * @param queryEnd
	 * @return List<Events>
	 * @throws Exception
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	public static List<Events> getInstancesWithLunar(Events event, Date queryStart, Date queryEnd) throws Exception  {
		if (event.getSolarType() != null && SolarType.LUNAR.equals(event.getSolarType())) {
			// 음력을 검색할 경우엔 음력 시작일과 종료일을 태양력에 대입하고
			// 검색 범위일자를 음력일자로 대체하여 조회한다.
			event.setStartDate(event.getLunarStartDate());
			event.setEndDate(event.getLunarEndDate());
			
			queryStart = CalendarUtil.toLunar(queryStart);
			queryEnd = CalendarUtil.toLunar(queryEnd);
		}
		
		List<Events> instanceList = getInstances(event, queryStart, queryEnd);
		
		for (Iterator<Events> i = instanceList.iterator(); i.hasNext();) {
			Events instance = (Events)i.next();
			 
			translateInstance(instance);
		}

		return instanceList;
	}

	/**
	 * @Description : instance를 LUNAR 또는 SOLAR 타입에 맞게 property 정보를 변경한다.
	 * @Method      : translateInstance
	 * @param instance
	 * @throws Exception
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	private static void translateInstance(Events instance) throws Exception {
		int startOffset = instance.getStartDateOffset();
		int endOffset = instance.getEndDateOffset();
		
		try {
			if (instance.getSolarType() != null && SolarType.LUNAR.equals(instance.getSolarType())) {
				Date recurrenceDate = instance.getStartDate();
				instance.setStartDate(CalendarUtil.addDay(CalendarUtil.toSolar(instance.getStartDate()), startOffset));
				instance.setEndDate(CalendarUtil.addDay(CalendarUtil.toSolar(instance.getEndDate()), endOffset));
				
				instance.setRecurrenceId(CalendarUtil.toSolar(recurrenceDate).getTime());
				instance.setRecurrenceDate(CalendarUtil.toSolar(recurrenceDate));
				instance.setLunarRecurrenceDate(recurrenceDate);
				estimateAlarmDateTime(instance);
			} else {
				Date recurrenceDate = instance.getStartDate();
				instance.setStartDate(CalendarUtil.addDay(instance.getStartDate(), startOffset));
				instance.setEndDate(CalendarUtil.addDay(instance.getEndDate(), endOffset));
				
				instance.setLunarStartDate(CalendarUtil.toLunar(instance.getStartDate()));
				instance.setLunarEndDate(CalendarUtil.toLunar(instance.getEndDate()));
				 
				HashMap<String, Object> lunarMap = CalendarUtil.toLunarWithLeap(recurrenceDate);
				 
				instance.setRecurrenceId(recurrenceDate.getTime());
				instance.setRecurrenceDate(recurrenceDate);
				instance.setLunarRecurrenceDate((Date)lunarMap.get("date"));
				instance.setLeap((int)lunarMap.get("leap"));
				 
				estimateAlarmDateTime(instance);
			}
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	/**
	 * @Description : 해당 Event의  다음 Alarm을 가져온다. (현재시간 기준 - 이미 지난 시간은 무의미)
	 * @Method      : nextAlarm
	 * @param event
	 * @param queryStart
	 * @return Events
	 * @throws Exception
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	public static Events nextAlarm(Events event, Date queryStart) throws Exception {
		Recurrence recurrence = event.getRecurrence();
		// recurrence가 없으면 해당 이벤트의 Alarm 설정 값을 계산하여  리턴
		if (recurrence == null || StringUtils.isEmpty(event.getRecurrenceYN()) || N.equals(event.getRecurrenceYN())) {
			// Event의 시작시간이 이미 지났거나, Alarm 받생 여부를 N으로 설정했을 경우는 Null 리턴
			if (event.getStartDate().compareTo(queryStart) < 0
					|| StringUtils.isEmpty(event.getAlarmYN())
					|| N.equals(event.getAlarmYN())) {
				return null;
			} else {
				event.setRecurrenceId(event.getStartDate().getTime());
				estimateAlarmDateTime(event);
				if (event.getAlarmDateTime().compareTo(queryStart) < 0) { return null; }
				 
				return event;
			}
		}
		
		Date queryEnd = estimateAlarmQueryEndDate(event, queryStart);
		
		List<Events> instanceList = getInstancesWithLunar(event, queryStart, queryEnd);
		
		Events alarmEvent = null;
		for (Events instance : instanceList) {
			if (instance.getAlarmDateTime().compareTo(queryStart) >= 0) {
				 /** 예외 일이 포함될 경우는 제외시킴 */
				 if (recurrence.getExceptionDates() != null && recurrence.getExceptionDates().contains(instance.getStartDate())) { continue; }
				 else {
					 alarmEvent = instance;
					 break;
				 }
			 } else {
				 continue;
			 }
		}
		
		return alarmEvent;
	}
	
	/**
	 * @Description : Alarm 발생 일시
	 * @Method      : estimateAlarmDateTime
	 * @param event
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	static void estimateAlarmDateTime(Events event) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(event.getRecurrenceId());
		int triggerValue = -1 * Math.abs(event.getAlarmTriggerValue());
		
		if (AlarmTriggerType.MINUTE.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.MINUTE, triggerValue);
		} else if (AlarmTriggerType.HOUR.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.HOUR_OF_DAY, triggerValue);
		} else if (AlarmTriggerType.DAY.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.DATE, triggerValue);
		} else if (AlarmTriggerType.WEEK.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.WEEK_OF_MONTH, triggerValue);
		}
		
		event.setAlarmDateTime(cal.getTime());
	}
	
	/**
	 * @Description : Next Alarm을 위해 반복설정값에 의한 현재시간 이후의 Instance가 발생할 예측 시간
	 * @Method      : estimateAlarmQueryEndDate
	 * @param event
	 * @param queryStart
	 * @return Date
	 * @Date        : 2015. 3. 30.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	private static Date estimateAlarmQueryEndDate(Events event, Date queryStart) {
		/** 반복에 의한 간격과 Alarm에 의한간격을 포함하여 계산해야 한다. */
		Calendar cal = Calendar.getInstance();
		Calendar maxCal = Calendar.getInstance();
		
		cal.setTime(queryStart);
		maxCal.setTime(queryStart);
		maxCal.add(Calendar.DATE, 30); // APP ENGINE의 Sheduled Task의 최대 적용일 수
		
		Recurrence recurrence = event.getRecurrence();
		
		//-----------------------------------------------------------------
		// Recurrecne의 의한 EndDate 추가
		
		int intervalValue = 1;
		if (recurrence.getInterval() != null) {
			int exceptionDateCount = 1;
			
			/** 반복간격에 혹시라도 예외일이 포함될수 있으므로 예외일시의 갯수만큼 반복 간격을 더해준다. */
			if (recurrence.getExceptionDates()!=null) { exceptionDateCount += recurrence.getExceptionDates().size(); }
			intervalValue = Math.abs(recurrence.getInterval()) * exceptionDateCount;
		}
		
		if (Frequency.SECONDLY.equals(recurrence.getFrequency())) {
			cal.add(Calendar.SECOND, intervalValue);
		} else if (Frequency.MINUTELY.equals(recurrence.getFrequency())) {
			cal.add(Calendar.MINUTE, intervalValue);
		} else if (Frequency.HOURLY.equals(recurrence.getFrequency())) {
			cal.add(Calendar.HOUR_OF_DAY, intervalValue);
		} else if (Frequency.DAILY.equals(recurrence.getFrequency())) {
			cal.add(Calendar.DATE, intervalValue);
		} else if (Frequency.WEEKLY.equals(recurrence.getFrequency())) {
			cal.add(Calendar.WEEK_OF_MONTH, intervalValue);
		}  else if (Frequency.MONTHLY.equals(recurrence.getFrequency())) {
			// 사실은 무의미하다(AppEngine의 Scheduled Task는 최대 30일 이상 불가능)
			cal.add(Calendar.MONTH, intervalValue);
		} else if (Frequency.YEARLY.equals(recurrence.getFrequency())) {
			// 사실은 무의미하다(AppEngine의 Scheduled Task는 최대 30일 이상 불가능)
			cal.add(Calendar.YEAR, intervalValue);
		}
		//-----------------------------------------------------------------
		
		//-----------------------------------------------------------------
		// Alarm Trigger에 의한 간격 추가
		int triggerValue = Math.abs(event.getAlarmTriggerValue());
		
		if (AlarmTriggerType.MINUTE.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.MINUTE, triggerValue);
		} else if (AlarmTriggerType.HOUR.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.HOUR_OF_DAY, triggerValue);
		} else if (AlarmTriggerType.DAY.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.DATE, triggerValue);
		} else if (AlarmTriggerType.WEEK.equals(event.getAlarmTriggerType())) {
			cal.add(Calendar.WEEK_OF_MONTH, triggerValue);
		}
		//-----------------------------------------------------------------
		
		/** Scheduled Task에 적용할 Alarm이 최대 적용가능한 maxCal의 값보다 큰지 판단 */
		if (cal.compareTo(maxCal) > 0) { return maxCal.getTime(); }
		else { return cal.getTime(); }
	}
	
	public static void sort(List<Events> list) {
		Collections.sort(list, new Comparator<Events>() {
	        @Override
	        public int compare(Events first, Events second) {
				if (first.getRecurrenceId() == null && second.getRecurrenceId() == null) {
	        		return 0;
	        	} else if (first.getRecurrenceId()==null ) {
	        		return 1;
	        	} else if (second.getRecurrenceId()==null) {
	        		return -1;
	        	}
	        	
	        	if (first.getRecurrenceId() > second.getRecurrenceId()) {
	        		return 1;
	        	} else if (first.getRecurrenceId() < second.getRecurrenceId()) {
	        		return -1;
	        	} else {
	        		return 0;
	        	}
	        }
	    });
	}
}
