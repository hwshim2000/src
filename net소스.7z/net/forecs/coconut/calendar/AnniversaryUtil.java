package net.forecs.coconut.calendar;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.security.SecurityUtils;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

public class AnniversaryUtil {
	private Map<String, Anniversary> anniversaryMap = new HashMap<String, Anniversary>();
	
	private String createKey(Anniversary anniversary) {
		StringBuilder sb = new StringBuilder();
		sb.append(anniversary.getOwner())
			.append(anniversary.getSolarType())
			.append(anniversary.getTitle())
			.append(anniversary.getYear())
			.append(anniversary.getDate());
			
		return SecurityUtils.getMD5(sb.toString());
		//return String.format("%s-%s-%s-%s", anniversary.getSolarType(), anniversary.getTitle(), anniversary.getYear(), anniversary.getDate());
	}
	
	@SuppressWarnings("unused")
	private void addAnniversary(Anniversary anniversary) {
		anniversaryMap.put(createKey(anniversary), anniversary);
	}
	public void addAnniversary(Users user) {
		if (user==null || user.getUserProfiles() == null) { return; }
		try {
			if (user.getUserProfiles().getBirthday() != null) {
				Date birthday = user.getUserProfiles().getBirthday();
				String title = String.format("%s's Birthday!", CommonService.getDisplayUserName(user));
				SolarType solarType = user.getUserProfiles().getSolarType() == null ? SolarType.SOLAR : user.getUserProfiles().getSolarType();
				//String birthYear = CalendarUtil.toString(birthday, "yyyy");
				//String birthMonthDay = CalendarUtil.toString(birthday, "MMdd");
				
				int leap = 0;
				if (SolarType.SOLAR.equals(solarType)) {
					leap = CalendarUtil.getLeap(birthday);
				} else {
					leap = user.getUserProfiles().getBirthdayLeap();
				}
				Anniversary anniversary = new Anniversary(user.getUserId(), title, birthday, AnniversaryType.BIRTH, solarType, leap);
				//Anniversary anniversary = new Anniversary(user.getUserId(), title, birthday, birthYear, birthMonthDay, solarType, leap);
				
				anniversaryMap.put(createKey(anniversary), anniversary);
			}
			if (user.getUserProfiles().getWeddingday() != null) {
				Date weddingday = user.getUserProfiles().getWeddingday();
				String title = String.format("%s's Weddingday!", CommonService.getDisplayUserName(user));
				SolarType solarType = SolarType.SOLAR;
				//String weddingYear = CalendarUtil.toString(weddingday, "yyyy");
				//String weddingMonthDay = CalendarUtil.toString(weddingday, "MMdd");
				Anniversary anniversary = new Anniversary(user.getUserId(), title, weddingday, AnniversaryType.WEDDING, solarType, 0);
				//Anniversary anniversary = new Anniversary(user.getUserId(), title, weddingday, weddingYear, weddingMonthDay, solarType, 0);
				anniversaryMap.put(createKey(anniversary), anniversary);
			}
		} catch (Exception ex) {
		}
	}
	
	public List<Events> createAnniversaryEventList(String domainId, String boardId) {
		List<Events> eventList = new ArrayList<Events>();
		for (Map.Entry<String, Anniversary> entry : anniversaryMap.entrySet()) {
			Events event = (Events)entry.getValue();
			event.setDomainId(domainId);
			event.setBoardId(boardId);
			
			event.setKey(KeyUtil.createEventKey(entry.getKey()));
			event.setEventGroupId(event.getEventId());
			if (StringUtils.isEmpty(event.getUid())) {
				event.setUid(event.getEventId());
			}
			
			eventList.add(event);
		}

		return eventList;
	}
}
