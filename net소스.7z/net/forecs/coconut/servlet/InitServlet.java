package net.forecs.coconut.servlet;

import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import net.forecs.coconut.endpoint.common.CommonService;

import com.google.appengine.api.modules.ModulesServiceFactory;

@Singleton
public class InitServlet extends HttpServlet {
	private static final long serialVersionUID = -5167641910618701815L;
	private static final Logger LOG = Logger.getLogger(InitServlet.class.getName());

	@Inject
	public InitServlet() { }

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			CommonService.initEntityManager();
			//List<Domains> list = CommonService.listDomains(null, null).getResultList();
			//logger.warning("[INIT] New instance startup.(domains : " + list.size() +")");
			try {
				LOG.warning("[INIT] Instance ID : " + ModulesServiceFactory.getModulesService().getCurrentInstanceId());
			} catch (Exception ex) {
				LOG.warning("[INIT] Development server does not support module service.");
			}
		} catch (Exception ex) {
			LOG.warning("[INIT Error] "+ ex.getMessage());	
		}
	}
}
