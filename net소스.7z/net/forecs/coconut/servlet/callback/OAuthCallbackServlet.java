package net.forecs.coconut.servlet.callback;

/*
 * Copyright (c) 2010 Google Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.util.security.OAuthUtils;

import com.google.api.client.auth.oauth2.AuthorizationCodeFlow;
import com.google.api.client.auth.oauth2.AuthorizationCodeResponseUrl;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.appengine.auth.oauth2.AbstractAppEngineAuthorizationCodeCallbackServlet;
import com.google.appengine.api.users.UserServiceFactory;

/**
 * HTTP servlet to process access granted from user.
 * 
 * @author Yaniv Inbar
 */
public class OAuthCallbackServlet extends AbstractAppEngineAuthorizationCodeCallbackServlet {

	private static final Logger LOG = Logger.getLogger(OAuthCallbackServlet.class.getName());
	private static final long serialVersionUID = 1L;

	@Override
	protected void onSuccess(HttpServletRequest request, HttpServletResponse response, Credential credential) throws ServletException, IOException {

		String scheme = request.getScheme() + "://";
		String serverName = request.getServerName();
		String serverPort = (request.getServerPort() == 80) ? "" : ":" + request.getServerPort();
		String contextPath = request.getContextPath();
		String servletPath = request.getServletPath();
		String pathInfo = (request.getPathInfo() == null) ? "" : request.getPathInfo();
		String queryString = (request.getQueryString() == null) ? "" : "?" + request.getQueryString();

		LOG.info("request url:" + scheme + serverName + serverPort+ contextPath + servletPath + pathInfo + queryString);

		response.sendRedirect(CommonProperty.MY_GOOGLE_CALENDAR_URL);
	}

	@Override
	protected void onError(HttpServletRequest req, HttpServletResponse resp, AuthorizationCodeResponseUrl errorResponse) throws ServletException, IOException {
		String nickname = UserServiceFactory.getUserService().getCurrentUser().getNickname();
		resp.getWriter().print(
				"<h3>" + nickname
						+ ", why don't you want to play with me?</h1>");
		resp.setStatus(200);
		resp.addHeader("Content-Type", "text/html");
	}

	@Override
	protected String getRedirectUri(HttpServletRequest req)	throws ServletException, IOException {
		return OAuthUtils.getRedirectUri(req);
	}

	@Override
	protected AuthorizationCodeFlow initializeFlow() throws IOException {
		return OAuthUtils.newFlow();
	}
}
