package net.forecs.coconut.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineService;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;

import org.apache.commons.lang.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@Deprecated
@Singleton
public class PostShareServlet extends HttpServlet {
	private static final long serialVersionUID = 5854425377393309446L;
	private static final Logger LOG = Logger.getLogger(PostShareServlet.class);
	
	private final ITaskTimelineService taskTimelineService;
	private final ITaskService taskService;
	
	private static final String COCOWORKS_LOGO = "https://www.cocoworks.net/images/main/cocoworks_logo.png";
	
	@Inject
	public PostShareServlet(ITaskTimelineService taskTimelineService, ITaskService taskService) {
		this.taskTimelineService = taskTimelineService;
		this.taskService = taskService;
	}
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		process(req, res);
	}
	private void process(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		try {
			String keyStr = req.getParameter("linkId");
			if (StringUtils.isBlank(keyStr)) {
				throw new UnavailableException("Requires parameter");
			}
			Key key = KeyFactory.stringToKey(keyStr);
			
			String namespace = key.getNamespace();
			//String kind = key.getKind();
			
			TaskTimelines timeline = getTaskTimeline(namespace, keyStr);
			Tasks task = getTasks(namespace, timeline.getTaskId());
			String title = "[BOARDS] > " + task.getTaskStage() + " > " +task.getTitle();
			 
			Document doc = Jsoup.parse(timeline.getDescription().getValue());
			String description = doc.text();
			Elements imageEls = doc.select("img[src]");
			String image = null;
			if (imageEls.size() > 0) { image = imageEls.get(0).attr("src"); } 
			if (StringUtils.isBlank(image)) {
				if (timeline.getImages().size() > 0) {
					image = timeline.getImages().get(0).getServingUrl();
				} else {
					image = COCOWORKS_LOGO;	
				}
			}
			
			String linkUrl = req.getRequestURL() + "?" + req.getQueryString();
			
			res.setContentType("text/html");
			res.setCharacterEncoding(CommonProperty.UTF_8);
			PrintWriter writer = res.getWriter();
			writer.println("<!doctype html><html><head>");
			writer.println("<meta http-equiv='content-type' content='text/html; charset=UTF-8'>");
			
			writer.println("<meta property='og:title' content='" + title + "'>");
			writer.println("<meta property='og:description' content='" + description + "'>");
			if (StringUtils.isNotBlank(image)) {
				writer.println("<meta property='og:image' content='" + image + "'>");
			}
			
			writer.println("<title>" + title + "</title>");
			writer.println("</head><body>");
			writer.println("<div style='width:300px;height:500px;border:1px solid #cdcdcd;'>");
			writer.println("<div style='background:#eeeeee;width:294px;height:20px;border:1px solid #777777;padding:1px;padding-top:7px;margin:1px;font-family:굴림체;font-size:12px;font-weight:bold;'>"
					+ title
					+ "</div>");
			writer.println("<div style='background:#eeeeee;width:294px;height:400px;border:1px solid #777777;padding:1px;margin:1px;font-family:굴림체;font-size:11px;'>"
					+ "<img src='" + image + "'><br>"
					+ description
					+ "</div>");
			writer.println("<div style='width:294px;border:1px solid red;padding:1px;margin:1px;'><a target='_blank' href='https://www.cocoworks.net'>https://www.cocoworks.net</a></div>");
			writer.println("<div style='width:294px;border:1px solid red;padding:1px;margin:1px;'><a target='_blank' href='"+linkUrl+"'><img src='" + image + "'></a></div>");
			writer.println("</div>");
			writer.println("<div><iframe width='640' height='360' src='https://www.youtube.com/embed/AMSvArIMPrc'></iframe></div>");
			writer.println("</body></html>");
			
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		}
	}
	
	private TaskTimelines getTaskTimeline(String domainName, String taskTimelineId) throws Exception {
		return taskTimelineService.getTaskTimelines(domainName, taskTimelineId);
		
	}
	private Tasks getTasks(String domainName, String taskId) throws Exception {
		return taskService.getTasks(domainName, taskId);
	}
}
