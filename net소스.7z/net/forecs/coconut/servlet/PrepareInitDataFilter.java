package net.forecs.coconut.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.PrepareManager;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.user.Users;

public class PrepareInitDataFilter implements Filter {
	private static final Logger LOG = Logger.getLogger(PrepareInitDataFilter.class.getName());
	
	@Override
	public void init(FilterConfig config) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		assert (request instanceof HttpServletRequest);

		HttpServletRequest httpRequest = (HttpServletRequest)request;
		HttpServletResponse httpResponse = (HttpServletResponse)response;
		
		//httpResponse.setHeader("Access-Control-Allow-Origin", "https://www.cocoworks.net");
		httpResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpResponse.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
		httpResponse.setHeader("Access-Control-Max-Age", "3600");
		httpResponse.setHeader("Access-Control-Allow-Headers", "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization");

		String boardId = httpRequest.getParameter(PARAM.BOARDID);
		String prepareType = httpRequest.getParameter(PARAM.PREPARETYPE);
		
//		String requestUri = httpRequest.getRequestURI();
		Users user = CommonService.getCurrentUser();
		
		if (user != null) {
			String domainName = user.getDomainName();
			String userId = user.getUserId();
			
			PrepareManager.prepare(domainName, userId, boardId, prepareType);
			LOG.warning(String.format("PrepareType=%s, Domain=%s, User=%s, Boards=%s", prepareType, domainName, user.getUserName(), boardId));
		} else {
			LOG.warning("User session not found.");
		}
		return;
//		HttpServletResponse httpResponse = (HttpServletResponse)response;
//		try (TokenContext context = TokenContext.create(httpRequest, httpResponse)) {
//			chain.doFilter(request, response);
//		}
	}

	@Override
	public void destroy() {
	}
}
