package net.forecs.coconut.servlet.cron;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.channel.FirebaseChannel;

@Singleton
public class RemoveAllUnavailableChannelServlet extends HttpServlet {
	private static final long serialVersionUID = -3469530417514085751L;
	private static final Logger LOG = Logger.getLogger(RemoveAllUnavailableChannelServlet.class.getName());

	

	@Inject
	public RemoveAllUnavailableChannelServlet() {
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		process(req, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			FirebaseChannel.getInstance().removeAllUnavailableDomainChannels();
			FirebaseChannel.getInstance().removeAllUnavailableOnlineUserChannels();
		} catch (Exception ex) {
			LOG.warning("[Remove all unavailable channel token]" + ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus(HttpServletResponse.SC_OK);
	}
}
