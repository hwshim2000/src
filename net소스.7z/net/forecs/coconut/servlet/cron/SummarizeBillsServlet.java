package net.forecs.coconut.servlet.cron;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.billing.IBillingService;

@Singleton
public class SummarizeBillsServlet extends HttpServlet {
	private static final long serialVersionUID = -1613809278865325449L;
	private static final Logger LOG = Logger.getLogger(SummarizeBillsServlet.class.getName());

	private final IBillingService billingService;
	
	@Inject
	public SummarizeBillsServlet(IBillingService billingService) {
		this.billingService = billingService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			billingService.summarizeBills();
		} catch (Exception ex) {
			LOG.warning("[CheckScheduledBills] "+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
