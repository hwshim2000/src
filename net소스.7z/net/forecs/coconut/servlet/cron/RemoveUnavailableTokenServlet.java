package net.forecs.coconut.servlet.cron;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.security.ITokenService;

@Singleton
public class RemoveUnavailableTokenServlet extends HttpServlet {
	private static final long serialVersionUID = -2792185494502656101L;

	private static final Logger LOG = Logger.getLogger(RemoveUnavailableTokenServlet.class.getName());

	private final ITokenService tokenService;

	@Inject
	public RemoveUnavailableTokenServlet(ITokenService tokenService) {
		this.tokenService = tokenService;
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		process(req, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			tokenService.removeUnavailableTokens(null);
		} catch (Exception ex) {
			LOG.warning("[Remove all unavailable access token]" + ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus(HttpServletResponse.SC_OK);
	}
}
