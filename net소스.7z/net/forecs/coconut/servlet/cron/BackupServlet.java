package net.forecs.coconut.servlet.cron;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.admin.IBackupService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.domain.Domains;


@Singleton
public class BackupServlet extends HttpServlet {
	private static final long serialVersionUID = -1987561769241819051L;
	private static final Logger LOG = Logger.getLogger(BackupServlet.class.getName());
	
	private final IBackupService backupService;
	
	@Inject
	public BackupServlet(IBackupService backupService) {
		this.backupService = backupService;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}
	
	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			QueryResult<Domains> queryResult = CommonService.listDomains(null, null);
			List<Domains> domainList = queryResult.getResultList();
			
			Long dateTimeMillis = new Date().getTime();
			
			for(Domains domainName : domainList) {
				backupService.dataBackupToGCS(domainName.getDomainName(), dateTimeMillis);
				
				dateTimeMillis += CommonProperty.BACKUP_INTERVAL_PER_DOMAIN;
			}			
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			resp.setStatus( HttpServletResponse.SC_OK );
		}
	}
}
