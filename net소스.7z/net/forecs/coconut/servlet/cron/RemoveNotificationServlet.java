package net.forecs.coconut.servlet.cron;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.endpoint.channel.INotificationService;

@Singleton
public class RemoveNotificationServlet extends HttpServlet {
	private static final long serialVersionUID = -5631056883825534L;
	private static final Logger LOG = Logger.getLogger(RemoveNotificationServlet.class.getName());
	private final INotificationService notificationService;
	
	@Inject
	public RemoveNotificationServlet(INotificationService notificationService) {
		this.notificationService = notificationService;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}
	
	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			notificationService.scheduledRemoveAllNotifications();
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			resp.setStatus( HttpServletResponse.SC_OK );
		}
	}
}
