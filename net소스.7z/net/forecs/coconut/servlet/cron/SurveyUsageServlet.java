package net.forecs.coconut.servlet.cron;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.endpoint.admin.IUsageService;

@Singleton
public class SurveyUsageServlet extends HttpServlet {
	private static final long serialVersionUID = -1582013483688553698L;
	private static final Logger LOG = Logger.getLogger(SurveyUsageServlet.class.getName());

	private final IUsageService ussageService;
	@Inject
	public SurveyUsageServlet(IUsageService ussageService) {
		this.ussageService = ussageService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			ussageService.surveyUsage();
		} catch (Exception ex) {
			LOG.warning("[Survey usage]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
