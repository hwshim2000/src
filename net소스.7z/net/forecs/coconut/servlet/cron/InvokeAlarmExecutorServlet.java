package net.forecs.coconut.servlet.cron;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





import org.apache.commons.lang.StringUtils;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.endpoint.board.IAlarmService;

/**
 * @Project    : coconut
 * @Package    : net.forecs.coconut.servlet.cron
 * @FileName   : InvokeAlarmExecutorServlet.java
 * @Date       : 2015. 3. 26.
 * @Author     : hyeunwoo.shim@forecs.net
 * @Version    :
 * @Histories  :
 * @Description: Alarm 대상을 도메인 별로 조회해서 Task에 등록
 *             : (도메인 별로 스케줄러를 등록하면 좋으나, App engine 자체적으로 스케줄러의 갯수 제한때문에 스케줄러에는 현 Servlet 만 등록하고,
 *             : 도메인 목록을 조회해서 TaskQueue에 일정시간마다 Alarm 대상을 조회할 수 있도록 처리)
 */
@Singleton
public class InvokeAlarmExecutorServlet extends HttpServlet {
	private static final long serialVersionUID = -3193169346722446989L;
	private static final Logger LOG = Logger.getLogger(InvokeAlarmExecutorServlet.class.getName());

	private final IAlarmService alarmService;
	
	@Inject
	public InvokeAlarmExecutorServlet(IAlarmService alarmService) {
		this.alarmService = alarmService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String eventTypeStr = req.getParameter(PARAM.EVENTTYPE);
			EventType eventType = null;
			if (StringUtils.isNotBlank(eventTypeStr)) {
				eventType = EventType.valueOf(eventTypeStr);
			}
			
			alarmService.invokeAlarmExecutor(eventType);
		} catch (Exception ex) {
			LOG.warning("[Invoke Alarm Executor]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
