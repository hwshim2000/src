package net.forecs.coconut.servlet.cron;

import java.io.IOException;
import java.util.Date;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.endpoint.common.IAttachmentService;

@Singleton
public class RemoveUploadedTrashFilesServlet extends HttpServlet {
	private static final long serialVersionUID = 5872430256778414172L;
	private static final Logger LOG = Logger.getLogger(RemoveUploadedTrashFilesServlet.class.getName());

	private final IAttachmentService attachmentService;

	@Inject
	public RemoveUploadedTrashFilesServlet(IAttachmentService attachmentService) {
		this.attachmentService = attachmentService;
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		process(req, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			attachmentService.removeUploadedTrashFiles(CalendarUtil.addDay(new Date(), -1));
		} catch (Exception ex) {
			LOG.warning("[Remove all uploaded trash files]" + ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus(HttpServletResponse.SC_OK);
	}
}
