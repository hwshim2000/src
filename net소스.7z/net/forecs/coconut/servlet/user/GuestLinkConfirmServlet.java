package net.forecs.coconut.servlet.user;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.board.IBoardInviteService;


@Deprecated
@Singleton
public class GuestLinkConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(GuestLinkConfirmServlet.class.getName());
	
	@SuppressWarnings("unused")
	private final IBoardInviteService boardInviteService;
	
	@Inject
	public GuestLinkConfirmServlet(IBoardInviteService boardInviteService) {
		this.boardInviteService = boardInviteService;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		try {
//			String inviteTokenId = req.getParameter(PARAM.INVITETOKEN);
//			if(boardInviteService.confirmInvite(inviteTokenId, req.getRemoteHost()) != null) {
//				resp.setStatus( HttpServletResponse.SC_OK );
//
//				RequestDispatcher rd = req.getRequestDispatcher("/");
//				rd.forward(req, resp);
//			}
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//		}
	}
}
