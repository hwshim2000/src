package net.forecs.coconut.servlet.user;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;


@Singleton
public class SettingsServlet extends BaseServlet {
	private static final long serialVersionUID = 8335033813412964020L;
	static final Logger LOG = Logger.getLogger(SettingsServlet.class.getName());

    @Inject
    SettingsServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String userId = request.getParameter(PARAM.ID);
            String password = request.getParameter(PARAM.PASSWORD);

            Subject subject = SecurityUtils.getSubject();
            String id = (String)subject.getPrincipal();
            IUser user = userDao.findUser(id);
            if (subject.isAuthenticated() && user != null) {
                if (userId.equals(id)) {
                    if (password != null) {
                    	user = userDao.savePassword(userId, password);
                        issueJson(response, HTTP_STATUS_OK, MESSAGE, "password changed successfully");
                    } else {
                        issueJson(response, HTTP_STATUS_FORBIDDEN, MESSAGE, "Your password is invalid: " + password);
                    }
                } else {
                    issueJson(response, HTTP_STATUS_NOT_FOUND, MESSAGE, "You're not " + userId);
                }
            }  else {
                if (user == null) {
                    issueJson(response, HTTP_STATUS_FORBIDDEN, MESSAGE, "You're not a user I can set the password for");
                }  else {
                    issueJson(response, HTTP_STATUS_FORBIDDEN, MESSAGE, "You're not authenticated");
                }
            }
        } catch (Exception e) {
            issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR, MESSAGE, "Oops, error in settings: " + e.getMessage());
        }
    }
}