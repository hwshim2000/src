package net.forecs.coconut.servlet.user;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.persistence.EntityNotFoundException;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.util.FileTypes;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.shiro.authz.UnauthenticatedException;

import au.com.bytecode.opencsv.CSVWriter;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


@Singleton
public class ExcelDownloadServlet extends HttpServlet {
	private static final Logger LOG = Logger
			.getLogger(ExcelDownloadServlet.class.getName());
	private static final long serialVersionUID = 4611474435933334643L;

	private final IUserService userService;

	private final static String DEFAULT_SHEET_NAME = "Domain User List";
	private final static String[] HEADERS = new String[] { "id", "password", "email", "userName", "memberInfo" };
	
	@Inject
	public ExcelDownloadServlet(IUserService userService) {
		this.userService = userService;
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) {
		try {
			req.setCharacterEncoding(CommonProperty.UTF_8);
			String domainId = req.getParameter(PARAM.DOMAINID);
			String loginUserId = req.getParameter(PARAM.USERID);
			String fileName = req.getParameter(PARAM.FILENAME);
			
			if (StringUtils.isBlank(domainId) || StringUtils.isBlank(loginUserId)) {
				throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage("DomainId and userId should not be empty."));
			}
			
			Users loginUser = userService.getUsers(loginUserId, false);
			if (!loginUser.isActive() || !loginUser.isSuper()) {	//	Admin has super authority.
				throw new UnauthenticatedException(ErrorCode.UNAUTHENTICATION.getMessage("Login user is not admin or super user."));
			}
			
			Key domainKey = KeyFactory.stringToKey(domainId);
			String domainName = domainKey.getName();
			
			String baseName = FilenameUtils.getBaseName(fileName);
			String ext = FilenameUtils.getExtension(fileName);
			
			if (StringUtils.isBlank(baseName)) { baseName = String.format("%s-UserList", domainName); }
			if (StringUtils.isBlank(ext) || !FileTypes.EXCEL_TYPES.contains(ext.toLowerCase())) { ext = FileTypes.DEFAULT_EXT; } 
			
			fileName = String.format("%s.%s", baseName, ext);
			
			List<Users> users = this.listDomainUsers(domainId);
			
			List<Users> userList = new ArrayList<Users>();
			for (Users user : users) {
				if (user.isAdmin()) { continue; }
				userList.add(user);
			}
			
			if (userList == null || userList.size() == 0) {
				throw new EntityNotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Can't find domain users."));
			}
	
			String mimeType = "application/octet-stream";
			res.setCharacterEncoding(CommonProperty.UTF_8);
			res.setContentType(mimeType);
			res.setHeader("Content-Transfer-Encoding", "binary;");
			res.setHeader("Pragma", "no-cache;");
			res.setHeader("Expires", "-1;");

			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", URLEncoder.encode(fileName, CommonProperty.UTF_8));
			res.setHeader(headerKey, headerValue);
			
			if (ext.equalsIgnoreCase(FileTypes.XLSX) || ext.equalsIgnoreCase(FileTypes.XLS)) {
				this.downloadForSSF(res, userList, ext);
			} else if (ext.equalsIgnoreCase(FileTypes.CSV) || ext.equalsIgnoreCase(FileTypes.TSV)){
				this.downloadForCSV(res, userList, ext);
			} 
			//LOG.info(fileName + " written successfully on disk.");
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		}
	}

	private List<Users> listDomainUsers(String domainId) {
		String prevNamespace = NamespaceManager.get();

		List<Users> userList = null;

		try {
			Key domainKey = KeyFactory.stringToKey(domainId);

			String domainName = domainKey.getName();
			NamespaceManager.set(domainName);

			userList = userService.listUsers(true, false);
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
		return userList;
	}
	
	@SuppressWarnings("resource")
	private void downloadForSSF(HttpServletResponse res, List<Users> userList, String ext) throws Exception {
		// Blank workbook
		Workbook workbook = null;
		
		try {
			if (ext.equalsIgnoreCase(FileTypes.XLSX)) {
				workbook = new XSSFWorkbook();
			} else {
				workbook = new HSSFWorkbook();
			}
			// Create a blank sheet
			Sheet sheet = workbook.createSheet(DEFAULT_SHEET_NAME);
	
			// This data needs to be written (Object[])
			Map<Integer, Object[]> data = new TreeMap<Integer, Object[]>();
			data.put(1, HEADERS);
	
			int rowNumbers = 2;
			for (Users user : userList) {
				data.put(rowNumbers++, new Object[] { user.getId(), "********", user.getEmail(), user.getUserName(), user.getNickName() });
			}
	
			// Iterate over data and write to sheet
			int rownum = 0;
			for (Map.Entry<Integer, Object[]> entry : data.entrySet()) {
				Row row = sheet.createRow(rownum++);
				Object[] objArr = entry.getValue();
				int cellnum = 0;
				for (Object obj : objArr) {
					Cell cell = row.createCell(cellnum++);
					if (obj instanceof String)
						cell.setCellValue((String) obj);
					else if (obj instanceof Integer)
						cell.setCellValue((Integer) obj);
				}
			}
			
			OutputStream os = res.getOutputStream();
			workbook.write(os);
			
			os.close();
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private void downloadForCSV(HttpServletResponse res, List<Users> userList, String ext) throws IOException {
		CSVWriter cw = null;
		
		try {
			if (ext.equalsIgnoreCase(FileTypes.CSV)) {
				cw = new CSVWriter(res.getWriter(), FileTypes.DELIMITER_COMMA, '"');
			} else {
				cw = new CSVWriter(res.getWriter(), FileTypes.DELIMITER_TAB , '"');
			}
			
			cw.writeNext(HEADERS);
			for (Users user : userList) {
				cw.writeNext(new String[] { user.getId(), "********", user.getEmail(), user.getUserName(), user.getNickName() });
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			cw.close();
		}
	}
}