package net.forecs.coconut.servlet.user;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;


@Singleton
public class UserSuspendServlet extends BaseServlet {
	private static final long serialVersionUID = 1285286160167818758L;
	static final Logger LOG = Logger.getLogger(UserSuspendServlet.class.getName());

	@Inject
    UserSuspendServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);    
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            if (!isCurrentUserAdmin()) {
                issueJson(response, HTTP_STATUS_OK,
                		MESSAGE, "Only admins can suspend users",
                		CODE, "404");
                return;
			}

            String id = request.getParameter(PARAM.ID);
            boolean suspend = getParameter(request, PARAM.SUSPEND, true);
            IUser user = userDao.findUser(id, false);
            if (user != null) {
                user = userDao.suspendUser(user.getObjectId(), suspend);
            	issueJson(response, HTTP_STATUS_OK,
            			MESSAGE, "User " + id + " is suspended");
            } else {
                LOG.warning("Can't find user " + id);
                issueJson(response, HTTP_STATUS_NOT_FOUND,
                		MESSAGE, "Can't find user " + id);
            }
        } catch (Exception e) {
            LOG.severe("Suspend failure: " + e.getMessage());
            issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR,
            		MESSAGE, "Error generating JSON: " + e.getMessage());
        }
    }
}