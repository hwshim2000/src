package net.forecs.coconut.servlet.user;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;
import net.forecs.coconut.servlet.ContentTypes;

import org.json.JSONException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.datastore.Cursor;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;


@Singleton
public class UserListServlet extends BaseServlet {
	private static final long serialVersionUID = 1069137266682862951L;
	static final Logger LOG = Logger.getLogger(UserListServlet.class.getName());

    private static final int MAX_QUERY_OFFSET = 50;

    @Inject
    UserListServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        try {
            int draw = getParameter(request, "draw", -1);
            int start = getParameter(request, "start", 0);
            int length = getParameter(request, "length", 10);
            String search = request.getParameter("search[value]");
            HttpSession session = request.getSession();
            doOutput(session, response, search, start, length, draw);
        } catch (Exception e) {
            LOG.severe("Error posting to list: " + e.getMessage());
            issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR, MESSAGE, "Error generating JSON: " + e.getMessage());
        }
    }

    private void doOutput(HttpSession session, HttpServletResponse response, String sSearch, int start, int length, int draw)
            throws JSONException, IOException {
        long nUsers = userDao.getCount();
		Map<String, Object> map = Maps.newHashMap();
		map.put("recordsTotal", nUsers);
		map.put("recordsFiltered", nUsers);
		map.put("draw", draw);

        List<IUser> users = users(session, userDao, sSearch, start, length);
        map.put("data", users);
        ObjectMapper mapper = new ObjectMapper();
        mapper.setDateFormat(new SimpleDateFormat("MMM dd yyyy"));
        String output = mapper.writeValueAsString(map);
        issue(response, ContentTypes.APPLICATION_JSON, HTTP_STATUS_OK, output); // This is JSON
    }

    private List<IUser> users(HttpSession session, IUserDao<? extends IUser> dao,
    		String sSearch, int start, int length) {
        if (sSearch != null && !"".equals(sSearch)) {
        	IUser user = dao.findUser(sSearch, false);
            List<IUser> list = Lists.newArrayList();
            if (user != null) {
                list.add(user);
            }
            return list;
        } else {
            List<IUser> list = Lists.newArrayList();

            Cursor cursor = (Cursor)session.getAttribute("cursor_" + start);
            if (cursor == null && start >= MAX_QUERY_OFFSET) {
                // Doing a query with an offset is very expensive as you have to read through
                // everything up to the offset.  So we just bail out if that it the case. The font
                // end should display an error of some sort.
                LOG.warning("Can't process query for offset " + start + " as its too expensive");
                return list;
            }

            QueryResult<? extends IUser> queryResult = dao.query(cursor, length, "-dateRegistered");
            list.addAll(queryResult.getResultList());
            cursor = queryResult.getCursor();

			session.setAttribute("cursor_" + (start + length), cursor);
            return list;
        }
    }
}