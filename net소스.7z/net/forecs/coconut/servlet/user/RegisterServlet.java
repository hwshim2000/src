package net.forecs.coconut.servlet.user;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;

import org.apache.shiro.crypto.RandomNumberGenerator;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.util.ByteSource;
import org.apache.shiro.util.SimpleByteSource;
import org.apache.shiro.web.util.WebUtils;

import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;


@Singleton
public class RegisterServlet extends BaseServlet {
	private static final long serialVersionUID = 9009820846393317908L;
	static final Logger LOG = Logger.getLogger(RegisterServlet.class.getName());

    private final String userBaseUrl;

    @Inject
    RegisterServlet(IUserDao<? extends IUser> userDao, @Named(FLD.userBaseUrl) String userBaseUrl) {
        super(userDao);
        this.userBaseUrl = userBaseUrl;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        doPost(request, response);    
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        try {
        	String domainName = WebUtils.getCleanParam(request, PARAM.DOMAINNAME);
            String id = WebUtils.getCleanParam(request, PARAM.ID);
            String userName = WebUtils.getCleanParam(request, PARAM.USERNAME);
            String email = WebUtils.getCleanParam(request, PARAM.EMAIL);
            boolean isForgot = Boolean.parseBoolean(WebUtils.getCleanParam(request, PARAM.EMAIL));

            IUser user = userDao.findUser(id, false);
            if (!isForgot && user != null && user.isRegistered()) {
                // You can't add a user who's already registered
                issueJson(response, HTTP_STATUS_FORBIDDEN,
                        MESSAGE, id + " is already registered");
            }  else {
                // we override the user, any registration email should work though (as long as its valid)
                String regCode = regCode(id);
                LOG.info("registration is " + regCode);

                userDao.saveRegCode(regCode, null, id, userName, email);

				/**
				 * Send registration email via the task queue.
				 * We need to use the task queue as it's possible for mail to take a long time
				 * and fail if we send it within servlet requests.
				 * <p> I'm using the default queue, which is limited to 5 requests per second,
				 * which would need to change if this was other than a simple demo.
				 */
                Queue queue = QueueFactory.getDefaultQueue();
                queue.add(TaskOptions.Builder
                        //.withUrl(userBaseUrl + "/tasks/sendRegCode")
                		.withUrl(userBaseUrl + CommonProperty.SEND_REG_CODE_URL)
                		.param(PARAM.DOMAINNAME, domainName)
                        .param(PARAM.ID, id)
                        .param(PARAM.EMAIL, email)
                        .param(PARAM.REGCODE, regCode)
                        .param(PARAM.FORGOT, Boolean.toString(isForgot)));

                issueJson(response, HTTP_STATUS_OK, MESSAGE, "ok");
            }
        } catch (Exception e) {
            LOG.warning("Can't register: " + e.getMessage());
            issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR, MESSAGE, "Internal error: " + e.getMessage());
        }
    }

    private String regCode(String userId) {
        RandomNumberGenerator rng = new SecureRandomNumberGenerator();
        ByteSource salt = rng.nextBytes();
        return new Sha256Hash(userId, new SimpleByteSource(salt), 63).toHex().substring(0,10);
    }
}