package net.forecs.coconut.servlet.user;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.util.CharsetUtil;
import net.forecs.coconut.common.util.FileTypes;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.util.Streams;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.poi.POIXMLDocument;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.shiro.authz.UnauthenticatedException;

import au.com.bytecode.opencsv.CSVReader;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


@Singleton
public class ExcelUploadServlet extends HttpServlet {
	private static final Logger LOG = Logger.getLogger(ExcelUploadServlet.class.getName());
	private static final long serialVersionUID = -2944278706081804769L;
	
	private final IDomainService domainService;
	private final IUserService userService;
	
	@Inject
	public ExcelUploadServlet(IDomainService domainService, IUserService userService) {
		this.domainService = domainService;
		this.userService = userService;
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) {
		List<Users> userList = new ArrayList<Users>();
		
		String results = null;
		
		try {
			req.setCharacterEncoding(CommonProperty.UTF_8);
			boolean isMultipart = ServletFileUpload.isMultipartContent(req);
			ServletFileUpload upload = new ServletFileUpload();
			
			HashMap<String, String> dataMap = new HashMap<String, String>();
			
			if (!isMultipart) {
				throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Form type is not multipart"));
			}

			FileItemIterator iterator = upload.getItemIterator(req);
			
			while (iterator.hasNext()) {
				FileItemStream item = iterator.next();
				String name = item.getFieldName();
				//InputStream stream = item.openStream();
				BufferedInputStream bis = new BufferedInputStream(item.openStream());
				
				if (item.isFormField()) {
					String value = Streams.asString(bis);
					dataMap.put(name, value);
					//LOG.warning("formField:" + name + " / value : " + value);
				} else {
//					LOG.info("Uploaded Filename : " + item.getName());
//					LOG.info("POIXML : " + POIXMLDocument.hasOOXMLHeader(bis));
//					LOG.info("POIFS : " + POIFSFileSystem.hasPOIFSHeader(bis));
					
					if (bis.markSupported() && (POIXMLDocument.hasOOXMLHeader(bis) || POIFSFileSystem.hasPOIFSHeader(bis))) {
						userList.addAll(getValidUserListForSS(bis));	
					} else if (isCSV(bis)) {
						userList.addAll(this.getValidUserListForCSV(bis));
					} else if (isTSV(bis)) {
						userList.addAll(this.getValidUserListForTSV(bis));
					} else {
						if (bis != null) { bis.close(); }
						throw new IOException("Unsupported file format(support file format=xls, xlsx, csv, tsv");
					}
				}
				
				if (bis != null) { bis.close(); }
			}

			List<Users> uploadedUsers = new ArrayList<Users>();
			List<Users> targetUsers = new ArrayList<Users>();
			List<Users> duplicationIdUsers = new ArrayList<Users>();
			List<Users> duplicationEmailUsers = new ArrayList<Users>();
			
			if (userList.size() > 0 && dataMap.size() > 0) {
				String domainId = dataMap.get(PARAM.DOMAINID);
				String loginUserId = dataMap.get(PARAM.USERID);
				if (StringUtils.isBlank(domainId) || StringUtils.isBlank(loginUserId)) {
					throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage("DomainId and userId should not be empty."));
				}
				
				Key domainKey = KeyFactory.stringToKey(domainId);
				String domainName = domainKey.getName();
				boolean isOverwrite = isOverwrite(dataMap.get(PARAM.OVERWRITE));
				
				
				Set<String> userIds = new HashSet<String>();
				Set<String> userEmails = new HashSet<String>();
				
				for (Users user : userList) {
					String id = user.getId();
					String email = user.getEmail();
					
					if (userIds.contains(id)) {
						duplicationIdUsers.add(user);
					} else if (userEmails.contains(email)) {
						duplicationEmailUsers.add(user);
					} else {
						//user.setId(id);
						targetUsers.add(user);
						userIds.add(id);
						userEmails.add(email);
					} 
				}
				
				uploadedUsers = bulkUploadDomainUsers(domainName, targetUsers, isOverwrite, loginUserId);
			}
			
			ObjectMapper om = new ObjectMapper();
			Map<String, Object> resultMap = new HashMap<String, Object>();
			
//			resultMap.put("requestUsers", userList);
//			resultMap.put("duplicationIdUsers", duplicationIdUsers);
//			resultMap.put("duplicationEmailUsers",  duplicationEmailUsers);
//			resultMap.put("targetUsers",  targetUsers);
//			resultMap.put("uploadedUsers", uploadedUsers);
			
			resultMap.put("duplcationIdCount", duplicationIdUsers.size());
			resultMap.put("duplicationEmailCount",  duplicationEmailUsers.size());
			resultMap.put("uploadedCount", uploadedUsers.size());
			resultMap.put("requestCount", userList.size());
			resultMap.put("targetCount", targetUsers.size());
			resultMap.put("failedCount",  targetUsers.size() - uploadedUsers.size());
			
			
			results = om.writeValueAsString(resultMap);
			res.setStatus( HttpServletResponse.SC_OK );
			res.getWriter().write(results);
			res.addHeader("Access-Control-Allow-Origin", "*");

		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		}
	}

	private static boolean isOverwrite(String value) {
		if (!StringUtils.isBlank(value) && (value.equalsIgnoreCase("on") || value.equalsIgnoreCase("true"))) { return true; }
		else { return false; }
	}
	
	private static boolean isCSV(BufferedInputStream bis) throws IOException {
		return isCSVorTSV(bis, FileTypes.DELIMITER_COMMA);
	}
	private static boolean isTSV(BufferedInputStream bis) throws IOException {
		return isCSVorTSV(bis, FileTypes.DELIMITER_TAB);
	}
	@SuppressWarnings("deprecation")
	private static boolean isCSVorTSV(BufferedInputStream bis, Character delimiter) throws IOException {
		try {
			
			DataInputStream dis = new DataInputStream(bis);
			 
			if (dis.available() != 0) {
				String row = dis.readLine();
				int delimiters = row.split(delimiter.toString()).length;
				
				//LOG.warning("DELIMITERS : " + delimiters);
				dis.reset();
				if (delimiters > 1) { return true; }
				else { return false; }
			} else {
				return false;
			}
		} catch (IOException ex) {
			throw ex;
		}
	}
	
	/**
	 * @Description : HSSF / XSSF / COMMON SS UserModel
	 * @Method      : getValidUserListForSS
	 * @param is
	 * @return
	 * @Date        : 2015. 5. 8.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	private List<Users> getValidUserListForSS(InputStream is) {
		List<Users> userList = new ArrayList<Users>();

		try {
			Workbook workbook = WorkbookFactory.create(is);
			Sheet sheet = workbook.getSheetAt(0);
			
			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Users user = getValidUser(row);

				if (user != null) {
					userList.add(user);
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
		} finally {

		}
		return userList;
	}
	
	private List<Users> getValidUserListForCSV(InputStream is) {
		return getValidUserListForCSVorTSV(is, FileTypes.DELIMITER_COMMA);
	}
	private List<Users> getValidUserListForTSV(InputStream is) {
		return getValidUserListForCSVorTSV(is, FileTypes.DELIMITER_TAB);
	}
	private List<Users> getValidUserListForCSVorTSV(InputStream is, char delimiter) {
		List<Users> userList = new ArrayList<Users>();

		try {
			String charset = CharsetUtil.detectCharset(is, CommonProperty.UTF_8);
			
			@SuppressWarnings("resource")
			CSVReader reader = new CSVReader(new InputStreamReader(is, charset), delimiter);
			String[] row;
			
			while ((row = reader.readNext()) != null) {
				if (row != null) {
					Users user = getValidUser(row);
					
					if (user != null) {
						userList.add(user);
					}
					LOG.info("[CSV Row] : " + Arrays.toString(row));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return userList;
	}

	private Users getValidUser(Row row) {
		Users user = new Users();
		EmailValidator emailValidator = EmailValidator.getInstance(false);
		
		String id = null;
		String password = null;
		String nickName = null;
		String email = null;
		String userName = null;
		
		id = StringUtils.trim(getStringValue(row, 0));
		password = StringUtils.trim(getStringValue(row, 1));
		email = StringUtils.trim(getStringValue(row, 2));
		userName = StringUtils.trim(getStringValue(row, 3));
		nickName = StringUtils.trim(getStringValue(row, 4));
		
		if (StringUtils.isBlank(id) 
				//|| StringUtils.isBlank(password)
				|| StringUtils.isBlank(email)
				|| StringUtils.isBlank(userName)
				|| !emailValidator.isValid(email)) {
			return null;
		}

		user.setId(id);
		user.setPassword(password);
		user.setEmail(email);
		user.setUserName(userName);
		user.setNickName(nickName);

		return user;
	}
	
	private String getStringValue(Row row, int index) {
		DataFormatter fmt = new DataFormatter();
		Cell cell = row.getCell(index, Row.RETURN_BLANK_AS_NULL);

		if (cell != null) {
			String value = fmt.formatCellValue(cell);
			if (value.trim().isEmpty()) {
				return null;
			}
			return value;
		}

		return null;
	}
	
	private Users getValidUser(String[] row) {
		if (row.length != 5) { return null; }
		
		Users user = new Users();
		EmailValidator emailValidator = EmailValidator.getInstance(false);

		String id = StringUtils.trim(row[0]);
		String password = StringUtils.trim(row[1]);
		String email = StringUtils.trim(row[2]);
		String userName = StringUtils.trim(row[3]);
		String nickName = StringUtils.trim(row[4]);
		
		if (StringUtils.isBlank(id)
				//|| StringUtils.isBlank(password)
				|| StringUtils.isBlank(email)
				|| StringUtils.isBlank(userName)
				|| !emailValidator.isValid(email)) {
			return null;
		}

		user.setId(id);
		user.setPassword(password);
		user.setEmail(email);
		user.setUserName(userName);
		user.setNickName(nickName);

		return user;
	}

	private List<Users> bulkUploadDomainUsers(String domainName,
			List<Users> userList, boolean isOverwrite, String loginUserId)
			throws Exception {
		String prevNamespace = NamespaceManager.get();
		List<Users> assignedUserList = null;
		List<Users> targetUserList = new ArrayList<Users>();
		try {
			NamespaceManager.set(domainName);
			
			Users loginUser = userService.getUsers(loginUserId, false);
			
			if (loginUser.isActive() && loginUser.isSuper()) {	// Admin has super authority.
				Set<String> userIds = new HashSet<String>();
				
				String domainId = KeyUtil.createDomainKeyString(domainName);
				Domains domain = domainService.getDomains(domainId);
				for (Users user : userList) {
					String id = user.getId();
					if (domain.isCaseInsensitive()) { id = id.toLowerCase(); }
					if (!userIds.contains(id)) {
						//user.setId(id);
						targetUserList.add(user);
						userIds.add(id);
					} 
				}
				assignedUserList = domainService.assignOrOverwriteMemberList(domain, targetUserList, isOverwrite, loginUserId);
			} else {
				throw new UnauthenticatedException(ErrorCode.UNAUTHENTICATION.getMessage("Login user is not admin or super user."));
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}

		return assignedUserList;
	}
}
