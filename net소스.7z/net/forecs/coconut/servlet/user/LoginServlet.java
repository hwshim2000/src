package net.forecs.coconut.servlet.user;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;
import net.forecs.coconut.shiro.ShiroUtils;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.web.util.WebUtils;


@Singleton
public class LoginServlet extends BaseServlet {
	private static final long serialVersionUID = 5895410858234970280L;
	static final Logger LOG = Logger.getLogger(LoginServlet.class.getName());

    @Inject
    public LoginServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        showView(response, "login.ftl");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        try {
            String userId = WebUtils.getCleanParam(request, PARAM.ID);
            String password = WebUtils.getCleanParam(request, PARAM.PASSWORD);
            boolean rememberMe = WebUtils.isTrue(request, PARAM.REMEMBERME);
            String host = request.getRemoteHost();
			try {
				ShiroUtils.loginWithNewSession(userId, password, rememberMe, host);
				issueJson(response, HTTP_STATUS_OK, MESSAGE, "ok");
			} catch (AuthenticationException e) {
				issueJson(response, HTTP_STATUS_NOT_FOUND,
						MESSAGE, "Cannot authorize " + userId + ": " + e.getMessage());
			}
		} catch (Exception e) {
			issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR,
					MESSAGE, "Internal error: " + e.getMessage());
		}
	}
}