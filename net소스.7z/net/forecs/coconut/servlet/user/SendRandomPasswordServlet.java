package net.forecs.coconut.servlet.user;

import java.io.IOException;
import java.util.HashMap;

import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.freemarker.DocBuilder;

import org.apache.commons.lang.StringUtils;

import com.ibm.icu.text.MessageFormat;


@Singleton
public class SendRandomPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 6133028512233490279L;
	private static final Logger LOG = Logger.getLogger(SendRandomPasswordServlet.class.getName());

	private final SendEmail sendMail;
	private final DocBuilder docBuilder;

	@Inject
	public SendRandomPasswordServlet(SendEmail sendMail, DocBuilder docBuilder) {
		this.sendMail = sendMail;
		this.docBuilder = docBuilder;
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String id = req.getParameter(PARAM.ID);
			String userId = req.getParameter(PARAM.USERID);
			String email = req.getParameter(PARAM.EMAIL);
			String userName = req.getParameter(PARAM.USERNAME);
			String nickName = req.getParameter(PARAM.NICKNAME);
			String randomPassword = req.getParameter(PARAM.RANDOMPASSWORD);
			//String templateName = req.getParameter(PARAM.TEMPLATENAME);
			
			//NamespaceManager.set(domainName);
			Messages message = Messages.localeMessages(userId, WRAPPED_CHAR_TYPE.EMAIL);
			
			//String subject = "임시 비밀번호 입니다.";
			String subject = message.getSourceMessage(Messages.SENDRANDOMPASSWORD_SUBJECT);
			String templateName = MessageFormat.format(CommonProperty.DOMAIN_USER_RANDOM_PASSWORD_TEMPLATE, message.getLocale());
			
			if (StringUtils.isNotBlank(id) && StringUtils.isNotBlank(email) 
					&& StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(randomPassword)) { 
				HashMap<String, Object> messageMap = new HashMap<String, Object>();
				messageMap.put(PARAM.DOMAINNAME, domainName);
				messageMap.put(PARAM.ID, id);
				messageMap.put(PARAM.USERNAME, userName);
				messageMap.put(PARAM.NICKNAME, nickName);
				messageMap.put(PARAM.RANDOMPASSWORD, randomPassword);
				messageMap.put(PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL);
				messageMap.put(PARAM.LOCALE, message.getLocale().toString());
				
				String htmlBody = docBuilder.createDocumentString(templateName, messageMap);
				
				sendMail.send(email, subject, htmlBody);
//				if (SmtpSendEMail.domains.contains(domainName)) {
//					SmtpSendEMail.send(email, subject, htmlBody);
//				} else {
//					sendMail.send(email, subject, htmlBody);
//				}
			}
		} catch (Exception ex) {
			LOG.warning("[Random Password Email]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
