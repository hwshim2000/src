package net.forecs.coconut.servlet.user;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.subject.Subject;


/**
 * Get the current session status via Ajax.  Gets information about whether the
 * user is known (remembered) and authenticated.  You are authenticated only if
 * you logged in during this session.
 * <p> Note that any client-side record of status can't be definitive -- checks are
 * always run server-side to avoid scams.  However this information can be used to
 * set up display options.
 */
@Singleton
public class StatusServlet extends BaseServlet {
	private static final long serialVersionUID = 4468335004058049392L;
	static final Logger LOG = Logger.getLogger(StatusServlet.class.getName());

    @Inject
    StatusServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.info("status GET");
        try {
            Subject subject = SecurityUtils.getSubject();
            boolean isKnown = subject.isAuthenticated() || subject.isRemembered();
            if (isKnown) {
                String userId = subject.getPrincipal().toString();
                LOG.info("status, known: " + userId);
                issueJson(response, HTTP_STATUS_OK,
                        MESSAGE, "known",
                        PARAM.ID, userId,
                        "authenticated", Boolean.toString(subject.isAuthenticated()),
                        "admin", Boolean.toString(hasRole(subject, "admin")));
            } else {
                LOG.info("status, unknown");
                issueJson(response, HTTP_STATUS_OK,
                        MESSAGE, "unknown",
                        PARAM.ID, "",
                        "authenticated", "false",
                        "admin", "false");
            }
        } catch (Exception e) {
            issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR, MESSAGE, "Internal error getting status: " + e.getMessage());
        }
    }

    private static boolean hasRole(Subject subject, String role) {
        try {
            subject.checkRole(role);
            return true;
        }  catch (AuthorizationException e)  {
            return false;
        }
    }
}