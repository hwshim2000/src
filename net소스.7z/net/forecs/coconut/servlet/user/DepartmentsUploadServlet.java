package net.forecs.coconut.servlet.user;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.util.CharsetUtil;
import net.forecs.coconut.common.util.FileTypes;
import net.forecs.coconut.endpoint.domain.IDepartmentService;
import net.forecs.coconut.entity.domain.Departments;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.util.Streams;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.POIXMLDocument;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import au.com.bytecode.opencsv.CSVReader;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@Singleton
public class DepartmentsUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 7689082005007287776L;
	private static final Logger LOG = Logger.getLogger(DepartmentsUploadServlet.class.getName());
	
	private final IDepartmentService departmentService;
	
	@Inject
	public DepartmentsUploadServlet(IDepartmentService departmentService) {
		this.departmentService = departmentService;
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) {
		try {
			List<Departments> departments = new ArrayList<Departments>();
			String results = null;
			
			req.setCharacterEncoding(CommonProperty.UTF_8);
			boolean isMultipart = ServletFileUpload.isMultipartContent(req);
			ServletFileUpload upload = new ServletFileUpload();
			
			HashMap<String, String> dataMap = new HashMap<String, String>();
			
			if (!isMultipart) {
				throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Form type is not multipart"));
			}

			FileItemIterator iterator = upload.getItemIterator(req);
			
			while (iterator.hasNext()) {
				FileItemStream item = iterator.next();
				String name = item.getFieldName();
				//InputStream stream = item.openStream();
				BufferedInputStream bis = new BufferedInputStream(item.openStream());
				
				if (item.isFormField()) {
					String value = Streams.asString(bis);
					dataMap.put(name, value);
					//LOG.warning("formField:" + name + " / value : " + value);
				} else {
//					LOG.info("Uploaded Filename : " + item.getName());
//					LOG.info("POIXML : " + POIXMLDocument.hasOOXMLHeader(bis));
//					LOG.info("POIFS : " + POIFSFileSystem.hasPOIFSHeader(bis));
					
					if (bis.markSupported() && (POIXMLDocument.hasOOXMLHeader(bis) || POIFSFileSystem.hasPOIFSHeader(bis))) {
						departments.addAll(getValidDepartmentsListForSS(bis));	
					} else if (isCSV(bis)) {
						departments.addAll(getValidDepartmentsListForCSV(bis));
					} else if (isTSV(bis)) {
						departments.addAll(getValidDepartmentsListForTSV(bis));
					} else {
						String jsonString = getString(bis);
						departments.addAll(departmentService.parseDepartments(jsonString));
					}
				}
				
				if (bis != null) { bis.close(); }
			}

			String userId = null;
			String key = null;

			if (departments.size() > 0 && dataMap.size() > 0) {
				userId = dataMap.get(PARAM.USERID);
				key = dataMap.get(PARAM.KEY);
			}

			if (StringUtils.isBlank(userId)) {
				res.getWriter().print("User id should not be empty.");
				throw new UnavailableException("User id should not be empty.");
			}
			
			if (!MemcacheManager.isValidAccessKey(key, userId)) {
				res.getWriter().print("Invalid key or upload time was expired.");
				throw new Exception("Invalid key or upload time was expired.");
			}

			Key userKey = KeyFactory.stringToKey(userId);
			String domainName = userKey.getNamespace();
			
			departmentService.applyDepartments(domainName, departments);
						
			ObjectMapper om = new ObjectMapper();
			results = om.writeValueAsString(departments);
			
			res.setStatus( HttpServletResponse.SC_OK );
			res.getWriter().write(results);
			res.addHeader("Access-Control-Allow-Origin", "*");

		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		}
	}
	
	private static boolean isCSV(BufferedInputStream bis) throws IOException {
		return isCSVorTSV(bis, FileTypes.DELIMITER_COMMA);
	}
	private static boolean isTSV(BufferedInputStream bis) throws IOException {
		return isCSVorTSV(bis, FileTypes.DELIMITER_TAB);
	}
	@SuppressWarnings("deprecation")
	private static boolean isCSVorTSV(BufferedInputStream bis, Character delimiter) throws IOException {
		try {
			
			DataInputStream dis = new DataInputStream(bis);
			 
			if (dis.available() != 0) {
				String row = dis.readLine();
				int delimiters = row.split(delimiter.toString()).length;
				
				//LOG.warning("DELIMITERS : " + delimiters);
				dis.reset();
				if (delimiters > 1) { return true; }
				else { return false; }
			} else {
				return false;
			}
		} catch (IOException ex) {
			throw ex;
		}
	}
	
	private List<Departments> getValidDepartmentsListForSS(InputStream is) {
		List<Departments> deptList = new ArrayList<Departments>();

		try {
			Workbook workbook = WorkbookFactory.create(is);
			Sheet sheet = workbook.getSheetAt(0);
			
			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				Departments dept = getValidDepartments(row);

				if (dept != null) { deptList.add(dept); }
			}
		} catch (Exception e) {
			//e.printStackTrace();
		} finally {

		}
		return deptList;
	}
	
	private List<Departments> getValidDepartmentsListForCSV(InputStream is) {
		return getValidDepartmentsListForCSVorTSV(is, FileTypes.DELIMITER_COMMA);
	}
	private List<Departments> getValidDepartmentsListForTSV(InputStream is) {
		return getValidDepartmentsListForCSVorTSV(is, FileTypes.DELIMITER_TAB);
	}
	private List<Departments> getValidDepartmentsListForCSVorTSV(InputStream is, char delimiter) {
		List<Departments> deptList = new ArrayList<Departments>();

		try {
			String charset = CharsetUtil.detectCharset(is, CommonProperty.UTF_8);
			
			@SuppressWarnings("resource")
			CSVReader reader = new CSVReader(new InputStreamReader(is, charset), delimiter);
			String[] row;
			
			while ((row = reader.readNext()) != null) {
				if (row != null) {
					Departments dept = getValidDepartments(row);
					
					if (dept != null) {	deptList.add(dept);	}
					LOG.info("[CSV Row] : " + Arrays.toString(row));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return deptList;
	}
	
	private String getString(InputStream is) {
		String result = null;
		try {
			String charset = CharsetUtil.detectCharset(is, CommonProperty.UTF_8);
			
			StringWriter writer = new StringWriter();
			IOUtils.copy(is, writer, charset);
			result = writer.toString();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}
	
	private Departments getValidDepartments(Row row) {
		String title = null;
		String desc = null;
		String contact = null;
		String parentDeptCode = null;
		String deptCode = null;
		String id = null;
		
		int index = 0;
		title = StringUtils.trim(getStringValue(row, index++));
		desc = StringUtils.trim(getStringValue(row, index++));
		contact = StringUtils.trim(getStringValue(row, index++));
		parentDeptCode = StringUtils.trim(getStringValue(row, index++));
		deptCode = StringUtils.trim(getStringValue(row, index++));
		id = StringUtils.trim(getStringValue(row, index++));
		
		if (isHeaderRow(title, desc, contact, parentDeptCode, deptCode, id)) { return null; }
		if (StringUtils.isBlank(title) || StringUtils.isBlank(deptCode)) { return null; }
		
		return new Departments(title, desc, contact, parentDeptCode, deptCode, id);
	}
	
	private String getStringValue(Row row, int index) {
		DataFormatter fmt = new DataFormatter();
		Cell cell = row.getCell(index, Row.RETURN_BLANK_AS_NULL);

		if (cell != null) {
			String value = fmt.formatCellValue(cell);
			if (value.trim().isEmpty()) {
				return null;
			}
			return value;
		}

		return null;
	}
	
	private Departments getValidDepartments(String[] row) {
		if (row.length != 6) { return null; }
		int index = 0;
		String title = StringUtils.trim(row[index++]);
		String desc = StringUtils.trim(row[index++]);
		String contact = StringUtils.trim(row[index++]);
		String parentDeptCode = StringUtils.trim(row[index++]);
		String deptCode = StringUtils.trim(row[index++]);
		String id = StringUtils.trim(row[index++]);
		
		if (isHeaderRow(title, desc, contact, parentDeptCode, deptCode, id)) { return null; }
		if (StringUtils.isBlank(title) || StringUtils.isBlank(deptCode)) { return null;	}
		
		return new Departments(title, desc, contact, parentDeptCode, deptCode, id);
	}
	
	private static boolean isHeaderRow(String title, String desc, String contact, String parentDeptCode, String deptCode, String id) {
		int matchCnt = 0; 
	
		if (StringUtils.equalsIgnoreCase("title", title)) { matchCnt++; }
		if (StringUtils.equalsIgnoreCase("description", desc)) { matchCnt++; }
		if (StringUtils.equalsIgnoreCase("contact", contact)) { matchCnt++; }
		if (StringUtils.equalsIgnoreCase("parentDeptCode", parentDeptCode)) { matchCnt++; }
		if (StringUtils.equalsIgnoreCase("deptCode", deptCode)) { matchCnt++; }
		if (StringUtils.equalsIgnoreCase("id", id)) { matchCnt++; }
		
		if (matchCnt > 3) { return true; }
		
		return false;
	}
}