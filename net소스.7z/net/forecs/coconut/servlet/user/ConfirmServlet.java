package net.forecs.coconut.servlet.user;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;
import net.forecs.coconut.user.Role;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;

import com.google.common.base.Preconditions;


/**
 * This servlet registers a user for the first time and also changes the password
 * if the user has lost it, or just wants a new one.
 * A change of password is accompanied by a <code>change</code> parameter.
 */
@Singleton
public class ConfirmServlet extends BaseServlet {
	private static final long serialVersionUID = 2152118806818745379L;
	static final Logger LOG = Logger.getLogger(ConfirmServlet.class.getName());

    @Inject
    ConfirmServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            final String regCode = Preconditions.checkNotNull(request.getParameter(PARAM.REGCODE), "The registration code can't be null");
            final String userId = Preconditions.checkNotNull(request.getParameter(PARAM.ID), "The user ID can't be null");
            final String password = Preconditions.checkNotNull(request.getParameter(PARAM.PASSWORD), "The password can't be null");

            boolean resetPassword = "true".equals(request.getParameter(PARAM.FORGOT));

            //-->
            //IUser user = userDao.registerUserFromCode(regCode, password,
            //		Role.DEFAULT_ROLES, Permission.DEFAULT_PERMISSIONS);
    		//--
    		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
            IUser user = userDao.registerUserFromCode(regCode, password, Role.DEFAULT_ROLE);
            //<--
            if (user != null) {
                Subject sub = SecurityUtils.getSubject();
                UsernamePasswordToken token = new UsernamePasswordToken(userId, password);
                sub.login(token);

                issueJson(response, HTTP_STATUS_OK,
                        MESSAGE, resetPassword
                                ? "OK, password changed for user ID " + userId
                                : "OK, you're registered with user ID " + userId);
            } else {
                issueJson(response, HTTP_STATUS_NOT_FOUND,
                		MESSAGE, "Wrong code, or code is expired: \"" + regCode + "\", you'll need to retry");
            }
        } catch (Exception e) {
            issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR,
            		MESSAGE, "Error in confirm: " + e.getMessage());
        }
    }
}