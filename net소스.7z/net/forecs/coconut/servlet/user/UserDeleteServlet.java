package net.forecs.coconut.servlet.user;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;


@Singleton
public class UserDeleteServlet extends BaseServlet {
	private static final long serialVersionUID = -8125620114394106940L;
	static final Logger LOG = Logger.getLogger(UserDeleteServlet.class.getName());

    @Inject
    public UserDeleteServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    try {
	        String id = request.getParameter(PARAM.ID);
	        IUser user = userDao.findUser(id, false);
	        if (user != null) {
	            if (isCurrentUserAdmin()) {
	            	//userDao.deleteUser(user);
	            	userDao.deleteUser(user.getObjectId());
	                issueJson(response, HTTP_STATUS_OK,
	                        MESSAGE, "User " + id + " is deleted");
	            } else {
	                issueJson(response, HTTP_STATUS_OK,
	                        MESSAGE, "Only admins can delete users",
	                        CODE, "404");
	                }
	        } else {
	            LOG.warning("Can't find user " + id);
	            issueJson(response, HTTP_STATUS_NOT_FOUND,
	            		MESSAGE, "Can't find user " + id);
	        }
	    } catch (Exception e) {
	        LOG.severe("Suspend failure: " + e.getMessage());
	        issueJson(response, HTTP_STATUS_INTERNAL_SERVER_ERROR,
	        		MESSAGE, "Error generating JSON: " + e.getMessage());
	    }
    }
}