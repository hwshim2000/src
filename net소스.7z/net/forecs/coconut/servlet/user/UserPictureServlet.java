package net.forecs.coconut.servlet.user;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;

import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Text;

@Singleton
public class UserPictureServlet extends HttpServlet {
	private static final Logger LOG = Logger
			.getLogger(UserPictureServlet.class.getName());
	private static final long serialVersionUID = -5810764830925108799L;
	private final IUserService userService;
	
	@Inject
	public UserPictureServlet(IUserService userService) {
		this.userService = userService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}

	@SuppressWarnings("deprecation")
	private void process(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String prevNamespace = NamespaceManager.get();
		try {
			long cacheAge = 60*60*24*365;
			long expiry = new Date().getTime() + cacheAge*1000;
		    
			res.setDateHeader("Expires", expiry);
			res.setHeader("Cache-Control", "max-age="+ cacheAge);
		    
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String userId = req.getParameter(PARAM.USERID);

			if (StringUtils.isBlank(domainName) || StringUtils.isBlank(userId)) {
				throw new Exception(ErrorCode.ILLEGAL_PARAMETER.getMessage("DomainName and userId are required."));
			}
			
			NamespaceManager.set(domainName);
			
			Text userPicture = null;
			Users user = userService.getUsers(userId, false);
			if (user != null) {
				userPicture = user.getPicture();
			}
			
			if (userPicture != null && StringUtils.isNotBlank(userPicture.getValue())) {
				String mimeType = "application/octet-stream";
//				res.setCharacterEncoding(ExcelUtil.ENCODING);
				res.setContentType(mimeType);
//				res.setHeader("Content-Transfer-Encoding", "binary;");
//				res.setHeader("Pragma", "no-cache;");
//				res.setHeader("Expires", "-1;");
				//byte[] b = Base64.decodeBase64(userPicture.getValue().split("^data:image/(png|jpeg|jpg|jpe|gif|bmp|x-portable-bitmap|tiff|tif|x-xbitmap);base64,")[1]);
				byte[] b = Base64.decodeBase64(userPicture.getValue().split("^data:image/.+;base64,")[1]);
				  
				InputStream inStream = new ByteArrayInputStream(b);
		        OutputStream outStream = res.getOutputStream();
		         
		        byte[] buffer = new byte[4096];
		        int bytesRead = -1;
		         
		        while ((bytesRead = inStream.read(buffer)) != -1) {
		            outStream.write(buffer, 0, bytesRead);
		        }
		         
		        inStream.close();
		        outStream.close();      
			}
		} catch (Exception ex) {
			LOG.warning("[User Picture Get Error] "+ex.getMessage());
			//throw new IOException(ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
		//res.setStatus( HttpServletResponse.SC_OK );
	}
}
