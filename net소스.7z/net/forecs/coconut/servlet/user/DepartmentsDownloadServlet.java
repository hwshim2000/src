package net.forecs.coconut.servlet.user;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.persistence.EntityNotFoundException;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Dept;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.CharsetUtil;
import net.forecs.coconut.common.util.FileTypes;
import net.forecs.coconut.endpoint.domain.IDepartmentService;
import net.forecs.coconut.entity.domain.Departments;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import au.com.bytecode.opencsv.CSVWriter;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@Singleton
public class DepartmentsDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = -4038492815382143875L;
	private static final Logger LOG = Logger
			.getLogger(DepartmentsDownloadServlet.class.getName());
	
	private final IDepartmentService departmentService;
	
	private final static String DEFAULT_SHEET_NAME = "Domain Department List";
	private final static String[] HEADERS = new String[] { "title", "description", "contact", "parentDeptCode", "deptCode", "id" };
	
	@Inject
	public DepartmentsDownloadServlet(IDepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) {
		try {
			req.setCharacterEncoding(CommonProperty.UTF_8);
			
			String userId = req.getParameter(PARAM.USERID);
			String format = req.getParameter(PARAM.FORMAT);
			String key = req.getParameter(PARAM.KEY);
			
			if (StringUtils.isBlank(userId)) {
				res.getWriter().print("Domain name and user id should not be empty.");
				throw new UnavailableException("Domain name and user id should not be empty.");
			}
			
			if (!MemcacheManager.isValidAccessKey(key, userId)) {
				res.getWriter().print("Invalid key or download time was expired.");
				throw new Exception("Invalid key or download time was expired.");
			}
			
			Key userKey = KeyFactory.stringToKey(userId);
			String domainName = userKey.getNamespace();
			
			String baseName = String.format("%s-Departments-%s", domainName, CalendarUtil.toString(new Date(), "yyyyMMddHHmmss"));
			if (StringUtils.isBlank(format) || !FileTypes.AVAIL_TYPES.contains(format.toLowerCase())) { format = FileTypes.DEFAULT_EXT; } 
			String fileName = baseName + "." + format;
			
			List<Departments> departments = listDepartments(domainName);
			ObjectMapper om = new ObjectMapper();
			String encoding = CharsetUtil.getEncoding(om.writeValueAsString(departments));
		
			String mimeType = "application/octet-stream";
			res.setCharacterEncoding(encoding);
			res.setContentType(mimeType);
			res.setHeader("Content-Transfer-Encoding", "binary;");
			res.setHeader("Pragma", "no-cache;");
			res.setHeader("Expires", "-1;");

			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", URLEncoder.encode(fileName, CommonProperty.UTF_8));
			res.setHeader(headerKey, headerValue);
			
			if (format.equalsIgnoreCase(FileTypes.XLSX) || format.equalsIgnoreCase(FileTypes.XLS)) {
				downloadForSSF(res, departments, format);
			} else if (format.equalsIgnoreCase(FileTypes.CSV) || format.equalsIgnoreCase(FileTypes.TSV)){
				downloadForCSV(res, departments, format);
			} else if (format.equalsIgnoreCase(FileTypes.JSON_ARR)) {
				downloadForJsonArray(res, departments);
			} else if (format.equalsIgnoreCase(FileTypes.JSON)) {
				downloadForJsonObject(res, departments);
			}
			//LOG.info(fileName + " written successfully on disk.");
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		}
	}

	private List<Departments> listDepartments(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			List<Departments> departments = departmentService.listDepartments(true);
			if (departments == null || departments.size() == 0) {
				throw new EntityNotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Can't find domain departments."));
			}
			return departments;
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@SuppressWarnings("resource")
	private void downloadForSSF(HttpServletResponse res, List<Departments> departments, String ext) throws Exception {
		// Blank workbook
		Workbook workbook = null;
		
		try {
			if (ext.equalsIgnoreCase(FileTypes.XLSX)) {
				workbook = new XSSFWorkbook();
			} else {
				workbook = new HSSFWorkbook();
			}
			// Create a blank sheet
			Sheet sheet = workbook.createSheet(DEFAULT_SHEET_NAME);
	
			// This data needs to be written (Object[])
			Map<Integer, Object[]> data = new TreeMap<Integer, Object[]>();
			data.put(1, HEADERS);
			int rowNumbers = 2;
			for (Departments dept : departments) {
				data.put(rowNumbers++, toRowData(dept));
			}
	
			// Iterate over data and write to sheet
			int rownum = 0;
			for (Map.Entry<Integer, Object[]> entry : data.entrySet()) {
				Row row = sheet.createRow(rownum++);
				Object[] objArr = entry.getValue();
				int cellnum = 0;
				for (Object obj : objArr) {
					Cell cell = row.createCell(cellnum++);
					if (obj instanceof String)
						cell.setCellValue((String) obj);
					else if (obj instanceof Integer)
						cell.setCellValue((Integer) obj);
				}
			}
			
			OutputStream os = res.getOutputStream();
			workbook.write(os);
			
			os.close();
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private void downloadForCSV(HttpServletResponse res, List<Departments> departments, String ext) throws IOException {
		CSVWriter cw = null;
		
		try {
			if (ext.equalsIgnoreCase(FileTypes.CSV)) {
				cw = new CSVWriter(res.getWriter(), FileTypes.DELIMITER_COMMA, '"');
			} else {
				cw = new CSVWriter(res.getWriter(), FileTypes.DELIMITER_TAB , '"');
			}
			
			cw.writeNext(HEADERS);
			for (Departments dept : departments) {
				cw.writeNext(toRowData(dept));
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			cw.close();
		}
	}
	
	private void downloadForJsonArray(HttpServletResponse res, List<Departments> departments) throws IOException {
		PrintWriter writer = null;
		try {
			writer = res.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			List<Dept> depts = Dept.convertToDept(departments);
			String jsonStr = mapper.writeValueAsString(depts);
			
			writer.print(jsonStr);
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (writer != null) { writer.close(); }
		}
	}
	
	private void downloadForJsonObject(HttpServletResponse res, List<Departments> departments) throws IOException {
		PrintWriter writer = null;
		try {
			writer = res.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			Map<String, List<Dept>> deptMap = new HashMap<String, List<Dept>>();
			
			mapper.setSerializationInclusion(Include.NON_NULL);
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			List<Dept> depts = Dept.convertToDept(departments);
			deptMap.put("items", depts);
			String jsonStr = mapper.writeValueAsString(deptMap);
			
			writer.print(jsonStr);
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (writer != null) { writer.close(); }
		}
	}

	private static String[] toRowData(Departments dept) {
		String title = dept.getTitle();
		String desc = null;
		String contact = dept.getContact();
		String parentDeptCode = dept.getParentDeptCode();
		String deptCode = dept.getDeptCode();
		String id = null;
		
		if (dept.getDescription() != null) { desc = dept.getDescription().getValue(); }
		if (StringUtils.isBlank(parentDeptCode) && StringUtils.isNotBlank(dept.getParentId())) {
			parentDeptCode = KeyFactory.stringToKey(dept.getParentId()).getName();
		}
		if (StringUtils.isBlank(deptCode) && StringUtils.isNotBlank(dept.getDepartmentId())) {
			deptCode = KeyFactory.stringToKey(dept.getDepartmentId()).getName();
		}
		if (StringUtils.isNotBlank(dept.getMemberId())) { id = KeyFactory.stringToKey(dept.getMemberId()).getName(); }
		return new String[] { title, desc, contact, parentDeptCode, deptCode, id };
	}
}