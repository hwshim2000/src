package net.forecs.coconut.servlet.calendar;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.calendar.CalendarConverter;
import net.forecs.coconut.calendar.GoogleCalendarConverter;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.CalendarAccessRole;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.security.OAuthUtils;
import net.forecs.coconut.endpoint.calendar.ICalendarService;
import net.forecs.coconut.entity.calendar.Calendars;
import net.forecs.coconut.entity.calendar.Events;

import org.apache.commons.lang.StringUtils;

import com.google.api.client.auth.oauth2.AuthorizationCodeFlow;
import com.google.api.client.extensions.appengine.auth.oauth2.AbstractAppEngineAuthorizationCodeServlet;
import com.google.api.services.calendar.model.CalendarList;
import com.google.api.services.calendar.model.CalendarListEntry;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Text;
import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;


@Singleton
//public class GoogleCalendarServlet extends HttpServlet  {
public class GoogleCalendarServlet extends AbstractAppEngineAuthorizationCodeServlet {
	private static final Logger LOG = Logger.getLogger(GoogleCalendarServlet.class.getName());
	private static final long serialVersionUID = 1L;

	static final String APP_NAME = "My Google Calendar";
	static final String GWT_MODULE_NAME = "calendar";
	  
	private static final String HOST_DOMAIN = "google.com";
//	private static final String HOST_DOMAIN = "forecs.net";
	
	private final ICalendarService calendarService;
	
	@Inject
	public GoogleCalendarServlet(ICalendarService calendarService) {
		this.calendarService = calendarService;
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		String scheme = request.getScheme() + "://";
//	    String serverName = request.getServerName();
//	    String serverPort = (request.getServerPort() == 80) ? "" : ":" + request.getServerPort();
//	    String contextPath = request.getContextPath();
//	    String servletPath = request.getServletPath();
//	    String pathInfo = (request.getPathInfo() == null) ? "" : request.getPathInfo();
//	    String queryString = (request.getQueryString() == null) ? "" : "?" + request.getQueryString();
//	    
//	    LOG.warning(scheme + serverName + serverPort + contextPath + servletPath + pathInfo + queryString);
	    
		process(request, response);
	}

	protected void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String domainName = request.getParameter(PARAM.DOMAINNAME);
		String userId = request.getParameter(PARAM.USERID);
		
//		Users user = getCurrentUser();
//		if (user == null) {
//			LOG.warning("require login");
//		} else {
//			LOG.warning("userId : " + user.getUserId());
//		}
		if (StringUtils.isBlank(domainName) || StringUtils.isBlank(userId)) {
			throw new IOException("Require user id and domain name.");
		}
		
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			com.google.api.services.calendar.Calendar clientCalendar = OAuthUtils.loadCalendarClient();
			if (clientCalendar != null) {
				System.out.println(clientCalendar.getApplicationName());
				System.out.println(clientCalendar.events().list("hyeunwoo.shim@forecs.net").execute().getItems());
			}
			CalendarList calendarList = clientCalendar.calendarList().list().execute();
			
			

			for (CalendarListEntry entry : calendarList.getItems()) {
				LOG.info("=== CALENDAR ID[" + entry.getId() +"] TimeZone["+entry.getTimeZone()+"]Access Role["+entry.getAccessRole()+"]");
				//LOG.info("*** Location ***" + entry.getLocation());
				LOG.info("***********************************************");
				
				//if (!"owner".equals(entry.getAccessRole())) { continue; }
				
				Calendars coconutUserCalendar = new Calendars();
				
				coconutUserCalendar.setKey(KeyUtil.createCalendarKey(userId, entry.getId()));
				coconutUserCalendar.setCreator(userId);
				coconutUserCalendar.setId(entry.getId());
				coconutUserCalendar.setSummary(entry.getSummary());
				coconutUserCalendar.setLocation(entry.getLocation());
				coconutUserCalendar.setHostDomain(HOST_DOMAIN);
				if (StringUtils.isNotEmpty(entry.getDescription())) {
					coconutUserCalendar.setDescription(new Text(entry.getDescription()));
				}
				coconutUserCalendar.setOwner(userId);
				coconutUserCalendar.setPrimary(entry.getPrimary()==null?false:entry.getPrimary());
				coconutUserCalendar.setUserId(userId);
				if (StringUtils.isNotEmpty(entry.getSummary())) {
					coconutUserCalendar.setTitle("My Calendar : " + entry.getSummary());
				} else {
					coconutUserCalendar.setTitle("My Calendar");
				}
				coconutUserCalendar.setAccessRole(CalendarAccessRole.valueOf(entry.getAccessRole()));
				coconutUserCalendar.setTimeZone(entry.getTimeZone());
				
				com.google.api.services.calendar.model.Events googleEvents = clientCalendar.events().list(entry.getId()).execute();
				List<Events> coconutEventList = GoogleCalendarConverter.listEventsFromCalendar(null, null, null, googleEvents);
				net.fortuna.ical4j.model.Calendar iCalendar = CalendarConverter.convertEventToCalendar(coconutEventList, entry.getId());
				
				coconutUserCalendar.setEvents(new Text(iCalendar.toString()));
				
				calendarService.insertOrUpdateCalendar(coconutUserCalendar);
				// String eventsStr = gson.toJson(coconutEventList);
				//LOG.warning(iCalendar);
			}
			UserService userService = UserServiceFactory.getUserService();
			response.setContentType("text/html");
		    response.setCharacterEncoding(CommonProperty.UTF_8);
			response.setStatus(200);
			
			String thisURI = request.getScheme() + "://" +   // "http" + "://
		             request.getServerName() +       // "myhost"
		             ":" +                           // ":"
		             request.getServerPort() +       // "8080"
		             request.getRequestURI() +       // "/people"
		             "?" +                           // "?"
		             request.getQueryString();       // "lastname=Fox&age=30"

			String userName = null;
			
			if (request.getUserPrincipal() == null) {
				User user = userService.getCurrentUser();
				if (user != null) {
					userName = user.getEmail();
					
//					LOG.warning(user.getAuthDomain());
//					LOG.warning(user.getEmail());
//					LOG.warning(user.getNickname());
//					LOG.warning(user.getUserId());
//					LOG.warning(user.getClass());
				}
			} else {
				userName = request.getUserPrincipal().getName();
			}

			PrintWriter writer = response.getWriter();
			if (userName != null) {
				writer.println("<div class=\"header\"><b>" + userName + "</b> | "
			        + "<a href=\"" + userService.createLogoutURL(thisURI)
			        + "\">Log out</a> | <a href='javascript:self.close();'>CLOSE(X)</href></div>");
			} else {
				writer.println("<p>Please <a href=\"" +
                        userService.createLoginURL(thisURI) +
                        "\">sign in</a>.</p>");
			}
			try {
				MemcacheManager.removeAllMemcache(Events.class, EventType.PRIVATE.toString());
			} catch (Exception ex) { }
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.warning(ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}

	@Override
	protected String getRedirectUri(HttpServletRequest req) throws ServletException, IOException {
		return OAuthUtils.getRedirectUri(req);
	}

	@Override
	protected AuthorizationCodeFlow initializeFlow() throws IOException {
		return OAuthUtils.newFlow();
	}
}
