package net.forecs.coconut.servlet.calendar;

import java.io.IOException;
import java.io.PrintWriter;
import net.forecs.coconut.common.Logger;

import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.util.security.OAuthUtils;

import com.google.api.client.auth.oauth2.AuthorizationCodeFlow;
import com.google.api.client.extensions.appengine.auth.oauth2.AbstractAppEngineAuthorizationCodeServlet;
import com.google.api.services.calendar.model.CalendarList;
import com.google.api.services.calendar.model.CalendarListEntry;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Events;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;


@Deprecated
@Singleton
public class MyCalendarServlet extends AbstractAppEngineAuthorizationCodeServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG = Logger.getLogger(MyCalendarServlet.class.getName());
	private static final String APP_NAME = "APPL";
	private static final String GWT_MODULE_NAME = "calendar";

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding(CommonProperty.UTF_8);
		PrintWriter writer = response.getWriter();
		writer.println("<!doctype html><html><head>");
		writer.println("<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">");
		writer.println("<title>" + APP_NAME + "</title>");
		writer.println("<link type=\"text/css\" rel=\"stylesheet\" href=\""
				+ GWT_MODULE_NAME + ".css\">");
		writer.println("<script type=\"text/javascript\" language=\"javascript\" "
				+ "src=\""
				+ GWT_MODULE_NAME
				+ "/"
				+ GWT_MODULE_NAME
				+ ".nocache.js\"></script>");
		writer.println("</head><body>");
		UserService userService = UserServiceFactory.getUserService();
		writer.println("<div class=\"header\"><b>"
				+ request.getUserPrincipal().getName()
				+ "</b> | "
				+ "<a href=\""
				+ userService.createLogoutURL(request.getRequestURL()
						.toString())
				+ "\">Log out</a> | "
				+ "<a href=\"http://code.google.com/p/google-api-java-client/source/browse"
				+ "/calendar-appengine-sample?repo=samples\">See source code for "
				+ "this sample</a></div>");
		writer.println("<div id=\"main\"/>");
		writer.println("</body></html>");

		try {
			com.google.api.services.calendar.Calendar client = OAuthUtils
					.loadCalendarClient();
			CalendarList calendarList = client.calendarList().list().execute();

			LOG.info(String.valueOf(calendarList.getItems().size()));

			LOG.info(client.events().list("koosup.kim@forecs.net").execute()
					.toString());
			LOG.info(client.events().list("yonkyoung.park@forecs.net")
					.execute().toString());

			for (CalendarListEntry entry : calendarList.getItems()) {
				LOG.info("******************************************************************");
				Events myEvents = client.events().list(entry.getId()).execute();

				LOG.info("*** CALENDAR ID ***" + entry.getId());
				LOG.info("*** Location ***" + entry.getLocation());
				LOG.info("*** Time zone ***" + entry.getTimeZone());
				LOG.info("******************************************************************");
				for (Event event : myEvents.getItems()) {
					LOG.info("-----------------------------------------------");
					LOG.info("=ID=" + event.getId());
					LOG.info("=UID=" + event.getICalUID());
					LOG.info("=START=" + event.getStart());
					LOG.info("=IsAllDay="
							+ event.getStart().getDate().isDateOnly());
					LOG.info("=END=" + event.getEnd());
					LOG.info("=Description=" + event.getDescription());
					LOG.info("=Summary=" + event.getSummary());
					LOG.info("=Location=" + event.getLocation());
					LOG.info("=Class=" + event.getClassInfo());
					LOG.info("=COLOR=" + event.getColorId());
					LOG.info("=KIND=" + event.getKind());
					LOG.info("=Status=" + event.getStatus());
					LOG.info("=Transparency=" + event.getTransparency());
					LOG.info("=visibility=" + event.getVisibility());
					LOG.info("=Sequence=" + event.getSequence());
					LOG.info("=RecurrenceEventId="
							+ event.getRecurringEventId());
					LOG.info("=Recurrence=" + event.getRecurrence());
					if (event.getRecurrence() != null) {
						for (String rec : event.getRecurrence()) {
							LOG.info("   -REC ITEM:" + rec);
						}
					}
					LOG.info("-----------------------------------------------");
				}
				LOG.info("==================================================================");
				display(entry);
			}

		} catch (Exception ex) {
		}

		// com.google.api.services.calendar.Calendar.CalendarList.List
		// listRequest =
		// client.calendarList().list();
		// listRequest.setFields("items(id,summary)");
		// CalendarList feed = listRequest.execute();
		// ArrayList<GwtCalendar> result = new ArrayList<GwtCalendar>();
		// if (feed.getItems() != null) {
		// for (CalendarListEntry entry : feed.getItems()) {
		// result.add(new GwtCalendar(entry.getId(), entry.getSummary()));
		// }
		// }

	}

	static void display(CalendarListEntry entry) {
		LOG.info("ID: " + entry.getId());
		LOG.info("Summary: " + entry.getSummary());
		if (entry.getDescription() != null) {
			LOG.info("Description: " + entry.getDescription());
		}
	}

	@Override
	protected String getRedirectUri(HttpServletRequest req)
			throws ServletException, IOException {
		return OAuthUtils.getRedirectUri(req);
	}

	@Override
	protected AuthorizationCodeFlow initializeFlow() throws IOException {
		return OAuthUtils.newFlow();
	}
}