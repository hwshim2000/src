package net.forecs.coconut.servlet;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.endpoint.common.IAttachmentService;
import net.forecs.coconut.entity.attachment.Attachments;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@Singleton
public class AttachmentDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = -6268729001242716690L;
	private static final Logger LOG = Logger.getLogger(AttachmentDownloadServlet.class.getName());
	
	private static final int downloads = 30; 
	private final IAttachmentService attachmentService;
	
	@Inject
	public AttachmentDownloadServlet(IAttachmentService attachmentService) {
		this.attachmentService = attachmentService;
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) {
		String prevNamespace = NamespaceManager.get();
		try {
			req.setCharacterEncoding(CommonProperty.UTF_8);
			
			String key = req.getParameter(PARAM.KEY);
			String domainId = req.getParameter(PARAM.DOMAINID);
			String[] attachmentIds = req.getParameterValues(PARAM.ATTACHMENTID);
			
			if (!MemcacheManager.isValidAccessKey(key, domainId)) {
				res.getWriter().print("Invalid key or download time was expired.");
				throw new Exception("Invalid key or download time was expired.");
			}
			
			if (StringUtils.isBlank(domainId) || attachmentIds == null || attachmentIds.length == 0) {
				res.getWriter().print("DomainId and attachmentId should not be empty.");
				throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage("DomainId and attachmentId should not be empty."));
			}
			
			List<String> attachmentIdList = new ArrayList<String>();
			for (String attachIds : attachmentIds) {
				if (StringUtils.isBlank(attachIds)) { continue; }
				String[] attachIdArr = StringUtils.split(attachIds, ",; ");
				for (String attachmentId : attachIdArr) {
					if (StringUtils.isBlank(attachmentId)) { continue; }
					if (!attachmentIdList.contains(attachmentId)) { attachmentIdList.add(attachmentId); }
				}
			}
			
			if (attachmentIdList.size() > downloads) {
				res.getWriter().print("Can not exceeds " + downloads + " of numbers of download.");
				throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Can not exceeds " + downloads + " of numbers of download."));
			}
			
			Key taskKey = KeyFactory.stringToKey(domainId);
			String domainName = taskKey.getNamespace();
			NamespaceManager.set(domainName);
			
			res.setContentType("Content-type: text/zip");
			res.setHeader("Content-Transfer-Encoding", "binary;");
			res.setHeader("Pragma", "no-cache;");
			res.setHeader("Expires", "-1;");
			String date = CalendarUtil.toString(new Date(), "yyyyMMddHHmmss");
			String downloadName = String.format("attachment; filename=\"%s\"", URLEncoder.encode(domainName+"-"+date+".zip", CommonProperty.UTF_8));
			res.setHeader("Content-Disposition", downloadName);
			
			
			List<Attachments> attachments = attachmentService.listAttachments(attachmentIdList);
			
			downloadForZip(res, attachments);
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	private void downloadForZip(HttpServletResponse res, List<Attachments> attachments) throws IOException {
		ZipOutputStream zos = null;
		
		try {
			zos = new ZipOutputStream(new BufferedOutputStream(res.getOutputStream()));
		
			for (Attachments attachment : attachments) {
				final InputStream is = getInputStream(attachment.getFilePath());
				addZipEntry(zos, StringUtils.substringAfter(attachment.getFilePath(), "/"), is);
//				String path = String.format("final/%s/%s", CalendarUtil.toString(attachment.getCreated()), attachment.getFileName());
//				addZipEntry(zos, path, is);
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (zos != null) { zos.close(); }
		}
	}
	
	private void addZipEntry(ZipOutputStream zos, String zipFileName, final InputStream is) throws IOException {
		if (is == null) { return; }
		try {
			zos.putNextEntry(new ZipEntry(zipFileName));
			int read;
		    byte[] buffer = new byte[8192];
	        while ((read = is.read(buffer)) != -1) {
	           zos.write(buffer, 0, read);
	        }
	        zos.closeEntry();
		} finally {
			if (is != null) { is.close(); }
		}
	}
	
	private final InputStream getInputStream(String filePath) {
		try {
			String downloadUrl = attachmentService.getDownloadUrl(filePath, 180);
	    	URL url = new URL(downloadUrl);  
			return url.openStream();
		} catch (final MalformedURLException e) {
//			System.out.println("malformed url error!");
	    } catch (final IOException e) {
//	    	System.out.println("image doesn't exists!");
	    } catch (final Exception e) {
//	    	System.out.println(e.getMessage());
	    }
		
	    return null;
	}
	
	public static void main(String[] args) throws Exception {
		String str = StringUtils.substringAfter("/aa/bb/cc/dd.txt", "/");
		System.out.println(str);
		
	}
}