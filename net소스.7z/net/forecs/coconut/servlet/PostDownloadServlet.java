package net.forecs.coconut.servlet;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.FileTypes;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IAttachmentService;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import au.com.bytecode.opencsv.CSVWriter;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


@Singleton
public class PostDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 597782781085709467L;
	private static final Logger LOG = Logger.getLogger(PostDownloadServlet.class.getName());
	
	private final ITaskService taskService; 
	private final ITaskTimelineService taskTimelineService;
	private final IUserService userService;
	private final IAttachmentService attachmentService;

	private final static String TASK_SHEET_NAME = "Task";
	private final static String TASK_CHECKLIST_SHEET_NAME = "TaskChecklist";
	private final static String TASK_LABEL_SHEET_NAME = "TaskLabel";
	private final static String TASK_MEMBER_SHEET_NAME = "TaskMember";
	private final static String TASK_ATTACHMENT_SHEET_NAME = "TaskAttachment";
	
	private final static String TIMELINE_SHEET_NAME = "TaskTimelines";
	
	private final static String[] TASK_HEADERS = new String[] {"제목", "단계", "업무내용", "위키(업무현황)", "소유자", "중요도", "달력표시여부", "시작일", "목표일", "완료일", "작성일", "수정일" };
	private final static String[] TASK_CHECKLIST_HEADERS = new String[] {"체크내용", "확인여부"};
	private final static String[] TASK_LABEL_HEADERS = new String[] {"레이블", "색상"};
	private final static String[] TASK_MEMBER_HEADERS = new String[] {"아이디", "이름", "닉네임", "이메일"};
	private final static String[] TASK_ATTACHMENT_HEADERS = new String[] {"파일명", "사이즈", "경로"};
	
	private final static String[] TIMELINE_HEADERS = new String[] {"포스트", "댓글", "내용", "작성일", "작성자", "최종코멘트/수정일" };
	
	@Inject
	public PostDownloadServlet(ITaskService taskService, ITaskTimelineService taskTimelineService, IUserService userService, IAttachmentService attachmentService) {
		this.taskService = taskService;
		this.taskTimelineService = taskTimelineService;
		this.userService = userService;
		this.attachmentService = attachmentService;
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) {
		String prevNamespace = NamespaceManager.get();
		try {
			req.setCharacterEncoding(CommonProperty.UTF_8);
			
			String key = req.getParameter(PARAM.KEY);
			String taskId = req.getParameter(PARAM.TASKID);
 
			if (!MemcacheManager.isValidAccessKey(key, taskId)) {
				res.getWriter().print("Invalid key or download time was expired.");
				throw new Exception("Invalid key or download time was expired.");
			}
			
			String format = req.getParameter(PARAM.FORMAT);
			String ext = FileTypes.XLSX;
			if (StringUtils.isNotBlank(format)) {
				ext = format;
			}
			
			if (StringUtils.isBlank(taskId)) {
				res.getWriter().print("TaskId should not be empty.");
				throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage("TaskId should not be empty."));
			}
			
			Key taskKey = KeyFactory.stringToKey(taskId);
			String domainName = taskKey.getNamespace();
			
			NamespaceManager.set(domainName);
			
			Tasks task = taskService.getTasksDetail(taskId);
			List<String> taskIdList = new ArrayList<String>();
			taskIdList.add(taskId);
			
			Map<String, Users> users = domainUsers();
			QueryResult<TaskTimelines> queryResult = taskTimelineService.queryTaskTimelines(null, null, null, taskIdList, null, SortType.lastCommented, SortDirection.DESC);
			List<TaskTimelines> timelineList = queryResult.getResultList();
			
			if (ext.equalsIgnoreCase(FileTypes.CSV) || ext.equalsIgnoreCase(FileTypes.TSV)) {
				res.setCharacterEncoding(CommonProperty.MS949);
			} else {
				res.setCharacterEncoding(CommonProperty.UTF_8);
			}
			String mimeType = "application/octet-stream";
			if (StringUtils.equalsIgnoreCase(ext, "zip")) {
				mimeType = "Content-type: text/zip";
			}
			res.setContentType(mimeType);
			res.setHeader("Content-Transfer-Encoding", "binary;");
			res.setHeader("Pragma", "no-cache;");
			res.setHeader("Expires", "-1;");

			String date = CalendarUtil.toString(new Date(), "yyyyMMddHHmmss");
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", URLEncoder.encode(taskId+"-"+date+"."+ext, CommonProperty.UTF_8));
			res.setHeader(headerKey, headerValue);
			
			if (StringUtils.equalsIgnoreCase(ext, FileTypes.XLSX) || StringUtils.equalsIgnoreCase(ext, FileTypes.XLS)) {
				this.downloadForSSF(res, task, timelineList, users, ext);
			} else if (StringUtils.equalsIgnoreCase(ext, FileTypes.CSV) || StringUtils.equalsIgnoreCase(ext, FileTypes.TSV)) {
				this.downloadForCSV(res, task, timelineList, users, ext);
			} else if (StringUtils.equalsIgnoreCase(ext, "zip")) {
				downloadForZip(res, task, timelineList, users, ext);
			} else {
				downloadForJSON(res, task, timelineList, users, ext);
			}
			//LOG.info(fileName + " written successfully on disk.");
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@SuppressWarnings("resource")
	private void downloadForSSF(HttpServletResponse res, Tasks task, List<TaskTimelines> timelineList, Map<String, Users> users, String ext) throws Exception {
		// Blank workbook
		Workbook workbook = null;
		OutputStream os = null;
		try {
			os = res.getOutputStream();
			if (ext.equalsIgnoreCase(FileTypes.XLSX)) {
				workbook = new XSSFWorkbook();
			} else {
				workbook = new HSSFWorkbook();
			}
			
			// TASK
			Sheet taskSheet = workbook.createSheet(TASK_SHEET_NAME);
			setWorksheetData(taskSheet, makeTaskData(task, users));
			// CHECKLIST
			Sheet checklistSheet = workbook.createSheet(TASK_CHECKLIST_SHEET_NAME);
			setWorksheetData(checklistSheet, makeTaskChecklistData(task.getChecklists()));
			// LABEL
			Sheet labelSheet = workbook.createSheet(TASK_LABEL_SHEET_NAME);
			setWorksheetData(labelSheet, makeTaskLabelData(task.getLabels()));
			// MEMBER
			Sheet memberSheet = workbook.createSheet(TASK_MEMBER_SHEET_NAME);
			setWorksheetData(memberSheet, makeTaskMemberData(task.getMembers()));
			// ATTACHMENT
			Sheet attachmentSheet = workbook.createSheet(TASK_ATTACHMENT_SHEET_NAME);
			setWorksheetData(attachmentSheet, makeTaskAttachmentData(task.getAttachments()));
			// TIMELINE
			Sheet postSheet = workbook.createSheet(TIMELINE_SHEET_NAME);
			setWorksheetData(postSheet, makeTimelineData(timelineList, users));
			
			workbook.write(os);
		} catch (Exception ex) {
			throw ex;
		} finally {
			if (os != null) { os.close(); }
		}
	}
	
	private void downloadForCSV(HttpServletResponse res, Tasks task, List<TaskTimelines> timelineList, Map<String, Users> users, String ext) throws IOException {
		CSVWriter cw = null;
		try {
			if (ext.equalsIgnoreCase(FileTypes.CSV)) {
				cw = new CSVWriter(res.getWriter(), FileTypes.DELIMITER_COMMA, '"');
			} else {
				cw = new CSVWriter(res.getWriter(), FileTypes.DELIMITER_TAB , '"');
			}
			
			// TASK
			setCSWData(cw, makeTaskData(task, users));
			// CHECKLIST
			setCSWData(cw, makeTaskChecklistData(task.getChecklists()));
			// LABEL
			setCSWData(cw, makeTaskLabelData(task.getLabels()));
			// MEMBER
			setCSWData(cw, makeTaskMemberData(task.getMembers()));
			// ATTACHMENT
			setCSWData(cw, makeTaskAttachmentData(task.getAttachments()));
			// TIMELINE
			setCSWData(cw, makeTimelineData(timelineList, users));
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (cw != null) { cw.close(); }
		}
	}
	
	private void downloadForZip(HttpServletResponse res, Tasks task, List<TaskTimelines> timelineList, Map<String, Users> users, String ext) throws IOException {
		ZipOutputStream zos = null;
		
		try {
			zos = new ZipOutputStream(new BufferedOutputStream(res.getOutputStream()));
			
			// TASK
			addZipEntry(zos, "task.txt", makeTaskData(task, users));
			// CHECKLIST
			addZipEntry(zos, "checklist.txt", makeTaskChecklistData(task.getChecklists()));
			// LABEL
			addZipEntry(zos, "taskLabel.txt", makeTaskLabelData(task.getLabels()));
			// MEMBER
			addZipEntry(zos, "member.txt", makeTaskMemberData(task.getMembers()));
			// ATTACHMENT
			addZipEntry(zos, "attachment.txt", makeTaskAttachmentData(task.getAttachments()));
			// TIMELINE
			addZipEntry(zos, "timeline.txt", makeTimelineData(timelineList, users));
			
			for (Attachments attachment : task.getAttachments()) {
				final InputStream is = getInputStream(attachment.getFilePath());
				addZipEntry(zos, StringUtils.substringAfter(attachment.getFilePath(), "/"), is);
//				String path = String.format("final/%s/%s", CalendarUtil.toString(attachment.getCreated()), attachment.getFileName());
//				addZipEntry(zos, path, is);
			}
			
			for (TaskTimelines timeline : timelineList) {
				for (Attachments attachment : timeline.getAttachments()) {
					final InputStream is = getInputStream(attachment.getFilePath());
					addZipEntry(zos, StringUtils.substringAfter(attachment.getFilePath(), "/"), is);
//					String path = String.format("post/%s/%s", CalendarUtil.toString(attachment.getCreated()), attachment.getFileName());
//					addZipEntry(zos, path, is);
				}
				for (Images image : timeline.getImages()) {
					final InputStream is = getInputStream(image.getFilePath());
					addZipEntry(zos, StringUtils.substringAfter(image.getFilePath(), "/"), is);
//					String path = String.format("image/%s/%s", CalendarUtil.toString(image.getCreated()), image.getFileName());
//					addZipEntry(zos, path, is);
				}
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (zos != null) { zos.close(); }
		}
	}
	private void addZipEntry(ZipOutputStream zos, String zipFileName, List<String[]> data) throws IOException {
		StringBuilder sb = new StringBuilder();
		for (String[] arr : data) {
			sb.append(StringUtils.join(arr, "\t"));
			sb.append('\n');
		}
		zos.putNextEntry(new ZipEntry(zipFileName));
		zos.write(sb.toString().getBytes(CommonProperty.UTF_8));
		
		zos.closeEntry();
	}
	private void addZipEntry(ZipOutputStream zos, String zipFileName, final InputStream is) throws IOException {
		if (is == null) { return; }
		try {
			zos.putNextEntry(new ZipEntry(zipFileName));
			int read;
		    byte[] buffer = new byte[8192];
	        while ((read = is.read(buffer)) != -1) {
	           zos.write(buffer, 0, read);
	        }
	        zos.closeEntry();
		} finally {
			if (is != null) { is.close(); }
		}
	}
	private void downloadForJSON(HttpServletResponse res, Tasks task, List<TaskTimelines> timelineList, Map<String, Users> users, String ext) throws IOException {
		PrintWriter writer = null;
		try {
			writer = res.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			Map<String, Object> objs = new TreeMap<String, Object>();
			objs.put("task", task);
			objs.put("timeline", timelineList);
			String jsonStr = mapper.writeValueAsString(objs);
//			Gson gson = new GsonBuilder().setPrettyPrinting().create();
//			String jsonStr = gson.toJson(timelineList);
			
			writer.print(jsonStr);
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (writer != null) { writer.close(); }
		}
	}
	
	private Map<String, Users> domainUsers() {
		Map<String, Users> users = new HashMap<String, Users>();
		try {
			List<Users> userList = userService.listUsers(true, false);
			for (Users user : userList) {
				users.put(user.getUserId(), user);
			}
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
		}
		return users;
	}
	
	private List<String[]> makeTaskData(Tasks task, Map<String, Users> users) {
		List<String[]> data = new ArrayList<String[]>();
		data.add(TASK_HEADERS);
		//"제목", "단계", "업무내용", "위키(업무현황)", "소유자", "중요도", "달력표시여부", "시작일", "목표일", "종료일", "작성일", "수정일"
		String title = task.getTitle();
		String stage = task.getTaskStage().toString();
		String description = "";
		if (task.getDescription() != null && StringUtils.isNotBlank(task.getDescription().getValue())) {
			description = task.getDescription().getValue();
		}
		String wiki = "";
		if (task.getWiki() != null && StringUtils.isNotBlank(task.getWiki().getValue())) {
			description = task.getWiki().getValue();
		}
		String owner = CommonService.getDisplayUserName(users.get(task.getOwner()));
		String importance = task.getImportance();
		String displayInCalendar = task.getDisplayInCalendarYN();
		String startDate = CalendarUtil.toString(task.getStartDate());
		String dueDate = CalendarUtil.toString(task.getDueDate());
		String completeDate = CalendarUtil.toString(task.getCompleteDate());
		String created = CalendarUtil.toString(task.getCreated());
		String modified = CalendarUtil.toString(task.getModified());
		
		data.add(new String[] { title, stage, description, wiki, owner, importance, displayInCalendar, startDate, dueDate, completeDate, created, modified });
		return data;
	}
	private List<String[]> makeTaskChecklistData(List<TaskChecklists> checklists) {
		List<String[]> data = new ArrayList<String[]>();
		data.add(TASK_CHECKLIST_HEADERS);
		for (TaskChecklists check : checklists) {
			data.add(new String[] { check.getTitle(), check.getCheckYN() });
		}
		return data;
	}
	private List<String[]> makeTaskLabelData(List<TaskLabels> labels) {
		List<String[]> data = new ArrayList<String[]>();
		data.add(TASK_LABEL_HEADERS);
		for (TaskLabels label : labels) {
			data.add(new String[] { label.getLabel(), label.getColor() });
		}
		return data;
	}
	private List<String[]> makeTaskMemberData(List<Users> members) {
		List<String[]> data = new ArrayList<String[]>();
		data.add(TASK_MEMBER_HEADERS);
		for (Users user : members) {
			String userName = CommonService.getDisplayUserName(user);
			data.add(new String[] { user.getId(), userName, user.getNickName(), user.getEmail() });
		}
		return data;
	}
	private List<String[]> makeTaskAttachmentData(List<Attachments> attachments) {
		List<String[]> data = new ArrayList<String[]>();
		data.add(TASK_ATTACHMENT_HEADERS);
		for (Attachments attachment : attachments) {
			data.add(new String[] { attachment.getFileName(), String.valueOf(attachment.getFileSize()), attachment.getFilePath() });
		}
		return data;
	}
	
	private List<String[]> makeTimelineData(List<TaskTimelines> timelineList, Map<String, Users> users) {
		List<String[]> data = new ArrayList<String[]>();
		data.add(TIMELINE_HEADERS);
		for (TaskTimelines timeline : timelineList) {
			String userName = CommonService.getDisplayUserName(users.get(timeline.getCreator()));
			String created = CalendarUtil.toString(timeline.getCreated());
			String commented = CalendarUtil.toString(timeline.getLastCommented());
			String description = "";
			if (timeline.getDescription() != null && StringUtils.isNotBlank(timeline.getDescription().getValue())) {
				description = timeline.getDescription().getValue();
			}
			
			data.add(new String[] { "TIMELINE", "", description, created, userName, commented });
			
			for (TaskTimelineComments comment : timeline.getComments()) {
				userName = CommonService.getDisplayUserName(users.get(comment.getCreator()));
				created = CalendarUtil.toString(comment.getCreated());
				String modified = CalendarUtil.toString(comment.getModified());
				description = "";
				if (comment.getDescription() != null && StringUtils.isNotBlank(comment.getDescription().getValue())) {
					description = timeline.getDescription().getValue();
				}
				
				data.add(new String[] { "", "COMMENT", description, created, userName, modified });
			}
		}
		return data;
	}
	private void setWorksheetData(Sheet sheet, List<String[]> data) {
		int rownum = 0;
		for (String[] strArr : data) {
			Row row = sheet.createRow(rownum++);
			int cellnum = 0;
			for (String str : strArr) {
				Cell cell = row.createCell(cellnum++);
				cell.setCellValue(str);
			}
		}
	}
	
	private void setCSWData(CSVWriter cw, List<String[]> data) {
		cw.writeAll(data);
		cw.writeNext(new String[] {""});
	}
	
	private final InputStream getInputStream(String filePath) {
		try {
			String downloadUrl = attachmentService.getDownloadUrl(filePath, 180);
	    	URL url = new URL(downloadUrl);  
			return url.openStream();
		} catch (final MalformedURLException e) {
//			System.out.println("malformed url error!");
	    } catch (final IOException e) {
//	    	System.out.println("image doesn't exists!");
	    } catch (final Exception e) {
//	    	System.out.println(e.getMessage());
	    }
		
	    return null;
	}
}