package net.forecs.coconut.servlet;

import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.common.IImageService;
import net.forecs.coconut.endpoint.common.ImageService;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

@Singleton
public class ImageInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 5487629922314550177L;
	private static final Logger LOG = Logger.getLogger(ImageInfoServlet.class.getName());

	private final IImageService imageService;
	@Inject
	public ImageInfoServlet(IImageService imageService) {
		this.imageService = imageService;
	}
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		process(req, res);
	}
	private void process(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		try {
			String bucketName = req.getParameter(FLD.bucket);
			String filePath = req.getParameter(FLD.filePath);
			String sizeStr = req.getParameter(FLD.imageSize);
			String secretKey = req.getParameter(FLD.secretKey);
		
			if (!StringUtils.equals(ImageService.SECRET_KEY, secretKey)) { return; }
			
			if (StringUtils.isNotBlank(bucketName) && StringUtils.isNotBlank(filePath)) {
				int imageSize = 0;
				if (StringUtils.isNumeric(sizeStr)) { imageSize = Integer.valueOf(sizeStr); }
				Map<String, Object> metaMap = imageService.getImageInfo(bucketName, filePath, imageSize);
				ObjectMapper om = new ObjectMapper();
				String responseStr = om.writeValueAsString(metaMap);
				
				res.setContentType("application/json");
			    res.setCharacterEncoding(CommonProperty.UTF_8);
			    res.getWriter().write(responseStr);
				res.setStatus( HttpServletResponse.SC_OK );
			}
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		}
	}
}
