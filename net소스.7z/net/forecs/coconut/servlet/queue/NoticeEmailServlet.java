package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.email.SendEmail;

import org.apache.commons.lang.StringUtils;

import edu.emory.mathcs.backport.java.util.Arrays;

@Deprecated
@Singleton
public class NoticeEmailServlet extends HttpServlet {
	private static final long serialVersionUID = 7981261553318278031L;
	private static final Logger LOG = Logger.getLogger(NoticeEmailServlet.class.getName());

	private final SendEmail sendMail;
	private final int sendSize = 100;

	@Inject
	public NoticeEmailServlet(SendEmail sendMail) {
		this.sendMail = sendMail;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String[] emails = req.getParameterValues(PARAM.EMAIL);
			String subject = req.getParameter(PARAM.SUBJECT);
			String body = req.getParameter(PARAM.BODY);
			
			if (emails != null && emails.length > 0 && StringUtils.isNotBlank(subject) && StringUtils.isNotBlank(body)) { 
				@SuppressWarnings("unchecked")
				List<String> emailList = Arrays.asList(emails);
			
				for (int fromIndex = 0; fromIndex < emailList.size(); fromIndex = fromIndex + sendSize) {
					int toIndex = fromIndex + sendSize;
					if (toIndex >= emailList.size()) { toIndex = emailList.size(); }
					sendMail.send(emailList.subList(fromIndex, toIndex), subject, body);
				}
			}
		} catch (Exception ex) {
			LOG.warning("[Send Email]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
	
//	@SuppressWarnings("unused")
//	@Deprecated
//	private void processOld(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		try {
//			String domainName = req.getParameter(PARAM.DOMAINNAME);
////			String email = req.getParameter(PARAM.EMAIL);
//			String subject = req.getParameter(PARAM.SUBJECT);
//			String message = req.getParameter(PARAM.MESSAGE);
//			String templateName = req.getParameter(PARAM.TEMPLATENAME);
//			
//			templateName = CommonProperty.NOTICE_EMAIL_TEMPLATE;
//			
//			List<String> emailList = adminService.getDomainUserEmails(domainName);
////			List<Users> userList = userService.listUsers(null, null, true);
//			
//			//if (StringUtils.isNotBlank(email) && StringUtils.isNotBlank(subject) && StringUtils.isNotBlank(message)) { 
//			if (emailList != null && emailList.size() > 0 && StringUtils.isNotBlank(subject) && StringUtils.isNotBlank(message)) {
//				HashMap<String, Object> messageMap = new HashMap<String, Object>();
//				messageMap.put(PARAM.DOMAINNAME, domainName);
//				messageMap.put(PARAM.MESSAGE, message);
//				messageMap.put(PARAM.USERNAME, "cocoworks 사용자님");
//				messageMap.put(PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL);
//				
//				String htmlBody = message;
//				if (StringUtils.isNotEmpty(templateName)) {
//					htmlBody = docBuilder.createDocumentString(templateName, messageMap);
//				}
//				
//				for (int fromIndex = 0; fromIndex < emailList.size(); fromIndex = fromIndex + sendSize) {
//					int toIndex = fromIndex + sendSize;
//					sendMail.send(emailList.subList(fromIndex, toIndex), subject, htmlBody);
//				}
////				sendMail.send(emailList, subject, htmlBody);
//			}
//		} catch (Exception ex) {
//			logger.warning("[Send Email]"+ex.getMessage());
//			throw new IOException(ex.getMessage());
//		}
//		resp.setStatus( HttpServletResponse.SC_OK );
//	}
}