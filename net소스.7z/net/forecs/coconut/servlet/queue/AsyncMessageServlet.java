package net.forecs.coconut.servlet.queue;

import javax.inject.Singleton;
import javax.servlet.http.HttpServlet;

@Deprecated
@Singleton
public class AsyncMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 965606606495592367L;
//	private static final Logger LOG = Logger.getLogger(AsyncMessageServlet.class.getName());
//
//	private final ISyncService syncService;
//	
//	@Inject
//	public AsyncMessageServlet(ISyncService syncService) {
//		this.syncService = syncService;
//	}
//	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
//		process(req, resp);
//	}
//	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
//		process(req, resp);
//	}
//
//	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		try {
//			String domainId = req.getParameter(PARAM.DOMAINID);
//			String message = req.getParameter(PARAM.MESSAGE);
//			String secCode = req.getParameter(PARAM.SECCODE);
//			
//			String verCode = SecurityUtils.getMD5(domainId+message);
//			if (!verCode.equals(secCode)) { throw new Exception("invalid code!"); }
//			
//			syncService.syncMessage(domainId, message);
//		} catch (Exception ex) {
//			LOG.warning("[ASync Message] "+ex.getMessage());
//			throw new IOException(ex.getMessage());
//		}
//		resp.setStatus( HttpServletResponse.SC_OK );
//	}
}
