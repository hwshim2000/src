package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.common.ActivityService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.freemarker.DocBuilder;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.ibm.icu.text.MessageFormat;


@Deprecated
@Singleton
public class NotificationEmailServlet extends HttpServlet {
	private static final long serialVersionUID = -4724538372619146643L;
	private static final Logger LOG = Logger.getLogger(NotificationEmailServlet.class.getName());
	
	private final IActivityService activityService;
	private final IBoardService boardService;
	
	private final SendEmail sendMail;
	private final DocBuilder docBuilder;
	
	@Inject
	public NotificationEmailServlet(IActivityService activityService,
			IBoardService boardService,
			SendEmail sendMail,
			DocBuilder docBuilder) {
		this.activityService = activityService;
		this.boardService = boardService;
		this.sendMail = sendMail;
		this.docBuilder = docBuilder;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String prevNamespace = NamespaceManager.get();
		
		try {
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String email = req.getParameter(PARAM.EMAIL);
			//String subject = "[cocoworks] 새로운 알림 메일 입니다.";
			String[] activityArr = req.getParameterValues(PARAM.ACTIVITIES);
			//String templateName = req.getParameter(PARAM.TEMPLATENAME);
			String userId = req.getParameter(PARAM.USERID);
			String userName = req.getParameter(PARAM.USERNAME);
			
			NamespaceManager.set(domainName);
			Messages message = Messages.localeMessages(userId, WRAPPED_CHAR_TYPE.EMAIL);
		
			String subject = message.getMessage(Messages.NOTIFICATION_SUBJECT, domainName);
			String templateName = MessageFormat.format(CommonProperty.NOTIFICATION_EMAIL_TEMPLATE, message.getLocale());
			
			List<Activities> activityList = makeActivityMessage(activityArr, message);
			
			if (StringUtils.isNotBlank(email) && StringUtils.isNotBlank(subject) && activityList != null && activityList.size() > 0) {
				HashMap<String, Object> documentMap = new HashMap<String, Object>();
				TreeMap<String, List<Activities>> activityMap = getActivityMap(activityList, message);
				List<String> activityMapKeys = getKeyListCustomOrdered(activityMap);
				
				documentMap.put(PARAM.DOMAINNAME, domainName);
				//documentMap.put(PARAM.ACTIVITIES, activityList);
				documentMap.put(PARAM.ACTIVITYMAP, activityMap);
				documentMap.put(PARAM.ACTIVITYMAPKEYS, activityMapKeys);
				documentMap.put(PARAM.USERNAME, userName);
				documentMap.put(PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL);
				documentMap.put(PARAM.LOCALE, message.getLocale().toString());
				
				String htmlBody = docBuilder.createDocumentString(templateName, documentMap);
				
				sendMail.send(email, subject, htmlBody);
//				if (SmtpSendEMail.domains.contains(domainName)) {
//					SmtpSendEMail.send(email, subject, htmlBody);
//				} else {
//					sendMail.send(email, subject, htmlBody);
//				}
			}
		} catch (Exception ex) {
			LOG.warning("[Notification Email]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
		
		resp.setStatus( HttpServletResponse.SC_OK );
	}
	
//	private Messages getLocaleMessages(String userId) {
//		UserSetting userSetting = null;
//		if (StringUtils.isNotBlank(userId)) {
//			userSetting = userSettingService.getUserSetting(userId, CommonProperty.USER_UI_SETTING_NAME);
//		}
//		
//		return new Messages(userSetting);
//	}
	
	private List<Activities> makeActivityMessage(String[] activityArr, Messages message) {
		if (activityArr == null) { return null; }
		
		//--> hyeunwoo.shim 2015-10-07 batch query
		Set<String> activityIds = new HashSet<String>(Arrays.asList(activityArr));
		List<Activities> activityList = activityService.batchListActivities(activityIds);
		if (activityList != null) {
			for (Activities activity : activityList) {
				activity.setMessage(message.getMessage(activity));
			}
		}
		
//		List<Activities> activityList = new ArrayList<Activities>();
//		for (String activityId : activityArr) {
//			Activities activity = activityService.getActivities(activityId);
//			
//			activity.setMessage(message.getMessage(activity));
//			if (activity != null) { activityList.add(activity); }
//		}
		//<--

		return activityList;
	}
	
	private TreeMap<String, List<Activities>> getActivityMap(List<Activities> activityList, Messages message) throws Exception {
		try {
			TreeMap<String, List<Activities>> activityMap = new TreeMap<String, List<Activities>>();
			
			Set<String> boardIds = new HashSet<String>();
			
			for (Activities activity : activityList) {
				String boardId = activity.getBoardId();
				if (StringUtils.isNotBlank(boardId)) {
					boardIds.add(boardId);
				}
			}
			
			Map<String, Boards> boardMap = boardService.batchMapBoards(boardIds);
			
			for (Activities activity : activityList) {
				String boardId = activity.getBoardId();
				String key = null;
				if (StringUtils.isEmpty(boardId)) {
					key = message.getSourceMessage(Messages.NOTIFICATION_COMMON);
					//key = activity.getActivityKind().toString();
				} else {
					Boards board = boardMap.get(boardId);
					if (board == null) { key = boardId; }
					else { key = board.getTitle(); }
				}
				
				// 사용하지 않는 summary field에다가  @UserName, @UserName, @UserName, .... 형식으로 저장
				activity.setSummary(ActivityService.getMentionedUserNames(activity));
				
				if (!activityMap.containsKey(key)) { activityMap.put(key, new ArrayList<Activities>()); }
				activityMap.get(key).add(activity);
			}
			
			return activityMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<String> getKeyListCustomOrdered(TreeMap<String, List<Activities>> activityMap) {
		List<String> keyList = new ArrayList<String>(activityMap.keySet());
		
		if (keyList.contains(Messages.NOTIFICATION_COMMON)) {
			keyList.remove(Messages.NOTIFICATION_COMMON);
			keyList.add(0, Messages.NOTIFICATION_COMMON);
		}
		return keyList;
	}
}
