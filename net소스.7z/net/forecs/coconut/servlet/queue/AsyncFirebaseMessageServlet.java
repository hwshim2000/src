package net.forecs.coconut.servlet.queue;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.endpoint.channel.FirebaseChannel;

@Singleton
public class AsyncFirebaseMessageServlet extends HttpServlet {
	private static final long serialVersionUID = -7750285457386827031L;
	private static final Logger LOG = Logger.getLogger(AsyncFirebaseMessageServlet.class.getName());
	
	@Inject
	public AsyncFirebaseMessageServlet() {
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String syncMessage = req.getParameter(PARAM.MESSAGE);
			String channelKey = req.getParameter(PARAM.CHANNELKEY);
			
			FirebaseChannel.getInstance().sendFirebaseMessage(channelKey, syncMessage);
		} catch (Exception ex) {
			LOG.warning("[ASync Message] "+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}