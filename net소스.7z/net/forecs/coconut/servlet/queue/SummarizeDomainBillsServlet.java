package net.forecs.coconut.servlet.queue;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.endpoint.billing.IBillingService;

@Singleton
public class SummarizeDomainBillsServlet extends HttpServlet {
	/**
	 * @Description :
	 * @Author      : hyeunwoo.shim@forecs.net 2017. 6. 14.
	 */
	private static final long serialVersionUID = -7682482614812970386L;

	private static final Logger LOG = Logger.getLogger(SummarizeDomainBillsServlet.class.getName());

	private final IBillingService billingService;
	
	@Inject
	public SummarizeDomainBillsServlet(IBillingService billingService) {
		this.billingService = billingService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String domainName = null;
		try {
			domainName = req.getParameter(PARAM.DOMAINNAME);
			billingService.summarizeUsageForBills(domainName, null);
			
			resp.setStatus( HttpServletResponse.SC_OK );
		} catch (Exception ex) {
			LOG.warning(String.format("[Summarize %s domain bills] %s", domainName, ex.getMessage()));
			throw new IOException(ex.getMessage());
		}
	}
}
