package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.endpoint.board.IAlarmService;


@Singleton
public class AlarmPushServlet extends HttpServlet {
	private static final long serialVersionUID = 5414626721845025583L;
	private static final Logger LOG = Logger.getLogger(AlarmPushServlet.class.getName());

	private final IAlarmService alarmService;
	
	@Inject
	public AlarmPushServlet(IAlarmService alarmService) {
		this.alarmService = alarmService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String eventId = req.getParameter(PARAM.EVENTID);
			String alarmDateTimeMillis = req.getParameter(PARAM.ALARMDATETIMEMILLS);
			String eventTypeStr = req.getParameter(PARAM.EVENTTYPE);
			EventType eventType = null;
			if (StringUtils.isNotBlank(eventTypeStr)) {
				eventType = EventType.valueOf(eventTypeStr);
			}
			
			if (EventType.ANNIVERSARY.equals(eventType)) {
				String userId = req.getParameter(PARAM.USERID);
				AnniversaryType anniversaryType = AnniversaryType.valueOf(req.getParameter(PARAM.ANNIVERSARYTYPE));
				String eventDateTimeMillis = req.getParameter(PARAM.EVENTDATETIMEMILLS);
				alarmService.pushAnniversaryAlarms(domainName, userId, anniversaryType, eventDateTimeMillis, alarmDateTimeMillis);
			} else {
				alarmService.pushAlarms(domainName, eventId, alarmDateTimeMillis);
			}
		} catch (Exception ex) {
			LOG.warning("[Push Alarm]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
