package net.forecs.coconut.servlet.queue;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.endpoint.billing.IBillingService;

@Singleton
public class PaymentDomainServlet extends HttpServlet {
	private static final long serialVersionUID = -8962796959353410061L;
	private static final Logger LOG = Logger.getLogger(PaymentDomainServlet.class);

	private final IBillingService billingService;
	
	@Inject
	public PaymentDomainServlet(IBillingService billingService) {
		this.billingService = billingService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String domainName = null;
		try {
			domainName = req.getParameter(PARAM.DOMAINNAME);
			billingService.scheduledPayments(domainName);
			
			resp.setStatus( HttpServletResponse.SC_OK );
		} catch (Exception ex) {
			LOG.warning(String.format("[Payment domain - %s] %s", domainName, ex.getMessage()));
			throw new IOException(ex.getMessage());
		}
	}
}
