package net.forecs.coconut.servlet.queue;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.PrepareType;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.dashboard.IDashboardService;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.KeyFactory;

@Singleton
public class PrepareInitDataServlet extends HttpServlet {
	private static final long serialVersionUID = 6469647174867243533L;

	private static final Logger LOG = Logger.getLogger(PrepareInitDataServlet.class);

	private final IUserService userService;
	private final IBoardService boardService;
	private final IDashboardService dashboardService;
	
	@Inject
	public PrepareInitDataServlet(IUserService userService, IBoardService boardService, IDashboardService dashboardService) {
		this.userService = userService;
		this.boardService = boardService;
		this.dashboardService = dashboardService; 
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String userId = req.getParameter(PARAM.USERID);
			String boardId = req.getParameter(PARAM.BOARDID);
			String prepareType = req.getParameter(PARAM.PREPARETYPE);
			
			if (StringUtils.isNotBlank(domainName) && StringUtils.isNotBlank(userId)) {
				String id = KeyFactory.stringToKey(userId).getName();
				if (StringUtils.isBlank(prepareType) || StringUtils.equals(PrepareType.USERSTATUS, prepareType)) {
					userService.prepareUserStatus(domainName, userId);
					LOG.warning("[PREPARE-USERSTATUS] preapred user status data. " + id);
				}
				
				if (StringUtils.isBlank(prepareType) || StringUtils.equals(PrepareType.BOARDS, prepareType)) {
					if (StringUtils.isNotBlank(boardId)) {
						boardService.prepareBoardItems(domainName, boardId, userId);
						LOG.warning("[PREPARE-BOARD] prepared board data. " + id + "(boardId=" + boardId+ ")");
					} else {
						if (MainModule.serviceMode) {
							boardService.prepareBoardItemsWithTaskQueue(domainName, userId);
						} else {
							boardService.prepareBoardItems(domainName, userId);
						}
						LOG.warning("[PREPARE-BOARD] Prepared boards data. " + id);
					}
				}
				
				if (StringUtils.isBlank(prepareType) || StringUtils.equals(PrepareType.TASKTIMELINES, prepareType)) {
					dashboardService.prepareMyDashboardTimelines(domainName, userId, null, 30, null, null);
					LOG.warning("[PREPARE-TIMELINE] prepared task timelines data." + id);
				}
			}
		} catch (Exception ex) {
			LOG.warning("[Error Prepare] "+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
