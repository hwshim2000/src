package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.endpoint.channel.INotificationService;

@Singleton
public class PrepareNotificationServlet extends HttpServlet {
	private static final long serialVersionUID = 6467537144710764067L;
	private static final Logger LOG = Logger.getLogger(NotificationExecuteServlet.class.getName());

	private final INotificationService notificationService;
	
	@Inject
	public PrepareNotificationServlet(INotificationService notificationService) {
		this.notificationService = notificationService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {	
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String activityId = req.getParameter(PARAM.ACTIVITYID);
			String[] userIdArr = req.getParameterValues(PARAM.USERID);
			
			List<String> notificationUserIds = null;
			if (userIdArr != null && userIdArr.length > 0) {
				notificationUserIds = Arrays.asList(userIdArr);
			}
			notificationService.prepareNotification(domainName, activityId, notificationUserIds);
		} catch (Exception ex) {
			LOG.warning("[Prepare Notification] "+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
