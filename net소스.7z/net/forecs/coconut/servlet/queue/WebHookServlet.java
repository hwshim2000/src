package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.endpoint.channel.IWebHookService;

@Singleton
public class WebHookServlet extends HttpServlet {
	private static final long serialVersionUID = -2250590357853805526L;
	private static final Logger LOG = Logger.getLogger(WebHookServlet.class.getName());
	
	private IWebHookService webHookService;
	
	@Inject
	public WebHookServlet(IWebHookService webHookService) {
		this.webHookService = webHookService;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String webHookId = req.getParameter(PARAM.WEBHOOKID);
			String activityId = req.getParameter(PARAM.ACTIVITYID);
			
			webHookService.executeHook(webHookId, activityId);
			
			resp.setStatus( HttpServletResponse.SC_OK );
		} catch (Exception ex) {
			LOG.warning("[WebHook Message] "+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
	}
}
