package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.freemarker.DocBuilder;
import net.forecs.coconut.servlet.BaseServlet;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.emory.mathcs.backport.java.util.Arrays;


@Singleton
public class SendEmailServlet extends BaseServlet {
	private static final long serialVersionUID = 7981261553318278031L;
	private static final Logger LOG = Logger.getLogger(SendEmailServlet.class.getName());

	private final SendEmail sendMail;
	private final DocBuilder docBuilder;
	private final static int sendSize = 100;

	@Inject
	public SendEmailServlet(IUserDao<? extends IUser> userDao, SendEmail sendMail, DocBuilder docBuilder) {
		super(userDao);
		this.sendMail = sendMail;
		this.docBuilder = docBuilder;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String[] emails = req.getParameterValues(PARAM.EMAIL);
			String subject = req.getParameter(PARAM.SUBJECT);
			String body = req.getParameter(PARAM.BODY);
			String templateName = req.getParameter(PARAM.TEMPLATENAME);
			String templateName2 = req.getParameter(PARAM.TEMPLATENAME2);		// add 20170808
			String messages = req.getParameter(PARAM.MESSAGES);
					
//			LOG.warning("SendEmailServlet process - body : " + body );					// viper
//			LOG.warning("SendEmailServlet process - body len: " + body.length() );		// viper
			
			if (emails != null && emails.length > 0 && StringUtils.isNotBlank(subject)) { 
				@SuppressWarnings("unchecked")
				List<String> emailList = Arrays.asList(emails);
				String htmlBody = body;
				
				if ( StringUtils.isNotEmpty(templateName2))	{
//					LOG.warning("SendEmailServlet step template2 : " + templateName2 );		// viper
					try {		
						/////////////////////////////////////////////////////////////////////////////////
//						아래의 코드로 작성해도 동작이 됨. 초기 버전
//						String htmlMessage = getView(templateName2,
//								PARAM.BODY, body,
//								PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL
//								);
						/////////////////////////////////////////////////////////////////////////////////
						
						/////////////////////////////////////////////////////////////////////////////////
						// 아래이 코드는 NotificationEmailServlet.java 코드를 활용한 것임
						HashMap<String, Object> documentMap = new HashMap<String, Object>();
						documentMap.put(PARAM.BODY, body);
						documentMap.put(PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL);
						String htmlMessage = docBuilder.createDocumentString(templateName2, documentMap);
						
						LOG.warning("SendEmailServlet step template2 : " + htmlMessage );		// viper
						for (int fromIndex = 0; fromIndex < emailList.size(); fromIndex = fromIndex + sendSize) {
							int toIndex = fromIndex + sendSize;
							if (toIndex > emailList.size()) 
								{ toIndex = emailList.size(); }
							sendMail.send(emailList.subList(fromIndex, toIndex), subject, htmlMessage);
						}

//			            LOG.info("Admin Notice email sent to " + emails );

			        } catch (Exception e) {
			            LOG.severe("Error sending mail to " + emails + ": " + e.getMessage());
			        }
					
				}
				else {
					if (StringUtils.isNotEmpty(templateName)) {
						Map<String, Object> messageMap = null;
						if (StringUtils.isNotBlank(messages)) {
							// 아래의 내용으로 보면 messages는 json형식으로 전달 된 데이터 임
							// 예) {"title":"제목임","description":"내용임","시간":"12:12"} ObjectMapper를 참조해야 함.
							ObjectMapper om = new ObjectMapper();
							messageMap = om.readValue(messages, new TypeReference<HashMap<String, String>>() {});
						}
						
						htmlBody = docBuilder.createDocumentString(templateName, messageMap);
					}
					if (StringUtils.isNotBlank(htmlBody)) {
						for (int fromIndex = 0; fromIndex < emailList.size(); fromIndex = fromIndex + sendSize) {
							int toIndex = fromIndex + sendSize;
							if (toIndex > emailList.size()) { toIndex = emailList.size(); }
							sendMail.send(emailList.subList(fromIndex, toIndex), subject, htmlBody);
						}
					}
				}
			}
		} catch (Exception ex) {
			LOG.warning("[Send Email]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
