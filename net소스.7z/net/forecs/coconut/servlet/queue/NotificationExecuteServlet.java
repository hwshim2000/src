package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.endpoint.channel.INotificationService;


@Singleton
public class NotificationExecuteServlet extends HttpServlet {
	private static final long serialVersionUID = -3031633317639896423L;
	private static final Logger LOG = Logger.getLogger(NotificationExecuteServlet.class.getName());

	private final INotificationService notificationService;
	
	@Inject
	public NotificationExecuteServlet(INotificationService notificationService) {
		this.notificationService = notificationService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String userId = req.getParameter(PARAM.USERID);
			String notificationSettingId = req.getParameter(PARAM.NOTIFICATIONSETTINGID);
			
			notificationService.executeNotification(userId, notificationSettingId);
		} catch (Exception ex) {
			LOG.warning("[Execute Notification]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
