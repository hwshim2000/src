package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import java.util.HashMap;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.freemarker.DocBuilder;

import org.apache.commons.lang.StringUtils;

import com.ibm.icu.text.MessageFormat;

@Deprecated
@Singleton
public class SendLostIdEmailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = Logger.getLogger(SendLostIdEmailServlet.class.getName());

	private final SendEmail sendMail;
	private final DocBuilder docBuilder;
	
	@Inject
	public SendLostIdEmailServlet(SendEmail sendMail, DocBuilder docBuilder) {
		this.sendMail = sendMail;
		this.docBuilder = docBuilder;
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String userName = req.getParameter(PARAM.USERNAME);
			String id = req.getParameter(PARAM.ID);
			String userId = req.getParameter(PARAM.USERID);
			String email = req.getParameter(PARAM.EMAIL);
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			//String subject = String.format("[cocoworks] %s님의 ID 정보입니다.", userName);
			
			Messages message = Messages.localeMessages(userId, WRAPPED_CHAR_TYPE.EMAIL);
			String subject = message.getMessage(Messages.SENDLOSTIDEMAIL_SUBJECT, userName);
			String templateName = MessageFormat.format(CommonProperty.SENDLOSTID_EMAIL_TEMPLATE, message.getLocale());
			
			if (StringUtils.isNotBlank(email) 
					&& StringUtils.isNotBlank(userName)
					&& StringUtils.isNotBlank(id)
					&& StringUtils.isNotBlank(domainName)) {
				HashMap<String, Object> messageMap = new HashMap<String, Object>();
				
				messageMap.put(PARAM.ID, id);
				messageMap.put(PARAM.USERNAME, userName);
				messageMap.put(PARAM.DOMAINNAME, domainName);
				messageMap.put(PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL);
				messageMap.put(PARAM.LOCALE, message.getLocale().toString());
						
				String htmlBody = docBuilder.createDocumentString(templateName, messageMap);
				
				sendMail.send(email, subject, htmlBody);
//				if (SmtpSendEMail.domains.contains(domainName)) {
//					SmtpSendEMail.send(email, subject, htmlBody);
//				} else {
//					sendMail.send(email, subject, htmlBody);
//				}
			}
		} catch (Exception ex) {
			LOG.warning("[LostId Email]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
