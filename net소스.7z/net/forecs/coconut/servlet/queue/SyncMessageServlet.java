package net.forecs.coconut.servlet.queue;

import javax.inject.Singleton;
import javax.servlet.http.HttpServlet;

@Deprecated
@Singleton
public class SyncMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 2464453761284765003L;
//	private static final Logger LOG = Logger.getLogger(SyncMessageServlet.class.getName());
//
//	private final ISyncService syncService;
//	
//	@Inject
//	public SyncMessageServlet(ISyncService syncService) {
//		this.syncService = syncService;
//	}
//	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
//		//process(req, resp);
//	}
//	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
//		//process(req, resp);
//	}

//	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		try {
//			String syncTimeStr = req.getParameter(PARAM.SYNCTIME);
//			String domainName = req.getParameter(PARAM.DOMAINNAME);
//			String longPollingTime = req.getParameter(PARAM.LONGPOLLINGTIME);
//			
//			Date syncTime = new Date();
//			long pollingTime = 3000L;
//			
//			if (StringUtils.isNotBlank(syncTimeStr)) {
//				long time = Long.parseLong(syncTimeStr);
//				syncTime = new Date(time); 
//				//Calendar cal = DatatypeConverter.parseDateTime(syncDateStr);	// ISO date string 일 경우
//				//syncDate = cal.getTime();
//			}
//			
//			if (StringUtils.isNotBlank(longPollingTime)) {
//				pollingTime = Long.parseLong(longPollingTime);
//			} else {
//				pollingTime = getLongPollingTime(syncTime);
//			}
//			
//			Activities activity = syncService.getSyncMessage(domainName, syncTime);
//			
//			if (activity != null) {
//				ObjectMapper om = new ObjectMapper();
//				resp.getWriter().write(om.writeValueAsString(activity));
//			} else {
//				try { Thread.sleep(pollingTime); } catch (Exception ex) {};		
//			}
//			
//			resp.setStatus( HttpServletResponse.SC_OK );
//		} catch (Exception ex) {
//			LOG.warning("[Sync Message] "+ex.getMessage());
//			throw new IOException(ex.getMessage());
//		}
//	}
//	
//	private static long getLongPollingTime(Date syncTime) {
//		Date curr = new Date();
//		long diff = curr.getTime() - syncTime.getTime();
//		if (diff < 10000) return diff;
//		else return 10000;
////		if (diff < 1000) return 1000;
////		else if (diff < 2000) return 2000;
////		else if (diff < 3000) return 3000;
////		else if (diff < 5000) return 5000;
////		else return 10000;
//	}
}
