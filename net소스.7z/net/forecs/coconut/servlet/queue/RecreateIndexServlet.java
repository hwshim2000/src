package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.IndexKind;
import net.forecs.coconut.endpoint.admin.IDataService;

@Singleton
public class RecreateIndexServlet extends HttpServlet {
	private static final long serialVersionUID = 5781230809771220669L;
	private static final Logger LOG = Logger.getLogger(RecreateIndexServlet.class.getName());
	private final IDataService dataService; 
	
	@Inject
	public RecreateIndexServlet(IDataService dataService) {
		this.dataService = dataService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String domainName = req.getParameter(PARAM.DOMAINNAME);
		String kind = req.getParameter(PARAM.KIND);
		
		try {
			if (StringUtils.isBlank(domainName) && StringUtils.isBlank(kind)) {
				dataService.recreateAllIndex();
			} else if (StringUtils.isNotBlank(domainName) && StringUtils.isBlank(kind)) {
				dataService.recreateNamespaceIndex(domainName);
			} else if (StringUtils.isNotBlank(domainName) && StringUtils.isNotBlank(kind)) {
				IndexKind indexKind = IndexKind.valueOf(kind);
				switch (indexKind) {
					//case UserIndex : recreateUserIndex(namespace); break;
					case TaskIndex : dataService.recreateTaskIndex(domainName); break;
					case EventIndex : dataService.recreateEventIndex(domainName); break;
					case NoticeIndex : dataService.recreateNoticeIndex(domainName); break;
					case TimelineIndex : dataService.recreateTimelineIndex(domainName); break;
					case CommentIndex : dataService.recreateCommentIndex(domainName); break;
					//case ChecklistHistoryIndex : recreateChecklistHistoryIndex(namespace); break;
					//case ChecklistIndex : recreateChecklistIndex(namespace); break;
					case AttachmentIndex : dataService.recreateAttachmentIndex(domainName); break;
					default : break;
				}
			}
		} catch (Exception ex) {
			LOG.warning(String.format("[recreateIndex] %s-%s : ", domainName, kind, ex.getMessage()));
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
