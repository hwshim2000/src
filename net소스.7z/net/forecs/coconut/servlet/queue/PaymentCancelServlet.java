package net.forecs.coconut.servlet.queue;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.billing.CancelInfo;
import net.forecs.coconut.endpoint.billing.IamportManager;
import net.forecs.coconut.servlet.BaseServlet;

@Singleton
public class PaymentCancelServlet extends BaseServlet {
	private static final long serialVersionUID = -1187859517429850218L;
	private static final Logger LOG = Logger.getLogger(PaymentCancelServlet.class);

	@Inject
	public PaymentCancelServlet() {
		super(null);
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String domainName = null;
		try {
			domainName = getParameter(req, PARAM.DOMAINNAME);
			String merchant_uid = getParameter(req, PARAM.MERCHANT_UID);
			Integer amount = getIntParameter(req, PARAM.AMOUNT);
			String reason = getParameter(req, PARAM.REASON);
			
			IamportManager.cancelIamportPayment(new CancelInfo(merchant_uid, amount, reason));
			
			resp.setStatus( HttpServletResponse.SC_OK );
		} catch (Exception ex) {
			LOG.warning(String.format("[PaymentCancelServlet- %s] %s", domainName, ex.getMessage()));
			throw new IOException(ex.getMessage());
		}
	}
}