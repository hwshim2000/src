package net.forecs.coconut.servlet.queue;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.endpoint.admin.IUsageService;

@Singleton
public class SurveyDomainUsageServlet extends HttpServlet {
	private static final long serialVersionUID = 208400099930243826L;
	private static final Logger LOG = Logger.getLogger(SurveyDomainUsageServlet.class.getName());

	private final IUsageService usageService;
	
	@Inject
	public SurveyDomainUsageServlet(IUsageService usageService) {
		this.usageService = usageService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String domainName = null;
		try {
			domainName = req.getParameter(PARAM.DOMAINNAME);
			usageService.surveyUsage(domainName);
			
			resp.setStatus( HttpServletResponse.SC_OK );
		} catch (Exception ex) {
			LOG.warning(String.format("[Survey %s doman usage] ", domainName, ex.getMessage()));
			throw new IOException(ex.getMessage());
		}
	}
}
