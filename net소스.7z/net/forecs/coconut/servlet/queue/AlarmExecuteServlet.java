package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.endpoint.board.IAlarmService;


@Singleton
public class AlarmExecuteServlet extends HttpServlet {
	private static final long serialVersionUID = -3459974509642831029L;
	private static final Logger LOG = Logger.getLogger(AlarmExecuteServlet.class.getName());

	private final IAlarmService alarmService;
	
	@Inject
	public AlarmExecuteServlet(IAlarmService alarmService) {
		this.alarmService = alarmService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String eventTypeStr = req.getParameter(PARAM.EVENTTYPE);
			EventType eventType = null;
			if (StringUtils.isNotBlank(eventTypeStr)) {
				eventType = EventType.valueOf(eventTypeStr);	
			}
			
			alarmService.executeAlarms(domainName, eventType);	
		} catch (Exception ex) {
			LOG.warning("[Execute Alarm]"+ex.getMessage());
			throw new IOException(ex.getMessage());
		}
		resp.setStatus( HttpServletResponse.SC_OK );
	}
}
