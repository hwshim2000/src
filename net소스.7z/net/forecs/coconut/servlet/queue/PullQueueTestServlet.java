package net.forecs.coconut.servlet.queue;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskHandle;
import com.google.appengine.api.taskqueue.TaskOptions;

@Singleton
@SuppressWarnings("serial")
public class PullQueueTestServlet extends HttpServlet {
	//private static final Logger LOG = Logger.getLogger(PullQueueTestServlet.class.getName());
	
	@Inject
	public PullQueueTestServlet() {
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}
	
	public void process(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		/*
		 * Pull Queue 대략 설명
		 * pull queue 정의 : queue.xml mode 를 pull로 tjfwjd
		 * 정의한 queue에 task 등록
		 * countdownMills :  지정 시간 만큼 지난 후에 queue에서 꺼낼 수 있도록 설정
		 * leaseTasks : 지정시간만큼 후에 지정갯수 만큼 quque에서 꺼내온다. (이때 지정시간이 지나기 전까지는 다른 프로세스에서 꺼낼 수 없다.)
		 * 꺼낸 quque를 삭제하지 않으면 빌려온 시간이 지나면  또다시 꺼내서 사용할 수 있다.
		 * 일회성 동작이면 꺼낸 task를 삭제하면 된다.
		 */
		try {
			Queue q = QueueFactory.getQueue("pull-queue");
			q.add(TaskOptions.Builder.withMethod(TaskOptions.Method.PULL).countdownMillis(1000).payload("payload1").tag("tag1"));
			q.add(TaskOptions.Builder.withMethod(TaskOptions.Method.PULL).payload("payload2").tag("tag"));
			q.add(TaskOptions.Builder.withMethod(TaskOptions.Method.PULL).payload("payload3").tag("tag"));
			q.add(TaskOptions.Builder.withMethod(TaskOptions.Method.PULL).payload("payload4").tag("tag"));
			q.add(TaskOptions.Builder.withMethod(TaskOptions.Method.PULL).payload("payload5").tag("tag"));
			
			List<TaskHandle> tasks = q.leaseTasks(1000, TimeUnit.MILLISECONDS, 100);
			
			for (TaskHandle handle : tasks) {
				System.out.println(handle.getName());
				System.out.println(handle.getTag());
				System.out.println(handle.getQueueName());
				System.out.println(new String(handle.getPayload()));
		
				System.out.println("----------------------------------------------");
			}
			Thread.sleep(2000);
			
			System.out.println("222222222222222222----------------------------------------------");
			List<TaskHandle> tasks2 = q.leaseTasks(1000, TimeUnit.MILLISECONDS, 100);
			for (TaskHandle handle : tasks2) {
				System.out.println(handle.getName());
				System.out.println(handle.getTag());
				System.out.println(handle.getQueueName());
				System.out.println(new String(handle.getPayload()));
		
				System.out.println("----------------------------------------------");
			}
			
			System.out.println("333333333333333333----------------------------------------------");
			List<TaskHandle> task3 = q.leaseTasks(3600, TimeUnit.SECONDS, 100);
			for (TaskHandle handle : task3) {
				System.out.println(handle.getName());
				System.out.println(handle.getTag());
				System.out.println(handle.getQueueName());
				System.out.println(new String(handle.getPayload()));
		
				System.out.println("----------------------------------------------");
			}
			
			q.deleteTask(tasks);
		} catch (Exception ex) {
			throw new ServletException(ex.getMessage());
		}
	}
}
