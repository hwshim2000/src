package net.forecs.coconut.servlet.queue;

import javax.inject.Singleton;
import javax.servlet.http.HttpServlet;

@Deprecated
@Singleton
public class InvitationEmailServlet extends HttpServlet {
	private static final long serialVersionUID = -2338176016439176636L;
//	private static final Logger LOG = Logger.getLogger(InvitationEmailServlet.class.getName());
//
//	private final SendEmail sendMail;
//	private final DocBuilder docBuilder;
//	
//	@Inject
//	public InvitationEmailServlet(SendEmail sendMail, DocBuilder docBuilder) {
//		this.sendMail = sendMail;
//		this.docBuilder = docBuilder;
//	}
//	
//	public void doGet(HttpServletRequest req, HttpServletResponse resp)	throws IOException, ServletException {
//		process(req, resp);
//	}
//	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
//		process(req, resp);
//	}
//
//	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		try {
//			// TODO : 추후 다국어 처리가 필요할경우에 구현
//			@SuppressWarnings("unused")
//			String domainName = req.getParameter(PARAM.DOMAINNAME);
//			String email = req.getParameter(PARAM.EMAIL);
//			String subject = req.getParameter(PARAM.SUBJECT);
//			String[] messages = req.getParameterValues(PARAM.MESSAGES);
//			String templateName = CommonProperty.INVITATION_EMAIL_TEMPLATE;
//			
//			if (StringUtils.isNotBlank(email) && StringUtils.isNotBlank(subject) && messages != null && messages.length > 0) { 
//				HashMap<String, Object> messageMap = new HashMap<String, Object>();
//				messageMap.put(PARAM.MESSAGES, Arrays.asList(messages));
//				
//				String htmlBody = docBuilder.createDocumentString(templateName, messageMap);
//				
//				sendMail.send(email, subject, htmlBody);
////				if (SmtpSendEMail.domains.contains(domainName)) {
////					SmtpSendEMail.send(email, subject, htmlBody);
////				} else {
////					sendMail.send(email, subject, htmlBody);
////				}
//			}
//		} catch (Exception ex) {
//			LOG.warning("[Invitation Email]"+ex.getMessage());
//			throw new IOException(ex.getMessage());
//		}
//		resp.setStatus( HttpServletResponse.SC_OK );
//	}
}
