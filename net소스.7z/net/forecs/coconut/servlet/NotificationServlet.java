package net.forecs.coconut.servlet;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.ServletUtil;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;

@Deprecated
@Singleton
public class NotificationServlet extends HttpServlet {
	private static final Logger LOG = Logger.getLogger(NotificationServlet.class.getName());
	private static final long serialVersionUID = -947237273882318969L;

	@Inject
	public NotificationServlet() {
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}
	
	public void process(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
	    getServletInfo(req, resp);
	}
	
	@SuppressWarnings("rawtypes")
	public static void getServletInfo(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		req.setCharacterEncoding(CommonProperty.UTF_8);;
		
		LOG.warning("================================= QUERY STRING =============================");
		LOG.warning("[QueryString]"+req.getQueryString());
		
		Enumeration hds = req.getHeaderNames();
		if (hds != null) {
			LOG.warning("================================= HEADERS =============================");
			while(hds.hasMoreElements()) {
				Object obj = hds.nextElement();
				String header = (String)obj;
				String value = req.getHeader(header);
				
				LOG.warning("["+ header + "] " + value);
			}
		}
		
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			LOG.warning("================================= COOKIES =============================");
			for(Cookie cookie : cookies) {
				LOG.warning(String.format("[Cookie-%s] %s %s %s %s %d", cookie.getName(), cookie.getValue(), cookie.getDomain(), cookie.getPath(),cookie.getSecure(), cookie.getMaxAge()) );
			}
		}
		
		Enumeration en = req.getParameterNames();
		if (en != null) {
			LOG.warning("=================================PARAMS ==============================");
			while(en.hasMoreElements()) {
				Object obj = en.nextElement();
				String param = (String)obj;
				String value = req.getParameter(param);
				
				LOG.warning("["+ param + "] " + value);
			}
		}
		
		Enumeration enAttr = req.getAttributeNames();
		if (enAttr != null) {
			LOG.warning("=================================ATTRS ===============================");
			while(enAttr.hasMoreElements()) {
				Object obj = enAttr.nextElement();
				String attr = (String)obj;
				Object value = req.getAttribute(attr);
				
				LOG.warning("["+ attr + "] " + value);
			}
		}
		
	    String msg = req.getParameter("item");
	    if (StringUtils.isNotBlank(msg)) {
	    	LOG.warning("=================================ITEMS ===============================");
			JSONObject jObj = new JSONObject(); // this parses the json
			Iterator it = jObj.keys(); //gets all the keys
	
			System.out.println(msg);
			while(it.hasNext())
			{
			    String key = (String)it.next(); // get key
			    Object o = jObj.get(key); // get value
			    LOG.warning(key +" = "+o);
			}
	    }
	    
	    try {
		    LOG.warning("=================================READER ==============================");
		    //Map<String, Object> contentsMap = ServletUtil.getContentsMap(req);
		  //System.out.println(contentsMap);
		    String message = ServletUtil.getContents(req);
		    LOG.warning(message);
	    } catch (Exception ex) {
	    	LOG.warning(ex.getMessage());
	    }
	}
}
