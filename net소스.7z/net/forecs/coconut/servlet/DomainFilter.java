package net.forecs.coconut.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.account.AccountServiceAPI;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.security.SsoServiceManager;
import net.forecs.coconut.security.TokenContext;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;


public class DomainFilter implements Filter {
//	private static final Logger LOG = Logger.getLogger(DomainFilter.class.getName());
	
	@Override
	public void init(FilterConfig config) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		assert (request instanceof HttpServletRequest);

		HttpServletRequest httpRequest = (HttpServletRequest)request;
		String requestUri = httpRequest.getRequestURI();
		
		boolean applyDomain = false;
		if (requestUri.startsWith(API.SPI_ROOT+API.PACKAGE_ROOT)		
				&& !requestUri.contains(AccountServiceAPI.class.getSimpleName())) {
			applyDomain = true;
		} else {
			applyDomain = false;	// Namespace handled within API
		}
		
		if (applyDomain) {
			String domainName = NamespaceManager.get();
			if (StringUtils.isEmpty(domainName)) {
				Users user = CommonService.getCurrentUser();
				if (user != null) {
					domainName = user.getDomainName();
					NamespaceManager.set(domainName);
				}
			}
		}
//		HttpServletResponse httpResponse = (HttpServletResponse)response;
//		try (TokenContext context = TokenContext.create(httpRequest, httpResponse)) {
//			chain.doFilter(request, response);
//		}
		// TODO : dongbu
		HttpServletResponse httpResponse = (HttpServletResponse)response;
		MultiReadHttpServletRequest multiReadRequest = new MultiReadHttpServletRequest(httpRequest);
		SsoServiceManager.set(multiReadRequest, httpResponse);
		try (TokenContext context = TokenContext.create(multiReadRequest, httpResponse)) {
			chain.doFilter(multiReadRequest, httpResponse);
		}
	}

	@Override
	public void destroy() {
	}
}