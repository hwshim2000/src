package net.forecs.coconut.servlet;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.shiro.ShiroUtils;

import com.google.common.collect.Maps;


//
//  I originally used FreemarkerServlet, but it didn't work with HTTPS for some reason.
//
@Singleton
public class FreemarkerServlet extends BaseServlet {
	private static final long serialVersionUID = -1829858672416694020L;
	static final Logger LOG = Logger.getLogger(FreemarkerServlet.class.getName());

    @Inject
    public FreemarkerServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        showView(response, uri, mapping(request));
    }

	private Map<String, Object> mapping(HttpServletRequest request) {
		Map<String, Object> map = Maps.newHashMap();
		IUser user = ShiroUtils.getCurrentUser();
		if (user != null) {
			map.put(PARAM.ID, user.getId());
			map.put("userType", userType(user));
		} else {
			map.put("userType", "UNKNOWN");
		}
		map.put("RequestParameters", requestParameters(request));
		return map;
	}

    private static String userType(IUser user) {
        String hash = user.getPassword();
        return (hash == null) ? "SOCIAL" : "COCONUT";
    }

    private static Map<String, String> requestParameters(HttpServletRequest request) {
        Map<String, String> map = Maps.newHashMap();
        for (Enumeration<?> enumeration = request.getParameterNames(); enumeration.hasMoreElements();) {
            String key = (String)enumeration.nextElement();
            map.put(key, request.getParameter(key));
        }
        return map;
    }
}