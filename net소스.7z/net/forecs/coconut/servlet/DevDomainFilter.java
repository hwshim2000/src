package net.forecs.coconut.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.StopWatchUtil;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.account.AccountServiceAPI;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.guice.MainModule;
import net.forecs.coconut.security.SsoServiceManager;
import net.forecs.coconut.security.TokenContext;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;

public class DevDomainFilter implements Filter {
	private static final Logger LOG = Logger.getLogger(DomainFilter.class.getName());
	private boolean isDevMode = false;
	
	@Override
	public void init(FilterConfig config) throws ServletException {
		isDevMode = MainModule.developmentServer;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		assert (request instanceof HttpServletRequest);

		HttpServletRequest httpRequest = (HttpServletRequest)request;
		String requestUri = httpRequest.getRequestURI();
		
		StopWatchUtil sw = null;
		if (isDevMode) {
			sw = new StopWatchUtil(requestUri);
			sw.start();
		}
		
		boolean applyDomain = false;
		if (requestUri.startsWith(API.SPI_ROOT+API.PACKAGE_ROOT)
				&& !requestUri.contains(AccountServiceAPI.class.getSimpleName())) {
			applyDomain = true;
		} else {
			applyDomain = false;	// Namespace handled within API
		}
		
		if (!requestUri.equals(API.CHANNEL_DEV_ROOT)) {
			if (isDevMode) {
				LOG.info("requestUri=" + requestUri + ", applyDomain=" + applyDomain);
			}
		}
		if (applyDomain) {
			String domainName = NamespaceManager.get();
			if (StringUtils.isEmpty(domainName)) {
				Users user = CommonService.getCurrentUser();
				if (user != null) {
					domainName = user.getDomainName();
					if (isDevMode) { LOG.info("applyDomain domainName=" + domainName); }
					NamespaceManager.set(domainName);
				}
			}
		}
		HttpServletResponse httpResponse = (HttpServletResponse)response;
		MultiReadHttpServletRequest multiReadRequest = new MultiReadHttpServletRequest(httpRequest);
		SsoServiceManager.set(multiReadRequest, httpResponse);
		try (TokenContext context = TokenContext.create(multiReadRequest, httpResponse)) {
			chain.doFilter(multiReadRequest, httpResponse);
		}
		
		if (isDevMode) { sw.stop(); }
	}

	@Override
	public void destroy() {
	}
}
