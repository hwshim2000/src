package net.forecs.coconut.servlet;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.util.Date;
import java.util.logging.Level;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.security.OAuthUtils;
import net.forecs.coconut.endpoint.admin.GCSService;
import net.forecs.coconut.endpoint.admin.IGCSService;
import net.forecs.coconut.endpoint.common.IAttachmentService;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;

import com.google.api.services.storage.Storage;
import com.google.api.services.storage.Storage.Objects.Get;
import com.google.api.services.storage.model.Objects;
import com.google.api.services.storage.model.StorageObject;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.blobstore.BlobKey;
import com.google.appengine.api.blobstore.BlobstoreService;
import com.google.appengine.api.blobstore.BlobstoreServiceFactory;
import com.google.appengine.tools.cloudstorage.GcsFileOptions;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsInputChannel;
import com.google.appengine.tools.cloudstorage.GcsOutputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;

@Singleton
public class GCSDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = -4940538315864007897L;

	private static final Logger LOG = Logger.getLogger(GCSDownloadServlet.class.getName());
	private static final int BUFFER_SIZE = 2 * 1024 * 1024;
	private final GcsService googleCloudStorageService = GcsServiceFactory
			.createGcsService(new RetryParams.Builder()
			.initialRetryDelayMillis(10)
			.retryMaxAttempts(10)
			.totalRetryPeriodMillis(15000).build());
	
	//private static final int downloads = 30; 
	private final IGCSService gcsService;
	private final IAttachmentService attachmentService;
	
	@Inject
	public GCSDownloadServlet(IGCSService gcsService, IAttachmentService attachmentService) {
		this.gcsService = gcsService;
		this.attachmentService = attachmentService;
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) {
		String prevNamespace = NamespaceManager.get();
		try {
			req.setCharacterEncoding(CommonProperty.UTF_8);
			
			String key = req.getParameter(PARAM.KEY);
			String bucket = req.getParameter(PARAM.GS_BUCKET_NAME);
			String fileName = req.getParameter(PARAM.FILENAME);
			
			if (!MemcacheManager.isValidAccessKey(key, req)) {
				res.getWriter().print("Invalid key or download time was expired.");
				throw new Exception("Invalid key or download time was expired.");
			}
			
			// --------------------------------------------------------- ServiceFactory
			// Temporary
			// ServiceFactory를 이용하게 되면 실제 Storage가 아닌 local binary storage를 이용하게 된다.
			// 테스트시에는 임시로 dumy 파일을 올려두고 활용하도록 구성하였다.
			//String mode = req.getParameter("mode");
			//if (StringUtils.equalsIgnoreCase("upload", mode)) {
			//	uploadUsingGcsServiceFactory(bucket, fileName);
			//}
			// --------------------------------------------------------- ServiceFactory
			
			if (StringUtils.isBlank(bucket)) { bucket = GCSService.ATTACHMENT_BUCKET; }
			
			res.setHeader("Content-Transfer-Encoding", "binary;");
			res.setHeader("Pragma", "no-cache;");
			res.setHeader("Expires", "-1;");
			Objects objs = gcsService.listStorageObjects(bucket, null, null, null, fileName, null, null, null);
			if (objs == null || objs.getItems() == null || objs.getItems().size() == 0) { return; }
			if (objs.getItems().size() > 1) { 
				res.setContentType("Content-type: text/zip");
				res.setHeader("Content-Disposition", getDownloadFileName(bucket, fileName, true));
				downloadToZip(res, bucket, objs);
				//dowonloadUsingAttachmentService(res, objs);
			} else {
				fileName = objs.getItems().get(0).getName();
				res.setContentType("Content-type: application/octet-stream");
				res.setHeader("Content-Disposition", getDownloadFileName(bucket, fileName, false));
				downloadSingleFile(res, bucket, fileName);
				
				// --------------------------------------------------------- ServiceFactory
				// Temporary
				// ServiceFactory를 이용하게 되면 실제 Storage가 아닌 local binary storage를 이용하게 된다.
				// 테스트시에는 임시로 dumy 파일을 올려두고 활용하도록 구성하였다.
				//downloadUsingGcsServiceFactory(res, bucket, fileName);
				// --------------------------------------------------------- ServiceFactory
			}
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	private void downloadToZip(HttpServletResponse res, String bucket, Objects objs) throws IOException {
		ZipOutputStream zos = null;
		
		try {
			zos = new ZipOutputStream(new BufferedOutputStream(res.getOutputStream()));
		
			Storage storage = OAuthUtils.loadGCS();
			
			for (StorageObject obj : objs.getItems()) {
				String filePath = obj.getName();
				if (StringUtils.isBlank(filePath)) { continue; }
				if (obj.getSize() == BigInteger.ZERO) { continue; }
				if (filePath.lastIndexOf('/')==filePath.length()-1) { continue; }
				
				final InputStream is = getInputStream(storage, bucket, filePath);
				addZipEntry(zos, filePath, is);
			}
		} catch (Exception ex) {
			throw new IOException(ex.getMessage());
		} finally {
			if (zos != null) { zos.close(); }
		}
	}
	
	private void downloadSingleFile(HttpServletResponse res, String bucket, String fileName) throws Exception {
		byte[] buffer = new byte[10240];
		OutputStream output = null;
		try {
			output = res.getOutputStream();
			Storage storage = OAuthUtils.loadGCS();
				
			final InputStream input = getInputStream(storage, bucket, fileName);
			
			for (int length = 0; (length = input.read(buffer)) > 0;) {
		        output.write(buffer, 0, length);
		    }
		} catch (Exception ex) {
			throw ex;
		} finally {
			if (output != null) { output.close(); }
		}
	}
	
	private void addZipEntry(ZipOutputStream zos, String zipFileName, final InputStream is) throws IOException {
		if (is == null) { return; }
		try {
			zos.putNextEntry(new ZipEntry(zipFileName));
			int read;
			byte[] buffer = new byte[8192];
			while ((read = is.read(buffer)) != -1) {
				zos.write(buffer, 0, read);
			}
			zos.closeEntry();
		} finally {
			if (is != null) { is.close(); }
		}
	}
	
	private final InputStream getInputStream(Storage storage, String bucket, String fileName) throws IOException {
		Get get = storage.objects().get(bucket, fileName);	// fileName 은 bucket이름부터 상대적 경로이름이다.
		get.getMediaHttpDownloader().setDirectDownloadEnabled(false);
		
		return get.executeMediaAsInputStream();
	}
	
	private String getDownloadFileName(String bucket, String fileName, boolean isZip) {
		String downloadName = null;
		if (isZip) {
			String date = CalendarUtil.toString(new Date(), "yyyyMMddHHmmss");
			
			if (StringUtils.isBlank(fileName)) {
				downloadName = String.format("%s-%s.zip", bucket, date);
			} else {
				downloadName = String.format("%s-%s-%s.zip", bucket, FilenameUtils.getBaseName(StringUtils.removeEnd(fileName, "/")), date);	
			}
			try {
				downloadName = URLEncoder.encode(downloadName, CommonProperty.UTF_8);
			} catch (UnsupportedEncodingException ex) {}
		} else {
			if (StringUtils.isBlank(fileName)) {
				downloadName = bucket;	
			} else {
				downloadName = FilenameUtils.getName(StringUtils.removeEnd(fileName, "/"));
			}
			
			try {
				downloadName = URLEncoder.encode(FilenameUtils.getName(downloadName), CommonProperty.UTF_8);
			} catch (UnsupportedEncodingException ex) {}
		}
		return String.format("attachment; filename=\"%s\"", downloadName);
	}
	
	// --------------------------------------------------------- ServiceFactory
	@SuppressWarnings("unused")
	private void downloadUsingGcsServiceFactory(HttpServletResponse res,
			String bucket, String fileName) throws Exception {
		GcsFilename gcsFileName = new GcsFilename(bucket, fileName);
		boolean SERVE_USING_BLOBSTORE_API = false;
		if (SERVE_USING_BLOBSTORE_API) {
			BlobstoreService blobstoreService = BlobstoreServiceFactory
					.getBlobstoreService();
			BlobKey blobKey = blobstoreService.createGsBlobKey("/gs/" + bucket
					+ "/" + gcsFileName.getObjectName());
			blobstoreService.serve(blobKey, res);
		} else {
			GcsInputChannel readChannel = googleCloudStorageService
					.openPrefetchingReadChannel(gcsFileName, 0, BUFFER_SIZE);
			copy(Channels.newInputStream(readChannel), res.getOutputStream());
		}
	}
	// --------------------------------------------------------- ServiceFactory
	private void copy(InputStream input, OutputStream output)
			throws IOException {
		try {
			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead = input.read(buffer);
			while (bytesRead != -1) {
				output.write(buffer, 0, bytesRead);
				bytesRead = input.read(buffer);
			}
		} finally {
			input.close();
			output.close();
		}
	}
	
	// --------------------------------------------------------- ServiceFactory
	@SuppressWarnings("unused")
	private void uploadUsingGcsServiceFactory(String bucket, String fileName) throws Exception {
		GcsService gcs = GcsServiceFactory.createGcsService(new RetryParams.Builder()
        .initialRetryDelayMillis(10)
        .retryMaxAttempts(10)
        .totalRetryPeriodMillis(15000)
        .build());
		
		//ByteArrayOutputStream os = new ByteArrayOutputStream();
		//ByteBuffer buf = ByteBuffer.wrap(os.toByteArray());
		String msg = "This is sample file test.";
		ByteBuffer buf = ByteBuffer.wrap(msg.getBytes("UTF-8"));
		
		GcsFilename gcsfileName = new GcsFilename(bucket, fileName);
		//bucketFileName =  your file name
		GcsFileOptions options = new GcsFileOptions.Builder().mimeType("text/plain").build();
		GcsOutputChannel outputChannel = gcs.createOrReplace(gcsfileName, options);
		outputChannel.write(buf);
		outputChannel.close();
	}
	// --------------------------------------------------------- ServiceFactory
	
	@SuppressWarnings("unused")
	private void dowonloadUsingAttachmentService(HttpServletResponse res, Objects objs) throws IOException {
		ZipOutputStream zos = null;
		
		try {
			zos = new ZipOutputStream(new BufferedOutputStream(res.getOutputStream()));
		
			for (StorageObject obj : objs.getItems()) {
				String filePath = obj.getName();
				if (StringUtils.isBlank(filePath)) { continue; }
				if (obj.getSize() == BigInteger.ZERO) { continue; }
				if (filePath.lastIndexOf('/')==filePath.length()-1) { continue; }
				
				final InputStream is = getInputStreamFromAttachmentService(filePath);
				addZipEntry(zos, StringUtils.substringAfter(filePath, "/"), is);
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (zos != null) { zos.close(); }
		}
	}
	private final InputStream getInputStreamFromAttachmentService(String filePath) throws IOException{
		try {
			String downloadUrl = attachmentService.getDownloadUrl(filePath, 180);
	    	URL url = new URL(downloadUrl);  
			return url.openStream();
		} catch (final MalformedURLException e) {
			throw new IOException(e.getMessage());
	    } catch (final IOException e) {
	    	throw new IOException(e.getMessage());
	    } catch (final Exception e) {
	    	throw new IOException(e.getMessage());
	    }
	}
	
	@SuppressWarnings("unused")
	private final void downloadToZipOutputStream(Storage storage, String bucket, String filePath, ZipOutputStream zos) throws IOException {
		zos.putNextEntry(new ZipEntry(filePath));
		Get get = storage.objects().get(bucket, filePath);
		get.getMediaHttpDownloader().setDirectDownloadEnabled(false);
			
		get.executeMediaAndDownloadTo(zos);
	    zos.closeEntry();
	}
	
//	public static void main(String[] args) throws Exception {
//		String str = "aa/bb/cc/dd/";
//		System.out.println(StringUtils.removeEnd(str, "/"));
//	}
}
