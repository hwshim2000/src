package net.forecs.coconut.servlet;


import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.CharsetUtil;
import net.forecs.coconut.common.util.FileTypes;
import net.forecs.coconut.common.util.schema.Columns;
import net.forecs.coconut.common.util.schema.DDLUtils;
import net.forecs.coconut.common.util.schema.Schemas;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import edu.emory.mathcs.backport.java.util.Arrays;
@Singleton
public class DBSchemaDDLServlet extends HttpServlet {
	private static final long serialVersionUID = 2999012259492183544L;
	private static final Logger LOG = Logger.getLogger(DBSchemaDDLServlet.class.getName());
	private static final String FONT_FAMILY = "맑은 고딕";	// Arial, 동움, 새굴림
	private static final String[] HEADERS = new String[] { "번호", "컬럼명", "타입", "길이", "PK", "FK", "UQ", "IDX", "NN", "DEFAULT", "AI", "설명" };
	private static final int RED = 240;
	private static final int GREEN = 240;
	private static final int BLUE = 240;
	private static final short FSIZE_MAIN_TITLE = 16;
	private static final short FSIZE_TABLE_SUBJECT = 12;
	private static final short FSIZE_TABLE_VALUE = 11;
	private static final short FSIZE_FIELD_HEADER = 12;
	private static final short FSIZE_FILED_VALUE = 11;
	private static final short FSIZE_FIELD_DESCRIPTION = 10;
	private static final short HEIGHT_MAIN_TITLE = 30;
	private static final short HEIGHT_SUBJECT = 20;
	private static final short HEIGHT_FIELD_HEADER = 20;
	private static final short HEIGHT_FIELD = 18;
	
	@Inject
	public DBSchemaDDLServlet() {
		
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}
	
	@SuppressWarnings("unchecked")
	private void process(HttpServletRequest req, HttpServletResponse res) {
		try {
			req.setCharacterEncoding(CommonProperty.UTF_8);
			
			String[] kinds = req.getParameterValues(PARAM.KIND);
			//String key = req.getParameter(PARAM.KEY);
			String format = req.getParameter(PARAM.FORMAT);
			String userName = req.getParameter(PARAM.USERNAME);
			
//			if (!MemcacheManager.isValidAccessKey(key, userId)) {
//				res.getWriter().print("Invalid key or download time was expired.");
//				throw new Exception("Invalid key or download time was expired.");
//			}
			
			List<Schemas> schemas = null;
			if (kinds != null) {
				schemas = DDLUtils.listSchemas(Arrays.asList(kinds));
			} else {
				schemas = DDLUtils.listAllSchemas();
			}
			
			if (schemas == null || schemas.size() == 0) {
				throw new Exception("Schema not found!");
			}
			ObjectMapper om = new ObjectMapper();
			String encoding = CharsetUtil.getEncoding(om.writeValueAsString(schemas));
		
		
			String mimeType = "application/octet-stream";
			res.setCharacterEncoding(encoding);
			res.setContentType(mimeType);
			res.setHeader("Content-Transfer-Encoding", "binary;");
			res.setHeader("Pragma", "no-cache;");
			res.setHeader("Expires", "-1;");

			String headerKey = "Content-Disposition";
			
			String baseName = String.format("테이블정의서-%s", CalendarUtil.toString(new Date(), "yyyyMMddHHmmss"));
			if (StringUtils.isBlank(format) || !StringUtils.equalsIgnoreCase(FileTypes.JSON, format)) { format = FileTypes.DEFAULT_EXT; } 
			String fileName = baseName + "." + format;
			
			String headerValue = String.format("attachment; filename=\"%s\"", URLEncoder.encode(fileName, CommonProperty.UTF_8));
			res.setHeader(headerKey, headerValue);
			
			if (format.equalsIgnoreCase(FileTypes.XLSX) || format.equalsIgnoreCase(FileTypes.XLS)) {
				downloadForSSF(res, schemas, userName);
			} else if (format.equalsIgnoreCase(FileTypes.JSON)) {
				downloadForJsonObject(res, schemas);
			}
			//LOG.info(fileName + " written successfully on disk.");
		} catch (Exception ex) {
			LOG.log(Level.WARNING, ex.getMessage());
			res.setStatus( HttpServletResponse.SC_SERVICE_UNAVAILABLE );
		}
	}
	
	private void downloadForSSF(HttpServletResponse res, List<Schemas> schemas, String userName) throws Exception {
		// Blank workbook
		XSSFWorkbook workbook = null;
		
		try {
			workbook = new XSSFWorkbook();
			// Create a blank sheet
			for (Schemas schema : schemas) {
				XSSFSheet sheet = workbook.createSheet(schema.getName());
				
				int tableInfoRows = setTableInfo(workbook, sheet, schema, userName);
				createDivideCell(sheet, tableInfoRows++);
				tableInfoRows = setFieldsInfo(workbook, sheet, schema, tableInfoRows);
				createDivideCell(sheet, tableInfoRows++);
				setSqlInfo(workbook, sheet, schema, tableInfoRows++);
				setColWidth(sheet);
			}
			
			OutputStream os = res.getOutputStream();
			workbook.write(os);
			
			os.close();
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private static int setTableInfo(XSSFWorkbook workbook, XSSFSheet sheet, Schemas schema, String userName) {
		if (StringUtils.isBlank(userName)) { userName = "시스템"; }
		
		int tableInfoRows = 0;
		tableMainTitleMapper(workbook, sheet, tableInfoRows++);
		tableInfoMapper(workbook, sheet, tableInfoRows++, "시스템명", "SN-FORECS-TD-001", "작성일시", CalendarUtil.toString(new Date(), "yyyy-MM-dd"));
		tableInfoMapper(workbook, sheet, tableInfoRows++, "테이블명", schema.getName(), "작성자", userName);
		tableInfoMapper(workbook, sheet, tableInfoRows++, "참조테이블", StringUtils.join(schema.getReferences(), ","));
		tableInfoMapper(workbook, sheet, tableInfoRows++, "설명", schema.getDescription());
		tableInfoMapper(workbook, sheet, tableInfoRows++, "기본 키", schema.getPkConstraint());
		tableInfoMapper(workbook, sheet, tableInfoRows++, "외래 키", StringUtils.join(schema.getFkConstraints(), "\n"));

		return tableInfoRows;
	}
	
	private void setSqlInfo(XSSFWorkbook workbook, XSSFSheet sheet, Schemas schema, int tableInfoRows){
		String sql = DDLUtils.createTableStatement(schema);
		sqlMapper(workbook, sheet, schema, tableInfoRows, "테이블 생성 쿼리", sql);
	}
	
	private static int setFieldsInfo(XSSFWorkbook workbook, XSSFSheet sheet, Schemas schema, int startFieldRows) {
		// This data needs to be written (Object[])
		List<Object[]> data = new ArrayList<Object[]>();
		data.add(HEADERS);
		int rowNumbers = 1;
		for (Columns col : schema.getColumns()) {
			data.add(toRowData(col, rowNumbers++));
		}
	
		// Iterate over data and write to sheet
		int fieldRows = startFieldRows;
		for (Object[] objArr : data) {
			Row row = sheet.createRow(fieldRows);
			if (fieldRows==startFieldRows) { row.setHeightInPoints(HEIGHT_FIELD_HEADER); }
			//else { row.setHeightInPoints(HEIGHT_FIELD); }
			
			int fieldCols = 0;
			for (Object obj : objArr) {
				Cell cell = row.createCell(fieldCols);
				cell.setCellStyle(styleFieldMapper(workbook, fieldCols, fieldRows==startFieldRows));
				
				if (obj instanceof String) { cell.setCellValue((String) obj); }
				else if (obj instanceof Integer) { cell.setCellValue((Integer) obj); }
				
				fieldCols++;
			}
			
			fieldRows++;
		}
		return fieldRows;
	}
	
	private static void tableInfoMapper(XSSFWorkbook workbook, XSSFSheet sheet, int tableInfoRows, String lTitle, String lValue, String rTitle, String rValue) {
		initTableInfoCell(workbook, sheet, tableInfoRows);

		sheet.getRow(tableInfoRows).getCell(0).setCellValue(lTitle);
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 0,(short)1)); //가로병합
		sheet.getRow(tableInfoRows).getCell(2).setCellValue(lValue);
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 2,(short)7)); //가로병합
		
		sheet.getRow(tableInfoRows).getCell(8).setCellValue(rTitle);
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 8,(short)10)); //가로병합
		sheet.getRow(tableInfoRows).getCell(11).setCellValue(rValue);
	}
	private static void tableInfoMapper(XSSFWorkbook workbook, XSSFSheet sheet, int tableInfoRows, String title, String value) {
		initTableInfoCell(workbook, sheet, tableInfoRows);
		
		sheet.getRow(tableInfoRows).getCell(0).setCellValue(title);
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 0,(short)1)); //가로병합
		sheet.getRow(tableInfoRows).getCell(2).setCellValue(value);
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 2,(short)11)); //가로병합
	}
	private static void sqlMapper(XSSFWorkbook workbook, XSSFSheet sheet, Schemas schema, int tableInfoRows, String title, String value) {
		initSqlInfoCell(workbook, sheet, schema, tableInfoRows);
		
		sheet.getRow(tableInfoRows).getCell(0).setCellValue(title);
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 0,(short)1)); //가로병합
		sheet.getRow(tableInfoRows).getCell(2).setCellValue(value);
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 2,(short)11)); //가로병합
	}
	private static void tableMainTitleMapper(XSSFWorkbook workbook, XSSFSheet sheet, int tableInfoRows) {
		Row row = sheet.createRow(tableInfoRows);
		row.setHeightInPoints(HEIGHT_MAIN_TITLE);
		
		for (int col=0; col < HEADERS.length; col++) {
			Cell cell = row.createCell(col);
			cell.setCellStyle(styleMainTitleMapper(workbook));
		}
		sheet.getRow(tableInfoRows).getCell(0).setCellValue("테이블 정의서");
		sheet.addMergedRegion(new CellRangeAddress(tableInfoRows,(short)tableInfoRows, 0,(short)11)); //가로병합
	}
	private static void setColWidth(XSSFSheet sheet) {
		for (int col=0; col < HEADERS.length; col++) {
			//sheet.autoSizeColumn(i);//appengine에서는 안된다.
			if (col==1) {		// 필드명
				sheet.setColumnWidth(col, (sheet.getColumnWidth(col)) + 2048 );
			} else if (col==2) {	// 타입
				sheet.setColumnWidth(col, (sheet.getColumnWidth(col)) + 512 );
			} else if (col==9) {	// 기본값
				sheet.setColumnWidth(col, (sheet.getColumnWidth(col)) + 1024);
			} else if (col==11) {	// 설명
				sheet.setColumnWidth(col, (sheet.getColumnWidth(col)) + 10240 );
			} else {
				sheet.setColumnWidth(col, (sheet.getColumnWidth(col)) - 512);
			}
		}
	}
	private static void initTableInfoCell(XSSFWorkbook workbook, XSSFSheet sheet, int tableInfoRows) {
		Row row = sheet.createRow(tableInfoRows);
		row.setHeightInPoints(HEIGHT_SUBJECT);
		
		for (int col=0; col < HEADERS.length; col++) {
			Cell cell = row.createCell(col);
			if (tableInfoRows < 3) {
				if (col < 2 || ( col > 7 && col < 11)) {
					cell.setCellStyle(styleSubjectsMapper(workbook));
				} else {
					cell.setCellStyle(styleSubjectValuesMapper(workbook));
				}
			} else {
				if (col < 2) {
					cell.setCellStyle(styleSubjectsMapper(workbook));
				} else {
					cell.setCellStyle(styleSubjectValuesMapper(workbook));
				}
			}
		}
	}
	private static void initSqlInfoCell(XSSFWorkbook workbook, XSSFSheet sheet, Schemas schema, int tableInfoRows) {
		Row row = sheet.createRow(tableInfoRows);
		//row.setHeightInPoints(HEIGHT_FIELD_HEADER);
		int lines = 2 // ( and )
				+ schema.getColumns().size()
				+ schema.getFkConstraints().size()
				+ (StringUtils.isNotBlank(schema.getPkConstraint())?1:0);
		row.setHeightInPoints((short)(HEIGHT_FIELD * lines));
		
		for (int col=0; col < HEADERS.length; col++) {
			Cell cell = row.createCell(col);
			
			XSSFCellStyle cellStyle = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();
			font.setFontName(FONT_FAMILY);
			
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN); // 밑으로 4줄까진 셀 테두리
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);// 셀 v정렬
			
			if (col < 2) {
				cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				font.setFontHeightInPoints(FSIZE_FIELD_HEADER);
				font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);  
			} else {
				cellStyle.setWrapText(true);
				cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				font.setFontHeightInPoints(FSIZE_FILED_VALUE);
			}		
				
			cellStyle.setFont(font);
			
			cell.setCellStyle(cellStyle);
		}
	}
	private static void createDivideCell(XSSFSheet sheet, int tableInfoRows) {
		Row row = sheet.createRow(tableInfoRows);
		row.setHeightInPoints((short)3);
	}
	
	private static XSSFCellStyle styleMainTitleMapper(XSSFWorkbook workbook) {
		XSSFCellStyle cellStyle =  workbook.createCellStyle();

		XSSFFont font = workbook.createFont();  
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);  
		font.setFontName(FONT_FAMILY);
		font.setFontHeightInPoints(FSIZE_MAIN_TITLE);
		cellStyle.setFont(font);
		
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN); // 밑으로 4줄까진 셀 테두리
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		cellStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND); // 셀 패턴
		
		//cellStyle.setFillForegroundColor(new XSSFColor(new byte[]{ (byte)255, (byte)200, (byte)255, (byte)200})); // 셀 배경 색
		cellStyle.setFillForegroundColor(new XSSFColor(new byte[]{ (byte)255, (byte)RED, (byte)GREEN, (byte)BLUE})); // 셀 배경 색
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER); // 샐 정렬
		cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);// 셀 v정렬
			
		return cellStyle;
	}
	private static XSSFCellStyle styleSubjectsMapper(XSSFWorkbook workbook) {
		XSSFCellStyle cellStyle =  workbook.createCellStyle();

		XSSFFont font = workbook.createFont();  
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);  
		font.setFontName(FONT_FAMILY);
		font.setFontHeightInPoints((short)FSIZE_TABLE_SUBJECT);
		
		cellStyle.setFont(font);
		
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN); // 밑으로 4줄까진 셀 테두리
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		cellStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND); // 셀 패턴
		
		cellStyle.setFillForegroundColor(new XSSFColor(new byte[]{ (byte)255, (byte)RED, (byte)GREEN, (byte)BLUE})); // 셀 배경 색
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER); // 샐 정렬
		cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);// 셀 v정렬
			
		return cellStyle;
	}
	private static XSSFCellStyle styleSubjectValuesMapper(XSSFWorkbook workbook) {
		XSSFCellStyle cellStyle =  workbook.createCellStyle();

		XSSFFont font = workbook.createFont();  
		//font.setBoldweight((short)6000);  
		font.setFontName(FONT_FAMILY);
		font.setFontHeightInPoints(FSIZE_TABLE_VALUE);
		 
		cellStyle.setFont(font);
		cellStyle.setWrapText(true);
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN); // 밑으로 4줄까진 셀 테두리
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);// 셀 v정렬
		
		return cellStyle;
	}
	
	private static XSSFCellStyle styleFieldMapper(XSSFWorkbook workbook, int col, boolean isFieldHeader) {
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		
		font.setFontName(FONT_FAMILY);
	
		if (isFieldHeader) { // 0이면 header style이고
			font.setFontHeightInPoints(FSIZE_FIELD_HEADER);
			font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);  
			cellStyle.setFont(font);
			
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN); // 밑으로 4줄까진 셀 테두리
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			cellStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND); // 셀 패턴
			cellStyle.setFillForegroundColor(new XSSFColor(new byte[]{ (byte)255, (byte)RED, (byte)GREEN, (byte)BLUE})); // 셀 배경 색
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER); // 샐 정렬
			cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);// 셀 v정렬
		} else { // 1이면 body style이게 ㅋㅋ
			font.setFontHeightInPoints(FSIZE_FILED_VALUE);
			cellStyle.setFont(font);
	
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN); // 밑으로 4줄까진 셀 테두리
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);// 셀 v정렬
			
			if (col == 1 || col == 2 || col == 11) {
				cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
			} else if (col == 3) {
				cellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
			} else {
				cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			}
			
			if (col == 11) {
				cellStyle.setWrapText(true);
				font.setFontHeightInPoints(FSIZE_FIELD_DESCRIPTION);
				cellStyle.setFont(font);
			}
		}
		return cellStyle;
	}
	
	private void downloadForJsonObject(HttpServletResponse res, Object obj) throws IOException {
		PrintWriter writer = null;
		try {
			writer = res.getWriter();
			ObjectMapper mapper = new ObjectMapper();
			
			mapper.setSerializationInclusion(Include.NON_NULL);
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			
			String jsonStr = mapper.writeValueAsString(obj);
			
			writer.print(jsonStr);
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (writer != null) { writer.close(); }
		}
	}

	private static Object[] toRowData(Columns col, int rowNumber) {
		String fieldName = col.getName();
		String type = col.getType();
		int length = col.getLength();
		String primary = col.isPrimary()?"O":"";
		String foreign = col.isForeign()?"O":"";
		String unique = col.isUnique()?"O":"";
		String index = col.isIndex()?"O":"";
		String notnull = col.isNotnull()?"O":"";
		String defaultValue = col.getDefaultValue();
		String autoIncrement = col.isAutoIncrement()?"O":"";
		String description = col.getDescription();
		
		return new Object[] { rowNumber, fieldName, type, length, primary, foreign, unique, index, notnull, defaultValue, autoIncrement, description };
	}
}
