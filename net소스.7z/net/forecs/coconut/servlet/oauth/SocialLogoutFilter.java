package net.forecs.coconut.servlet.oauth;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.SessionException;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authc.LogoutFilter;

import javax.inject.Inject;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import net.forecs.coconut.common.Logger;


public class SocialLogoutFilter extends LogoutFilter {
    static final Logger LOG = Logger.getLogger(SocialLogoutFilter.class.getName());

    @Inject
    public SocialLogoutFilter() {}

    @Override
    protected boolean preHandle(ServletRequest request, ServletResponse response) throws Exception {
        Subject subject = SecurityUtils.getSubject();

        try {
            subject.logout();
        } catch (SessionException ise) {
            LOG.info("Encountered session exception during logout. This can generally safely be ignored: " + ise.getMessage());
        }
        WebUtil.logoutGoogleService(request, response, "/shiro.html");
        return false;
    }
}