package net.forecs.coconut.servlet.oauth;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;
import net.forecs.coconut.servlet.ContentTypes;
import net.forecs.coconut.shiro.UserAuthType;
import net.forecs.coconut.shiro.oauth.OAuthAuthenticationToken;
import net.forecs.coconut.shiro.oauth.OAuthInfo;
import net.forecs.coconut.shiro.oauth.provider.FacebookAuth;
import net.forecs.coconut.shiro.oauth.provider.GoogleAuth;
import net.forecs.coconut.shiro.oauth.provider.IOAuthProviderInfo;
import net.forecs.coconut.user.Role;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.util.SavedRequest;
import org.apache.shiro.web.util.WebUtils;


// This is set up so that its possible to user other types of OAuth provider rather easily
@Singleton
public class OAuthLoginServlet extends BaseServlet {
	private static final long serialVersionUID = -9128017601016041531L;
	static final Logger LOG = Logger.getLogger(OAuthLoginServlet.class.getName());

    private final String site;

    @Inject
    public OAuthLoginServlet(@Named(FLD.social_site) String site, IUserDao<? extends IUser> userDao) {
        super(userDao);
        this.site = site;
    }

    /**
     * Step 1 is to send off a request.
     * @param request request
     * @param response response
     * @throws ServletException if something goes wrong
     * @throws IOException if we can't write stuff
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String currentUri = WebUtils.getRequestUri(request);
            IOAuthProviderInfo auth = getProvider(request);
            putSessionData("userAuthType", auth.getUserAuthType().name());

            String url = isReAuthenticate() ? auth.reAuthenticateURL(currentUri) : auth.loginURL(currentUri);
            WebUtils.issueRedirect(request, response, url);
        } catch (Exception e) {
            issue(response, ContentTypes.TEXT_PLAIN, HTTP_STATUS_INTERNAL_SERVER_ERROR,
            		"Something unexpected went wrong when posting: " + e.getMessage());
        }
    }

    // Step 2 is the return from Facebook, either giving permission and returning the email, or not...
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = WebUtils.getCleanParam(request, "code");
        String currentUri = WebUtils.getRequestUri(request);
        try {
            IOAuthProviderInfo auth = getProvider((String)getAndClearSessionData("userAuthType"));
            OAuthInfo info = auth.getUserInfo(code, currentUri);
            if (info.isError()) {
                String message = info.getErrorString();
                issue(response, ContentTypes.TEXT_PLAIN, HTTP_BAD_REQUEST,
                		"Couldn't get " + info.getUserAuthType() + " permission: " + message);
            } else {
                String id = info.getEmail();
                String email = info.getEmail();
                IUser user = userDao.findUser(id);
                if (user == null) {
                	//-->
                	//user = userDao.registerUser(id, null, null, email, Role.DEFAULT_ROLES, Permission.DEFAULT_PERMISSIONS);
                	//--
                	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
                	user = userDao.registerUser(id, null, null, email, Role.DEFAULT_ROLE);
                	//<--
                }

                OAuthAuthenticationToken token = new OAuthAuthenticationToken(info.getToken(), info.getUserAuthType(), id, request.getRemoteHost());

                Subject subject = SecurityUtils.getSubject();
                subject.login(token);

                // redirect to wherever you were going, or to home
                SavedRequest savedRequest = WebUtils.getAndClearSavedRequest(request);
                String redirectUrl = (savedRequest == null) ? "/shiro.html" : savedRequest.getRequestUrl();
                // revoking the token immediately is (a) safe as the token can't float around anywhere, and (b) lets us re-suthenticate and logout properly.
                // Just seems odd as the token is meant to last a long time...
                auth.revokeToken(info.getToken(), request, response, redirectUrl);
                //response.sendRedirect(response.encodeRedirectURL(redirectUrl));
            }
        } catch (Exception e) {
            issue(response, ContentTypes.TEXT_PLAIN, HTTP_STATUS_INTERNAL_SERVER_ERROR,
            		"Something unexpected went wrong: " + e.getMessage());
        }
    }

    private boolean isReAuthenticate() {
        Subject subject = SecurityUtils.getSubject();
        String id = (String)subject.getPrincipal();
        if (id != null) {
        	IUser user = userDao.findUser(id);
            return user != null;
        } else {
            return false;
        }
    }

    private IOAuthProviderInfo getProvider(String authType) {
        return getProvider(authType, site);
    }

    private IOAuthProviderInfo getProvider(HttpServletRequest request) {
        String authType = request.getParameter("provider");
        return getProvider(authType, site);
    }

    private static void putSessionData(String key, Object data) {
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        session.setAttribute(key, data);
    }

    private static Object getAndClearSessionData(String key) {
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        Object data = session.getAttribute(key);
        session.removeAttribute(key);
        return data;
    }

    private static IOAuthProviderInfo getProvider(String name, String site) {
        try {
            UserAuthType type = UserAuthType.valueOf(name);
            switch (type) {
                case GOOGLE:
                    return new GoogleAuth(site);
                case FACEBOOK:
                    return new FacebookAuth(site);
                default:
                    LOG.warning("Auth type " + name + "isn't handled");
                    return null;
            }
        } catch (Exception e) {
            LOG.warning("Can't work out the auth type of " + name);
            return null;
        }
    }
}
