package net.forecs.coconut.servlet.oauth;

import java.io.IOException;
import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.servlet.BaseServlet;
import net.forecs.coconut.servlet.ContentTypes;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.shiro.googlegae.GoogleGaeAuthenticationToken;
import net.forecs.coconut.user.Role;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.web.util.SavedRequest;
import org.apache.shiro.web.util.WebUtils;

import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;


/**
 * Google authentication is handled using the built-in service API, rather than calls
 * to OAuth, as for Facebook.  This is deliberate as if you only want this, then you don't
 * need to include the OAuth library.
 * <p>The idea is that you login by (a) logging in the user service and then (b) logging in to
 * Shiro with an access token, whose password is a dummy.  You "check" the password by making sure
 * that the logged-in user is the same as the one you are authenticating.
 * <p>What happens is that a request to URL "googleLogin" is made.  This then logs you
 * in with GAE user service.
 * Once this is done, and you're definitely logged in there is a redirect to URL "googleLoginAuth".
 * You are logged in to the suer service when you get here, and if there is no GAEUser with your Email
 * we create one (tagged as a Google user).
 * <p>When the <code>DatastoreRealm</code> is queried about this user (with dummy password) it authenticates
 * if the Google user has the same Email as the GAEUser.  This seems to be secure.
 * <p>One tiny fly in the ointment is that we really log you out on logout, which means that your browser
 * is logged out & you'll have to re-authenticate with other Google services.  I guess we could make this
 * an option if users find it too annoying.
 */
@Singleton
public class GoogleLoginServlet extends BaseServlet {
	private static final long serialVersionUID = -1102786808132384749L;
	static final Logger LOG = Logger.getLogger(GoogleLoginServlet.class.getName());

    @Inject
    public GoogleLoginServlet(IUserDao<? extends IUser> userDao) {
        super(userDao);
    }

    @Override
    // this is called from login, and all that's required is to login via the Google URL with a return
    // to this place, but with GET as the verb
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UserService userService =  UserServiceFactory.getUserService();
        String currentUri = WebUtils.getRequestUri(request);
        String authUrl = userService.createLoginURL(currentUri);
        try {
            response.sendRedirect(response.encodeRedirectURL(authUrl));
        } catch (Exception e) {
            LOG.warning("Error trying to redirect to " + authUrl);
            response.sendRedirect("/");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        UserService userService =  UserServiceFactory.getUserService();
        try {
            User currentUser = userService.getCurrentUser();
            if (currentUser == null) {
                issue(response, ContentTypes.TEXT_PLAIN, HTTP_STATUS_NOT_FOUND,
                		"Cannot login as we can't find Google user");
                return;
            }

            String id = currentUser.getEmail();
            String userName = currentUser.getNickname();
            String email = currentUser.getEmail();

            // add the user to the database
            IUser user = userDao.findUser(id);
            if (user == null) {
            	//-->
            	//user = userDao.registerUser(id, null, userName, email,
            	//		Role.DEFAULT_ROLES, Permission.DEFAULT_PERMISSIONS);
            	//--
            	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
            	user = userDao.registerUser(id, null, userName, email, Role.DEFAULT_ROLE);
            	//<--
            }

            String host = request.getRemoteHost();
            GoogleGaeAuthenticationToken token = new GoogleGaeAuthenticationToken(id, host);
            try {
                ShiroUtils.loginWithNewSession(token);

                // go back to where Shiro thought we should go or to home if that's not set
                SavedRequest savedRequest = WebUtils.getAndClearSavedRequest(request);
                String redirectUrl = (savedRequest == null) ? "/" : savedRequest.getRequestUrl();
                response.sendRedirect(response.encodeRedirectURL(redirectUrl));
            } catch (AuthenticationException e) {
                issue(response, ContentTypes.TEXT_PLAIN, HTTP_STATUS_NOT_FOUND,
                		"cannot authorize " + id + ": " + e.getMessage());
            }
        } catch (Exception e) {
            issue(response, ContentTypes.TEXT_PLAIN, HTTP_STATUS_INTERNAL_SERVER_ERROR,
            		"Internal error: " + e.getMessage());
        }
    }

    @SuppressWarnings("unused")
	private static void logoutGoogleIfLoggedIn(HttpServletRequest request, HttpServletResponse response, UserService service) throws IOException{
        User user = service.getCurrentUser();
        if (user != null) {
            String redirectUrl = request.getRequestURL().toString();
            WebUtil.logoutGoogleService(request, response, redirectUrl);
        }
    }
}