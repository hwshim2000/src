package net.forecs.coconut.servlet.oauth;

import java.io.IOException;
import java.net.URLEncoder;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.security.TokenService;
import net.forecs.coconut.servlet.BaseServlet;
import net.forecs.coconut.shiro.ShiroUtils;

@Singleton
public class DongbuServiceSsoLoginServlet extends BaseServlet {
	private static final long serialVersionUID = 8551068474626387599L;
	private static final Logger LOG = Logger.getLogger(DongbuServiceSsoLoginServlet.class.getName());
	
	static final String baseOAuthUrl = "https://accounts.google.com/o/oauth2/auth";
	static final String callbackUri = "/jsp/login/oauth_callback.jsp";
	static final String responseType = "token";
	
	@Inject
	public DongbuServiceSsoLoginServlet() {
		super(null);
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		process(req, resp);
	}
	
	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		try {
			String scheme = req.getScheme() + "://";
			String serverName = req.getServerName();
			String serverPort = (req.getServerPort() == 80) ? "" : ":" + req.getServerPort();
			
			String redirectHost = scheme + serverName + serverPort;
			
			req.setCharacterEncoding(CommonProperty.UTF_8);
			resp.setCharacterEncoding(CommonProperty.UTF_8);

			String state = getParameter(req, "state", "").trim();
			String emailScope = URLEncoder.encode(CommonProperty.EMAIL_SCOPE, CommonProperty.UTF_8);
			String profileScope = URLEncoder.encode(CommonProperty.PROFILE_SCOPE, CommonProperty.UTF_8);
			String adminUserScope = URLEncoder.encode(CommonProperty.SCOPE_ADMIN_DIRECTORY_USER, CommonProperty.UTF_8);
			String adminGroupScope = URLEncoder.encode(CommonProperty.SCOPE_ADMIN_DIRECTORY_GROUP, CommonProperty.UTF_8);
			
			String scope = emailScope + "+" + profileScope + "+" + adminUserScope + "+" + adminGroupScope;
			String redirect_uri = redirectHost + callbackUri;
			
			String oauthUrl = baseOAuthUrl
					+ "?scope=" + scope
					+ "&state=" + state
					+ "&redirect_uri=" + redirect_uri
					//+ "&access_type=offline"
					//+ "&response_type=code"
					+ "&response_type=" + responseType
					+ "&client_id=" + CommonProperty.DONGBU_SERVICE_WEB_CLIENT_ID;
					//+ "&immediate=true";

			if (ShiroUtils.getCurrentUser() != null) {
				ShiroUtils.logout();
			}
			TokenService.removeCurrentAccessToken();
			
			resp.sendRedirect(resp.encodeRedirectURL(oauthUrl));
		} catch (Exception ex) {
			resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			LOG.warning(ex.getMessage());
			//throw new IOException(ex.getMessage());
		} finally {
			//resp.setStatus( HttpServletResponse.SC_OK );
		}
	}
}
