package net.forecs.coconut.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.entity.board.Boards;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Text;

@Deprecated
@Singleton
public class BoardLogoServlet extends HttpServlet {
	private static final long serialVersionUID = -8647611369007218203L;
	private static final Logger LOG = Logger
			.getLogger(BoardLogoServlet.class.getName());

	private final IBoardService boardService;
	
	@Inject
	public BoardLogoServlet(IBoardService boardService) {
		this.boardService = boardService;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String prevNamespace = NamespaceManager.get();
		try {
			String domainName = req.getParameter(PARAM.DOMAINNAME);
			String boardId = req.getParameter(PARAM.BOARDID);

			if (StringUtils.isBlank(domainName) || StringUtils.isBlank(boardId)) {
				throw new Exception(ErrorCode.ILLEGAL_PARAMETER.getMessage("DomainName and boardId are required."));
			}
			
			NamespaceManager.set(domainName);
			
			Text userPicture = null;
			Boards board = boardService.getBoards(boardId);
			if (board != null) {
				userPicture = board.getBoardLogo();
			}
			
			if (userPicture != null && StringUtils.isNotBlank(userPicture.getValue())) {
				String mimeType = "application/octet-stream";
//				res.setCharacterEncoding(ExcelUtil.ENCODING);
				res.setContentType(mimeType);
//				res.setHeader("Content-Transfer-Encoding", "binary;");
//				res.setHeader("Pragma", "no-cache;");
//				res.setHeader("Expires", "-1;");
				//byte[] b = Base64.decodeBase64(userPicture.getValue().split("^data:image/(png|jpeg|jpg|jpe|gif|bmp|x-portable-bitmap|tiff|tif|x-xbitmap);base64,")[1]);
				byte[] b = Base64.decodeBase64(userPicture.getValue().split("^data:image/.+;base64,")[1]);
				  
				InputStream inStream = new ByteArrayInputStream(b);
		        OutputStream outStream = res.getOutputStream();
		         
		        byte[] buffer = new byte[4096];
		        int bytesRead = -1;
		         
		        while ((bytesRead = inStream.read(buffer)) != -1) {
		            outStream.write(buffer, 0, bytesRead);
		        }
		         
		        inStream.close();
		        outStream.close();      
			}
		} catch (Exception ex) {
			LOG.warning("[BoardLogo Get Error] "+ex.getMessage());
			//throw new IOException(ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
		//res.setStatus( HttpServletResponse.SC_OK );
	}
}