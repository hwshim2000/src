package net.forecs.coconut.servlet;

import java.io.IOException;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.NonNull;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.freemarker.DocBuilder;
import net.forecs.coconut.user.Role;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.common.base.Preconditions;


public class BaseServlet extends HttpServlet {
	private static final long serialVersionUID = -2212144330059715168L;
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(BaseServlet.class.getName());

    protected static final String MESSAGE = "message";
    protected static final String CODE = "code";

    protected static final int HTTP_STATUS_OK = 200;
    protected static final int HTTP_BAD_REQUEST = 400;
    protected static final int HTTP_STATUS_NOT_FOUND = 404;
    protected static final int HTTP_STATUS_FORBIDDEN = 403;
    protected static final int HTTP_STATUS_INTERNAL_SERVER_ERROR = 500;

    private DocBuilder viewBuilder;

    protected final IUserDao<? extends IUser> userDao;

	protected BaseServlet(IUserDao<? extends IUser> userDao) {
        this.userDao = userDao;
    }

	@Inject
    protected void setViewBuilder(DocBuilder viewBuilder) {
        this.viewBuilder = viewBuilder;
    }

    protected void issue(HttpServletResponse response, String mimeType, int status, String message)
    		throws IOException {
        response.setContentType(mimeType);
        response.setStatus(status);
        response.getWriter().println(message);
    }

    protected void issueJson(HttpServletResponse response, int status, String... args) throws IOException {
        Preconditions.checkArgument(args.length % 2 == 0, "There must be an even number of strings");
		try {
			JSONObject obj = new JSONObject();
			for (int i = 0; i < args.length; i += 2) {
				obj.put(args[i], args[i + 1]);
			}
            issueJson(response, status, obj);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    protected void issueJson(HttpServletResponse response, int status, JSONObject obj) throws IOException {
        issue(response, ContentTypes.APPLICATION_JSON, status, obj.toString());
    }

    protected void showView(HttpServletResponse response, String templateName, Object... args)
    		throws IOException {
        showView(response, templateName, DocBuilder.map(args));
    }

    protected void showView(HttpServletResponse response, String templateName, Map<String, Object> map)
    		throws IOException {
        try {
            String html = viewBuilder.createDocumentString(templateName, map);
            issue(response, ContentTypes.TEXT_HTML, HTTP_STATUS_OK, html);
        } catch (Exception e) {
            issue(response, ContentTypes.TEXT_PLAIN, HTTP_STATUS_NOT_FOUND,
            		"Can't find " + templateName + " : " + e.getMessage());
        }
     }

    protected String getView(String templateName, Object... args) {
        return viewBuilder.createDocumentString(templateName, args);
    }

    protected String getParameter(HttpServletRequest request, @NonNull String name) {
        return request.getParameter(name);
    }
    
    protected String getParameter(HttpServletRequest request, @NonNull String name, String defaultValue) {
        String value = request.getParameter(name);
        return (value == null) ? defaultValue : value;
    }

    protected int getParameter(HttpServletRequest request, @NonNull String name, int defaultValue) {
        String value = request.getParameter(name);
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
    protected long getParameter(HttpServletRequest request, @NonNull String name, long defaultValue) {
        String value = request.getParameter(name);
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
    protected Integer getIntParameter(HttpServletRequest request, @NonNull String name) {
        return getParameter(request, name, (Integer)null);
    }
    protected Integer getParameter(HttpServletRequest request, @NonNull String name, Integer defaultValue) {
        String value = request.getParameter(name);
        try {
            return Integer.valueOf(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
    protected Long getLongParameter(HttpServletRequest request, @NonNull String name) {
        return getParameter(request, name, (Long)null);
    }
    protected Long getParameter(HttpServletRequest request, @NonNull String name, Long defaultValue) {
        String value = request.getParameter(name);
        try {
            return Long.valueOf(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    protected boolean getParameter(HttpServletRequest request, @NonNull String name, boolean defaultValue) {
        String value = request.getParameter(name);
        return (value == null) ? defaultValue : Boolean.parseBoolean(value);
    }

    protected boolean isCurrentUserAdmin() {
        Subject subject = SecurityUtils.getSubject();
        return subject.hasRole(Role.ADMIN);
    }

    protected IUser getCurrentGaeUser() {
        Subject subject = SecurityUtils.getSubject();
        String id = (String)subject.getPrincipal();
        if (id == null) {
            return null;
        } else {
            return userDao.findUser(id);
        }
    }
}