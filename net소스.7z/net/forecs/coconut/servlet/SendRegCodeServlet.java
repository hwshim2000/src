package net.forecs.coconut.servlet;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import net.forecs.coconut.common.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.entity.user.IUser;

import com.ibm.icu.text.MessageFormat;


@Singleton
public class SendRegCodeServlet extends BaseServlet {
	private static final long serialVersionUID = 2964138291988534053L;
	static final Logger LOG = Logger.getLogger(SendRegCodeServlet.class.getName());

    private final SendEmail sendEmail;

    @Inject
    SendRegCodeServlet(IUserDao<? extends IUser> userDao, SendEmail sendEmail) {
        super(userDao);
        this.sendEmail = sendEmail;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
    	@SuppressWarnings("unused")
		String domainName = request.getParameter(PARAM.DOMAINNAME);
    	String id = request.getParameter(PARAM.ID);
        String userId = request.getParameter(PARAM.USERID);
        String userName = getParameter(request, PARAM.USERNAME, "Unknown");
        String email = request.getParameter(PARAM.EMAIL);
        String regCode = request.getParameter(PARAM.REGCODE);
        boolean forgot = getParameter(request, PARAM.FORGOT, false);
        
//        String subject = "Complete Registration for CoCoNut";
//        String templateName = CommonProperty.SEND_REGIST_EMAIL_TEMPLATE;
        
        Messages message = Messages.localeMessages(userId, WRAPPED_CHAR_TYPE.EMAIL);
		String subject = message.getSourceMessage(Messages.COMPLETEREGISTRATION_SUBJECT);
		String templateName = MessageFormat.format(CommonProperty.SEND_REGIST_EMAIL_TEMPLATE, message.getLocale());
		
        if (forgot) {
        	subject = message.getMessage(Messages.RESETPASSWORD_SUBJECT, userName);
        	templateName = MessageFormat.format(CommonProperty.SEND_RESET_PASSWORD_EMAIL_TEMPLATE, message.getLocale());
        	//subject = String.format("[cocoworks] %s님의 Resset Password 정보입니다.", userName);
        	//templateName = CommonProperty.SEND_RESET_PASSWORD_EMAIL_TEMPLATE;
        }
        
        try {
            String url = urlFor(regCode, id, forgot);
            LOG.info("Link URL is " + url);
			String htmlMessage = getView(templateName,
					PARAM.EMAIL, email,
					PARAM.USERNAME, userName,
					PARAM.HREF, url,
					PARAM.REGCODE, regCode,
					PARAM.FORGOT, Boolean.toString(forgot),
					PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL,
					PARAM.LOCALE, message.getLocale().toString()
					);
			sendEmail.send(email, subject, htmlMessage);
//			if (SmtpSendEMail.domains.contains(domainName)) {
//				SmtpSendEMail.send(email, subject, htmlMessage);
//			} else {
//				sendEmail.send(email, subject, htmlMessage);
//			}
            if (forgot) {
            	LOG.info("Reset password email sent to " + email + " with return url " + url);
            } else {
            	LOG.info("Registration email sent to " + email + " with return url " + url);
            }
        } catch (Exception e) {
            LOG.severe("Error sending mail to " + email + ": " + e.getMessage());
        }
    }

    private static String urlFor(String regCode, String userId, boolean forgot) {
      	String query = PARAM.REGCODE + "=" + regCode + "&" + PARAM.ID + "=" + userId;
      	if (forgot) {
      		query = query + "&" + PARAM.FORGOT + "=true";
      	}
      	return String.format("%s/#/confirm-password?%s", CommonProperty.WEB_BASE_URL, query);
    }
    @SuppressWarnings("unused")
	private static String urlFor(HttpServletRequest request, String regCode, String userId, boolean forgot) {
        try {
        	String query = PARAM.REGCODE + "=" + regCode + "&" + PARAM.ID + "=" + userId;
        	if (forgot) {
        		query = query + "&" + PARAM.FORGOT + "=true";
        	}
			URI uri = new URI(request.getScheme(), null, request.getServerName(), request.getServerPort(),
					//"/registerByEmail.ftl",
					"/#/confirm-password",
					query, null);
			return uri.toString().replace("%23", "#");
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}