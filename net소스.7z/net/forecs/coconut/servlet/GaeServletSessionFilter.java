package net.forecs.coconut.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.ServletServiceAPI;
import net.forecs.coconut.guice.MainModule;


// jongwook.yi@forecs.net 2015-05-26 : Workaround to apply session to non-endpoint servlets on dev server
public class GaeServletSessionFilter implements Filter {
	private static final Logger LOG = Logger.getLogger(GaeServletSessionFilter.class.getName());
	private boolean isDevMode = false;
	@Override
	public void init(FilterConfig config) throws ServletException {
		isDevMode = MainModule.developmentServer;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		assert (request instanceof HttpServletRequest);
		assert (response instanceof HttpServletResponse);

		HttpServletRequest httpRequest = (HttpServletRequest)request;
		HttpServletResponse httpResponse = (HttpServletResponse)response;

		String requestUri = httpRequest.getRequestURI();
		
		if (!requestUri.equals(API.CHANNEL_DEV_ROOT)) {
			if (isDevMode) { LOG.info("requestUri=" + requestUri); }
		}

		if (ServletServiceAPI.dispatch(httpRequest, httpResponse)) {
			return;	// Request dispatched
		}

		if (requestUri.contains("ServletServiceAPI")) {
			// ServletResponse object is required for ServletServiceAPI to dispatch request.
			request.setAttribute(ServletServiceAPI.KEY_SERVLET_RESPONSE, response);
		}

		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
	}
}
