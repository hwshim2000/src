package net.forecs.coconut.endpoint.manage;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.manage.Feedbacks;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class FeedbackServiceAPI {
	private final IFeedbackService feedbackService;
	
	@Inject
	public FeedbackServiceAPI(IFeedbackService feedbackService) {
		this.feedbackService = feedbackService;
	}
	
	@ApiMethod(name = "queryMyFeedbacks", path = "manage/feedbacks/my", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Feedbacks> queryMyFeedbacks(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.email) String email,
			@Nullable @Named(FLD.category) List<String> categories) throws Exception {
		QueryResult<Feedbacks> queryResult = feedbackService.queryMyFeedbacks(cursorString, limit, categories);
		
		List<Feedbacks> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Feedbacks>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "getFeedback", path = "manage/feedbacks/{feedbackId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Feedbacks getFeedback(@Named(FLD.feedbackId) String feedbackId) throws Exception {
		return feedbackService.getFeedback(feedbackId);
	}
	
	@ApiMethod(name = "insertFeedback", path = "manage/feedbacks", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Feedbacks insertFeedback(Feedbacks feedback) throws Exception {
		return feedbackService.insertFeedback(feedback);
	}
	
	@ApiMethod(name = "updateFeedback", path = "manage/feedbacks", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Feedbacks updateFeedback(Feedbacks feedback) throws Exception {
		return feedbackService.updateFeedback(feedback);
	}
	
	@ApiMethod(name = "evaluateSatisfaction", path = "manage/feedbacks/satisfaction", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Feedbacks evaluateSatisfaction(@Named(FLD.feedbackId) String feedbackId,
			@Named(FLD.satisfaction) int satisfaction) throws Exception {
		return feedbackService.evaluateSatisfaction(feedbackId, satisfaction);
	}
	
	@ApiMethod(name = "removeFeedback", path = "manage/feedbacks/{feedbackId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeFeedback(@Named(FLD.feedbackId) String feedbackId) throws Exception {
		feedbackService.removeFeedback(feedbackId);
	}
	
	@ApiMethod(name = "addFeedbackAttachment", path = "manage/feedbacks/{feedbackId}/attachments", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Attachments addFeedbackAttachment(@Named(FLD.feedbackId) String feedbackId, Attachments attachment) throws Exception {
		return feedbackService.addFeedbackAttachment(feedbackId, attachment);
	}

	@ApiMethod(name="removeFeedbackAttachment", path = "manage/feedbacks/{feedbackId}/attachments/{attachmentId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public Attachments removeFeedbackAttachment(@Named(FLD.feedbackId) String feedbackId, @Named(FLD.attachmentId) String attachmentId) throws Exception {
		return feedbackService.removeFeedbackAttachment(feedbackId, attachmentId);
	}

	@ApiMethod(name="addFeedbackImage", path = "manage/feedbacks/{feedbackId}/images", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Images addFeedbackImage(@Named(FLD.feedbackId) String feedbackId, Images image) throws Exception {
		return feedbackService.addFeedbackImage(feedbackId, image);
	}
	
	@ApiMethod(name="removeFeedbackImage", path = "manage/feedbacks/{feedbackId}/images/{imageId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public Images removeFeedbackImage(@Named(FLD.imageId) String imageId) throws Exception {
		return feedbackService.removeFeedbackImage(imageId);
	}
}
