package net.forecs.coconut.endpoint.manage;

import java.util.Collection;

import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.manage.Feedbacks;

import com.google.appengine.api.datastore.Text;

public interface IFeedbackService extends ICommonService {
	public abstract QueryResult<Feedbacks> queryFeedbacks(
			String cursorString,
			Integer limit,
			String domainName,
			String id,
			String email,
			Collection<String> categories) throws Exception;
	
	public abstract QueryResult<Feedbacks> queryMyFeedbacks(
			String cursorString,
			Integer limit,
			Collection<String> categories) throws Exception;
	
	public abstract Feedbacks getFeedback(String feedbackId) throws Exception;
	public abstract Feedbacks insertFeedback(Feedbacks feedback) throws Exception;
	public abstract Feedbacks updateFeedback(Feedbacks feedback) throws Exception;
	public abstract Feedbacks answerFeedback(String feedbackId, String answerer, Text answer) throws Exception;
	public abstract Feedbacks evaluateSatisfaction(String feedbackId, int satisfaction) throws Exception;
	public abstract void removeFeedback(String feedbackId) throws Exception;
	public abstract void permanentRemoveFeedback(String feedbackId) throws Exception;
	
	public abstract Attachments addFeedbackAttachment(String feedbackId, Attachments attachment) throws Exception;
	public abstract Attachments removeFeedbackAttachment(String feedbackId, String attachmentId) throws Exception;

	public abstract Images addFeedbackImage(String feedbackId, Images image) throws Exception;
	public abstract Images removeFeedbackImage(String imageId) throws Exception;
}
