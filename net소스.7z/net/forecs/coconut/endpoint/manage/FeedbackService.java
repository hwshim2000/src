package net.forecs.coconut.endpoint.manage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IAttachmentService;
import net.forecs.coconut.endpoint.common.IImageService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.manage.Feedbacks;
import net.forecs.coconut.entity.user.Users;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;

public class FeedbackService extends CommonService implements IFeedbackService {
	private static final Logger LOG = Logger.getLogger(FeedbackService.class.getName());
	
	private final IAttachmentService attachmentService;
	private final IImageService imageService;
	
	@Inject
	public FeedbackService(IAttachmentService attachmentService, IImageService imageService) {
		this.attachmentService = attachmentService;
		this.imageService = imageService;
	}

	@Override
	public QueryResult<Feedbacks> queryFeedbacks(
			String cursorString,
			Integer limit,
			String domainName,
			String id,
			String email,
			Collection<String> categories) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Set<String> categorySet = null;
			
			if (categories != null && 1 < categories.size()) {
				categorySet = new HashSet<String>();
				for (String category : categories) {
					categorySet.add(category);
				}
				categories = null;
			}
				
			DsQuery<Feedbacks> dsQuery = new DsQuery<>(Feedbacks.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.domainName, domainName)
					.eq(FLD.id, id)
					.eq(FLD.email, email)
					.in(FLD.category, categories)
					.sort(FLD.created, SortDirection.DESC)
					.cursor(cursorString)
					.limit(limit);

			int bulkFetchAmount = 1;	// 검색 속도를 높이기 위해 한꺼번에 많은 양을 가져와서 해당되는 값들을 필터링하기 위해, 즉 , limit보다  bulkFetchAmount배 많이 가져온뒤에 필터링
			if (categorySet != null) { bulkFetchAmount = 2; }
 
			do {
				dsQuery.nextFetch(mgr, bulkFetchAmount++);
				while(dsQuery.hasEntity()) {
					Feedbacks feedback = dsQuery.nextEntity();
					if (categorySet != null && !categorySet.contains(feedback.getCategory())) { continue; }
					dsQuery.addResult(feedback);
				}
			} while (dsQuery.hasNextFetch());
			
			List<Feedbacks> feedbacks = dsQuery.getResults();
			try {
				Map<String, List<Attachments>> attachmentsMap = batchMapFeedbackAttachments(mgr, feedbacks);
				Map<String, List<Images>> imagesMap = batchMapFeedbackImages(mgr, feedbacks);
				
				for (Feedbacks feedback : feedbacks) {
					feedback.setAttachments(attachmentsMap.get(feedback.getFeedbackId()));
					feedback.setImages(imagesMap.get(feedback.getFeedbackId()));
				}
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
			return new QueryResult<Feedbacks>(feedbacks, dsQuery.getCursor());	
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public QueryResult<Feedbacks> queryMyFeedbacks(
			String cursorString,
			Integer limit,
			Collection<String> categories) throws Exception {
		Users user = getCurrentUser();
		valid(user);
		String domainName = user.getDomainName();
		String id = user.getId();
		String email = user.getEmail();
		
		return queryFeedbacks(cursorString, limit, domainName, id, email, categories);	
	}

	@Override
	public Feedbacks getFeedback(String feedbackId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			return getFeedback(mgr, feedbackId);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private Feedbacks getFeedback(EntityManager mgr, String feedbackId) throws Exception {
			Feedbacks feedback = doFind(mgr, Feedbacks.class, feedbackId);
			List<Attachments> attachments = attachmentService.listChildAttachments(mgr, feedbackId);
			List<Images> images = imageService.listChildImages(mgr, feedbackId);
			feedback.setAttachments(attachments);
			feedback.setImages(images);
			
			return feedback;
	}
	
	private Map<String, List<Attachments>> batchMapFeedbackAttachments(EntityManager mgr, List<Feedbacks> feedbacks) throws Exception {
		if (feedbacks == null || feedbacks.size() == 0) { return new HashMap<String, List<Attachments>>(); }
		List<String> feedbackIds = new ArrayList<String>();
		for (Feedbacks feedback : feedbacks) {
			feedbackIds.add(feedback.getFeedbackId());
		}
		return attachmentService.batchMapChildAttachments(mgr, feedbackIds);
	}
	private Map<String, List<Images>> batchMapFeedbackImages(EntityManager mgr, List<Feedbacks> feedbacks) throws Exception {
		if (feedbacks == null || feedbacks.size() == 0) { return new HashMap<String, List<Images>>(); }
		List<String> feedbackIds = new ArrayList<String>();
		for (Feedbacks feedback : feedbacks) {
			feedbackIds.add(feedback.getFeedbackId());
		}
		return imageService.batchMapChildImages(mgr, feedbackIds);
	}

	@Override
	public Feedbacks insertFeedback(Feedbacks feedback) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			if (loginUser != null) {
				feedback.setCreator(loginUser.getUserId());
				feedback.setDomainName(loginUser.getDomainName());
				feedback.setId(loginUser.getId());
				feedback.setEmail(loginUser.getEmail());
			}
			feedback.setKey(KeyUtil.createFeedbackKey());
			
			if (contains(mgr, Feedbacks.class, feedback.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Feedbacks.class, feedback.getFeedbackId()));
			}
			
			try {
				updateFeedbackAttachments(feedback);
				updateFeedbackImages(feedback);
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
				throw ex;
			}
			
			doPersistTransaction(mgr, feedback);
			
			return feedback;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Feedbacks updateFeedback(Feedbacks feedback) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			try {
				updateFeedbackAttachments(feedback);
				updateFeedbackImages(feedback);
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
				throw ex;
			}
			
			List<Attachments> attachments = feedback.getAttachments();
			List<Images> images = feedback.getImages();
			
			feedback = doMergeTransaction(mgr, feedback);
			
			feedback.setAttachments(attachments);
			feedback.setImages(images);
			
			return feedback;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Feedbacks answerFeedback(String feedbackId, String answerer, Text answer) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Feedbacks feedback = getFeedback(mgr, feedbackId);
			List<Attachments> attachments = feedback.getAttachments();
			List<Images> images = feedback.getImages();
			
			feedback.setAnswer(answer);
			feedback.setAnswerDate(new Date());
			feedback.setAnswerer(answerer);
			
			feedback = doMergeTransaction(mgr, feedback);
			
			feedback.setAttachments(attachments);
			feedback.setImages(images);
			
			return feedback;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Feedbacks evaluateSatisfaction(String feedbackId, int satisfaction) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Feedbacks feedback = getFeedback(mgr, feedbackId);
			List<Attachments> attachments = feedback.getAttachments();
			List<Images> images = feedback.getImages();
			
			feedback.setSatisfaction(satisfaction);
			
			feedback.setAttachments(attachments);
			feedback.setImages(images);
			
			return feedback;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void removeFeedback(String feedbackId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Feedbacks feedback = doFind(mgr, Feedbacks.class, feedbackId);
			feedback.setDeleteYN(Y);
			feedback.setDeleted(new Date());
			
			doMergeTransaction(mgr, feedback);
			
			boolean archived = Y.equals(feedback.getArchiveYN());
			boolean deleted = Y.equals(feedback.getDeleteYN());
			attachmentService.markChildAttachments(feedbackId, archived, deleted);
			imageService.removeChildImages(feedbackId);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void permanentRemoveFeedback(String feedbackId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Feedbacks feedback = doFind(mgr, Feedbacks.class, feedbackId);
			doRemoveTransaction(mgr, feedback);
			attachmentService.removeChildAttachments(feedbackId);
			imageService.removeChildImages(feedbackId);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private void updateFeedbackAttachments(Feedbacks feedback) throws Exception {
		String feedbackId = feedback.getFeedbackId();
		List<Attachments> attachments = new ArrayList<Attachments>();
		List<Attachments> addAttachments = new ArrayList<Attachments>();
		List<Attachments> updateAttachments = new ArrayList<Attachments>();
		
		EntityManager mgr = getEntityManager();
		try {
			for (Attachments attachment : feedback.getAttachments()) {
				Key attachmentKey = attachment.getKey();
				if (attachmentKey == null) { attachmentKey = KeyUtil.createAttachmentKey(attachment); }
				
				if (doFind(mgr, Attachments.class, attachmentKey) == null) {
					addAttachments.add(attachment);
				} else {
					attachment.setKey(attachmentKey);
					updateAttachments.add(attachment);
				}
			}
		} finally {
			finalizeTransaction(mgr);
		}
		
		attachments.addAll(attachmentService.updateChildAttachments(feedbackId, updateAttachments));
		attachments.addAll(attachmentService.addChildAttachments(feedbackId, addAttachments));
		
		feedback.setAttachments(attachments);
	}
	
	private void updateFeedbackImages(Feedbacks feedback) throws Exception {
		String feedbackId = feedback.getFeedbackId();
		List<Images> images = feedback.getImages();
		imageService.appendOrRemoveImages(feedbackId, images);
	}
	
	@Override
	public Attachments addFeedbackAttachment(String feedbackId, Attachments attachment) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();

		try {
			Feedbacks feedback = doFind(mgr, Feedbacks.class, feedbackId);
			valid(feedback);
			return attachmentService.addChildAttachment(feedbackId, attachment);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Attachments removeFeedbackAttachment(String feedbackId, String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Feedbacks feedback = doFind(mgr, Feedbacks.class, feedbackId);
			valid(feedback);

			return attachmentService.removeChildAttachment(feedbackId, attachmentId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Images addFeedbackImage(String feedbackId, Images image) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		try {
			image.setParentId(feedbackId);
			return imageService.insertOrUpdateImage(image);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public Images removeFeedbackImage(String imageId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		try {
			return imageService.removeImages(imageId);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
}
