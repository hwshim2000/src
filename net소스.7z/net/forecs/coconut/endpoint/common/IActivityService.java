package net.forecs.coconut.endpoint.common;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;


public interface IActivityService extends ICommonService {
	public abstract QueryResult<Activities> listActivities(
			String cursorString,
			Integer limit,
			String boardId,
			Boolean notification,
			Boolean show) throws Exception;
	public abstract QueryResult<Activities> listDashboardActivities(
			String cursorString,
			Integer limit,
			Boolean notification,
			Boolean show) throws Exception;
	public abstract QueryResult<Activities> listDashboardActivities(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			List<String> boardIds,
			Boolean notification,
			Boolean show) throws Exception;
	public abstract QueryResult<Activities> listTaskActivities(
			String cursorString,
			Integer limit,
			String taskId,
			Boolean notification,
			Boolean show) throws Exception;
	
	public abstract List<Activities> batchListActivities(Collection<String> activityIds);
	
	public abstract Activities getActivities(String activityId);
	public abstract Activities insertActivities(Activities activity) throws Exception;
	public abstract List<Activities> insertActivities(List<Activities> activityList) throws Exception;
	public abstract Activities createUserActivity(Users user, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createTaskActivity(Tasks task, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createBoardActivity(Boards board, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createEventActivity(Events event, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createNoticeActivity(Notice event, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createTaskChecklistActivity(TaskChecklists taskChecklist, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createTaskTimelineActivity(TaskTimelines taskTimeline, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createTaskTimelineCommentActivity(TaskTimelineComments taskTimelineComment, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
	public abstract Activities createUsageActivity(Usage usage, Object refObj, ActivityType activityType) throws Exception;
	
	public abstract boolean isShowActivity(Activities activity);
	
	public abstract int bulkRemoveActivities(
			String boardId,
			String kindId,
			ActivityKind activityKind,
			ActivityType activityType,
			String userId) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract Activities createTaskChecklistCommentActivity(TaskChecklistComments taskChecklistComment, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
//	public abstract Activities createTaskCommentActivity(TaskComments taskComment, Object refObj, ActivityType activityType, Users loginUser) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
