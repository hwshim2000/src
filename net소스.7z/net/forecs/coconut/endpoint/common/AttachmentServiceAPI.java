package net.forecs.coconut.endpoint.common;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.query.SearchOption;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.search.ISearchService;
import net.forecs.coconut.entity.search.Attachment;
import net.forecs.coconut.user.Role;

import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;


@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class AttachmentServiceAPI {
	private final IAttachmentService attachmentService;
	private final ISearchService searchService;
	@Inject
	public AttachmentServiceAPI(IAttachmentService attachmentService, ISearchService searchService) {
		this.attachmentService = attachmentService;
		this.searchService = searchService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getUploadUrl", path = "attachments/uploadUrl", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result getUploadUrl(@Named(FLD.filePath) String filePath,
			@Nullable @Named(FLD.contentType) String contentType,
			@Nullable @Named(FLD.expiresIn) Integer expiresIn) throws Exception {
		return new Result(attachmentService.getUploadUrl(filePath, contentType, expiresIn));
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getDownloadUrl", path = "attachments/downloadUrl", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result getDownloadUrl(@Named(FLD.filePath) String filePath,
			@Nullable @Named(FLD.expiresIn) Integer expiresIn) throws Exception {
		return new Result(attachmentService.getDownloadUrl(filePath, expiresIn));
	}
	
	@ApiMethod(name = "listAttachments", path = "attachments", httpMethod = HttpMethod.GET)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	//@RequiresUser
	public Map<String, Map<String, List<Attachment>>> listAttachments(
			@Nullable @Named(FLD.cursor) String cursorString 
			, @Nullable @Named(FLD.limit) Integer limit
			, @Nullable @Named(FLD.boardId) String boardId
			, @Nullable @Named(FLD.taskId) String taskId
			, @Nullable @Named(FLD.searchStr) String searchStr
			, @Nullable SearchOption searchOption
			) throws Exception {
		Map<String, Map<String, List<Attachment>>> results = searchService.searchAttachmentsForFileManage(cursorString, limit,  boardId, taskId, searchStr, searchOption);
		return results;
	}
	
	@ApiMethod(name = "requestDowonloadKey", path = "attachments/download/key/{domainId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result requestDowonload(@Named(FLD.domainId) String domainId) throws Exception {
		CommonService.validNamespace(domainId);
		return new Result(MemcacheManager.createAccessKey(domainId));
	}
	// ************* Unused service ******************
	// chulhong.kim 2015-05-26 : Added to support deleting attachment
//	@ApiMethod(name = "getDeleteUrl", path = "attachments/deleteUrl", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Result getDeleteUrl(@Named(FLD.filePath) String filePath,
//			@Nullable @Named(FLD.expiresIn) Integer expiresIn) throws Exception {
//		return new Result(attachmentService.getDeleteUrl(filePath, expiresIn));
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "getAttachments", path = "attachments/{attachmentId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Attachments getAttachments(@Named(FLD.attachmentId) String attachmentId) throws Exception {
//		CommonService.validNamespace(attachmentId);
//		return attachmentService.getAttachments(attachmentId);
//	}
	
//	@ApiMethod(name = "childAttachmentsMap", path = "attachments/childAttachmentsMap", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, List<Attachments>> childAttachmentsMap(@Named(FLD.parentId) List<String> parentIdList) throws Exception {
//		return attachmentService.childAttachmentsMap(parentIdList);
//	}
}
