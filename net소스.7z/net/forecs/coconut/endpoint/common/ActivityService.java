package net.forecs.coconut.endpoint.common;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.NoticeKind;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.TaskStage;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.HtmlUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.channel.INotificationService;
import net.forecs.coconut.endpoint.channel.ISyncService;
import net.forecs.coconut.endpoint.channel.IWebHookService;
import net.forecs.coconut.endpoint.domain.IStageService;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Activities.ActivityData;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.datastore.Text;


@SuppressWarnings("deprecation")
public class ActivityService extends CommonService implements IActivityService {
	private static final Logger LOG = Logger.getLogger(ActivityService.class.getName());
	
	private final static String DEFAULT_BOARD_NAME = "NON-BOARD";
	private final static Set<String> excludeSyncActivities = new HashSet<String>();
	private final static Set<String> hiddenActivities = new HashSet<String>();
	private final static Set<String> notiActivities = new HashSet<String>();
	static {
		//------------------ Exclude Sync Activities --------------------
		excludeSyncActivities.add(join(ActivityKind.USAGE));
		excludeSyncActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM));
		excludeSyncActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_BIRTH));
		excludeSyncActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_WEDDING));
		
		//------------------ Hidden Activities --------------------
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.SUBSCRIBE));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.UNSUBSCRIBE));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.FINAL_ATTACHED));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.FINAL_UNATTACHED));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_EDIT_PERMISSION));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_DETAIL_EDIT_OWNER_PERMISSION));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_DETAIL_EDIT_MEMBER_PERMISSION));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_CHECKLIST_EDIT_OWNER_PERMISSION));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_CHECKLIST_EDIT_MEMBER_PERMISSION));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.UPDATE_DISPLAY_IN_CALENDAR));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.SHOW_IN_CALENDAR));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.HIDE_IN_CALENDAR));
//		hiddenActivities.add(join(ActivityKind.TASKS, ActivityType.UPDATED));
		
		hiddenActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.EVALUATED));
		hiddenActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.CANCEL_EVALUATED));
		hiddenActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.ATTACHED));
		hiddenActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.UNATTACHED));
		
		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.CLOSED));
		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.OPENED));
		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.GROUP_EDITED));
		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.GROUP_DELETED));
		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.CREATED_LABEL));
		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_LABEL));
		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.DELETED_LABEL));
//		hiddenActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATED));
		
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_EVENT_TYPE));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_EVENT_DATE));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_EVENT_STARTDATE));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_EVENT_ENDDATE));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_EVENT_ALLDAY));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_DESCRIPTION));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_LOCATION));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_RECURRENCE));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATE_ALARM));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM));
		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_WEDDING));
//		hiddenActivities.add(join(ActivityKind.SCHEDULE, ActivityType.UPDATED));
		
//		hiddenActivities.add(join(ActivityKind.USERS, ActivityType.LOGIN));
//		hiddenActivities.add(join(ActivityKind.USERS, ActivityType.LOGOUT));
		hiddenActivities.add(join(ActivityKind.USERS, ActivityType.ASSIGNED));
		hiddenActivities.add(join(ActivityKind.USERS, ActivityType.UNASSIGNED));
		hiddenActivities.add(join(ActivityKind.USERS, ActivityType.CONNECTED));
		hiddenActivities.add(join(ActivityKind.USERS, ActivityType.DISCONNECTED));
		hiddenActivities.add(join(ActivityKind.USERS, ActivityType.UPDATED));
		
		hiddenActivities.add(join(ActivityKind.NOTICE, ActivityType.SYSTEM_NOTICE_ADDED));
		hiddenActivities.add(join(ActivityKind.NOTICE, ActivityType.SYSTEM_NOTICE_DELETED));
		hiddenActivities.add(join(ActivityKind.NOTICE, ActivityType.SYSTEM_NOTICE_UPDATED));
		
		hiddenActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_BOARDS_USAGE));
		
		
		//------------------ Notification Activities --------------------
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.ASSIGNED));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.UNASSIGNED));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.REQUEST_MEMBERS));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.CONFIRM_MEMBERS));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.REJECT_MEMBERS));
		
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_OWNERSHIP));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.ATTACHED));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.FINAL_ATTACHED));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.UPDATE_DUEDATE));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_DETAIL_EDIT_OWNER_PERMISSION));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_DETAIL_EDIT_MEMBER_PERMISSION));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_CHECKLIST_EDIT_OWNER_PERMISSION));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.CHANGED_CHECKLIST_EDIT_MEMBER_PERMISSION));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.CLOSED));
		notiActivities.add(join(ActivityKind.TASKS, ActivityType.OPENED));
		
		notiActivities.add(join(ActivityKind.TASK_CHECKLISTS, ActivityType.ASSIGNED));
		
		notiActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.ADDED));
		notiActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.ADDED_WITH_MENTION));
		notiActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.COPIED));
		notiActivities.add(join(ActivityKind.TASK_TIMELINES, ActivityType.UPDATED_WITH_MENTION));
		
		notiActivities.add(join(ActivityKind.TASK_TIMELINE_COMMENTS, ActivityType.ADDED));
		notiActivities.add(join(ActivityKind.TASK_TIMELINE_COMMENTS, ActivityType.ADDED_WITH_MENTION));
		notiActivities.add(join(ActivityKind.TASK_TIMELINE_COMMENTS, ActivityType.UPDATED_WITH_MENTION));
		
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.ASSIGNED));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UNASSIGNED));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.CHANGED_OWNERSHIP));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_PUBLIC_SEARCH_RANGE_DOMAIN));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_PUBLIC_SEARCH_RANGE_BOARD));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_CREATE_NOTICE_AUTH_OWNER));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_CREATE_NOTICE_AUTH_MEMBER));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_CREATE_TASK_AUTH_OWNER));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_CREATE_TASK_AUTH_MEMBER));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_CREATE_SCHEDULE_AUTH_OWNER));
		notiActivities.add(join(ActivityKind.BOARDS, ActivityType.UPDATE_CREATE_SCHEDULE_AUTH_MEMBER));
		
		notiActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ADDED));
		notiActivities.add(join(ActivityKind.SCHEDULE, ActivityType.RENAMED));
		notiActivities.add(join(ActivityKind.SCHEDULE, ActivityType.DELETED));
		notiActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_BIRTH));
		
		notiActivities.add(join(ActivityKind.NOTICE, ActivityType.ADDED));
		
		notiActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_USERS_USAGE));
		notiActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_STORAGE_USAGE));
		notiActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_EXPIRATION));
	}
	
	private final IUserService userService;
	private final IBoardService boardService;
	private final ITaskService taskService;
	private final INotificationService notificationService;
	private final ISyncService syncService;
	private final IWebHookService webHookService;
	private final IStageService stageService;
	
	@Inject
	public ActivityService(
			IUserService userService,
			IBoardService boardService,
			ITaskService taskService,
			INotificationService notificationService,
			IWebHookService webHookService,
			IStageService stageService,
			ISyncService syncService) {
		this.userService = userService;
		this.boardService = boardService;
		this.taskService = taskService;
		this.notificationService = notificationService;
		this.syncService = syncService;
		this.webHookService = webHookService;
		this.stageService = stageService;
	}
	
	@Override
	public QueryResult<Activities> listActivities(String cursorString,
			Integer limit,
			String boardId,
			Boolean notification,
			Boolean show) throws Exception {
		List<String> boardIds = new ArrayList<String>();
		boardIds.add(boardId);
		
		return listActivities(cursorString, limit, boardIds, notification, show);
	}
	private QueryResult<Activities> listActivities(String cursorString,
			Integer limit,
			Collection<String> boardIds,
			Boolean notification,
			Boolean show) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return listActivities(mgr, cursorString, limit, boardIds, null, notification, show);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private QueryResult<Activities> listActivities(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> boardIds,
			String taskId,
			Boolean notification,
			Boolean show) throws Exception {
		try {
			if (limit == null) { limit = 10; }
			
			Date createdAfter;
			if ((notification != null)) {
				createdAfter = CalendarUtil.addDay(new Date(), -7);
			} else {
				createdAfter = null;
			}

			Set<String> boardIdSet = null;
			
			if (boardIds != null && 1 < boardIds.size()) {
				boardIdSet = new HashSet<String>();
				for (String boardId : boardIds) {
					boardIdSet.add(boardId);
				}
				boardIds = null;
			}
			
			Users user = getCurrentUser();
			Messages localeMessage = Messages.localeMessages(user.getUserId(), WRAPPED_CHAR_TYPE.WEB);
			
			if ((boardIds != null && boardIds.size() > 0)
					|| (boardIdSet != null && boardIdSet.size() > 0) || StringUtils.isNotBlank(taskId)) {
				DsQuery<Activities> dsQuery = new DsQuery<>(Activities.class)
						.eq(FLD.deleteYN, null)
						.in(FLD.boardId, boardIds)
						.eq(FLD.taskId, taskId)
						.eq(FLD.notification, notification)
						.eq(FLD.show, show)
						.gt(FLD.created, createdAfter)
						.sort(FLD.created, SortDirection.DESC)
						.cursor(cursorString)
						.limit(limit);
				
				int bulkFetchAmount = 1;	// 검색 속도를 높이기 위해 한꺼번에 많은 양을 가져와서 해당되는 값들을 필터링하기 위해, 즉 , limit보다  bulkFetchAmount배 많이 가져온뒤에 필터링
				if (boardIdSet != null) { bulkFetchAmount = 2; } 
				
				do {
					dsQuery.nextFetch(mgr, bulkFetchAmount++);
					while (dsQuery.hasEntity()) {
						Activities activity = dsQuery.nextEntity();
						if (boardIdSet != null && !boardIdSet.contains(activity.getBoardId())) { continue; }
						//if (!(isShowActivity(activity)==show)) { continue; }
						
						String message = localeMessage.getMessage(activity);
						message = toLocaleStageString(message, localeMessage);
						activity.setMessage(message);
						dsQuery.addResult(activity);
					}
				} while (dsQuery.hasNextFetch());
				return new QueryResult<Activities>(dsQuery.getResults(), dsQuery.getCursor());
			} else {
				return new QueryResult<Activities>();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public QueryResult<Activities> listDashboardActivities(String cursorString,
			Integer limit,
			Boolean notification,
			Boolean show) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users user = getCurrentUser();
			Set<String> boardIds = boardService.getUserBoardIds(mgr, user);
//			List<String> userIdList = new ArrayList<String>();
//			userIdList.add(user.getUserId());
//			Set<String> boardIds = boardService.getUsersBoardForDashboard(mgr, user, userIdList);
			return listActivities(mgr, cursorString, limit, boardIds, null, notification, show);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public QueryResult<Activities> listDashboardActivities(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			List<String> boardIds,
			Boolean notification,
			Boolean show) throws Exception {
		return listActivities(mgr, cursorString, limit, boardIds, null, notification, show);
	}
	
	@Override
	public QueryResult<Activities> listTaskActivities(
			String cursorString,
			Integer limit,
			String taskId,
			Boolean notification,
			Boolean show) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return listActivities(mgr, cursorString, limit, null, taskId, notification, show);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Activities> batchListActivities(Collection<String> activityIds) {
		try {
			return batchListByKey(Activities.class, activityIds);
		} catch (Exception ex) {
			return null;
		}
	}

	@Override
	public Activities getActivities(String activityId) {
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, Activities.class, activityId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Activities> insertActivities(List<Activities> activityList) throws Exception {
		if (activityList == null) { return null; }

		List<Activities> resultList = new ArrayList<Activities>();
		for (Activities activity : activityList) {
			resultList.add(insertActivities(activity));
		}
		return resultList;
	}

	@Override
	public Activities insertActivities(Activities activity) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			beginTransaction(mgr);
			activity = insertActivities(mgr, activity);
			commitTransaction(mgr);
			// 원격 호출 횟수를 줄이기 위해(client에게 리턴값이 바로 전달되는 값이 아니기때문에 궂이 lazyFetch를 할 필요가 없을듯...)
			activity = setNotificationUserIds(mgr, activity);
		} catch (Exception ex) {
			LOG.warning("[Insert activity error]" + ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	
		prepareNotification(activity);

		if (isIncludeSyncActivity(activity)) {
			syncService.sync(activity);
		}
	
		if (CommonProperty.WEB_HOOK_ENABLE) {
			webHookService.hook(activity);
		}
	
		return activity;
	}

	private Activities insertActivities(EntityManager mgr, Activities activity) throws Exception {
		try {
			activity.setKey(KeyUtil.createActivityKey());
			if (contains(mgr, Activities.class, activity.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(activity.getActivityId()));
			}
			doPersist(mgr, activity);
			return activity;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private boolean isIncludeSyncActivity(Activities activity) {
		return !isExcludeSyncActivity(activity);
	}
	
	private boolean isExcludeSyncActivity(Activities activity) {
		if (excludeSyncActivities.contains(join(activity.getActivityKind(), activity.getActivityType()))
				|| excludeSyncActivities.contains(join(activity.getActivityKind()))){
			return true;
		}
		return false;
	}
	
	@Override
	public Activities createTaskActivity(Tasks task, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		Activities activity = new Activities(task, activityType, loginUser);
		Boards board = boardService.getBoards(task.getBoardId());
		Stages stage = stageService.getStageByTaskStageCode(task.getTaskStage());
		String taskStage = stage.getTitle();
		String userName = getDisplayUserName(loginUser);
		String boardTitle = board.getTitle();
		
		activity.setLinkURL(CommonProperty.BOARD_LINK_URL + task.getBoardId());
		activity.setShow(isShowActivity(activity));
		activity.setNotification(isNotificationTarget(activity));
		
		switch (activityType) {
			case ADDED :
				//message = String.format("[%s] added [%s] to [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case RENAMED : {
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				String originTitle = (String)data.getOldEntity();
				String newTitle = (String)data.getNewEntity();
				activity.setSyncEntity(newTitle);
				activity.setRefObj(originTitle);
				//message = String.format("[%s] renamed [%s] to [%s] on [%s] on [%s]", userName, originTitle, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, originTitle, task.getTitle(), taskStage, boardTitle);
			}	break;
			case MOVED : {
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				String oldStage = (String)data.getOldEntity();
				activity.setSyncEntity(data.getNewEntity());
				activity.setRefObj(oldStage);
				activity.setMsgParams(userName, task.getTitle(), oldStage, taskStage, boardTitle);
			}	break;
			case MOVED_BOARD : {
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				Stages fromStage = (Stages)data.getOldEntity();
				Stages toStage = (Stages)data.getNewEntity();
				Boards fromBoard = boardService.getBoards(fromStage.getBoardId());
				activity.setSyncEntity(toStage.getTaskStage());
				activity.setRefObj(fromStage.getTaskStage());
				activity.setMsgParams(userName, task.getTitle(), boardTitle, taskStage, fromBoard.getTitle());
			}	break;
			case COPIED : {
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				Stages fromStage = (Stages)data.getOldEntity();
				Stages toStage = (Stages)data.getNewEntity();
				Boards fromBoard = boardService.getBoards(fromStage.getBoardId());
				activity.setSyncEntity(toStage.getTaskStage());
				activity.setRefObj(fromStage.getTaskStage());
				activity.setMsgParams(userName, task.getTitle(), boardTitle, taskStage, fromBoard.getTitle());
			}	break;
			case ARCHIVED :
				//message = String.format("[%s] archived [%s] to [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case UNARCHIVED :
				//message = String.format("[%s] unarchived [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case DELETED :
				//message = String.format("[%s] deleted [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case ASSIGNED :
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				Users assignedUser = (Users)refObj;
				String assignedUserName = getDisplayUserName(assignedUser);
				activity.setRefObj(assignedUserName);
				activity.setSyncEntity(assignedUser);
				//message = String.format("[%s] assigned [%s] to [%s] on [%s] on [%s]", userName, assignedUserName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, assignedUserName, task.getTitle(), taskStage, boardTitle);
				break;
			case UNASSIGNED :
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				Users unassignedUser = (Users)refObj;
				String unassiginedUserName = getDisplayUserName(unassignedUser);
				activity.setRefObj(unassiginedUserName);
				activity.setSyncEntity(unassignedUser);
				//message = String.format("[%s] unassigned [%s] from [%s] on [%s] on [%s]", userName, unassiginedUserName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, unassiginedUserName, task.getTitle(), taskStage, boardTitle);
				break;
			case REQUEST_MEMBERS :
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				//String requestUserName = getDisplayUserName(loginUser);
				//activity.setRefObj(requestUserName);
				activity.setSyncEntity(loginUser);
				//message = String.format("[%s] member requested [%s] to [%s] on [%s] on [%s]", userName, assignedUserName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case CONFIRM_MEMBERS :
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				Users requestUser = (Users)refObj;
				String confirmUserName = getDisplayUserName(requestUser);
				activity.setRefObj(confirmUserName);
				activity.setSyncEntity(requestUser);
				//message = String.format("[%s] member confirmed [%s] to [%s] on [%s] on [%s]", userName, assignedUserName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, confirmUserName, task.getTitle(), taskStage, boardTitle);
				break;
			case REJECT_MEMBERS :
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				Users rejectUser = (Users)refObj;
				String rejectUserName = getDisplayUserName(rejectUser);
				activity.setRefObj(rejectUserName);
				activity.setSyncEntity(rejectUser);
				//message = String.format("[%s] member confirmed [%s] to [%s] on [%s] on [%s]", userName, assignedUserName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, rejectUserName, task.getTitle(), taskStage, boardTitle);
				break;
			case CHANGED_OWNERSHIP :
				Users changedOwner = (Users)refObj;
				String changedUserName = getDisplayUserName(changedOwner);
				activity.setRefObj(changedUserName);
				activity.setSyncEntity(changedOwner);
				//message = String.format("[%s] changed ownership [%s] to manage [%s] on [%s] on [%s]", userName, changedUserName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, changedUserName, task.getTitle(), taskStage, boardTitle);
				break;
			case SUBSCRIBE :
				Users subscribedUser = (Users)refObj;
				String subscribedUserName = getDisplayUserName(subscribedUser);
				activity.setRefObj(subscribedUserName);
				activity.setSyncEntity(subscribedUser);
				//message = String.format("[%s] subscribe [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case UNSUBSCRIBE :
				Users unsubscribedUser = (Users)refObj;
				String unsubscribedUserName = getDisplayUserName(unsubscribedUser);
				activity.setRefObj(unsubscribedUserName);
				activity.setSyncEntity(unsubscribedUser);
				//message = String.format("[%s] unsubscribe [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case ATTACHED :
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				String attachedFileName = ((Attachments)refObj).getFileName();
				activity.setRefObj(attachedFileName);
				activity.setSyncEntity(refObj);
				//message = String.format("[%s] attached [%s] to [%s] on [%s] on [%s]", userName, attachedFileName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, attachedFileName, task.getTitle(), taskStage, boardTitle);
				break;
			case UNATTACHED :
				String unattachedFileName = ((Attachments)refObj).getFileName();
				activity.setRefObj(unattachedFileName);
				activity.setSyncEntity(refObj);
				//message = String.format("[%s] unattached [%s] from [%s] on [%s] on [%s]", userName, unattachedFileName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, unattachedFileName, task.getTitle(), taskStage, boardTitle);
				break;
			case FINAL_ATTACHED :
				//String finalAttachedFileName = ((Attachments)refObj).getTitle();
				String finalAttachedFileName = ((Attachments)refObj).getFileName();
				activity.setRefObj(finalAttachedFileName);
				activity.setSyncEntity(refObj);
				//message = String.format("[%s] attached [%s] to [%s] on [%s]", userName, finalAttachedFileName, task.getTitle(), boardTitle);
				activity.setMsgParams(userName, finalAttachedFileName, task.getTitle(), boardTitle);
				break;
			case FINAL_UNATTACHED :
				//String finalUnattachedFileName = ((Attachments)refObj).getTitle();
				String finalUnattachedFileName = ((Attachments)refObj).getFileName();
				activity.setRefObj(finalUnattachedFileName);
				activity.setSyncEntity(refObj);
				//message = String.format("[%s] unattached [%s] from [%s] on [%s]", userName, finalUnattachedFileName, task.getTitle(), boardTitle);
				activity.setMsgParams(userName, finalUnattachedFileName, task.getTitle(), boardTitle);
				break;
			case UPDATE_IMPORTANCE : {
				String importance = task.getImportance();
				activity.setRefObj(importance);
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				String newImportance = (String)data.getNewEntity();
				activity.setSyncEntity(newImportance);
				//message = String.format("[%s] edited importance to [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
			}	break;
			case UPDATE_STARTDATE : {
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				Date newStartDate = (Date)data.getNewEntity();
				activity.setSyncEntity(newStartDate);
				//message = String.format("[%s] edited Start Date [%s] to [%s] on [%s] on [%s]", userName, CalendarUtil.toString(task.getStartDate(), "yyyy-MM-dd"), task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, CalendarUtil.toString(task.getStartDate(), "yyyy-MM-dd"), task.getTitle(), taskStage, boardTitle);
			}	break;
			case UPDATE_DUEDATE : {
				activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				Date newDueDate = (Date)data.getNewEntity();
				activity.setSyncEntity(newDueDate);
				//message = String.format("[%s] editied Due Date[%s] to [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, CalendarUtil.toString(task.getDueDate(), "yyyy-MM-dd"), task.getTitle(), taskStage, boardTitle);
			}	break;
			case UPDATE_LABEL :
				//message = String.format("[%s] edited label to [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case UPDATE_DESCRIPTION : {
				String desc = HtmlUtil.ellipsis(task.getDescription());
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				Text newDescription = (Text)data.getNewEntity();
				activity.setSyncEntity(newDescription);
				//message = String.format("[%s] edited description [%s] to [%s] on [%s] on [%s]", userName, desc, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, desc, task.getTitle(), taskStage, boardTitle);
			}	break;
			case CHANGED_EDIT_PERMISSION :
				//message = String.format("[%s] changed edit permission [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case CHANGED_DETAIL_EDIT_OWNER_PERMISSION :
				//message = String.format("[%s] changed description edit permission Owner only to [%s] on [%s] on [%s]", userName,  task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case CHANGED_DETAIL_EDIT_MEMBER_PERMISSION :
				//message = String.format("[%s] changed description edit permission Task member to [%s] on [%s] on [%s]", userName,  task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case CHANGED_CHECKLIST_EDIT_OWNER_PERMISSION :
				//message = String.format("[%s] changed checklist edit permission Owner only to [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case CHANGED_CHECKLIST_EDIT_MEMBER_PERMISSION :
				//message = String.format("[%s] changed checklist edit permission Task member to [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
			case UPDATE_WIKI :
				//message = String.format("[%s] edited wiki to [%s] on [%s]", userName, task.getTitle(), boardTitle);
				activity.setMsgParams(userName, task.getTitle(), boardTitle, taskStage);
				break;
			case UPDATE_DISPLAY_IN_CALENDAR : {
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				String newDisplayInCalendarYN = (String)data.getNewEntity();
				activity.setSyncEntity(newDisplayInCalendarYN);
				//message = String.format("[%s] edited display in calendar [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				//activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
			}	break;
			case SHOW_IN_CALENDAR : {
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				String newDisplayInCalendarYN = (String)data.getNewEntity();
				activity.setSyncEntity(newDisplayInCalendarYN);
				//message = String.format("[%s] edited display in calendar ON [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
			}	break;
			case HIDE_IN_CALENDAR : {
				Activities.ActivityData data = (Activities.ActivityData)refObj;
				String newDisplayInCalendarYN = (String)data.getNewEntity();
				activity.setSyncEntity(newDisplayInCalendarYN);
				//message = String.format("[%s] edited display in calendar OFF [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
			}	break;
			case CLOSED :
				//message = String.format("[%s] closed [%s] on [%s] on [%s]", userName, taskStage, task.getTitle(), boardTitle);
				activity.setMsgParams(userName, board.getTitle(), taskStage, boardTitle);
				break;
			case OPENED :
				//message = String.format("[%s] opened [%s] on [%s] on [%s]", userName, taskStage, task.getTitle(), boardTitle);
				activity.setMsgParams(userName, board.getTitle(), taskStage, boardTitle);
				break;
			default :	// UPDATED
				//message = String.format("[%s] updated [%s] on [%s] on [%s]", userName, task.getTitle(), taskStage, boardTitle);
				activity.setMsgParams(userName, task.getTitle(), taskStage, boardTitle);
				break;
		}
		//activity.setMessage(Messages.getMessage(activity, null));
		return activity;
	}
	
	@Override
	public Activities createTaskChecklistActivity(TaskChecklists taskChecklist, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Activities activity = new Activities(taskChecklist, activityType, loginUser);
			Boards board = boardService.getBoards(mgr, taskChecklist.getBoardId());
			Tasks task = taskService.getTasks(mgr, taskChecklist.getTaskId());
			String userName = getDisplayUserName(loginUser);
			Stages stage = stageService.getStageByTaskStageCode(task.getTaskStage());
			String taskStage = stage.getTitle();
			
			activity.setSyncEntity(taskChecklist);
			activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + taskChecklist.getTaskId());
			activity.setShow(isShowActivity(activity));
			activity.setNotification(isNotificationTarget(activity));
			
			switch (activityType) {
				case ADDED :
					//message = String.format("[%s] added [%s] checklist [%s] to [%s] on [%s]", userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle(), taskStage);
					break;
				case DELETED :
					//message = String.format("[%s] deleted [%s] checklist [%s] to [%s] on [%s]", userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle(), taskStage);
					break;
				case CHECKED :
					//message = String.format("[%s] checked [%s] checklist [%s] to [%s] on [%s]", userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle(), taskStage);
					break;
				case ASSIGNED :
					String assigneeName = getDisplayUserName(userService.getUsers(mgr, taskChecklist.getAssignee(), false));
					//message = String.format("[%s] assigned [%s] checklist [%s] to [%s] on [%s]", userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle());
					activity.setMsgParams(assigneeName, taskChecklist.getTitle(), task.getTitle(), board.getTitle(), taskStage);
					break;
				case UNCHECKED :
					//message = String.format("[%s] unchecked [%s] checklist [%s] to [%s] on [%s]", userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle(), taskStage);
					break;
				case UPDATED :
				default :
					//message = String.format("[%s] edited [%s] checklist [%s] to [%s] on [%s]", userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, taskChecklist.getTitle(), task.getTitle(), board.getTitle(), taskStage);
					break;
			}
			//activity.setMessage(Messages.getMessage(activity, null));
			return activity;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Activities createTaskTimelineActivity(TaskTimelines taskTimeline, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Activities activity = new Activities(taskTimeline, activityType, loginUser);
			Boards board = boardService.getBoards(mgr, taskTimeline.getBoardId());
			Tasks task = taskService.getTasks(mgr, taskTimeline.getTaskId());
			taskTimeline.setBoardTitle(board.getTitle());
			taskTimeline.setTaskTitle(task.getTitle());
			Stages stage = stageService.getStageByTaskStageCode(task.getTaskStage());
			String taskStage = stage.getTitle();
			String userName = getDisplayUserName(loginUser);
			activity.setSyncEntity(taskTimeline);
			activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + taskTimeline.getTaskId());
			activity.setShow(isShowActivity(activity));
			activity.setNotification(isNotificationTarget(activity));
			String ellipseDesc = HtmlUtil.ellipsis(taskTimeline.getDescription());
			
			switch (activityType) {
				case ADDED :
					//message = String.format("[%s] added Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case ADDED_WITH_MENTION :
					//message = String.format("[%s] added Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMentionIds(taskTimeline.getMentionIds());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case COPIED :
					//message = String.format("[%s] added Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case EVALUATED :
					//message = String.format("[%s] evaluated Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case CANCEL_EVALUATED :
					//message = String.format("[%s] cancel evaluated Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case ATTACHED :
					activity.setSyncEntity(refObj);
					//message = String.format("[%s] attached Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case UNATTACHED :
					activity.setSyncEntity(refObj);
					//message = String.format("[%s] unattached Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case DELETED :
					//message = String.format("[%s] deleted Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case UPDATED_WITH_MENTION :
					//--> hyeunwoo.shim 2015-12-11 : 만일 새로 추가된 맨션에게만 보낼경우는 아래코드를 이용, 그렇지 않고 맨션 모두에게 보낼 경우에는 주석 처리
					@SuppressWarnings("unchecked")
					List<String> newMentions = (List<String>)refObj;
					activity.setMentionIds(newMentions);
					//message = String.format("[%s] edited Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case UPDATED :
				default :
					//message = String.format("[%s] edited Post [%s] to [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
			}
			//activity.setMessage(Messages.getMessage(activity, null));
			return activity;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Activities createTaskTimelineCommentActivity(TaskTimelineComments taskTimelineComment, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Activities activity = new Activities(taskTimelineComment, activityType, loginUser);
			Boards board = boardService.getBoards(mgr, taskTimelineComment.getBoardId());
			Tasks task = taskService.getTasks(mgr, taskTimelineComment.getTaskId());
			Stages stage = stageService.getStageByTaskStageCode(task.getTaskStage());
			String taskStage = stage.getTitle();
			//TaskTimelines taskTimeline = taskTimelineService.getTaskTimelines(taskTimelineComment.getTaskTimelineId());
			String userName = getDisplayUserName(loginUser);
	
			activity.setSyncEntity(taskTimelineComment);
			activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + taskTimelineComment.getTaskId());
			activity.setShow(isShowActivity(activity));
			activity.setNotification(isNotificationTarget(activity));
			String ellipseDesc = HtmlUtil.ellipsis(taskTimelineComment.getDescription());
	
			switch (activityType) {
				case ADDED :
					//message = String.format("[%s] added comment [%s] to Post on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case ADDED_WITH_MENTION :
					activity.setMentionIds(taskTimelineComment.getMentionIds());
					//message = String.format("[%s] added comment [%s] to Post on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case DELETED :
					//message = String.format("[%s] deleted comment [%s] to Post on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case UPDATED_WITH_MENTION :
					//--> hyeunwoo.shim 2015-12-11 : 만일 새로 추가된 맨션에게만 보낼경우는 아래코드를 이용, 그렇지 않고 맨션 모두에게 보낼 경우에는 주석 처리
					@SuppressWarnings("unchecked")
					List<String> newMentions = (List<String>)refObj;
					activity.setMentionIds(newMentions);
					//message = String.format("[%s] edited comment [%s] to Post on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
				case UPDATED :
				default :
					//message = String.format("[%s] edited comment [%s] to Post on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
					activity.setMsgParams(userName, ellipseDesc, task.getTitle(), board.getTitle(), taskStage);
					break;
			}
			//activity.setMessage(Messages.getMessage(activity, null));
			return activity;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Activities createBoardActivity(Boards board, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		Activities activity = new Activities(board, activityType, loginUser);
		String userName = getDisplayUserName(loginUser);
		
		activity.setLinkURL(CommonProperty.BOARD_LINK_URL + board.getBoardId());
		activity.setShow(isShowActivity(activity));
		activity.setNotification(isNotificationTarget(activity));

		switch (activityType) {
			case CREATED :
				//message = String.format("[%s] created [%s]", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
				break;
			case OPENED :
				//message = String.format("[%s] opened [%s]", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
				break;
			case CLOSED :
				//message = String.format("[%s] closed [%s]", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
				break;
			case RENAMED :
				String originTitle = (String)refObj;
				activity.setRefObj(originTitle);
				activity.setSyncEntity(board.getTitle());
				//message = String.format("[%s] renamed [%s] to [%s]", userName, originTitle, board.getTitle());
				activity.setMsgParams(userName, originTitle, board.getTitle());
				break;
			case ASSIGNED : {
				Users assignedUser = ((MemberAuths)refObj).getUser();
				String assignedUserName = getDisplayUserName(assignedUser);
				activity.setRefObj(assignedUser.getUserId());
				//activity.setRefObj(assignedUserName);
				activity.setSyncEntity(assignedUser);
				//message = String.format("[%s] assigned [%s] to [%s]", userName, assignedUserName, board.getTitle());
				activity.setMsgParams(userName, assignedUserName, board.getTitle());
			}	break;
			case UNASSIGNED : {
				Users unassignedUser = ((MemberAuths)refObj).getUser();
				String unassiginedUserName = getDisplayUserName(unassignedUser);
				activity.setRefObj(unassignedUser.getUserId());
				//activity.setRefObj(unassiginedUserName);
				activity.setSyncEntity(unassignedUser);
				//message = String.format("[%s] unassigned [%s] from [%s]", userName, unassiginedUserName, board.getTitle());
				activity.setMsgParams(userName, unassiginedUserName, board.getTitle());
			}	break;
			case CHANGED_OWNERSHIP :
				Users changedOwner = (Users)refObj;
				String changedUserName = getDisplayUserName(changedOwner);
				activity.setRefObj(changedUserName);
				activity.setSyncEntity(changedOwner);
				//message = String.format("[%s] changed ownership [%s] to manage [%s]", userName, changedUserName, board.getTitle());
				activity.setMsgParams(userName, changedUserName, board.getTitle());
				break;
			case GROUP_EDITED : {
				ActivityData data = (ActivityData)refObj;
				Groups oldGroup = (Groups)data.getOldEntity();
				Groups newGroup = (Groups)data.getNewEntity();
				String originGroupName = oldGroup.getTitle();
				String newGroupName = newGroup.getTitle();
				activity.setRefObj(newGroupName);
				activity.setSyncEntity(newGroup);
				//message = String.format("[%s] edited [%s] group to [%s] group of [%s]", userName, originGroupName, newGroupName, board.getTitle());
				activity.setMsgParams(userName, originGroupName, newGroupName, board.getTitle());
			}	break;
			case GROUP_DELETED : {
				ActivityData data = (ActivityData)refObj;
				Groups oldGroup = (Groups)data.getOldEntity();
				Groups newGroup = (Groups)data.getNewEntity();
				String groupName = oldGroup.getTitle();
				activity.setRefObj(groupName);
				activity.setSyncEntity(newGroup.getObjectId());
				//message = String.format("[%s] deleted [%s] from [%s]", userName, groupName, board.getTitle());
				activity.setMsgParams(userName, groupName, board.getTitle());
			}	break;
			case CREATED_LABEL : {
				ActivityData data = (ActivityData)refObj;
				TaskLabels newLabel = (TaskLabels)data.getNewEntity();
				activity.setSyncEntity(newLabel);
				//message = String.format("[%s] created label [%s] on [%s]", userName, newLabel.getLabel(), board.getTitle());
				activity.setMsgParams(userName, newLabel.getLabel(), board.getTitle());
			}	break;
			case UPDATE_LABEL : {
				ActivityData data = (ActivityData)refObj;
				TaskLabels newLabel = (TaskLabels)data.getNewEntity();
				activity.setSyncEntity(newLabel);
				//message = String.format("[%s] updated label [%s] on [%s]", userName, newLabel.getLabel(), board.getTitle());
				activity.setMsgParams(userName, newLabel.getLabel(), board.getTitle());
			}	break;
			case DELETED_LABEL : {
				ActivityData data = (ActivityData)refObj;
				TaskLabels deletedLabel = (TaskLabels)data.getOldEntity();
				activity.setSyncEntity(deletedLabel);
				//message = String.format("[%s] deleted label [%s] on [%s]", userName, deletedLabel.getLabel(), board.getTitle());
				activity.setMsgParams(userName, deletedLabel.getLabel(), board.getTitle());
			}	break;
			case UPDATE_PUBLIC_SEARCH_RANGE_DOMAIN : {
				//message = String.format("[%s] changed Public search range of [%s] to Board member", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			case UPDATE_PUBLIC_SEARCH_RANGE_BOARD : {
				 //message = String.format("[%s] changed Public search range of [%s] to Domain member", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			case UPDATE_CREATE_NOTICE_AUTH_OWNER : {
				 //message = String.format("[%s] changed Notice create permission of [%s] to Board owner only", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			case UPDATE_CREATE_NOTICE_AUTH_MEMBER : {
				 //message = String.format("[%s] changed Notice create permission of [%s] to Board member", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			case UPDATE_CREATE_TASK_AUTH_OWNER : {
				 //message = String.format("[%s] changed Task create permission of [%s] to Board owner only", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			case UPDATE_CREATE_TASK_AUTH_MEMBER : {
				 //message = String.format("[%s] changed Task create permission of [%s] to Board member", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			case UPDATE_CREATE_SCHEDULE_AUTH_OWNER : {
				 //message = String.format("[%s] changed Schedule create permission of [%s] to Board owner only", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			case UPDATE_CREATE_SCHEDULE_AUTH_MEMBER : {
				 //message = String.format("[%s] changed Schedule create permission of [%s] to Board member", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
			}	break;
			default :	// UPDATED
				//message = String.format("[%s] updated [%s]", userName, board.getTitle());
				activity.setMsgParams(userName, board.getTitle());
				break;
		}
		//activity.setMessage(Messages.getMessage(activity, null));
		return activity;
	}

	@Override
	public Activities createEventActivity(Events event, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		EntityManager mgr = getEntityManager();
			try {
			Activities activity = new Activities(event, activityType, loginUser);
	
			String boardTitle = DEFAULT_BOARD_NAME;
			if (StringUtils.isNotBlank(event.getBoardId())) {
				activity.setLinkURL(CommonProperty.BOARD_LINK_URL + event.getBoardId());
				boardTitle = boardService.getBoards(mgr, event.getBoardId()).getTitle();
			}
	
			String userName = getDisplayUserName(loginUser);
			activity.setShow(isShowActivity(activity));
			activity.setNotification(isNotificationTarget(activity));
	
			switch (activityType) {
				case ADDED :
					//message = String.format("[%s] added [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case RENAMED :
					String originTitle = (String)refObj;
					activity.setRefObj(originTitle);
					//message = String.format("[%s] renamed [%s] to [%s] on [%s]", userName, originTitle, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, originTitle, event.getTitle(), boardTitle);
					break;
				case DELETED :
					//message = String.format("[%s] deleted [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case UPDATE_EVENT_TYPE :
					//message = String.format("[%s] edited type of [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case UPDATE_EVENT_DATE :
					//message = String.format("[%s] edited [Date] to [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case UPDATE_EVENT_STARTDATE :
					//message = String.format("[%s] edited Start Date [%s] to [%s] on [%s]", userName, CalendarUtil.toString(event.getStartDate(), "yyyy-MM-dd"), event.getTitle(), boardTitle);
					activity.setMsgParams(userName, CalendarUtil.toString(event.getStartDate(), "yyyy-MM-dd"), event.getTitle(), boardTitle);
					break;
				case UPDATE_EVENT_ENDDATE :
					//message = String.format("[%s] edited End Date [%s] to [%s] on [%s]", userName, CalendarUtil.toString(event.getStartDate(), "yyyy-MM-dd"), event.getTitle(), boardTitle);
					activity.setMsgParams(userName, CalendarUtil.toString(event.getEndDate(), "yyyy-MM-dd"), event.getTitle(), boardTitle);
					break;
				case UPDATE_EVENT_ALLDAY :
					String onOff = "Off";
					if ((boolean)refObj) { onOff = "On"; }
					//message = String.format("[%s] edited [All-day %s] to [%s] on [%s]", userName, onOff, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, onOff, event.getTitle(), boardTitle);
					break;
				case UPDATE_DESCRIPTION :
					//message = String.format("[%s] edited [Description] to [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case UPDATE_LOCATION :
					//message = String.format("[%s] edited [Location] to [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case UPDATE_RECURRENCE :
					//message = String.format("[%s] repeated [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case UPDATE_ALARM :
					//message = String.format("[%s] alarmed [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
				case ALARM :
	//				activity.setRefObj(activity.getBoardId());
	//				activity.setBoardId(null);
					//message = String.format("[%s] alarmed at [%s]", event.getTitle(), CalendarUtil.toString(event.getAlarmDateTime(), "yyyy-MM-dd HH:mm:ss"));
					activity.setMsgParams(event.getTitle(), CalendarUtil.toString(event.getAlarmDateTime(), "yyyy-MM-dd HH:mm:ss"));
					break;
				case ALARM_BIRTH :
	//				activity.setRefObj(activity.getBoardId());
	//				activity.setBoardId(null);
					String birthUserName = getDisplayUserName(userService.getUsers(mgr, event.getOwner(), false));
					//message = String.format("Tommorow(%s) is [%s]'s BirthDay!", CalendarUtil.toString(event.getStartDate(), "yyyy-MM-dd"), birthUserName);
					activity.setMsgParams(CalendarUtil.toString(event.getRecurrenceDate(), "yyyy-MM-dd"), birthUserName);
					break;
				case ALARM_WEDDING :
	//				activity.setRefObj(activity.getBoardId());
	//				activity.setBoardId(null);
					String weddingUserName = getDisplayUserName(userService.getUsers(mgr, event.getOwner(), false));
					//message = String.format("Tommorow(%s) is [%s]'s Weddingday!", CalendarUtil.toString(event.getStartDate(), "yyyy-MM-dd"), weddingUserName);
					activity.setMsgParams(CalendarUtil.toString(event.getRecurrenceDate(), "yyyy-MM-dd"), weddingUserName);
					break;
				default :
					//message = String.format("[%s] updated [%s] on [%s]", userName, event.getTitle(), boardTitle);
					activity.setMsgParams(userName, event.getTitle(), boardTitle);
					break;
			}
			//activity.setMessage(Messages.getMessage(activity, null));
			return activity;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Activities createUserActivity(Users originUser, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		//-->
		// If use pictureURL, will be recovered originally.
		Users user = (Users)CopyUtil.copyDeeply(originUser);
		//<--
		Activities activity = new Activities(originUser, activityType);

		String userName = getDisplayUserName(loginUser);
		activity.setShow(isShowActivity(activity));
		activity.setNotification(isNotificationTarget(activity));
		
		switch (activityType) {
			case LOGIN :
				//message = String.format("[%s] login", userName);
				activity.setMsgParams(userName);
				break;
			case LOGOUT :
				//message = String.format("[%s] logout", userName);
				activity.setMsgParams(userName);
				break;
			case CONNECTED :
				//message = String.format("[%s] connected", userName);
				activity.setMsgParams(userName);
				break;
			case DISCONNECTED :
				//message = String.format("[%s] disconnected", userName);
				activity.setMsgParams(userName);
				break;
			case ASSIGNED :
				//message = String.format("[%s] activated", userName);
				activity.setMsgParams(userName);
				break;
			case UNASSIGNED :
				//message = String.format("[%s] inactivated", userName);
				activity.setMsgParams(userName);
				break;
			default : {	// UPDATED
				// Sync message size limit : 32K (picture image null processing)
				//user.setPicture(new Text("-"));
				activity.setSyncEntity(user);
				//message = String.format("[%s] updated user [%s]", userName, getDisplayUserName(user));
				activity.setMsgParams(userName, getDisplayUserName(user));
			}	break;
		}
		//activity.setMessage(Messages.getMessage(activity, null));
		return activity;
	}

	@Override
	public Activities createNoticeActivity(Notice notice, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
		Activities activity = new Activities(notice, activityType, loginUser);
		activity.setKindId(notice.getObjectId());
		activity.setShow(isShowActivity(activity));
		activity.setNotification(isNotificationTarget(activity));
		
		String boardTitle = DEFAULT_BOARD_NAME;
		if(NoticeKind.BOARDS.equals(notice.getNoticeKind()) && StringUtils.isNotBlank(notice.getNoticeId())) {
			activity.setLinkURL(CommonProperty.BOARD_LINK_URL + notice.getKindId());
			Boards board = boardService.getBoards(notice.getKindId());
			if (board != null) { boardTitle = board.getTitle(); }
		} else if (NoticeKind.SYSTEM.equals(notice.getNoticeKind())) {
			boardTitle = "SYSTEM NOTICE";
		}
		
		String userName = getDisplayUserName(loginUser);
		
		switch (activityType) {
			case ADDED :				
				//message = String.format("[%s] added Notice [%s] on [%s]", userName, notice.getTitle(), boardTitle);
				activity.setMsgParams(userName, notice.getTitle(), boardTitle);
				break;
			case SYSTEM_NOTICE_ADDED :				
				//message = String.format("[%s] added Notice [%s]", systemUserName, notice.getTitle());
				activity.setMsgParams(userName, notice.getTitle(), "SYSTEM NOTICE");
				break;
			case DELETED :
				//message = String.format("[%s] deleted Notice [%s] on [%s]", userName, notice.getTitle(), boardTitle);
				activity.setMsgParams(userName, notice.getTitle(), boardTitle);
				break;
			case SYSTEM_NOTICE_UPDATED :				
				//message = String.format("[%s] edited Notice [%s] on [%s]", userName, notice.getTitle(), boardTitle);
				activity.setMsgParams(userName, notice.getTitle(), "SYSTEM NOTICE");
				break;
			case UPDATED :
			default :
				//message = String.format("[%s] edited Notice [%s] on [%s]", userName, notice.getTitle(), boardTitle);
				activity.setMsgParams(userName, notice.getTitle(), boardTitle);
				break;
		}
		//activity.setMessage(Messages.getMessage(activity, null));
		return activity;
	}

	@Override
	public Activities createUsageActivity(Usage usage, Object refObj, ActivityType activityType) throws Exception {
		Activities activity = new Activities(usage, activityType);
		activity.setLinkURL(CommonProperty.DOMAIN_INFO_LINK_URL);
		activity.setShow(isShowActivity(activity));
		activity.setNotification(isNotificationTarget(activity));
		
		Domains domain = (Domains)refObj;
		//String userName = CommonProperty.SYSTEM_USER_NAME;

		switch (activityType) {
		case WARNING_OF_USERS_USAGE:
			Long userQuota = domain.getUserQuota();
			if (userQuota == null || userQuota == 0) { userQuota = CommonProperty.DEFAULT_USER_QUOTA; }
			long userUsagePercent = 100* usage.getUserCount() / userQuota;
			
			//message = String.format("[%s] 사용자 항목의 사용량이 %d%%를 넘었습니다.[%d/%d]", domain.getDomainName(), userUsagePercent, usage.getUserCount(), userQuota);
			activity.setMsgParams(domain.getDomainName(),
					Long.toString(userUsagePercent),
					Long.toString(usage.getUserCount()),
					Long.toString(userQuota));
			break;
		case WARNING_OF_STORAGE_USAGE:
			Long storageQuota = domain.getStorageQuota();
			if (storageQuota == null || storageQuota == 0) { storageQuota = CommonProperty.DEFAULT_STORAGE_QUOTA; }
			long storageUsagePercent = 100 * (usage.getBytes() + usage.getAttachmentBytes()) / storageQuota;
			//message = String.format("[%s] 스토리지 항목의 사용량이 %d%%를 넘었습니다.[%d/%d]", domain.getDomainName(), storageUsagePercent, (usage.getBytes() + usage.getAttachmentBytes()), storageQuota);
			activity.setMsgParams(
					domain.getDomainName(),
					Long.toString(storageUsagePercent),
					Long.toString((usage.getBytes() + usage.getAttachmentBytes())),
					Long.toString(storageQuota));
			break;
		case WARNING_OF_BOARDS_USAGE:
			Long boardQuota = domain.getBoardQuota();
			if (boardQuota == null || boardQuota == 0) { boardQuota = CommonProperty.DEFAULT_BOARD_QUOTA; }
			long boardUsagePercent = 100* usage.getBoardCount() / boardQuota;
			
			//message = String.format("[%s] 보드 항목의 사용량이 %d%%를 넘었습니다.[%d/%d]", domain.getDomainName(), boardUsagePercent, usage.getBoardCount(), boardQuota);
			activity.setMsgParams(domain.getDomainName(),
					Long.toString(boardUsagePercent),
					Long.toString(usage.getBoardCount()),
					Long.toString(boardQuota));
			break;
		case WARNING_OF_EXPIRATION:
			long diff = usage.getExpirationDate().getTime() - new Date().getTime();
			if (diff < 0) { diff = 0; }
//			long diff = Math.abs(usage.getExpirationDate().getTime() - new Date().getTime());
//			long diffDays = diff / (24 * 60 * 60 * 1000);
			
			Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
			cal.setTimeInMillis(diff);
			
//			message = String.format("[%s] 사용 종료일[%s]까지 앞으로 약 %02d일 %02d시 %02d분 정도 남았습니다.",
//					domain.getDomainName(),
//					CalendarUtil.toString(usage.getExpirationDate(), "yyyy-MM-dd HH:mm:ss"),
//					cal.get(Calendar.DAY_OF_YEAR) - 1,
//					cal.get(Calendar.HOUR_OF_DAY),
//					cal.get(Calendar.MINUTE)
//				);
			activity.setMsgParams(
					domain.getDomainName(),
					CalendarUtil.toString(usage.getExpirationDate(), "yyyy-MM-dd HH:mm:ss"),
					Integer.toString(cal.get(Calendar.DAY_OF_YEAR) - 1),
					Integer.toString(cal.get(Calendar.HOUR_OF_DAY)),
					Integer.toString(cal.get(Calendar.MINUTE)));
			break;
		default:
			// message = String.format("[%s] %s", userName,
			// activityType.toString());
			break;
		}
		//activity.setMessage(Messages.getMessage(activity, null));
		return activity;
	}

	@Override
	public int bulkRemoveActivities(
			String boardId,
			String kindId,
			ActivityKind activityKind,
			ActivityType activityType,
			String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			TypedQuery<Activities> query = new QueryBuilder<>(Activities.class)
					.addClause(FLD.deleteYN, null)
					.addClause(FLD.boardId, boardId)
					.addClause(FLD.kindId, kindId)
					.addClause(FLD.activityKind, activityKind)
					.addClause(FLD.activityType, activityType)
					.addClause(FLD.creator, userId)
					.build(mgr);

			List<Activities> results = queryResults(query);
			doRemoveTransaction(mgr, results);
			
			return results.size();
			// TODO bulkRemove시에도 activity를 남겨야 한다면..............................................
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void prepareNotification(Activities activity) throws UnavailableException, Exception {
		if (!activity.isNotification()) { return; }
		
		if (MainModule.serviceMode) {
			notificationService.prepareNotificationQueue(activity);
		} else {
			notificationService.prepareNotification(activity);
		}
	}
	
	private Activities setNotificationUserIds(EntityManager mgr, Activities activity) throws Exception {
		try {
			List<Users> notificationUserList = notificationService.getNotificationUsers(mgr, activity);
			List<String> notificationUserIds = new ArrayList<String>();
			
			for (Users user : notificationUserList) {
				notificationUserIds.add(user.getUserId());
			}
			
			//--> hyeunwoo.shim 2015-12-10 : included mention user
			for (String userId : activity.getMentionIds()) {
				if (!notificationUserIds.contains(userId)) { notificationUserIds.add(userId); }
			}
			//<--
			
			activity.setNotificationUserIds(notificationUserIds);
			return activity;
		} catch (Exception ex) { throw ex; }
	}
	
	@Override
	public boolean isShowActivity(Activities activity) {
		if (hiddenActivities.contains(join(activity.getActivityKind(), activity.getActivityType()))) {
			return false;
		}
		return true;
	}
	
	private boolean isNotificationTarget(Activities activity) {
		if (notiActivities.contains(join(activity.getActivityKind(), activity.getActivityType()))) {
			return true;
		}
		return false;
	}

	public static String getMentionedUserNames(List<String> userIdList) {
		try {
			if (userIdList == null || userIdList.isEmpty()) { return null; }
			List<String> params = new ArrayList<String>();
			Map<String, Users> usersMap = batchMapByKey(Users.class, userIdList);
			for (String userId : userIdList) {
				if (usersMap.containsKey(userId)) {
					params.add("@"+getDisplayUserName(usersMap.get(userId)));
				}
			}
			
			return StringUtils.join(params, ", ");
		} catch (Exception ex) {
			LOG.warning("[get mentioned user names error] : " + ex.getMessage());
			return null;
		}
	}
	public static String getMentionedUserNames(Activities activity) {
		return getMentionedUserNames(activity.getMentionIds());
	}
	public static String getTaskStage(String taskId) {
		if (StringUtils.isBlank(taskId)) { return null; }
		EntityManager mgr = getEntityManager();
		try {
			Tasks task = doFind(mgr, Tasks.class, taskId);
			if (task != null && StringUtils.isNotBlank(task.getTaskStage())) {
				Stages stage = doFind(mgr, Stages.class, KeyUtil.createStageKey(task.getTaskStage()));
				return stage.getTitle();
			} else {
				return null;
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	public static String toLocaleStageString(String message, Messages localeMessage) {
		for (TaskStage stage : TaskStage.values()) {
			message = message.replaceAll(stage.toString(), localeMessage.getSourceMessage(stage.toString()));
		}
		return message;
	}
	
//	public static String getMentionedUserNames(Activities activity) {
//		try {
//			switch (activity.getActivityKind()) {
//				case TASK_TIMELINES :
//					return getTaskTimelineMentionedUserName(activity);
//				case TASK_TIMELINE_COMMENTS :
//					return getTaskTimelineCommentMentionedUserName(activity);
//				default :
//					return null;
//			}
//		} catch (Exception ex) {
//			LOG.warning("[get mentioned user names error] : " + ex.getMessage());
//			return null;
//		}
//	}
//	private static String getTaskTimelineMentionedUserName(Activities activity) {
//		switch (activity.getActivityType()) {
//			case ADDED_WITH_MENTION :
//			case UPDATED_WITH_MENTION :
//			return activity.getMsgParams()[4];
//			default :
//				return null;
//		}
//	}
//	private static String getTaskTimelineCommentMentionedUserName(Activities activity) {
//		switch (activity.getActivityType()) {
//			case ADDED_WITH_MENTION :
//			case UPDATED_WITH_MENTION :
//			return activity.getMsgParams()[4];
//			default :
//				return null;
//		}
//	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public Activities createTaskChecklistCommentActivity(TaskChecklistComments taskChecklistComment, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			Activities activity = new Activities(taskChecklistComment, activityType, loginUser);
//			Boards board = boardService.getBoards(mgr, taskChecklistComment.getBoardId(), false);
//			Tasks task = taskService.getTasks(mgr, taskChecklistComment.getTaskId());
//			String userName = getDisplayUserName(loginUser);
//	
//			activity.setSyncEntity(taskChecklistComment);
//			activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + taskChecklistComment.getTaskId());
//			activity.setShow(isShowActivity(activity));
//			activity.setNotification(isNotificationTarget(activity));
//	
//			switch (activityType) {
//				case ADDED :
//					//message = String.format("[%s] added comment [%s] to Check list on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
//					activity.setMsgParams(userName, desc, task.getTitle(), board.getTitle());
//					break;
//				case DELETED :
//					//message = String.format("[%s] deleted comment [%s] to Check list on  [%s]  on [%s]", userName, desc, task.getTitle(), board.getTitle());
//					activity.setMsgParams(userName, desc, task.getTitle(), board.getTitle());
//					break;
//				case UPDATED :
//				default :
//					//message = String.format("[%s] edited comment [%s] to Check list on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
//					activity.setMsgParams(userName, desc, task.getTitle(), board.getTitle());
//					break;
//			}
//			activity.setMessage(Messages.getMessage(activity, null));
//			return activity;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Activities createTaskCommentActivity(TaskComments taskComment, Object refObj, ActivityType activityType, Users loginUser) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			Activities activity = new Activities(taskComment, activityType, loginUser);
//			Boards board = boardService.getBoards(mgr, taskComment.getBoardId(), false);
//			Tasks task = taskService.getTasks(mgr, taskComment.getTaskId());
//			String userName = getDisplayUserName(loginUser);
//	
//			activity.setSyncEntity(taskComment);
//			activity.setLinkURL(CommonProperty.WORKSPACE_LINK_URL + task.getTaskId());
//			activity.setShow(isShowActivity(activity));
//			activity.setNotification(isNotificationTarget(activity));
//	
//			switch (activityType) {
//				case ADDED :
//					//message = String.format("[%s] added comment [%s] to Wiki on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
//					activity.setMsgParams(userName, desc, task.getTitle(), board.getTitle());
//					break;
//				case DELETED :
//					//message = String.format("[%s] deleted comment [%s] to Wiki on [%s]  on [%s]", userName, desc, task.getTitle(), board.getTitle());
//					activity.setMsgParams(userName, desc, task.getTitle(), board.getTitle());
//					break;
//				case UPDATED :
//				default :
//					//message = String.format("[%s] edited comment [%s] to Wiki on [%s] on [%s]", userName, desc, task.getTitle(), board.getTitle());
//					activity.setMsgParams(userName, desc, task.getTitle(), board.getTitle());
//					break;
//			}
//			activity.setMessage(Messages.getMessage(activity, null));
//			return activity;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
