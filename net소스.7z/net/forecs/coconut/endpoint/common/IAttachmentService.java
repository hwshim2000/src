package net.forecs.coconut.endpoint.common;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.entity.attachment.Attachments;


public interface IAttachmentService extends ICommonService {
	public abstract String getUploadUrl(String filePath, String contentType, Integer expiresIn) throws Exception;
	public abstract String getDownloadUrl(String filePath, Integer expiresIn) throws Exception;
	public abstract String getDeleteUrl(String filePath, Integer expiresIn) throws Exception;

	public abstract Attachments getAttachments(String attachmentId) throws Exception;
	public abstract Attachments getAttachments(EntityManager mgr, String attachmentId) throws Exception;
	
	public abstract Attachments addChildAttachment(String parentId, Attachments attachment) throws Exception;
	public abstract List<Attachments> addChildAttachments(String parentId, List<Attachments> attachments) throws Exception;
	
	// TODO Remove this. Can be replaced with addTaskAttachment.
	public abstract Attachments addFinalAttachment(String parentId, String attachmentId) throws Exception;
	public abstract List<Attachments> updateChildAttachments(String parentId, List<Attachments> attachments) throws Exception;
	public abstract List<Attachments> markChildAttachments(String parentId, boolean archived, boolean deleted) throws Exception;
	public abstract Attachments removeChildAttachment(String parentId, String attachmentId) throws Exception;
	
	public abstract Attachments removeAttachments(String attachmentId) throws Exception;
	public abstract List<Attachments> removeChildAttachments(String parentId) throws Exception;

	public abstract List<Attachments> listAttachments(List<String> attachmentIdList) throws Exception;
	public abstract List<Attachments> listChildAttachments(String parentId) throws Exception;
	public abstract List<Attachments> listChildAttachments(EntityManager mgr, String parentId) throws Exception;
	
	public abstract Map<String, List<Attachments>> batchMapChildAttachments(EntityManager mgr, Collection<String> parentIds) throws Exception;

	public abstract void removeUploadedTrashFiles(Date date);
	public abstract void completeUploadedFile(String filePath);
	public abstract void deleteGcsFile(String filePath);
}
