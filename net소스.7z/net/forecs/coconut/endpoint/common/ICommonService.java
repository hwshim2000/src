package net.forecs.coconut.endpoint.common;


public interface ICommonService {
}
