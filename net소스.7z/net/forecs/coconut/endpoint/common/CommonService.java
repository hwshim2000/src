package net.forecs.coconut.endpoint.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.TypedQuery;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.AuthStatus;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.security.TokenService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Notifications;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.entity.billing.ServiceGrades;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.channel.WebHook;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.common.EMF;
import net.forecs.coconut.entity.domain.Departments;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.manage.Feedbacks;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.survey.SurveyAnswers;
import net.forecs.coconut.entity.survey.SurveyItems;
import net.forecs.coconut.entity.survey.SurveyQuestions;
import net.forecs.coconut.entity.tasklist.Tasklists;
import net.forecs.coconut.entity.user.UserDevices;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskHistories;
import net.forecs.coconut.entity.workspace.TaskLabelMap;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.guice.MainModule;
import net.forecs.coconut.security.TokenContext;
import net.forecs.coconut.shiro.ShiroUtils;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.ServiceException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.api.server.spi.response.ServiceUnavailableException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entities;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.google.appengine.datanucleus.query.JPACursorHelper;


public class CommonService implements ICommonService {
	private static final Logger LOG = Logger.getLogger(CommonService.class.getName());
	private static final int WAIT_COUNT = 5;
	private static final DatastoreService dsService = DatastoreServiceFactory.getDatastoreService();
	private static final int LIMITED_QUERY_CHUNKSIZE = 1000;
	public static final String Y = "Y";
	public static final String N = "N";
	
	private static final Set<Class<?>> useMemcacheKinds = new HashSet<Class<?>>();
	private static final Set<Class<?>> useMemcacheQueryKinds = new HashSet<Class<?>>();
	static {
		useMemcacheKinds.add(Users.class);
		useMemcacheKinds.add(UserDevices.class);
		useMemcacheKinds.add(UserProfiles.class);
		useMemcacheKinds.add(MemberAuths.class);
		useMemcacheKinds.add(Domains.class);
//		useMemcacheKinds.add(AdminEMailNotice.class);			/* 자주사용하는 것이 아니기에 Memcache에서 삭제함 */
		useMemcacheKinds.add(Boards.class);
		useMemcacheKinds.add(Groups.class);
		useMemcacheKinds.add(Tasks.class);
		useMemcacheKinds.add(Subscriptions.class);
		useMemcacheKinds.add(Tasklists.class);
		useMemcacheKinds.add(TaskLabels.class);
		useMemcacheKinds.add(TaskLabelMap.class);
		useMemcacheKinds.add(NotificationSettings.class);
		useMemcacheKinds.add(Attachments.class);
		useMemcacheKinds.add(AttachmentsMap.class);
		useMemcacheKinds.add(Images.class);
		useMemcacheKinds.add(Usage.class);
		useMemcacheKinds.add(UsageLogs.class);
//		useMemcacheKinds.add(Calendars.class);
		useMemcacheKinds.add(Events.class);
		useMemcacheKinds.add(Notice.class);
		useMemcacheKinds.add(UserSetting.class);
		useMemcacheKinds.add(TaskChecklists.class);
		useMemcacheKinds.add(TaskChecklistHistories.class);
//		useMemcacheKinds.add(TaskComments.class);			// deprecated
//		useMemcacheKinds.add(TaskChecklistComments.class);	// deprecated
		useMemcacheKinds.add(TaskTimelines.class);
		useMemcacheKinds.add(TaskTimelineComments.class);
//		useMemcacheKinds.add(TaskTimelineScores.class);		// deprecated
		useMemcacheKinds.add(TaskHistories.class);
		useMemcacheKinds.add(ChannelToken.class);
		useMemcacheKinds.add(Activities.class);
		useMemcacheKinds.add(Notifications.class);
		useMemcacheKinds.add(Stages.class);
		
		useMemcacheKinds.add(Bills.class);
		useMemcacheKinds.add(Customers.class);
		useMemcacheKinds.add(ServiceGrades.class);
		
		useMemcacheKinds.add(Auths.class);
		useMemcacheKinds.add(Tokens.class);
		useMemcacheKinds.add(WebHook.class);
		useMemcacheKinds.add(Departments.class);
		useMemcacheKinds.add(Emoticons.class);
		
		useMemcacheKinds.add(Feedbacks.class);
		
		useMemcacheKinds.add(SurveyQuestions.class);
		useMemcacheKinds.add(SurveyItems.class);
		useMemcacheKinds.add(SurveyAnswers.class);
		
		useMemcacheQueryKinds.add(MemberAuths.class);
		useMemcacheQueryKinds.add(Tasks.class);
		useMemcacheQueryKinds.add(TaskTimelines.class);
		useMemcacheQueryKinds.add(TaskTimelineComments.class);
		useMemcacheQueryKinds.add(Events.class);
		useMemcacheQueryKinds.add(UserProfiles.class);
		useMemcacheQueryKinds.add(TaskChecklists.class);
		useMemcacheQueryKinds.add(TaskLabelMap.class);
		useMemcacheQueryKinds.add(AttachmentsMap.class);
		useMemcacheQueryKinds.add(Stages.class);
	}
	
	public static EntityManager getEntityManager() {
		EntityManager mgr = EMF.get().createEntityManager();
		mgr.setFlushMode(FlushModeType.AUTO);
		
		return mgr;
	}
	public static void initEntityManager() {
		EntityManager mgr = getEntityManager();
		try {
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	public static EntityManager getEntityManagerEventualReads() {
//		EntityManager mgr = EMF.getEventualReads().createEntityManager();
//		mgr.setFlushMode(FlushModeType.AUTO);
//		
//		return mgr;
//	}
//	public static EntityManager getEntityManagerTransactionsOptional() {
//		EntityManager mgr = EMF.get().createEntityManager();
//		mgr.setFlushMode(FlushModeType.AUTO);
//		
//		return mgr;
//	}

	protected static void waitEntityForLazyFetch(List<?> objList) {
		if (objList == null) return;
		
		for (Object obj : objList) {
			waitEntityForLazyFetch((Base)obj);
		}
	}

	protected static <T extends Base> void waitEntityForLazyFetch(T base) {
		if (base == null) { return; }
		
		Key key = base.getKey();
		if (key == null) { return; }
		
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(key.getNamespace());

		try {
			Filter keyFilter = new FilterPredicate(Entity.KEY_RESERVED_PROPERTY, FilterOperator.EQUAL, key);
			Query q =  new Query().setFilter(keyFilter);
			
			int count = 1;
			int waitTime = 0;

			while(dsService.prepare(q).asList(FetchOptions.Builder.withDefaults()).size()==0 && count <= WAIT_COUNT) {
				Thread.sleep(count*count);
				waitTime += count*count;
				count++;
			};
			if (waitTime > 0) {
				StringBuilder sb = new StringBuilder();
				
				if (key.getParent() != null) {
					sb.append(String.format("\t>> Parnent:'%s', id:%d, name:%s\n", key.getParent().getKind(), key.getParent().getId(), key.getParent().getName()));
				}
				sb.append(String.format("\t>>Kind:'%s', id:%d, name:%s\n", key.getKind(), key.getId(), key.getName()));
				
				LOG.info(String.format("===[WAIT FOR PERSIST & INDEXING] : Total wait time is( %d )(millisecond).]===", waitTime));
				LOG.info(sb.toString());
			}
		} catch (Exception ex) {
			LOG.severe("WaitEntityForLazyFetch Error:"+ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	protected static <T extends Base> void waitEntityForLazyRemove(List<T> objList) {
		if (objList == null) return;
		
		for (Object obj : objList) {
			waitEntityForLazyRemove((Base)obj);
		}
	}
	protected static <T extends Base> void waitEntityForLazyRemoveById(List<String> idList) {
		if (idList == null) return;
		
		for (String id : idList) {
			waitEntityForLazyRemove(id);
		}
	}
	protected static <T extends Base> void waitEntityForLazyRemove(T base) {
		if (base == null) { return; }
		waitEntityForLazyRemove(base.getKey());
	}
	protected static <T extends Base> void waitEntityForLazyRemove(String id) {
		if (StringUtils.isBlank(id)) { return; }
		waitEntityForLazyRemove(KeyFactory.stringToKey(id));
	}
	protected static <T extends Base> void waitEntityForLazyRemove(Key key) {
		if (key == null) { return; }
		
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(key.getNamespace());
		
		try {
			Filter keyFilter = new FilterPredicate(Entity.KEY_RESERVED_PROPERTY, FilterOperator.EQUAL, key);
			Query q =  new Query().setFilter(keyFilter);

			int count = 1;
			int waitTime = 0;

			while(dsService.prepare(q).asList(FetchOptions.Builder.withDefaults()).size() > 0 && count <= WAIT_COUNT) {
				Thread.sleep(count*count);
				waitTime += count*count;
				count++;
			};
			if (waitTime > 0) {
				StringBuilder sb = new StringBuilder();
				
				if (key.getParent() != null) {
					sb.append(String.format("\t>> Parnent:'%s', id:%d, name:%s\n", key.getParent().getKind(), key.getParent().getId(), key.getParent().getName()));
				}
				sb.append(String.format("\t>>Kind:'%s', id:%d, name:%s\n", key.getKind(), key.getId(), key.getName()));
				
				LOG.info(String.format("===[WAIT FOR ENTITY REMOVE] : Total wait time is( %d )(millisecond).]===", waitTime));
				LOG.info(sb.toString());
			}
		} catch (Exception ex) {
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	public static <T extends Base> boolean contains(Class<T> clazz, String key) {
		return doFind(clazz, key) != null;
	}
	public static <T extends Base> boolean contains(Class<T> clazz, Key key) {
		return doFind(clazz, key) != null;
	}
	public static <T extends Base> boolean contains(EntityManager mgr, Class<T> clazz, String key) {
		return doFind(mgr, clazz, key) != null;
	}
	public static <T extends Base> boolean contains(EntityManager mgr, Class<T> clazz, Key key) {
		return doFind(mgr, clazz, key) != null;
	}
	
	public static QueryResult<Domains> listDomains(
			String cursorString,
			Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			return listDomains(mgr, cursorString, limit);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	public static List<Domains> listAllDomains(EntityManager mgr) throws Exception {
		return listDomains(mgr, null, null).getResultList();
	}
	public static QueryResult<Domains> listDomains(EntityManager mgr,
			String cursorString,
			Integer limit) throws Exception {
		try {
			DsQuery<Domains> dsQuery = new DsQuery<>(Domains.class)
				.cursor(cursorString)
				.limit(limit);
			
			List<Domains> results = dsQuery.execute(mgr);
			return new QueryResult<Domains>(results, dsQuery.getCursor());
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	protected static <T extends Base> List<T> queryResults(TypedQuery<T> query) throws Exception {
		if (query.getMaxResults() > LIMITED_QUERY_CHUNKSIZE/* || query.getMaxResults() == Integer.MAX_VALUE*/) {
			return listAllEntitiesForLimitedChunkSize(query);
		} else {
			return query.getResultList();
		}
	}
//	protected static <T extends Base> List<T> queryResults(Class<T> clazz, Query query) throws Exception {
//		List<Key> keys = listAllKeysForLimitedChunkSize(query);
//		return batchListByKey(clazz, keys);
//	}
//	protected static <T extends Base> List<T> queryResults(EntityManager mgr, Class<T> clazz, Query query) throws Exception {
//		return queryResults(mgr, clazz, query, null);
//	}
	public static <T extends Base> List<T> queryResults(EntityManager mgr, Class<T> clazz, Query query, FetchOptions fo) throws Exception {
		List<Key> keys = null;
		if (fo == null) {
			keys = listAllKeysForLimitedChunkSize(query);
		} else {
			keys = new ArrayList<Key>();
			
			List<Entity> results = dsService.prepare(query).asList(fo);
			for (Entity e : results) {
				keys.add(e.getKey());
			}
		}
		return batchListByKey(mgr, clazz, keys);
	}
//	public static <T extends Base> List<T> queryResults(EntityManager mgr, Class<T> clazz, DsQuery<T> dsQuery) throws Exception {
//		Query query = dsQuery.setKeysOnly();
//		FetchOptions fo = dsQuery.getFetchOptions();
//		List<Key> keys = null;
//		if (fo == null) {
//			keys = listAllKeysForLimitedChunkSize(query);
//		} else {
//			keys = new ArrayList<Key>();
//			
//			List<Entity> results = dsService.prepare(query).asList(fo);
//			for (Entity e : results) {
//				keys.add(e.getKey());
//			}
//		}
//		return batchListByKey(mgr, clazz, keys);
//	}

	protected static <T extends Base> T querySingleResults(TypedQuery<T> query) throws Exception {
		return query.getSingleResult();
	}
	protected static <T extends Base> List<T> queryResults(EntityManager mgr, Class<T> clazz, TypedQuery<Key> query) throws Exception {
		List<Key> keys = new ArrayList<Key>();
		
		if (query.getMaxResults() > LIMITED_QUERY_CHUNKSIZE /*|| query.getMaxResults() == Integer.MAX_VALUE*/) {
			keys = listAllKeysForLimitedChunkSize(query);
		} else {
			keys = query.getResultList();
		}
		
		return batchListByKey(mgr, clazz, keys);
	}
	protected static <T extends Base> T querySingleResults(EntityManager mgr, Class<T> clazz, TypedQuery<Key> query) throws Exception {
		Key key = query.getSingleResult();
		
		return doFind(mgr, clazz, key);
	}
//	protected static <T extends Base> T querySingleResults(EntityManager mgr, Class<T> clazz, DsQuery<T> dsQuery) throws Exception {
//		Query query = dsQuery.setKeysOnly();
//		Entity e = dsService.prepare(query).asSingleEntity();
//		if (e != null) { return doFind(mgr, clazz, e.getKey()); }
//		else { return null; }
//	}
	public static <T extends Base> T querySingleResults(EntityManager mgr, Class<T> clazz, Query query) throws Exception {
		Entity e = dsService.prepare(query).asSingleEntity();
		if (e != null) { return doFind(mgr, clazz, e.getKey()); }
		else { return null; }
	}
//	protected static <T extends Base> Long queryCount(DsQuery<T> dsQuery) {
//		Query query = dsQuery.setKeysOnly();
//		FetchOptions fo = FetchOptions.Builder.withDefaults();
//		int count = dsService.prepare(query).countEntities(fo);
//		
//		return new Long(count);
//	}
	public static <T extends Base> Long queryCount(Query query) {
		FetchOptions fo = FetchOptions.Builder.withDefaults();
		int count = dsService.prepare(query).countEntities(fo);
		
		return new Long(count);
	}
	
	public static <T extends Base> void valid(T obj) throws ServiceException {
		if (obj == null) { 
			throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage());
		}	
		
		if (obj.getClass().equals(Users.class)) {
			validUser((Users)obj);
		} else if (obj.getClass().equals(Boards.class)) {
			validBoards(obj);
		} else if (obj.getClass().equals(MemberAuths.class)) {
			validMemberAuth(obj);
		} else if (obj.getClass().getSuperclass().equals(Common.class)) {
			validCommon(obj);
		} else if (obj.getClass().getSuperclass().equals(Base.class)) {
			validBase(obj);
		}
	}
	
	public static <T extends Base> boolean isValid(T obj){
		try {
			valid(obj);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	private static <T extends Base> void validBase(T obj) throws ServiceException {
		if (Y.equals(obj.getDeleteYN())) {
			throw new ServiceUnavailableException(ErrorCode.UNAVAILABLE.getMessage(obj.getClass(), KeyFactory.keyToString(obj.getKey())));
		}
	}
	private static <T extends Base> void validBoards(T obj) throws ServiceException {
		validBase(obj);
		validCommon(obj);
		Boards board = (Boards)obj;
		if (Y.equals(board.getCloseYN())) {
			throw new ServiceUnavailableException(ErrorCode.UNAVAILABLE.getMessage(obj.getClass(), KeyFactory.keyToString(board.getKey())));
		}
	}
	private static <T extends Base>void validCommon(T obj) throws ServiceException {
		validBase(obj);
		Common common = (Common)obj;
		if (Y.equals(common.getArchiveYN()) || Y.equals(common.getPermanentDeleteYN())) {
			throw new ServiceUnavailableException(ErrorCode.UNAVAILABLE.getMessage(obj.getClass(), KeyFactory.keyToString(common.getKey())));
		}
	}
	private static <T extends Base> void validMemberAuth(T obj) throws ServiceException {
		validBase(obj);
		MemberAuths auth = (MemberAuths)obj;
		if (AuthStatus.INACTIVE.equals(auth.getAuthStatus())) {
			throw new ServiceUnavailableException(ErrorCode.UNAVAILABLE.getMessage(obj.getClass(), KeyFactory.keyToString(auth.getKey())));
		}
	}

	private static void validUser(Users user) throws ServiceException {
		if (user != null) {
			validBase(user);
		} else {
			throw new NotFoundException(ErrorCode.USER_NOT_FOUND.getMessage());
		}

		if (N.equals(user.getConfirmYN()) || !user.isValid()) { //|| Y.equals(user.getForcePasswordChangeYN())
			throw new ServiceUnavailableException(ErrorCode.UNAVAILABLE.getMessage(Users.class, user.getId()));
		}
	}
	
	public static String getDisplayUserName(Users user) {
		if (user == null) {
			return CommonProperty.SYSTEM_USER_NAME;
		} else if (StringUtils.isNotEmpty(user.getUserName())) {
			return user.getUserName();
		} else if (StringUtils.isNotEmpty(user.getNickName())) {
			return user.getNickName();
		} else {
			return user.getId();
		}
	}
	public static String getDisplayUserName(Users user, String defaultName) {
		if (user == null) {
			return defaultName;
		} else if (StringUtils.isNotEmpty(user.getUserName())) {
			return user.getUserName();
		} else if (StringUtils.isNotEmpty(user.getNickName())) {
			return user.getNickName();
		} else {
			return user.getId();
		}
	}
	
	public static List<String> listNamespaces() {
		Query q = new Query(Entities.NAMESPACE_METADATA_KIND);
		
		// Initialize result list
		List<String> results = new ArrayList<String>();

		// Build list of query results
		for (Entity e : dsService.prepare(q).asIterable()) {
			String namespace = Entities.getNamespaceFromNamespaceKey(e.getKey());
			if (StringUtils.isNotBlank(namespace)) {
				results.add(Entities.getNamespaceFromNamespaceKey(e.getKey()));
			}
		}
		return results;
	}

	public static List<String> listKinds(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		
		try {
			List<String> results = new ArrayList<String>();
			
			Query q = new Query(Entities.KIND_METADATA_KIND);
	
			for (Entity e : dsService.prepare(q).asIterable()) {
				String kind = e.getKey().getName();
				if (kind.indexOf("_") == 0) { continue; }
				//if (kind.indexOf("__") == 0) { continue; }
				//if (kind.indexOf("_AE") == 0) { continue; }
				//if (kind.indexOf("_GAE") == 0) { continue; }
				//if (kind.indexOf("_ah_") == 0) { continue; }
				results.add(kind);
			}
			
			return results;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	public static Map<String, List<String>> listProperties(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);

		try {
			Map<String, List<String>> propertyMap = new HashMap<String, List<String>>();
			// Create unrestricted keys-only property query
			//Query q = new Query(Entities.PROPERTY_METADATA_KIND).setKeysOnly();
			Query q = new Query(Entities.PROPERTY_METADATA_KIND);

			// Print query results
			for (Entity e : dsService.prepare(q).asIterable()) {
				String kind = e.getKey().getParent().getName();
				String property = e.getKey().getName();
				
				if (!propertyMap.containsKey(kind)) {
					propertyMap.put(kind, new ArrayList<String>());
				} 
				propertyMap.get(kind).add(property);
				
				//System.out.println(kind + ":" + property + ": " + e.getProperty("property_representation"));
//				LOG.warning(e.getKey().getNamespace() + ":"
//						+ e.getKey().getKind() + ":"
//						+ e.getKey().getParent().getName() + ": "
//						+ e.getKey().getName());
			}
			
			return propertyMap;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@SuppressWarnings("unchecked")
	public static Collection<String> representationsOfProperty(
			String namespace,
            String kind,
            String property) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		
		try {
			// Start with unrestricted non-keys-only property query
			Query q = new Query(Entities.PROPERTY_METADATA_KIND);
			
			// Limit to specified kind and property
			q.setFilter(new FilterPredicate("__key__",  Query.FilterOperator.EQUAL, Entities.createPropertyKey(kind, property)));
			
			// Get query result
			Entity propInfo = dsService.prepare(q).asSingleEntity();
			
			//LOG.warning(propInfo.getProperty("property_representation"));
			return (Collection<String>) propInfo.getProperty("property_representation");
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	public static <E> List<E> listAllEntitiesForLimitedChunkSize(TypedQuery<E> query) {
		Integer limit = LIMITED_QUERY_CHUNKSIZE;
		Cursor cursor = null;
		
		query.setFirstResult(0);
		query.setMaxResults(limit);

		List<E> totalResultList = new ArrayList<E>();
		List<E> resultList = query.getResultList();
		cursor = JPACursorHelper.getCursor(resultList);
		
		totalResultList.addAll(resultList);
		if (totalResultList.size() >= limit && cursor != null) {
			while (true) {
				cursor = JPACursorHelper.getCursor(resultList);
				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
				query.setFirstResult(0);
				query.setMaxResults(limit);
				
				resultList = query.getResultList();
				totalResultList.addAll(resultList);
				
				cursor = JPACursorHelper.getCursor(resultList);
				List<E> temp = new ArrayList<E>();
				temp.addAll(new ArrayList<E>(resultList));
				if (temp.size() != limit) { break; }
			}
			LOG.warning("[QueryForLimitedChunkSize] List All Entities Size : " + totalResultList.size());
		}
		
		return totalResultList;
	}
	
	protected static List<Key> listAllKeysForLimitedChunkSize(Query query) {
		Integer limit = LIMITED_QUERY_CHUNKSIZE;
		FetchOptions fo = FetchOptions.Builder.withChunkSize(LIMITED_QUERY_CHUNKSIZE);
		
		fo = fo.offset(0).limit(limit);

		List<Key> keys = new ArrayList<Key>();
		List<Entity> totalResults = new ArrayList<Entity>();
		List<Entity> results = dsService.prepare(query).asList(fo);
		
		totalResults.addAll(results);
		int nextResults = 0;
		if (totalResults.size() >= limit) {
			while (true) {
				fo = fo.offset((++nextResults)*limit).limit(limit);
				results = dsService.prepare(query).asList(fo);
				
				totalResults.addAll(results);
				if (results.size() != limit) { break; }
			}
			LOG.warning("[QueryForLimitedChunkSize] List All Keys Size : " + totalResults.size());
		}
		
		for(Entity e : totalResults) {
			keys.add(e.getKey());
		}
		
		return keys;
	}
	
	@SuppressWarnings("unchecked")
	protected static List<Key> listAllKeysForLimitedChunkSize(javax.persistence.Query query) {
		Integer limit = LIMITED_QUERY_CHUNKSIZE;
//		Cursor cursor = null;
		
		query.setFirstResult(0);
		query.setMaxResults(limit);

		List<Key> totalResultList = new ArrayList<Key>();
		List<Key> resultList = query.getResultList();
//		cursor = JPACursorHelper.getCursor(resultList);
		
		totalResultList.addAll(resultList);
		int nextResults = 0;
		if (totalResultList.size() >= limit) {
			while (true) {
//				cursor = JPACursorHelper.getCursor(resultList);
//				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
				query.setFirstResult((++nextResults)*limit);
				query.setMaxResults(limit);

				resultList = query.getResultList();
				totalResultList.addAll(resultList);
				
//				cursor = JPACursorHelper.getCursor(resultList);
				List<Key> temp = new ArrayList<Key>();
				temp.addAll(new ArrayList<Key>(resultList));
				if (temp.size() != limit) { break; }
			}
			LOG.warning("[QueryForLimitedChunkSize] List All Keys Size : " + totalResultList.size());
		}
		
		return totalResultList;
	}

	protected static void beginTransaction(EntityManager mgr) {
		beginTransaction(mgr, true);
	}
	protected static void beginTransaction(EntityManager mgr, boolean clear) {
		if (clear) { mgr.clear(); }
		EntityTransaction tx = mgr.getTransaction();
		if (tx != null && !tx.isActive()) { tx.begin(); }
	}
	protected static void commitTransaction(EntityManager mgr) {
		EntityTransaction tx = mgr.getTransaction();
		if (tx != null && tx.isActive()) { mgr.flush(); tx.commit(); }
	}
	
	protected static void doPersist(EntityManager mgr, Object... objs) {
		if (objs == null || objs.length == 0) { return; }
		for (Object obj : objs) {
//			if (isBaseClass(obj)) {
//				((Base)obj).setModified(((Base)obj).getCreated());
//			}
			if (obj != null) { mgr.persist(obj); putMemcache(obj); }
		}
	}
	protected static <T extends Base> void doPersist(EntityManager mgr, List<T> objs) {
		if (objs == null || objs.size() == 0) { return; }
		int txCount = 0;
		for (T obj : objs) {
//			if (isBaseClass(obj)) {
//				obj.setModified(obj.getCreated());
//			}
			if (obj != null) { mgr.persist(obj); putMemcache(obj); }
			if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) {
				commitTransaction(mgr);
				beginTransaction(mgr);
				txCount = 0;
			}
		}
	}
	@Deprecated
	private static <T extends Base> void doRemove(EntityManager mgr, Object... objs) {
		if (objs == null || objs.length == 0) { return; }
		for (Object obj : objs) {
			if (obj != null) {
				Object attachedObj = mgr.find(obj.getClass(), ((Base)obj).getObjectId());
				if (attachedObj != null) { mgr.remove(attachedObj); }
				removeMemcache(obj);
			}
		}
	}
	protected static <T extends Base> void doRemove(EntityManager mgr, List<T> objs) {
		if (objs == null || objs.size() == 0) { return; }
		int txCount = 0;
		for (T obj : objs) {
			if (obj != null) {
				Object attachedObj = mgr.find(obj.getClass(), obj.getObjectId());
				if (attachedObj != null) { mgr.remove(attachedObj); }
				removeMemcache(obj);
			}
			if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) {
				commitTransaction(mgr);
				beginTransaction(mgr, false);
				txCount = 0;
			}
		}
	}
	protected static <T extends Base> void doRemove(EntityManager mgr, Class<T> clazz, List<String> ids) {
		if (ids == null || ids.size() == 0) { return; }
		int txCount = 0;
		for (String id : ids) {
			if (StringUtils.isNotBlank(id)) {
				Object attachedObj = mgr.find(clazz, id);
				if (attachedObj != null) {
					mgr.remove(attachedObj);
					removeMemcache(attachedObj);
				}
			}
			if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) {
				commitTransaction(mgr);
				beginTransaction(mgr, false);
				txCount = 0;
			}
		}
	}
	@SuppressWarnings("unchecked")
	protected static <T extends Base> T[] doMerge(EntityManager mgr, T... objs) {
		if (objs == null || objs.length == 0) { return null; }
		for (T obj : objs) {
			if (isBaseClass(obj)) {
				obj.setModified(new Date());
			}
			if (obj != null) {
				putMemcache(obj);
				obj = retryMerge(mgr, obj);
				//obj = mgr.merge(obj);
			}
		}
		return objs;
	}
	protected static <T extends Base> List<T> doMerge(EntityManager mgr, List<T> objs) {
		if (objs == null || objs.size() == 0) { return null; }
		int txCount = 0;
		for (T obj : objs) {
			if (isBaseClass(obj)) {
				obj.setModified(new Date());
			}
			if (obj != null) {
				putMemcache(obj);
				obj = retryMerge(mgr, obj);
				//obj = mgr.merge(obj); 
			}
			if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) {
				commitTransaction(mgr);
				beginTransaction(mgr);
				txCount = 0;
			}
		}
		return objs;
	}
	
	protected static <T extends Base> T doMerge(EntityManager mgr, T obj) {
		return doMerge(mgr, obj, true);
	}
	protected static <T extends Base> T doMerge(EntityManager mgr, T obj, boolean isModified) {
		if (obj != null) {
			if (isModified && isBaseClass(obj)) {
				obj.setModified(new Date());
			}
			putMemcache(obj);
			obj = retryMerge(mgr, obj);
			//obj = mgr.merge(obj);
		}
		return obj;
	}
	private static <T extends Base> T retryMerge(EntityManager mgr, T obj) {
		int retryCount = 0;
		while(true) {
			try {
				obj = mgr.merge(obj);
				if (retryCount > 0) { LOG.warning("[ConcurrentModificationException] : retry count = " + retryCount); }
				return obj;
			} catch (ConcurrentModificationException ex) {	// too much contention on these datastore entities. please try again.
				try { Thread.sleep(retryCount); } catch (InterruptedException e) {}
				if (++retryCount > 10) { throw ex; }
			}
		}
	}
	protected static <T extends Base> void doPersist(EntityManager mgr, T obj) {
		if (obj != null) {
//			if (isBaseClass(obj)) {
//				obj.setModified(obj.getCreated());
//			}
			mgr.persist(obj);
			putMemcache(obj);
		}
	}
	protected static <T extends Base> void doRemove(EntityManager mgr, T obj) {
		if (obj != null) {
			Object attachedObj = mgr.find(obj.getClass(), obj.getObjectId());
			if (attachedObj != null) { mgr.remove(attachedObj);	}
			removeMemcache(obj);
		}
	}
	protected static <T extends Base> void doRemove(EntityManager mgr, Class<T> clazz, String id) {
		if (StringUtils.isNotBlank(id)) {
			Object attachedObj = mgr.find(clazz, id);
			if (attachedObj != null) {
				mgr.remove(attachedObj);
				removeMemcache(attachedObj); 
			}
		}
	}
	protected static <T extends Base> void doRemove(EntityManager mgr, Class<T> clazz, Key key) {
		if (key != null) {
			Object attachedObj = mgr.find(clazz, key);
			if (attachedObj != null) {
				mgr.remove(attachedObj);
				removeMemcache(attachedObj);
			}
		}
	}
	protected static void doPersistTransaction(EntityManager mgr, Object... objs) {
		if (objs == null || objs.length == 0) { return; }
		beginTransaction(mgr);
		doPersist(mgr, objs);
		commitTransaction(mgr);
//		waitEntityForLazyFetch(Arrays.asList(objs));
	}
	protected static <T extends Base> void doPersistTransaction(EntityManager mgr, List<T> objs) {
		if (objs == null || objs.size() == 0) { return; }
		beginTransaction(mgr);
		doPersist(mgr, objs);
		commitTransaction(mgr);
//		waitEntityForLazyFetch(objs);
	}
	@SuppressWarnings("unused")
	@Deprecated
	private static <T extends Base> void doRemoveTransaction(EntityManager mgr, Object... objs) {
		if (objs == null || objs.length == 0) { return; }
		beginTransaction(mgr, false);
		doRemove(mgr, objs);
		commitTransaction(mgr);
//		waitEntityForLazyRemove(Arrays.asList(objs));
	}
	protected static <T extends Base> void doRemoveTransaction(EntityManager mgr, List<T> objs) {
		if (objs == null || objs.size() == 0) { return; }
		beginTransaction(mgr, false);
		doRemove(mgr, objs);
		commitTransaction(mgr);
//		waitEntityForLazyRemove(objs);
	}
	protected static <T extends Base> void doRemoveTransaction(EntityManager mgr, Class<T> clazz, List<String> ids) {
		if (ids == null || ids.size() == 0) { return; }
		beginTransaction(mgr, false);
		doRemove(mgr, clazz, ids);
		commitTransaction(mgr);
//		waitEntityForLazyRemoveById(ids);
	}
	protected static <T extends Base> void doRemoveTransaction(EntityManager mgr, Class<T> clazz, String id) {
		if (StringUtils.isBlank(id)) { return; }
		beginTransaction(mgr, false);
		doRemove(mgr, clazz, id);
		commitTransaction(mgr);
//		waitEntityForLazyRemove(id);
	}
	protected static <T extends Base> void doRemoveTransaction(EntityManager mgr, Class<T> clazz, Key key) {
		if (key == null) { return; }
		beginTransaction(mgr, false);
		doRemove(mgr, clazz, key);
		commitTransaction(mgr);
//		waitEntityForLazyRemove(key);
	}
	@SuppressWarnings("unchecked")
	protected static <T extends Base> T[] doMergeTransaction(EntityManager mgr, T... objs) {
		if (objs == null || objs.length == 0) { return null; }
		beginTransaction(mgr);
		objs = doMerge(mgr, objs);
		commitTransaction(mgr);
		return objs;
	}
	protected static <T extends Base> List<T> doMergeTransaction(EntityManager mgr, List<T> objs) {
		if (objs == null || objs.size() == 0) { return null; }
		beginTransaction(mgr);
		objs = doMerge(mgr, objs);
		commitTransaction(mgr);
		return objs;
	}
	protected static <T extends Base> void doPersistTransaction(EntityManager mgr, T obj) {
		if (obj == null) { return; }
		beginTransaction(mgr);
		doPersist(mgr, obj);
		commitTransaction(mgr);
//		waitEntityForLazyFetch(obj);
	}
	protected static <T extends Base> T doMergeTransaction(EntityManager mgr, T obj) {
		return doMergeTransaction(mgr, obj, true);
	}
	protected static <T extends Base> T doMergeTransaction(EntityManager mgr, T obj, boolean isModified) {
		if (obj == null) { return null; }
		beginTransaction(mgr);
		obj = doMerge(mgr, obj, isModified);
		commitTransaction(mgr);
		return obj;
	}
	protected static <T extends Base> void doRemoveTransaction(EntityManager mgr, T obj) {
		if (obj == null) { return; }
		beginTransaction(mgr, false);
		doRemove(mgr, obj);
		commitTransaction(mgr);
		//waitEntityForLazyRemove(obj);
	}
	protected static void finalizeTransaction(EntityManager mgr) {
		if (mgr != null) {
			EntityTransaction tx = mgr.getTransaction();
			if (tx != null && tx.isActive()) { tx.rollback(); }
			mgr.clear();
			mgr.close();
		}
	}
	protected static void finalizeTransaction(EntityManager mgr, String prevNamespace) {
		finalizeTransaction(mgr);
		NamespaceManager.set(prevNamespace);
	}
	
	private static boolean isBaseClass(Object obj) {
		if (Common.class.equals(obj.getClass().getSuperclass()) ||
				Base.class.equals(obj.getClass().getSuperclass())) {
			return true;
		}
		return false;
	}

	protected static <T extends Base> List<T> batchListByField(Class<T> clazz, Collection<String> ids, String field) throws Exception {
		if (ids == null || ids.size() == 0) { return new ArrayList<T>(); }
		EntityManager mgr = getEntityManager();
		try {
			return batchListByField(mgr, clazz, ids, field);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	protected static <T extends Base> List<T> batchListByField(EntityManager mgr, Class<T> clazz, Collection<String> ids, String field) throws Exception {
		if (ids == null || ids.size() == 0) { return new ArrayList<T>(); }
		try {
			return new DsQuery<>(clazz).in(field, ids).execute(mgr);
		} catch (Exception ex) {
			throw ex;
		}
	}
	protected static <T extends Base> List<T> batchListByField(Class<T> clazz, String id, String field) throws Exception {
		if (StringUtils.isBlank(id)) { return new ArrayList<T>(); }
		EntityManager mgr = getEntityManager();
		try {
			return batchListByField(mgr, clazz, id, field);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	protected static <T extends Base> List<T> batchListByField(EntityManager mgr, Class<T> clazz, String id, String field) throws Exception {
		if (StringUtils.isBlank(id)) { return new ArrayList<T>(); }
		try {
			return new DsQuery<>(clazz).eq(field, id).execute(mgr);
		} catch (Exception ex) {
			throw ex;
		}
	}
	protected static <T extends Base> List<T> listAll(EntityManager mgr, Class<T> clazz) throws Exception {
		try {
			return new DsQuery<>(clazz).execute(mgr);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	public static Entity getEntity(Key key) {
    	try {
    		return dsService.get(key);
    	} catch (EntityNotFoundException ex) {
    		return null;
    	}
    }
	
	public static void validNamespace(Base base) throws UnavailableException {
		String currentNamespace = NamespaceManager.get();
    	Key key = base.getKey();
    	if (key == null) { return; }
    	validNamespace(currentNamespace, key.getNamespace());
    }
	
    public static void validNamespace(String keyStr) throws UnavailableException {
    	if (StringUtils.isBlank(keyStr)) { return; }
    	try {
	    	String currentNamespace = NamespaceManager.get();
	    	Key key = KeyFactory.stringToKey(keyStr);
	    	
	    	validNamespace(currentNamespace, key.getNamespace());
    	} catch (IllegalArgumentException ex) {
    		throw new UnavailableException(ErrorCode.ILLEGAL_PARAMETER.getMessage(ex.getMessage()));
    	}
    }
    
    public static void validNamespaceName(String namespaceName) throws UnavailableException {
    	if (StringUtils.isBlank(namespaceName)) { return; }
    	validNamespace(NamespaceManager.get(), namespaceName);
    }
    
    protected static void validNamespace(String currentNamespace, String requestNamespace) throws UnavailableException {
    	if (!StringUtils.equals(currentNamespace, requestNamespace)) {
	    	throw new UnavailableException(ErrorCode.INVALID_NAMESPACE.getMessage("Invalid namespace."));
	    }
    }
    
    protected static List<String> getNewMentions(List<String> originMentions, List<String> currentMentions) {
    	// If want to send all mention users notification
//    	return currentMentions;
    	
    	// If want to send new mention users notification
		List<String> newMentions = null;
		if (currentMentions == null) {
			newMentions = new ArrayList<String>();
		} else {
			newMentions = new ArrayList<String>(currentMentions);
		}
		
		if (originMentions != null) {
			newMentions.removeAll(originMentions);
		}
		
		return newMentions;
	}
    
    protected static <T extends Base> Map<String, T> batchMapByKey(Class<T> clazz, Collection<String> keyIds) throws Exception {
		if (keyIds == null || keyIds.size() == 0) { return new HashMap<String, T>(); }
		
		List<T> results = batchListByKey(clazz, keyIds);
		Map<String, T> resultMap = new HashMap<String, T>();
		for (T t : results) {
			String id = KeyFactory.keyToString(t.getKey());
			if (!resultMap.containsKey(id)) { resultMap.put(id, t); }
		}
		return resultMap;
	}
	protected static <T extends Base> Map<String, T> batchMapByKey(EntityManager mgr, Class<T> clazz, Collection<String> keyIds) throws Exception {
		if (keyIds == null || keyIds.size() == 0) { return new HashMap<String, T>(); }
		
		List<T> results = batchListByKey(mgr, clazz, keyIds);
		Map<String, T> resultMap = new HashMap<String, T>();
		for (T t : results) {
			String id = KeyFactory.keyToString(t.getKey());
			if (!resultMap.containsKey(id)) { resultMap.put(id, t); }
		}
		return resultMap;
	}
	protected static <T extends Base> List<T> batchListByKey(Class<T> clazz, Collection<String> keyIds) throws Exception {
		if (keyIds == null || keyIds.size() == 0) { return new ArrayList<T>(); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			return batchListByKey(mgr, clazz, keyIds);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	protected static <T extends Base> List<T> batchListByKey(Class<T> clazz, List<Key> keys) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return batchListByKey(mgr, clazz, keys);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	protected static <T extends Base> List<T> batchListByKey(EntityManager mgr, Class<T> clazz, Collection<String> keyIds) throws Exception {
		List<Key> keys = new ArrayList<Key>();
		for (String id : keyIds) {
			keys.add(KeyFactory.stringToKey(id));
		}
		return batchListByKey(mgr, clazz, keys);
	}
	protected static <T extends Base> List<T> batchListByKey(EntityManager mgr, Class<T> clazz, List<Key> keys) throws Exception {
		String currentNamespace = NamespaceManager.get();
		
		try {
			List<T> results = new ArrayList<T>();
			for (Key key : keys) {
				if (StringUtils.isBlank(currentNamespace) || StringUtils.equals(currentNamespace, key.getNamespace())) {
					T obj = doFind(mgr, clazz, key);
					if (obj != null) {
						results.add(obj);
					}
				}
			}

			return results;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
//	protected static <T extends Base> List<T> batchListByKey(EntityManager mgr, Class<T> clazz, Collection<String> keyIds) throws Exception {
//		if (keyIds == null || keyIds.size() == 0) { return new ArrayList<T>(); }
//		String currentNamespace = NamespaceManager.get();
//		
//		try {
//			List<T> results = new ArrayList<T>();
//			Map<String, T> resultMap = new HashMap<String, T>();
//			Map<String, T> memResults = getEntitiesFromMemcache(clazz, keyIds);
//			List<String> findTargetIds = new ArrayList<String>();
//			List<String> validIds = new ArrayList<String>();
//			
//			//if (memResults != null && memResults.size() > 0) { resultMap.putAll(memResults); }
//			
//			for (String id : keyIds) {
//				Key key = KeyFactory.stringToKey(id);
//				if (StringUtils.isBlank(currentNamespace) || StringUtils.equals(currentNamespace, key.getNamespace())) {
//					validIds.add(id);
//				}
//			}
//			if (memResults == null) {
//				findTargetIds.addAll(validIds);
//			} else {
//				resultMap.putAll(memResults);
//				for(String id : validIds) {
//					if (!memResults.containsKey(id)) {
//						findTargetIds.add(id);
//					}
//				}
//			}
//			if (findTargetIds.size() > 0) {
//				List<T> queryResults = new ArrayList<T>();
//				for (String id : findTargetIds) {
//					T obj = mgr.find(clazz, id);
//					if (obj != null) {
//						//--> 2016-05-03
//						mgr.detach(obj);
//						queryResults.add(obj);
//						resultMap.put(id, obj);
//					}
//				}
//				//--> 2016-05-03
//				//mgr.clear();
//				putEntitiesToMemcache(queryResults);
//			}
//			
//			// To sort in requiring order
//			for (String keyId : keyIds) {
//				T resObj = resultMap.get(keyId);
//				if (resObj != null) { results.add(resObj); }
//			}
//		
//			return results;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//    
    
    protected static <T extends Base> T doFindNoCache(EntityManager mgr, Class<T> clazz, Key key) {
    	return doFindNoCache(mgr, clazz, KeyFactory.keyToString(key));
	}
    protected static <T extends Base> T doFindNoCache(EntityManager mgr, Class<T> clazz, String keyId) {
    	return mgr.find(clazz, keyId);
    }
    
    protected static <T extends Base> T doFind(EntityManager mgr, Class<T> clazz, Key key) {
		return doFind(mgr, clazz, KeyFactory.keyToString(key));
	}
	protected static <T extends Base> T doFind(EntityManager mgr, Class<T> clazz, String keyId) {
    	if (useMemcacheKinds.contains(clazz)) {
    		T obj = MemcacheManager.get(keyId);
    	
			if (obj == null) {
				obj = mgr.find(clazz, keyId);
				if (obj != null) {
					//--> 2016-05-03
					mgr.detach(obj);
					//mgr.clear();
					MemcacheManager.put(obj.getObjectId(), obj);
				}
			}
			return obj;
    	} else {
    		return mgr.find(clazz, keyId);
    	}
	}
	public static <T extends Base> T doFind(Class<T> clazz, Key key) {
		return doFind(clazz, KeyFactory.keyToString(key));
	}
	public static <T extends Base> T doFind(Class<T> clazz, String keyId) {
		EntityManager mgr = getEntityManager();
		try {
	    	if (useMemcacheKinds.contains(clazz)) {
	    		T obj = MemcacheManager.get(keyId);
	    	
				if (obj == null) {
					obj = mgr.find(clazz, keyId);
					if (obj != null) {
						//--> 2016-05-03
						mgr.detach(obj);
						//mgr.clear();
						MemcacheManager.put(obj.getObjectId(), obj);
					}
				}
				return obj;
	    	} else {
	    		return mgr.find(clazz, keyId);
	    	}
		} finally {
			finalizeTransaction(mgr);
		}
	}
    protected static void putMemcache(Object obj) {
    	if (useMemcacheKinds.contains(obj.getClass())) {
			MemcacheManager.put(((Base)obj).getObjectId(), obj);
    	}
    	removeAllMemcacheForQueryResults(obj);
	}
    @SuppressWarnings("unused")
	private static <T extends Base> Map<String, T> getEntitiesFromMemcache(Class<T> clazz, Collection<String> keyIds) {
    	if (useMemcacheKinds.contains(clazz)) {
			return MemcacheManager.getAll(keyIds);
    	} else { return new HashMap<String, T>(); }
	}
    @SuppressWarnings("unused")
	private static <T extends Base> void putEntitiesToMemcache(Collection<T> objs) {
    	Map<String, T> valueMap = new HashMap<String, T>();
    	for (T obj : objs) {
	    	if (useMemcacheKinds.contains(obj.getClass())) {
				if (obj != null) {
					valueMap.put(obj.getObjectId(), obj);
				}
	    	}
    	}
    	MemcacheManager.putAll(valueMap);
	}

    private static void removeMemcache(Object obj) {
    	if (useMemcacheKinds.contains(obj.getClass())) {
	    	try {
		    	MemcacheManager.delete(((Base)obj).getObjectId());
	    	} catch (IllegalArgumentException ex) {
	    		LOG.warning(String.format("removeMemcache [%s %s] %s", NamespaceManager.get(), obj.getClass().getSimpleName(), ex.getMessage()));
	    	}
    	}
    	removeAllMemcacheForQueryResults(obj);
    }
    
    private static <T extends Base> void removeMemcache(T obj) {
    	if (useMemcacheKinds.contains(obj.getClass())) {
	    	try {
	    		MemcacheManager.delete(obj.getObjectId());
	    	} catch (IllegalArgumentException ex) {
	    		LOG.warning(String.format("removeMemcache [%s %s] %s", NamespaceManager.get(), obj.getClass().getSimpleName(), ex.getMessage()));
	    	}
    	}
    	removeAllMemcacheForQueryResults(obj);
    }
    
    private static void removeAllMemcacheForQueryResults(Object obj) {
    	if (useMemcacheQueryKinds.contains(obj.getClass())) {
    		if (TaskTimelines.class.equals(obj.getClass())) {
    			String taskId = ((TaskTimelines)obj).getTaskId();	// parent keySet
    			if (StringUtils.isNotBlank(taskId)) { MemcacheManager.removeAllMemcache(obj.getClass(), taskId); }
    		} else if (TaskTimelineComments.class.equals(obj.getClass())) {
    			String timelineId = ((TaskTimelineComments)obj).getTaskTimelineId();	// parent keySet
    			if (StringUtils.isNotBlank(timelineId)) { MemcacheManager.removeAllMemcache(obj.getClass(), timelineId); }
    		} else if (Tasks.class.equals(obj.getClass())) {
    			String boardId = ((Tasks)obj).getBoardId();	// parent keySet
    			if (StringUtils.isNotBlank(boardId)) { MemcacheManager.removeAllMemcache(obj.getClass(), boardId); }
    		} else if (MemberAuths.class.equals(obj.getClass())) {
    			String boardId = ((MemberAuths)obj).getBoardId();	// parent keySet
    			String kindId = ((MemberAuths)obj).getKindId();		// parent keySet
    			String userId = ((MemberAuths)obj).getUserId();		// parent keySet
    			if (StringUtils.isNotBlank(boardId)) { MemcacheManager.removeAllMemcache(obj.getClass(), boardId); }
    			if (StringUtils.isNotBlank(kindId)) { MemcacheManager.removeAllMemcache(obj.getClass(), kindId); }
    			if (StringUtils.isNotBlank(userId)) { MemcacheManager.removeAllMemcache(obj.getClass(), userId); }
    		} else if (Events.class.equals(obj.getClass())) {
    			String boardId = ((Events)obj).getBoardId();	// parent keySet
    			if (StringUtils.isNotBlank(boardId)) { MemcacheManager.removeAllMemcache(obj.getClass(), boardId); }
    		} else if (UserProfiles.class.equals(obj.getClass())) {
    			MemcacheManager.removeAllMemcache(Events.class, EventType.PRIVATE_ANNIVERSARY.toString());
    		} else if (TaskChecklists.class.equals(obj.getClass())) {
    			String boardId = ((TaskChecklists)obj).getBoardId();
    			String taskId = ((TaskChecklists)obj).getTaskId();
    			if (StringUtils.isNotBlank(boardId)) { MemcacheManager.removeAllMemcache(obj.getClass(), boardId); }
    			if (StringUtils.isNotBlank(taskId)) { MemcacheManager.removeAllMemcache(obj.getClass(), taskId); }
    		} else if (TaskLabelMap.class.equals(obj.getClass())) {
    			String taskId = ((TaskLabelMap)obj).getTaskId();
    			if (StringUtils.isNotBlank(taskId)) { MemcacheManager.removeAllMemcache(obj.getClass(), taskId); }
    		} else if (AttachmentsMap.class.equals(obj.getClass())) {
    			String kindId = ((AttachmentsMap)obj).getKindId();
    			String attachmentId = ((AttachmentsMap)obj).getAttachmentId();
    			if (StringUtils.isNotBlank(kindId)) { MemcacheManager.removeAllMemcache(obj.getClass(), kindId); }
    			if (StringUtils.isNotBlank(attachmentId)) { MemcacheManager.removeAllMemcache(obj.getClass(), attachmentId); }
    		} else if (Stages.class.equals(obj.getClass())) {
    			String boardId = ((Stages)obj).getBoardId();
    			if (StringUtils.isNotBlank(boardId)) { MemcacheManager.removeAllMemcache(obj.getClass(), boardId); }
    		}
    		
    		MemcacheManager.removeAllMemcache(obj.getClass());
    	}
//		String key = getMemcacheKey(obj.getClass());
//		mcs.delete(key);
    }
    
    protected static String join(ActivityType type) {
		return join("ALL", type.toString());
	}
    protected static String join(ActivityKind kind) {
		return join(kind.toString(), "ALL");
	}
    protected static String join(ActivityKind kind, ActivityType type) {
		return join(kind.toString(), type.toString());
	}
    protected static String join(String kind, String type) {
		return String.format("%s_%s", kind, type);
	}
    
    protected static Domains getCurrentDomain() {
    	EntityManager mgr = getEntityManager();
    	try {
    		return getCurrentDomain(mgr);
    	} finally {
    		finalizeTransaction(mgr);
    	}
	}
    protected static Domains getCurrentDomain(EntityManager mgr) {
    	String currentDomainName = NamespaceManager.get();
		return doFind(mgr, Domains.class, KeyUtil.createDomainKey(currentDomainName));
	}
    public static Users getCurrentUser() {
    	Users user = (Users)ShiroUtils.getCurrentUser();
		if (TokenService.ENABLE_TOKEN_USER) {
			if (user == null) {	user = getCurrentUserFromToken(); }
		}
		
		return user;
    }
    public static String getCurrentUserId() {
    	return getCurrentUserId(null);
    }
    public static String getCurrentUserId(String defaultValue) {
    	Users user = getCurrentUser();
    	if (user == null) { return defaultValue; }
    	return user.getUserId();
    }
    
    public static Users getCurrentUserFromToken() {
		// TODO : 2017-07-07
		// 만일, accessToken(Oauth등등)을 이용하여 로그인할 경우, 세션에 사용자 정보가 담겨 있지 않으므로
		// 현재 인스턴스에 accessToken을 이용하여 접근할시에 해당 사용자의 User 정보를 context에 저장하고,
		// 이부분에 저장된 사용자 정보를 꺼내 오도록 추가한다.
		return TokenContext.getCurrentUser();
	}
    
	protected static Domains getDomainFromDefaultNamespace(String domainName) {
		EntityManager mgr = getEntityManager();
		
		try {
			return getDomainFromDefaultNamespace(mgr, domainName);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	protected static Domains getDomainFromDefaultNamespace(EntityManager mgr, String domainName) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		try {
			return doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	protected static Domains getDomainFromUserNamespace(String domainName) {
		EntityManager mgr = getEntityManager();
		
		try {
			return getDomainFromUserNamespace(mgr, domainName);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	protected static Domains getDomainFromUserNamespace(EntityManager mgr, String domainName) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			return doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	public static void printDev(String str, int count) {
		if (MainModule.developmentServer) {
			StringBuilder sb = new StringBuilder(str.length()*count);
			for (int i=0; i < count; i++) {
				sb.append(str);
			}
			System.out.print(sb.toString());
		}
	}
	public static void printlnDev(String str, int count) {
		if (MainModule.developmentServer) {
			StringBuilder sb = new StringBuilder(str.length()*count);
			for (int i=0; i < count; i++) {
				sb.append(str);
			}
			System.out.println(sb.toString());
		}
	}
	public static void printDev(String msg) {
		if (MainModule.developmentServer) System.out.print(msg);
	}
	public static void printlnDev(String msg) {
		if (MainModule.developmentServer) System.out.println(msg);
	}
	public static void printDev(String subject, Object... msgs) {
		if (MainModule.developmentServer) {
			String str = StringUtils.join(msgs, ", ");
			System.out.print(String.format("[%s] %s", subject, str));
		}
	}
	public static void printlnDev(String subject, Object... msgs) {
		if (MainModule.developmentServer) {
			String str = StringUtils.join(msgs, ", ");
			System.out.println(String.format("[%s] %s", subject, str));
		}
	}
}
