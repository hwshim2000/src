package net.forecs.coconut.endpoint.common;

import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.admin.UsageService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.attachment.Uploads;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.BadRequestException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;


public class AttachmentService extends CommonService implements IAttachmentService {
	private static final Logger LOG = Logger.getLogger(AttachmentService.class.getName());
	
	private final IAttachmentMapService attachmentMapService;
	private final String site;
	
	@Inject
	public AttachmentService(IAttachmentMapService attachmentMapService, @Named(FLD.social_site) String site) {
		this.attachmentMapService = attachmentMapService;
		this.site = site;
	}

	@Override
	public String getUploadUrl(String filePath, String contentType, Integer expiresIn) throws Exception {
		//filePath = StringUtils.stripStart(filePath, "/");
		//String domainName = NamespaceManager.get();
		//if (StringUtils.isEmpty(domainName)) {
		//	objectName = filePath;
		//} else {
		//	objectName = domainName + "/" + filePath;
		//}
		String objectName = filePath;

		GcsSignedUrlUtil gcsUtils = new GcsSignedUrlUtil(site);
		String uploadUrl = gcsUtils.getUploadUrl(objectName, contentType, expiresIn);
		
		standbyUploadingFile(filePath);
		
		return uploadUrl;
	}
	
	@Override
	public String getDownloadUrl(String filePath, Integer expiresIn) throws Exception {
		//filePath = StringUtils.stripStart(filePath, "/");
		//String domainName = NamespaceManager.get();
		//if (StringUtils.isEmpty(domainName)) {
		//	objectName = filePath;
		//} else {
		//	objectName = domainName + "/" + filePath;
		//}
		String objectName = filePath;

		GcsSignedUrlUtil gcsUtils = new GcsSignedUrlUtil(site);
		return gcsUtils.getDownloadUrl(objectName, expiresIn);
	}

	// chulhong.kim 2015-05-26 : Added to support deleting attachment
	@Override
	public String getDeleteUrl(String filePath, Integer expiresIn) throws Exception {
		String objectName = filePath;

		GcsSignedUrlUtil gcsUtils = new GcsSignedUrlUtil(site);
		return gcsUtils.getDeleteUrl(objectName, expiresIn);
	}
	
	@Override
	public List<Attachments> listAttachments(List<String> attachmentIdList) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return listAttachments(mgr, attachmentIdList);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<Attachments> listAttachments(EntityManager mgr, List<String> attachmentIdList) throws Exception {
		List<Attachments> attachmentList = new ArrayList<Attachments>();
		List<Attachments> attachments = batchListByKey(mgr, Attachments.class, attachmentIdList);
		
		for (Attachments attachment : attachments) {
			if (attachment != null && isValid(attachment)) {
				attachmentList.add(attachment);
			}
		}
		
		return attachmentList;
	}

	@Override
	public Attachments getAttachments(String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getAttachments(mgr, attachmentId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Attachments getAttachments(EntityManager mgr, String attachmentId) throws Exception {
		if (StringUtils.isBlank(attachmentId)) { return null; }
		return doFind(mgr, Attachments.class, attachmentId);
	}

	@Override
	public Attachments removeAttachments(String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			List<AttachmentsMap> attachmentMappings = attachmentMapService.listAllAttachmentsMapByValue(mgr, attachmentId);
			Attachments attachments = getAttachments(mgr, attachmentId);
			if ((attachmentMappings != null) && (0 < attachmentMappings.size())) {
				// Do not delete attachment if any mapping exists.
				return attachments;
			}
			doRemoveTransaction(mgr, attachments);

			try {
				deleteGcsFile(attachments.getFilePath());
				UsageService.decreaseUsage(attachments);
			} catch (Exception ex) {}
			
			return attachments;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void deleteGcsFile(String filePath) {
		try {
			GcsSignedUrlUtil gcsUtils = new GcsSignedUrlUtil(site);
			String deleteUrl = gcsUtils.getSignedUrl("DELETE", filePath, null, null);
			LOG.info("DELETE Request URL : " + deleteUrl);
			URL url = new URL(deleteUrl);
			HttpURLConnection connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod("DELETE");
			int statusCode = connection.getResponseCode();
			LOG.info("DELETE Response code : " + statusCode);
			// TODO : Handle status code
			if (300 <= statusCode) {
				//renderResponse(connection.getInputStream());
			}
			connection.disconnect();
		} catch (Exception e) {
			// TODO : Handle exceptions
			LOG.warning("Exception while deleting the file : " + e);
		}
	}

	private Attachments insertAttachments(Attachments attachment) throws Exception {
		UsageService.validUsage(attachment);

		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();

			Key key = KeyUtil.createAttachmentKey(attachment);

			String filePath = attachment.getFilePath();
			attachment.setKey(key);
			attachment.setCreator(loginUser.getUserId());

			if (StringUtils.isNotBlank(filePath)) {
				String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
				attachment.setFileName(fileName);
			}

			if (contains(mgr, Attachments.class, attachment.getKey())) {
				throw new EntityExistsException("Object already exists");
			}

			doPersistTransaction(mgr, attachment);
			UsageService.increaseUsage(attachment);
			
			completeUploadedFile(filePath);
			
			return attachment;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@SuppressWarnings("unused")
	private Attachments updateAttachments(Attachments attachment) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Key attachmentKey = attachment.getKey();
			if (attachmentKey == null) {
				attachmentKey = KeyUtil.createAttachmentKey(attachment.getFilePath());
			}

			valid(attachment);

			String filePath = attachment.getFilePath();
			if (StringUtils.isNotBlank(filePath)) {
				String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
				attachment.setFileName(fileName);
			}

			doMergeTransaction(mgr, attachment);
			completeUploadedFile(filePath);
			return attachment;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Attachments> addChildAttachments(String parentId, List<Attachments> attachments) throws Exception {
		List<Attachments> attachmentList = new ArrayList<Attachments>();
		for (Attachments attachment : attachments) {
			attachmentList.add(addChildAttachment(parentId, attachment));
		}
		return attachmentList;
	}
	
	@Override
	public Attachments addChildAttachment(String parentId, Attachments attachment) throws Exception {
		if (attachment == null || StringUtils.isBlank(attachment.getFilePath())) {
			throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage(
    				"File path of the attachment should not be blank."));
		}

		String attachmentId = attachment.getAttachmentId();
		if (StringUtils.isEmpty(attachmentId)) {
			attachment = insertAttachments(attachment);
			attachmentId = attachment.getAttachmentId();
		}

		AttachmentsMap attachmentsMap = attachmentMapService.insertAttachmentsMap(parentId, attachmentId);
		return getAttachments(attachmentsMap.getAttachmentId());
	}

	@Override
	public Attachments addFinalAttachment(String parentId, String attachmentId) throws Exception {
		Attachments attachment = getAttachments(attachmentId);
		if (attachment == null) {
			throw new NotFoundException("Attachment not found : attachmentId=" + attachmentId);
		}
		return addChildAttachment(parentId, attachment);
	}

	@Override
	public List<Attachments> updateChildAttachments(String parentId, List<Attachments> attachments) throws Exception {
		List<String> attachmentIds = new ArrayList<String>();
		for (Attachments attachment : attachments) {
			attachmentIds.add(attachment.getAttachmentId());
		}

		List<AttachmentsMap> attachmentsMapList = attachmentMapService.updateAttachmentsMap(parentId, attachmentIds);

		List<String> attachmentIdList = new ArrayList<String>();
		for (AttachmentsMap map : attachmentsMapList) {
			attachmentIdList.add(map.getAttachmentId());
		}
		return listAttachments(attachmentIdList);
	}
	
	@Override
	public List<Attachments> markChildAttachments(String parentId, boolean archived, boolean deleted) throws Exception {
		List<AttachmentsMap> attachmentsMapList = attachmentMapService.markAttachmentsMap(parentId, archived, deleted);
		List<String> attachmentIdList = new ArrayList<String>();
		for (AttachmentsMap map : attachmentsMapList) {
			attachmentIdList.add(map.getAttachmentId());
		}
		return listAttachments(attachmentIdList);
	}

	@Override
	public Attachments removeChildAttachment(String parentId, String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Attachments attachment = getAttachments(mgr, attachmentId);
			if (attachment == null) {
				LOG.warning("Attachment not found : attachmentId=" + attachmentId);
				//throw new NotFoundException("Attachment not found : attachmentId=" + attachmentId);
			}
	
			//-->
			// hyeunwoo.shim 2015-07-03 : Remove relevant link if linked count is larger than 2.
			int linkCount = countAttachmentLink(mgr, attachmentId);
			attachmentMapService.removeAttachmentsMap(parentId, attachmentId);
//			waitEntityForLazyRemove(removedAttachmentsMap);
			
			if (attachment != null && linkCount <= 1) {
				attachment = removeAttachments(attachmentId);
			}
	
			return attachment;
			//attachmentMapService.removeAttachmentsMap(parentId, attachmentId);
			//return removeAttachments(attachmentId);
			//<--
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private int countAttachmentLink(EntityManager mgr, String attachmentId) {
		try {
			int linkCount = 0;
			List<AttachmentsMap> attachmentsMapList = attachmentMapService.listAllAttachmentsMapByValue(mgr, attachmentId);
			if (attachmentsMapList != null) { linkCount = attachmentsMapList.size(); }
			return linkCount;
		} catch (Exception ex) { return 0;}
	}

//	@Override
//	public List<Attachments> removeTaskAttachments(List<String> taskIds) throws Exception {
//		List<Attachments> results = new ArrayList<Attachments>();
//		for (String taskId : taskIds) {
//			results.addAll(removeChildAttachments(taskId));
//		}
//		return results;
//	}

	@Override
	public List<Attachments> removeChildAttachments(String parentId) throws Exception {
		List<Attachments> attachmentList = new ArrayList<Attachments>();
		List<AttachmentsMap> attachmentsMapList = attachmentMapService.removeAttachmentsMap(parentId);
		for (AttachmentsMap attachmentsMap : attachmentsMapList) {
			String attachmentId = attachmentsMap.getAttachmentId();
			Attachments attachment = removeAttachments(attachmentId);
			attachmentList.add(attachment);
		}
		return attachmentList;
	}

	@Override
	public List<Attachments> listChildAttachments(String parentId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return listChildAttachments(mgr, parentId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<Attachments> listChildAttachments(EntityManager mgr, String parentId) throws Exception {
		List<AttachmentsMap> attachmentsMapList = attachmentMapService.listAttachmentsMap(mgr, parentId);
		List<String> attachmentIdList = new ArrayList<String>();
		for (AttachmentsMap map : attachmentsMapList) {
			attachmentIdList.add(map.getAttachmentId());
		}
		return listAttachments(attachmentIdList);
	}
	
	@SuppressWarnings("unused")
	private List<Attachments> batchListChilldAttachments(EntityManager mgr, String parentId) throws Exception {
		List<String> parentIds = new ArrayList<String>();
		parentIds.add(parentId);
		return batchMapChildAttachments(mgr, parentIds).get(parentId);
	}
	
	@Override
	public Map<String, List<Attachments>> batchMapChildAttachments(EntityManager mgr, Collection<String> parentIds) throws Exception {
		// 1. 부모 ID 목록에 포함된 모든 attachmentMap 데이터를 가져온다.
		List<AttachmentsMap> attachmentsMapList = batchListByField(mgr, AttachmentsMap.class, parentIds, FLD.kindId);
		Map<String, List<Attachments>> attachmentsListMap = new HashMap<String, List<Attachments>>();
		
		List<String> attachmentIdList = new ArrayList<String>();
		Map<String, List<String>> attachmentIdListMap = new HashMap<String, List<String>>();
		
		// 2. 가져온 모든 attachmentMap에서  attachment ID 리스트를 만들고, 각 attachment의 부모(kindId) map을 만든다.
		for (AttachmentsMap map : attachmentsMapList) {
			attachmentIdList.add(map.getAttachmentId());
			if (!attachmentIdListMap.containsKey(map.getKindId())) { attachmentIdListMap.put(map.getKindId(), new ArrayList<String>()); }
			attachmentIdListMap.get(map.getKindId()).add(map.getAttachmentId());
		}
		
		// 3. attachmentID 리스트에 해당하는 모든 attachment를 가져온다.
		List<Attachments> results = listAttachments(mgr, attachmentIdList);
		Map<String, Attachments> resultsMap = new HashMap<String, Attachments>();
		
		// 4. attachment ID 에 대응하는 map 데이터를 만든다.
		// (AttachmentsMap과는 별개의 값이다. 나중에 각 kind(parent)에 해당하는 attachment를 찾아서 넣어주기 위한 map 데이터이다)
		for (Attachments attachment : results) {
			if (!resultsMap.containsKey(attachment.getAttachmentId())) { resultsMap.put(attachment.getAttachmentId(), attachment); }
		}
		 
		// 5. kindId - attachments ID List 에 mapping
		// 2단계에서 만든 attachmentIdListMap을 순환하면서 kindId에 대응하는 살제 attachment를 찾아 넣어준다.
		
		for (Map.Entry<String, List<String>> entry : attachmentIdListMap.entrySet()) {
			String key = entry.getKey();
			if (!attachmentsListMap.containsKey(key)) { attachmentsListMap.put(key, new ArrayList<Attachments>()); }
			for (String val : entry.getValue()) {
				Attachments attachment = resultsMap.get(val);
				if (attachment != null) { attachmentsListMap.get(key).add(attachment); }
			}
		}
		
		// 6. 최종으로 kindID별 attachment List를 리턴한다.
		return attachmentsListMap;
	}
	
	private void standbyUploadingFile(String filePath) {
		if (StringUtils.isBlank(filePath)) { return; }
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			String uploadPath = URLDecoder.decode(filePath, CommonProperty.UTF_8);
			Key key = KeyUtil.createUploadKey(uploadPath);
			Uploads upload = new Uploads();
			upload.setKey(key);
			upload.setFilePath(filePath);
			
			doPersistTransaction(mgr, upload);
		} catch (Exception e) {
			LOG.warning("Upload standby error : " + e.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public void completeUploadedFile(String filePath) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			String uploadPath = URLDecoder.decode(filePath, CommonProperty.UTF_8);
			Key key = KeyUtil.createUploadKey(uploadPath);
			
			doRemoveTransaction(mgr, Uploads.class, key);
			//removeTrashUploads(mgr, CalendarUtil.addDay(new Date(), -1));
		} catch (Exception e) {
			LOG.warning("Upload complete error : " + e.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void removeUploadedTrashFiles(Date date) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
			
		try {
			removeUploadedTrashFiles(mgr, date);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private void removeUploadedTrashFiles(EntityManager mgr, Date date) {
		try {
			if (date == null) { date = new Date(); }
			DsQuery<Uploads> dsQuery = new DsQuery<>(Uploads.class)
					.lt(FLD.created, date);
					//.lt(FLD.created, new Date());

			List<Uploads> results = dsQuery.execute(mgr);
			for (Uploads upload : results) {
				deleteGcsFile(upload.getFilePath());
				doRemoveTransaction(mgr, upload);
			}
		} catch (Exception e) {
			LOG.warning("Remove all trash files error : " + e.getMessage());
		}
	}

	public static class GcsSignedUrlUtil {
//		private static final Logger LOG = Logger.getLogger(GcsSignedUrlUtil.class.getName());
		//private static final String SERVICE_ACCOUNT_EMAIL = "1042066804754-fqhu6keiaa9m6hh5iu429cqd04f57u13@developer.gserviceaccount.com";
		//private static final String SERVICE_ACCOUNT_PKCS12_FILE_PATH = "WEB-INF/CoCoWorks_Service_Account_Key.p12";
		//private static final String SERVICE_ACCOUNT_EMAIL = "679798256317-3i9bupu89tjr4a710kkmmd0dn1r2vq9v@developer.gserviceaccount.com";
		//private static final String SERVICE_ACCOUNT_PKCS12_FILE_PATH = "WEB-INF/CoCoNut_Service_Account_Key.p12";
		
		public static final String LIVE_BUCKET_NAME = "cocoworks-task-attachments";
		public static final String DEV_BUCKET_NAME = "cocoworks-task-attachments-for-dev";
		public static final String EMOTICON_BUCKET_NAME = "cocoworks-emoticons";
		public static final String EMOTICONS_SITE = "emoticons";
		
//		public static final String LIVE_BUCKET_NAME = "cocoworks-for-ecs.appspot.com";
//		public static final String DEV_BUCKET_NAME = "cocoworks-for-ecs.appspot.com";
		
		private final String bucketName;
		//private static final String BUCKET_NAME = "coconut-task-attachments";
		public GcsSignedUrlUtil(String site) {
			if (StringUtils.isNotEmpty(site) && "live".equals(site)) { bucketName = LIVE_BUCKET_NAME; }
			else if (StringUtils.equals(EMOTICONS_SITE, site)) { this.bucketName = EMOTICON_BUCKET_NAME; }
			else { bucketName = DEV_BUCKET_NAME; }
		}

		//		public GcsSignedUrlUtil() {
//			try {
//				String objectName = "test/somerandomfile.txt";
//				int expiresIn = 60;
//
//				LOG.warning("======= PUT File =========");
//				String put_url = getSignedUrl("PUT", objectName, null, expiresIn);
//
//				URL url = new URL(put_url);
//				HttpURLConnection httpCon = (HttpURLConnection)url.openConnection();
//				httpCon.setDoOutput(true);
//				httpCon.setRequestMethod("PUT");
//				OutputStreamWriter out = new OutputStreamWriter(httpCon.getOutputStream());
//				out.write("Lorem ipsum");
//				out.close();
//
//				LOG.warning("PUT Request URL: " + put_url);
//				LOG.warning("PUT Response code: " + httpCon.getResponseCode());
//				renderResponse(httpCon.getInputStream());
//
//				LOG.warning("======= GET File =========");
//
//				String get_url = getSignedUrl("GET", objectName, null, expiresIn);
//				url = new URL(get_url);
//				httpCon = (HttpURLConnection)url.openConnection();
//				httpCon.setRequestMethod("GET");
//
//				LOG.warning("GET Request URL " + get_url);
//				LOG.warning("GET Response code: " + httpCon.getResponseCode());
//				renderResponse(httpCon.getInputStream());
//
//				LOG.warning("======= DELETE File ======");
//
//				String delete_url = getSignedUrl("DELETE", objectName, null, expiresIn);
//				url = new URL(delete_url);
//				httpCon = (HttpURLConnection)url.openConnection();
//				httpCon.setRequestMethod("DELETE");
//
//				LOG.warning("DELETE Request URL " + get_url);
//				LOG.warning("DELETE Response code: " + httpCon.getResponseCode());
//				renderResponse(httpCon.getInputStream());
//			} catch (Exception e) {
//				LOG.warning("Error : " + e);
//			}
//		}
//
//		private void renderResponse(InputStream is) throws Exception {
//			BufferedReader in = new BufferedReader(new InputStreamReader(is));
//			String inputLine;
//			while ((inputLine = in.readLine()) != null)
//				LOG.warning(inputLine);
//			in.close();
//		}

		public String getUploadUrl(String objectName, String contentType, Integer expiresIn) throws Exception {
			return getSignedUrl("PUT", objectName, contentType, expiresIn);
		}

		public String getDownloadUrl(String objectName, Integer expiresIn) throws Exception {
			return getSignedUrl("GET", objectName, "", expiresIn);
		}

		public String getDeleteUrl(String objectName, Integer expiresIn) throws Exception {
			return getSignedUrl("DELETE", objectName, "", expiresIn);
		}
		
		public String getSignedUrl(String httpVerb, String objectName, String contentType, Integer expiresIn)
				throws Exception {
			String contentMd5 = "";
			if (contentType == null) {
				contentType = "";
			}
			if (expiresIn == null) {
				expiresIn = 3 * 60;	// 3 minutes
			}
			final long expiration = System.currentTimeMillis() / 1000 + expiresIn;
			String extensionHeaders = "";

			// chulhong.kim 2016-04-07 : Revert encoding for the '~' to fix file uploading issue
			//objectName = URLEncoder.encode(objectName, CommonProperty.UTF_8);
			objectName = URLEncoder.encode(objectName, CommonProperty.UTF_8).replace("%7E", "~");

			// Refer to https://cloud.google.com/storage/docs/accesscontrol#Construct-the-String
			String stringToSign = httpVerb + "\n"				// Required
					+ contentMd5 + "\n"							// Optional
					+ contentType + "\n"						// Optional
					+ expiration + "\n"							// Required
					+ extensionHeaders							// Optional
					+ "/" + bucketName + "/" + objectName;		// Required

			String signature = signString(stringToSign);
			String signedUrl = "https://storage.googleapis.com/" + bucketName + "/" + objectName
					+ "?GoogleAccessId=" + CommonProperty.SERVICE_ACCOUNT_EMAIL
					+ "&Expires=" + expiration
					+ "&Signature=" + URLEncoder.encode(signature, CommonProperty.UTF_8);
			
			return signedUrl;
		}

		private static PrivateKey loadKeyFromPkcs12(String filename, char[] password) throws Exception {
			FileInputStream fis = new FileInputStream(filename);
			KeyStore ks = KeyStore.getInstance("PKCS12");
			ks.load(fis, password);
			return (PrivateKey)ks.getKey("privatekey", password);
		}

		private static String signString(String stringToSign) throws Exception {
			PrivateKey key = loadKeyFromPkcs12(CommonProperty.SERVICE_ACCOUNT_PKCS12_FILE_PATH, "notasecret".toCharArray());
			if (key == null) {
				throw new Exception("Private Key not initalized");
			}

			Signature signer = Signature.getInstance("SHA256withRSA");
			signer.initSign(key);
			signer.update(stringToSign.getBytes(StandardCharsets.UTF_8));
			byte[] rawSignature = signer.sign();
			return new String(Base64.encodeBase64(rawSignature, false), StandardCharsets.UTF_8);
		}
	}
}
