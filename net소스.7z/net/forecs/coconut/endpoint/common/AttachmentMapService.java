package net.forecs.coconut.endpoint.common;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.AttachmentIndex;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


public class AttachmentMapService extends CommonService implements IAttachmentMapService {
	private static final Logger LOG = Logger.getLogger(AttachmentMapService.class.getName());
	
	private final IAttachmentService attachmentService;
	private final IAttachmentMapService attachmentMapService;
	
	@Inject
	public AttachmentMapService(IAttachmentService attachmentService, IAttachmentMapService attachmentMapService) {
		this.attachmentService = attachmentService;
		this.attachmentMapService = attachmentMapService;
		
	}

	@Override
	public List<AttachmentsMap> listAttachmentsMap(EntityManager mgr, String kindId) throws Exception {
		return listAttachmentsMap(mgr, kindId, null, N);
	}

	private List<AttachmentsMap> listAllAttachmentsMap(EntityManager mgr, String kindId) throws Exception {
		return listAttachmentsMap(mgr, kindId, null, null);
	}

	@Override
	public List<AttachmentsMap> listAllAttachmentsMapByValue(EntityManager mgr, String attachmentId) throws Exception {
		return listAttachmentsMap(null, attachmentId, null);
	}

	private List<AttachmentsMap> listAttachmentsMap(
			String kindId,
			String attachmentId,
			String archiveYN) throws Exception{
		EntityManager mgr = getEntityManager();
		try {
			return listAttachmentsMap(mgr, kindId, attachmentId, archiveYN);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<AttachmentsMap> listAttachmentsMap(
			EntityManager mgr,
			String kindId,
			String attachmentId,
			String archiveYN) throws Exception{
		try {
			String keySet = null;
			if (StringUtils.isNotBlank(kindId)) { keySet = MemcacheManager.keySet(kindId); }
			else { keySet = MemcacheManager.keySet(attachmentId); }
 			
			MemcacheManager<AttachmentsMap, List<AttachmentsMap>> mm = new MemcacheManager<>(AttachmentsMap.class, keySet);
			String memcacheKey = mm.createMemcacheKey(kindId, attachmentId, archiveYN);
			List<AttachmentsMap> attachmentsMapList = mm.getMemcache(memcacheKey);
			if (attachmentsMapList == null) {
				DsQuery<AttachmentsMap> dsQuery = new DsQuery<>(AttachmentsMap.class)
						.eq(FLD.deleteYN, N)
						.eq(FLD.kindId, kindId)
						.eq(FLD.attachmentId, attachmentId)
						.eq(FLD.archiveYN, archiveYN);
				attachmentsMapList = dsQuery.execute(mgr);
				mm.setMemcache(memcacheKey, attachmentsMapList);
			}
			return attachmentsMapList;
		} catch (Exception e) {
			throw e;
		}
	}

	@SuppressWarnings("unused")
	private AttachmentsMap getAttachmentsMap(String attachmentMapId) throws Exception {
		if (StringUtils.isBlank(attachmentMapId)) { return null; }
		else { return getAttachmentsMap(KeyFactory.stringToKey(attachmentMapId)); }
	}
	
	private AttachmentsMap getAttachmentsMap(Key attachmentMapKey) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, AttachmentsMap.class, attachmentMapKey);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public AttachmentsMap insertAttachmentsMap(String parentId, String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			beginTransaction(mgr);
			AttachmentsMap attachmentsMap = insertAttachmentsMap(mgr, parentId, attachmentId);
			commitTransaction(mgr);

			createOrUpdateAttachmentIndex(attachmentsMap);
			
			return attachmentsMap;
		}  catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private AttachmentsMap insertAttachmentsMap(EntityManager mgr, String parentId, String attachmentId) throws Exception {
		AttachmentsMap attachmentMap = new AttachmentsMap(parentId, attachmentId);
		if (containsAttachmentsMap(mgr, attachmentMap)) {
			throw new EntityExistsException("Object already exists");
		}

		Key Key = KeyUtil.createAttachmentMapKey(parentId, attachmentId);
		attachmentMap.setKey(Key);

		doPersist(mgr, attachmentMap);
		
		return attachmentMap;
	}

	@Override
	public List<AttachmentsMap> updateAttachmentsMap(String parentId, List<String> attachmentIds) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			List<AttachmentsMap> attachmentMapListToRemove = new ArrayList<AttachmentsMap>(listAllAttachmentsMap(mgr, parentId));
			List<AttachmentsMap> attachmentMapList = new ArrayList<AttachmentsMap>();

			int txCount = 0;
			beginTransaction(mgr, false);
			for (String attachmentId : attachmentIds) {
				AttachmentsMap attachmentMap = null;
				for (AttachmentsMap mapToRemove : attachmentMapListToRemove) {
					if (mapToRemove.getAttachmentId().equals(attachmentId)) {
						attachmentMap = mapToRemove;
						break;
					}
				}

				if (attachmentMap != null) {
					attachmentMapListToRemove.remove(attachmentMap);	// Keep the same attachment
				} else {
					attachmentMap = insertAttachmentsMap(mgr, parentId, attachmentId);
					if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) { txCount = 0; commitTransaction(mgr); beginTransaction(mgr); }
				}

				attachmentMapList.add(attachmentMap);
			}

			for (AttachmentsMap map : attachmentMapListToRemove) {
				doRemove(mgr, map); 
				if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) { txCount = 0; commitTransaction(mgr); beginTransaction(mgr); }
			}
			commitTransaction(mgr);
			
			return attachmentMapList;
		}  catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public void removeAttachmentsMap(String parentId, String attachmentId) {
		LOG.warning(String.format("[INFO-removeAttachmentsMap] %s %s", parentId, attachmentId));
		Key attachmentMapKey = KeyUtil.createAttachmentMapKey(parentId, attachmentId);
		removeAttachmentsMap(attachmentMapKey);
	}
	
	private void removeAttachmentsMap(Key attachmentMapKey) {
		EntityManager mgr = getEntityManager();
		try {
			removeAttachmentsMap(mgr, attachmentMapKey);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeAttachmentsMap(EntityManager mgr, Key attachmentMapKey) {
		try {
			doRemoveTransaction(mgr, AttachmentsMap.class, attachmentMapKey);
			removeAttachmentIndex(attachmentMapKey);
		} catch (Exception ex) {
			LOG.warning(String.format("[removeAttachmentMap] %s : %s", NamespaceManager.get(), ex.getMessage()));
			ex.printStackTrace();
			throw ex;
		}
	}

	@Override
	public List<AttachmentsMap> removeAttachmentsMap(String kindId) throws Exception {
		return bulkRemoveAttachmentsMap(null, null, kindId, null, null);
	}
	private List<AttachmentsMap> bulkRemoveAttachmentsMap(
			String domainId,
			String boardId,
			String kindId,
			String attachmentId,
			String archiveYN) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			TypedQuery<AttachmentsMap> query = new QueryBuilder<>(AttachmentsMap.class)
//					.addClause(FLD.domainId, domainId)	// unnecessary condition
					.addClause(FLD.boardId, boardId)
					.addClause(FLD.kindId, kindId)
					.addClause(FLD.attachmentId, attachmentId)
					.addClause(FLD.archiveYN, archiveYN)
					.build(mgr);

			List<AttachmentsMap> attachmentsMapList = queryResults(query);
			
			doRemoveTransaction(mgr, attachmentsMapList);
			
			return attachmentsMapList;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public AttachmentIndex createOrUpdateAttachmentIndex(AttachmentsMap attachmentsMap) {
		EntityManager mgr = getEntityManager();
		try {
			return createOrUpdateAttachmentIndex(mgr, attachmentsMap);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private AttachmentIndex createOrUpdateAttachmentIndex(EntityManager mgr, AttachmentsMap attachmentsMap) {
		try {
			AttachmentIndex attachmentMapIndex = null;
			
			if (attachmentsMap != null) {
				Attachments attachment = attachmentService.getAttachments(mgr, attachmentsMap.getAttachmentId());
				if (attachment != null) {
					attachmentMapIndex = new AttachmentIndex(attachment, attachmentsMap);
					setKindInfo(mgr, attachmentMapIndex);
					
					SearchManager sm = new SearchManager();
					sm.createIndex(attachmentMapIndex);
				} else {
					attachmentMapService.removeAttachmentsMap(mgr, attachmentsMap.getKey());
				}
			}
			
			return attachmentMapIndex;
		} catch (Exception ex) {
			LOG.warning(String.format("[createOrUpdateAttachmentIndex] %s %s", NamespaceManager.get(), ex.getMessage()));
			return null;
		}
	}

	private void setKindInfo(EntityManager mgr, AttachmentIndex attachmentIndex) throws Exception {
		try {
			Key kindKey = KeyFactory.stringToKey(attachmentIndex.getKindId());
			String kind = kindKey.getKind();
			
			if (Tasks.class.getSimpleName().equals(kind)) {
				Tasks task = doFind(mgr, Tasks.class, kindKey);
				if (task != null) {
					attachmentIndex.setBoardId(task.getBoardId());
					attachmentIndex.setTaskId(task.getTaskId());
				}
			} else if (TaskTimelines.class.getSimpleName().equals(kind)) {
				TaskTimelines taskTimeline = doFind(mgr, TaskTimelines.class, kindKey);
				if (taskTimeline != null) {
					attachmentIndex.setBoardId(taskTimeline.getBoardId());
					attachmentIndex.setTaskId(taskTimeline.getTaskId());
				}
			} else if (Notice.class.getSimpleName().equals(kind)) {
				Notice notice = doFind(mgr, Notice.class, kindKey);
				
				if (notice != null) {
					String noticeKindId = notice.getKindId();
					
					if (noticeKindId != null) {
						Key noticeKindKey = KeyFactory.stringToKey(noticeKindId);
						
						if (Boards.class.getSimpleName().equals(noticeKindKey.getKind())) {
							attachmentIndex.setBoardId(noticeKindId);
						}
					}
				}
			}
			
			if (StringUtils.isNotBlank(kind)) { attachmentIndex.setKind(kind); }
		} catch (Exception ex) {
			LOG.warning(String.format("[setKindInfo] %s", ex.getMessage()));
		}
	}
	
	private void removeAttachmentIndex(Key attachmentsMapKey) {
		removeAttachmentIndex(KeyFactory.keyToString(attachmentsMapKey));
	}
	private void removeAttachmentIndex(String attachmentsMapId) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.deleteDocuments(AttachmentIndex.class, attachmentsMapId);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}

	private boolean containsAttachmentsMap(EntityManager mgr, AttachmentsMap attachmentsMap) {
		Key key = attachmentsMap.getKey();
		if (key == null) {
			key = KeyUtil.createAttachmentMapKey(attachmentsMap.getKindId(), attachmentsMap.getAttachmentId());
		}
		return doFind(mgr, AttachmentsMap.class, key) != null;
	}

	@Override
	public List<AttachmentsMap> markAttachmentsMap(String parentId, boolean archived, boolean deleted) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			List<AttachmentsMap> attachmentsMapList = listAllAttachmentsMap(mgr, parentId);
			
			int txCount = 0;
			beginTransaction(mgr);
			for (AttachmentsMap attachmentsMap : attachmentsMapList) {
				attachmentsMap.setArchiveYN(archived ? Y : N);
				attachmentsMap.setArchived(archived ? new Date() : null);
				attachmentsMap.setDeleteYN(deleted ? Y : N);
				attachmentsMap.setDeleted(deleted ? new Date() : null);

				doMerge(mgr, attachmentsMap);
				if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) { txCount = 0; commitTransaction(mgr); beginTransaction(mgr); }
				
				try {
					if (archived || deleted) {
						removeAttachmentIndex(attachmentsMap.getKey());
					} else {
						createOrUpdateAttachmentIndex(attachmentsMap);
					}
				} catch (Exception ex) {
					// Ignored. Not a critical part of application.
				}
			}
			commitTransaction(mgr);

			return attachmentsMapList;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public List<AttachmentsMap> listAttachmentsMapByValue(String attachmentId) throws Exception {
//		return listAttachmentsMap(null, attachmentId, N);
//	}
//	@Override
//	public List<AttachmentsMap> listAllAttachmentsMap(String kindId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return listAllAttachmentsMap(mgr, kindId);
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<AttachmentsMap> listAllAttachmentsMapByValue(String attachmentId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return listAllAttachmentsMapByValue(mgr, attachmentId);
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public AttachmentsMap getAttachmentsMap(String parentId, String attachmentId) throws Exception {
//		if (StringUtils.isBlank(attachmentId)) {
//			return null;
//		} else {
//			Key attachmentMapKey = KeyUtil.createAttachmentMapKey(parentId, attachmentId);
//			return getAttachmentsMap(attachmentMapKey);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
