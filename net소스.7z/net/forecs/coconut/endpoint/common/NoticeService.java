package net.forecs.coconut.endpoint.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.CountInfo;
import net.forecs.coconut.common.CountNotice;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.NoticeKind;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.query.SimpleQuery;
import net.forecs.coconut.common.util.CreateLetterIndexUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.search.index.NoticeIndex;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.ServiceException;
import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;


public class NoticeService extends CommonService implements INoticeService {
	private static final Logger LOG = Logger.getLogger(NoticeService.class.getName());
	public static final String KINDID_SYSTEM_NOTICE = "SYSTEM";
	public static final String KINDID_DOMAIN_NOTICE = "DOMAIN";
	
//	private final INoticeCommentService noticeCommentService;
	private final IAttachmentService attachmentService;
	private final IActivityService activityService;
	
	@Inject
	public NoticeService(
//			INoticeCommentService noticeCommentService,
			IAttachmentService attachmentService,
			IActivityService activityService) {
//		this.noticeCommentService = noticeCommentService;
		this.attachmentService = attachmentService;
		this.activityService = activityService;
	}

	@Override
	public QueryResult<Notice> queryNotice(String cursorString,
			Integer limit,
			Collection<String> kindIdList) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return queryNotice(mgr, cursorString, limit, kindIdList);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public QueryResult<Notice> queryNotice(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> kindIdList) throws Exception {
		try {
			Set<String> kindIdSet = null;
			
			if (kindIdList != null && 1 < kindIdList.size()) {
				kindIdSet = new HashSet<String>();
				for (String kindId : kindIdList) {
					kindIdSet.add(kindId);
				}
				kindIdList = null;
			}
				
			DsQuery<Notice> dsQuery = new DsQuery<>(Notice.class)
					.eq(FLD.deleteYN, N)
					.in(FLD.kindId, kindIdList)
					.sort(FLD.created, SortDirection.DESC)
					.cursor(cursorString)
					.limit(limit);

			int bulkFetchAmount = 1;	// 검색 속도를 높이기 위해 한꺼번에 많은 양을 가져와서 해당되는 값들을 필터링하기 위해, 즉 , limit보다  bulkFetchAmount배 많이 가져온뒤에 필터링
			if (kindIdSet != null) { bulkFetchAmount = 2; }
 
			do {
				dsQuery.nextFetch(mgr, bulkFetchAmount++);
				while(dsQuery.hasEntity()) {
					Notice notice = dsQuery.nextEntity();
					if (kindIdSet != null && !kindIdSet.contains(notice.getKindId())) { continue; }
					dsQuery.addResult(notice);
				}
			} while (dsQuery.hasNextFetch());
				
			return new QueryResult<Notice>(dsQuery.getResults(), dsQuery.getCursor());	
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public Notice getNotice(String noticeId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getNotice(mgr, noticeId, true);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private Notice getNotice(EntityManager mgr, String noticeId, boolean includeAttachements) throws Exception {
		Notice notice = doFind(mgr, Notice.class, noticeId);
		
		if (notice != null && includeAttachements) {
			List<Attachments> attachments = attachmentService.listChildAttachments(mgr, notice.getNoticeId());
			notice.setAttachments(attachments);
		}
		
		return notice;
	}
	
	@Override
	public Notice insertNotice(Notice notice) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return insertNotice(mgr, notice);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private Notice insertNotice(EntityManager mgr, Notice notice) throws Exception {
		try {
			Users loginUser = getCurrentUser();
			String loginUserId = null;
			String domainName = NamespaceManager.get();
			
			if (NoticeKind.BOARDS.equals(notice.getNoticeKind())) {
				loginUserId = loginUser.getUserId();
			} else if (NoticeKind.DOMAINS.equals(notice.getNoticeKind())) {
				notice.setKindId(KINDID_DOMAIN_NOTICE);
				loginUserId = loginUser.getUserId();
			} else if (NoticeKind.SYSTEM.equals(notice.getNoticeKind())) {
				notice.setKindId(KINDID_SYSTEM_NOTICE);
				loginUserId = CommonProperty.SYSTEM_USER_ID;
			}

			notice.setCreator(loginUserId);
			notice.setOwner(loginUserId);

			if (StringUtils.isNotBlank(domainName) && StringUtils.isBlank(notice.getDomainId())) {
				notice.setDomainId(KeyUtil.createDomainKeyString(domainName));
			}
			
			if (notice.getKey() == null) {
				notice.setKey(KeyUtil.createNoticeKey());
			}

			if (contains(mgr, Notice.class, notice.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Notice.class, notice.getNoticeId()));
			}

			doPersistTransaction(mgr, notice);

			try {
				if (StringUtils.isNotBlank(domainName)) {
					createOrUpdateNoticeIndex(notice);
//					updateNoticeAttachments(notice);
					
					if (NoticeKind.SYSTEM.equals(notice.getNoticeKind())) {
						activityService.insertActivities(activityService.createNoticeActivity(notice, null, ActivityType.SYSTEM_NOTICE_ADDED, loginUser));
					} else {
						activityService.insertActivities(activityService.createNoticeActivity(notice, null, ActivityType.ADDED, loginUser));
					}
				}
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return notice;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public Notice updateNotice(Notice notice) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return updateNotice(mgr, notice, true);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Notice updateNotice(EntityManager mgr, Notice notice, boolean includeAttachments) throws Exception {
		try {
			valid(notice);
			String domainName = NamespaceManager.get();
			
			if (NoticeKind.DOMAINS.equals(notice.getNoticeKind())) {
				notice.setKindId(KINDID_DOMAIN_NOTICE);
			} else if (NoticeKind.SYSTEM.equals(notice.getNoticeKind())) {
				notice.setKindId(KINDID_SYSTEM_NOTICE);
			}
			
			if (StringUtils.isNotBlank(domainName) && StringUtils.isBlank(notice.getDomainId())) {
				notice.setDomainId(KeyUtil.createDomainKeyString(domainName));
			}
			
			doMergeTransaction(mgr, notice);

			try {
				if (StringUtils.isNotBlank(domainName)) {
					createOrUpdateNoticeIndex(notice);
//					if (includeAttachments) { updateNoticeAttachments(notice); }
				
					Users loginUser = getCurrentUser();
					if (NoticeKind.SYSTEM.equals(notice.getNoticeKind())) {
						activityService.insertActivities(activityService.createNoticeActivity(notice, null, ActivityType.SYSTEM_NOTICE_UPDATED, loginUser));
					} else {
						activityService.insertActivities(activityService.createNoticeActivity(notice, null, ActivityType.UPDATED, loginUser));
					}
				}
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }

			return notice;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public void removeNotice(String noticeId) throws ServiceException {
		EntityManager mgr = getEntityManager();
		
		try {
			removeNotice(mgr, noticeId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void removeNotice(EntityManager mgr, String noticeId) throws ServiceException {
		try {
			Notice notice = doFind(mgr, Notice.class, noticeId);
//			valid(notice);

			if (notice != null) {
				notice.setDeleteYN(Y);
				notice.setDeleted(new Date());

				doMergeTransaction(mgr, notice);

				try {
					if (StringUtils.isNotBlank(NamespaceManager.get())) {
						removeNoticeIndex(noticeId);
						boolean archived = Y.equals(notice.getArchiveYN());
						boolean deleted = Y.equals(notice.getDeleteYN());
						attachmentService.markChildAttachments(noticeId, archived, deleted);
				
						Users loginUser = getCurrentUser();
						
						if (NoticeKind.SYSTEM.equals(notice.getNoticeKind())) {
							activityService.insertActivities(activityService.createNoticeActivity(notice, null, ActivityType.SYSTEM_NOTICE_DELETED, loginUser));
						} else {
							activityService.insertActivities(activityService.createNoticeActivity(notice, null, ActivityType.DELETED, loginUser));
						}
					}
				} catch (Exception ex) {
					LOG.warning(ex.getMessage());
				}
			}
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public NoticeIndex createOrUpdateNoticeIndex(Notice notice) {
		if (notice == null) { return null; }
		
		NoticeIndex noticeIndex = null;
		
		try {
			noticeIndex = new NoticeIndex();
			
			noticeIndex.setKey(notice.getKey());
			noticeIndex.setDomainId(notice.getDomainId());
			if (NoticeKind.BOARDS.equals(notice.getNoticeKind())) {
				noticeIndex.setBoardId(notice.getKindId());
			}
			noticeIndex.setKindId(notice.getKindId());
			noticeIndex.setNoticeId(notice.getNoticeId());
			//noticeIndex.setArchived(notice.getArchived());
			noticeIndex.setArchiveYN(notice.getArchiveYN());
			noticeIndex.setTitle(CreateLetterIndexUtil.createLetterIndex(notice.getTitle()));
			noticeIndex.setDescription(CreateLetterIndexUtil.createLetterIndex(notice.getDescription()));
			noticeIndex.setCreator(notice.getCreator());

			//-->
			// hyeunwoo.shim 2016-02-17 : unnecessary code.
			// Remove lower part comment if I use comment.
			/*
			QueryResult<NoticeComments> queryResult = noticeCommentService.listNoticeComments(null, null, notice.getNoticeId());
			List<NoticeComments> comments = queryResult.getResultList();

			String commentTitleStr = "";
			String commentDescriptionStr = "";
			
			if (comments != null && comments.size() > 0) {
				List<String> commentTitleList = new ArrayList<String>();
				List<String> commentsDescriptionList = new ArrayList<String>();
				for (NoticeComments comment : comments) {
					if (StringUtils.isNotBlank(comment.getTitle())) { commentTitleList.add(comment.getTitle()); }
					if (comment.getDescription()!= null && StringUtils.isNotBlank(comment.getDescription().getValue())) {
						commentsDescriptionList.add(comment.getDescription().getValue());
					}
				}
				commentTitleStr = CreateLetterIndexUtil.createLetterIndex(StringUtils.join(commentTitleList, " "));
				commentDescriptionStr = CreateLetterIndexUtil.createLetterIndex(StringUtils.join(commentsDescriptionList, " "));
			}

			noticeIndex.setCommentTitle(commentTitleStr);
			noticeIndex.setCommentDescription(new Text(commentDescriptionStr));
			*/
			//<--
			
			SearchManager sm = new SearchManager();
			if (noticeIndex != null) { sm.createIndex(noticeIndex); }

			return noticeIndex;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}

	@Override
	public void removeNoticeIndex(String noticeId) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.deleteDocuments(NoticeIndex.class, noticeId);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}

//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
	@Override
	public Notice updateNoticeTitle(String noticeId, String title) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Notice notice = getNotice(mgr, noticeId, false);
			valid(notice);
			notice.setTitle(title);
			return updateNotice(mgr, notice, false);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public Notice updateNoticeDescription(String noticeId, Text description) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Notice notice = getNotice(mgr, noticeId, false);
			valid(notice);
			notice.setDescription(description);
			return updateNotice(mgr, notice, false);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public NoticeIndex createOrUpdateNoticeIndex(String noticeId) throws Exception{
		return createOrUpdateNoticeIndex(getNotice(noticeId));
	}
	@Override
	public int bulkRemoveNotice(NoticeKind noticeKind, String kindId, String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			TypedQuery<Key> query = new QueryBuilder<>(Notice.class)
//					.addClause(FLD.noticeKind, noticeKind)	// unnecessary condition
					.addClause(FLD.kindId, kindId)
					.addClause(FLD.owner, userId)
					.buildKeyOnlyRead(mgr);
			
			List<Key> keys = listAllKeysForLimitedChunkSize(query);
			for (Key key : keys) {
				permanentRemoveNotice(mgr, KeyFactory.keyToString(key));
			}

			return keys.size();
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private void permanentRemoveNotice(EntityManager mgr, String noticeId) throws ServiceException {
		doRemoveTransaction(mgr, Notice.class, noticeId);

		try {
			removeNoticeIndex(noticeId);
//			noticeCommentService.bulkRemoveNoticeComments(noticeId);
			attachmentService.removeChildAttachments(noticeId);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	@Override
	public Notice insertDomainNotice(Notice notice) throws Exception {
		notice.setNoticeKind(NoticeKind.DOMAINS);
		notice.setKindId(KINDID_DOMAIN_NOTICE);
		
		return insertNotice(notice);
	}
	@Override
	public Notice updateDomainNotice(Notice notice) throws Exception {
		notice.setNoticeKind(NoticeKind.DOMAINS);
		notice.setKindId(KINDID_DOMAIN_NOTICE);
		
		return updateNotice(notice);
	}
	@Override
	public void removeDomainNotice(String noticeId) throws ServiceException {
		removeNotice(noticeId);
	}
	@Override
	public CountNotice countNotice(CountNotice countNotice) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			for (CountInfo countInfo : countNotice.getCountInfos()) {
				Long count = countNotice(mgr, countInfo.getBoardId(), countInfo.getCheckDate());
				countInfo.setCount(count);
			}
			
			return countNotice;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Long countNotice(EntityManager mgr, String boardId, Date checkedDate) {
		try {
			SimpleQuery<Notice> sq = new SimpleQuery<>(mgr, Notice.class);
			sq.where(sq.and(
					sq.equal(FLD.boardId, boardId),
					sq.greaterThan(FLD.created, checkedDate)));
			TypedQuery<Long> countQuery = sq.count();
			
			return countQuery.getSingleResult();
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Notice Kind or entity not found.", ex.getMessage()));
			return 0L;
		}
	}
	@Override
	public QueryResult<Notice> querySystemNotice(String cursorString, Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			List<String> kindIdList = new ArrayList<String>();
			kindIdList.add(KINDID_SYSTEM_NOTICE);
			return queryNotice(mgr, cursorString, limit, kindIdList);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public Notice getSystemNotice(String noticeId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		try {
			return getNotice(mgr, noticeId, false);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public Notice insertSystemNotice(List<String> domainNames, Notice notice) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			if (domainNames == null) {
				domainNames = new ArrayList<String>();
				List<Domains> domainList = listAllDomains(mgr);
				for (Domains domain : domainList) {
					domainNames.add(domain.getDomainName());
				}
			}
			Notice rootSystemNotice = null;
			if (domainNames != null && domainNames.size() > 0) {
				notice.setNoticeKind(NoticeKind.SYSTEM);
				notice.setKindId(KINDID_SYSTEM_NOTICE);
				notice.setCreator(CommonProperty.SYSTEM_USER_ID);
				
				rootSystemNotice = insertNotice(mgr, notice);
				
				for (String domainName : domainNames) {
					insertDomainSystemNotice(mgr, domainName, notice);
				}
			}
			return rootSystemNotice;			
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private Notice insertDomainSystemNotice(EntityManager mgr, String domainName, Notice systemNotice) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			Notice notice = new Notice(systemNotice);
			notice.setKey(KeyUtil.createDomainSystemNoticeKey(systemNotice.getKey().getId()));
			notice.setDomainId(KeyUtil.createDomainKeyString(domainName));

			return insertNotice(mgr, notice);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	@Override
	public Notice updateSystemNotice(Notice notice) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Notice systemNotice = getNotice(mgr, notice.getNoticeId(), false);
			systemNotice.setTitle(notice.getTitle());
			systemNotice.setDescription(notice.getDescription());
			systemNotice = updateNotice(mgr, systemNotice, false);
			systemNotice = updateDomainSystemNotice(mgr, systemNotice);
			return systemNotice;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public Notice updateSystemNoticeTitle(String noticeId, String title) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Notice systemNotice = getNotice(mgr, noticeId, false);
			
			systemNotice.setTitle(title);
			systemNotice = updateNotice(mgr, systemNotice, false);
			return updateDomainSystemNotice(mgr, systemNotice);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public Notice updateSystemNoticeDescription(String noticeId, Text Description) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Notice systemNotice = getNotice(mgr, noticeId, false);
			systemNotice.setDescription(Description);
			systemNotice = updateNotice(mgr, systemNotice, false);
			return updateDomainSystemNotice(mgr, systemNotice);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private Notice updateDomainSystemNotice(EntityManager mgr, Notice systemNotice) throws Exception {
			List<Domains> domainList = listAllDomains(mgr);
			
			for (Domains domain : domainList) {
				updateDomainSystemNotice(mgr, domain.getDomainName(), systemNotice);
			}
			 
			return systemNotice;
	}
	private Notice updateDomainSystemNotice(EntityManager mgr, String domainName, Notice systemNotice) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			Notice notice = doFind(mgr, Notice.class, KeyUtil.createDomainSystemNoticeKey(systemNotice.getKey().getId()));
			if (notice != null) {
				notice.setTitle(systemNotice.getTitle());
				notice.setDescription(systemNotice.getDescription());
				
				notice = updateNotice(mgr, notice, false);
			}
			return notice;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	@Override
	public void removeSystemNotice(String noticeId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			removeNotice(mgr, noticeId);
			
			List<Domains> domainList = listAllDomains(mgr);
			
			for (Domains domain : domainList) {
				removeDomainSystemNotice(mgr, domain.getDomainName(), KeyFactory.stringToKey(noticeId).getId());
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private void removeDomainSystemNotice(EntityManager mgr, String domainName, long parentKeyId) throws ServiceException {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			Key noticeKey = KeyUtil.createDomainSystemNoticeKey(parentKeyId);
			if (contains(mgr, Notice.class, noticeKey)) {
				removeNotice(mgr, KeyFactory.keyToString(noticeKey));
			}
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	@Override
	public Attachments addNoticeAttachment(String noticeId, Attachments attachment) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Notice notice = doFind(mgr, Notice.class, noticeId);
			valid(notice);

			attachment = attachmentService.addChildAttachment(noticeId, attachment);

//			doMergeTransaction(mgr, notice);
//			try {
//				createOrUpdateNoticeIndex(notice);
//			} catch (Exception ex) {}
			return attachment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public Attachments removeNoticeAttachment(String noticeId, String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Notice notice = doFind(mgr, Notice.class, noticeId);
			valid(notice);

			Attachments attachment = attachmentService.removeChildAttachment(noticeId, attachmentId);

			//doMergeTransaction(mgr, notice);
			//createOrUpdateNoticeIndex(notice);
			return attachment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@SuppressWarnings("unused")
	private void updateNoticeAttachments(Notice notice) throws Exception {
		String noticeId = notice.getNoticeId();
		List<Attachments> attachments = notice.getAttachments();
		attachmentService.updateChildAttachments(noticeId, attachments);
	}
}
