package net.forecs.coconut.endpoint.common;


@Deprecated
public interface INoticeCommentService extends ICommonService {
//	public abstract QueryResult<NoticeComments> listNoticeComments(
//			String cursorString,
//			Integer limit,
//			String noticeId) throws Exception;
//
//	public abstract NoticeComments getNoticeComments(String noticeCommentId);
//	public abstract NoticeComments insertNoticeComments(String parentNoticeCommentId, NoticeComments noticecomments) throws Exception;
//	public abstract NoticeComments updateNoticeComments(NoticeComments noticecomments) throws Exception;
//	public abstract void removeNoticeComments(String noticeCommentId) throws Exception;
//	public abstract void permanentRemoveNoticeComments(String noticeCommentId) throws Exception;
//	public abstract int bulkRemoveNoticeComments(String noticeId) throws Exception;
}
