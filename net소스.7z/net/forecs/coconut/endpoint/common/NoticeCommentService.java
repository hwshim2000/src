package net.forecs.coconut.endpoint.common;


@Deprecated
public class NoticeCommentService extends CommonService implements INoticeCommentService {
//	private final INoticeService noticeService;
//	private final IUserService userService;
//	
//	@Inject
//	public NoticeCommentService(INoticeService noticeService, IUserService userService) {
//		this.noticeService = noticeService;
//		this.userService = userService;
//	}
//
//	@Override
//	public QueryResult<NoticeComments> listNoticeComments(
//			String cursorString,
//			Integer limit,
//			String noticeId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Cursor cursor = null;
//
//			TypedQuery<NoticeComments> query = new QueryBuilder<>(NoticeComments.class)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.noticeId, noticeId)
//					.addOrder(FLD.familyId, SortDirection.DESC)
//					.addOrder(FLD.depth, SortDirection.ASC)
//					//.addOrder(FLD.created, SortDirection.DESC)
//					.build(mgr);
//
//			if (StringUtils.isNotBlank(cursorString)) {
//				cursor = Cursor.fromWebSafeString(cursorString);
//				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
//			}
//
//			if (limit != null) {
//				query.setFirstResult(0);
//				query.setMaxResults(limit);
//			}
//
//			List<NoticeComments> noticeCommentList = query.getResultList();
//			cursor = JPACursorHelper.getCursor(noticeCommentList);
//			
//			Map<String, Users> userMap = batchMapNoticeCommentUsers(mgr, noticeCommentList);
//			
//			for (NoticeComments obj : noticeCommentList) {
//				obj.setUser(userMap.get(obj.getCreator()));
//			}
//
//			return new QueryResult<NoticeComments>(noticeCommentList, cursor);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	
//	private Map<String, Users> batchMapNoticeCommentUsers(EntityManager mgr, List<NoticeComments> noticeComments) throws Exception {
//		Set<String> userIds = new HashSet<String>();
//		for (NoticeComments comment : noticeComments) {
//			userIds.add(comment.getCreator());
//		}
//		return userService.batchMapUsers(mgr, userIds, false);
//	}
//
//	private List<NoticeComments> updateAllDepth(long familyId, int depth) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TypedQuery<NoticeComments> query = new QueryBuilder<>(NoticeComments.class)
//					.addClause(FLD.familyId, familyId)
//					.addGTClause(FLD.depth, depth, SortDirection.ASC)
//					.build(mgr);
//			
//			List<NoticeComments> noticeCommentList = queryResults(query);
//
//			for (NoticeComments noticeComment : noticeCommentList) {
//				noticeComment.setDepth(noticeComment.getDepth()+1);
//			}
//			
//			doMergeTransaction(mgr, noticeCommentList);
//			
//			return noticeCommentList;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	private boolean hasChildComments(EntityManager mgr, String noticeCommentId) throws Exception {
//		boolean hasChilds = false;
//		
//		Key noticeCommentKey = KeyFactory.stringToKey(noticeCommentId);
//
//		SimpleQuery<NoticeComments> sq = new SimpleQuery<>(mgr, NoticeComments.class);
//		sq.where(sq.equal(FLD.parentId, noticeCommentKey.getId()));
//		TypedQuery<Long> query = sq.count();
//
//		Long childCount = query.getSingleResult();
//		if (childCount != null && childCount > 0) {
//			hasChilds = true;
//		}
//		
//		return hasChilds;
//	}
//
//	@Override
//	public NoticeComments getNoticeComments(String noticeCommentId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return this.getNoticeComments(mgr, noticeCommentId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private NoticeComments getNoticeComments(EntityManager mgr, String noticeCommentId) {
//		return doFind(mgr, NoticeComments.class, noticeCommentId);
//	}
//	
//	@Override
//	public NoticeComments insertNoticeComments(String parentNoticeCommentId, NoticeComments noticecomments) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Users loginUser = getCurrentUser();
//			String loginUserId = loginUser.getUserId();
//			noticecomments.setCreator(loginUserId);
//
//			Key noticeCommentKey = KeyUtil.createNoticeCommentKey(noticecomments.getNoticeId());
//			long familyId = noticeCommentKey.getId();
//			
//			if (StringUtils.isEmpty(parentNoticeCommentId)) {
//				//noticecomments.setNo(familyId);
//				noticecomments.setFamilyId(familyId);
//				noticecomments.setParentId(0);
//				noticecomments.setDepth(0);
//				noticecomments.setIndent(0);
//			} else {
//				NoticeComments parentComments = getNoticeComments(mgr, parentNoticeCommentId);
//				
//				updateAllDepth(parentComments.getFamilyId(), parentComments.getDepth());
//				
//				//noticecomments.setNo(no);
//				noticecomments.setFamilyId(parentComments.getFamilyId());
//				noticecomments.setParentId(parentComments.getKey().getId());
//				noticecomments.setDepth(parentComments.getDepth()+1);
//				noticecomments.setIndent(parentComments.getIndent()+1);
//			}
//			
//			noticecomments.setKey(noticeCommentKey);
//			noticecomments.setUser(loginUser);
//			
//			if (contains(mgr, NoticeComments.class, noticecomments.getKey())) {
//				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(NoticeComments.class, noticecomments.getNoticeCommentId()));
//			}
//			
//			doPersistTransaction(mgr, noticecomments);
//			
//			noticeService.createOrUpdateNoticeIndex(noticecomments.getNoticeId());
//			
//			return noticecomments;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public NoticeComments updateNoticeComments(NoticeComments noticecomments) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			valid(noticecomments);
//			doMergeTransaction(mgr, noticecomments);
//			noticeService.createOrUpdateNoticeIndex(noticecomments.getNoticeId());
//			return noticecomments;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public void removeNoticeComments(String noticeCommentId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			NoticeComments noticeComment = doFind(mgr, NoticeComments.class, noticeCommentId);
//			valid(noticeComment);
//
//			if (hasChildComments(mgr, noticeCommentId)) {
//				noticeComment.setDeleted(new Date());
//				noticeComment.setDeleteYN(Y);
//
//				doMergeTransaction(mgr, noticeComment);
//			} else {
//				doRemoveTransaction(mgr, noticeComment);
//			}
//
//			noticeService.removeNoticeIndex(noticeCommentId);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public void permanentRemoveNoticeComments(String noticeCommentId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			NoticeComments noticeComment = doFind(mgr, NoticeComments.class, noticeCommentId);
//			permanentRemoveNoticeComments(mgr, noticeComment);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private void permanentRemoveNoticeComments(EntityManager mgr, NoticeComments noticeComment) throws Exception {
//		try {
//			doRemoveTransaction(mgr, noticeComment);
//			noticeService.removeNoticeIndex(noticeComment.getNoticeCommentId());
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	
//	@Override
//	public int bulkRemoveNoticeComments(String noticeId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			int resultCount = 0;
//			
//			TypedQuery<NoticeComments> query = new QueryBuilder<>(NoticeComments.class)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.archiveYN, null)
//					.addClause(FLD.noticeId, noticeId)
//					.build(mgr);
//
//			List<NoticeComments> noticeCommentList = queryResults(query);
//			// **********************************************************************
//			// warning
//			// 같은 EntityManager로부터 온 Object를 삭제할 경우 query.getResultList()에서 리천되어온 값을 곧바로 사용하면 가능하지만
//			// 한번이라도 다른객체에 이동한 뒤에 삭제하면 attach/detatch관련 에러가 발생하므로 주의해서 사용해야 한다.
//			// **********************************************************************
//			
//			for (NoticeComments noticeComment : noticeCommentList) {
//				permanentRemoveNoticeComments(mgr, noticeComment);
//				resultCount++;
//			}
//			
//			return resultCount;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
}
