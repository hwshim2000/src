package net.forecs.coconut.endpoint.common;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.entity.attachment.Images;

public interface IImageService extends ICommonService {
	public abstract String getServingUrl(String bucketName, String filePath, int imageSize);
	public abstract String getServingUrlForDev(Images image);
	public abstract Images insertOrUpdateImage(Images image) throws Exception;
	public abstract List<Images> appendOrRemoveImages(String parentId, List<Images> newImages) throws Exception;
	public abstract Images appendOrRemoveImages(String parentId, Images newImage) throws Exception;
	public abstract Images removeImages(String imageId) throws Exception;
	public abstract void removeChildImages(String parentId) throws Exception;

	public abstract Map<String, List<Images>> batchMapChildImages(EntityManager mgr, Collection<String> parentIds) throws Exception;
	public abstract List<Images> listChildImages(EntityManager mgr, String parentId) throws Exception;
	public abstract Map<String, Object> getImageInfo(String bucketName, String filePath, int imageSize) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract Images getImages(String imageId);
//	public abstract List<Images> listTaskTimelineImages(String taskTimelineId) throws Exception;
//	public abstract Images removeImagesMetadata(String imageId) throws Exception;
//	public abstract Images getUserImage(String userId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
