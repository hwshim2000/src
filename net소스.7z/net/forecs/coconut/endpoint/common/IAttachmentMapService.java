package net.forecs.coconut.endpoint.common;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.search.index.AttachmentIndex;

import com.google.appengine.api.datastore.Key;


public interface IAttachmentMapService extends ICommonService {
	public abstract List<AttachmentsMap> listAttachmentsMap(EntityManager mgr, String parentId) throws Exception;
	public abstract List<AttachmentsMap> listAllAttachmentsMapByValue(EntityManager mgr, String attachmentId) throws Exception;
	public abstract AttachmentsMap insertAttachmentsMap(String parentId, String attachmentId) throws Exception;
	public abstract List<AttachmentsMap> updateAttachmentsMap(String parentId, List<String> attachmentIds) throws Exception;
	public abstract List<AttachmentsMap> markAttachmentsMap(String parentId, boolean archived, boolean deleted) throws Exception;
	public abstract void removeAttachmentsMap(String parentId, String attachmentId) throws Exception;
	public abstract void removeAttachmentsMap(EntityManager mgr, Key attachmentMapKey);
	public abstract List<AttachmentsMap> removeAttachmentsMap(String parentId) throws Exception;
	public abstract AttachmentIndex createOrUpdateAttachmentIndex(AttachmentsMap attachmentsMap);
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract AttachmentIndex createOrUpdateAttachmentIndex(EntityManager mgr, AttachmentsMap attachmentsMap);
//	public abstract List<AttachmentsMap> listAttachmentsMapByValue(String attachmentId) throws Exception;
//	public abstract List<AttachmentsMap> listAllAttachmentsMap(String parentId) throws Exception;
//	public abstract List<AttachmentsMap> listAllAttachmentsMapByValue(String attachmentId) throws Exception;
//	public abstract AttachmentsMap getAttachmentsMap(String parentId, String attachmentId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
