package net.forecs.coconut.endpoint.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.rest.ApacheHttpClient;
import net.forecs.coconut.endpoint.admin.UsageService;
import net.forecs.coconut.endpoint.common.AttachmentService.GcsSignedUrlUtil;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.images.ImagesService;
import com.google.appengine.api.images.ImagesServiceFactory;
import com.google.appengine.api.images.ServingUrlOptions;
import com.google.appengine.tools.cloudstorage.GcsFileMetadata;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;

public class ImageService extends CommonService implements IImageService {
	private static final Logger LOG = Logger.getLogger(AttachmentService.class.getName());
	//private final BlobstoreService blobstoreService;
	private final ImagesService imagesService;
	private final AttachmentService attachmentService;
	
	private final String site;
	private final String BUCKET_NAME;
	public static final String SECRET_KEY = "dzhFVjJuUDhQTGs4bWE2Mm9CQnBIQXBUQWl0ZVpKNUk";
	
	@Inject
	public ImageService(@Named(FLD.social_site) String site, AttachmentService attachmentService) {
		//blobstoreService = BlobstoreServiceFactory.getBlobstoreService();
		this.attachmentService = attachmentService;
		imagesService = ImagesServiceFactory.getImagesService();
		this.site = site;
		
		//bucketName = "coco_dev_images"; // for test
		if (StringUtils.isNotEmpty(this.site) && "live".equals(this.site)) { BUCKET_NAME = GcsSignedUrlUtil.LIVE_BUCKET_NAME; }
		else { BUCKET_NAME = GcsSignedUrlUtil.DEV_BUCKET_NAME; }
	}
	
	private List<Images> listChildImages(String parentId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return listChildImages(mgr, parentId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<Images> listChildImages(EntityManager mgr, String parentId) throws Exception {
		List<Images> imageList = new ArrayList<Images>();
		
		DsQuery<Images> dsQuery = new DsQuery<>(Images.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.parentId, parentId);
		List<Images> results = dsQuery.execute(mgr);
		for (Images image : results) {
			imageList.add(image);
		}
		return imageList;
	}

	private Images getChildImages(EntityManager mgr, String parentId) throws Exception {
		try {
			DsQuery<Images> dsQuery = new DsQuery<>(Images.class)
						.eq(FLD.parentId, parentId);
			return dsQuery.single(mgr);
		} catch (NoResultException ex) {
			LOG.warning(ex.getMessage());
			return null;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		}
	}
	
	@Override
	public Map<String, List<Images>> batchMapChildImages(EntityManager mgr, Collection<String> parentIds) throws Exception {
		try {
			Map<String, List<Images>> resultMap = new HashMap<String, List<Images>>();
			List<Images> results = batchListByField(mgr, Images.class, parentIds, FLD.parentId);
			
			for (Images image : results) {
				if (!resultMap.containsKey(image.getParentId())) { resultMap.put(image.getParentId(), new ArrayList<Images>()); }
				resultMap.get(image.getParentId()).add(image);
			}
			return resultMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@SuppressWarnings("unused")
	private List<String> listChildImageIds(String parentId) throws Exception {
		try {
			List<Images> images = listChildImages(parentId);
			List<String> imageIds = new ArrayList<String>();
			
			for (Images image : images) {
				imageIds.add(image.getImageId());
			}
			return imageIds;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<Images> listImagesToRemove(List<Images> oldImages, List<Images> newImages) {
		List<Images> removeImages = new ArrayList<Images>(oldImages);
		
		for (Images newImage : newImages) {
			Images currImage = null;
			for (Images oldImage : oldImages) {
				if (oldImage.getImageId().equals(newImage.getImageId())) {
					currImage = oldImage;
					break;
				}
			}
			if (currImage != null) { removeImages.remove(currImage); }
		}
		return removeImages;
	}
	
	private List<Images> insertOrUpdateImages(EntityManager mgr, String parentId, List<Images> images) throws Exception {
		List<Images> results = new ArrayList<Images>();
		
		for (Images image : images) {
			image.setParentId(parentId);
			results.add(insertOrUpdateImage(mgr, image));
		}
		
		return results;
	}
	private Images insertOrUpdateImages(EntityManager mgr, String parentId, Images image) throws Exception {
		image.setParentId(parentId);
		image = insertOrUpdateImage(mgr, image);
		
		return image;
	}
	
	@Override
	public Images insertOrUpdateImage(Images image) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return insertOrUpdateImage(mgr, image);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Images insertOrUpdateImage(EntityManager mgr, Images image) throws Exception {
		UsageService.validUsage(image);

		try {
			Users loginUser = getCurrentUser();

			Key key = KeyUtil.createImageKey(image);

			String filePath = image.getFilePath();
			image.setKey(key);
			if (loginUser != null) { image.setCreator(loginUser.getUserId()); }

			if (StringUtils.isNotBlank(filePath)) {
				String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
				image.setFileName(fileName);
			}
			if (MainModule.developmentServer) {
				image.setServingUrl(getServingUrlForDev(image));
			} else {
				image.setServingUrl(getServingUrl(image));
			}
			
			if (contains(mgr, Images.class, image.getKey())) {
				doMergeTransaction(mgr, image);
			} else {
				doPersistTransaction(mgr, image);
			}
			
			UsageService.increaseUsage(image);
			attachmentService.completeUploadedFile(filePath);
			return image;
		} catch (Exception e) {
			throw e;
		}
	}
	
	@SuppressWarnings("unused")
	private Images updateImage(String parentId, Images image) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Key imageKey = image.getKey();
			if (imageKey == null) {
				imageKey = KeyUtil.createAttachmentKey(image.getFilePath());
			}

			valid(image);
			image.setParentId(parentId);
			String filePath = image.getFilePath();
			if (StringUtils.isNotBlank(filePath)) {
				String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
				image.setFileName(fileName);
			}

			doMergeTransaction(mgr, image);
			
			return image;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeChildImages(String parentId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<Images> removeImages = listChildImages(mgr, parentId);
			for (Images image : removeImages) {
				removeImages(mgr, image.getImageId());
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Images removeImages(String imageId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return removeImages(mgr, imageId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	public Images removeImages(EntityManager mgr, String imageId) throws Exception {
		try {
			Images image = doFind(mgr, Images.class, imageId);
			doRemoveTransaction(mgr, image);

			try {
				attachmentService.deleteGcsFile(image.getFilePath());
				UsageService.decreaseUsage(image);
			} catch (Exception ex) {}
			
			return image;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private String getServingUrl(Images image) {
		String bucketName = image.getBucket();
		if (StringUtils.isBlank(bucketName)) { bucketName =  BUCKET_NAME; }
		return getServingUrl(bucketName, image.getFilePath(), image.getImageSize());
 	}

	@Override
	public String getServingUrl(String bucketName, String filePath, int imageSize) {
		try {
			// BlobKey blobKey = blobstoreService.createGsBlobKey(
			// "/gs/"+bucketName+"/"+image.getFilePath());
			//
			// //LOG.warning(blobKey.getKeyString());
			//
			// //BlobKey blobKey = new BlobKey(key);
			// ServingUrlOptions options =
			// ServingUrlOptions.Builder.withBlobKey(blobKey);
			GcsFilename gcsFilename = new GcsFilename(bucketName, filePath);
			String filename = String.format("/gs/%s/%s",
					gcsFilename.getBucketName(), gcsFilename.getObjectName());
			ServingUrlOptions options = ServingUrlOptions.Builder
					.withGoogleStorageFileName(filename).secureUrl(true);
			
			// options.crop(crop);
			//if (imageSize > 0) {
				options.imageSize(imageSize);
			//}
			//Image image = ImagesServiceFactory.makeImageFromFilename(filename);
			// image.width() X image.height()
	
			String servingUrl = imagesService.getServingUrl(options);
			// LOG.warning("GCS FileName : " + filename);
			// LOG.warning("GCS Serving URL : " + servingUrl);
			return servingUrl;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
 	}
	
	@Deprecated
	@Override
	public String getServingUrlForDev(Images image) {
		try {
			//String url = "https://performance-dot-cocoworks-for-ecs.appspot.com" + CommonProperty.IMAGE_INFO_URL;
			String url = "https://cocoworks-for-ecs.appspot.com" + CommonProperty.IMAGE_INFO_URL;
			
			String bucket = image.getBucket();
			if (StringUtils.isBlank(bucket)) { bucket =  BUCKET_NAME; }
			
			Map<String, String> entityMap = new HashMap<String, String>();
			entityMap.put(FLD.filePath, image.getFilePath());
			entityMap.put(FLD.bucket, bucket );
			entityMap.put(FLD.imageSize, String.valueOf(image.getImageSize()));
			entityMap.put(FLD.secretKey, SECRET_KEY);
	//		url += "?" + FLD.bucket +"=" + URLEncoder.encode(bucket, CommonProperty.UTF_8);
	//		url += "&" + FLD.filePath +"=" + URLEncoder.encode(filePath, CommonProperty.UTF_8);
	//		url += "&" + FLD.imageSize +"=" + imageSize;
	//		url += "&" + FLD.secretKey +"=" + SECRET_KEY;
			ObjectMapper mapper = new ObjectMapper();	
			String result = ApacheHttpClient.postToAppengine(url, null, entityMap);
			Map<String, String> map = mapper.readValue(result, new TypeReference<Map<String, String>>(){});
			
			return map.get(FLD.servingUrl);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}
	
	
	@Override
	public List<Images> appendOrRemoveImages(String parentId, List<Images> newImages) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<Images> oldImages = listChildImages(mgr, parentId);
			List<Images> removeImages = listImagesToRemove(oldImages, newImages);
			
			for (Images image : removeImages) {
				removeImages(mgr, image.getImageId());
			}
			
			List<Images> resultImages = insertOrUpdateImages(mgr, parentId, newImages);
			
			return resultImages;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Images appendOrRemoveImages(String parentId, Images newImage) throws Exception {
		if (newImage == null || StringUtils.isBlank(newImage.getFilePath())) { return null; }
		EntityManager mgr = getEntityManager();
		try {
			Images oldImage = getChildImages(mgr, parentId);
			if (oldImage != null) {
				removeImages(mgr, oldImage.getImageId());
			}
			
			return insertOrUpdateImages(mgr, parentId, newImage);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Map<String, Object> getImageInfo(String bucketName, String filePath, int imageSize) throws Exception {
		GcsFilename gcs_filename = new GcsFilename(bucketName, filePath);
		GcsService service = GcsServiceFactory.createGcsService();
		GcsFileMetadata metaData = service.getMetadata(gcs_filename);
		
		Map<String, Object> metaMap = new HashMap<String, Object>();
		metaMap.put(FLD.fileName, metaData.getFilename().getObjectName());
		metaMap.put(FLD.lastModified, metaData.getLastModified());
		metaMap.put(FLD.fileSize, metaData.getLength());
		metaMap.put(FLD.mimeType, metaData.getOptions().getMimeType());
		metaMap.put(FLD.servingUrl, getServingUrl(bucketName, filePath, imageSize));
		
		return metaMap;
		//InputStream stream = Channels.newInputStream(rbc);
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public Images getImages(String imageId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getImages(mgr, imageId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private Images getImages(EntityManager mgr, String imageId) {
//		return doFind(mgr, Images.class, imageId);
//	}
//	@Override
//	public List<Images> listTaskTimelineImages(String taskTimelineId) throws Exception {
//		return listChildImages(taskTimelineId);
//	}
//	@Override
//	public Images removeImagesMetadata(String imageId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			doRemoveTransaction(mgr, Images.class, imageId);
//			try {
//				UsageService.decreaseUsage(image);
//			} catch (Exception ex) {}
//			
//			return image;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Images getUserImage(String userId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getChildImages(mgr, userId);
//		} catch (NoResultException ex) {
//			return null;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
