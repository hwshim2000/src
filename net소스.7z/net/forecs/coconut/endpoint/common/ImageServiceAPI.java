package net.forecs.coconut.endpoint.common;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.admin.IEmoticonService;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.appengine.api.NamespaceManager;

@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class ImageServiceAPI {
	private final IImageService imageService;
	private final IEmoticonService emoticonService;
	
	@Inject
	public ImageServiceAPI(IImageService imageService, IEmoticonService emoticonService) {
		this.imageService = imageService;
		this.emoticonService = emoticonService;
	}
	
	@ApiMethod(name = "queryEmoticons", path = "emoticons", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Emoticons> queryEmoticons(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			//@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.sortType) SortType sortType,
			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection) throws Exception {
		String domainName = NamespaceManager.get();
		QueryResult<Emoticons> result = emoticonService.queryEmoticons(cursorString, limit, domainName, sortType, sortDirection);
		return CollectionResponse.<Emoticons>builder().setItems(result.getResultList()).setNextPageToken(result.getNextPageToken()).build();
	}
	
	// ************* Unused service ******************
	@ApiMethod(name = "getServingUrl", path = "images/servingUrl", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result getServingUrl(@Named(FLD.bucket) String bucket, @Named(FLD.filePath) String filePath, @Named(FLD.imageSize) int imageSize) {
		return new Result(imageService.getServingUrl(bucket, filePath, imageSize));
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getImages", path = "images/{imageId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Images getImages(@Named(FLD.imageId) String imageId) throws UnavailableException {
//		CommonService.validNamespace(imageId);
//		return imageService.getImages(imageId);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "listTaskTimelineImages", path = "images/taskTimelines/{parentId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public List<Images> listTaskTimelineImages(@Named(FLD.parentId) String parentId) throws Exception {
//		CommonService.validNamespace(parentId);
//		return imageService.listTaskTimelineImages(parentId);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "insertOrUpdateImage", path = "images", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Images insertOrUpdateImage(Images image) throws Exception {
		if (StringUtils.isNotBlank(image.getParentId())) {
			CommonService.validNamespace(image.getParentId());
		}
		return imageService.insertOrUpdateImage(image);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "removeTaskTimelineImages", path = "images/taskTimelines/{taskTimelineId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeTaskTimelineImages(@Named(FLD.taskTimelineId) String taskTimelineId) throws Exception {
//		CommonService.validNamespace(taskTimelineId);
//		imageService.removeTaskTimelineImages(taskTimelineId);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "removeImages", path = "images/{imageId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public Images removeImages(@Named(FLD.imageId) String imageId) throws Exception {
//		CommonService.validNamespace(imageId);
//		return imageService.removeImages(imageId);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "removeImagesMetadata", path = "images/{imageId}/metadata", httpMethod = HttpMethod.DELETE)
//	@Deprecated
//	@RequiresUser
//	public Images removeImagesMetadata(@Named(FLD.imageId) String imageId) throws Exception {
//		CommonService.validNamespace(imageId);
//		return imageService.removeImagesMetadata(imageId);
//	}
}
