package net.forecs.coconut.endpoint.common;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.notice.Notice;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.ServiceException;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;


@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class NoticeServiceAPI {
	private final INoticeService noticeService;

	@Inject
	public NoticeServiceAPI(INoticeService noticeService) {
		this.noticeService = noticeService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryBoardNotice", path = "notice/boards", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Notice> queryBoardNotice(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		List<String> kindIdList = new ArrayList<String>();
		kindIdList.add(boardId);
		kindIdList.add(NoticeService.KINDID_DOMAIN_NOTICE);
		kindIdList.add(NoticeService.KINDID_SYSTEM_NOTICE);
		QueryResult<Notice> queryResult = noticeService.queryNotice(cursorString, limit, kindIdList);
		List<Notice> list = queryResult.getResultList();
		
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Notice> builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "queryTaskNotice", path = "notice/tasks", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Notice> queryTaskNotice(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.boardId) String boardId,
			@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		List<String> kindIdList = new ArrayList<String>();
		kindIdList.add(taskId);
		if (StringUtils.isNotBlank(boardId)) { kindIdList.add(boardId); }
		kindIdList.add(NoticeService.KINDID_DOMAIN_NOTICE);
		kindIdList.add(NoticeService.KINDID_SYSTEM_NOTICE);
		QueryResult<Notice> queryResult = noticeService.queryNotice(cursorString, limit, kindIdList);
		List<Notice> list = queryResult.getResultList();
		
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Notice> builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getNotice", path = "notice/{noticeId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Notice getNotice(@Named(FLD.noticeId) String noticeId) throws Exception {
		CommonService.validNamespace(noticeId);
		return noticeService.getNotice(noticeId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "insertNotice", path = "notice", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Notice insertNotice(Notice notice) throws Exception {
		CommonService.validNamespace(notice.getDomainId());
		return noticeService.insertNotice(notice);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateNotice", path = "notice", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Notice updateNotice(Notice notice) throws Exception {
		CommonService.validNamespace(notice);
		return noticeService.updateNotice(notice);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "updateNoticeTitle", path = "notice/{noticeId}/title", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Notice updateNoticeTitle(@Named(FLD.noticeId) String noticeId, @Named(FLD.title) String title) throws Exception {
//		CommonService.validNamespace(noticeId);
//		return noticeService.updateNoticeTitle(noticeId, title);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "updateNoticeDescription", path = "notice/{noticeId}/description", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Notice updateNoticeDescription(@Named(FLD.noticeId) String noticeId, Text description) throws Exception {
//		CommonService.validNamespace(noticeId);
//		return noticeService.updateNoticeDescription(noticeId, description);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "removeNotice", path = "notice/{noticeId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeNotice(@Named(FLD.noticeId) String noticeId) throws ServiceException, UnavailableException {
		CommonService.validNamespace(noticeId);
		noticeService.removeNotice(noticeId);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "bulkRemoveNotice", path = "notice/bulk", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public Result bulkRemoveNotice(
//			@Nullable @Named(FLD.noticeKind) NoticeKind noticeKind,
//			@Named(FLD.domainId) String domainId,
//			@Nullable @Named(FLD.kindId) String kindId,
//			@Nullable @Named(FLD.userId) String userId) throws Exception {
//		CommonService.validNamespace(domainId);
//		return new Result(noticeService.bulkRemoveNotice(noticeKind, domainId, kindId, userId));
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "addNoticeAttachment", path = "notice/{noticeId}/attachments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Attachments addNoticeAttachment(@Named(FLD.noticeId) String noticeId, Attachments attachment) throws Exception {
//		CommonService.validNamespace(noticeId);
//		return noticeService.addNoticeAttachment(noticeId, attachment);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "removeNoticeAttachment", path = "notice/{noticeId}/attachments/{attachmentId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public Attachments removeNoticeAttachment(@Named(FLD.noticeId) String noticeId, @Named(FLD.attachmentId) String attachmentId) throws Exception {
//		CommonService.validNamespace(noticeId);
//		return noticeService.removeNoticeAttachment(noticeId, attachmentId);
//	}
}