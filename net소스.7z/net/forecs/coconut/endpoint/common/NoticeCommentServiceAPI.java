package net.forecs.coconut.endpoint.common;


//@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
//@RequiresUser
public class NoticeCommentServiceAPI {
//	private final INoticeCommentService noticeCommentService;
//
//	@Inject
//	public NoticeCommentServiceAPI(INoticeCommentService noticeCommentService) {
//		this.noticeCommentService = noticeCommentService;
//	}
//	// ************* Unused service ******************
//	@ApiMethod(name = "listNoticeComments", path = "notice/comments", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<NoticeComments> listNoticeComments(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.noticeId) String noticeId) throws Exception {
//		if (StringUtils.isNotBlank(noticeId)) {
//			CommonService.validNamespace(noticeId);
//		}
//		QueryResult<NoticeComments> queryResult = noticeCommentService.listNoticeComments(cursorString, limit, noticeId);
//		List<NoticeComments> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<NoticeComments>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}
//	// ************* Unused service ******************
//	@ApiMethod(name = "getNoticeComments", path = "notice/comments/{noticeCommentId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public NoticeComments getNoticeComments(@Named(FLD.noticeCommentId) String noticeCommentId) throws UnavailableException {
//		CommonService.validNamespace(noticeCommentId);
//		return noticeCommentService.getNoticeComments(noticeCommentId);
//	}
//	// ************* Unused service ******************
//	@ApiMethod(name = "insertNoticeComments", path = "notice/comments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public NoticeComments insertNoticeComments(@Nullable @Named(FLD.parentNoticeCommentId) String parentNoticeCommentId,
//			NoticeComments noticecomments) throws Exception {
//		CommonService.validNamespace(noticecomments.getNoticeId());
//		return noticeCommentService.insertNoticeComments(parentNoticeCommentId, noticecomments);
//	}
//	// ************* Unused service ******************
//	@ApiMethod(name = "updateNoticeComments", path = "notice/comments", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public NoticeComments updateNoticeComments(NoticeComments noticecomments) throws Exception {
//		CommonService.validNamespace(noticecomments);
//		return noticeCommentService.updateNoticeComments(noticecomments);
//	}
//	// ************* Unused service ******************
//	@ApiMethod(name = "removeNoticeComments", path = "notice/comments/{noticeCommentId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeNoticeComments(@Named(FLD.noticeCommentId) String noticeCommentId) throws Exception {
//		CommonService.validNamespace(noticeCommentId);
//		noticeCommentService.removeNoticeComments(noticeCommentId);
//	}
}