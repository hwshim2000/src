package net.forecs.coconut.endpoint.common;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.CountNotice;
import net.forecs.coconut.common.code.NoticeKind;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.search.index.NoticeIndex;

import com.google.api.server.spi.ServiceException;
import com.google.appengine.api.datastore.Text;


public interface INoticeService extends ICommonService {
	public abstract QueryResult<Notice> queryNotice(String cursorString, Integer limit, Collection<String> kindIdList) throws Exception;
	public abstract QueryResult<Notice> queryNotice(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> kindIdList) throws Exception;
	
	public abstract Notice getNotice(String noticeId) throws Exception;
	public abstract Notice insertNotice(Notice notice) throws Exception;
	public abstract Notice updateNotice(Notice notice) throws Exception;

	public abstract void removeNotice(String noticeId) throws ServiceException;
	public abstract NoticeIndex createOrUpdateNoticeIndex(Notice notice);
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
	public abstract Attachments addNoticeAttachment(String noticeId, Attachments attachment) throws Exception;
	public abstract Attachments removeNoticeAttachment(String noticeId, String attachmentId) throws Exception;
	public abstract QueryResult<Notice> querySystemNotice(String cursorString, Integer limit) throws Exception;
	public abstract Notice getSystemNotice(String noticeId) throws Exception;
	public abstract Notice insertSystemNotice(List<String> domainNames, Notice notice) throws Exception;
	public abstract Notice updateSystemNotice(Notice notice) throws Exception;
	public abstract Notice updateSystemNoticeTitle(String noticeId, String title) throws Exception;
	public abstract Notice updateSystemNoticeDescription(String noticeId, Text Description) throws Exception;
	public abstract void removeSystemNotice(String noticeId) throws Exception;
	public abstract Notice updateNoticeTitle(String noticeId, String title) throws Exception;
	public abstract Notice updateNoticeDescription(String noticeId, Text description) throws Exception;
	public abstract NoticeIndex createOrUpdateNoticeIndex(String noticeId) throws Exception;
	public abstract void removeNoticeIndex(String noticeId);
	public abstract int bulkRemoveNotice(NoticeKind noticeKind, String kindId, String userId) throws Exception;
	public abstract Notice insertDomainNotice(Notice notice) throws Exception;
	public abstract Notice updateDomainNotice(Notice notice) throws Exception;
	public abstract void removeDomainNotice(String noticeId) throws ServiceException;
	public abstract CountNotice countNotice(CountNotice countNotice) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
