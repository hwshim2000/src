package net.forecs.coconut.endpoint.common;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.CountNotifications;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.channel.INotificationService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.shiro.annotation.RequiresMember;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;


@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class ActivityServiceAPI {
	private final IActivityService activityService;
	private final INotificationService notificationService;

	@Inject
	public ActivityServiceAPI(IActivityService activityService, INotificationService notificationService) {
		this.activityService = activityService;
		this.notificationService = notificationService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listActivities", path = "activities/boards/{boardId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	@RequiresMember(clazz = Boards.class, objectId = "{boardId}")
	public CollectionResponse<Activities> listActivities(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		QueryResult<Activities> queryResult = activityService.listActivities(cursorString, limit, boardId, null, true);
		List<Activities> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listNotifications", path = "notifications/boards/{boardId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	@RequiresMember(clazz = Boards.class, objectId = "{boardId}")
	public CollectionResponse<Activities> listNotifications(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Named(FLD.boardId) String boardId,
			@Nullable @Named(FLD.mention) Boolean mention) throws Exception {
		CommonService.validNamespace(boardId);
		QueryResult<Activities> queryResult = notificationService.listMyNotificationsByActivity(cursorString, limit, boardId, mention);
		List<Activities> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listDashboardActivities", path = "activities/dashboard", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Activities> listDashboardActivities(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		}
		QueryResult<Activities> queryResult = activityService.listDashboardActivities(cursorString, limit, null, true);
		List<Activities> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "listTaskActivities", path = "activities/task", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Activities> listTaskActivities(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.taskId) String taskId) throws Exception {
		if (StringUtils.isNotBlank(taskId)) {
			CommonService.validNamespace(taskId);
		}
		QueryResult<Activities> queryResult = activityService.listTaskActivities(cursorString, limit, taskId, null, true);
		List<Activities> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listDashboardNotifications", path = "notifications/dashboard", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Activities> listDashboardNotifications(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.mention) Boolean mention) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		}
		QueryResult<Activities> queryResult = notificationService.listMyNotificationsByActivity(cursorString, limit, null, mention);
		List<Activities> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "readCheckNotifications", path = "notifications/readCheck", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result readCheckNotifications(
			@Nullable @Named(FLD.activityIdList) List<String> activityIdList) throws Exception {
		CommonService.validNamespace(activityIdList.get(0));
		try {
			notificationService.updateNotificationsRead(activityIdList, true);
			return new Result(true);
		} catch (Exception ex) {
			return new Result(false);
		}
	}
	// ************* Unused service ******************
//	@ApiMethod(name = "unreadCheckNotifications", path = "notifications/unreadCheck", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Result unreadCheckNotifications(
//			@Nullable @Named(FLD.activityIdList) List<String> activityIdList) throws Exception {
//		CommonService.validNamespace(activityIdList.get(0));
//		try {
//			notificationService.updateNotificationsRead(activityIdList, false);
//			return new Result(true);
//		} catch (Exception ex) {
//			return new Result(false);
//		}
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "countUserNotifications", path = "notifications/count", httpMethod = HttpMethod.POST)
	@RequiresUser
	public CountNotifications countUserNotifications(CountNotifications countNotification) throws Exception {
		CommonService.validNamespace(countNotification.getCountInfos().get(0).getBoardId());
		return notificationService.countUserNotifications(countNotification);
	}
}