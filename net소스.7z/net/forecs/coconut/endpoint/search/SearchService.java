package net.forecs.coconut.endpoint.search;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.CommentType;
import net.forecs.coconut.common.query.SearchArea;
import net.forecs.coconut.common.query.SearchOption;
import net.forecs.coconut.common.query.SearchSortOption;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.NoticeService;
import net.forecs.coconut.endpoint.domain.IStageService;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.search.Attachment;
import net.forecs.coconut.entity.search.SearchResponse;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.SearchFieldsBuilder;
import net.forecs.coconut.search.index.AttachmentIndex;
import net.forecs.coconut.search.index.CommentIndex;
import net.forecs.coconut.search.index.EventIndex;
import net.forecs.coconut.search.index.NoticeIndex;
import net.forecs.coconut.search.index.TaskIndex;
import net.forecs.coconut.search.index.TimelineIndex;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.search.SortExpression;


public class SearchService extends CommonService implements ISearchService {
	private static final Logger LOG = Logger.getLogger(SearchService.class.getName());

	private static final boolean IS_SEARCH_WITH_MEMCACHE = true;
	private static final String NEXT_PAGE_TOKEN = "nextPageToken";
	private static final String ITEMS = "items";
	private static final String OBJS = "objs";
	private static final int DEFAULT_SEARCH_LIMIT = 10;
	//private static final String TOTAL_COUNT = "totalCount";
	
	private final IBoardService boardService;
	private final ITaskService taskService;
	private final ITaskTimelineService taskTimelineService;
	private final IStageService stageService;

	@Inject
	public SearchService(IBoardService boardService, ITaskService taskService, ITaskTimelineService taskTimelineService, IStageService stageService) {
		this.boardService = boardService;
		this.taskService = taskService;
		this.taskTimelineService = taskTimelineService;
		this.stageService = stageService;
	}
	
	@Override
	public Map<String, Map<String, Object>> search(String cursorString,
			Integer limit, Set<SearchArea> searchAreas, String boardId,
			String searchStr, SearchOption searchOption, Date startDate,
			Date endDate) throws Exception {
		Map<String, Object> taskResults = null;
		Map<String, Object> eventResults = null;
		Map<String, Object> timelineResults = null;
		Map<String, Object> commentsResults = null;
		Map<String, Object> attachmentsResults = null;
		
		if (searchAreas == null || searchAreas.contains(SearchArea.ALL)) {
			taskResults = searchTasks(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
			eventResults = searchEvents(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
			timelineResults = searchTimelines(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
			commentsResults = searchComments(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
			attachmentsResults = searchAttachments(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
		} else {
			for (SearchArea searchArea : searchAreas) {
				if (SearchArea.TASKS.equals(searchArea)) {
					taskResults = searchTasks(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
				} else if (SearchArea.EVENTS.equals(searchArea)) {
					eventResults = searchEvents(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
				} else if (SearchArea.TIMELINES.equals(searchArea)) {
					timelineResults = searchTimelines(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
				} else if (SearchArea.COMMENTS.equals(searchArea)) {
					commentsResults = searchComments(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
				} else if (SearchArea.ATTACHMENTS.equals(searchArea)) {
					attachmentsResults = searchAttachments(cursorString, limit, boardId, searchStr, searchOption, startDate, endDate);
				}
			}
		}
		
		Map<String, Map<String, Object>> results = new HashMap<String, Map<String, Object>>();
		
		if (taskResults != null) { results.put("task", taskResults); }
		if (eventResults != null) { results.put("event", eventResults); }
		if (timelineResults != null) { results.put("timeline", timelineResults); }
		if (commentsResults != null) { results.put("comment", commentsResults); }
		if (attachmentsResults != null) { results.put("attachment", attachmentsResults); }
		
		return results;
	}
	
	private Map<String, Object> searchTasks(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption, Date startDate, Date endDate) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<TaskIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption);
			List<String> boardIdList = getMyBoardIdList(boardId);
			List<String> taskIdList = getTaskIdListForPublicSearch(boardIdList);
			String queryStr = getQueryString(SearchArea.TASKS, boardIdList, taskIdList, searchStr, startDate, endDate);
			
			List<TaskIndex> taskIndexList = new ArrayList<TaskIndex>();
			List<String> taskIds = new ArrayList<String>();
			
			Map<Integer, Stages> stageMap = stageService.stageMapByStageOrdinal();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(TaskIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(TaskIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (TaskIndex taskIndex : results.getItems()) {
					if (taskIdList == null || (taskIdList != null && taskIdList.contains(taskIndex.getTaskId()))) {
						if (taskIndex.getStageOrdinal() != null) {
							taskIndex.setStage(stageMap.get(taskIndex.getStageOrdinal()));
						}
						taskIndexList.add(taskIndex);
						taskIds.add(taskIndex.getTaskId());
						cursorString = taskIndex.getNextPageToken();
						if (limit.equals(++i)) { break; }
					}
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			if (taskIndexList != null) {
				if (limit != taskIndexList.size() || taskIndexList.size() == 0) { cursorString = null; }
//				Map<String, Tasks> tasks = batchMapByKey(Tasks.class, taskIds);
//				for (TaskIndex index : taskIndexList) {
//					index.setObj(tasks.get(index.getTaskId()));
//				}
				resultMap.put(OBJS, batchListByKey(Tasks.class, taskIds));
				resultMap.put(ITEMS, taskIndexList);
				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}
	
	private Map<String, Object> searchComments(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption, Date startDate, Date endDate) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<CommentIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption);
			List<String> boardIdList = getMyBoardIdList(boardId);
			List<String> taskIdList = getTaskIdListForPublicSearch(boardIdList);
			String queryStr = getQueryString(SearchArea.COMMENTS, boardIdList, taskIdList, searchStr, startDate, endDate);
			List<CommentIndex> commentIndexList = new ArrayList<CommentIndex>();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(CommentIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(CommentIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (CommentIndex commentIndex : results.getItems()) {
					if (taskIdList == null || (taskIdList != null && taskIdList.contains(commentIndex.getTaskId()))) {
						commentIndexList.add(commentIndex);
						cursorString = commentIndex.getNextPageToken();
						if (limit.equals(++i)) { break; }
					}
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			if (commentIndexList != null) {
				if (limit != commentIndexList.size() || commentIndexList.size() == 0) { cursorString = null; }
				resultMap.put(ITEMS, commentIndexList);				
				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}
	
	private Map<String, Object> searchEvents(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption, Date startDate, Date endDate) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<EventIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption);
			List<String> boardIdList = getMyBoardIdList(boardId);
			List<String> taskIdList = getTaskIdListForPublicSearch(boardIdList);
			String queryStr = getQueryString(SearchArea.EVENTS, boardIdList, taskIdList, searchStr, startDate, endDate);
			
			List<EventIndex> eventIndexList = new ArrayList<EventIndex>();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(EventIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(EventIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (EventIndex eventIndex : results.getItems()) {
					if (StringUtils.isBlank(eventIndex.getTaskId()) || taskIdList == null || (taskIdList != null && taskIdList.contains(eventIndex.getTaskId()))) {
						eventIndexList.add(eventIndex);
						cursorString = eventIndex.getNextPageToken();
						if (limit.equals(++i)) { break; }
					}
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			if (eventIndexList != null) {
				if (limit != eventIndexList.size() || eventIndexList.size() == 0) { cursorString = null; }
				resultMap.put(ITEMS, eventIndexList);				
				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}

	private Map<String, Object> searchTimelines(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption, Date startDate, Date endDate) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<TimelineIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption);
			List<String> boardIdList = getMyBoardIdList(boardId);
			List<String> taskIdList = getTaskIdListForPublicSearch(boardIdList);
			String queryStr = getQueryString(SearchArea.TIMELINES, boardIdList, taskIdList, searchStr, startDate, endDate);

			List<TimelineIndex> timelineIndexList = new ArrayList<TimelineIndex>();
			List<String> timelineIds = new ArrayList<String>();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(TimelineIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(TimelineIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (TimelineIndex timelineIndex : results.getItems()) {
					if (taskIdList == null || (taskIdList != null && taskIdList.contains(timelineIndex.getTaskId()))) {
						timelineIndexList.add(timelineIndex);
						timelineIds.add(timelineIndex.getTaskTimelineId());
						cursorString = timelineIndex.getNextPageToken();
						if (limit.equals(++i)) { break; }
					}
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
		
			if (timelineIndexList != null) {
				EntityManager mgr = getEntityManager();
				try {
					if (limit != timelineIndexList.size() || timelineIndexList.size() == 0) { cursorString = null; }
					List<TaskTimelines> timelines = batchListByKey(mgr, TaskTimelines.class, timelineIds);
					
//					Map<String, List<Images>> imagesMap = taskTimelineService.batchMapTaskTimelineImages(mgr, timelines);
//					Map<String, List<Attachments>> attachmentsMap = taskTimelineService.batchMapTaskTimelineAttachments(mgr, timelines);
//					
//					for (TaskTimelines taskTimeline : timelines) {
//						taskTimeline.setImages(imagesMap.get(taskTimeline.getTaskTimelineId()));
//						taskTimeline.setAttachments(attachmentsMap.get(taskTimeline.getTaskTimelineId()));
//					}
					
					taskTimelineService.setTaskTimelinesDetail(timelines);
					
					resultMap.put(OBJS, timelines);
					resultMap.put(ITEMS, timelineIndexList);
					resultMap.put(NEXT_PAGE_TOKEN, cursorString);
				} finally {
					finalizeTransaction(mgr);
				}
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}
	
	private Map<String, Object> searchAttachments(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption, Date startDate, Date endDate) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<AttachmentIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
//		List<AttachmentsMap> attachmentsMapList = new ArrayList<AttachmentsMap>();

		try {
			if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption, FLD.fileName);
			List<String> boardIdList = getMyBoardIdList(boardId);
			List<String> taskIdList = getTaskIdListForPublicSearch(boardIdList);
			String queryStr = getQueryString(SearchArea.ATTACHMENTS, boardIdList, taskIdList, searchStr, startDate, endDate);

			List<AttachmentIndex> attachmentIndexList = new ArrayList<AttachmentIndex>();
			List<String> attachmentsIds = new ArrayList<String>();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (AttachmentIndex attachmentIndex : results.getItems()) {
					if (taskIdList == null || (taskIdList != null && taskIdList.contains(attachmentIndex.getTaskId()))) {
						attachmentIndexList.add(attachmentIndex);
						attachmentsIds.add(attachmentIndex.getAttachmentId());
						cursorString = attachmentIndex.getNextPageToken();
						if (limit.equals(++i)) { break; }
					}
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			if (attachmentIndexList != null) {
				if (limit != attachmentIndexList.size() || attachmentIndexList.size() == 0) { cursorString = null; }
//				Map<String, Attachments> attachments = batchMapByKey(Attachments.class, attachmentsIds);
//				for (AttachmentIndex index : attachmentIndexList) {
//					index.setObj(attachments.get(index.getAttachmentId()));
//				}
				resultMap.put(OBJS, batchListByKey(Attachments.class, attachmentsIds));
				resultMap.put(ITEMS, attachmentIndexList);
				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}

	
	@Override
	public List<Attachments> listAttachments(String boardId, String taskId, String userId) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<AttachmentIndex> results = null;
		//Map<String, Object> resultMap = new HashMap<String, Object>();
		List<Attachments> attachments = new ArrayList<Attachments>();

		try {
			//if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			Integer limit = 1000;
			List<SearchSortOption> ssolist = translateSearchSortOption(null, FLD.fileName);
			
			String queryStr = attachmentQueryString(boardId, taskId, null, null, null, null);

			List<AttachmentIndex> attachmentIndexList = new ArrayList<AttachmentIndex>();
			List<String> attachmentsIds = new ArrayList<String>();
			
			String nextCursorString = null;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (AttachmentIndex attachmentIndex : results.getItems()) {
					attachmentIndexList.add(attachmentIndex);
					attachmentsIds.add(attachmentIndex.getAttachmentId());
					//cursorString = attachmentIndex.getNextPageToken();
					if (limit.equals(++i)) { break; }
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			if (attachmentIndexList != null) {
				List<Attachments> batchResults = batchListByKey(Attachments.class, attachmentsIds);
				if (StringUtils.isNotBlank(userId)) {
					for (Attachments attachment : batchResults) {
						if (StringUtils.equals(userId, attachment.getCreator())) {
							attachments.add(attachment);
						}
					}
				} else {
					attachments.addAll(batchResults);
				}
//				resultMap.put(OBJS, batchListByKey(Attachments.class, attachmentsIds));
//				resultMap.put(ITEMS, attachmentIndexList);
//				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return attachments;
	}
	
	@Override
	public Map<String, Object> queryAttachments(String cursorString, Integer limit, String boardId, String taskId, String userId, String searchStr, SearchOption searchOption, Date startDate, Date endDate) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<AttachmentIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
//		List<AttachmentsMap> attachmentsMapList = new ArrayList<AttachmentsMap>();

		try {
			//if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			if (limit == null || limit == 0) { limit = 1000; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption, FLD.fileName);
			
			String queryStr = attachmentQueryString(boardId, taskId, userId, searchStr, startDate, endDate);

			List<AttachmentIndex> attachmentIndexList = new ArrayList<AttachmentIndex>();
			List<String> attachmentsIds = new ArrayList<String>();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (AttachmentIndex attachmentIndex : results.getItems()) {
					attachmentIndexList.add(attachmentIndex);
					attachmentsIds.add(attachmentIndex.getAttachmentId());
					cursorString = attachmentIndex.getNextPageToken();
					if (limit.equals(++i)) { break; }
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			if (attachmentIndexList != null) {
				if (limit != attachmentIndexList.size() || attachmentIndexList.size() == 0) { cursorString = null; }
//				Map<String, Attachments> attachments = batchMapByKey(Attachments.class, attachmentsIds);
//				for (AttachmentIndex index : attachmentIndexList) {
//					index.setObj(attachments.get(index.getAttachmentId()));
//				}
				resultMap.put(OBJS, batchListByKey(Attachments.class, attachmentsIds));
				resultMap.put(ITEMS, attachmentIndexList);
				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}
	
	@SuppressWarnings("unused")
	private Map<String, Object> searchNotice(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption) throws IOException {
		SearchManager searchManager = new SearchManager();
		SearchResponse<NoticeIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption);
			
			List<String> boardIdList = new ArrayList<String>();
			boardIdList.add(boardId);
			boardIdList.add(NoticeService.KINDID_SYSTEM_NOTICE);
			boardIdList.add(NoticeService.KINDID_DOMAIN_NOTICE);
			
			String queryStr = new SearchFieldsBuilder()
//						.and(FLD.boardId, boardId)
						.and(FLD.kindId, boardIdList)
						.or(FLD.title, searchStr)
						.or(FLD.description, searchStr)
						//.or(FLD.attachments, searchStr)
						.build();

			if (IS_SEARCH_WITH_MEMCACHE) {
				results = searchManager.searchDocumentsWithMemcache(NoticeIndex.class, cursorString, limit, queryStr, ssolist);
			} else {
				results = searchManager.searchDocuments(NoticeIndex.class, cursorString, limit, queryStr, ssolist);
			}
			
			if (results != null && results.getItems() != null) {
				resultMap.put(ITEMS, results.getItems());
				resultMap.put(NEXT_PAGE_TOKEN, results.getNextPageToken());
				//resultMap.put(TOTAL_COUNT, results.getTotalCount());
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}

	@SuppressWarnings("unused")
	private Map<String, Object> searchDashboardNotice(String cursorString, Integer limit, String searchStr, SearchOption searchOption) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<NoticeIndex> results = null;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			if (limit == null || limit == 0) { limit = DEFAULT_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption);
			List<String> boardIdList = getMyBoardIdList();
			Set<String> boardIds = null;

			boardIdList.add(NoticeService.KINDID_SYSTEM_NOTICE);
			boardIdList.add(NoticeService.KINDID_DOMAIN_NOTICE);
			
			if (boardIdList.size() > 50) {
				boardIds = new HashSet<String>();
				boardIds.addAll(boardIdList);
				boardIdList.clear();
				boardIdList = null;
			}
			String queryStr = new SearchFieldsBuilder()
//						.and(FLD.boardId, boardIdList)
						.and(FLD.kindId, boardIdList)
						.or(FLD.title, searchStr)
						.or(FLD.description, searchStr)
						//.or(FLD.attachments, searchStr)
						.build();
			
			List<NoticeIndex> noticeIndexList = new ArrayList<NoticeIndex>();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
				if (IS_SEARCH_WITH_MEMCACHE) {
					results = searchManager.searchDocumentsWithMemcache(NoticeIndex.class, nextCursorString, limit, queryStr, ssolist);
				} else {
					results = searchManager.searchDocuments(NoticeIndex.class, nextCursorString, limit, queryStr, ssolist);
				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				
				for (NoticeIndex noticeIndex : results.getItems()) {
					if (boardIds == null || (boardIds != null && boardIds.contains(noticeIndex.getKindId()))) {
						noticeIndexList.add(noticeIndex);
						cursorString = noticeIndex.getNextPageToken();
						if (limit.equals(++i)) { break; }
					}
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			if (noticeIndexList != null) {
				if (limit != noticeIndexList.size() || noticeIndexList.size() == 0) { cursorString = null; }
				resultMap.put(ITEMS, noticeIndexList);
				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
			
//			if (CommonProperty.IS_SEARCH_WITH_MEMCACHE) {
//				results = searchManager.searchDocumentsWithMemcache(NoticeIndex.class, cursorString, limit, queryStr, ssolist);
//			} else {
//				results = searchManager.searchDocuments(NoticeIndex.class, cursorString, limit, queryStr, ssolist);
//			}
			
//			if (noticeIndexList != null && noticeIndexList.getItems() != null) {
//				resultMap.put(ITEMS, results.getItems());
//				resultMap.put(NEXT_PAGE_TOKEN, results.getNextPageToken());
//				//resultMap.put(TOTAL_COUNT, results.getTotalCount());
//			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}
	
	@Override
	public Map<String, Map<String, List<Attachment>>> searchAttachmentsForFileManage(String cursorString, Integer limit, String boardId, String taskId, String searchStr, SearchOption searchOption) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<AttachmentIndex> results = null;
		Map<String, Map<String, List<Attachment>>> resultMap = new TreeMap<String, Map<String, List<Attachment>>>();
//		List<AttachmentsMap> attachmentsMapList = new ArrayList<AttachmentsMap>();

		try {
			if (limit == null || limit == 0) { limit = SearchManager.MAX_SEARCH_LIMIT; }
			List<SearchSortOption> ssolist = translateSearchSortOption(searchOption, FLD.fileName);
			
			String queryStr = new SearchFieldsBuilder()
				.and(FLD.archiveYN, N)
				//.and(FLD.kind, Arrays.asList(new String[] { Tasks.class.getSimpleName(), TaskTimelines.class.getSimpleName() }))
				.and(FLD.boardId, boardId)
				.and(FLD.taskId, taskId)
//				.andBetween(FLD.created, startDate, endDate)
				.or(FLD.fileName, searchStr)
				.build();

			List<AttachmentIndex> attachmentIndexList = new ArrayList<AttachmentIndex>();
			List<String> attachmentsIds = new ArrayList<String>();
			
			String nextCursorString = cursorString;
			int i = 0;
			while(true) {
//				if (CommonProperty.IS_SEARCH_WITH_MEMCACHE) {
//					results = searchManager.searchDocumentsWithMemcache(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
//				} else {
					results = searchManager.searchDocuments(AttachmentIndex.class, nextCursorString, limit, queryStr, ssolist);
//				}
				
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				for (AttachmentIndex attachmentIndex : results.getItems()) {
					attachmentIndexList.add(attachmentIndex);
					attachmentsIds.add(attachmentIndex.getAttachmentId());
					cursorString = attachmentIndex.getNextPageToken();
					if (limit.equals(++i)) { break; }
				}
				if (limit.equals(i) || results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
			
			if (attachmentIndexList != null) {
				if (limit != attachmentIndexList.size() || attachmentIndexList.size() == 0) { cursorString = null; }
				Map<String, Attachments> attachments = batchMapByKey(Attachments.class, attachmentsIds);
				for (AttachmentIndex index : attachmentIndexList) {
					if (!resultMap.containsKey(index.getBoardId())) { resultMap.put(index.getBoardId(), new TreeMap<String, List<Attachment>>()); }
					if (!resultMap.get(index.getBoardId()).containsKey(index.getTaskId())) { resultMap.get(index.getBoardId()).put(index.getTaskId(), new ArrayList<Attachment>()); }
					resultMap.get(index.getBoardId()).get(index.getTaskId()).add(new Attachment(index, attachments.get(index.getAttachmentId())));
				}
//				resultMap.put(OBJS, batchListByKey(Attachments.class, attachmentsIds));
//				resultMap.put(ITEMS, attachmentIndexList);
//				resultMap.put(NEXT_PAGE_TOKEN, cursorString);
			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;
	}
	
	@Override
	public void moveBoardOfTaskAttachments(String taskId, String toBoardId) throws Exception {
		SearchManager searchManager = new SearchManager();
		SearchResponse<AttachmentIndex> results = null;
//		Map<String, Map<String, List<Attachment>>> resultMap = new TreeMap<String, Map<String, List<Attachment>>>();
//		List<AttachmentsMap> attachmentsMapList = new ArrayList<AttachmentsMap>();

		try {
			Integer limit = SearchManager.MAX_SEARCH_LIMIT;
			
			String queryStr = new SearchFieldsBuilder()
				//.and(FLD.boardId, boardId)
				.and(FLD.taskId, taskId)
				.build();

			List<AttachmentIndex> attachmentIndexList = new ArrayList<AttachmentIndex>();
			List<String> attachmentsIds = new ArrayList<String>();
			
			String nextCursorString = null;
			while(true) {
				results = searchManager.searchDocuments(AttachmentIndex.class, nextCursorString, limit, queryStr, null);
				if (results == null || results.getItems() == null || results.getItems().size() == 0) { break; }
				
				for (AttachmentIndex index : results.getItems()) {
					searchManager.updateIndexField(AttachmentIndex.class, KeyFactory.keyToString(index.getKey()), FLD.boardId, toBoardId);
					attachmentsIds.add(index.getAttachmentId());
				}
				attachmentIndexList.addAll(results.getItems());
				
				if (results.getItems().size() < limit) { break; }
				nextCursorString = results.getNextPageToken();
				if (StringUtils.isBlank(nextCursorString)) { break; }
			}
			
//			if (attachmentIndexList != null) {
//				Map<String, Attachments> attachments = batchMapByKey(Attachments.class, attachmentsIds);
//				for (AttachmentIndex index : attachmentIndexList) {
//					if (!resultMap.containsKey(index.getBoardId())) { resultMap.put(index.getBoardId(), new TreeMap<String, List<Attachment>>()); }
//					if (!resultMap.get(index.getBoardId()).containsKey(index.getTaskId())) { resultMap.get(index.getBoardId()).put(index.getTaskId(), new ArrayList<Attachment>()); }
//					resultMap.get(index.getBoardId()).get(index.getTaskId()).add(new Attachment(index, attachments.get(index.getAttachmentId())));
//				}
//			}
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		//return resultMap;
	}


	private List<SearchSortOption> translateSearchSortOption(SearchOption searchOption) {
		return translateSearchSortOption(searchOption, FLD.title);
	}
	private List<SearchSortOption> translateSearchSortOption(SearchOption searchOption, String defaultSortField) {
		List<SearchSortOption> ssolist = new ArrayList<SearchSortOption>();
		
		if (searchOption == null || searchOption.getSortOptions() == null || searchOption.getSortOptions().size() == 0) {
			SearchSortOption sso = new SearchSortOption(defaultSortField, SortExpression.SortDirection.ASCENDING, "");
			ssolist.add(sso);
		} else {
			ssolist.addAll(searchOption.getSortOptions());
		}
		return ssolist;
	}

	private List<String> getMyBoardIdList() throws Exception {
		return getMyBoardIdList(null);
	}
	private List<String> getMyBoardIdList(String boardId) throws Exception {
		List<String> boardIdList = new ArrayList<String>();
		if (StringUtils.isNotBlank(boardId)) {
			boardIdList.add(boardId);
		} else {
			// 내가 속한 보드 목록 + Search가 공개된 보드 목록
			List<Boards> myBoards = boardService.getMyBoards();
			for (Boards board : myBoards) { boardIdList.add(board.getBoardId()); }
		}
		return boardIdList;
	}
	
	@SuppressWarnings("unused")
	private List<String> getTaskIdListForPublicSearch(String boardId) {
		if (StringUtils.isBlank(boardId)) { return null; }
		return getTaskIdListForPublicSearch(Arrays.asList(new String[]{ boardId }));
	}
	private List<String> getTaskIdListForPublicSearch(Collection<String> boardIdList) {
		if (boardIdList == null || boardIdList.size() == 0) { return null; }
		try {
			List<String> taskIdList = taskService.listMyTaskIds(boardIdList);
			return taskIdList;	
		} catch (Exception ex) { LOG.warning(ex.getMessage()); return null; }
		
	}
	
	private static String getQueryString(SearchArea area, List<String> boardIdList, List<String> taskIdList, String searchStr, Date startDate, Date endDate) {
		String queryStr = validQueryString(area, null, taskIdList, searchStr, startDate, endDate);
		if (queryStr.length() < 2000) { return queryStr; }
		queryStr = validQueryString(area, boardIdList, null, searchStr, startDate, endDate);
		if (queryStr.length() < 2000) { return queryStr; }
		return queryStr = validQueryString(area, null, null, searchStr, startDate, endDate);
	}
	
	private static <T> String validQueryString(SearchArea area, List<String> boardIdList, List<String> taskIdList, String searchStr, Date startDate, Date endDate) {
		String queryStr = null;
		switch(area) {
			case TASKS : {
				queryStr = new SearchFieldsBuilder()
				.and(FLD.archiveYN, N)
				.and(FLD.boardId, boardIdList)
				.and(FLD.taskId, taskIdList)
				.andBetween(FLD.created, startDate, endDate)
				.or(FLD.title, searchStr)
				.or(FLD.description, searchStr)
				.or(FLD.checklists, searchStr)
				.or(FLD.wiki, searchStr)
		//		.or(FLD.labels, searchStr)
		//		.or(FLD.assignMembers, searchStr)
		//		.or(FLD.attachments, searchStr)
				.build();
				break;
			}
			case EVENTS : {
				queryStr = new SearchFieldsBuilder()
				.and(FLD.boardId, boardIdList)
				.and(FLD.taskId, taskIdList)
				.andBetween(FLD.created, startDate, endDate)
				.or(FLD.title, searchStr)
				.or(FLD.description, searchStr)
				.build();
				break;
			}
			case TIMELINES : {
				queryStr = new SearchFieldsBuilder()
				.and(FLD.boardId, boardIdList)
				.and(FLD.taskId, taskIdList)
				.andBetween(FLD.created, startDate, endDate)
				.or(FLD.description, searchStr)
				.or(FLD.links, searchStr)
				//.or(FLD.attachments, searchStr)
				.build();
				break;
			}
			case COMMENTS : {
				queryStr = new SearchFieldsBuilder()
				// 2016-10-10 TimelineComments 타입외에 나머지는 모두 deprecated 된 상태이기 때문에 TimelineComments만 검색되도록 변경하였다.
				// (이유 : 이전에 혹시라도 기록되어 있던 Comment가 검색될수도 있기때문에)
				.and(FLD.commentType, CommentType.TIMELINE.toString())
				.and(FLD.boardId, boardIdList)
				.and(FLD.taskId, taskIdList)
				.andBetween(FLD.created, startDate, endDate)
//				.or(FLD.title, searchStr)
				.or(FLD.description, searchStr)
				.build();
				break;
			}
			case ATTACHMENTS : {
				queryStr = new SearchFieldsBuilder()
				.and(FLD.archiveYN, N)
				.and(FLD.kind, Arrays.asList(new String[] { Tasks.class.getSimpleName(), TaskTimelines.class.getSimpleName() }))
				.and(FLD.boardId, boardIdList)
				.and(FLD.taskId, taskIdList)
				.andBetween(FLD.created, startDate, endDate)
		//		.or(FLD.title, searchStr)
		//		.or(FLD.description, searchStr)
				.or(FLD.fileName, searchStr)
				.build();
				break;
			}
			default :
				queryStr = "";
				break;
		}
	
		return queryStr;
	}
	
	private static String attachmentQueryString(String boardId, String taskId, String userId, String searchStr, Date startDate, Date endDate) {
		String queryStr = new SearchFieldsBuilder()
				.and(FLD.archiveYN, N)
				.and(FLD.kind, Arrays.asList(new String[] { Tasks.class.getSimpleName(), TaskTimelines.class.getSimpleName() }))
				.and(FLD.boardId, boardId)
				.and(FLD.taskId, taskId)
				.and(FLD.creator, userId)
				.andBetween(FLD.created, startDate, endDate)
		//		.or(FLD.title, searchStr)
		//		.or(FLD.description, searchStr)
				.or(FLD.fileName, searchStr)
				.build();
	
		return queryStr;
	}
	
	public static void main(String[] args) throws Exception {
		Object o = 0L;
		
		System.out.println((Date)o);
	}
}
