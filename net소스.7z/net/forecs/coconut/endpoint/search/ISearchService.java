package net.forecs.coconut.endpoint.search;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.forecs.coconut.common.query.SearchArea;
import net.forecs.coconut.common.query.SearchOption;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.search.Attachment;


public interface ISearchService extends ICommonService {
	public abstract Map<String, Map<String, Object>> search(
			String cursorString, Integer limit, Set<SearchArea> searchAreas,
			String boardId, String searchStr, SearchOption searchOption,
			Date startDate,	Date endDate) throws Exception;

	public abstract Map<String, Map<String, List<Attachment>>> searchAttachmentsForFileManage(String cursorString, Integer limit, String boardId, String taskId, String searchStr, SearchOption searchOption) throws Exception;
	public abstract Map<String, Object> queryAttachments(String cursorString, Integer limit, String boardId, String taskId, String userId, String searchStr, SearchOption searchOption, Date startDate, Date endDate) throws Exception;
	public abstract List<Attachments> listAttachments(String boardId, String taskId, String userId) throws Exception;
	
	public abstract void moveBoardOfTaskAttachments(String taskId, String toBoardId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract Map<String, Object> searchTasks(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchComments(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchEvents(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchTimelines(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchNotice(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchAttachments(String cursorString, Integer limit, String boardId, String searchStr, SearchOption searchOption) throws Exception;
//
//	public abstract Map<String, Object> searchDashboardTasks(String cursorString, Integer limit, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchDashboardComments(String cursorString, Integer limit, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchDashboardEvents(String cursorString, Integer limit, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchDashboardTimelines(String cursorString, Integer limit, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchDashboardNotice(String cursorString, Integer limit, String searchStr, SearchOption searchOption) throws Exception;
//	public abstract Map<String, Object> searchDashboardAttachments(String cursorString, Integer limit, String searchStr, SearchOption searchOption) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
