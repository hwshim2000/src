package net.forecs.coconut.endpoint.search;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.logging.Level;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.query.SearchSortOption;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.security.SecurityUtils;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.search.SearchResponse;
import net.forecs.coconut.search.SearchStorageUsage;
import net.forecs.coconut.search.index.AttachmentIndex;
import net.forecs.coconut.search.index.CommentIndex;
import net.forecs.coconut.search.index.EventIndex;
import net.forecs.coconut.search.index.NoticeIndex;
import net.forecs.coconut.search.index.TaskIndex;
import net.forecs.coconut.search.index.TimelineIndex;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.util.ClassUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;
import com.google.appengine.api.memcache.Expiration;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;
import com.google.appengine.api.search.Document;
import com.google.appengine.api.search.Field;
import com.google.appengine.api.search.GeoPoint;
import com.google.appengine.api.search.GetIndexesRequest;
import com.google.appengine.api.search.GetRequest;
import com.google.appengine.api.search.GetResponse;
import com.google.appengine.api.search.Index;
import com.google.appengine.api.search.IndexSpec;
import com.google.appengine.api.search.PutException;
import com.google.appengine.api.search.PutResponse;
import com.google.appengine.api.search.Query;
import com.google.appengine.api.search.QueryOptions;
import com.google.appengine.api.search.Results;
import com.google.appengine.api.search.Schema;
import com.google.appengine.api.search.ScoredDocument;
import com.google.appengine.api.search.SearchException;
import com.google.appengine.api.search.SearchServiceConfig;
import com.google.appengine.api.search.SearchServiceFactory;
import com.google.appengine.api.search.SortExpression;
import com.google.appengine.api.search.SortOptions;
import com.google.appengine.api.search.StatusCode;

public class SearchManager {
	private static final Logger LOG = Logger.getLogger(SearchManager.class.getName());
	private final SearchServiceConfig config;
	
	/** UNIT(seconds): search result keep memcache. */
	private static  final int SEARCH_RESULT_KEEP_TIME = 60;
	private static final String NEXT_PAGE_TOKEN = "nextPageToken";
	private static final int MAX_DELETE_LIMIT = 200;
	public static final int MAX_SEARCH_LIMIT = 1000;
	private static final int MAX_SORT_LIMIT = 10000;
	private static final int NUMBER_FOUND_ACCURACY = 25000; // max value : 25000
	
	private final static Map<String, String> sortValueTypes;
	static {
		sortValueTypes = new HashMap<String, String>();
		sortValueTypes.put("created", Date.class.getSimpleName());
		sortValueTypes.put("modified", Date.class.getSimpleName());
		sortValueTypes.put("lastCommented", Date.class.getSimpleName());
		sortValueTypes.put("dueDate", Date.class.getSimpleName());
		sortValueTypes.put("completeDate", Date.class.getSimpleName());
		sortValueTypes.put("boardCreated", Date.class.getSimpleName());
		sortValueTypes.put("stageOrdinal", Number.class.getSimpleName());
	}
	
	@Getter @Setter
	private boolean isCursorPerResult = true;
	
	/**
	 * namespace 가 Null이면 현재 셋팅되어 있는 Namespace를 기준으로한다(!!!!! default namespace가 아님(물론 default로 셋팅되어 있으면 default)
	 * namespace 가 "" (empty)면 default namespace임
	 * namespace 가 null 혹은 "" 이 아니면 지정된 namespace에서 검색을 하게 된다.
	 * @param namespace
	 */
	public SearchManager() {
		config = SearchServiceConfig.newBuilder().setNamespace(null).build();
	}
	
	public SearchManager(String namespace) {
		config = SearchServiceConfig.newBuilder().setNamespace(namespace).build();
	}
	
	private <T> Document retrieveDocument(Class<T> type, String documentId) {
		String indexName = type.getSimpleName();
		IndexSpec indexSpec = IndexSpec.newBuilder().setName(indexName).build();
		Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
		//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);
		
		return index.get(documentId);
	}
	
	private <T> T getEntity(Class<T> type, String documentId) {
		return getEntityFromDocument(type, retrieveDocument(type, documentId));
	}
	
	public <T> void updateIndexField(Class<T> type, String documentId, String fieldName, Object obj) throws PutException, Exception {
		try {
			updateIndexField(type, documentId, fieldName, obj, null);
		} catch (PutException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
	}
	public <T> void updateIndexField(Class<T> type, String documentId, String fieldName, Object obj, Date modified) throws PutException, Exception {
		try {
			T entity = getEntity(type, documentId);
			injectObject(entity, fieldName, obj);
			if (modified != null) {
				injectObject(entity, "modified", modified);
			}
			createIndex(entity);
		} catch (PutException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
	}

	public <T> void updateIndexField(Class<T> type, String documentId, Map<String, Object> objMap) throws PutException, Exception {
		try {
			T entity = getEntity(type, documentId);
			for (Map.Entry<String, Object> entry : objMap.entrySet()) {
				injectObject(entity, entry.getKey(), entry.getValue());
			}
			
			createIndex(entity);
		} catch (PutException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@SuppressWarnings("unused")
	private <T> Results<ScoredDocument> retrieveDocuments(Class<T> type, String searchText) {
		String indexName = type.getSimpleName();
		IndexSpec indexSpec = IndexSpec.newBuilder().setName(indexName).build();
		Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);

		return index.search(searchText);
	}
	
	public <T> SearchResponse<T> searchDocuments(Class<T> type, String cursorStr, Integer limit, String queryStr, List<SearchSortOption> searchSortOptions) throws IOException {
		Results<ScoredDocument> results = null;
		//Cursor cursor = null;
		SearchResponse<T> searchResults = null;
		List<T> list = null;
		long totalCount = 0;
		String nextPageToken = null;
		int searchLimit = MAX_SEARCH_LIMIT;
		int offset = 0;
		if (limit != null && limit > 0) { searchLimit = limit; }
		try {
			if (!isIndexed(type)) { return null; }
			
			if (StringUtils.isNotEmpty(cursorStr) && StringUtils.isNumeric(cursorStr)) {
				offset = Integer.parseInt(cursorStr);
			} 
			
			SortOptions sortOptions = null;
			if (searchSortOptions != null) {
				SortOptions.Builder sortBuilder = SortOptions.newBuilder();
				for (SearchSortOption sso : searchSortOptions) {
					SortExpression.Builder expBuilder = getSortExpressionBuilder(sso);
					if (expBuilder!=null) {
						sortBuilder.addSortExpression(expBuilder);
					}
				}
				sortOptions = sortBuilder
						.setLimit(MAX_SORT_LIMIT)
						.build();
			}

			// Build the QueryOptions
			QueryOptions.Builder queryBuilder = QueryOptions.newBuilder();

			queryBuilder = queryBuilder
				//.setFieldsToReturn(FLD.title, FLD.description, FLD.creator, FLD.created)
				.setOffset(offset) // offset and cursor cannot be set in the same request 
				.setLimit(searchLimit)
				.setNumberFoundAccuracy(NUMBER_FOUND_ACCURACY);
				//.setCursor(cursor);
			
			if (TaskIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.tasklistId, FLD.stageOrdinal, FLD.taskId);
			} else if (AttachmentIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.kind, FLD.kindId, FLD.attachmentId);
//			} else if (ChecklistHistoryIndex.class.equals(type)) {
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.checklistId, FLD.taskChecklistHistoryId, FLD.activityType);
//			} else if (ChecklistIndex.class.equals(type)) {
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.taskChecklistId);
			} else if (CommentIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.commentId, FLD.commentType);
			} else if (EventIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.eventId, FLD.eventType);
			} else if (NoticeIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.kindId, FLD.boardId, FLD.noticeId);
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.noticeId);
			} else if (TimelineIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.taskTimelineId);
//			} else if (UserIndex.class.equals(type)) {
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.id, FLD.userId, FLD.email, FLD.userName, FLD.nickName, FLD.isActive, FLD.isValid);
			}
			
			if (sortOptions != null) { queryBuilder = queryBuilder.setSortOptions(sortOptions); }

			QueryOptions options = queryBuilder.build();

			Query query = Query.newBuilder().setOptions(options).build(queryStr);
			
			IndexSpec indexSpec = IndexSpec.newBuilder().setName(type.getSimpleName()).build();
			Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
			//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);
			
			nextPageToken = null;
			results = index.search(query);
			
			if (results != null) {
				LOG.info("[QueryIndex] "+index.toString());
				LOG.info("[QueryString] "+queryStr);
				LOG.info("[TotalResultCount] "+results.getNumberFound());
				LOG.info("[FetchCount] "+results.getNumberReturned());
				
				totalCount = results.getNumberFound();
				
				list = getEntityFromDocument(type, results, offset);
				
				if (list != null && list.size() > 0 && list.size() == searchLimit){
					nextPageToken = extractCursor(list.get(list.size() - 1));
				}
			}
		} catch (SearchException ex) {
			if (StatusCode.TRANSIENT_ERROR.equals(ex.getOperationResult().getCode())) {
				// retry
			}
		} catch (NegativeArraySizeException ex) {
			LOG.log(Level.WARNING, ex.getMessage());
		}

		searchResults = SearchResponse.<T>builder()
				.setItems(list)
				.setNextPageToken(nextPageToken)
				.setTotalCount(totalCount)
				.build();
		
		return searchResults;
	}
	
	public <T> SearchResponse<T> searchDocumentsWithMemcache(Class<T> type, String cursorString, Integer limit, String queryStr, List<SearchSortOption> searchSortOptions) throws IOException {
		int searchLimit = MAX_SEARCH_LIMIT;
		if (limit != null) { searchLimit = limit; }
		String nextCursorStr = cursorString;
		int bulkCursor = 0;
		if (StringUtils.isNotBlank(cursorString) && StringUtils.isNumeric(cursorString)) {
			bulkCursor = Integer.parseInt(cursorString)/MAX_SEARCH_LIMIT;
		}
		long totalCount = 0;
		boolean isLastFetch = false;
		List<T> allResults = null;
		List<T> resultList = new ArrayList<T>();
		
		try {
			while(true) {
				allResults = bulkSearchWithMemcache(type, bulkCursor++, queryStr, searchSortOptions);
				if (allResults == null || allResults.size() != MAX_SEARCH_LIMIT) { isLastFetch = true; }
				else { isLastFetch = false; }
				
				if (allResults != null && allResults.size() > 0) {
					totalCount += allResults.size();
					boolean isFindCursor = false;
					for (T object : allResults) {
						if (StringUtils.isEmpty(nextCursorStr) || isFindCursor) {
							resultList.add(object);
							
							if (searchLimit == resultList.size()) { break; }
						} else {
							java.lang.reflect.Field field = object.getClass().getDeclaredField(NEXT_PAGE_TOKEN);
							field.setAccessible(true);
							String nextPageToken = (String)field.get(object);
							
							if (nextPageToken.equals(nextCursorStr)) { isFindCursor = true; }
							continue;
						}
					}
					
					if (resultList.size() < searchLimit) {
						if (isLastFetch) {
							nextCursorStr = null;
						break; }
					} else {
						nextCursorStr = extractCursor(resultList.get(resultList.size() - 1));
						break;
					}
				} else {
					nextCursorStr = null;
					break;
				}
			}
		} catch (Exception ex) {}
		
		return SearchResponse.<T>builder()
				.setItems(resultList)
				.setNextPageToken(nextCursorStr)
				.setTotalCount(totalCount)
				.build();
	}
	
	private <T> List<T> bulkSearchWithMemcache(Class<T> type, int bulkCursor, String queryStr, List<SearchSortOption> searchSortOptions) throws IOException {
		String bulkCursorStr = Integer.toString(bulkCursor*MAX_SEARCH_LIMIT);
		String searchKey = SearchManager.createSearchKey(type, bulkCursorStr, queryStr, getSearchSortOptionKeyString(searchSortOptions));
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		@SuppressWarnings("unchecked")
		List<T> bulkResult = (List<T>)mcs.get(searchKey);
		
		if (bulkResult == null) {
			bulkResult = new ArrayList<T>();
			LOG.info("-------------------------------Read from index storage.");
			SearchResponse<T> searchResults = searchDocuments(type, bulkCursorStr, null, queryStr, searchSortOptions);
			if (searchResults != null && searchResults.getItems() != null) {
				bulkResult.addAll(searchResults.getItems());
			}
		} else {
			LOG.info("-------------------------------Read from memory cache.");
		}
		
//		LOG.warning("-------------------------------BulkCursor:"+bulkCursorStr);
		
		try {
			mcs.put(searchKey, bulkResult, Expiration.byDeltaSeconds(SEARCH_RESULT_KEEP_TIME));
		} catch (Exception ex) {
			LOG.warning("BulkSearchWithMemcache Error:" + ex.getMessage());
		}
		
		return bulkResult;
	}
	public <T> void deleteDocuments(String type, String docId) throws IOException {
		deleteDocuments(type, docId, false);
	}
	public <T> void deleteDocumentsAsync(String type, String docId) throws IOException {
		deleteDocuments(type, docId, true);
	}
	public <T> void deleteDocuments(Class<T> type, String docId) throws IOException {
		deleteDocuments(type, docId, false);
	}
	public <T> void deleteDocumentsAsync(Class<T> type, String docId) throws IOException {
		deleteDocuments(type, docId, true);
	}
	private <T> void deleteDocuments(Class<T> type, String docId, boolean isAsync) throws IOException {
		deleteDocuments(type.getSimpleName(), docId, isAsync);
	}
	private <T> void deleteDocuments(String type, String docId, boolean isAsync) throws IOException {
		try {
			IndexSpec indexSpec = IndexSpec.newBuilder().setName(type).build();
			Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
			//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);

			if (isAsync) {
				index.deleteAsync(docId);
			} else {
				index.delete(docId);
			}
		} catch (RuntimeException e) {
			LOG.log(Level.SEVERE, "Failed to delete documents", e);
		}
	}
	public <T> void deleteDocuments(String type, List<String> docIds) throws IOException {
		deleteDocuments(type, docIds, false);
	}
	public <T> void deleteDocumentsAsync(String type, List<String> docIds) throws IOException {
		deleteDocuments(type, docIds, true);
	}
	public <T> void deleteDocuments(Class<T> type, List<String> docIds) throws IOException {
		deleteDocuments(type, docIds, false);
	}
	public <T> void deleteDocumentsAsync(Class<T> type, List<String> docIds) throws IOException {
		deleteDocuments(type, docIds, true);
	}
	private <T> void deleteDocuments(Class<T> type, List<String> docIds, boolean isAsync) throws IOException {
		deleteDocuments(type.getSimpleName(), docIds, isAsync);
	}
	private <T> void deleteDocuments(String type, List<String> docIds, boolean isAsync) throws IOException {
		try {
			IndexSpec indexSpec = IndexSpec.newBuilder().setName(type).build();
			Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
			//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);
			
			if (isAsync) {
				index.deleteAsync(docIds);
			} else {
				index.delete(docIds);
			}
		} catch (RuntimeException e) {
			LOG.log(Level.SEVERE, "Failed to delete documents", e);
		}
	}
	public <T> void deleteAllDocuments(Class<T> type) throws IOException {
		deleteAllDocuments(type, false);
	}
	public <T> void deleteAllDocumentsAsync(Class<T> type) throws IOException {
		deleteAllDocuments(type, true);
	}
	@SuppressWarnings("deprecation")
	private <T> void deleteAllDocuments(Class<T> type, boolean isAsync) throws IOException {
		try {
			IndexSpec indexSpec = IndexSpec.newBuilder().setName(type.getSimpleName()).build();
			GetRequest request = GetRequest.newBuilder().setReturningIdsOnly(true).setLimit(MAX_DELETE_LIMIT).build();

			Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
			//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);
			while(true) {
				GetResponse<Document> responseList = index.getRange(request);
				if (responseList == null || responseList.getResults() == null || responseList.getResults().size() == 0) { break; }
				List<String> docIdList = new ArrayList<String>();
				
				for (Document doc : responseList.getResults()) {
					docIdList.add(doc.getId());
					//index.deleteAsync(doc.getId());
				}
				if (isAsync) {
					index.deleteAsync(docIdList);
				} else {
					index.delete(docIdList);
				}
			}
			
			if (isAsync) {
				index.deleteSchemaAsync();
			} else {
				index.deleteSchema();
			}
		} catch (RuntimeException e) {
			LOG.log(Level.SEVERE, "Failed to delete documents", e);
		}
	}

	public PutResponse createIndex(Object obj) throws PutException, Exception {
		PutResponse putResponse = null;
		try {
			Document.Builder docBuilder = Document.newBuilder();
	
			setDocBuilder(docBuilder, obj);
			
			Document doc = docBuilder.build();
			putResponse = createIndex(obj.getClass().getSimpleName(), doc);
		} catch (PutException ex) {
			LOG.warning(String.format("[createIndex - PutException] %s %s", obj.getClass().getSimpleName(), ex.getMessage()));
			throw ex;
		} catch (Exception ex) {
			LOG.warning(String.format("[createIndex - Exception] %s %s", obj.getClass().getSimpleName(), ex.getMessage()));
			throw ex;
		}
		return putResponse;
	}
	private PutResponse createIndex(String indexName, Document document) throws PutException, Exception{
		IndexSpec indexSpec = IndexSpec.newBuilder().setName(indexName).build();
		Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
		//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);
		PutResponse putRes = null;
		try {
			putRes = index.put(document);
		} catch (PutException e) {
			if (StatusCode.TRANSIENT_ERROR.equals(e.getOperationResult()
					.getCode())) {
				LOG.severe("[Transient indexing error]" + e.getMessage());
				putRes = index.put(document);
				// retry putting the document
			} else {
				LOG.severe("[Create index error]" + e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			throw ex;
		}
		return putRes;
	}
	
	public Future<PutResponse> createIndexAsync(Object obj) throws Exception {
		Future<PutResponse> putResponse = null;
		try {
			Document.Builder docBuilder = Document.newBuilder();
	
			setDocBuilder(docBuilder, obj);
			
			Document doc = docBuilder.build();
			putResponse = createIndexAsync(obj.getClass().getSimpleName(), doc);
		} catch (PutException ex) {
			throw ex;
		} catch (Exception ex) {
			throw ex;
		}
		return putResponse;
	}
	private Future<PutResponse> createIndexAsync(String indexName, Document document) throws Exception{
		IndexSpec indexSpec = IndexSpec.newBuilder().setName(indexName).build();
		Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
		//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);
		Future<PutResponse> putRes = null;
		try {
			putRes = index.putAsync(document);
//			while (!putRes.isDone()) {
//				if (putRes.isCancelled()) {
//					break; 
//				} 
//			} 
		} finally {}
		return putRes;
	}
	
	public List<String> getAllIndexNameList() {
		List<String> indexNameList = new ArrayList<String>();
		
		GetResponse<Index> response = SearchServiceFactory.getSearchService(
				config).getIndexes(GetIndexesRequest.newBuilder());
		
		for (Index index : response) {
			indexNameList.add(index.getName());
//			index.getName();
//			index.getNamespace();
//			index.search("query");
		}
		return indexNameList;
	}

	public Map<String, Schema> getAllIndexSchemaMaps() {
		Map<String, Schema> indexSchemaMaps = new HashMap<String, Schema>();
		
		GetResponse<Index> response = SearchServiceFactory.getSearchService(
				config).getIndexes(
				GetIndexesRequest.newBuilder().setSchemaFetched(true));
		
		for (Index index : response) {
			if (index.getSchema() != null) {
				indexSchemaMaps.put(index.getName(), index.getSchema());
			}
		}
		return indexSchemaMaps;
	}
	
	private SortExpression.Builder getSortExpressionBuilder(SearchSortOption sso) {
		SortExpression.Builder builder = SortExpression.newBuilder()
				.setExpression(sso.getSortItem())
				.setDirection(sso.getSortDirection());
		
		String defaultValue = sso.getDefaultValue();
		if (!sortValueTypes.containsKey(sso.getSortItem())) {
			if (StringUtils.isBlank(defaultValue)) { defaultValue = new String(""); }
			builder.setDefaultValue(defaultValue);
		} else {
			String type = sortValueTypes.get(sso.getSortItem());
			if (StringUtils.equals(Number.class.getSimpleName(), type)) {
				double d = new Double(0);
				try {
					if (StringUtils.isNumeric(defaultValue)) { d = Double.valueOf(defaultValue); }
				} catch (Exception ex) { d = new Double(0); }
				builder.setDefaultValueNumeric(d);
			} else if (StringUtils.equals(Date.class.getSimpleName(), type)) {
				Date d = new Date(0);
				try {
					d = CalendarUtil.parseDate(defaultValue);
					if (d == null && StringUtils.isNumeric(defaultValue)) { d = new Date(Long.valueOf(defaultValue)); }
				} catch (Exception ex) { d = new Date(0); }
				builder.setDefaultValueDate(d);
			}
		}
		
		return builder;
	}
//	private SortExpression.Builder getSortExpressionBuilder_20170111(SearchSortOption sso) {
//		if (String.class.equals(sso.getDefaultValue().getClass())) {
//			return SortExpression.newBuilder()
//					.setExpression(sso.getSortItem())
//					.setDirection(sso.getSortDirection())
//					.setDefaultValue((String)sso.getDefaultValue());
//		} else if (Date.class.equals(sso.getDefaultValue().getClass())) {
//			return SortExpression.newBuilder()
//					.setExpression(sso.getSortItem())
//					.setDirection(sso.getSortDirection())
//					.setDefaultValueDate((Date)sso.getDefaultValue());
//		} else if (Integer.class.equals(sso.getDefaultValue().getClass()) 
//				|| Long.class.equals(sso.getDefaultValue().getClass())
//				|| Double.class.equals(sso.getDefaultValue().getClass())
//				|| Number.class.equals(sso.getDefaultValue().getClass())
//				|| Float.class.equals(sso.getDefaultValue().getClass())) {
//			return SortExpression.newBuilder()
//					.setExpression(sso.getSortItem())
//					.setDirection(sso.getSortDirection())
//					.setDefaultValueNumeric((double)sso.getDefaultValue());
//		} else {
//			return null;
//		}
//	}
	private <M> void setDocBuilder(Document.Builder docBuilder, M source) {
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(source.getClass());
			// Iterate over all the attributes
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				// Only copy writable attributes
				if (descriptor.getWriteMethod() != null) {
					Object originalValue = descriptor.getReadMethod().invoke(source);
					// Only copy values values where the destination values is null
					if (originalValue != null) {
					//if (originalValue != null && IndexFields.get(source.getClass()).contains(descriptor.getName())) {
						if (descriptor.getName().equals(FLD.key) &&
								descriptor.getPropertyType().equals(com.google.appengine.api.datastore.Key.class)) {
							docBuilder.setId(KeyFactory.keyToString((Key)originalValue));
						} else if (descriptor.getPropertyType().equals(java.lang.String.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setText((String)originalValue));
						} else if (descriptor.getPropertyType().equals(java.util.Date.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setDate((Date)originalValue));
						} else if (descriptor.getPropertyType().equals(java.lang.Integer.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setNumber(((Integer)originalValue).doubleValue()));
						} else if (descriptor.getPropertyType().equals(java.lang.Number.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setNumber(((Number)originalValue).doubleValue()));
						} else if (descriptor.getPropertyType().equals(java.lang.Long.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setNumber(((Long)originalValue).doubleValue()));
						} else if (descriptor.getPropertyType().equals(java.lang.Float.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setNumber(((Float)originalValue).doubleValue()));
						} else if (descriptor.getPropertyType().equals(java.lang.Double.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setNumber((Double)originalValue));
						} else if (descriptor.getPropertyType().equals(com.google.appengine.api.datastore.Text.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setHTML(((Text)originalValue).getValue()));
						} else if (descriptor.getPropertyType().equals(com.google.appengine.api.search.GeoPoint.class)) {
							docBuilder.addField(Field.newBuilder().setName(descriptor.getName()).setGeoPoint((GeoPoint)originalValue));
						}
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private <T> T getEntityFromDocument(Class<T> type, Document document) {
		Object entityObj = ClassUtils.newInstance(type);
		injectObject(entityObj, FLD.key, KeyFactory.stringToKey(document.getId()));
		for (String field : document.getFieldNames()) {
			Object valObj = getDocumentValue(document, field);
			injectObject(entityObj, field, valObj);
		}
		return (T)entityObj;
	}
	@SuppressWarnings("unchecked")
	private <T> List<T> getEntityFromDocument(Class<T> type, Results<ScoredDocument> results, int offset) {
		List<T> resultList = new ArrayList<T>();
		
		for (ScoredDocument document : results) {
			Object entityObj = ClassUtils.newInstance(type);
			injectObject(entityObj, FLD.key, KeyFactory.stringToKey(document.getId()));
			for (String field : document.getFieldNames()) {
				Object valObj = getDocumentValue(document, field);
				injectObject(entityObj, field, valObj);
			}
			String cursorStr = ""+(1+offset+resultList.size());
			injectObject(entityObj, NEXT_PAGE_TOKEN, cursorStr);
			resultList.add((T)entityObj);
		}
		return resultList;
	}
	
	private <M> void injectObject(M target, String field, Object value) {
		//if (value==null) { return; }
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(target.getClass());
			// Iterate over all the attributes
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				// Only copy writable attributes
				if (descriptor.getName().equals(field)) {
					if (descriptor.getWriteMethod() != null) {
						if (descriptor.getPropertyType().equals(com.google.appengine.api.datastore.Text.class)) {
							if (value.getClass().equals(com.google.appengine.api.datastore.Text.class)) {
								descriptor.getWriteMethod().invoke(target, value);
							} else {
								descriptor.getWriteMethod().invoke(target, new Text(String.valueOf(value)));
							}
						} else if (descriptor.getPropertyType().equals(java.lang.String.class)) {
							if (value.getClass().equals(java.lang.String.class)) {
								descriptor.getWriteMethod().invoke(target, value);
							} else if (value.getClass().equals(com.google.appengine.api.datastore.Text.class)) {
								descriptor.getWriteMethod().invoke(target, ((Text)value).getValue());
							} else { 
								descriptor.getWriteMethod().invoke(target, String.valueOf(value));
							}
						} else if (descriptor.getPropertyType().equals(java.lang.Integer.class)) {
							descriptor.getWriteMethod().invoke(target, ((Number)value).intValue());
						} else if (descriptor.getPropertyType().equals(java.lang.Float.class)) {
							descriptor.getWriteMethod().invoke(target, ((Number)value).floatValue());
						} else if (descriptor.getPropertyType().equals(java.lang.Long.class)) {
							descriptor.getWriteMethod().invoke(target, ((Number)value).longValue());
						} else if (descriptor.getPropertyType().equals(java.lang.Double.class)) {
							descriptor.getWriteMethod().invoke(target, ((Number)value).doubleValue());
//						} else if (descriptor.getPropertyType().equals(java.lang.Number.class)) {
//							descriptor.getWriteMethod().invoke(target, (Number)value);
						} else {
							descriptor.getWriteMethod().invoke(target, value);
						}
					}
					break;
				}
			}
		} catch (Exception ex) {
			LOG.warning("[Inject object error]" + ex.getMessage());
//			ex.getStackTrace();
		}
	}
	
	@SuppressWarnings("unused")
	private <M> void injectCursor(M target, Object value) {
		//if (value==null) { return; }
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(target.getClass());
			// Iterate over all the attributes
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				// Only copy writable attributes
				if (descriptor.getWriteMethod() != null && descriptor.getName().equals(NEXT_PAGE_TOKEN)) {
					descriptor.getWriteMethod().invoke(target, value);
					break;
				}
			}
		} catch (Exception ex) {
			LOG.warning("[Inject cursor error]" + ex.getMessage());
			//ex.getStackTrace();
		}
	}
	private <M> String extractCursor(M target) {
		if (target == null) { return null; }
		String result = null;
		
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(target.getClass());
			// Iterate over all the attributes
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				// Only copy writable attributes
				if (descriptor.getReadMethod() != null && descriptor.getName().equals(NEXT_PAGE_TOKEN)) {
					result = (String)descriptor.getReadMethod().invoke(target);
					break;
				}
			}
		} catch (Exception ex) {
			LOG.warning("[Extract cursor error]" + ex.getMessage());
			//ex.getStackTrace();
		}
		
		return result;
	}
	
	private Object getDocumentValue(Document document, String field) {
		Object obj = null;

		if (document.getFieldNames().contains(field)) {
			switch(document.getOnlyField(field).getType()) {
				case ATOM : obj = document.getOnlyField(field).getAtom();
					break;
				case DATE : obj = document.getOnlyField(field).getDate();
					break;
				case HTML : obj = document.getOnlyField(field).getHTML();
					break;
				case NUMBER : obj = document.getOnlyField(field).getNumber();
					break;
				case GEO_POINT : obj = document.getOnlyField(field).getGeoPoint();
					break;
				case TEXT : obj = document.getOnlyField(field).getText();
				default :
					break;
			}
		} 
		return obj;
	}
	
	public static String createSearchKey(Class<?> clazz, Object... params) {
		String searchKey = null;
		try {
			ObjectMapper om = new ObjectMapper();
			
			searchKey = String.format("__SCH_%s_KEY__%s", clazz.getSimpleName(), SecurityUtils.getMD5(om.writeValueAsString(params)));
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
		return searchKey;
	}
	
	private <T> boolean isIndexed(Class<T> clazz) {
		Map<String, Schema> indexSchemaMaps = getAllIndexSchemaMaps();
		
		if (indexSchemaMaps == null || indexSchemaMaps.size() == 0){ return false; }
		else { return indexSchemaMaps.containsKey(clazz.getSimpleName()); }
	}
	
	private String getSearchSortOptionKeyString(List<SearchSortOption> searchSortOptions) {
		if (searchSortOptions == null) return null;
		StringBuilder sb = new StringBuilder();
		
		for (SearchSortOption sso : searchSortOptions) {
			sb.append(sso.getSortItem()).append(sso.getSortDirection()).append(sso.getDefaultValue());
		}
		
		return sb.toString();
	}
	
	public static SearchStorageUsage getSearchIndexUsage(String namespace) {
		SearchServiceConfig config = SearchServiceConfig.newBuilder().setNamespace(namespace).build();
		GetIndexesRequest IndexRequest = GetIndexesRequest.newBuilder().setSchemaFetched(true).build();
		GetResponse<Index> response = SearchServiceFactory.getSearchService(config).getIndexes(IndexRequest);
		//GetRequest request = GetRequest.newBuilder().setReturningIdsOnly(true).setLimit(MAX_SEARCH_LIMIT).build();
		
		SearchStorageUsage ssu = new SearchStorageUsage();
		ssu.setDomainName(namespace);
		
		if (response != null) {
			for (Index index : response) {
				int indexCount = getIndexCount(index);
				//int indexCount = (int)index.getRange(request).getResults().size();
				ssu.append(index.getName(), index.getStorageUsage(), index.getStorageLimit(), indexCount);
	//			Schema schema = index.getSchema();
	//		    for (String fieldName : schema.getFieldNames()) {
	//		        List<FieldType> typesForField = schema.getFieldTypes(fieldName);
	//		    }
			}
		}
		
		return ssu;
	}
	
	private static int getIndexCount(Index index) {
		int numberRetrieved = 0;
		int offset = 0;

		do {
			QueryOptions options = QueryOptions.newBuilder()
					.setReturningIdsOnly(true)
					.setOffset(offset)
					.setLimit(MAX_SEARCH_LIMIT)
					.build();
			
	        Query query = Query.newBuilder().setOptions(options).build("");
	        
	        // search at least once
	        Results<ScoredDocument> result = index.search(query);
	        numberRetrieved = result.getNumberReturned();
	        if (numberRetrieved > 0) {
	            offset += numberRetrieved;
	            // process the matched docs
	        }
		} while (numberRetrieved > 0);
		
		return offset;
	}
	
	public static List<SearchStorageUsage> listSearchIndexUsage() {
		List<String> namespaceList = CommonService.listNamespaces();
		List<SearchStorageUsage> ssuList = new ArrayList<SearchStorageUsage>();
		
		for (String namespace : namespaceList) {
			ssuList.add(getSearchIndexUsage(namespace));
		}
		
		return ssuList;
	}
	
	public <T> void deleteDocumentsSchema(Class<T> type) throws IOException {
		deleteDocumentsSchema(type, false);
	}
	public <T> void deleteDocumentsSchemaAsync(Class<T> type) throws IOException {
		deleteDocumentsSchema(type, true);
	}
	@SuppressWarnings("deprecation")
	private <T> void deleteDocumentsSchema(Class<T> type, boolean isAsync) throws IOException {
		try {
			IndexSpec indexSpec = IndexSpec.newBuilder().setName(type.getSimpleName()).build();
			Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
			
			if (isAsync) {
				index.deleteSchemaAsync();
			} else {
				index.deleteSchema();
			}
		} catch (RuntimeException e) {
			LOG.log(Level.SEVERE, "Failed to delete documents", e);
		}
	}
/*	
	@Deprecated
	private <T> SearchResponse<T> searchDocuments20161115(Class<T> type, String cursorStr, Integer limit, String queryStr, List<SearchSortOption> searchSortOptions) throws IOException {
		Results<ScoredDocument> results = null;
		Cursor cursor = null;
		SearchResponse<T> searchResults = null;
		List<T> list = null;
		long totalCount = 0;
		String nextPageToken = null;
		int searchLimit = MAX_SEARCH_LIMIT;
		
		if (limit != null && limit > 0) { searchLimit = limit; }
		try {
			if (!isIndexed(type)) { return null; }
			
			if (StringUtils.isNotEmpty(cursorStr)) {
				cursor = Cursor.newBuilder().setPerResult(isCursorPerResult).build(cursorStr);
			} else {
				cursor = Cursor.newBuilder().setPerResult(isCursorPerResult).build();
			}
			
			SortOptions sortOptions = null;
			if (searchSortOptions != null) {
				SortOptions.Builder sortBuilder = SortOptions.newBuilder();
				for (SearchSortOption sso : searchSortOptions) {
					SortExpression.Builder expBuilder = getSortExpressionBuilder(sso);
					if (expBuilder!=null) {
						sortBuilder.addSortExpression(expBuilder);
					}
				}
				sortOptions = sortBuilder
						.setLimit(MAX_SORT_LIMIT)
						.build();
			}

			// Build the QueryOptions
			QueryOptions.Builder queryBuilder = QueryOptions.newBuilder();

			queryBuilder = queryBuilder
				//.setFieldsToReturn(FLD.title, FLD.description, FLD.creator, FLD.created)
				//.setOffset(0) // offset and cursor cannot be set in the same request 
				.setLimit(searchLimit)
				.setNumberFoundAccuracy(NUMBER_FOUND_ACCURACY)
				.setCursor(cursor);
			
			if (TaskIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.tasklistId, FLD.taskId);
			} else if (AttachmentIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.kind, FLD.kindId, FLD.attachmentId);
//			} else if (ChecklistHistoryIndex.class.equals(type)) {
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.checklistId, FLD.taskChecklistHistoryId, FLD.activityType);
//			} else if (ChecklistIndex.class.equals(type)) {
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.taskChecklistId);
			} else if (CommentIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.commentId, FLD.commentType);
			} else if (EventIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.eventId, FLD.eventType);
			} else if (NoticeIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.kindId, FLD.boardId, FLD.noticeId);
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.noticeId);
			} else if (TimelineIndex.class.equals(type)) {
				queryBuilder = queryBuilder.setFieldsToReturn(FLD.boardId, FLD.taskId, FLD.taskTimelineId);
//			} else if (UserIndex.class.equals(type)) {
//				queryBuilder = queryBuilder.setFieldsToReturn(FLD.id, FLD.userId, FLD.email, FLD.userName, FLD.nickName, FLD.isActive, FLD.isValid);
			}
			
			if (sortOptions != null) { queryBuilder = queryBuilder.setSortOptions(sortOptions); }

			QueryOptions options = queryBuilder.build();

			Query query = Query.newBuilder().setOptions(options).build(queryStr);
			
			IndexSpec indexSpec = IndexSpec.newBuilder().setName(type.getSimpleName()).build();
			Index index = SearchServiceFactory.getSearchService(config).getIndex(indexSpec);
			//Index index = SearchServiceFactory.getSearchService().getIndex(indexSpec);
			
			nextPageToken = null;
			results = index.search(query);
			
			if (results != null) {
				LOG.info("[QueryIndex] "+index.toString());
				LOG.info("[QueryString] "+queryStr);
				LOG.info("[TotalResultCount] "+results.getNumberFound());
				LOG.info("[FetchCount] "+results.getNumberReturned());
				
				totalCount = results.getNumberFound();
				
				// Iterate over the documents in the results
				list = getEntityFromDocument20161115(type, results);
				
				if (results.getCursor() != null) {
					nextPageToken = results.getCursor().toWebSafeString();
				
					LOG.info("[CURSOR -> Copy to url and paste [ ?cursorStr="
							+ nextPageToken + " ]");
				} else if (list != null && list.size() > 0 && list.size() == searchLimit){
					nextPageToken = extractCursor(list.get(list.size() - 1));
				}
			}
		} catch (SearchException ex) {
			if (StatusCode.TRANSIENT_ERROR.equals(ex.getOperationResult().getCode())) {
				// retry
			}
		} catch (NegativeArraySizeException ex) {
			LOG.log(Level.WARNING, ex.getMessage());
		}

		searchResults = SearchResponse.<T>builder()
				.setItems(list)
				.setNextPageToken(nextPageToken)
				.setTotalCount(totalCount)
				.build();
		
		return searchResults;
	}
	@Deprecated
	@SuppressWarnings("unchecked")
	private <T> List<T> getEntityFromDocument20161115(Class<T> type, Results<ScoredDocument> results) {
		List<T> resultList = new ArrayList<T>();
		
		for (ScoredDocument document : results) {
			Object entityObj = ClassUtils.newInstance(type);
			injectObject(entityObj, FLD.key, KeyFactory.stringToKey(document.getId()));
			for (String field : document.getFieldNames()) {
				Object valObj = getDocumentValue(document, field);
				injectObject(entityObj, field, valObj);
			}
			Cursor cursor = document.getCursor();
			if (cursor != null && cursor.isPerResult()) {
				injectObject(entityObj, NEXT_PAGE_TOKEN, cursor.toWebSafeString());
			}
			
			resultList.add((T)entityObj);
		}
		return resultList;
	}
	@Deprecated
	@SuppressWarnings("unused")
	private <T> List<T> searchAllWithMemcache20161115(Class<T> type, String queryStr, List<SearchSortOption> searchSortOptions) throws IOException {
		//String cursorStr = null;
		//MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		//searchKey = SecurityUtils.getMD5(searchKey);
		String searchKey = SearchManager.createSearchKey(type, queryStr, getSearchSortOptionKeyString(searchSortOptions));
		
		List<T> allResults = getDataFromMemcache20161115(searchKey);
		//List<T> allResults = (List<T>)mcs.get(searchKey);
		
		String cursorStr = null;
		if (allResults == null) {
			allResults = new ArrayList<T>();
			LOG.info("-------------------------------Read from index storage.");
			while(true) {
				SearchResponse<T> searchResults = searchDocuments20161115(type, cursorStr, null, queryStr, searchSortOptions);
				
				if (searchResults != null && searchResults.getItems() != null) {
					allResults.addAll(searchResults.getItems());
					if (searchResults.getNextPageToken()==null) { break; }
					
					cursorStr = searchResults.getNextPageToken();
				} else { break; }
			}
		} else {
			LOG.info("-------------------------------Read from memory cache.");
		}
		
		// In case of request search consecutively, SEARCH_RESULT_KEEP_TIME preservation.
		
		setDataToMemcache20161115(allResults, searchKey);
		//try {
		//mcs.put(searchKey, allResults, Expiration.byDeltaSeconds(CommonProperty.SEARCH_RESULT_KEEP_TIME));
		//} catch (Exception ex) {
		//	LOG.warning(ex.getMessage());
		//}
		
		return allResults;
	}
	private static <T> List<T> getDataFromMemcache20161115(String searchKey) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		//searchKey = SecurityUtils.getMD5(searchKey);
		//String searchKey = SearchManager.createMemcacheKey(type, queryStr, keyStr);
		
		List<T> allResults = null;
		
		int memcacheIndex = 0;
		while(true) {
			String memcacheKey = getMemcacheKey20161115(searchKey, memcacheIndex);
			@SuppressWarnings("unchecked")
			List<T> results = (List<T>)mcs.get(memcacheKey);
			if (results != null && results.size() != 0) {
				if (allResults == null) { allResults = new ArrayList<T>(); }
				allResults.addAll(results);
				memcacheIndex++;
			} else { break; }
		}
		return allResults;
	}
	private static <T> void setDataToMemcache20161115(List<T> allResults, String searchKey) {
		try {
			MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
			//searchKey = SecurityUtils.getMD5(searchKey);
			//String searchKey = SearchManager.createMemcacheKey(type, queryStr, keyStr);
			final int putSize = 100;
			for (int memcacheIndex=0; memcacheIndex*putSize < allResults.size(); memcacheIndex++) {
				int startIndex = memcacheIndex*putSize;
				int endIndex = (memcacheIndex+1)*putSize;
				if (endIndex > allResults.size()) {
					endIndex = allResults.size();
				}
				List<T> results = new ArrayList<T>(allResults.subList(startIndex, endIndex));
				String memcacheKey = getMemcacheKey20161115(searchKey, memcacheIndex);
				mcs.put(memcacheKey, results, Expiration.byDeltaSeconds(CommonProperty.SEARCH_RESULT_KEEP_TIME));
			}
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}
	@SuppressWarnings("unused")
	private static String getCursorFromMemcache20161115(String searchKey) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		return (String)mcs.get(searchKey+"_cursor");
	}
	@SuppressWarnings("unused")
	private static void setCursorToMemcache20161115(String cursorStr, String searchKey) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		mcs.put(searchKey+"_cursor", cursorStr, Expiration.byDeltaSeconds(CommonProperty.SEARCH_RESULT_KEEP_TIME+1));
	}
	
	private static String getMemcacheKey20161115(String searchKey, int memcacheIndex) {
		return String.format("%s_%d",searchKey, memcacheIndex);
	}*/
}
