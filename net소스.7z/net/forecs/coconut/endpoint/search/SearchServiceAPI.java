package net.forecs.coconut.endpoint.search;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.query.SearchArea;
import net.forecs.coconut.common.query.SearchOption;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.attachment.Attachments;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;


@Api(name = API.BOARD_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.BOARD_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class SearchServiceAPI {
	private final ISearchService searchService;
	
	@Inject
	public SearchServiceAPI(ISearchService searchService) {
		this.searchService = searchService;
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "search", path = "search", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Map<String, Map<String, Object>> search(
			@Nullable @Named(FLD.cursor) String cursorString
			, @Nullable @Named(FLD.limit) Integer limit
			, @Nullable @Named(FLD.searchAreas) Set<SearchArea> searchAreas
			, @Nullable @Named(FLD.boardId) String boardId
			, @Named(FLD.searchStr) String searchStr
			, @Nullable SearchOption searchOption
			, @Nullable @Named(FLD.startDate) Date startDate
			, @Nullable @Named(FLD.endDate) Date endDate) throws Exception {
		if (StringUtils.isNotBlank(boardId)) {
			CommonService.validNamespace(boardId);
		}
		Map<String, Map<String, Object>> results = searchService.search(cursorString, limit, searchAreas, boardId, searchStr, searchOption, startDate, endDate);
		return results;
	}
	
	@ApiMethod(name = "listAttachments", path = "search/attachments", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<Attachments> listAttachments(
			@Nullable @Named(FLD.boardId) String boardId
			, @Nullable @Named(FLD.taskId) String taskId
			, @Nullable @Named(FLD.userId) String userId
			) throws Exception {
		if (StringUtils.isNotBlank(boardId)) {
			CommonService.validNamespace(boardId);
		}
		return  searchService.listAttachments(boardId, taskId, userId);
	}
	
	@ApiMethod(name = "queryAttachment", path = "search/attachments", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Map<String, Object> queryAttachments(
			@Nullable @Named(FLD.cursor) String cursorString
			, @Nullable @Named(FLD.limit) Integer limit
			, @Nullable @Named(FLD.boardId) String boardId
			, @Nullable @Named(FLD.taskId) String taskId
			, @Nullable @Named(FLD.userId) String userId
			, @Nullable @Named(FLD.searchStr) String searchStr
			, @Nullable SearchOption searchOption
			, @Nullable @Named(FLD.startDate) Date startDate
			, @Nullable @Named(FLD.endDate) Date endDate) throws Exception {
		if (StringUtils.isNotBlank(boardId)) {
			CommonService.validNamespace(boardId);
		}
		Map<String, Object> results = searchService.queryAttachments(cursorString, limit, boardId, taskId, userId, searchStr, searchOption, startDate, endDate);
		return results;
	}
	
	// ------------- Current service ----------------
	@Deprecated
	@ApiMethod(name = "searchDashboard", path = "search/dashboard", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Map<String, Map<String, Object>> searchDashboard(
			@Nullable @Named(FLD.cursor) String cursorString 
			, @Nullable @Named(FLD.limit) Integer limit
			, @Nullable @Named(FLD.searchAreas) Set<SearchArea> searchAreas
			, @Named(FLD.searchStr) String searchStr
			, @Nullable SearchOption searchOption
			, @Nullable @Named(FLD.startDate) Date startDate
			, @Nullable @Named(FLD.endDate) Date endDate) throws Exception {
		Map<String, Map<String, Object>> results = searchService.search(cursorString, limit, searchAreas, null, searchStr, searchOption, startDate, endDate);
		return results;
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "searchTasks", path = "search/tasks", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchTasks(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Nullable @Named(FLD.boardId) String boardId
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		Map<String, Object> results = searchService.searchTasks(cursorString, limit, boardId, searchStr, searchOption);
//		return results;
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "searchComments", path = "search/comments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchComments(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Nullable @Named(FLD.boardId) String boardId
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		Map<String, Object> results = searchService.searchComments(cursorString, limit, boardId, searchStr, searchOption);
//		return results;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "searchEvents", path = "search/events", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchEvents(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Nullable @Named(FLD.boardId) String boardId
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		Map<String, Object> results = searchService.searchEvents(cursorString, limit, boardId, searchStr, searchOption);
//		return results;
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "searchTimelines", path = "search/timelines", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchTimelines(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Nullable @Named(FLD.boardId) String boardId
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		Map<String, Object> results = searchService.searchTimelines(cursorString, limit, boardId, searchStr, searchOption);
//		return results;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "searchNotice", path = "search/notice", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchNotice(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Nullable @Named(FLD.boardId) String boardId
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		Map<String, Object> results = searchService.searchNotice(cursorString, limit, boardId, searchStr, searchOption);
//		return results;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "searchAttachments", path = "search/attachments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchAttachments(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Nullable @Named(FLD.boardId) String boardId
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		Map<String, Object> results = searchService.searchAttachments(cursorString, limit, boardId, searchStr, searchOption);
//		return results;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "searchDashboardTasks", path = "search/dashboard/tasks", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchDashboardTasks(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		Map<String, Object> results = searchService.searchDashboardTasks(cursorString, limit, searchStr, searchOption);
//		return results;
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "searchDashboardComments", path = "search/dashboard/comments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchDashboardComments(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		Map<String, Object> results = searchService.searchDashboardComments(cursorString, limit, searchStr, searchOption);
//		return results;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "searchDashboardEvents", path = "search/dashboard/events", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchDashboardEvents(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		Map<String, Object> results = searchService.searchDashboardEvents(cursorString, limit, searchStr, searchOption);
//		return results;
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "searchDashboardTimelines", path = "search/dashboard/timelines", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchDashboardTimelines(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		Map<String, Object> results = searchService.searchDashboardTimelines(cursorString, limit, searchStr, searchOption);
//		return results;
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "searchDashboardNotice", path = "search/dashboard/notice", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchDashboardNotice(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		Map<String, Object> results = searchService.searchDashboardNotice(cursorString, limit, searchStr, searchOption);
//		return results;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "searchDashboardAttachments", path = "search/dashboard/attachments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Map<String, Object> searchDashboardAttachments(
//			@Nullable @Named(FLD.cursor) String cursorString
//			, @Nullable @Named(FLD.limit) Integer limit
//			, @Named(FLD.searchStr) String searchStr
//			, @Nullable SearchOption searchOption) throws Exception {
//		Map<String, Object> results = searchService.searchDashboardAttachments(cursorString, limit, searchStr, searchOption);
//		return results;
//	}
}
