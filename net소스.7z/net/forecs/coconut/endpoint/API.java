package net.forecs.coconut.endpoint;

import net.forecs.coconut.endpoint.account.AccountServiceAPI;


public final class API {
	// ========================== COMMON DEFINE ===============================
	public final static String API_ROOT = "/_ah/api/";
	public final static String SPI_ROOT = "/_ah/spi/";
	public final static String VERSION = "v1";
	public final static String OWNER_DOMAIN = "forecs.net";
	public final static String OWNER_NAME = "forecs.net";
	public final static String PACKAGE_ROOT = "net.forecs.";
	public final static String ENDPOINT_ROOT = PACKAGE_ROOT + "coconut.endpoint.";
	
	// ========================== APPENGINE PRE DEFINE ===============================
	public final static String APPSTATS_ROOT = "/_ah/appstats/";
	public final static String MAIL_ROOT = "/_ah/mail/";
	public final static String CHANNEL_DEV_ROOT = "/_ah/channel/dev";
	
	// ========================== ACCOUNT SERVICE DEFINE ===============================
	public final static String ACCOUNT_SERVICE = "accountService";
	public final static String ACCOUNT_SERVICE_PACKAGE = "coconut.endpoint.account";
	public final static String ACCOUNT_SERVICE_URI = SPI_ROOT + AccountServiceAPI.class.getName();

	// ========================== ADMIN SERVICE DEFINE ===============================
	public final static String ADMIN_SERVICE = "adminService";
	public final static String ADMIN_SERVICE_PACKAGE = "coconut.endpoint.admin";

	// ========================== BILLING SERVICE DEFINE ===============================
	public final static String BILLING_SERVICE = "billingService";
	public final static String BILLING_SERVICE_PACKAGE = "coconut.endpoint.billing";

	// ========================== BOARD SERVICE DEFINE ===============================
	public final static String BOARD_SERVICE = "boardService";
	public final static String BOARD_SERVICE_PACKAGE = "coconut.endpoint.board";

	// ========================== CHANNEL SERVICE DEFINE ===============================
	public final static String CHANNEL_SERVICE = "channelService";
	public final static String CHANNEL_SERVICE_PACKAGE = "coconut.endpoint.channel";
	
	// ========================== COMMON SERVICE DEFINE ===============================
	public final static String COMMON_SERVICE = "commonService";
	public final static String COMMON_SERVICE_PACKAGE = "coconut.endpoint.common";
	
	// ========================== DASHBOARD SERVICE DEFINE ===============================
	public final static String DASHBOARD_SERVICE = "dashboardService";
	public final static String DASHBOARD_SERVICE_PACKAGE = "coconut.endpoint.dashboard";
	
	// ========================== DOMAIN SERVICE DEFINE ===============================
	public final static String DOMAIN_SERVICE = "domainService";
	public final static String DOMAIN_SERVICE_PACKAGE = "coconut.endpoint.domain";

	// ========================== SETTING SERVICE DEFINE ===============================
	public final static String SETTING_SERVICE = "settingService";
	public final static String SETTING_SERVICE_PACKAGE = "coconut.endpoint.setting";
	
	// ========================== WORKSPACE SERVICE DEFINE ===============================
	public final static String WORKSPACE_SERVICE = "workspaceService";
	public final static String WORKSPACE_SERVICE_PACKAGE = "coconut.endpoint.workspace";
	
	// ========================== FOREIGN SERVICE DEFINE ===============================
		public final static String FOREIGN_SERVICE = "foreignService";
		public final static String FOREIGN_SERVICE_PACKAGE = "coconut.endpoint.foreign";
}
