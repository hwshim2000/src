package net.forecs.coconut.endpoint.survey;

import java.util.Date;

import com.google.appengine.api.datastore.Text;

import net.forecs.coconut.common.code.QuestionItemType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.survey.SurveyAnswers;
import net.forecs.coconut.entity.survey.SurveyItems;
import net.forecs.coconut.entity.survey.SurveyQuestions;

public interface ISurveyService extends ICommonService {
	public abstract QueryResult<SurveyQuestions> querySurveyQuestions(
			String cursorString,
			Integer limit,
			String surveyKind,
			String kindId,
			String displayYN,
			Date startDate,
			Date endDate,
			Boolean includeItems,
			Boolean includeAnswers,
			Boolean enableTree) throws Exception;
	public abstract SurveyQuestions getSurveyQuestion(String surveyQuestionId, Boolean includeItems, Boolean includeAnswers, Boolean enableTree) throws Exception;
	public abstract SurveyQuestions getSurveyResults(String surveyQuestionId) throws Exception;
	public abstract SurveyQuestions insertSurveyQuestion(SurveyQuestions question) throws Exception;
	public abstract SurveyQuestions updateSurveyQuestion(SurveyQuestions question) throws Exception;
	public abstract void removeSurveyQuestion(String surveyQuestionId) throws Exception;
	public abstract SurveyQuestions updateSurveyQuestionTitle(String surveyQuestionId, String title) throws Exception;
	public abstract SurveyQuestions updateSurveyQuestionDescription(String surveyQuestionId, Text Description) throws Exception;
	public abstract SurveyQuestions updateSurveyQuestionDisplayYN(String surveyQuestionId, String displayYN) throws Exception;
	public abstract SurveyQuestions updateSurveyQuestionPeriod(String surveyQuestionId, Date startDate, Date endDate) throws Exception;
	
	public abstract SurveyItems insertSurveyItem(SurveyItems item) throws Exception;
	public abstract SurveyItems updateSurveyItem(SurveyItems item) throws Exception;
	public abstract SurveyItems updateSurveyItemTitle(String surveyItemId, String title) throws Exception;
	public abstract SurveyItems updateSurveyItemDescription(String surveyItemId, Text description) throws Exception;
	public abstract SurveyItems updateSurveyItemType(String surveyItemId, QuestionItemType type) throws Exception;
	public abstract void removeSurveyItem(String surveyItemId) throws Exception;
	
	public abstract boolean isAnswerSurvey(String surveyQuestionId, String email) throws Exception;
	public abstract SurveyAnswers getSurveyAnswers(String surveyAnswerId) throws Exception;
	public abstract SurveyAnswers answerSurvey(String surveyItemId, Text description, Boolean checked, String email) throws Exception;
	public abstract void removeSurveyAnswer(String surveyAnswerId) throws Exception;
	public abstract void removeSurveyAnswers(String surveyQuestionId, String parentId, String surveyItemId, QuestionItemType type, String email) throws Exception;
	public abstract void removeMySurveyAnswers(String surveyQuestionId, String parentId, String surveyItemId, String email) throws Exception;
}
