package net.forecs.coconut.endpoint.survey;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.QuestionItemType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.survey.SurveyAnswers;
import net.forecs.coconut.entity.survey.SurveyItems;
import net.forecs.coconut.entity.survey.SurveyQuestions;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;

public class SurveyService extends CommonService implements ISurveyService {
	//private static final Logger LOG = Logger.getLogger(SurveyService.class.getName());
	
	@Inject
	public SurveyService() {
	}
	
	@Override
	public QueryResult<SurveyQuestions> querySurveyQuestions(
			String cursorString,
			Integer limit,
			String surveyKind,
			String kindId,
			String displayYN,
			Date startDate,
			Date endDate,
			Boolean includeItems,
			Boolean includeAnswers,
			Boolean enableTree) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<SurveyQuestions> dsQuery = new DsQuery<>(SurveyQuestions.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.surveyKind, surveyKind)
					.eq(FLD.kindId, kindId)
					.eq(FLD.displayYN, displayYN)
					.ge(FLD.startDate, startDate)
					.le(FLD.endDate, endDate)
					.sort(FLD.created, SortDirection.DESC)
					.cursor(cursorString)
					.limit(limit);

			int bulkFetchAmount = 1;	// 검색 속도를 높이기 위해 한꺼번에 많은 양을 가져와서 해당되는 값들을 필터링하기 위해, 즉 , limit보다  bulkFetchAmount배 많이 가져온뒤에 필터링
 
			List<String> surveyQuestionIds = new ArrayList<String>();
			do {
				dsQuery.nextFetch(mgr, bulkFetchAmount++);
				while(dsQuery.hasEntity()) {
					SurveyQuestions question = dsQuery.nextEntity();
					dsQuery.addResult(question);
					surveyQuestionIds.add(question.getSurveyQuestionId());
				}
			} while (dsQuery.hasNextFetch());
			
			List<SurveyQuestions> questions = dsQuery.getResults();
			
			for (SurveyQuestions question : questions) {
				question = getSurveyQuestionDetails(mgr, question, includeItems, includeAnswers, enableTree);
			}
			return new QueryResult<SurveyQuestions>(questions, dsQuery.getCursor());	
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyQuestions getSurveyQuestion(String surveyQuestionId, Boolean includeItems, Boolean includeAnswers, Boolean enableTree) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getSurveyQuestion(mgr, surveyQuestionId, includeItems, includeAnswers, enableTree);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private SurveyQuestions getSurveyQuestion(EntityManager mgr, String surveyQuestionId, Boolean includeItems, Boolean includeAnswers, Boolean enableTree) throws Exception {
		SurveyQuestions question = doFind(mgr, SurveyQuestions.class, surveyQuestionId);
		return getSurveyQuestionDetails(mgr, question, includeItems, includeAnswers, enableTree);
	}
	
	private SurveyQuestions getSurveyQuestionDetails(EntityManager mgr, SurveyQuestions question, Boolean includeItems, Boolean includeAnswers, Boolean enableTree) throws Exception {
		if (question == null) { return null; }
		if (Boolean.TRUE.equals(includeItems)) {
			List<SurveyItems> items = listSurveyItems(mgr, question.getSurveyQuestionId());
			
			Map<String, List<SurveyAnswers>> answerMap = getSurveyAnswerMap(mgr, question.getSurveyQuestionId());
			for (SurveyItems item : items) {
				List<SurveyAnswers> answers = answerMap.get(item.getSurveyItemId());
				if (answers != null) {
					item.setCount(answers.size());
					if (Boolean.TRUE.equals(includeAnswers)) { item.setAnswers(answers); }
				}
			}
			if (Boolean.TRUE.equals(enableTree)) { items = translateSurveyItemsChildTree(items); }
			question.setSurveyItems(items);
		}
		return question;
	}
	
	@Override
	public SurveyQuestions getSurveyResults(String surveyQuestionId) throws Exception {
		return getSurveyQuestion(surveyQuestionId, true, true, true);
	}
	
	@Override
	public SurveyQuestions insertSurveyQuestion(SurveyQuestions question) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			if (StringUtils.isNotBlank(question.getKindId())) {
				question.setSurveyKind(KeyFactory.stringToKey(question.getKindId()).getKind());
			} else {
				question.setSurveyKind(NamespaceManager.get());
			}

			question.setCreator(getCurrentUserId());
			question.setKey(KeyUtil.createSurveyQuestionKey());

			if (question.getStartDate() == null || question.getEndDate() == null) {
				throw new UnavailableException("Start and end date is required.");
			}
			if (contains(mgr, SurveyQuestions.class, question.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(SurveyQuestions.class, question.getSurveyQuestionId()));
			}

			doPersistTransaction(mgr, question);
			
			return question;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public SurveyQuestions updateSurveyQuestion(SurveyQuestions question) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			if (StringUtils.isNotBlank(question.getKindId())) {
				question.setSurveyKind(KeyFactory.stringToKey(question.getKindId()).getKind());
			} else {
				question.setSurveyKind(NamespaceManager.get());
			}

			if (question.getStartDate() == null || question.getEndDate() == null) {
				throw new UnavailableException("Start and end date is required.");
			}
			if (!contains(mgr, SurveyQuestions.class, question.getKey())) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage(SurveyQuestions.class, question.getSurveyQuestionId()));
			}

			return doMergeTransaction(mgr, question);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeSurveyQuestion(String surveyQuestionId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			SurveyQuestions question = doFind(mgr, SurveyQuestions.class, surveyQuestionId);
			if (question != null) {
				doRemoveTransaction(mgr, question);
				removeSurveyItems(mgr, surveyQuestionId);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyQuestions updateSurveyQuestionTitle(String surveyQuestionId, String title) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyQuestions question = doFind(mgr, SurveyQuestions.class, surveyQuestionId);
			question.setTitle(title);
			
			return doMergeTransaction(mgr, question);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public SurveyQuestions updateSurveyQuestionDescription(String surveyQuestionId, Text description) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyQuestions question = doFind(mgr, SurveyQuestions.class, surveyQuestionId);
			question.setDescription(description);
			
			return doMergeTransaction(mgr, question);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyQuestions updateSurveyQuestionDisplayYN(String surveyQuestionId, String displayYN) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyQuestions question = doFind(mgr, SurveyQuestions.class, surveyQuestionId);
			question.setDisplayYN(displayYN);
			
			return doMergeTransaction(mgr, question);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyQuestions updateSurveyQuestionPeriod(String surveyQuestionId, Date startDate, Date endDate) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyQuestions question = doFind(mgr, SurveyQuestions.class, surveyQuestionId);
			question.setStartDate(startDate);
			question.setEndDate(endDate);
			
			return doMergeTransaction(mgr, question);
		} finally {
			finalizeTransaction(mgr);
		}
	}

	// -------------------------------------------------------------------------------------------------------------------------
	private List<SurveyItems> listSurveyItems(EntityManager mgr, String surveyQuestionId) throws Exception {
		List<String> surveyQuestionIds = new ArrayList<String>();
		surveyQuestionIds.add(surveyQuestionId);
		return listSurveyItems(mgr, surveyQuestionIds);
	}
	private List<SurveyItems> listSurveyItems(EntityManager mgr, List<String> surveyQuestionIds) throws Exception {
		Set<String> questionIdSet = null;

		if (surveyQuestionIds != null && surveyQuestionIds.size() > CommonProperty.SUBQUERY_PARAM_COUNT) {
			questionIdSet = new HashSet<String>();
			questionIdSet.addAll(surveyQuestionIds);
			surveyQuestionIds = null;
		}
		
		DsQuery<SurveyItems> dsQuery = new DsQuery<>(SurveyItems.class)
				.eq(FLD.deleteYN, N)
				.in(FLD.surveyQuestionId, surveyQuestionIds)
				.sort(FLD.ordernum, SortDirection.ASC);

		List<SurveyItems> results  = dsQuery.execute(mgr);		
		List<SurveyItems> items = new ArrayList<SurveyItems>();
	
		for (SurveyItems a : results) {
			if (questionIdSet != null && !questionIdSet.contains(a.getSurveyQuestionId())) { continue; }
			items.add(a);
		}

		return items;
	}
	private List<SurveyItems> translateSurveyItemsChildTree(List<SurveyItems> items) throws Exception {
		//List<SurveyItems> items = listSurveyItems(mgr, surveyQuestionIds);

		Map<String, SurveyItems> itemMap = new LinkedHashMap<String, SurveyItems>();
		for (SurveyItems item : items) {
			itemMap.put(item.getSurveyItemId(), item);
		}
		for (SurveyItems item : items) {
			if (StringUtils.isNotBlank(item.getParentId())) {
				itemMap.get(item.getParentId()).appendChild(item);
			}
		}
		for (SurveyItems item : items) {
			if (StringUtils.isNotBlank(item.getParentId())) {
				itemMap.remove(item.getSurveyItemId());
			}
		}
		return new ArrayList<SurveyItems>(itemMap.values());
	}
	
	@Override
	public SurveyItems insertSurveyItem(SurveyItems item) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			item.setCreator(getCurrentUserId());
			item.setKey(KeyUtil.createSurveyItemKey());

			if (contains(mgr, SurveyItems.class, item.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(SurveyItems.class, item.getSurveyItemId()));
			}

			doPersistTransaction(mgr, item);
			return item;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyItems updateSurveyItem(SurveyItems item) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			if (!contains(mgr, SurveyItems.class, item.getKey())) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage(SurveyQuestions.class, item.getSurveyItemId()));
			}
			return doMergeTransaction(mgr, item);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyItems updateSurveyItemTitle(String surveyItemId, String title) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyItems item = doFind(mgr, SurveyItems.class, surveyItemId);
			if (item == null) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage(SurveyQuestions.class, surveyItemId));
			}
			
			item.setTitle(title);
			return doMergeTransaction(mgr, item);
			
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyItems updateSurveyItemDescription(String surveyItemId, Text description) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyItems item = doFind(mgr, SurveyItems.class, surveyItemId);
			if (item == null) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage(SurveyQuestions.class, surveyItemId));
			}
			
			item.setDescription(description);
			return doMergeTransaction(mgr, item);
			
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public SurveyItems updateSurveyItemType(String surveyItemId, QuestionItemType type) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyItems item = doFind(mgr, SurveyItems.class, surveyItemId);
			if (item == null) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage(SurveyQuestions.class, surveyItemId));
			}
			
			item.setType(type);
			return doMergeTransaction(mgr, item);
			
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeSurveyItem(String surveyItemId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyItems item = doFind(mgr, SurveyItems.class, surveyItemId);
			if (item == null) { return; }
			
			SurveyQuestions question = getSurveyQuestion(mgr, item.getSurveyQuestionId(), true, true, true);
			if (question == null) { return; }
			
			List<SurveyItems> treeItems = question.getSurveyItems();
			SurveyItems itemWithAllChilds = findAllChildItems(treeItems, surveyItemId);
			
			removeAllChildItemsAndAnswers(mgr, itemWithAllChilds);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private SurveyItems findAllChildItems(List<SurveyItems> items, String surveyItemId) {
		if (items == null || items.size() == 0) { return null; }
		for (SurveyItems item : items) {
			if (StringUtils.equals(surveyItemId, item.getSurveyItemId())) {
				return item;
			} 
			SurveyItems childItem = findAllChildItems(item.getChilds(), surveyItemId);
			if (childItem != null) { return childItem; }
		}
		return null;
	}
	
	private void removeAllChildItemsAndAnswers(EntityManager mgr, SurveyItems item) throws Exception {
		if (item == null) { return; }
		if (item.getChilds() != null && item.getChilds().size() > 0) {
			for (SurveyItems childItem : item.getChilds()) {
				removeAllChildItemsAndAnswers(mgr, childItem);
			}
		}
		doRemoveTransaction(mgr, item);
		if (item.getAnswers() != null && item.getAnswers().size() > 0) {
			for (SurveyAnswers answer : item.getAnswers()) {
				doRemoveTransaction(mgr, answer);
			}
		}
	}
	
	@SuppressWarnings("unused")
	@Deprecated
	private void removeSurveyItem_old(String surveyItemId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			SurveyItems item = doFind(mgr, SurveyItems.class, surveyItemId);
			if (item != null) {
				doRemoveTransaction(mgr, item);
				removeSurveyAnswers(mgr, null, null, surveyItemId, null, null);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void removeSurveyItems(EntityManager mgr, String surveyQuestionId) throws Exception {
		List<SurveyItems> items = listSurveyItems(mgr, surveyQuestionId);
		for (SurveyItems item : items) {
			doRemoveTransaction(mgr, item);
			removeSurveyAnswers(mgr, surveyQuestionId, null, null, null, null);
		}
	}
	
	// -------------------------------------------------------------------------------------------------------------------------
	@Override
	public boolean isAnswerSurvey(String surveyQuestionId, String email) throws Exception {
		Users loginUser = getCurrentUser();
		if (loginUser != null) { email = loginUser.getEmail(); }
		if (StringUtils.isBlank(email)) { return false; }
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<SurveyAnswers> dsQuery = new DsQuery<>(SurveyAnswers.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.email, email)
					.eq(FLD.surveyQuestionId, surveyQuestionId);
			
			return dsQuery.count() > 0;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public SurveyAnswers getSurveyAnswers(String surveyAnswerId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, SurveyAnswers.class, surveyAnswerId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<SurveyAnswers> listSurveyAnswers(EntityManager mgr, String surveyQuestionId, String parentId, String surveyItemId, QuestionItemType type, String email) throws Exception {
		try {
			DsQuery<SurveyAnswers> dsQuery = new DsQuery<>(SurveyAnswers.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.surveyQuestionId, surveyQuestionId)
					.eq(FLD.parentId, parentId)
					.eq(FLD.surveyItemId, surveyItemId)
					.eq(FLD.type, type)
					.eq(FLD.email, email)
					.sort(FLD.created, SortDirection.DESC);
	
			return  dsQuery.execute(mgr);		
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private Map<String, List<SurveyAnswers>> getSurveyAnswerMap(EntityManager mgr, String surveyQuestionId) throws Exception {
		Map<String, List<SurveyAnswers>> answerMap = new LinkedHashMap<String, List<SurveyAnswers>>();
		List<SurveyAnswers> answers = listSurveyAnswers(mgr, surveyQuestionId, null, null, null, null);
		for (SurveyAnswers answer : answers) {
			if (answerMap.get(answer.getSurveyItemId()) == null) {
				answerMap.put(answer.getSurveyItemId(), new ArrayList<SurveyAnswers>());
			}
			answerMap.get(answer.getSurveyItemId()).add(answer);
		}
		
		return answerMap;
	}
	
	@Override
	public SurveyAnswers answerSurvey(String surveyItemId, Text description, Boolean checked, String email) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			String loginUserId = null;
			if (loginUser != null) {
				email = loginUser.getEmail();
				loginUserId = loginUser.getUserId();
			}
			
			String surveyAnswerId = KeyUtil.createSurveyAnswerKeyString(surveyItemId, email);
			
			SurveyItems item = doFind(mgr, SurveyItems.class, surveyItemId);
			SurveyQuestions question = doFind(mgr, SurveyQuestions.class, item.getSurveyQuestionId());
			validSurveyDate(question);
			SurveyAnswers answer = null;
			if (StringUtils.isNotBlank(surveyAnswerId)) { answer = doFind(mgr, SurveyAnswers.class, surveyAnswerId); }
			if (answer == null) {
				// 이전에 응답이 없었으므로 새로 만든다.
				answer = new SurveyAnswers(surveyAnswerId, description, item, email, loginUserId);
				
				// 만일, Radio 타입일 경우, 해당 답변은 하나만 선택되어지어야 하므로, 같은그룹(부모아이디가 같은)에 이미 답변한 값들을 모두 지운다.
				if (QuestionItemType.RADIO.equals(item.getType()) && StringUtils.isNotBlank(email)) {
					removeSurveyAnswers(mgr, item.getSurveyQuestionId(), item.getParentId(), null, QuestionItemType.RADIO, email);
				}
				
				// 항목을 선택하였거나, 주관식 답변이 있을 경우에 응답 정보를 저장한다.
				if (Boolean.TRUE.equals(checked) || (description != null && StringUtils.isNotBlank(description.getValue()))) {
					doPersistTransaction(mgr, answer);
				}
			} else {
				if (isCheckedItemType(answer.getType())) {
					// 이미 응답이 있고, 응답 타입이 객관식(RADIO, CHECKBOX)일 경우에
					// check가 true 인경우에는 이전과 동일한 값이므로 merge가 필요하지 않다.
					// 하지만 check가 false인 경우에는 해당 응답을 삭제한다.
					if (!checked) {
						doRemoveTransaction(mgr, answer);
					}
				} else if (isTextItemType(answer.getType())) {
					// 답변이 주관식일경우, 해당 답변이 널값이 아닐 경우에는 기존의 답변 내용이 바뀐것이므로 update(merge)를 수행한다.
					// 답변내용이 없으면 해당 응답을 삭제한다.
					if (description != null && StringUtils.isNotBlank(description.getValue())) {
						answer.setDescription(description);
						answer = doMergeTransaction(mgr, answer);
					} else {
						doRemoveTransaction(mgr, answer);
					}
				}
			}
			
			return answer;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private static boolean isCheckedItemType(QuestionItemType type){
		return QuestionItemType.CHECKBOX.equals(type) || QuestionItemType.RADIO.equals(type);
	}
	private static boolean isTextItemType(QuestionItemType type){
		return QuestionItemType.LONG.equals(type) || QuestionItemType.SHORT.equals(type);
	}

	@Override
	public void removeSurveyAnswer(String surveyAnswerId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			SurveyAnswers answer = doFind(mgr, SurveyAnswers.class, surveyAnswerId);
			if (answer != null) {
				doRemoveTransaction(mgr, answer);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeMySurveyAnswers(String surveyQuestionId, String parentId, String surveyItemId, String email) throws Exception {
		Users loginUser = getCurrentUser();
		
		if (loginUser != null) { email = loginUser.getEmail(); }
		
		if (StringUtils.isNotBlank(email)) {
			removeSurveyAnswers(surveyQuestionId, parentId, surveyItemId, null, email);
		}
	}
	@Override
	public void removeSurveyAnswers(String surveyQuestionId, String parentId, String surveyItemId, QuestionItemType type, String email) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			removeSurveyAnswers(mgr, surveyQuestionId, parentId, surveyItemId, type, email);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private void removeSurveyAnswers(EntityManager mgr, String surveyQuestionId, String parentId, String surveyItemId, QuestionItemType type, String email) throws Exception {
		List<SurveyAnswers> answers = listSurveyAnswers(mgr, surveyQuestionId, parentId, surveyItemId, type, email);
		for (SurveyAnswers answer : answers) {
			doRemoveTransaction(mgr, answer);
		}
	}
	
	private static void validSurveyDate(SurveyQuestions question) throws Exception {
		Date currentDate = new Date();
		
		if (question.getStartDate() != null && currentDate.compareTo(question.getStartDate()) < 0) {
			throw new Exception("It is not survey period.");
		}
		if (question.getEndDate() != null && currentDate.compareTo(question.getEndDate()) > 0) {
			throw new Exception("Survey period passed.");
		}
	}
}