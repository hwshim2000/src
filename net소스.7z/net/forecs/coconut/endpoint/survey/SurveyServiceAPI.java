package net.forecs.coconut.endpoint.survey;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.QuestionItemType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.survey.SurveyAnswers;
import net.forecs.coconut.entity.survey.SurveyItems;
import net.forecs.coconut.entity.survey.SurveyQuestions;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.config.DefaultValue;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.appengine.api.datastore.Text;

@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class SurveyServiceAPI {
	private final ISurveyService surveyService;
	private final IUserService userService;
	
	@Inject
	public SurveyServiceAPI(ISurveyService surveyService, IUserService userService) {
		this.surveyService = surveyService;
		this.userService = userService;
	}
	
	// SURVEY QUESTIONS -------------------------------------------------------------------------------------------------------
	
	@ApiMethod(name = "querySurveyQuestions", path = "survey/questions", httpMethod = HttpMethod.GET)
	@RequiresUser
	public  CollectionResponse<SurveyQuestions> querySurveyQuestions(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.surveyKind) String surveyKind,
			@Nullable @Named(FLD.kindId) String kindId,
			@Nullable @Named(FLD.displayYN) String displayYN,
			@Nullable @Named(FLD.startDate) Date startDate,
			@Nullable @Named(FLD.endDate) Date endDate,
			@Nullable @Named(FLD.includeItems) Boolean includeItems,
			@Nullable @Named(FLD.includeAnswers) Boolean includeAnswers,
			@Nullable @Named(FLD.enableTree) Boolean enableTree) throws Exception {
		CommonService.validNamespace(kindId);
		QueryResult<SurveyQuestions> queryResult = surveyService.querySurveyQuestions(cursorString, limit, surveyKind, kindId, displayYN, startDate, endDate, includeItems, includeAnswers, enableTree);
		List<SurveyQuestions> list = queryResult.getResultList();
		
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<SurveyQuestions> builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "getSurveyQuestion", path = "survey/questions/{surveyQuestionId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public SurveyQuestions getSurveyQuestion(
			@Named(FLD.surveyQuestionId) String surveyQuestionId,
			@Nullable @DefaultValue("true") @Named(FLD.includeItems) Boolean includeItems,
			@Nullable @DefaultValue("true") @Named(FLD.includeAnswers) Boolean includeAnswers,
			@Nullable @DefaultValue("true") @Named(FLD.enableTree) Boolean enableTree) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		return surveyService.getSurveyQuestion(surveyQuestionId, includeItems, includeAnswers, enableTree);
	}
	
	@ApiMethod(name = "getSurveyResults", path = "survey/result/{surveyQuestionId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public SurveyQuestions getSurveyResults(@Named(FLD.surveyQuestionId) String surveyQuestionId) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		return surveyService.getSurveyResults(surveyQuestionId);
	}
	
	@ApiMethod(name = "insertSurveyQuestion", path = "survey/questions", httpMethod = HttpMethod.POST)
	@RequiresUser
	public SurveyQuestions insertSurveyQuestion(SurveyQuestions question) throws Exception {
		CommonService.validNamespace(question);
		return surveyService.insertSurveyQuestion(question);
	}
	
	@ApiMethod(name = "updateSurveyQuestion", path = "survey/questions", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyQuestions updateSurveyQuestion(SurveyQuestions question) throws Exception {
		CommonService.validNamespace(question);
		return surveyService.updateSurveyQuestion(question);
	}
	
	@ApiMethod(name = "removeSurveyQuestion", path = "survey/questions/{surveyQuestionId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeSurveyQuestion(@Named(FLD.surveyQuestionId) String surveyQuestionId) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		surveyService.removeSurveyQuestion(surveyQuestionId);
	}
	
	@ApiMethod(name = "updateSurveyQuestionTitle", path = "survey/questions/title/{surveyQuestionId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyQuestions updateSurveyQuestionTitle(@Named(FLD.surveyQuestionId) String surveyQuestionId,
			@Named(FLD.title) String title) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		return surveyService.updateSurveyQuestionTitle(surveyQuestionId, title);
	}
	
	@ApiMethod(name = "updateSurveyQuestionDescription", path = "survey/questions/description/{surveyQuestionId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyQuestions updateSurveyQuestionDescription(@Named(FLD.surveyQuestionId) String surveyQuestionId, Text description) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		return surveyService.updateSurveyQuestionDescription(surveyQuestionId, description);
	}
	
	@ApiMethod(name = "updateSurveyQuestionDisplayYN", path = "survey/questions/displayYN/{surveyQuestionId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyQuestions updateSurveyQuestionDisplayYN(@Named(FLD.surveyQuestionId) String surveyQuestionId,
			@Named(FLD.displayYN) String displayYN) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		return surveyService.updateSurveyQuestionDisplayYN(surveyQuestionId, displayYN);
	}
	
	@ApiMethod(name = "updateSurveyQuestionPeriod", path = "survey/questions/period/{surveyQuestionId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyQuestions updateSurveyQuestionPeriod(@Named(FLD.surveyQuestionId) String surveyQuestionId,
			@Named(FLD.startDate) Date startDate,
			@Named(FLD.endDate) Date endDate) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		return surveyService.updateSurveyQuestionPeriod(surveyQuestionId, startDate, endDate);
	}
	
	// SURVEY ITEMS -------------------------------------------------------------------------------------------------------
	
	@ApiMethod(name = "insertSurveyItem", path = "survey/items", httpMethod = HttpMethod.POST)
	@RequiresUser
	public SurveyItems insertSurveyItem(SurveyItems item) throws Exception {
		CommonService.validNamespace(item);
		return surveyService.insertSurveyItem(item);
	}
	
	@ApiMethod(name = "updateSurveyItem", path = "survey/items", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyItems updateSurveyItem(SurveyItems item) throws Exception {
		CommonService.validNamespace(item);
		return surveyService.updateSurveyItem(item);
	}
	
	@ApiMethod(name = "updateSurveyItemTitle", path = "survey/items/title/{surveyItemId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyItems updateSurveyItemTitle(@Named(FLD.surveyItemId) String surveyItemId,
			@Named(FLD.title) String title) throws Exception {
		CommonService.validNamespace(surveyItemId);
		return surveyService.updateSurveyItemTitle(surveyItemId, title);
	}
	
	@ApiMethod(name = "updateSurveyItemDescription", path = "survey/items/description/{surveyItemId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyItems updateSurveyItemDescription(@Named(FLD.surveyItemId) String surveyItemId, Text description) throws Exception {
		CommonService.validNamespace(surveyItemId);
		return surveyService.updateSurveyItemDescription(surveyItemId, description);
	}
	
	@ApiMethod(name = "updateSurveyItemType", path = "survey/items/type/{surveyItemId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public SurveyItems updateSurveyItemType(@Named(FLD.surveyItemId) String surveyItemId,
			@Named(FLD.type) QuestionItemType type) throws Exception {
		CommonService.validNamespace(surveyItemId);
		return surveyService.updateSurveyItemType(surveyItemId, type);
	}
	
	@ApiMethod(name = "removeSurveyItem", path = "survey/items/{surveyItemId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeSurveyItem(@Named(FLD.surveyItemId) String surveyItemId) throws Exception {
		CommonService.validNamespace(surveyItemId);
		surveyService.removeSurveyItem(surveyItemId);
	}
	
	// SURVEY ANSWERS -------------------------------------------------------------------------------------------------------
	@ApiMethod(name = "isAnswerSurvey", path = "survey/isAnswer/{surveyQuestionId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result isAnswerSurvey(@Named(FLD.surveyQuestionId) String surveyQuestionId/*, @Nullable @Named(FLD.email) String email*/) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		return new Result(surveyService.isAnswerSurvey(surveyQuestionId, null));
	}
	
	@ApiMethod(name = "getSurveyAnswers", path = "survey/answers/{surveyAnswerId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public SurveyAnswers getSurveyAnswers(@Named(FLD.surveyAnswerId) String surveyAnswerId) throws Exception {
		CommonService.validNamespace(surveyAnswerId);
		return surveyService.getSurveyAnswers(surveyAnswerId);
	}
	
	@ApiMethod(name = "answerSurvey", path = "survey/answers/{surveyItemId}", httpMethod = HttpMethod.POST)
	@RequiresUser
	public SurveyAnswers answerSurvey(@Named(FLD.surveyItemId) String surveyItemId,
			@Nullable Text description,
			@Nullable @Named(FLD.checked) Boolean checked
			/*@Nullable @Named(FLD.email) String email*/) throws Exception {
		CommonService.validNamespace(surveyItemId);
		return surveyService.answerSurvey(surveyItemId, description, checked, null);
	}
	
	@ApiMethod(name = "removeSurveyAnswer", path = "survey/answers/{surveyAnswerId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeSurveyAnswer(@Named(FLD.surveyAnswerId) String surveyAnswerId) throws Exception {
		CommonService.validNamespace(surveyAnswerId);
		surveyService.removeSurveyAnswer(surveyAnswerId);
	}
	
	@ApiMethod(name = "removeSurveyAnswerByEmail", path = "survey/answers/byEmail", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeSurveyAnswerByEmail(@Named(FLD.surveyQuestionId) String surveyQuestionId,
			@Nullable @Named(FLD.parentId)String parentId,
			@Nullable @Named(FLD.surveyItemId) String surveyItemId,
			@Nullable @Named(FLD.email) String email) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		surveyService.removeSurveyAnswers(surveyQuestionId, parentId, surveyItemId, null, email);
	}
	
	@ApiMethod(name = "removeSurveyAnswerById", path = "survey/answers/byId", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeSurveyAnswerById(@Named(FLD.surveyQuestionId) String surveyQuestionId,
			@Nullable @Named(FLD.parentId)String parentId,
			@Nullable @Named(FLD.surveyItemId) String surveyItemId,
			@Nullable @Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		surveyService.removeSurveyAnswers(surveyQuestionId, parentId, surveyItemId, null, userService.getUserEmail(userId));
	}
	
	@ApiMethod(name = "removeMySurveyAnswers", path = "survey/answers/my", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeMySurveyAnswers(@Named(FLD.surveyQuestionId) String surveyQuestionId,
			@Nullable @Named(FLD.parentId)String parentId,
			@Nullable @Named(FLD.surveyItemId) String surveyItemId
			/*@Nullable @Named(FLD.email) String email*/) throws Exception {
		CommonService.validNamespace(surveyQuestionId);
		surveyService.removeMySurveyAnswers(surveyQuestionId, parentId, surveyItemId, null);
	}
}