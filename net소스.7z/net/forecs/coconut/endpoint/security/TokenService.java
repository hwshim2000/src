package net.forecs.coconut.endpoint.security;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.security.AccessType;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.ServletUtil;
import net.forecs.coconut.common.util.security.JwtManager;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.admin.AdminCommonService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.security.TokenContext;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.UnauthenticatedException;
import org.apache.shiro.authz.annotation.Logical;

import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.UnauthorizedException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.memcache.Expiration;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;

import edu.emory.mathcs.backport.java.util.Arrays;

public class TokenService extends AdminCommonService implements ITokenService {
	private static final Logger LOG = Logger.getLogger(TokenService.class.getName());
	public final static boolean ENABLE_TOKEN_USER = false;
	
	private final static int onlineRefreshTokenExpirationTimes = 30 * 24 * 60 * 60;
	private final static int onlineAccessTokenExpirationTimes = 24 * 60 * 60;
	
	private final static int offlineRefreshTokenExpirationTimes = 365 * 24 * 60 * 60;
	private final static int offlineAccessTokenExpirationTimes = 7 * 24 * 60 * 60;
	
//	private final static int refreshTokenExpirationTimes = 120;
//	private final static int accessTokenExpirationTimes = 60;
	
	private final static int recentTokenMaintainTimes = 60 * 60;	// 1 hours
	//public final static String UserAgent = "User-Agent";
	public final static String Authorization = "Authorization";
	public final static String AuthorizationCocoworks = "X-COCOWORKS-AUTHORIZATION";
	public final static String Bearer = "Bearer";
	public final static String Basic = "Basic";
	
	private final IUserService userService;
	
	@Inject
	public TokenService(IUserService userService) {
		this.userService = userService;
	}
	
	@Override
	public Auths registAuth(String clientId, String domainName, String id,
			AccessType accessType, List<Scope> scopes, List<String> addresses,
			boolean agentCheck) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			String secretKey = createSecretKey();
			
			if (StringUtils.isNotBlank(domainName) && StringUtils.isNotBlank(id)) {
				Users user = userService.getUsers(domainName, id);
				if (user == null || !user.isActive()) {
					throw new UnavailableException("User not found or unauthenticated.");
				}
			}
			if (StringUtils.isBlank(clientId)) {
				while(true) {
					clientId = createClientId();
					if (getAuthById(mgr, clientId) == null) { break; }
				}
			} else {
				if (getAuthById(mgr, clientId) != null) {
					throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(clientId));
				}
			}
			
			if (StringUtils.isBlank(id)) { id = CommonProperty.SYSTEM_USER_ID; }
			if (accessType == null) { accessType = AccessType.online; }
			
			Auths auths = new Auths();
			auths.setClientId(clientId);
			auths.setSecretKey(secretKey);
			auths.setDomainName(domainName);
			auths.setId(id);
			auths.setAccessType(accessType);
			auths.setScopes(scopes);
			auths.setAddresses(addresses);
			auths.setAgentCheck(agentCheck);
			doPersistTransaction(mgr, auths);
			
			return auths;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Auths changeSecretKey(String clientId, String currentSecretKey) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Auths auth = doFind(mgr, Auths.class, KeyUtil.createAuthsKey(clientId));
			if (auth == null || StringUtils.equals(Y, auth.getDeleteYN())) {
				throw new UnauthenticatedException("Can not found client authentication information.");
			}
			if (StringUtils.equals(currentSecretKey, auth.getSecretKey())) {
				throw new InvalidKeyException("Invalid secret key.");
			}
			
			auth.setSecretKey(createSecretKey());
			return doMergeTransaction(mgr, auth);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Tokens getAccessToken(HttpServletRequest req, String clientId, String secretKey, boolean refresh) throws Exception {
		return getAccessToken(req, clientId, secretKey, refresh, null);
	}
	
	private Tokens getAccessToken(HttpServletRequest req, String clientId, String secretKey, boolean refresh, String tokenType) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();

		try {
			Auths auth = getAuthById(mgr, clientId);
			if (auth == null || !StringUtils.equals(secretKey, auth.getSecretKey())) {
				throw new UnauthorizedException("Invalid client id or secret key.");
			}
			
//			String ipAddress = req.getHeader("X-FORWARDED-FOR");
//			if (StringUtils.isBlank(ipAddress)) {
//				ipAddress = req.getRemoteAddr(); 
//			}
			String ipAddress = ServletUtil.getRemoteAddr(req); 
			String userAgent = ServletUtil.getUserAgent(req);
			
			// accessType 이 offline일 경우엔 자동으로 refresh를 하도록 설정.
			if (AccessType.offline.equals(auth.getAccessType())) {
				refresh = true;
			}
			
			Tokens token = getRecentToken(clientId, refresh, tokenType, userAgent, ipAddress);
//			Tokens token = new Tokens();
			
			if (token != null) { return token; }
		
			String accessToken = createAccessToken(mgr);
			String refreshToken = createRefreshToken(mgr, accessToken);
			
			token = new Tokens();
			
			token.setKey(KeyUtil.createTokenKey(accessToken));
			token.setAccessToken(accessToken);
			token.setRefreshToken(refreshToken);
			token.setClientId(clientId);
			token.setRefresh(refresh);
			token.setTokenType(tokenType);
			token.setAddress(ipAddress);
			token.setAgent(userAgent);
			
			token.setAuth(auth);
			setExpirationDate(token);
			/*************************/
			setJwsAccessToken(token);
			/*************************/
			
			doPersistTransaction(mgr, token);
			putRecentToken(token, refresh, tokenType, userAgent, ipAddress);
			
			return token;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Tokens getAccessTokenByRefreshToken(String refreshToken) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();

		try {
			Tokens oldToken = findTokenByRefreshToken(mgr, refreshToken);
			
			if (!isValidRefreshToken(oldToken)) {
				throw new UnavailableException("Refresh token not found or expired.");
			}
			
			Auths auth = getAuthById(mgr, oldToken.getClientId());
			if (auth == null) {
				throw new UnauthorizedException("Invalid client auth.");
			}
		
			String accessToken = createAccessToken(mgr);
			
			Tokens newToken = new Tokens();
			
			newToken.setKey(KeyUtil.createTokenKey(accessToken));
			newToken.setAccessToken(accessToken);
			newToken.setRefreshToken(refreshToken);
			newToken.setClientId(oldToken.getClientId());
			newToken.setRefresh(oldToken.isRefresh());
			newToken.setTokenType(oldToken.getTokenType());
			newToken.setAddress(oldToken.getAddress());
			newToken.setAgent(oldToken.getAgent());
			
			newToken.setAuth(auth);
			setExpirationDate(newToken);
			/*************************/
			setJwsAccessToken(newToken);
			/*************************/
			
			doRemoveTransaction(mgr, oldToken);
			doPersistTransaction(mgr, newToken);
			putRecentToken(newToken, newToken.isRefresh(), newToken.getTokenType(), newToken.getAgent(), newToken.getAddress());
			
			return newToken;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private static void setJwsAccessToken(Tokens token) throws NoSuchAlgorithmException, InvalidKeySpecException {
		JwtManager jm = JwtManager.getManager();
		// 사용자의 auth키 값을 이용할 경우
		String jwsAccessToken = jm.generateJwsAccessToken(token);
		token.setJwsAccessToken(jwsAccessToken);
	}
//	public static Tokens getToken(HttpServletRequest req) throws Exception {
//		String accessToken = retrieveAccessToken(req);
//		return getToken(accessToken);
//	}
	public static Tokens getToken(String accessToken) throws Exception {
		if (StringUtils.isBlank(accessToken)) { return null; }
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Tokens token = doFind(mgr, Tokens.class, KeyUtil.createTokenKey(accessToken));
			boolean foreceRefresh = false;
			if (token == null) { // token이  null일 경우에 refreshToken으로 다시한번 조회
				token = findTokenByRefreshToken(mgr, accessToken);
				if (token == null) { return null; }
				foreceRefresh = true;
			}
			
			Auths auth = token.getAuth();
			if (auth == null) {
				auth = doFind(mgr, Auths.class, KeyUtil.createAuthsKey(token.getClientId()));
			}
			
			if (auth != null) {
				token.setAuth(auth);
				if (token.isRefresh() || foreceRefresh) { // token이 refresh가 가능할경우만 refresh를 한다.
					token = tokenExtendByRefresh(mgr, token);
				}
				token.setAuth(auth);
			}
			
			return token;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private static Tokens findTokenByRefreshToken(EntityManager mgr, String refreshToken) throws Exception {
		return new DsQuery<>(Tokens.class).eq(FLD.refreshToken, refreshToken).single(mgr);
	}
	
	@Override
	public Auths getAuths(String clientId) {
		return getAuthById(clientId);
	}
	public static Auths getAuthById(String clientId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			return getAuthById(mgr, clientId);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	public static Auths getAuthById(EntityManager mgr, String clientId) {
		return doFind(mgr, Auths.class, KeyUtil.createAuthsKey(clientId));
	}
	
	@Override
	public Tokens extendTokenExpiration(String clientId, String refreshToken) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Auths auth = getAuthById(mgr, clientId);
			if (auth == null) { throw new UnauthorizedException("Invalid client id."); }
			
			DsQuery<Tokens> dsQuery = new DsQuery<>(Tokens.class)
				.eq(FLD.clientId, clientId)
				.eq(FLD.refreshToken, refreshToken);
			
			Tokens token = dsQuery.single(mgr);
			
			if (!isValidRefreshToken(token)) {
				throw new UnauthorizedException("Invalid refresh token."); 
			}
			token.setAuth(auth);
			setExpirationDate(token);
			/*************************/
			setJwsAccessToken(token);
			/*************************/
			token = doMergeTransaction(mgr, token);
			token.setAuth(auth);
			
			return token;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private static Tokens tokenExtendByRefresh(EntityManager mgr, Tokens token) throws Exception {
		if (!isValidRefreshToken(token)) { return token; }	// valid하지 않은 refresh token인지 체크
		if (isValidExpirationDate(token)) { return token; }	// 아직 valid한 토큰일 경우엔 refresh를 하지 않는다.(performance를 위해)
		setExpirationDate(token);
		/*************************/
		setJwsAccessToken(token);
		/*************************/
		return doMergeTransaction(mgr, token);
	}
	
	private static void setExpirationDate(Tokens token) {
		if (AccessType.offline.equals(token.getAuth().getAccessType())) {
			token.setExpire(CalendarUtil.addSecond(new Date(), offlineAccessTokenExpirationTimes));
			token.setRefreshExpire(CalendarUtil.addSecond(new Date(), offlineRefreshTokenExpirationTimes));
		} else {
			token.setExpire(CalendarUtil.addSecond(new Date(), onlineAccessTokenExpirationTimes));
			token.setRefreshExpire(CalendarUtil.addSecond(new Date(), onlineRefreshTokenExpirationTimes));
		}
	}
	
	@Override
	public void removeAccessToken(String clientId, String accessToken) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Auths auth = getAuthById(mgr, clientId);
			if (auth == null) { throw new UnauthorizedException("Invalid client id."); }
			
			Tokens token = doFind(mgr, Tokens.class, KeyUtil.createTokenKey(accessToken));
			
			if (token == null) { throw new UnauthorizedException("Invalid access token."); }
			if (!StringUtils.equals(clientId, token.getClientId())) { throw new UnauthorizedException("Do not have authority about request token."); }
			
			doRemoveTransaction(mgr, token);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	public static void removeCurrentAccessToken() {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			//Tokens token = TokenContext.getCurrentToken();
			Tokens token = doFind(mgr, Tokens.class, TokenContext.getCurrentAcccessToken());
			if (token != null) {
				doRemoveTransaction(mgr, token);
			}
		} catch (Exception ex) {
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	public static void removeAccessToken(Tokens token) {
		if (token==null) { return; }
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			doRemoveTransaction(mgr, token);
		} catch (Exception ex) {
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void removeUnavailableTokens(String clientId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Tokens> dsQuery = new DsQuery<>(Tokens.class)
				.lt(FLD.refreshExpire, new Date())
				.eq(FLD.clientId, clientId);
			
			List<Tokens> tokens = dsQuery.execute(mgr);
			doRemoveTransaction(mgr, tokens);
		} catch (Exception ex) {
			LOG.warning("[removeInvalidTokens] : " + ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private Tokens getRecentToken(String clientId, Object...objs) {
		try {
			MemcacheService mcs = MemcacheServiceFactory.getMemcacheService();
			
			String hashStr = StringUtils.join(objs);
			String key = String.format("%s_%d", clientId, hashStr.hashCode());
			
			return (Tokens)mcs.get(key);
		} catch (Exception ex) {
			LOG.warning("[getRecentToken] : " + ex.getMessage());
			return null;
		}
	}
	private void putRecentToken(Tokens token, Object...objs) {
		try {
			MemcacheService mcs = MemcacheServiceFactory.getMemcacheService();
			
			String hashStr = StringUtils.join(objs);
			String key = String.format("%s_%d", token.getClientId(), hashStr.hashCode());
			
			mcs.put(key, token, Expiration.byDeltaSeconds(recentTokenMaintainTimes));
		} catch (Exception ex) {
			LOG.warning("[putRecentToken] : " + ex.getMessage());
		}
	}
//	private Tokens recentToken(String clientId, boolean refresh, String tokenType, String userAgent, String ipAddress) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(null);
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Query query = new DsQuery(Tokens.class)
//				.gt(FLD.created, CalendarUtil.addSecond(new Date(), recentTokenFetchTimes))
//				.eq(FLD.refresh, refresh)
//				.eq(FLD.clientId, clientId)
//				.eq(FLD.tokenType, tokenType)
//				.sort(FLD.created, SortDirection.DESC)
//				.setKeysOnly();
//			
//			List<Tokens> tokens = queryResults(mgr, Tokens.class, query);
//			
//			Tokens recentToken = null;
//			for (Tokens token : tokens) {
//				if (!StringUtils.equals(token.getAgent(), userAgent)) { continue; }
//				if (!StringUtils.equals(token.getAddress(), ipAddress)) { continue; }
//				recentToken = token;
//				break;
//			}
//			return recentToken;
//		} catch (Exception ex) {
//			return null;
//		} finally {
//			finalizeTransaction(mgr, prevNamespace);
//		}
//	}
	
	@Override
	public List<Auths> listAuths(String domainName, String id) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Auths> dsQuery = new DsQuery<>(Auths.class)
				.eq(FLD.domainName, domainName)
				.eq(FLD.id, id);
			
			return dsQuery.execute(mgr);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
//	public static String retrieveAccessToken(HttpServletRequest req) {
//		final String authorization = req.getHeader(Authorization);
//		if (StringUtils.isNotBlank(authorization)) {
//			if (authorization.startsWith(Bearer)) {
////				LOG.warning("bearer : " + accessToken);
//				return authorization.substring(Bearer.length()).trim();
//			}
//		}
//
//		final String authorizationCocoworks = req.getHeader(AuthorizationCocoworks);
//		if (StringUtils.isNotBlank(authorizationCocoworks)) {
//			if (authorizationCocoworks.startsWith(Basic)) {
////				LOG.warning("basic : " + accessToken);
//				return authorizationCocoworks.substring(Basic.length()).trim();
//			}
//		}
//		
//		String accessToken = req.getParameter(FLD.accessToken);
//		if (StringUtils.isBlank(accessToken)) { return accessToken.trim(); }
//
//		Map<String, Object> map = ServletUtil.getContentsMap(req);
//		return (String)map.get(FLD.accessToken);
//	}
	
	public static String retrieveAccessTokenForOauth(HttpServletRequest req) {
		String accessToken = null;
		final String authorization = req.getHeader(Authorization);
		if (StringUtils.isNotBlank(authorization)) {
			if (authorization.startsWith(Bearer)) {
//				LOG.warning("bearer : " + accessToken);
				accessToken = authorization.substring(Bearer.length()).trim();
			}
		}
		return accessToken;
	}
	public static String retrieveAccessToken(HttpServletRequest req) {
		final String authorizationCocoworks = req.getHeader(AuthorizationCocoworks);
		String accessToken = null;
		if (StringUtils.isNotBlank(authorizationCocoworks)) {
			if (authorizationCocoworks.startsWith(Basic)) {
//				LOG.warning("basic : " + accessToken);
				accessToken = authorizationCocoworks.substring(Basic.length()).trim();
			}
		}
		if (StringUtils.isNotBlank(accessToken)) { return accessToken; }
		
		accessToken = req.getHeader(FLD.accessToken);
		if (StringUtils.isNotBlank(accessToken)) { return accessToken; }
		
		accessToken = req.getParameter(FLD.accessToken);
		if (StringUtils.isNotBlank(accessToken)) { return accessToken.trim(); }
		
		Map<String, Object> map = ServletUtil.getContentsMap(req);
		accessToken = (String)map.get(FLD.accessToken);
		if (StringUtils.isNotBlank(accessToken)) { return accessToken; }
		
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (StringUtils.equals(FLD.accessToken, cookie.getName())) {
					return cookie.getValue();
				}
			}
		}
		
		return null;
	}
	
	public static Tokens validAccessToken(String accessToken) throws Exception {
		return validAccessToken(getToken(accessToken));
	}
	public static Tokens validAccessToken(Tokens token) throws Exception {
		if (token == null) { throw new UnauthorizedException("Access token not found."); }
		if (token.getAuth() == null || Y.equals(token.getAuth().getDeleteYN())) { throw new UnauthorizedException("Authority not found."); }
		if (!isValidExpirationDate(token)) { throw new UnauthorizedException("Token expired."); }
		
		return token;
	}
	public static Tokens validAccessToken(String accessToken, Scope scope, TokenContext context) throws Exception {
		if (context != null && StringUtils.isBlank(accessToken)) { 
			//accessToken = retrieveAccessToken(context.getRequest());
			accessToken = context.getAccessToken();
			if (StringUtils.isBlank(accessToken)) { throw new UnauthorizedException("Invalid access token : " + accessToken); }
		}
		
		Tokens token = getToken(accessToken);
		
		if (token == null) { throw new UnauthorizedException("Access token not found."); }
		if (!CommonService.isValid(token.getAuth())) { throw new UnauthorizedException("Authority not found."); }
		if (!isValidExpirationDate(token)) { throw new UnauthorizedException("Token expired."); }
		if (!isValidScopes(token, scope)) { throw new UnauthorizedException("Not access privilege area."); }
		if (!isValidAgent(token, context.getUserAgent())) { throw new UnauthorizedException("Incorrected user agent."); }
		if (!isValidRemoteAddress(token, context.getRemoteAddr())) { throw new UnauthorizedException("Not allowed access address."); }
		
		return token;
	}
	public static boolean isValidAccessToken(String accessToken) {
		try {
			return isValidAccessToken(getToken(accessToken));
		} catch (Exception ex) {
			return false;
		}
	}
	public static boolean isValidAccessToken(Tokens token) {
		try {
			return validAccessToken(token) != null;
		} catch (Exception ex) {
			return false;
		}
	}
	
//	public static Tokens validAccessToken(String accessToken, HttpServletRequest req) throws Exception {
//		return validAccessToken(accessToken, null, req);
//	}
//	public static Tokens validAccessToken(String accessToken, Scope scope, HttpServletRequest req) throws Exception {
//		if (req != null && StringUtils.isBlank(accessToken)) { 
//			accessToken = retrieveAccessToken(req);
//			if (StringUtils.isBlank(accessToken)) { throw new UnauthorizedException("Invalid access token : " + accessToken); }
//		}
//		
//		Tokens token = getToken(accessToken);
//		
//		if (token == null) { throw new UnauthorizedException("Access token not found."); }
//		if (token.getAuth() == null) { throw new UnauthorizedException("Authority not found."); }
//		if (!isValidAccessToken(token)) { throw new UnauthorizedException("Token expired."); }
//		if (!isValidScopes(token, scope)) { throw new UnauthorizedException("Not access privilege area."); }
//		if (!isValidAgent(token, req)) { throw new UnauthorizedException("Incorrected user agent."); }
//		if (!isValidRemoteAddress(token, req)) { throw new UnauthorizedException("Not allowed access address."); }
//		
//		return token;
//	}
	
	@SuppressWarnings("unchecked")
	public static void validUserRoles(Users user, String[] roles, Logical logical) throws Exception {
		if (user == null) { return; }
		if (roles == null || roles.length == 0) { return; }
		if (roles.length == 1 && StringUtils.isBlank(roles[0])) { return; }
		if (Logical.OR.equals(logical)) {
			for (String role : user.getRoles()) {
				if (Arrays.asList(roles).contains(role)) { return; }
			}
		} else {
			if (Arrays.asList(roles).containsAll(user.getRoles())) { return; }
		}
		throw new UnauthorizedException("Requires roles.");
	}
	@SuppressWarnings("unchecked")
	public static void validUserPermissions(Users user, String[] permissions, Logical logical) throws Exception {
		if (user == null) { return; }
		if (permissions == null || permissions.length == 0) { return; }
		if (permissions.length == 1 && StringUtils.isBlank(permissions[0])) { return; }
		if (Logical.OR.equals(logical)) {
			for (String permission : user.getPermissions()) {
				if (Arrays.asList(permissions).contains(permission)) { return; }
			}
		} else {
			if (Arrays.asList(permissions).containsAll(user.getPermissions())) { return; }
		}
		throw new UnauthorizedException("Requires permissions.");
	}
	
	private static boolean isValidScopes(Tokens token, Scope scope) {
		if (scope == null || Scope.NONE.equals(scope)) { return true; }	// 요청한 scope가 없으면 권한 체크를 하지 않음
		
		final List<Scope> authScopes = token.getAuth().getScopes();
		
		if (authScopes == null || authScopes.size() == 0) { return true; } // TODO : Scope가 없는 경우의 처리
		if (authScopes.contains(Scope.ADMIN)) { return true; } // 관리자 Scope를 가진 자격이면 true
		return authScopes.contains(scope);
		
//		switch (scope) {
//			case ADMIN :
//				return authScopes.contains(scope);
//			case DOMAIN :
//				if (authScopes.contains(Scope.ADMIN)) { return true; }
//				return authScopes.contains(scope);
//			case DASHBOARD :
//				if (authScopes.contains(Scope.ADMIN)) { return true; }
//				if (authScopes.contains(Scope.DOMAIN)) { return true; }
//				return authScopes.contains(scope);
//			case BOARD :
//				if (authScopes.contains(Scope.ADMIN)) { return true; }
//				if (authScopes.contains(Scope.DOMAIN)) { return true; }
//				return authScopes.contains(scope);
//			case TASK :
//				if (authScopes.contains(Scope.ADMIN)) { return true; }
//				if (authScopes.contains(Scope.DOMAIN)) { return true; }
//				if (authScopes.contains(Scope.BOARD)) { return true; }
//				return authScopes.contains(scope);
//			default :
//				return authScopes.contains(scope);
//		}
	}
//	private static boolean isValidAgent(Tokens token, HttpServletRequest req) {
//		if (req == null) { return true; }
//		if (!token.getAuth().isAgentCheck()) { return true; }
//		
//		final String agent = token.getAgent();
//		final String userAgent = req.getHeader(UserAgent);
//		
//		if (StringUtils.isBlank(agent)) { return true; }
//		if (StringUtils.equals(userAgent, agent)) { return true; }	// TODO : 실제 원격 agent 정보를 체크할 것인지
//		return false;
//	}
//	private static boolean isValidRemoteAddress(Tokens token, HttpServletRequest req) {
//		if (req == null) { return true; }
//		
//		final String ipAddress = token.getAddress();
//		final String remoteAddress = req.getRemoteAddr();
//		final List<String> addresses = token.getAuth().getAddresses();
//		
//		if (StringUtils.isBlank(ipAddress)) { return true; }
//		if (addresses == null || addresses.size() == 0) { return true; }
//		if (addresses.contains("*")) { return true; }
//		if (addresses.contains("*.*.*.*")) { return true; }
//		if (addresses.contains(remoteAddress)) { return true; }
//		if (StringUtils.equals(remoteAddress, ipAddress)) { return true; }	// TODO : 실제 원격 주소를 체크를 할것인지
//		return false;
//	}
	private static boolean isValidAgent(Tokens token, String userAgent) {
		if (StringUtils.isBlank(userAgent)) { return true; }
		if (!token.getAuth().isAgentCheck()) { return true; }
		
		final String agent = token.getAgent();
		
		if (StringUtils.isBlank(agent)) { return true; }
		if (StringUtils.equals(userAgent, agent)) { return true; }	// TODO : 실제 원격 agent 정보를 체크할 것인지
		return false;
	}
	private static boolean isValidRemoteAddress(Tokens token, String remoteAddress) {
		if (StringUtils.isBlank(remoteAddress)) { return true; }
		
		final String ipAddress = token.getAddress();
		final List<String> addresses = token.getAuth().getAddresses();
		
		if (StringUtils.isBlank(ipAddress)) { return true; }
		if (addresses == null || addresses.size() == 0) { return true; }
		if (addresses.contains("*")) { return true; }
		if (addresses.contains("*.*.*.*")) { return true; }
		if (addresses.contains(remoteAddress)) { return true; }
		if (StringUtils.equals(remoteAddress, ipAddress)) { return true; }	// TODO : 실제 원격 주소를 체크를 할것인지
		return false;
	}
	
	private static boolean isValidExpirationDate(Tokens token) {
		if (token == null) { return false; }
		if (new Date().compareTo(token.getExpire()) > 0) { return false; }
		return true;
	}
	private static boolean isValidRefreshToken(Tokens token) {
		if (token == null) { return false; }
		if (new Date().compareTo(token.getRefreshExpire()) > 0) { return false; }
		return true;
	}
	
	private static String createClientId() throws Exception {
		return createToken(16, true);
	}
	private static String createSecretKey() throws Exception {
		return createToken(32, true);
	}
	private static String createAccessToken(EntityManager mgr) throws Exception {
		while (true) {
			String token = createToken(64, true);
			if (doFind(mgr, Tokens.class, token) == null) {
				return token;
			}
		}
	}
	private static String createRefreshToken(EntityManager mgr, String accessToken) throws Exception {
		while (true) {
			String token = createToken(64, true);
			if (doFind(mgr, Tokens.class, token) == null && !StringUtils.equals(accessToken, token)) {
				return token;
			}
		}
	}
	private static String createToken(int length, boolean isChunked) throws Exception {
		String source = KeyUtil.generateCode(length);
//		LOG.warning(source);
		byte [] tokenByte = Base64.encodeBase64(source.getBytes(StandardCharsets.UTF_8), false, isChunked);
		final String token = new String(tokenByte, StandardCharsets.UTF_8);
//		LOG.warning(token);
		return token;
	}
	
//	private static void putMemcache(Tokens token) {
//		putMemcache(token, accessTokenExpirationTimes);
//	}
//	private static void putMemcache(Tokens token, int expirationTimes) {
//		mcs.put(token.getAccessToken(), token, Expiration.byDeltaSeconds(expirationTimes), SetPolicy.SET_ALWAYS);
//	}
//	private static Tokens getMemcache(String accessToken) {
//		return (Tokens)mcs.get(accessToken);
//	}
//	private static void deleteMemcache(String accessToken) {
//		mcs.delete(accessToken);
//	}
	
	
//	private static String createAccessToken() throws Exception {
//		String source = KeyUtil.generateCode(32);
//		 
//		LOG.warning(source);
//		String key = "1111111111111111";
//		String secSource = AESCipher.encode(source, key);
//		
//		byte [] tokenByte = Base64.encodeBase64(secSource.getBytes(), false, true);
//		final String token = new String(tokenByte);
//		LOG.warning(token);
//		return token;
//	}
	
//	private static String resolveAccessToken(String token) throws Exception {
//		String key = "1111111111111111";
//		String decodedToken = new String(Base64.decodeBase64(token.getBytes()));
//		String source  = AESCipher.decode(decodedToken, key);
//		
//		LOG.warning("source " + source);
//		return source;
//	}
//	
//	public static void main(String[] args) throws Exception {
//		String token = createAccessToken();
//		//String source = resolveAccessToken(token);
//		LOG.warning(token);
//		LOG.warning(createClientId());
//		LOG.warning(createSecretKey());
//	}
}
