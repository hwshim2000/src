package net.forecs.coconut.endpoint.security;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.code.security.AccessType;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.endpoint.admin.IAdminCommonService;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;

public interface ITokenService extends IAdminCommonService {
	public abstract List<Auths> listAuths(String domainName, String id) throws Exception;
	public abstract Auths getAuths(String clientId);
	public abstract Tokens getAccessToken(HttpServletRequest req, String clientId, String secretKey, boolean refresh) throws Exception;
	public abstract Tokens getAccessTokenByRefreshToken(String refreshToken) throws Exception;

	public abstract Auths registAuth(String clientId, String domainName,
			String id, AccessType accessType, List<Scope> scopes,
			List<String> addresses, boolean agentCheck) throws Exception;
	public abstract Auths changeSecretKey(String clientId, String currentSecretKey) throws Exception;
	public abstract void removeAccessToken(String clientId, String accessToken) throws Exception;
	public abstract Tokens extendTokenExpiration(String clientId, String refreshToken) throws Exception;
	public abstract void removeUnavailableTokens(String clientId);
}
