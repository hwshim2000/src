package net.forecs.coconut.endpoint.security;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.security.AccessType;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.admin.AdminCommonService;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.appengine.api.users.User;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class TokenServiceAPI {
	private final ITokenService tokenService;
	
	@Inject
	public TokenServiceAPI(ITokenService tokenService) {
		this.tokenService = tokenService;
	}
	
	@ApiMethod(name = "listAuths", path = "auths", httpMethod = HttpMethod.GET,
			scopes = {CommonProperty.EMAIL_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	public List<Auths> listAuths(
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.id) String id, 
			@Named(FLD.code) String code,
			User user) throws Exception {
		if (!StringUtils.equals(code, AdminCommonService.secCode)) { throw new UnavailableException("Invalid code"); }
		AdminCommonService.validGAuthUser(user);
		return tokenService.listAuths(domainName, id);
	}
	
	@ApiMethod(name = "getAuths", path = "auths/{clientId}", httpMethod = HttpMethod.GET,
			scopes = {CommonProperty.EMAIL_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	public Auths getAuths(@Named(FLD.clientId) String clientId,
			@Named(FLD.code) String code,
			User user) throws Exception {
		if (!StringUtils.equals(code, AdminCommonService.secCode)) { throw new UnavailableException("Invalid code"); }
		AdminCommonService.validGAuthUser(user);
		return tokenService.getAuths(clientId);
	}
	
	@ApiMethod(name = "getAccessToken", path = "tokens/{clientId}/{secretKey}", httpMethod = HttpMethod.GET)
	public Tokens getAccessToken(HttpServletRequest req,
			@Named(FLD.clientId) String clientId,
			@Named(FLD.secretKey) String secretKey,
			@Named(FLD.refresh) boolean refresh) throws Exception {
		return tokenService.getAccessToken(req, clientId, secretKey, refresh);
	}
	
	@ApiMethod(name = "getAccessTokenByRefreshToken", path = "tokens/refresh", httpMethod = HttpMethod.GET)
	public Tokens getAccessTokenByRefreshToken(@Named(FLD.refreshToken) String refreshToken) throws Exception {
		return tokenService.getAccessTokenByRefreshToken(refreshToken);
	}
	
	@Deprecated
	@ApiMethod(name = "validAccessToken", path = "tokens/valid", httpMethod = HttpMethod.POST)
	public Tokens validAccessToken(HttpServletRequest req, @Named(FLD.accessToken) String accessToken) throws Exception {
		return TokenService.validAccessToken(accessToken);
	}
	
	@ApiMethod(name = "registAuth", path = "auths/regist", httpMethod = HttpMethod.POST,
		scopes = {CommonProperty.EMAIL_SCOPE},
	    clientIds = {CommonProperty.WEB_CLIENT_ID,
		com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	public Auths registAuth(
			@Nullable @Named(FLD.clientId) String clientId,
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.id) String id,
			@Nullable @Named(FLD.accessType) AccessType accessType,
			@Nullable @Named(FLD.scopes) List<Scope> scopes,
			@Nullable @Named(FLD.addresses) List<String> addresses,
			@Named(FLD.agentCheck) boolean agentCheck,
			@Named(FLD.code) String code,
			User user) throws Exception {
		if (!StringUtils.equals(code, AdminCommonService.secCode)) { throw new UnavailableException("Invalid code"); }
		AdminCommonService.validGAuthUser(user);
		return tokenService.registAuth(clientId, domainName, id, accessType, scopes, addresses, agentCheck);
	}
	
	@ApiMethod(name = "changeSecretKey", path = "auths/secretKey", httpMethod = HttpMethod.PUT)
	public Auths changeSecretKey(@Named(FLD.clientId) String clientId, @Named(FLD.secretKey) String currentSecretKey) throws Exception {
		return tokenService.changeSecretKey(clientId, currentSecretKey);
	}
	
	@Deprecated
	@ApiMethod(name = "removeAccessToken", path = "tokens", httpMethod = HttpMethod.DELETE)
	public void removeAccessToken(@Named(FLD.clientId) String clientId, @Named(FLD.accessToken) String accessToken) throws Exception {
		tokenService.removeAccessToken(clientId, accessToken);
	}
	
	@ApiMethod(name = "extendTokenExpiration", path = "tokens/extend", httpMethod = HttpMethod.PUT)
	public Tokens extendTokenExpiration(@Named(FLD.clientId) String clientId, @Named(FLD.refreshToken) String refreshToken) throws Exception {
		return tokenService.extendTokenExpiration(clientId, refreshToken);
	}
	@Deprecated
	@ApiMethod(name = "removeUnavailableTokens", path = "tokens/unavailable", httpMethod = HttpMethod.DELETE)
	public void removeUnavailableTokens(@Nullable @Named(FLD.clientId) String clientId) {
		tokenService.removeUnavailableTokens(clientId);
	}
}
