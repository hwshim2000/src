package net.forecs.coconut.endpoint.domain;

import java.util.List;
import java.util.Map;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.domain.Departments;

public interface IDepartmentService extends ICommonService {
	public abstract Map<String, Object> loadAllDepartmentObjects(String departmentId) throws Exception;	// for getOrgChart
	public abstract Departments getDepartmentsTree(String departmentId, Boolean makeVirtual) throws Exception;
	public abstract List<Departments> listDepartmentsTree(String departmentId, Boolean makeVirtual) throws Exception;
	public abstract List<Departments> listDepartments(Boolean makeVirtual) throws Exception;
	public abstract Departments getDepartment(String departmentId);
	public abstract Departments saveDepartment(Departments department) throws Exception;
	public abstract void removeDepartment(String departmentId) throws Exception;
	public abstract void moveDepartment(String departmentId, String parentId) throws Exception;
	public abstract int removeAllDepartments() throws Exception;
	public abstract String validRootId(List<Departments> departments);
	public abstract List<Departments> applyDepartments(String domainName, List<Departments> departments) throws Exception;
	public abstract List<Departments> parseDepartments(String jsonString) throws Exception;
	public abstract List<Departments> applyDepartmentsFromJSON(String domainName, String jsonString) throws Exception;
}
