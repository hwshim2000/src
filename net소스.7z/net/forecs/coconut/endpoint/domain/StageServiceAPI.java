package net.forecs.coconut.endpoint.domain;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.domain.Stagelist;
import net.forecs.coconut.entity.domain.Stages;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;


@Api(name = API.DOMAIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.DOMAIN_SERVICE_PACKAGE), description = "CoCoNut 최상위 Domain API 목록", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class StageServiceAPI {
	private final IStageService stageService;
	
	@Inject
	public StageServiceAPI(IStageService stageService) {
		this.stageService = stageService;
	}
	
	@ApiMethod(name = "getStage", path = "domains/stages/{stageId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Stages getStage(@Named(FLD.stageId) String stageId) throws Exception {
		CommonService.validNamespace(stageId);
		return stageService.getStage(stageId);
	}
	
	@ApiMethod(name = "listStages", path = "domains/stages", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<Stages> listStages(@Nullable @Named(FLD.boardIds) List<String> boardIds) throws Exception {
		if (boardIds != null) {
			if (!StringUtils.equals(StageService.COMMON_TASK_STAGE, boardIds.get(0))) {
				CommonService.validNamespace(boardIds.get(0));
			}
		}
		return stageService.listStages(boardIds);
	}
	
	@ApiMethod(name = "insertStage", path = "domains/stage", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Stages insertStage(Stages stage) throws Exception {
		return stageService.insertStage(stage);
	}
	
	@ApiMethod(name = "insertStages", path = "domains/stages", httpMethod = HttpMethod.POST)
	@RequiresUser
	public List<Stages> insertStages(Stagelist stages) throws Exception {
		return stageService.insertStages(stages.getStages());
	}

	@ApiMethod(name = "updateStageTitle", path = "domains/stages/{stageId}/title", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Stages updateStageTitle(@Named(FLD.stageId) String stageId, @Named(FLD.title) String title) throws Exception {
		CommonService.validNamespace(stageId);
		return stageService.updateStageTitle(stageId, title);
	}
	
	@ApiMethod(name = "updateStageColor", path = "domains/stages/{stageId}/color", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Stages updateStageColor(@Named(FLD.stageId) String stageId, @Named(FLD.color) String color) throws Exception {
		CommonService.validNamespace(stageId);
		return stageService.updateStageColor(stageId, color);
	}
	
	@ApiMethod(name = "updateStageIcon", path = "domains/stages/{stageId}/icon", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Stages updateStageIcon(@Named(FLD.stageId) String stageId, @Named(FLD.icon) String icon) throws Exception {
		CommonService.validNamespace(stageId);
		return stageService.updateStageIcon(stageId, icon);
	}
	
	@ApiMethod(name = "updateStage", path = "domains/stages", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Stages updateStage(@Named(FLD.stageId) String stageId
			, @Named(FLD.title) String title
			, @Named(FLD.color) String color
			, @Named(FLD.icon) String icon) throws Exception {
		CommonService.validNamespace(stageId);
		return stageService.updateStage(stageId, title, color, icon);
	}
	
	@ApiMethod(name = "updateStagesOrder", path = "domains/stages/order", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public void updateStagesOrder(@Named(FLD.stageIds) List<String> stageIds) throws Exception {
		if (stageIds != null && stageIds.size() > 0) {
			CommonService.validNamespace(stageIds.get(0));
		}
		stageService.updateStagesOrder(stageIds);
	}
	
	@ApiMethod(name = "updateBoardStagesOrder", path = "board/stages/order", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public void updateBoardStagesOrder(@Named(FLD.boardId) String boardId, @Nullable @Named(FLD.stageIds) List<String> stageIds) throws Exception {
		CommonService.validNamespace(boardId);
		stageService.updateBoardStagesOrder(boardId, stageIds);
	}
	
	@ApiMethod(name = "removeStage", path = "domains/stages/{stageId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeStage(@Named(FLD.stageId) String stageId) throws Exception {
		//stageService.removeStage(stageId);
		stageService.permanentRemoveStage(stageId);
	}
	
	@ApiMethod(name = "stageMapByStageOrdinal", path = "domains/stages/byOrdinal", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<Integer, Stages> stageMapByStageOrdinal() throws Exception {
		return stageService.stageMapByStageOrdinal();
	}
	
	@ApiMethod(name = "stageMapByTaskStageCode", path = "domains/stages/byCode", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<String, Stages> stageMapByCode() throws Exception {
		return stageService.stageMapByTaskStageCode();
	}
	
	@ApiMethod(name = "stageMapByStageId", path = "domains/stages/byId", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<String, Stages> stageMapByStageId() throws Exception {
		return stageService.stageMapByStageId();
	}
}
