package net.forecs.coconut.endpoint.domain;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.group.Groups;


public interface IGroupService extends ICommonService {
	public abstract List<Groups> listGroups() throws Exception;
	public abstract Groups insertGroups(Groups groups) throws Exception;
	public abstract Groups insertGroups(EntityManager mgr, Groups groups) throws Exception;
	public abstract Groups updateGroups(Groups groups) throws Exception;
	public abstract void removeGroups(String domainId, String groupId) throws Exception;
	
//	@Deprecated
//	public abstract Groups getDefaultGroup(String domainId) throws Exception;
//	@Deprecated
//	public abstract Groups getGroups(String groupId);
//	@Deprecated
//	public abstract boolean changeOrderGroups(List<String> groupIds) throws Exception;
}