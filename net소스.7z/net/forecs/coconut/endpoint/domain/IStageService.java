package net.forecs.coconut.endpoint.domain;

import java.util.List;
import java.util.Map;

import net.forecs.coconut.entity.domain.Stages;

public interface IStageService {
	public abstract Stages getStage(String stageId) throws Exception;
	public abstract Stages getStageByTaskStageCode(String taskStage);
	public abstract List<Stages> listStages(List<String> boardIds) throws Exception;
	public abstract Stages insertStage(Stages stage) throws Exception;
	public abstract List<Stages> insertStages(List<Stages> stages) throws Exception;
	public abstract Stages updateStageTitle(String stageId, String title);
	public abstract Stages updateStage(String stageId, String title, String color, String icon) throws Exception;
	public abstract void updateStagesOrder(List<String> stageIds);
	public abstract void updateBoardStagesOrder(String boardId, List<String> stageIds) throws Exception;
	
	public abstract Stages updateStageColor(String stageId, String color);
	public abstract Stages updateStageIcon(String stageId, String color);
	public abstract void removeStage(String stageId) throws Exception;
	public abstract void permanentRemoveStage(String stageId) throws Exception;
	
	public abstract Map<Integer, Stages> stageMapByStageOrdinal() throws Exception;
	public abstract Map<String, Stages> stageMapByTaskStageCode() throws Exception;
	public abstract Map<String, Stages> stageMapByStageId() throws Exception;
}
