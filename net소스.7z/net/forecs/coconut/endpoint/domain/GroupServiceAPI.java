package net.forecs.coconut.endpoint.domain;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.query.QueryOption;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.shiro.annotation.RequiresOwner;
import net.forecs.coconut.user.Permission;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;


@Api(name = API.DOMAIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.DOMAIN_SERVICE_PACKAGE), description = "CoCoNut 최상위 Domain API 목록", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class GroupServiceAPI {
	private final IGroupService groupService;

	@Inject
	public GroupServiceAPI(IGroupService groupService) {
		this.groupService = groupService;
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getDefaultGroup", path = "domains/{domainId}/group/default", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Groups getDefaultGroup(@Named(FLD.domainId) String domainId) throws Exception {
//		CommonService.validNamespace(domainId);
//		return groupService.getDefaultGroup(domainId);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryGroups", path = "domains/groups/query", httpMethod = HttpMethod.POST)
	@RequiresUser
	public CollectionResponse<Groups> queryGroups(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable QueryOption queryOption) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		}
		List<Groups> list = groupService.listGroups();
		return CollectionResponse.<Groups>builder().setItems(list).setNextPageToken(null).build();
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getGroups", path = "domains/groups/{groupId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Groups getGroups(@Named(FLD.groupId) String groupId) throws UnavailableException {
//		CommonService.validNamespace(groupId);
//		return groupService.getGroups(groupId);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "insertGroups", path = "domains/groups", httpMethod = HttpMethod.POST)
	@RequiresUser
	@RequiresPermissions(Permission.GROUP_CREATE)
	public Groups insertGroups(Groups group) throws Exception {
		CommonService.validNamespace(group.getDomainId());
		return groupService.insertGroups(group);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateGroups", path = "domains/groups", httpMethod = HttpMethod.PUT)
	@RequiresUser
	@RequiresPermissions(Permission.GROUP_WRITE)
	public Groups updateGroups(Groups group) throws Exception {
		CommonService.validNamespace(group);
		return groupService.updateGroups(group);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeGroups", path = "domains/groups/{groupId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	@RequiresOwner(clazz = Groups.class, objectId = "{groupId}")	// TODO : Added for test, Remove this before release
	@RequiresPermissions(Permission.GROUP_DELETE)
	public void removeGroups(@Nullable @Named(FLD.domainId) String domainId,
			@Named(FLD.groupId) String groupId) throws Exception {
		CommonService.validNamespace(groupId);
		groupService.removeGroups(domainId, groupId);
	}

	// ************* Unused service ******************
//	@ApiMethod(name="changeOrderGroups", path = "domains/groups/order", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Result changeOrderGroups(@Named(FLD.groupIds) List<String> groupIds) throws Exception {
//		CommonService.validNamespace(groupIds.get(0));
//		return new Result(groupService.changeOrderGroups(groupIds));
//	}
}