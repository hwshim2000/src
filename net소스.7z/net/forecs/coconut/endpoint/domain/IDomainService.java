package net.forecs.coconut.endpoint.domain;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.user.Users;


public interface IDomainService extends ICommonService {
	public abstract Domains createDomains(Domains domains, String email) throws Exception;
	public abstract Users assignMember(String domainId, Users user) throws Exception;
	public abstract Users reassignMember(String userId) throws Exception;
	public abstract void unassignMember(String userId) throws Exception;
	
	public abstract Domains getDomains(String domainId);
	public abstract Domains getDomains(EntityManager mgr, String domainId);
	public abstract Domains findByDomainName(String domainName);

	public abstract Users assignOrOverwriteMember(Domains domain, Users user, boolean isOverwrite, String loginUserId) throws Exception;
	public abstract List<Users> assignOrOverwriteMemberList(Domains domain, List<Users> userList, boolean isOverwrite, String loginUserId) throws Exception;
	public abstract Users assignAdmin(EntityManager mgr, String domainName, String id, String password, String email, String userName, String nickName) throws Exception;
	
	public abstract void permanentRemoveUsers(String userId) throws Exception;
	public abstract boolean isAssignedBoards(String userId) throws Exception;

//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract boolean checkDuplicationDomainName(String domainName);
//	public abstract List<Users> reassignMemberList(List<String> userIdList) throws Exception;
//	public abstract Users assignGuest(String domainId, Users user) throws Exception;
//	public abstract List<Users> unassignMemberList(List<String> userIdList) throws Exception;
//	public abstract Domains insertDomains(EntityManager mgr, Domains domains) throws Exception;
//	public abstract Domains updateDomains(Domains domains) throws Exception;
//	public abstract Domains updateDomains(EntityManager mgr, Domains domains) throws Exception;
//	public abstract void removeDomains(String domainId) throws Exception;
//	public abstract Users getDomainOwner (String domainId);
//	public abstract void removeAllDomainData(String domainName) throws Exception;
//	public abstract long countBoardMemberAuths(String userId) throws Exception;
//	public abstract Users assignAdmin(String domainName, String id, String password, String email, String userName, String nickName) throws Exception;
//	public abstract Users updateDomainNameForDefaultUser(String domainName, String id);
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}