package net.forecs.coconut.endpoint.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.TaskStage;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.domain.Stages;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;

public class StageService extends CommonService implements IStageService {
	//private static final Logger LOG = Logger.getLogger(StageService.class.getName());
	private static final int DEFAULT_STAGE_ORDINAL = 100;
	public static final String COMMON_TASK_STAGE = "COMMON";
	
	private final ITaskService taskService;
	
	@Inject
	public StageService(ITaskService taskService) {
		this.taskService = taskService;
	}

	@Override
	public Stages getStage(String stageId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return doFind(mgr, Stages.class, stageId);
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Stages getStageByTaskStageCode(String taskStage) {
		EntityManager mgr = getEntityManager();

		try {
			return doFind(mgr, Stages.class, createStageKey(taskStage));
		} catch (Exception ex) {
			return null;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Map<Integer, Stages> stageMapByStageOrdinal() throws Exception {
		List<Stages> stages = listStages(null);
		Map<Integer, Stages> stageMap = new HashMap<Integer, Stages>();
		for (Stages stage : stages) {
			stageMap.put(stage.getStageOrdinal(), stage);
		}
		return stageMap;
	}
	@Override
	public Map<String, Stages> stageMapByTaskStageCode() throws Exception {
		List<Stages> stages = listStages(null);
		Map<String, Stages> stageMap = new HashMap<String, Stages>();
		for (Stages stage : stages) {
			stageMap.put(stage.getTaskStage(), stage);
		}
		return stageMap;
	}
	@Override
	public Map<String, Stages> stageMapByStageId() throws Exception {
		List<Stages> stages = listStages(null);
		Map<String, Stages> stageMap = new HashMap<String, Stages>();
		for (Stages stage : stages) {
			stageMap.put(stage.getStageId(), stage);
		}
		return stageMap;
	}
	
	@Override
	public List<Stages> listStages(List<String> boardIds) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			if (boardIds != null) { java.util.Collections.sort(boardIds);	}
			MemcacheManager<Stages, List<Stages>> mm = new MemcacheManager<>(Stages.class, MemcacheManager.keySet(boardIds));
			String memberMemcacheKey = mm.createMemcacheKey(boardIds);
			List<Stages> stages = mm.getMemcache(memberMemcacheKey);

			if (stages == null) {
				stages = new ArrayList<Stages>();
				
				DsQuery<Stages> dsQuery = new DsQuery<>(Stages.class)
						//.in(FLD.boardId, boardIdList)
						.eq(FLD.deleteYN, null)
						.sort(FLD.ordernum, SortDirection.ASC);
					
				List<Stages> results = dsQuery.execute(mgr);
				// 이전 버전에서의 단계를 활용하기 위해 고유값인 ordinal값이 저장되어 있는지 구분하기 위해
				List<Integer> defaultOrdinals = new ArrayList<Integer>();
				for (Stages stage : results) {
					// 이전 ordinal값이 없으면 추가로 DB에 저장하기 위해 목록에 저장
					if (stage.getStageOrdinal() < DEFAULT_STAGE_ORDINAL) {
						defaultOrdinals.add(stage.getStageOrdinal());
					}
					if (boardIds != null && !boardIds.contains(stage.getBoardId())) { continue; }
					if (Y.equals(stage.getDeleteYN())) { continue; } 
					stages.add(stage);
				}
				
				// 목록에 저장된 값이 없을 경우를 판별하여, 기존의 ordinal값을 저장
				List<Stages> defaultStages = initDefaultStage(mgr, defaultOrdinals);
				if (boardIds == null || boardIds.contains(COMMON_TASK_STAGE)) {
					stages.addAll(0, defaultStages);
				}
				// 새로 추가한 기존의 Stage가 있을 경우, 목록의 첫부분에 저장
				mm.setMemcache(memberMemcacheKey, stages);
			}
			
			return stages;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private List<Stages> initDefaultStage(EntityManager mgr, List<Integer> defaultOrdinals) {
		List<Stages> stages = new ArrayList<Stages>();
		
		for (TaskStage taskStage : TaskStage.values()) {
			// 이미 DB에 저장된 ordinal이면 무시, 없으면 신규 추가
			if (defaultOrdinals.contains(taskStage.getOrdinal())) { continue; }
			Stages stage = doFind(mgr, Stages.class, createStageKey(taskStage));
			if (stage == null) {
				stage = new Stages(taskStage.toString(), taskStage.toString(), taskStage.getOrdinal());
				doPersistTransaction(mgr, stage);
				stages.add(stage);
			}
		}

		return stages;
	}
	
	@Override
	public Stages insertStage(Stages stage) throws Exception {
		EntityManager mgr = getEntityManager();
		try {

			return insertStage(mgr, stage);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Stages> insertStages(List<Stages> stages) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			List<Stages> results = new ArrayList<Stages>();
			for (Stages stage : stages) {
				stage = insertStage(mgr, stage);
				results.add(stage);
			}
			return results;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private Stages insertStage(EntityManager mgr, Stages stage) throws Exception {
		if (stage.getKey() == null) {
			int stageOrdinal = nextStageOrdinal(mgr);
			stage.setKey(createStageKey(stageOrdinal));
			stage.setTaskStage(createStage(stageOrdinal));
			stage.setStageOrdinal(stageOrdinal);
			stage.setOrdernum(stageOrdinal);
		} else if (contains(mgr, Stages.class, stage.getKey())) {
			throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(Stages.class, stage.getTaskStage()));
		}
		if (StringUtils.isBlank(stage.getBoardId())) {
			stage.setBoardId(COMMON_TASK_STAGE);
		}
		doPersistTransaction(mgr, stage);
		return stage;
	}
	
	@Override
	public Stages updateStageTitle(String stageId, String title) {
		EntityManager mgr = getEntityManager();
		try {
			Stages stage = doFind(mgr, Stages.class, stageId);
			stage.setTitle(title);
			return doMergeTransaction(mgr, stage);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Stages updateStageColor(String stageId, String color) {
		EntityManager mgr = getEntityManager();
		try {
			Stages stage = doFind(mgr, Stages.class, stageId);
			stage.setColor(color);
			return doMergeTransaction(mgr, stage);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Stages updateStageIcon(String stageId, String icon) {
		EntityManager mgr = getEntityManager();
		try {
			Stages stage = doFind(mgr, Stages.class, stageId);
			stage.setIcon(icon);
			return doMergeTransaction(mgr, stage);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public Stages updateStage(String stageId, String title, String color, String icon) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Stages stage = doFind(mgr, Stages.class, stageId);
			stage.setTitle(title);
			stage.setColor(color);
			stage.setIcon(icon);
			
			return doMergeTransaction(mgr, stage);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void updateStagesOrder(List<String> stageIds) {
		EntityManager mgr = getEntityManager();
		try {
			
			for (int inx = 0; inx < stageIds.size(); inx++) {
				Stages stage = doFind(mgr, Stages.class, stageIds.get(inx));
				stage.setOrdernum(inx);
				doMergeTransaction(mgr, stage);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public void updateBoardStagesOrder(String boardId, List<String> stageIds) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Boards board = doFind(mgr, Boards.class, boardId);
			
			if (stageIds != null & stageIds.size() > 0) {
				ObjectMapper om = new ObjectMapper();
				String stageOrder = om.writeValueAsString(stageIds);
				board.setStageOrder(new Text(stageOrder));
			} else {
				board.setStageOrder(null);
			}
			doMergeTransaction(mgr, board);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeStage(String stageId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Stages stage = doFind(mgr, Stages.class, stageId);
			valid(stage);
			stage.setDeleteYN(Y);
			doMergeTransaction(mgr, stage);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void permanentRemoveStage(String stageId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Stages originStage = doFind(mgr, Stages.class, stageId);
			Stages targetStage = doFind(mgr, Stages.class, createStageKey(TaskStage.None.toString()));
			taskService.batchMoveStage(mgr, originStage.getBoardId(), originStage, targetStage);
			doRemoveTransaction(mgr, originStage);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private int nextStageOrdinal(EntityManager mgr) throws Exception {
		DsQuery<Stages> dsQuery = new DsQuery<>(Stages.class)
				.eq(FLD.deleteYN, null)
				.sort(FLD.stageOrdinal, SortDirection.DESC)
				.cursor(null)
				.limit(1);
		
		List<Stages> stages = dsQuery.execute(mgr);
		
		int stageOrdinal = DEFAULT_STAGE_ORDINAL;
		if (stages.size() == 1) { stageOrdinal = stages.get(0).getStageOrdinal(); }
		if (stageOrdinal < DEFAULT_STAGE_ORDINAL) { stageOrdinal = DEFAULT_STAGE_ORDINAL; }
		while(true) {
			if (!contains(mgr, Stages.class, createStageKey(++stageOrdinal))) {
				break;
			}
		}
		return stageOrdinal;
	}
	
	private static String createStage(int stageOrdinal) {
		return String.format("STAGE-%d", stageOrdinal);
	}
	private static Key createStageKey(int stageOrdinal) {
		return KeyUtil.createStageKey(createStage(stageOrdinal));
	}
	private static Key createStageKey(TaskStage taskStage) {
		return KeyUtil.createStageKey(taskStage.toString());
	}
	private static Key createStageKey(String stage) {
		return KeyUtil.createStageKey(stage);
	}
}
