package net.forecs.coconut.endpoint.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.Dept;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.JsonType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.JSONUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.domain.Departments;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.response.ServiceUnavailableException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Text;
import com.google.gson.JsonParseException;


public class DepartmentService extends CommonService implements IDepartmentService {
//	private static final Logger LOG = Logger.getLogger(DepartmentService.class.getName());
//	private static final String ITEM = "item";
	private static final String ETC_KEY_NAME = "__ETC__";
//	private static final String CHILDREN  = "children";
	
	private final IUserService userService;
	@Inject
	public DepartmentService(IUserService userService) {
		this.userService = userService;
	}
	
	@Override
	public String validRootId(List<Departments> departments) {
		try {
			Map<String, String> childParentMap = new LinkedHashMap<String, String>();
			for (Departments department : departments) {
				String parentId = department.getParentId();
				String departmentId = department.getDepartmentId();
				if (StringUtils.equals(departmentId, parentId)) { parentId = null; }
				if (StringUtils.isBlank(departmentId)) {
					throw new IllegalArgumentException("Department id can not be null.");
				}
				childParentMap.put(departmentId, parentId);
			}
			return validAndFindRoot(childParentMap);
		} catch (Exception ex) {
			return null;
		}
	}
	
	
	// for getOrgChart
	@Override
	public Map<String, Object> loadAllDepartmentObjects(String departmentId) throws Exception {
		Map<String, Object> objMap = new HashMap<String, Object>();
		
		Users loginUser = getCurrentUser();
		List<Users> users = userService.listUsers(null, true);
		Map<String, Users> usersMap = getUsersMap(loginUser, users);
		List<Departments> depts = listDepartmentsTree(usersMap, departmentId, false);
		
		//String color = null;
		String theme = null;
		String rootId = departmentId;
		if (StringUtils.isBlank(departmentId)) {
			for(Departments dept : depts) {
				if (Boolean.TRUE.equals(dept.getRootNode())) {
					rootId = dept.getDepartmentId();
					//color = dept.getColor();
					theme = dept.getTheme();
					break;
				}
			}
		} else {
			for(Departments dept : depts) {
				if (StringUtils.equals(departmentId, dept.getDepartmentId())) {
					//color = dept.getColor();
					theme = dept.getTheme();
					break;
				}
			}
		}
		
		objMap.put("user", loginUser);
		objMap.put("users", users);
		objMap.put("depts", depts);
		objMap.put("rootId", rootId);
		//objMap.put("color", color);
		objMap.put("theme", theme);
		
		return objMap;
	}
	@Override
	public List<Departments> listDepartmentsTree(String departmentId,  Boolean makeVirtual) throws Exception {
		return listDepartmentsTree(null, departmentId, makeVirtual);
	}
	private List<Departments> listDepartmentsTree(Map<String, Users> usersMap, String departmentId,  Boolean makeVirtual) throws Exception {
		List<Departments> depts = listDepartments(usersMap, makeVirtual);
		List<Departments> deptsClone = new ArrayList<Departments>(depts);

		Map<String, Departments> deptMap = new LinkedHashMap<String, Departments>();
		String rootDepartmentId = null;
		for (Departments dept : depts) {
			if (Boolean.TRUE.equals(dept.getRootNode())) { rootDepartmentId = dept.getDepartmentId(); }
			if (!deptMap.containsKey(dept.getDepartmentId())) {
				deptMap.put(dept.getDepartmentId(), dept);
			}
		}
		for (Departments dept : depts) {
			if (StringUtils.isNotBlank(dept.getParentId()) && deptMap.get(dept.getParentId()) != null) {
				deptMap.get(dept.getParentId()).appendChildren(dept);
			}
		}
		
		Departments rootDepartments = null;
		if (StringUtils.isNotBlank(departmentId)) {
			rootDepartments = deptMap.get(departmentId);
		} else {
			rootDepartments = deptMap.get(rootDepartmentId);
		}
		Set<String> availDepartmentIds = new HashSet<String>();
		setDepth(rootDepartments, availDepartmentIds);
		
		List<Departments> results = new ArrayList<Departments>();
		for (Departments dept : deptsClone) {
			if (availDepartmentIds.contains(dept.getDepartmentId())) {
				dept.setDepth(deptMap.get(dept.getDepartmentId()).getDepth());
				results.add(dept);
			}
		}
		return results;
		//return results;
//		for (Departments dept : depts) {
//			if (StringUtils.isNotBlank(dept.getParentId())) {
//				deptMap.remove(dept.getDepartmentId());
//			}
//		}
//		return new ArrayList<Departments>(deptMap.values());
	}
	@Override
	public Departments getDepartmentsTree(String departmentId, Boolean makeVirtual) throws Exception {
		List<Departments> depts = listDepartments(makeVirtual);
		
		Map<String, Departments> deptMap = new LinkedHashMap<String, Departments>();
		String rootDepartmentId = null;
		for (Departments dept : depts) {
			if (Boolean.TRUE.equals(dept.getRootNode())) { rootDepartmentId = dept.getDepartmentId(); }
			deptMap.put(dept.getDepartmentId(), dept);
		}
		for (Departments dept : depts) {
			if (StringUtils.isNotBlank(dept.getParentId()) && deptMap.get(dept.getParentId()) != null) {
				deptMap.get(dept.getParentId()).appendChildren(dept);
			}
		}
		
		Departments rootDepartments = null;
		if (StringUtils.isNotBlank(departmentId)) {
			rootDepartments = deptMap.get(departmentId);
		} else {
			rootDepartments = deptMap.get(rootDepartmentId);
		}
		
		setDepth(rootDepartments, null);
		
		return rootDepartments;
//		for (Departments dept : depts) {
//			if (StringUtils.isNotBlank(dept.getParentId())) {
//				deptMap.remove(dept.getDepartmentId());
//			}
//		}
//		return new ArrayList<Departments>(deptMap.values());
	}
	
	private void setDepth(Departments dept, Set<String> availDepartmentIds) {
		if (availDepartmentIds != null && dept != null) { availDepartmentIds.add(dept.getDepartmentId()); }
		if (dept == null || dept.getChildren() == null || dept.getChildren().size() == 0) { return; }
		for (Departments child : dept.getChildren()) {
			child.setDepth(dept.getDepth()+1);
			setDepth(child, availDepartmentIds);
		}
	}
	
	@Override
	public List<Departments> listDepartments(Boolean makeVirtual) throws Exception {
		return listDepartments(null, makeVirtual);
	}
	private List<Departments> listDepartments(Map<String, Users> usersMap, Boolean makeVirtual) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Departments> dsQuery = new DsQuery<>(Departments.class)
				.eq(FLD.deleteYN, N)
				.sort(FLD.ordernum, SortDirection.ASC)
				.sort(FLD.created, SortDirection.ASC);
			
			List<Departments> departments = dsQuery.execute(mgr);
			if (usersMap == null) { usersMap = getUsersMap(mgr); }
			Set<String> assignedMembers = new HashSet<String>();
			for (Departments department : departments) {
				Users member = null;
				if (StringUtils.isNotBlank(department.getMemberId())) { member = usersMap.get(department.getMemberId()); }
				if (member != null) {
					department.setMember(member);
					assignedMembers.add(department.getMemberId());
				}
			}
			
//			for(String memberId : assignedMembers) {
//				membersMap.remove(memberId);
//			}
			if (Boolean.TRUE.equals(makeVirtual)) {
				if (usersMap.size() != assignedMembers.size()) {
					String rootId = validRootId(departments);
					departments.add(makeVirtualDepartment(rootId));
					for (Map.Entry<String, Users> entry : usersMap.entrySet()) {	// for ETC
						if (!assignedMembers.contains(entry.getKey())) {
							Departments etcDepartments = makeVirtualUserDepartment(entry.getValue());	// for ETC
							departments.add(etcDepartments);	// for ETC
						}
					}
				}
			}
			return departments;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private List<Departments> listChildDepartments(String parentId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Departments> dsQuery = new DsQuery<>(Departments.class)
				.eq(FLD.parentId, parentId)
				.eq(FLD.deleteYN, N);
			
			List<Departments> departments = dsQuery.execute(mgr);
			Map<String, Users> membersMap = getUsersMap(mgr);

			for (Departments department : departments) {
				department.setMember(membersMap.get(department.getMemberId()));
			}
			return departments;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	private Departments getRoot() throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			return getRoot(mgr);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
	private Departments getRoot(EntityManager mgr) throws Exception {
		DsQuery<Departments> dsQuery = new DsQuery<>(Departments.class).eq(FLD.rootNode, true);
		return dsQuery.single(mgr);
	}
	
	@Override
	public Departments getDepartment(String departmentId) {
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, Departments.class, departmentId);
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Departments saveDepartment(Departments department) throws Exception {
		return insertOrUpdateDepartment(department);
//		if (StringUtils.isBlank(department.getDepartmentId())) {
//			return insertDepartment(department);
//		} else {
//			return updateDepartment(department);
//		}
	}
	private Departments insertOrUpdateDepartment(Departments department) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			if (loginUser != null) { department.setCreator(loginUser.getUserId()); }
			
			beginTransaction(mgr);
			department = insertOrUpdateDepartment(mgr, department);
			commitTransaction(mgr);
			
			return department;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private Departments insertOrUpdateDepartment(EntityManager mgr, Departments department) throws Exception {
		try {
			String departmentId = department.getDepartmentId();
			
			if (StringUtils.isBlank(department.getParentId())) {
				Departments root = getRoot(mgr);
				if (root == null) {
					department.setRootNode(true);
				} else if (!StringUtils.equals(departmentId, root.getDepartmentId())) {
					throw new UnavailableException("Root node already exists!!!");
				}
			}
			
			if (StringUtils.isBlank(departmentId)) {
				if (StringUtils.isBlank(department.getDeptCode())) {
					departmentId = KeyUtil.createDepartmentKeyString();
				} else {
					departmentId = KeyUtil.createDepartmentKeyString(department.getDeptCode());
				}
			}
			department.setDepartmentId(departmentId);
			
			if (contains(mgr, Departments.class, departmentId)) {
				doMerge(mgr, department);
			} else {
				doPersist(mgr, department);
			}
			
			if (StringUtils.isNotBlank(department.getMemberId())) {
				Users member = userService.getUsers(mgr, department.getMemberId(), true);
				department.setMember(member);
			}
			
			return department;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<Departments> bulkInsertDepartments(List<Departments> departments) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			doPersistTransaction(mgr, departments);
			return departments;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Departments> parseDepartments(String jsonString) throws Exception {
		List<Departments> departments = new ArrayList<Departments>();
		
		ObjectMapper mapper = new ObjectMapper();
		JsonType jsonType = JSONUtil.getJsonType(jsonString);
		if (JsonType.ARRAY.equals(jsonType)) {
			List<Dept> list = mapper.readValue(jsonString, new TypeReference<List<Dept>>(){});
			if (list != null) {
				departments = Dept.convertToDepartments(list);
			}
		} else if (JsonType.OBJECT.equals(jsonType)) {
			Map<String, List<Dept>> map = mapper.readValue(jsonString, new TypeReference<Map<String, List<Dept>>>(){});
			if (map != null) {
				departments = Dept.convertToDepartments(map.entrySet().iterator().next().getValue());
			}
		}
		if (departments == null || departments.size() == 0) {
			throw new JsonParseException("Can't parse json string.");
		}
		return departments;
	}
	
	@Override
	public List<Departments> applyDepartmentsFromJSON(String domainName, String jsonString) throws Exception {
		List<Departments> departments = parseDepartments(jsonString);
		return applyDepartments(domainName, departments);
	}
	@Override
	public List<Departments> applyDepartments(String domainName, List<Departments> departments) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			assignKeysForDomain(departments);
			String rootId = validRootId(departments);

			if (StringUtils.isBlank(rootId)) {
				throw new IllegalArgumentException("Please check parentKey/childKey pairs.");
			}
			setDepartmentsRoot(rootId, departments);
			
			removeAllDepartments();
			return bulkInsertDepartments(departments);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	private void assignKeysForDomain(List<Departments> departments) {
		Set<String> verifyDupChecks = new HashSet<String>();
		for (Departments dept : departments) {
			final String deptCode = dept.getDeptCode();
			if (verifyDupChecks.contains(deptCode)) { throw new IllegalArgumentException("Duplicate deptCode was discovered.("+deptCode+")"); }
			verifyDupChecks.add(deptCode);
			
			if (StringUtils.isNotBlank(dept.getParentDeptCode())){
				dept.setParentId(KeyUtil.createDepartmentKeyString(dept.getParentDeptCode()));
			}
			dept.setDepartmentId(KeyUtil.createDepartmentKeyString(deptCode));
			if (dept.getMember() != null) {
				String id = dept.getMember().getId();
				String memberId = null;
				if (StringUtils.isNotBlank(id)) {
					memberId = KeyUtil.createUserKeyString(id);
				}
				dept.getMember().setUserId(memberId);
				dept.setMemberId(memberId);
			}
		}
	}
	private void setDepartmentsRoot(String rootId, List<Departments> departments) {
		for (Departments dept : departments) {
			if (StringUtils.equals(rootId, dept.getDepartmentId())) {
				dept.setRootNode(true);
				break;
			}
		}
	}
	
	@SuppressWarnings("unused")
	private Departments updateDepartment(Departments department) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Departments originDepartment = doFind(mgr, Departments.class, department.getDepartmentId());
			valid(originDepartment);
			originDepartment.setMemberId(department.getMemberId());
			originDepartment.setTitle(department.getTitle());
			originDepartment.setDescription(department.getDescription());
			originDepartment.setContact(department.getContact());
			originDepartment.setOrdernum(department.getOrdernum());

			return doMergeTransaction(mgr, originDepartment);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public void removeDepartment(String departmentId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Departments department = doFind(mgr, Departments.class, departmentId);
			List<Departments> children = listChildDepartments(department.getDepartmentId());
			
			if (Boolean.TRUE.equals(department.getRootNode()) && children.size() > 0) {
				throw new ServiceUnavailableException("Can't remove root object.(Exist child nodes)");
			}
			
			for (Departments child :  children) {
				child.setParentId(department.getParentId());
				doMergeTransaction(mgr, child);
			}
			
			doRemoveTransaction(mgr, department);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void moveDepartment(String departmentId, String parentId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Departments department = doFind(mgr, Departments.class, departmentId);
			if (Boolean.TRUE.equals(department.getRootNode())) {
				throw new ServiceUnavailableException("Can't move root object.");
			}
			department.setParentId(parentId);
			doMergeTransaction(mgr, department);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public int removeAllDepartments() throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			DsQuery<Departments> dsQuery = new DsQuery<>(Departments.class);
			List<Departments> results = dsQuery.execute(mgr);
			doRemoveTransaction(mgr, results);
			return results.size();
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private Map<String, Users> getUsersMap(Users loginUser, List<Users> users) throws Exception {
		Map<String, Users> usersMap = new LinkedHashMap<String, Users>();
		
		for (Users user : users) {
			if (loginUser.isManager() || user.isActive()) {
				usersMap.put(user.getUserId(), user);
			}
		}
		return usersMap;
	}
	private Map<String, Users> getUsersMap(EntityManager mgr) throws Exception {
		Map<String, Users> usersMap = new LinkedHashMap<String, Users>();
		Users loginUser = getCurrentUser();
		Boolean active = null;
		if (!loginUser.isManager()) {
			active = true;
		}
		List<Users> users = userService.listUsers(mgr, active, true);
	
		for (Users user : users) {
			usersMap.put(user.getUserId(), user);
		}
		return usersMap;
	}
	private Departments makeVirtualDepartment(String rootId) throws Exception {
		Departments department = new Departments();
		
		department.setParentId(rootId);
		department.setDepartmentId(KeyUtil.createDepartmentKeyString(ETC_KEY_NAME));
		department.setTitle("ETC(Unassigned members)");
		department.setDescription(new Text("어느부서에도 할당되지 않은 사람들(가상의조직임으로 이동이나 할당금지)"));
		
		return department;
	}
	private Departments makeVirtualUserDepartment(Users user) throws Exception {
		Departments department = new Departments();
		department.setParentId(KeyUtil.createDepartmentKeyString(ETC_KEY_NAME));
		department.setDepartmentId(KeyUtil.createDepartmentKeyString());
		department.setMemberId(user.getUserId());
		department.setMember(user);
		
		return department;
	}
	
	private static String findRoot(String key, Map<String, String> childParentMap, List<String> findPaths) throws IllegalArgumentException {
		String parentKey = childParentMap.get(key);
		findPaths.add(key);
		if (StringUtils.isBlank(parentKey) ||
				StringUtils.equalsIgnoreCase("root", parentKey)) {
			return key;
		} else {
			if (findPaths.contains(parentKey)) {
				throw new IllegalArgumentException("Infinite recursion error!");
			}
			return findRoot(parentKey, childParentMap, findPaths);
		}
	}
	
	private static String validAndFindRoot(Map<String, String> childParentMap) throws IllegalArgumentException {
		Set<String> roots = new HashSet<String>();
		
		Iterator<String> iter = childParentMap.keySet().iterator();
		while (iter.hasNext()) {
			List<String> findPath = new ArrayList<String>();
			
			String key = iter.next();
			String rootKey = findRoot(key, childParentMap, findPath);
			roots.add(rootKey);
			//System.out.println("KEY : "+ key +"/ROOT :" + rootKey);	
		}
		if (roots.size() != 1) {
			throw new IllegalArgumentException("Illegal root key.(please check parentKey:childKey pairs)");
		}
		return roots.iterator().next();
	}
}
