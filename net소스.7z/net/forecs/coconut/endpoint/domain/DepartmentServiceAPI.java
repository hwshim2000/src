package net.forecs.coconut.endpoint.domain;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.domain.Departments;
import net.forecs.coconut.shiro.annotation.RequiresToken;
import net.forecs.coconut.user.Role;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.config.DefaultValue;

@Api(name = API.DOMAIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.DOMAIN_SERVICE_PACKAGE), description = "CoCoNut 최상위 Domain API 목록", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class DepartmentServiceAPI {
	private final IDepartmentService departmentService;

	@Inject
	public DepartmentServiceAPI(IDepartmentService departmentService) {
		this.departmentService = departmentService;
	}
	
	@ApiMethod(name = "loadAllDepartmentObjects", path = "domains/departments/objects", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<String, Object> loadAllDepartmentObjects(@Nullable @Named(FLD.departmentId) String departmentId) throws Exception {
		System.out.println(departmentId);
		return departmentService.loadAllDepartmentObjects(departmentId);
	}
	
	@ApiMethod(name = "getDepartmentsTree", path = "domains/departments/tree", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Departments getDepartmentsTree(@Nullable @Named(FLD.departmentId) String departmentId, @DefaultValue("true") @Named(FLD.makeVirtual) Boolean makeVirtual) throws Exception {
		CommonService.validNamespace(departmentId);
		return departmentService.getDepartmentsTree(departmentId, makeVirtual);
	}
	
	@ApiMethod(name = "listDepartments", path = "domains/departments", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<Departments> listDepartments(@Named(FLD.domainId) String domainId, @DefaultValue("true") @Named(FLD.makeVirtual) Boolean makeVirtual) throws Exception {
		CommonService.validNamespace(domainId);
		return departmentService.listDepartments(makeVirtual);
	}
	
	@ApiMethod(name = "listDepartmentsTree", path = "domains/departments/listTree", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<Departments> listDepartmentsTree(@Nullable @Named(FLD.departmentId) String departmentId,
			@DefaultValue("true") @Named(FLD.makeVirtual) Boolean makeVirtual) throws Exception {
		if (StringUtils.isNotBlank(departmentId)) { CommonService.validNamespace(departmentId); }
		return departmentService.listDepartmentsTree(departmentId, makeVirtual);
	}
	
	@ApiMethod(name = "getDepartment", path = "domains/departments/{departmentId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Departments getDepartment(@Named(FLD.departmentId) String departmentId) throws Exception {
		CommonService.validNamespace(departmentId);
		return departmentService.getDepartment(departmentId);
	}
	
	@ApiMethod(name = "saveDepartment", path = "domains/departments", httpMethod = HttpMethod.POST)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public Departments saveDepartment(Departments department) throws Exception {
		CommonService.validNamespace(department.getDomainId());
		return departmentService.saveDepartment(department);
	}
	
	@ApiMethod(name = "removeDepartment", path = "domains/departments/{departmentId}", httpMethod = HttpMethod.DELETE)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public void removeDepartment(@Named(FLD.departmentId) String departmentId) throws Exception {
		CommonService.validNamespace(departmentId);
		departmentService.removeDepartment(departmentId);
	}
	
	@ApiMethod(name = "moveDepartment", path = "domains/departments/move", httpMethod = HttpMethod.PUT)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public void moveDepartment(@Named(FLD.departmentId) String departmentId, @Named(FLD.parentId) String parentId) throws Exception {
		CommonService.validNamespace(departmentId);
		departmentService.moveDepartment(departmentId, parentId);
	}
	
	@ApiMethod(name = "requestDepartmentAccessKey", path = "domains/departments/accessKey/{userId}", httpMethod = HttpMethod.GET)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public Result requestDepartmentAccessKey(@Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(userId);
		return new Result(MemcacheManager.createAccessKey(userId));
	}
	
	@ApiMethod(name = "applyDepartmentsFromJSON", path = "domains/departments/apply/json", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.DOMAIN, accessToken = "{accessToken}" )
	public List<Departments> applyDepartmentsFromJSON(@Named(FLD.domainName) String domainName,
			@Named(FLD.jsonString) String jsonString,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		CommonService.validNamespaceName(domainName);
		return departmentService.applyDepartmentsFromJSON(domainName, jsonString);
	}
}
