package net.forecs.coconut.endpoint.domain;

import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.admin.IAdminService;
import net.forecs.coconut.endpoint.admin.ICouponService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.billing.Coupons;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.user.Permission;
import net.forecs.coconut.user.Role;

import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.appengine.api.NamespaceManager;


@Api(name = API.DOMAIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.DOMAIN_SERVICE_PACKAGE), description = "CoCoNut 최상위 Domain API 목록", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class DomainServiceAPI {
	//private static final Logger LOG = Logger.getLogger(DomainServiceAPI.class.getName());

	private final IDomainService domainService;
//	private final INoticeService noticeService;
	private final ICouponService couponService;
	private final IAdminService adminService;
	
	@Inject
	public DomainServiceAPI(
			IDomainService domainService,
			//INoticeService noticeService,
			ICouponService couponService,
			IAdminService adminService) {
		this.domainService = domainService;
//		this.noticeService = noticeService;
		this.couponService = couponService;
		this.adminService = adminService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "assignMember", path = "domains/assign", httpMethod = HttpMethod.POST)
	@RequiresUser
	@RequiresPermissions(Permission.DOMAIN_ASSIGN_MEMBER)
	public Users assignMember(
			@Named(FLD.domainId) String domainId,
			//Users user,
			@Named(FLD.id) String id,
			@Named(FLD.password) String password,
			@Named(FLD.email) String email,
			@Nullable @Named(FLD.nickName) String nickName,
			@Named(FLD.userName) String userName) throws Exception {
		CommonService.validNamespace(domainId);
		Users user = new Users();
		
		user.setId(id);
		user.setPassword(password);
		user.setEmail(email);
		user.setNickName(nickName);
		user.setUserName(userName);
		
		return domainService.assignMember(domainId, user);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "unassignMember", path = "domains/unassign/{userId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	@RequiresPermissions(Permission.DOMAIN_UNASSIGN_MEMBER)
	public void unassignMember(@Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(userId);
		domainService.unassignMember(userId);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "unassignMemberList", path = "domains/unassign", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	@RequiresPermissions(Permission.DOMAIN_UNASSIGN_MEMBER)
//	public List<Users> unassignMemberList(@Named(FLD.userIdList) List<String> userIdList) throws Exception {
//		CommonService.validNamespace(userIdList.get(0));
//		return domainService.unassignMemberList(userIdList);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "reassignMember", path = "domains/reassign/{userId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	@RequiresPermissions(Permission.DOMAIN_ASSIGN_MEMBER)
	public Users reassignMember(@Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(userId);
		return domainService.reassignMember(userId);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "reassignMemberList", path = "domains/reassign", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	@RequiresPermissions(Permission.DOMAIN_ASSIGN_MEMBER)
//	public List<Users> reassignMemberList(@Named(FLD.userIdList) List<String> userIdList) throws Exception {
//		CommonService.validNamespace(userIdList.get(0));
//		return domainService.reassignMemberList(userIdList);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "checkDuplicationDomainName", path = "domains/checkDuplication/{domainName}", httpMethod = HttpMethod.GET)
//	public Result checkDuplicationDomainName(@Named(FLD.domainName) String domainName) {
//		return new Result(domainService.checkDuplicationDomainName(domainName));
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "createDomains", path = "domains", httpMethod = HttpMethod.POST)
	public Domains createDomains(Domains domain, @Named(FLD.email) String email) throws Exception {
		return domainService.createDomains(domain, email);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "updateDomains", path = "domains", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	@RequiresPermissions(Permission.DOMAIN_WRITE)
//	public Domains updateDomains(Domains domain) throws Exception {
//		CommonService.validNamespace(domain);
//		return domainService.updateDomains(domain);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "checkDuplicationNickName", path = "domains/checkNickName/{nickName}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Result checkDuplicationNickName(@Named(FLD.nickName) String nickName) throws Exception {
//		return new Result(userService.checkDuplicationNickName(nickName));
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "cancelCreateDomain", path = "domains/{domainName}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void cancelCreateDomain(@Named(FLD.domainName) String domainName) throws Exception {
//		CommonService.validNamespaceName(domainName);
//		domainService.removeAllDomainData(domainName);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getDomainInfo", path = "domains/{domainName}/info", httpMethod = HttpMethod.GET)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
	public Map<String, Object> getDomainInfo(@Named(FLD.domainName) String domainName) throws Exception {
		CommonService.validNamespaceName(domainName);
		return adminService.getDomainInfo(domainName);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "countBoardMemberAuths", path = "domains/countBoardMembers/{userId}", httpMethod = HttpMethod.GET)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
//	public Result countBoardMemberAuths(@Named(FLD.userId) String userId) throws Exception{
//		CommonService.validNamespace(userId);
//		long count = domainService.countBoardMemberAuths(userId);
//		
//		return new Result(count);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "permanentRemoveUsers", path = "domains/users/{userId}", httpMethod = HttpMethod.DELETE)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
	public void permanentRemoveUsers(@Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(userId);
		domainService.permanentRemoveUsers(userId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "isAssignedBoards", path = "domains/isAssignedBoards/{userId}", httpMethod = HttpMethod.GET)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
	public Result isAssignedBoards(@Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(userId);
		return new Result(domainService.isAssignedBoards(userId));
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "queryDomainNotice", path = "domains/notice", httpMethod = HttpMethod.GET)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
//	public CollectionResponse<Notice> queryDomainNotice(
//			@Named(FLD.domainId) String domainId,
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit) throws Exception {
//		CommonService.validNamespace(domainId);
//		
//		List<String> kindIdList = new ArrayList<String>();
//		kindIdList.add(NoticeService.KINDID_DOMAIN_NOTICE);
//		kindIdList.add(NoticeService.KINDID_SYSTEM_NOTICE);
//		QueryResult<Notice> queryResult = noticeService.queryNotice(cursorString, limit, kindIdList);
//		List<Notice> list = queryResult.getResultList();
//		
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<Notice> builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "insertDomainNotice", path = "domains/notice", httpMethod = HttpMethod.POST)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
//	public Notice insertDomainNotice(Notice notice) throws Exception {
//		CommonService.validNamespace(notice.getDomainId());
//		return noticeService.insertDomainNotice(notice);
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "updateDomainNotice", path = "domains/notice", httpMethod = HttpMethod.PUT)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
//	public Notice updateDomainNotice(Notice notice) throws Exception {
//		CommonService.validNamespace(notice.getDomainId());
//		return noticeService.updateDomainNotice(notice);
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "removeDomainNotice", path = "domains/notice/{noticeId}", httpMethod = HttpMethod.DELETE)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
//	public void removeDomainNotice(@Named(FLD.noticeId) String noticeId) throws Exception {
//		CommonService.validNamespace(noticeId);
//		noticeService.removeDomainNotice(noticeId);
//	}
	
	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "validCoupon", path = "domains/coupon/valid/{couponCode}", httpMethod = HttpMethod.GET)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
//	public Result validCoupon(@Named(FLD.couponCode) String couponCode) throws Exception {
//		return new Result(couponService.isValidCoupon(couponCode));
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "registCoupon",  path = "domains/coupon/regist/{couponCode}", httpMethod = HttpMethod.POST)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
	public Coupons registCoupon(
			@Named(FLD.domainId) String domainId,
			@Named(FLD.couponCode) String couponCode) throws Exception {
		CommonService.validNamespace(domainId);
		String domainName = NamespaceManager.get();
		return couponService.registCoupon(domainName, couponCode);
	}
	
	@ApiMethod(name = "changeCreateBoardAuth", path = "domains/createBoardAuth", httpMethod = HttpMethod.PUT)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public Domains changeCreateBoardAuth(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.createBoardAuth) Auth createBoardAuth) throws Exception {
		CommonService.validNamespaceName(domainName);
		return adminService.changeCreateBoardAuth(domainName, createBoardAuth, false, true);
	}
}
