package net.forecs.coconut.endpoint.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.AuthKind;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.UserType;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IMemberAuthService;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.setting.INotificationSettingService;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.user.Role;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.UnauthorizedException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.common.base.Preconditions;


public class DomainService extends CommonService implements IDomainService {
	private static final Logger LOG = Logger.getLogger(DomainService.class.getName());
	private static final String DEFAULT_GROUP_NAME = "Base Group";
	
	private final IGroupService groupService;
	private final IMemberAuthService memberAuthService;
	private final IUserService userService;
	private final INotificationSettingService notificationSettingService;
	private final IActivityService activityService;
//	private final IDataService dataService;

	@Inject
	public DomainService(
			IGroupService groupService,
			IMemberAuthService memberAuthService, IUserService userService,
			INotificationSettingService notificationSettingService,
			IActivityService activityService
//			IDataService dataService
			) {
		this.groupService = groupService;
		this.memberAuthService = memberAuthService;
		this.userService = userService;
		this.notificationSettingService = notificationSettingService;
		this.activityService = activityService;
//		this.dataService = dataService;
	}

	

	@Override
	public Users assignMember(String domainId, Users user) throws Exception {
		Users loginUser = getCurrentUser();
		return assignMember(domainId, user, loginUser.getUserId());
	}
	private Users assignMember(String domainId, Users user, String loginUserId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, domainId);
			valid(domain);

			String password = user.getPassword();
			
			user.setDomainName(domain.getDomainName());
			user.setRole(Role.MEMBER);
			user.setUserType(UserType.DOMAIN);
			user.setForcePasswordChangeYN(Y);
			user.setConfirmYN(Y);
			user.setCreator(loginUserId);
			user.setActive(true);
			
			// 만일 사용자가 등록한 password가 없으면 random password를 생성해서 보낸다.
			if (StringUtils.isBlank(password)) {
				password = KeyUtil.generateRandomPassword();
				user.setPassword(password);
			}
			
			beginTransaction(mgr);
			user = userService.assignUsers(mgr, user, true);
			
			try {
				notificationSettingService.insertNotificationSettings(mgr, new NotificationSettings(user.getUserId(), loginUserId));
			} catch (Exception ex) {
				LOG.warning("[assignMember] " + ex.getMessage());
			}
			commitTransaction(mgr);

			try {
				// Do not user user.getPassword(). (why? user object에 포함된 password는 Hashing된 값이므로)
				userService.sendRandomPassword(user, password); 
				// 기획 내용을 다시 검토한 후 random password를 이메일로 보낼지, 또는 비밀번호를 변경할 수 있는 코드를 이메일로 발송하는 방식으로 사용할지에 따라서 결정.  
				//userService.requestRegCode(domain.getDomainName(), user.getId(), user.getUserName(), user.getEmail(), true);
			} catch (Exception ex) {
				throw ex;
			}
			
			return user;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Users assignAdmin(EntityManager mgr, String domainName, String id, String password, String email, String userName, String nickName) throws Exception {
		byte[] salt = null;
		if (StringUtils.isNotBlank(password)) {
			Preconditions.checkNotNull(password);
	        salt = ShiroUtils.salt().getBytes();
	        password = ShiroUtils.hash(password, salt);
		}
		beginTransaction(mgr);
		Users admin = assignAdmin(mgr, domainName, id, password, salt, email, userName, nickName);
		commitTransaction(mgr);
		
		return admin;
	}
	private Users assignAdmin(EntityManager mgr, String domainName, String id, String password, byte[] salt, String email, String userName, String nickName) throws Exception {
		try {
			if (StringUtils.isBlank(id)) { id = String.format(CommonProperty.ADMINID_FORMAT, domainName); }
//			if (StringUtils.isBlank(password)) { password = id; }
			if (StringUtils.isBlank(userName)) { userName = CommonProperty.ADMIN_USERNAME; }
			if (StringUtils.isBlank(nickName)) { nickName = CommonProperty.ADMIN_NICKNAME; }
			
			Users user = new Users();
		
			String adminUserId = KeyUtil.createUserKeyString(id); 
			user.setId(id);
			user.setEmail(email);
			user.setUserName(userName);
			user.setNickName(nickName);
			user.setDomainName(domainName);
			user.setPassword(password);
			user.setSalt(salt);
			user.setRole(Role.ADMIN);
			user.setUserType(UserType.DOMAIN);
			user.setForcePasswordChangeYN(Y);
			user.setConfirmYN(Y);
			user.setCreator(adminUserId);
			user.setActive(true);
			// 만일 사용자가 등록한 password가 없으면 random password를 생성해서 보낸다.
			boolean isRandomPassword = false;
			if (StringUtils.isBlank(password)) {
				password = KeyUtil.generateRandomPassword();
				user.setPasswordHash(password);
				isRandomPassword = true;
			}
			
			user = userService.assignUsers(mgr, user, false);
			try {
				notificationSettingService.insertNotificationSettings(mgr, new NotificationSettings(user.getUserId(), adminUserId));
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}

			try {
				// Do not user user.getPassword(). (why? user object에 포함된 password는 Hashing된 값이므로)
				if (isRandomPassword) {
					userService.sendRandomPassword(user, password);
				}
				// 기획 내용을 다시 검토한 후 random password를 이메일로 보낼지, 또는 비밀번호를 변경할 수 있는 코드를 이메일로 발송하는 방식으로 사용할지에 따라서 결정.  
				//userService.requestRegCode(domain.getDomainName(), user.getId(), user.getUserName(), user.getEmail(), true);
			} catch (Exception ex) {
				throw ex;
			}
			
			return user;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Users reassignMember(String userId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users user = userService.getUsers(mgr, userId, false);
			 
			user.setActive(true);
			user.setDeleteYN(N);
			
			userService.reassignUsers(mgr, user);
			memberAuthService.reassignAllMemberAuth(userId, AuthKind.BOARDS);
			
			return user;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void unassignMember(String userId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users user = userService.getUsers(mgr, userId, false);
			
			if (user.isAdmin()) {
				throw new UnauthorizedException(ErrorCode.ADMIN_UNASSIGN_UNAVAILABLE.getMessage("Can't unassign admin user."));
			}

			user.setActive(false);
			userService.unassignUsers(mgr, user);
			memberAuthService.unassignAllMemberAuth(userId, AuthKind.BOARDS);
			
			//return user;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Users assignOrOverwriteMember(Domains domain, Users user, boolean isOverwrite, String loginUserId) throws Exception {
		Users assignedUser = null;
		String domainName = domain.getDomainName();
		Users originUser = null;
		
		if (!domain.isCaseInsensitive()) {
			originUser = userService.findUsers(user);
		} else {
			originUser = userService.findByLowerId(domainName, user.getId().toLowerCase());
		}
		
		Users emailUser = userService.findByEmail(domainName, user.getEmail());
		//Users nickNameUser = userService.findByNickName(user.getNickName());
		
		if (originUser == null) {
			if (emailUser == null || (!ServiceType.GSUITE.equals(domain.getServiceType()) && emailUser.isAdmin())) {
			//if (emailUser == null && nickNameUser == null) {
				assignedUser = assignMember(domain.getDomainId(), user, loginUserId);
			} else {
				LOG.log(Level.WARNING, "User email already exists");
			}
		} else if (isOverwrite){
			boolean isValidEmail = true;
			// boolean isValidNickname = true;
			
			if (emailUser != null && !emailUser.getUserId().equals(originUser.getUserId())) {
				isValidEmail = false;
			}
			//if (nickNameUser != null && !nickNameUser.getUserId().equals(originUser.getUserId())) {
			//	isValidNickname = false;
			//}
			
			//if (isValidEmail && isValidNickname) {
			if (isValidEmail) {
				originUser.setEmail(user.getEmail());
				originUser.setUserName(user.getUserName());
				originUser.setNickName(user.getNickName());
				assignedUser = userService.updateUsers(originUser);
			} else {
				LOG.log(Level.WARNING, "User already exists");
			}
		} else {
			LOG.log(Level.WARNING, "User already exists");
		}
		
		return assignedUser;
	}
	
	@Override
	public List<Users> assignOrOverwriteMemberList(Domains domain, List<Users> userList, boolean isOverwrite, String loginUserId) throws Exception {
		List<Users> resultList = new ArrayList<Users>();
		
		try {
			for (Users user : userList) {
				Users assignedUser = assignOrOverwriteMember(domain, user, isOverwrite, loginUserId);
				if (assignedUser != null) { resultList.add(user); }
			}
		} catch (Exception ex) {}
		
		return resultList;
	}
	
	@Override
	public Domains createDomains(Domains domain, String email) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);		// Access public namespace to create domain

		EntityManager mgr = getEntityManager();
		//Boards defaultBoard = null;
		try {
			// Domain 기본 정보 입력
			String domainName = domain.getDomainName();
			domain.setTitle(domainName);

			setDomainQuota(domain);
			
			beginTransaction(mgr);
			
			domain = insertDomains(mgr, domain);

			// Access domain's private namespace to create default group and board
			NamespaceManager.set(domain.getDomainName());

			String adminId = null;
			if (ServiceType.GSUITE.equals(domain.getServiceType())) {
				adminId = email;
			}
			// TODO : GSuite 사용자일 경우에 비밀번호를 랜덤 또는 지정생성할 것인지 결정
			// TODO : 임시 비밀번호 발생시 이메일로 발송하지 않도록 변경
			Users admin = assignAdmin(mgr, domain.getDomainName(), adminId, null, null, email, null, null);

			// Apply Namespace : Dummy domain for code compatibility
			Domains domainInfo = new Domains(domain);
			domainInfo.setCreator(admin.getUserId());
			domainInfo.setOwner(admin.getUserId());
			
			domain = insertDomains(mgr, domainInfo);

			// Default Group 생성
			Groups defaultGroup = new Groups();

			defaultGroup.setKey(KeyUtil.createDefaultGroupKey(domain));
			defaultGroup.setTitle(DEFAULT_GROUP_NAME);
			defaultGroup.setDomainId(domain.getDomainId());
			defaultGroup.setCreator(admin.getUserId());
			defaultGroup.setOwner(admin.getUserId());
			defaultGroup.setDefaultYN(Y);
			defaultGroup.setCreated(new Date());
			defaultGroup = groupService.insertGroups(mgr, defaultGroup);
			
			commitTransaction(mgr);
			
			return domain;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private void setDomainQuota(Domains domain) {
		if (ServiceType.GSUITE.equals(domain.getServiceType())) {
			domain.setBlockType(BlockType.PASS);
			domain.setServiceType(ServiceType.GSUITE);
			domain.setUserQuota(null);
			domain.setStorageQuota(null);
			domain.setBoardQuota(null);
			domain.setExpirationDate(null);
		} else {
			domain.setBlockType(BlockType.AUTO);
			domain.setServiceType(CommonProperty.DEFAULT_SERVICE_TYPE);
			domain.setUserQuota(CommonProperty.DEFAULT_USER_QUOTA);
			domain.setStorageQuota(CommonProperty.TRIAL_STORAGE_QUOTA);
	//		domain.setStorageQuota(CommonProperty.DEFAULT_STORAGE_QUOTA);
			domain.setBoardQuota(CommonProperty.DEFAULT_BOARD_QUOTA);
			domain.setExpirationDate(null);
		}
	}

	@Override
	public Domains getDomains(String domainId) {
		EntityManager mgr = getEntityManager();

		try {
			return getDomains(mgr, domainId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public Domains getDomains(EntityManager mgr, String domainId) {
		return doFind(mgr, Domains.class, domainId);
	}
	
	@Override
	public Domains findByDomainName(String domainName) {		
		if (StringUtils.isEmpty(domainName)) {
			return null;
		}

		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);					// Access public namespace to find domain

		EntityManager mgr = getEntityManager();
	
		try {
			return doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
		} catch (Exception e) {
			return null;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	private Domains insertDomains(EntityManager mgr, Domains domain) throws Exception {
		try {
			Key key = KeyUtil.createDomainKey(domain);
			
			if (contains(mgr, Domains.class, key)) {
				String message = ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Domains.class, domain.getDomainName());
				//LOG.info(message);
				throw new ConflictException(message);
			}

			domain.setKey(key);
			domain.setCreated(new Date());

			doMerge(mgr, domain);
			
			return domain;
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public void permanentRemoveUsers(String userId) throws Exception {
		try {
			if (isAssignedBoards(userId)) {
				throw new UnavailableException(ErrorCode.UNAVAILABLE.getMessage("Is an user who have ever allocated for board."));
			}
			userService.permanentRemoveUsers(userId);
			activityService.bulkRemoveActivities(null, null, null, null, userId);
		} catch (Exception ex) {
			throw ex;
		}
	}
	@Override
	public boolean isAssignedBoards(String userId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<MemberAuths> memberAuths = memberAuthService.listMemberAuths(mgr, null, null, null, null, null, userId, false);
			return memberAuths.size() > 0;
		} catch (Exception ex) {
			throw ex; 
		} finally {
			finalizeTransaction(mgr);
		}
	}

//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public boolean checkDuplicationDomainName(String domainName) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(null);		// Access public namespace to create domain
//
//		try {
//			return contains(Domains.class, KeyUtil.createDomainKey(domainName));
//		} finally {
//			NamespaceManager.set(prevNamespace);	// Restore namespace
//		}
//	}
//	@Override
//	public List<Users> reassignMemberList(List<String> userIdList) throws Exception{
//		EntityManager mgr = getEntityManager();
//		try {
//			List<Users> userList = batchListByKey(mgr, Users.class, userIdList);
//			List<Users> reassignUserList = new ArrayList<Users>();
//			List<String> reassignUserIds = new ArrayList<String>();
//			
//			for (Users user : userList) {
//				user.setActive(true);
//				user.setDeleteYN(N);
//				
//				reassignUserList.add(user);
//				reassignUserIds.add(user.getUserId());
//				
//				userService.reassignUsers(mgr, user);
//			}
//			memberAuthService.reassignAllMemberAuth(reassignUserIds, AuthKind.BOARDS);
//			
//			return reassignUserList;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Users assignGuest(String domainId, Users user) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Domains domain = doFind(mgr, Domains.class, domainId);
//			valid(domain);
//
//			user.setDomainName(domain.getDomainName());
//			user.setRole(Role.GUEST);
//			user.setForcePasswordChangeYN(N);
//			user.setConfirmYN(Y);
//			user.setCreator(user.getUserId());
//			user.setUserType(UserType.GUEST);
//			user.setActive(true);
//			
//			Users findUser = userService.getSimpleUsers(mgr, KeyUtil.createUserKeyString(user.getId()));
//			
//			beginTransaction(mgr);
//			// 이미 초대된 회원정보가 없으면 저장
//			if (findUser == null) {
//				user = userService.assignUsers(mgr, user, true);
//			} else if (!isValid(findUser)) {
//				// 이미 삭제처리 되었더라도 재 초대된 경우라면 새로 등록을 해야하므로 기존 정보를 활성시켜야 한다.
//				user.setKey(findUser.getKey());
//				user.setDeleteYN(N);
//				user.setConfirmYN(Y);
//				user.setDeleted(null);
//				user.setActive(true);
//				
//				user = userService.reassignUsers(mgr, user);
//			}
//			
//			try {
//				notificationSettingService.insertNotificationSettings(mgr, new NotificationSettings(user.getUserId(), user.getUserId()));
//			} catch (ConflictException ex) {}
//			
//			commitTransaction(mgr);
//			
//			return user;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Users> unassignMemberList(List<String> userIdList) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			List<Users> userList = batchListByKey(mgr, Users.class, userIdList);
//			List<Users> unassignUserList = new ArrayList<Users>();
//			List<String> unassignUserIds = new ArrayList<String>();
//			
//			for (Users user : userList) {
//				if (!isValid(user) || user.isAdmin()) { continue; }
//				user.setActive(false);
//				
//				unassignUserList.add(user);
//				unassignUserIds.add(user.getUserId());
//				userService.unassignUsers(mgr, user);
//			}
//			memberAuthService.unassignAllMemberAuth(unassignUserIds, AuthKind.BOARDS);
//			
//			return unassignUserList;
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Domains updateDomains(Domains domain) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			beginTransaction(mgr);
//			domain = updateDomains(mgr, domain);
//			commitTransaction(mgr);
//			
//			return domain;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Domains updateDomains(EntityManager mgr, Domains domain) throws Exception {
//		try {
//			valid(domain);
//			doMerge(mgr, domain);
//			return domain;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	@Override
//	public void removeDomains(String domainId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			beginTransaction(mgr);
//			removeDomains(mgr, domainId);
//			commitTransaction(mgr);
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private void removeDomains(EntityManager mgr, String domainId) throws Exception {
//		try {
//			Domains domain = doFind(mgr, Domains.class, domainId);
//			valid(domain);
//			
//			domain.setDeleted(new Date());
//			domain.setDeleteYN(Y);
//		
//			doMerge(mgr, domain);
//		} catch (Exception e) {
//			throw e;
//		}
//	}
//	@Override
//	public Users getDomainOwner (String domainId) {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Domains domain = doFind(mgr, Domains.class, domainId);
//			if (domain != null) {
//				return userService.getSimpleUsers(mgr, domain.getOwner());
//			}
//			
//			return null;
//		} catch (Exception ex) {
//			return null;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public void removeAllDomainData(String domainName) throws Exception {
//		try {
//			dataService.removeNamespace(domainName);
//		} catch (Exception e) {
//			throw e;
//		}
//	}
//	@Override
//	public long countBoardMemberAuths(String userId) throws Exception {
//		return memberAuthService.countMemberAuths(AuthKind.BOARDS, userId);
//	}
//	@Override
//	public Users assignAdmin(String domainName, String id, String password, String email, String userName, String nickName) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			beginTransaction(mgr);
//			Users user = assignAdmin(mgr, domainName, id, password, email, userName, nickName);
//			commitTransaction(mgr);
//			return user;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Users updateDomainNameForDefaultUser(String domainName, String id) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(null);
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Users user = doFind(mgr, Users.class, KeyUtil.createUserKey(id));
//			
//			if (user != null) {
//				user.setDomainName(domainName);
//				user = doMergeTransaction(mgr, user);
//			}
//			
//			return user;
//		} catch (Exception ex) {
//			ex.printStackTrace();
//			return null;
//		} finally {
//			finalizeTransaction(mgr, prevNamespace);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
