package net.forecs.coconut.endpoint.domain;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.channel.ISyncService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Activities.ActivityData;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.user.Users;

import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.ServiceUnavailableException;
import com.google.appengine.api.datastore.Key;


public class GroupService extends CommonService implements IGroupService {
	private static final Logger LOG = Logger.getLogger(GroupService.class.getName());
	private final IBoardService boardService;
	private final IActivityService activityService;
	private final ISyncService syncService;
	
	@Inject
	public GroupService(IBoardService boardService, IActivityService activityService, ISyncService syncService) {
		this.boardService = boardService;
		this.activityService = activityService;
		this.syncService = syncService;
	}
	
	private Groups getDefaultGroup(String domainId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Key defaultGroupKey = KeyUtil.createDefaultGroupKey(domainId);
			Groups group = doFind(mgr, Groups.class, defaultGroupKey);
			return group;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public List<Groups> listGroups() throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Groups> dsQuery = new DsQuery<>(Groups.class)
				.eq(FLD.deleteYN, N);
			
			List<Groups> groupList = dsQuery.execute(mgr);
			Groups.sort(groupList);
			
			return groupList;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private Groups getGroups(String groupId) {
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, Groups.class, groupId);
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Groups insertGroups(Groups group) throws Exception {
		//UsageService.validUsage(group);
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			group.setKey(KeyUtil.createGroupKey(group));
			group.setCreator(loginUser.getUserId());

			beginTransaction(mgr);
			group = insertGroups(mgr, group);
			commitTransaction(mgr);

			try {
				//UsageService.increaseUsage(group);
				
				Activities activity = new Activities(group, ActivityType.CREATED, loginUser);
				activity.setSyncEntity(group);
				syncService.sync(activity);
				
//				Activities activity = new Activities(group, ActivityType.CREATED, loginUser);
//				//Activities activity = new Activities(ActivityKind.GROUPS, ActivityType.CREATED,	group.getObjectId(), loginUser.getUserId());
//				activity.setSyncEntity(group);
//				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			
			return group;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Groups insertGroups(EntityManager mgr, Groups group) throws Exception {
		try {
			if (group.getKey() == null) {
				group.setKey(KeyUtil.createGroupKey(group));
			}

			if (contains(mgr, Groups.class, group.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Groups.class, group.getGroupId()));
			}

			doPersist(mgr, group);
			
			return group;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public Groups updateGroups(Groups group) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			String groupId = group.getObjectId();
			Groups originGroup = getGroups(groupId);
			valid(originGroup);

			ActivityData activityData = new ActivityData(originGroup, group);
			
			doMergeTransaction(mgr, group);

			List<Boards> boardList = boardService.listGroupBoards(mgr, groupId);
			for (Boards board : boardList) {
				try {
					activityService.insertActivities(activityService.createBoardActivity(board, activityData,
							ActivityType.GROUP_EDITED, loginUser));
				} catch (Exception e) {
					LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
				}
			}

			try {
				Activities activity = new Activities(group, ActivityType.UPDATED, loginUser);
				activity.setSyncEntity(group);
				syncService.sync(activity);
				
//				Activities activity = new Activities(group, ActivityType.UPDATED, loginUser);
//				//Activities activity = new Activities(ActivityKind.GROUPS, ActivityType.UPDATED, group.getObjectId(), loginUser.getObjectId());
//				activity.setSyncEntity(group);
//				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			
			return group;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public void removeGroups(String domainId, String groupId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			Groups group = doFind(mgr, Groups.class, groupId);
			if (Y.equals(group.getDefaultYN())) {
				throw new ServiceUnavailableException(ErrorCode.CANNOT_REMOVE_DEFAULT.getMessage(Groups.class, groupId));
			}
			
			List<Activities> activityList = new ArrayList<Activities>();

			Groups defaultGroup = getDefaultGroup(domainId);
			ActivityData activityData = new ActivityData(group, defaultGroup);

			List<Boards> boardList = boardService.listGroupBoards(mgr, groupId);
			
			beginTransaction(mgr, false);
			int txCount = 0;
			for (Boards board : boardList) {
				board.setGroupId(defaultGroup.getGroupId());

				doMerge(mgr, board);

				activityList.add(activityService.createBoardActivity(board, activityData,
						ActivityType.GROUP_DELETED, loginUser));
				if (++txCount >= CommonProperty.DEFAULT_TRANSACTION_COUNT) {txCount = 0; commitTransaction(mgr); beginTransaction(mgr, false); }
			}

			doRemove(mgr, group);
			commitTransaction(mgr);
			
			try {
				//String creator = loginUser.getObjectId();
				Activities activity = new Activities(group, ActivityType.DELETED, loginUser);
				activity.setSyncEntity(group);
				syncService.sync(activity);
				
//				Activities activity = new Activities(group, ActivityType.DELETED, loginUser);
//				//Activities activity = new Activities(ActivityKind.GROUPS, ActivityType.DELETED, 	group.getObjectId(), creator);
//				activity.setSyncEntity(group);
//				activityList.add(activity);
//				activityService.insertActivities(activityList);
			} catch (Exception e) {
				LOG.warning(e.getMessage());
				//	Ignored. Not a critical part of application.
			}

			//UsageService.decreaseUsage(group);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

//	@Deprecated
//	@Override
//	public boolean changeOrderGroups(List<String> groupIds) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			int orderCount = 0;
//
//			Map<String, Groups> groupsMap = batchMapByKey(mgr, Groups.class, groupIds);
//			List<Groups> groupList = new ArrayList<Groups>();
//
//			for (String groupId : groupIds) {
//				Groups group = groupsMap.get(groupId);
//				group.setOrdernum(orderCount++);
//				groupList.add(group);
//			
//			}
//			
//			doMergeTransaction(mgr, groupList);
//			
//			return true;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
}
