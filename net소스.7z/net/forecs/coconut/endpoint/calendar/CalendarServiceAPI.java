package net.forecs.coconut.endpoint.calendar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.UnavailableException;

import net.forecs.coconut.calendar.GoogleCalendarConverter;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.AlarmTriggerType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.RecurrenceChangeType;
import net.forecs.coconut.common.util.security.OAuthUtils;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.calendar.Events;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.api.client.util.DateTime;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.api.services.calendar.model.CalendarList;
import com.google.api.services.calendar.model.CalendarListEntry;
import com.google.api.services.calendar.model.Event;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;
import com.google.appengine.api.users.User;



@Api(name = API.BOARD_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.BOARD_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class CalendarServiceAPI {
	protected static final String Y = "Y";
	private final ICalendarService calendarService;
	
	@Inject
	public CalendarServiceAPI(ICalendarService calendarService) {
		this.calendarService = calendarService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryEvents", path = "events", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Events> queryEvents(
			@Nullable @Named(FLD.boardId) String boardId,
			@Nullable @Named(FLD.eventType) List<EventType> eventTypeList,
			@Named(FLD.startDate) Date startDate,
			@Named(FLD.endDate) Date endDate) throws Exception {
		if (StringUtils.isNotBlank(boardId)) {
			CommonService.validNamespace(boardId);
		}
		List<Events> list = calendarService.queryInstances(boardId, eventTypeList, null, Y, startDate, endDate);

		return CollectionResponse.<Events>builder().setItems(list).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getEvents", path = "events/{eventId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Events getEvents(@Named(FLD.eventId) String eventId) throws UnavailableException {
		CommonService.validNamespace(eventId);
		return calendarService.getEvents(eventId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "insertEvents", path = "events", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Events insertEvents(Events event) throws Exception {
		CommonService.validNamespace(event.getDomainId());
		return calendarService.insertEvents(event);
	}
	
	// ------------- Current service(Mobile) ----------------
	@ApiMethod(name = "updateEvents", path = "events", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEvents(Events event) throws Exception {
		CommonService.validNamespace(event.getEventId());
		return calendarService.updateEvents(event);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeEvents", path = "events/{eventId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeEvents(@Named(FLD.eventId) String eventId) throws Exception {
		CommonService.validNamespace(eventId);
		calendarService.removeEvents(eventId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventRecurrence", path = "events/recurrence", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventRecurrence(@Named(FLD.recurrenceChangeType) RecurrenceChangeType recurrenceChangeType,
			Events event) throws Exception {
		CommonService.validNamespace(event);
		return calendarService.updateEventRecurrence(recurrenceChangeType, event);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventTitle", path = "events/{eventId}/title", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventTitle(@Named(FLD.eventId) String eventId, @Named(FLD.title) String title) throws Exception {
		CommonService.validNamespace(eventId);
		return calendarService.updateEventTitle(eventId, title);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventType", path = "events/{eventId}/eventType", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventType(@Named(FLD.eventId) String eventId, @Named(FLD.eventType) EventType eventType) throws Exception {
		CommonService.validNamespace(eventId);
		return calendarService.updateEventType(eventId, eventType);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventDate", path = "events/{eventId}/eventDate", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventDate(@Named(FLD.eventId) String eventId, @Named(FLD.startDate) Date startDate, @Named(FLD.endDate) Date endDate) throws Exception {
		CommonService.validNamespace(eventId);
		return calendarService.updateEventDate(eventId, startDate, endDate);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "updateEventStartDate", path = "events/{eventId}/startDate", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Events updateEventStartDate(@Named(FLD.eventId) String eventId, @Named(FLD.startDate) Date startDate) throws Exception {
//		CommonService.validNamespace(eventId);
//		return calendarService.updateEventStartDate(eventId, startDate);
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "updateEventEndDate", path = "events/{eventId}/endDate", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Events updateEventEndDate(@Named(FLD.eventId) String eventId, @Named(FLD.endDate) Date endDate) throws Exception {
//		CommonService.validNamespace(eventId);
//		return calendarService.updateEventEndDate(eventId, endDate);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventAllDay", path = "events/{eventId}/allDayYN", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventAllDay(@Named(FLD.eventId) String eventId, @Named(FLD.allDayYN) String allDayYN) throws Exception {
		CommonService.validNamespace(eventId);
		return calendarService.updateEventAllDay(eventId, allDayYN);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventDescription", path = "events/{eventId}/description", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventDescription(@Named(FLD.eventId) String eventId, Text description) throws Exception {
		CommonService.validNamespace(eventId);
		return calendarService.updateEventDescription(eventId, description);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventLocation", path = "events/{eventId}/location", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventLocation(@Named(FLD.eventId) String eventId, @Named(FLD.location) String location) throws Exception {
		CommonService.validNamespace(eventId);
		return calendarService.updateEventLocation(eventId, location);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateEventAlarm", path = "events/{eventId}/alarm", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Events updateEventAlarm(
			@Named(FLD.eventId) String eventId,
//			@Named(FLD.alarmDateTime) Date alarmDateTime,
			@Named(FLD.alarmTriggerType) AlarmTriggerType alarmTriggerType, 
			@Named(FLD.alarmTriggerValue) Integer alarmTriggerValue,
			@Named(FLD.alarmYN) String alarmYN) throws Exception {
		CommonService.validNamespace(eventId);
		return calendarService.updateEventAlarm(eventId, alarmTriggerType, alarmTriggerValue, alarmYN);
	}
	
	@ApiMethod(name = "listGoogleCalendars", path = "events/google/calendars", httpMethod = HttpMethod.GET,
			scopes = {CommonProperty.EMAIL_SCOPE, CommonProperty.CALENDAR_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	//@RequiresUser
	public List<String> listGoogleCalendars(@Named(FLD.email) String email) throws Exception {
		com.google.api.services.calendar.Calendar clientCalendar = OAuthUtils.loadCalendarClientByEndpoints(email);
		CalendarList calendarList = clientCalendar.calendarList().list().execute();

		List<String> results = new ArrayList<String>();
		for (CalendarListEntry entry : calendarList.getItems()) {
			results.add(entry.getId());
		}
		return results;
	}
	
	@ApiMethod(name = "queryGoogleEvents", path = "events/google/calendar/events", httpMethod = HttpMethod.GET,
			scopes = {CommonProperty.EMAIL_SCOPE, CommonProperty.CALENDAR_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	//@RequiresUser
	public List<Events> queryGoogleEvents(
			@Named(FLD.email) String email,
			@Named(FLD.calendarId) String calendarId,
			@Named(FLD.startDate) Date startDate,
			@Named(FLD.endDate) Date endDate,
			User user) throws Exception {
		com.google.api.services.calendar.Calendar clientCalendar = OAuthUtils.loadCalendarClientByEndpoints(email);
		com.google.api.services.calendar.Calendar.Events.List eventList = clientCalendar.events().list(calendarId);

		System.out.println(calendarId);
		List<Events> instances = new ArrayList<Events>();
		
		if (endDate != null) {
			DateTime timeMax = new DateTime(endDate, TimeZone.getTimeZone("UTC"));
			eventList = eventList.setTimeMax(timeMax);
		}
		if (startDate != null) {
			DateTime timeMin = new DateTime(startDate, TimeZone.getTimeZone("UTC"));
			eventList = eventList.setTimeMin(timeMin);	
		}
			
		com.google.api.services.calendar.model.Events googleEvents = eventList.execute();
		ObjectMapper om = new ObjectMapper();
		om.enable(SerializationFeature.INDENT_OUTPUT);
		for (Event event : googleEvents.getItems()) {
			System.out.println("---------------------------");
			System.out.println(om.writeValueAsString(event));
			System.out.println("---------------------------");
			if (StringUtils.isNotBlank(event.getRecurringEventId())) { continue; }
			com.google.api.services.calendar.model.Events gIns = clientCalendar.events().instances(calendarId, event.getId()).execute();
			List<Events> coconutEventList = GoogleCalendarConverter.listEventsFromCalendar(null, null, null, gIns);
			instances.addAll(coconutEventList);
		}
//		List<Events> coconutEventList = GoogleCalendarConverter.listEventsFromCalendar(null, null, null, googleEvents);
//		if (coconutEventList != null) {
//			// 내 계정에서 가져온 Event
//			for (Events event : coconutEventList) {
//				instances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
//			}
//		}
		return instances;
	}
	
	@ApiMethod(name = "addGoogleEvent", path = "events/google/calendar/events", httpMethod = HttpMethod.POST,
			scopes = {CommonProperty.EMAIL_SCOPE, CommonProperty.CALENDAR_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	//@RequiresUser
	public void addGoogleEvent(
			@Named(FLD.email) String email,
			@Named(FLD.calendarId) String calendarId,
			Events event,
			User user) throws Exception {
		com.google.api.services.calendar.Calendar clientCalendar = OAuthUtils.loadCalendarClientByEndpoints(email);
		
		com.google.api.services.calendar.model.Event googleEvent = GoogleCalendarConverter.convertToGoogleEvent(event);
		clientCalendar.events().insert(calendarId, googleEvent).execute();
	}
	@ApiMethod(name = "deleteGoogleEvent", path = "events/google/calendar/events", httpMethod = HttpMethod.DELETE,
			scopes = {CommonProperty.EMAIL_SCOPE, CommonProperty.CALENDAR_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	//@RequiresUser
	public void deleteGoogleEvent(
			@Named(FLD.email) String email,
			@Named(FLD.calendarId) String calendarId,
			@Named(FLD.eventId) String eventId,
			User user) throws Exception {
		String id = eventId;
		try {
			id = KeyFactory.stringToKey(eventId).getName();
		} catch (Exception ex) { }
		
		com.google.api.services.calendar.Calendar clientCalendar = OAuthUtils.loadCalendarClientByEndpoints(email);
		clientCalendar.events().delete(calendarId, id).execute();
	}
	// ************* Unused service ******************
//	@ApiMethod(name = "bulkRemoveEvents", path = "events/bulk", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public Result bulkRemoveEvents(@Named(FLD.domainId) String domainId, @Nullable @Named(FLD.boardIdList) List<String> boardIdList) throws Exception {
//		CommonService.validNamespace(domainId);
//		return new Result(calendarService.bulkRemoveEvents(domainId, boardIdList));
//	}
}