package net.forecs.coconut.endpoint.calendar;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.UnavailableException;

import net.forecs.coconut.calendar.AnniversaryUtil;
import net.forecs.coconut.calendar.CalendarConverter;
import net.forecs.coconut.calendar.HolidayUtil;
import net.forecs.coconut.calendar.RecurrenceUtil;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.AlarmTriggerType;
import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.CalendarAccessRole;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.RecurrenceChangeType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.LocaleUtil;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.board.IAlarmService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Calendars;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.calendar.Recurrence;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.EventIndex;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.BadRequestException;
import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;


public class CalendarService extends CommonService implements ICalendarService {
	private static final Logger LOG = Logger.getLogger(CalendarService.class.getName());
	private static Set<String> excludeMergeProperty = new HashSet<String>();
	static {
		excludeMergeProperty.add(FLD.creator);
		excludeMergeProperty.add(FLD.created);
		excludeMergeProperty.add(FLD.uid);
		excludeMergeProperty.add(FLD.sequence);
		excludeMergeProperty.add(FLD.eventGroupId);
	}
	private static int ANNIVERSARY_QUERY_DAYS = 3;
	
	private final IBoardService boardService;
	private final ITaskService taskService;
	private final IActivityService activityService;
	private final IAlarmService alarmService;
	private final IUserService userService;
	
	@Inject
	public CalendarService(IBoardService boardService,
			ITaskService taskService,
			IActivityService activityService,
			IAlarmService alarmService,
			IUserService userService) {
		this.boardService = boardService;
		this.taskService = taskService;
		this.activityService = activityService;
		this.alarmService = alarmService;
		this.userService = userService;
	}

	@Override
	public Calendars insertOrUpdateCalendar(Calendars calendar) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			if (contains(mgr, Calendars.class, calendar.getKey())) {
				return updateCalendar(mgr, calendar);
			} else {
				return insertCalendar(mgr, calendar);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private Calendars insertCalendar(EntityManager mgr, Calendars calendar) throws Exception {
		if (contains(mgr, Calendars.class, calendar.getKey())) {
			throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Calendars.class, calendar.getCalendarId()));
		}
		doPersistTransaction(mgr, calendar);
		return calendar;
	}

	private Calendars updateCalendar(EntityManager mgr, Calendars calendar) throws Exception {
		valid(calendar);
		return doMergeTransaction(mgr, calendar);
	}

	private List<Events> queryEventAlarms(
			String boardId,
			Date startDate) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			List<String> boardIdList = null;
			if (StringUtils.isNotBlank(boardId)) {
				boardIdList = new ArrayList<String>();
				boardIdList.add(boardId);
			}
			return queryEventsForRecurrence(mgr, loginUser, boardIdList, null, Y, Y, startDate, null);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private List<Events> queryEventsForRecurrence (
			EntityManager mgr,
			Users user,
			Collection<String> boardIdList,
			Collection<EventType> eventTypeList,
			String alarmYN,
			String activeYN,
			Date startDate,
			Date endDate) throws Exception {
		try {
			List<Events> eventList = new ArrayList<Events>();
			
			int boardCount = 0;
			int typeCount = 0;
			Set<String> boardIdSet = null;

			if (boardIdList != null) { boardCount = boardIdList.size(); }
			if (eventTypeList != null) { typeCount = eventTypeList.size(); }
			
			if ((boardCount * typeCount) > CommonProperty.SUBQUERY_PARAM_COUNT) {
				boardIdSet = new HashSet<String>();
				for (String boardId : boardIdList) {
					boardIdSet.add(boardId);
				}
				boardIdList = null;
			}
			
			DsQuery<Events> dsQuery = new DsQuery<>(Events.class)
					.eq(FLD.deleteYN, N)
					.in(FLD.boardId, boardIdList)
					.in(FLD.eventType, eventTypeList)
					.eq(FLD.alarmYN, alarmYN)
					.eq(FLD.activeYN, activeYN)
					.le(FLD.startDate, endDate);
			
			List<Events> execute = dsQuery.execute(mgr);
			
			List<String> myTaskIds = null;
			if (user != null) {
				myTaskIds = taskService.listMyTaskIds(mgr, user, boardIdList != null ? boardIdList : boardIdSet);
			}
			
			Set<String> taskIdList = new HashSet<String>();
			for (Events event : execute) {
				if (boardIdSet != null && !boardIdSet.contains(event.getBoardId())) { continue; }
				if (EventType.TASK.equals(event.getEventType())	&& StringUtils.isNotBlank(event.getTaskId())){
					if (user == null || (user != null && myTaskIds.contains(event.getTaskId()))) {
						taskIdList.add(event.getTaskId());
					}
				}
			}
			
			Map<String, Tasks> taskMap = batchMapByKey(mgr, Tasks.class, taskIdList);
			for (Events event : execute) {
				if (boardIdSet != null && !boardIdSet.contains(event.getBoardId())) { continue; }
				if (EventType.TASK.equals(event.getEventType()) && StringUtils.isNotBlank(event.getTaskId())){
					if (!isValid(taskMap.get(event.getTaskId()))) { continue; }
				}
				// 반복의 종료일이 Unlimit가 아니고 반복종료일이 조회 시작일보다 작다면 이벤트가 종료된것임
				if (startDate != null
						&& event.getRecurrence() != null
						&& event.getRecurrence().getUntil() != null
						&& event.getRecurrence().getUntil().compareTo(startDate) <= 0) {
					continue;	
				}
				eventList.add(event);
			}
			
			return eventList;
		} catch (Exception ex) {
			LOG.warning("[queryEventsForRecurrence error] : " + ex.getMessage());
			throw ex;
		}
	}

	@Override
	public List<Events> queryInstances (
			String boardId,
			Collection<EventType> eventTypeList,
			String alarmYN,
			String activeYN,
			Date startDate,
			Date endDate) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			final String domainId = KeyUtil.createDomainKeyString(NamespaceManager.get());
			List<String> boardIdList = null;
			List<Events> instanceList = new LinkedList<Events>();
			
			List<Events> eventInstances = null;
			List<Events> holidayInstances = null;
			List<Events> anniversaryInstances = null;
			List<Events> myInstances = null;
	//		List<Events> taskInstances = null;
			
			String startDateStr = CalendarUtil.toString(startDate, "yyyyMMdd");
			String endDateStr = CalendarUtil.toString(endDate, "yyyyMMdd");
			
			if (StringUtils.isNotBlank(boardId)) {
				boardIdList = new ArrayList<String>();
				boardIdList.add(boardId);
	
				// TODO
				// BOARD가 Close된것인지 아닌지 체크
			}
			
			Users loginUser = getCurrentUser();
			if (loginUser == null && eventTypeList != null) { eventTypeList.remove(EventType.PRIVATE); }
	
			MemcacheManager<Events, List<Events>> eventMM = new MemcacheManager<>(Events.class, MemcacheManager.keySet(boardId));
			String eventKey = eventMM.createMemcacheKey(boardIdList, eventTypeList, alarmYN, activeYN, startDateStr, endDateStr);
			eventInstances = eventMM.getMemcache(eventKey);
			
			if (eventInstances == null) {
				eventInstances = new ArrayList<Events>();
				List<Events> eventList = queryEventsForRecurrence(mgr, loginUser, boardIdList, eventTypeList, alarmYN, activeYN, startDate, endDate);
				if (eventList != null) {
					for (Events event : eventList) {
						eventInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
					}
				}
				eventMM.setMemcache(eventKey, eventInstances);
			}
			instanceList.addAll(eventInstances);
			
			// hyeunwoo.shim 2015-06-19 : SYSTEM_HOLIDAY is common event type.
			if (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.SYSTEM_HOLIDAY)) {
				//String holidayEventKey = String.format("%s-%s", eventKey, EventType.HOLIDAY);
				Locale locale = LocaleUtil.getUserLocale(loginUser);
				MemcacheManager<Events, List<Events>> holidayMM = new MemcacheManager<>(Events.class, EventType.SYSTEM_HOLIDAY.toString());
				String holidayEventKey = holidayMM.createMemcacheKey(locale.toString(), startDateStr, endDateStr);
				
				holidayInstances = holidayMM.getMemcache(holidayEventKey);
				if (holidayInstances == null) {
					holidayInstances = new ArrayList<Events>();
					List<Events> holidayEventList = HolidayUtil.createHolidayEventList(locale);
					/** 명절, 국가공휴일, 24절기 등등의 이벤트 */
					if (holidayEventList != null) {
						for (Events event : holidayEventList) {
							holidayInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
						}
					}
					holidayMM.setMemcache(holidayEventKey, holidayInstances);
				}
				if (holidayInstances != null) { for (Events event : holidayInstances) { event.setDomainId(domainId); event.setBoardId(boardId); } }
				instanceList.addAll(holidayInstances);
			}
			
			if (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.PRIVATE_ANNIVERSARY)) {
				MemcacheManager<Events, List<Events>> anniversaryMM = new MemcacheManager<>(Events.class, EventType.PRIVATE_ANNIVERSARY.toString());
				String anniversaryEventKey = anniversaryMM.createMemcacheKey(domainId, boardId, startDateStr, endDateStr);
				anniversaryInstances = anniversaryMM.getMemcache(anniversaryEventKey);
				if (anniversaryInstances == null) {
					anniversaryInstances = new ArrayList<Events>();
					List<Events> anniversaryEventList = getBoardMemberAnniversaryEventList(mgr, boardId);
					/** 멤버와 관련된 이벤트 (생일) */
					if (anniversaryEventList != null) {
						for (Events event : anniversaryEventList) {
							anniversaryInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
						}
					}
					anniversaryMM.setMemcache(anniversaryEventKey, anniversaryInstances);
				}
				instanceList.addAll(anniversaryInstances);
			}
			
			//-----------------------------------------------------------------------------------------------------------------
			//-->
			// hyeunwoo.shim 2015-09-16 : Don't delete(구글 계정과 연동시에 사용(속도 향상을 위해 사용하지 않을동안 주석 처리)
			
			if (loginUser != null && (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.PRIVATE))) {
				MemcacheManager<Events, List<Events>> privateMM = new MemcacheManager<>(Events.class, loginUser.getId());
				String privateEventKey = privateMM.createMemcacheKey(loginUser.getId(), startDateStr, endDateStr);
				myInstances = privateMM.getMemcache(privateEventKey);
				if (myInstances == null) {
					myInstances = new ArrayList<Events>();
					List<Events> myEventList = listMyCalendarEvents(null, null);
					// Google Calendar 계정에서 가져온 Event
					if (myEventList != null) {
						for (Events event : myEventList) {
							myInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
						}
					}
					privateMM.setMemcache(privateEventKey, myInstances);
				}
				instanceList.addAll(myInstances);
			}
			
			//<--
			//-----------------------------------------------------------------------------------------------------------------
			
	/*		if (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.TASK)) {
				String taskEventKey = String.format("%s-%s", eventKey, EventType.TASK);
				taskInstances = mm.getMemcache(taskEventKey);
				if (taskInstances == null) {
					taskInstances = queryTaskEventsForCalendar(domainId, boardIdList, startDate, endDate);
					mm.setMemcache(taskEventKey, taskInstances, MemcacheManager.RESULT_KEEP_TIME);
				}
				instanceList.addAll(taskInstances);
			}*/
			
			RecurrenceUtil.sort(instanceList);
	
			return instanceList;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Events> queryInstanceForDashboard (
			@Deprecated Collection<String> userIdList,
			Collection<EventType> eventTypeList,
			Date startDate,
			Date endDate) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			final String domainId = KeyUtil.createDomainKeyString(NamespaceManager.get());
			List<Events> instanceList = new LinkedList<Events>();
			List<Events> eventInstances = null;
			List<Events> holidayInstances = null;
			List<Events> anniversaryInstances = null;
			List<Events> myInstances = null;	// Don't delete
	//		List<Events> taskInstances = null;	// Don't delete
			
			String startDateStr = CalendarUtil.toString(startDate, "yyyyMMdd");
			String endDateStr = CalendarUtil.toString(endDate, "yyyyMMdd");
			
			Users loginUser = getCurrentUser();
			if (loginUser == null && eventTypeList != null) { eventTypeList.remove(EventType.PRIVATE); }
	
			MemcacheManager<Events, List<Events>> eventMM = new MemcacheManager<>(Events.class);
			
			// 사용자(들)가 속한 보드 목록에서 이벤트 목록을 가져온다.
//			if (userIdList == null) { userIdList = new ArrayList<String>(); }
//			if (loginUser != null && !userIdList.contains(loginUser.getUserId())) { userIdList.add(loginUser.getUserId()); }
			Set<String> boardIdSet = boardService.getUserBoardIds(mgr, loginUser);
			//Set<String> boardIdSet = boardService.getUsersBoardForDashboard(mgr, loginUser, userIdList);
			String eventKey = eventMM.createMemcacheKey(boardIdSet, eventTypeList, Y, startDateStr, endDateStr);
			eventInstances = eventMM.getMemcache(eventKey);
			
			if (eventInstances == null) {
				eventInstances = new ArrayList<Events>();
				List<Events> eventList = queryEventsForRecurrence(mgr, loginUser, boardIdSet, eventTypeList, null, Y, startDate, endDate);
				if (eventList != null) {
					for (Events event : eventList) {
						eventInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
					}
				}
				eventMM.setMemcache(eventKey, eventInstances);
			}
			instanceList.addAll(eventInstances);
	
			// hyeunwoo.shim 2015-06-19 : SYSTEM_HOLIDAY is common event type.
			if (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.SYSTEM_HOLIDAY)) {
				Locale locale = LocaleUtil.getUserLocale(loginUser);
				MemcacheManager<Events, List<Events>> holidayMM = new MemcacheManager<>(Events.class, EventType.SYSTEM_HOLIDAY.toString());
				String holidayEventKey = holidayMM.createMemcacheKey(locale.toString(), startDateStr, endDateStr);
				holidayInstances = holidayMM.getMemcache(holidayEventKey);
				if (holidayInstances == null) {
					holidayInstances = new ArrayList<Events>();
					List<Events> holidayEventList = HolidayUtil.createHolidayEventList(locale);
					/** 명절, 국가공휴일, 24절기 등등의 이벤트 */
					if (holidayEventList != null) {
						for (Events event : holidayEventList) {
							holidayInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
						}
					}
					holidayMM.setMemcache(holidayEventKey, holidayInstances);
				}
				if (holidayInstances != null) { for (Events event : holidayInstances) { event.setDomainId(domainId); } }
				instanceList.addAll(holidayInstances);
			}
			
			if (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.PRIVATE_ANNIVERSARY)) {
				MemcacheManager<Events, List<Events>> anniversaryMM = new MemcacheManager<>(Events.class, EventType.PRIVATE_ANNIVERSARY.toString());
				String anniversaryEventKey = anniversaryMM.createMemcacheKey(domainId, startDateStr, endDateStr);
				anniversaryInstances = anniversaryMM.getMemcache(anniversaryEventKey);
				if (anniversaryInstances == null) {
					anniversaryInstances = new ArrayList<Events>();
					List<Events> anniversaryEventList = getDashboardMemberAnniversaryEventList(mgr, loginUser);
					if (anniversaryEventList != null) {
						/** 멤버와 관련된 이벤트 (생일) */
						for (Events event : anniversaryEventList) {
							anniversaryInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
						}
					}
					anniversaryMM.setMemcache(anniversaryEventKey, anniversaryInstances);
				}
				instanceList.addAll(anniversaryInstances);
			}
			
			//-----------------------------------------------------------------------------------------------------------------
			//-->
			// hyeunwoo.shim 2015-08-25 : Don't delete(구글 계정과 연동시에 사용(속도 향상을 위해 사용하지 않을동안 주석 처리)
			
			if (loginUser != null && (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.PRIVATE))) {
				MemcacheManager<Events, List<Events>> privateMM = new MemcacheManager<>(Events.class, loginUser.getId());
				String privateEventKey = privateMM.createMemcacheKey(loginUser.getId(), startDateStr, endDateStr);
				myInstances = privateMM.getMemcache(privateEventKey);
				if (myInstances == null) {
					myInstances = new ArrayList<Events>();
					List<Events> myEventList = listMyCalendarEvents(null, null);
					if (myEventList != null) {
						// 내 계정에서 가져온 Event
						for (Events event : myEventList) {
							myInstances.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
						}
					}
					privateMM.setMemcache(privateEventKey, myInstances);
				}
				instanceList.addAll(myInstances);
			}
			
			//<--
			//-----------------------------------------------------------------------------------------------------------------
			
			//-----------------------------------------------------------------------------------------------------------------
			// Task에서의 이벤트를 가져오는 쿼리 작성
			/*
	 		if (eventTypeList == null || eventTypeList.size() == 0 || eventTypeList.contains(EventType.TASK)) {
				*//** Task의 StartDate 혹은 DueDate로 Calendar에 표시할 이벤트를 가져온다. *//*
				*//** 중복 허용, StartDate + DueDate + Task의 이벤트 *//*
				String taskEventKey = String.format("%s-%s", eventKey, EventType.TASK);
				taskInstances = (List<Events>)mm.getMemcache(taskEventKey);
				if (taskInstances == null) {
					taskInstances = calendarService.queryTaskEventsForCalendar(domainId, boardIdSet, startDate, endDate);
					mm.setMemcache(taskEventKey, taskInstances, MemcacheManager.RESULT_KEEP_TIME);
				}
				instanceList.addAll(taskInstances);
			}*/
			//-----------------------------------------------------------------------------------------------------------------
	
			//--> 
			// hyeunwoo.shim 2015-08-25 : Don't delete(정렬이 필요하면 주석 제거)
			//RecurrenceUtil.sort(instanceList);
			//<--
			
			return instanceList;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<Events> getBoardMemberAnniversaryEventList(EntityManager mgr, String boardId) throws Exception {
		try {
			final String domainId = KeyUtil.createDomainKeyString(NamespaceManager.get());
			AnniversaryUtil anniversaryUtil = new AnniversaryUtil();
			List<Users> memberList = boardService.getAssignedMemberList(mgr, boardId);
			for (Users user : memberList) {
				anniversaryUtil.addAnniversary(user);
			}
			return anniversaryUtil.createAnniversaryEventList(domainId, boardId);
		} catch (Exception ex) {
			throw ex;
		}
	}
	private List<Events> getDashboardMemberAnniversaryEventList(EntityManager mgr, Users loginUser) throws Exception {
		try {
			final String domainId = KeyUtil.createDomainKeyString(NamespaceManager.get());
			AnniversaryUtil anniversaryUtil = new AnniversaryUtil();
			List<Users> memberList = getDashbordMemberList(mgr, loginUser);
			
			for (Users user : memberList) {
				anniversaryUtil.addAnniversary(user);
			}

			return anniversaryUtil.createAnniversaryEventList(domainId, null);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<Users> getDashbordMemberList(EntityManager mgr, Users loginUser) throws Exception {
		try {
			List<Boards> boardList = boardService.getUserBoards(mgr, loginUser);
			List<Users> dashboardMemberList = boardService.getAssignedMemberList(mgr, boardList);
			
			return dashboardMemberList;
		} catch (Exception ex) {
			LOG.severe(ex.getMessage());
			throw ex;
		}
	}
	
	@Override
	public List<Events> queryNextAlarms(
			String boardId
			) throws Exception {
		Date startDate = new Date();
		List<Events> eventAlarms = queryEventAlarms(boardId, startDate);
		List<Events> alarmList = new ArrayList<Events>();
		for (Events event : eventAlarms) {
			Events alarmEvent = RecurrenceUtil.nextAlarm(event, startDate);
			if (alarmEvent != null) {
				alarmList.add(alarmEvent);
			}
		}
		return alarmList;
	}

	@Override
	public Events nextAlarm(String eventId) throws Exception {
		Events event = getEvents(eventId);
		Events alarmEvent = null;
		
		if (event != null && isValid(event)) {
			if (Y.equals(event.getActiveYN()) && Y.equals(event.getAlarmYN())) {
				Date startDate = new Date();
				alarmEvent = RecurrenceUtil.nextAlarm(event, startDate);
			}
		}
		
		return alarmEvent;
	}

	@Override
	public Events getEvents(String eventId) {
		EntityManager mgr = getEntityManager();
		try {
			return getEvents(mgr, eventId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public Events getEvents(EntityManager mgr, String eventId) {
		return doFind(mgr, Events.class, eventId);
	}

	@Override
	public Events insertEvents(Events event) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			if (StringUtils.isBlank(event.getDomainId())) {
				event.setDomainId(KeyUtil.createDomainKeyString(NamespaceManager.get()));
			}

			if (event.getStartDate().compareTo(event.getEndDate()) >= 0) {
				throw new BadRequestException(ErrorCode.BAD_REQUEST.getMessage("Start datetime large or same than end datetime."));
			}
			event.setCreator(loginUser.getUserId());
			event.setOwner(loginUser.getUserId());

			/** 이벤트를 하루종일 설정하고자 할때 */
//			if (Y.equals(event.getAllDayYN())) {
//				Date startDate = event.getStartDate();
//				Date endDate = event.getEndDate();
//
//				if (startDate == null) { startDate = new Date(); }
//				if (endDate == null) { endDate = new Date(); }
//
//				event.setStartDate(CalendarUtil.getStartDateOfDay(startDate));
//				event.setEndDate(CalendarUtil.getEndDateOfDay(endDate));
//			}

			if (event.getStartDate() == null || event.getEndDate() == null) {
				throw new BadRequestException(ErrorCode.BAD_REQUEST.getMessage("Start date and end date are required."));
			}
			if (event.getRecurrence() == null) { event.setRecurrence(new Recurrence()); }

			event.setKey(KeyUtil.createEventKey());
			event.setEventGroupId(event.getEventId()); // 최초 생성이면 EventID와 groupId가 동일
			if (StringUtils.isEmpty(event.getUid())) {
				event.setUid(event.getEventId());
			}

			if (contains(mgr, Events.class, event.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Events.class, event.getEventId()));
			}
			
			doPersistTransaction(mgr, event);

			try {
				createOrUpdateEventIndex(event);
				
				if (Y.equals(event.getAlarmYN())) {
					alarmService.updateAlarmQueue(event.getEventId());
				}
				activityService.insertActivities(activityService.createEventActivity(event, null,
						ActivityType.ADDED, loginUser));
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());	// Ignored. Not a critical part of application.
			}
			
			return event;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Events updateEvents(Events event) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			valid(event);

			/** 이벤트를 하루종일 설정하고자 할때 */
//			if (Y.equals(event.getAllDayYN())) {
//				Date startDate = event.getStartDate();
//				Date endDate = event.getEndDate();
//
//				if (startDate == null) { startDate = new Date(); }
//				if (endDate == null) { endDate = new Date(); }
//
//				event.setStartDate(CalendarUtil.getStartDateOfDay(startDate));
//				event.setEndDate(CalendarUtil.getEndDateOfDay(endDate));
//			}

			doMergeTransaction(mgr, event);

			try {
				alarmService.updateAlarmQueue(event.getEventId());
				createOrUpdateEventIndex(event);
			} catch (Exception ex) {	// Ignored. Not a critical part of application.
			}
			
			return event;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Events updateEventTitle(String eventId, String title) throws Exception {
		Events event = new Events();
		event.setEventId(eventId);
		event.setTitle(title);
		
		return updatePortionOfEvents(event, ActivityType.RENAMED);
	}
	@Override
	public Events updateEventType(String eventId, EventType eventType) throws Exception {
		Events event = new Events();
		event.setEventId(eventId);
		event.setEventType(eventType);
		
		return updatePortionOfEvents(event, ActivityType.UPDATE_EVENT_TYPE);
	}
	@Override
	public Events updateEventDate(String eventId, Date startDate, Date endDate) throws Exception {
		Events event = new Events();
		event.setEventId(eventId);
		event.setStartDate(startDate);
		event.setEndDate(endDate);
		
		return updatePortionOfEvents(event, ActivityType.UPDATE_EVENT_DATE);
	}
	
	@Override
	public Events updateEventAllDay(String eventId, String allDayYN) throws Exception {
		Events event = new Events();
		event.setEventId(eventId);
		event.setAllDayYN(allDayYN);
		
		return updatePortionOfEvents(event, ActivityType.UPDATE_EVENT_ALLDAY);
	}
	@Override
	public Events updateEventDescription(String eventId, Text description) throws Exception {
		Events event = new Events();
		event.setEventId(eventId);
		event.setDescription(description);
		
		return updatePortionOfEvents(event, ActivityType.UPDATE_DESCRIPTION);
	}
	@Override
	public Events updateEventLocation(String eventId, String location) throws Exception {
		Events event = new Events();
		event.setEventId(eventId);
		event.setLocation(location);
		
		return updatePortionOfEvents(event, ActivityType.UPDATE_LOCATION);
	}

	private Events updatePortionOfEvents(Events event, ActivityType activityType) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			Events originEvent = getEvents(mgr, event.getEventId());
			valid(originEvent);
		
			Activities activity = null;
			
			switch (activityType) {
				case RENAMED :
					String originTitle = originEvent.getTitle();
					originEvent.setTitle(event.getTitle());
					activity = activityService.createEventActivity(originEvent, originTitle, activityType, loginUser);
					break;
				case UPDATE_EVENT_TYPE :
					originEvent.setEventType(event.getEventType());
					activity = activityService.createEventActivity(originEvent, null, activityType, loginUser);
					break;
				case UPDATE_EVENT_DATE :
					originEvent.setStartDate(event.getStartDate());
					originEvent.setEndDate(event.getEndDate());
					activity = activityService.createEventActivity(originEvent, null, activityType, loginUser);
					break;
				case UPDATE_EVENT_STARTDATE :
					originEvent.setStartDate(event.getStartDate());
					activity = activityService.createEventActivity(originEvent, null, activityType, loginUser);
					break;
				case UPDATE_EVENT_ENDDATE :
					originEvent.setEndDate(event.getEndDate());
					activity = activityService.createEventActivity(originEvent, null, activityType, loginUser);
					break;
				case UPDATE_EVENT_ALLDAY :
					boolean isActive = true;
					if (!Y.equals(event.getAllDayYN())) {
						isActive = false;
					}
					/** 이벤트를 하루종일 설정하고자 할때 */
//					if (Y.equals(event.getAllDayYN())) {
//						Date startDate = originEvent.getStartDate();
//						Date endDate = originEvent.getEndDate();
//						
//						if (startDate==null) { startDate = new Date(); }
//						if (endDate==null) { endDate = new Date(); }
//						
//						originEvent.setStartDate(CalendarUtil.getStartDateOfDay(startDate));
//						originEvent.setEndDate(CalendarUtil.getEndDateOfDay(endDate));
//					} else {
//						isActive = false;
////						originEvent.setStartDate(originEvent.getStartDate());
////						originEvent.setEndDate(originEvent.getEndDate());
//					}
					originEvent.setAllDayYN(event.getAllDayYN());
					activity = activityService.createEventActivity(originEvent, isActive, activityType, loginUser);
					break;
				case UPDATE_DESCRIPTION :
					originEvent.setDescription(event.getDescription());
					activity = activityService.createEventActivity(originEvent, null, activityType, loginUser);
					break;
				case UPDATE_LOCATION :
					originEvent.setLocation(event.getLocation());
					activity = activityService.createEventActivity(originEvent, null, activityType, loginUser);
					break;
				case UPDATE_ALARM :
					originEvent.setAlarmDateTime(event.getAlarmDateTime());
					originEvent.setAlarmTriggerType(event.getAlarmTriggerType());
					originEvent.setAlarmTriggerValue(event.getAlarmTriggerValue());
					originEvent.setAlarmYN(event.getAlarmYN());
					
					alarmService.updateAlarmQueue(event.getEventId());
					activity = activityService.createEventActivity(originEvent, null, activityType, loginUser);
					break;
				default :
					break;
			}
			
			doMergeTransaction(mgr, originEvent);
			
			try {
				createOrUpdateEventIndex(originEvent);
			} catch (Exception ex) {}
			
			try {
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return originEvent;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Events updateEventRecurrence(RecurrenceChangeType recurrenceChangeType, Events event) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			if (recurrenceChangeType == null) { recurrenceChangeType = RecurrenceChangeType.ALL; }
			
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();
			List<Activities> activityList = new ArrayList<Activities>();
			
			valid(event);
			
			if (RecurrenceChangeType.ALL.equals(recurrenceChangeType) || event.getRecurrence() == null) {
				doPersistTransaction(mgr, event);
				
				try {
					// 해당이벤트에 대해 알람이 설정(알람 설정에 따라 TaskQueue에서 제거되거나 새로 등록)
					alarmService.updateAlarmQueue(event.getEventId());	
					createOrUpdateEventIndex(event);
					activityList.add(activityService.createEventActivity(event, null, ActivityType.UPDATE_EVENT_DATE, loginUser));
				} catch (Exception ex) {}
			} else if (RecurrenceChangeType.ONLY.equals(recurrenceChangeType)) {
				if (event.getRecurrenceDate() == null) {
					throw new UnavailableException("Require recurrence date.");
				}

				Events originEvent = doFind(mgr, Events.class, event.getEventId());
				
				/**
				 * 중요 : 이벤트를 변경시 변경대상의 시간값은 startDate가 기준이 아니라 recurrenceDate가 기준임
				 * (즉, 반복되는 시간값을 기준값으로 주어야 제대로 event를 변경할 수 있다.)
				 * (startDate, endDate는 변경가능한 값이나, recurrenceDate는 변경불가값이며 반드시 있어야 하는값이다.)
				 */
				// 원래 이벤트에서 변경하고자 하는 날짜에서 해당 날짜를 제외시킨다.
				//RecurrenceUtil.addExDate(event, event.getStartDate());
				RecurrenceUtil.addExDate(originEvent, event.getRecurrenceDate());
				
				doMergeTransaction(mgr, originEvent);

				Events newEvent = event;
				newEvent.setKey(KeyUtil.createEventKey());
				newEvent.setCreated(new Date());
				newEvent.setCreator(loginUserId);
				newEvent.setRecurrence(null);
				newEvent.setRecurrenceYN(N);
				
				doPersistTransaction(mgr, newEvent);
				
				try {
					createOrUpdateEventIndex(event);
					createOrUpdateEventIndex(newEvent);

					activityList.add(activityService.createEventActivity(originEvent, null, ActivityType.UPDATE_EVENT_DATE, loginUser));
					activityList.add(activityService.createEventActivity(newEvent, null, ActivityType.ADDED, loginUser));

					// 해당이벤트에 대해 알람이 설정(알람 설정에 따라 TaskQueue에서 제거되거나 새로 등록)
					alarmService.updateAlarmQueue(event.getEventId());	
					alarmService.updateAlarmQueue(newEvent.getEventId());
				} catch (Exception ex) {}
			} else if (RecurrenceChangeType.AFTER.equals(recurrenceChangeType)) {
				if (event.getRecurrenceDate() == null) {
					throw new UnavailableException("Require recurrence date.");
				}
				/** 이전 날짜의 이벤트를 신규 입력하는 이벤트의 시작일자값으로 해서 
				 * 종결시킨다.
				 *
				 * 중요 : 이벤트를 변경시 변경대상의 시간값은 startDate가 기준이 아니라 recurrenceDate가 기준임
				 * (즉, 반복되는 시간값을 기준값으로 주어야 제대로 event를 변경할 수 있다.)
				 * (startDate, endDate는 변경가능한 값이나, recurrenceDate는 변경불가값이며 반드시 있어야 하는값이다.)
				 */

				Events beforeEvent = doFind(mgr, Events.class, event.getEventId());
				//RecurrenceUtil.divideRecurrence(beforeEvent, event.getStartDate());
				RecurrenceUtil.divideRecurrence(beforeEvent, event.getRecurrenceDate());
				
				doMergeTransaction(mgr, beforeEvent);

				Events afterEvent = event;
				afterEvent.setKey(KeyUtil.createEventKey());
				afterEvent.setCreated(new Date());
				afterEvent.setCreator(loginUserId);

				doPersistTransaction(mgr, afterEvent);
				
				try {
					createOrUpdateEventIndex(beforeEvent);
					createOrUpdateEventIndex(afterEvent);

					activityList.add(activityService.createEventActivity(beforeEvent, null, ActivityType.UPDATE_EVENT_DATE, loginUser));
					activityList.add(activityService.createEventActivity(afterEvent, null, ActivityType.ADDED, loginUser));

					// 해당이벤트에 대해 알람이 설정(알람 설정에 따라 TaskQueue에서 제거되거나 새로 등록)
					alarmService.updateAlarmQueue(beforeEvent.getEventId());	
					alarmService.updateAlarmQueue(afterEvent.getEventId());
				} catch (Exception ex) {}
			}

			try {
				activityList.add(activityService.createEventActivity(event, null, ActivityType.UPDATE_RECURRENCE, loginUser));
				activityService.insertActivities(activityList);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return event;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Events updateEventAlarm(
			String eventId,
//			Date alarmDateTime, 
			AlarmTriggerType alarmTriggerType, 
			Integer alarmTriggerValue, 
			String alarmYN) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Events originEvent = doFind(mgr, Events.class, eventId);
			valid(originEvent);

			originEvent.setAlarmTriggerType(alarmTriggerType);
			originEvent.setAlarmTriggerValue(alarmTriggerValue);
			originEvent.setAlarmYN(alarmYN);

			doMergeTransaction(mgr, originEvent);

			try {
				alarmService.updateAlarmQueue(originEvent.getEventId());
			} catch (Exception ex) {}
			
			try {
				Users loginUser = getCurrentUser();
				activityService.insertActivities(activityService.createEventActivity(originEvent, null,
						ActivityType.UPDATE_ALARM, loginUser));
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());	// Ignored. Not a critical part of application.
			}
			
			return originEvent;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Events removeEvents(String eventId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			Events event = doFind(mgr, Events.class, eventId);
			if (event != null) {
				event.setDeleteYN(Y);
				event.setDeleted(new Date());

				doMergeTransaction(mgr, event);

				try {
					removeEventIndex(eventId);
					alarmService.removeAlarmTaskQueue(event);
				} catch (Exception ex) {}

				try {
					activityService.insertActivities(activityService.createEventActivity(event, null,
							ActivityType.DELETED, loginUser));
				} catch (Exception ex) {
					LOG.warning(ex.getMessage());	// Ignored. Not a critical part of application.
				}
			}
			
			return event;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public EventIndex createOrUpdateEventIndex(Events event) {
		try {
			EventIndex eventIndex = null;
			
			if (event != null) {
				eventIndex = new EventIndex(event);
				SearchManager sm = new SearchManager();
				sm.createIndex(eventIndex);
			}
			
			return eventIndex;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}
	
	private void removeEventIndex(String eventId) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.deleteDocuments(EventIndex.class, eventId);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}

	//---------------------------------------------------------------------------------------------------------------------------------
	//--> User Anniversary Events Functions <--// 
	private List<Events> queryAnniversaryEventAlarms(Date startDate, Date endDate) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<Events> anniversaryEventAlarms = new ArrayList<Events>();
			
			if (endDate == null) { endDate = CalendarUtil.addDay(startDate, ANNIVERSARY_QUERY_DAYS); }
			
			List<Events> anniversaryEventList = getDomainMemberAnniversaryEventList(mgr);
			/** 멤버와 관련된 이벤트 (생일) */
			if (anniversaryEventList != null) {
				for (Events event : anniversaryEventList) {
					anniversaryEventAlarms.addAll(RecurrenceUtil.getInstancesWithLunar(event, startDate, endDate));
				}
			}
			return anniversaryEventAlarms;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private List<Events> getDomainMemberAnniversaryEventList(EntityManager mgr) throws Exception {
		try {
			final String domainId = KeyUtil.createDomainKeyString(NamespaceManager.get());
			AnniversaryUtil anniversaryUtil = new AnniversaryUtil();
			List<Users> memberList = userService.listUsers(mgr, true, true);
			for (Users user : memberList) {
				anniversaryUtil.addAnniversary(user);
			}
			return anniversaryUtil.createAnniversaryEventList(domainId, null);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Events getUserAnniversaryEvent(String userId, AnniversaryType anniversaryType) throws Exception {
		try {
			List<Events> userEventList = getUserAnniversaryEventList(userId);
			for (Events event : userEventList) {
				if (anniversaryType.equals(event.getAnniversaryType())) { return event; }
			}
			return null;
		} catch (Exception ex) {
			throw ex;
		}
	}
	private List<Events> getUserAnniversaryEventList(String userId) throws Exception {
		try {
			final String domainId = KeyUtil.createDomainKeyString(KeyFactory.stringToKey(userId).getNamespace());
			AnniversaryUtil anniversaryUtil = new AnniversaryUtil();
			anniversaryUtil.addAnniversary(userService.getUsers(userId, true));
			return anniversaryUtil.createAnniversaryEventList(domainId, null);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public List<Events> listDomainAnniversaryNextAlarms() throws Exception {
			// 시간값이 계속 변하기때문에 memcache를 사용할 필요없다.
		Date startDate = new Date();
		Date endDate = CalendarUtil.addDay(startDate, ANNIVERSARY_QUERY_DAYS);
		List<Events> eventAlarms = queryAnniversaryEventAlarms(startDate, endDate);
		List<Events> alarmList = new ArrayList<Events>();
		for (Events event : eventAlarms) {
			Events alarmEvent = RecurrenceUtil.nextAlarm(event, startDate);
			if (alarmEvent != null) {
				alarmList.add(alarmEvent);
			}
		}
		return alarmList;
	}
	
	@Override
	public List<Events> listUserAnniversaryNextAlarm(String userId) throws Exception {
		List<Events> eventList = getUserAnniversaryEventList(userId);
		List<Events> alarmEventList = new ArrayList<Events>();
		
		for (Events event : eventList) {
			if (event != null && isValid(event)) {
				if (Y.equals(event.getActiveYN()) && Y.equals(event.getAlarmYN())) {
					Date startDate = new Date();
					Events alarmEvent = RecurrenceUtil.nextAlarm(event, startDate);
					if (alarmEvent != null) { alarmEventList.add(alarmEvent); }
				}
			}
		}
		return alarmEventList;
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public List<Events> queryTaskEventsForCalendar(
//			String domainId,
//			Collection<String> boardIdList,
//			Date startDate,
//			Date endDate) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			List<Events> eventList = new ArrayList<Events>();
//			List<Tasks> startDateTaskList = queryTaskStartDateForCalendar(mgr, domainId, boardIdList, startDate, endDate);
//			List<Tasks> dueDateTaskList = queryTaskDueDateForCalendar(mgr, domainId, boardIdList, startDate, endDate);
//			
//			for (Tasks task : startDateTaskList) {
//				if (!isValid(task)) { continue; } 
//			
//				if (!containsEventTasks(eventList, task)) {
//					eventList.add(convertTasksToEvents(task));
//				}
//			}
//			
//			for (Tasks task : dueDateTaskList) {
//				if (!isValid(task)) { continue; } 
//			
//				if (!containsEventTasks(eventList, task)) {
//					eventList.add(convertTasksToEvents(task));
//				}
//			}
//			
//			return eventList;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private List<Tasks> queryTaskStartDateForCalendar(
//			EntityManager mgr,
//			//String domainId,
//			Collection<String> boardIdList,
//			Date startDate,
//			Date endDate) throws Exception {
//		try {
//			List<Tasks> taskList = new ArrayList<Tasks>();
//			List<String> taskIds = taskService.listMyTaskIds(boardIdList);
//		
//			List<Tasks> results = batchListByKey(mgr, Tasks.class, taskIds);
//			
//			for (Tasks task : results) {
//				if (!Y.equals(task.getDisplayInCalendarYN())) { continue; }
//				if (!N.equals(task.getArchiveYN())) { continue; }
//				if (task.getStartDate() != null) {
//					if (startDate != null && startDate.compareTo(task.getStartDate()) > 0) { continue; }
//					if (endDate != null && endDate.compareTo(task.getStartDate()) < 0) { continue; }
//				}
//				taskList.add(task);
//			}
//			
//			return taskList;
//		} catch (Exception ex){
//			throw ex;
//		}
//	}
//	private List<Tasks> queryTaskDueDateForCalendar(
//			EntityManager mgr,
//			//String domainId,
//			Collection<String> boardIdList,
//			Date startDate,
//			Date endDate) throws Exception {
//		try {
//			List<Tasks> taskList = new ArrayList<Tasks>();
//			List<String> taskIds = taskService.listMyTaskIds(boardIdList);
//		
//			List<Tasks> results = batchListByKey(mgr, Tasks.class, taskIds);
//			
//			for (Tasks task : results) {
//				if (!Y.equals(task.getDisplayInCalendarYN())) { continue; }
//				if (!N.equals(task.getArchiveYN())) { continue; }
//				if (task.getDueDate() != null) {
//					if (startDate != null && startDate.compareTo(task.getDueDate()) > 0) { continue; }
//					if (endDate != null && endDate.compareTo(task.getDueDate()) < 0) { continue; }
//				}
//				taskList.add(task);
//			}
//			
//			return taskList;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	private Events convertTasksToEvents(Tasks task) {
//		Events event = null;
//		if (task != null) {
//			event = new Events();
//			
//			event.setKey(KeyUtil.createEventKey(task.getTaskId())); // temporary event key
//			event.setDomainId(task.getDomainId());
//			event.setBoardId(task.getBoardId());
//			event.setTitle(task.getTitle());
//			event.setSummary(task.getSummary());
//			event.setDescription(task.getDescription());
//			event.setTaskId(task.getTaskId());
//			event.setEventType(EventType.TASK);
//			event.setStartDate(task.getStartDate());
//			event.setEndDate(task.getDueDate());
//			event.setCreated(task.getCreated());
//			event.setCreator(task.getCreator());
//			event.setEditableYN(N);
//			event.setActiveYN(Y);
//			
//			if (task.getStartDate() != null) {
//				event.setRecurrenceId(task.getStartDate().getTime());
//				event.setRecurrenceDate(task.getStartDate());
//			} else {
//				event.setRecurrenceId(task.getDueDate().getTime());
//				event.setRecurrenceDate(task.getDueDate());
//			}
//		}
//		return event;
//	}
//	@Deprecated
//	private boolean containsEventTasks(List<Events> eventList, Tasks task) {
//		for (Events event : eventList) {
//			if (task.getTaskId().equals(event.getTaskId())) {
//				return true;
//			}
//		}
//		
//		return false;
//	}
//	@Override
//	public List<Events> getInstances(
//			String eventId,
//			Date startDate,
//			Date endDate
//			) throws Exception {
//		List<Events> eventList = new ArrayList<Events>();
//
//		Events event = getEvents(eventId);
//		if (event != null && isValid(event)) {
//			if (Y.equals(event.getActiveYN())) {
//				eventList = RecurrenceUtil.getInstances(event, startDate, endDate);
//			}
//		}
//
//		return eventList;
//	}
//	@Override
//	public Events updateEventStartDate(String eventId, Date startDate) throws Exception {
//		Events event = new Events();
//		event.setEventId(eventId);
//		event.setStartDate(startDate);
//		
//		return updatePortionOfEvents(event, ActivityType.UPDATE_EVENT_STARTDATE);
//	}
//	@Deprecated
//	@Override
//	public Events updateEventEndDate(String eventId, Date endDate) throws Exception {
//		Events event = new Events();
//		event.setEventId(eventId);
//		event.setEndDate(endDate);
//		
//		return updatePortionOfEvents(event, ActivityType.UPDATE_EVENT_ENDDATE);
//	}
//	@Override
//	public int bulkRemoveEvents (
//			String domainId,
//			Collection<String> boardIdList
//			//EventType eventType,
//			//String alarmYN,
//			//String activeYN,
//			//Date startDate,
//			//Date endDate
//			) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Set<String> boardIdSet = null;
//			int resultCount = 0;
//			
//			if (boardIdList != null && boardIdList.size() > CommonProperty.SUBQUERY_PARAM_COUNT) {
//				boardIdSet = new HashSet<String>();
//				for (String boardId : boardIdList) { boardIdSet.add(boardId); }
//				boardIdList = null;
//			}
//			
//			TypedQuery<Events> query = new QueryBuilder<>(Events.class)
////					.addClause(FLD.domainId, domainId)	// unnecessary condition
//					.addFilter(FLD.boardId, boardIdList)
//					//.addClause(FLD.eventType, eventType)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.activeYN, null)
//					//.addClause(FLD.recurrenceYN, Y)
//					//.addGEClause(FLD.startDate, startDate, SortDirection.ASC)
//					//.addLEClause(FLD.startDate, endDate, SortDirection.ASC)
//					.build(mgr);
//
//			//List<Events> eventList = query.getResultList();
//			List<Events> eventList = queryResults(query);
//			for (Events event : eventList) {
//				if (boardIdSet != null && !boardIdSet.contains(event.getBoardId())) { continue; }
//				permanentRemoveEvents(event.getEventId());
//				resultCount++;
//			}
//			
//			return resultCount;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private void permanentRemoveEvents(String eventId) {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Events event = doFind(mgr, Events.class, eventId);
//			doRemoveTransaction(mgr, event);
//			
//			try {
//				removeEventIndex(eventId);
//				alarmService.removeAlarmTaskQueue(event);
//			} catch (Exception ex) {}
//			
//			try {
//				Users loginUser = getCurrentUser();
//				activityService.insertActivities(activityService.createEventActivity(event, null, ActivityType.DELETED, loginUser));
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<

	
	
	
// =====================================================================================
// --> Calendar
// =====================================================================================
//	@Override
	public List<Calendars> listMyCalendars(Boolean primary, CalendarAccessRole accessRole) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			TypedQuery<Calendars> query = new QueryBuilder<>(Calendars.class)
					.addClause(FLD.userId, loginUser.getUserId())
					.addClause(FLD.primary, primary)
					.addClause(FLD.accessRole, accessRole)
					.build(mgr);
			return queryResults(query);
		} finally {
			finalizeTransaction(mgr);
		}
	}
//	@Override
	public List<Events> listMyCalendarEvents(Boolean primary, CalendarAccessRole accessRole) throws Exception {
		List<Calendars> myCalendars = listMyCalendars(primary, accessRole);
		List<Events> myEvents = new ArrayList<Events>();

		for (Calendars myCalendar : myCalendars) {
			List<Events> events = CalendarConverter.convertEventFromCalendar(myCalendar.getEvents().getValue(), EventType.PRIVATE);
			if (events != null) { myEvents.addAll(events); }
		}

		return myEvents;
	}
//	@Override
//	public Calendars getCalendar(String calendarId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, Calendars.class, calendarId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Events> getMyCalendarEvents(String calendarId) throws Exception {
//		Calendars myCalendar = getCalendar(calendarId);
//		return CalendarConverter.convertEventFromCalendar(myCalendar.getEvents().getValue(), EventType.PRIVATE);
//	}
//	@Override
//	public Calendars insertCalendar(Calendars calendar) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			return insertCalendar(mgr, calendar);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Calendars updateCalendar(Calendars calendar) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return updateCalendar(mgr, calendar);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public void removeCalendar(String calendarId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			doRemoveTransaction(mgr, Calendars.class, calendarId);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
// =====================================================================================
// --> Calendar
// =====================================================================================

}
