package net.forecs.coconut.endpoint.calendar;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.AlarmTriggerType;
import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.RecurrenceChangeType;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.calendar.Calendars;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.search.index.EventIndex;

import com.google.appengine.api.datastore.Text;


public interface ICalendarService extends ICommonService {
	public abstract List<Events> queryInstances(
			String boardId,
			Collection<EventType> eventTypeList,
			String alarmYN,
			String activeYN,
			Date startDate,
			Date endDate) throws Exception;
	public abstract List<Events> queryInstanceForDashboard (
				Collection<String> userIdList,
				Collection<EventType> eventTypeList,
				Date startDate,
				Date endDate) throws Exception;
	public abstract List<Events> queryNextAlarms(String boardId) throws Exception;

	public abstract Events getEvents(String eventId);
	public abstract Events getEvents(EntityManager mgr, String eventId);
	public abstract Events nextAlarm(String eventId) throws Exception;
	public abstract Events insertEvents(Events event) throws Exception;
	public abstract Events updateEvents(Events event) throws Exception;
	public abstract Events removeEvents(String eventId) throws Exception;
	/**
	 * @Description : 반복설정이 있는 이벤트의 변경
	 *              : 일정 변경경시 eventId와 eventGroupId가 같으면 반복일정을 변경할 수 있으나
	 *              : eventId와 eventGroupId가 틀린경우에는 파생된 이벤트이므로 반복일정은 불가하고 날짜 혹은 시간대만 변경가능하다.
	 * @param recurrenceChangeType : ONLY(해당 이벤트만 변경), ALL(이번 일정에 상관없이 모두 변경, AFTER(이후 일정만 변경)
	 */
	public abstract Events updateEventRecurrence(RecurrenceChangeType recurrenceChangeType, Events event) throws Exception;
	public abstract Events updateEventTitle(String eventId, String title) throws Exception;
	public abstract Events updateEventType(String eventId, EventType eventType) throws Exception;
	public abstract Events updateEventDate(String eventId, Date startDate, Date endDate) throws Exception;
	public abstract Events updateEventAllDay(String eventId, String allDayYN) throws Exception;
	public abstract Events updateEventDescription(String eventId, Text description) throws Exception;
	public abstract Events updateEventLocation(String eventId, String location) throws Exception;
	public abstract Events updateEventAlarm(
			String eventId,
//			Date alarmDateTime, 
			AlarmTriggerType alarmTriggerType, 
			Integer alarmTriggerValue, 
			String alarmYN) throws Exception;
	
	public abstract EventIndex createOrUpdateEventIndex(Events event);
	
	public abstract Events getUserAnniversaryEvent(String userId, AnniversaryType anniversaryType) throws Exception;
	public abstract List<Events> listDomainAnniversaryNextAlarms() throws Exception;
	public abstract List<Events> listUserAnniversaryNextAlarm(String userId) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract List<Events> queryEventsForRecurrence (
//			String domainId,
//			Collection<String> boardIdList,
//			Collection<EventType> eventTypeList,
//			String alarmYN,
//			String activeYN,
//			Date startDate,
//			Date endDate) throws Exception;
//	public abstract List<Events> queryTaskEventsForCalendar(
//			String domainId,
//			Collection<String> boardIdList,
//			Date startDate,
//			Date endDate) throws Exception;
//	public abstract List<Events> getInstances(
//			String eventId,
//			Date startDate,
//			Date endDate
//			) throws Exception;
//	public abstract void permanentRemoveEvents(String eventId);
//	public abstract Events updateEventStartDate(String eventId, Date startDate) throws Exception;
//	public abstract Events updateEventEndDate(String eventId, Date startDate) throws Exception;
//	public abstract int bulkRemoveEvents (
//			String domainId,
//			Collection<String> boardIdList
//			//EventType eventType,
//			//String alarmYN,
//			//String activeYN,
//			//Date startDate,
//			//Date endDate
//			) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
	
	// =====================================================================================
	// --> Calendar
	// =====================================================================================
	/**
	 * @Description : 구글캘린더 동의 절차를 통해, 구글 캘린더를 가져오기흘 한 경우, 내가 가진 캘린더 목록을 가져온다.
	 * @Method      : listMyCalendars
	 * @param primary : 대표 캘린더인지 여부
	 * @param accessRole : owner, reader, freeBusyReader, writer
	 * @return CollectionResponse<Calendars>
	 * @throws Exception
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	//public abstract List<Calendars> listMyCalendars(Boolean primary, CalendarAccessRole accessRole) throws Exception;

	/**
	 * @Description : 내가 가진 구글 캘린더의 이벤트 목로을 가져온다.
	 * @Method      : listMyEvents
	 * @param primary : 대표 캘린더인지 여부
	 * @param accessRole : owner, reader, freeBusyReader, writer
	 * @return List<Events>
	 * @throws Exception
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	//public abstract List<Events> listMyCalendarEvents(Boolean primary, CalendarAccessRole accessRole) throws Exception;
	
	/**
	 * @Description : 저장된 구글 캘린더를 가져온다.
	 * @Method      : getCalendar
	 * @param calendarId : 구글 캘린더 ID를 이용
	 * @return net.forecs.coconut.entity.calendar.Calendars
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	//public abstract Calendars getCalendar(String calendarId);
	
	/**
	 * @Description : 저장된 캘린더의 이벤트 목록을 가져온다.(ical4j -> coconut event 변환)
	 * @Method      : getMyEvents
	 * @param calendarId
	 * @return List<Events>
	 * @throws Exception
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
//	public abstract List<Events> getMyCalendarEvents(String calendarId) throws Exception;
	
	/**
	 * @Description : 구글 캘린더를 가져올때 이 함수를 이용하여 내 캘린더에 저장하거나 변경한다.
	 * @Method      : insertOrUpdateCalendar
	 * @param calendar
	 * @param includeMergeProperty
	 * @return net.forecs.coconut.entity.calendar.Calendars
	 * @throws Exception
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	public abstract Calendars insertOrUpdateCalendar(Calendars calendar) throws Exception;
	
	/**
	 * @Description : 구글캘린더 목록 -> 목록별 goggle event -> coconut event변환 -> ical4 Calendar 변환 -> 저장
	 * @Method      : insertCalendar
	 * @param calendar
	 * @return net.forecs.coconut.entity.calendar.Calendars
	 * @throws Exception
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	//public abstract Calendars insertCalendar(Calendars calendar) throws Exception;
	
	/**
	 * @Description : 구글캘린더 목록 -> 목록별 goggle event -> coconut event변환 -> ical4 Calendar 변환 -> 변경
	 * @Method      : updateCalendar
	 * @param calendar
	 * @param includeMergeProperty
	 * @return net.forecs.coconut.entity.calendar.Calendars
	 * @throws Exception
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	//public abstract Calendars updateCalendar(Calendars calendar) throws Exception;
	
	/**
	 * 
	 * @Description : 내 캘린더 삭제
	 * @Method      : removeCalendar
	 * @param calendarId
	 * @throws Exception
	 * @Date        : 2015. 3. 25.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	//public abstract void removeCalendar(String calendarId) throws Exception;
	
	// =====================================================================================
	// <-- Calendar
	// =====================================================================================
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
