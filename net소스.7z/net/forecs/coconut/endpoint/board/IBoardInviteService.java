package net.forecs.coconut.endpoint.board;

import net.forecs.coconut.endpoint.common.ICommonService;

@Deprecated
public interface IBoardInviteService extends ICommonService {
//	public abstract QueryResult<BoardInvites> listBoardInvites (
//			String cursorString,
//			Integer limit,
//			String boardId) throws Exception;
//
//	public abstract BoardInvites invite(BoardInvites boardInvite, String baseUrl) throws Exception;
//	public abstract BoardInvites confirmInvite(String boardInviteId, String host) throws Exception;
//	public abstract BoardInvites getBoardInvites(String boardInviteId);
//	public abstract BoardInvites updateBoardInvites(BoardInvites boardinvites) throws Exception;
//	public abstract void removeBoardInvites(String boardInviteId);
}