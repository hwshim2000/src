package net.forecs.coconut.endpoint.board;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.CreateNoticeAuth;
import net.forecs.coconut.common.code.CreateScheduleAuth;
import net.forecs.coconut.common.code.CreateTaskAuth;
import net.forecs.coconut.common.code.PublicSearchRange;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.user.Users;


public interface IBoardService extends ICommonService {
	public abstract List<Users> assignMemberList(String boardId, List<String> userIdList/*, Auth auth*/) throws Exception;
	public abstract List<Users> unassignMemberList(String boardId, List<String> userIdList) throws Exception;
	public abstract Users removeMember(String boardId, String userId) throws Exception;
	public abstract Users changeOwnership(String boardId, String targetUserId) throws Exception;

	public abstract List<Boards> getMyBoards() throws Exception;
	public abstract List<Boards> getUserBoards(EntityManager mgr, Users user) throws Exception ;

	public abstract List<Users> getAssignedMemberList(String boardId) throws Exception;
	public abstract List<Users> getAssignedMemberList(EntityManager mgr, String boardId) throws Exception;
	public abstract List<Users> getAssignedMemberList(EntityManager mgr, List<Boards> boardList) throws Exception;
	public abstract List<Users> getUnassignedMemberList(String boardId) throws Exception;

	public abstract List<Boards> listGroupBoards(EntityManager mgr, String groupId) throws Exception;
	public abstract List<Boards> listBoards(String groupId, String closeYN,	PublicSearchRange publicSearchRange) throws Exception;
	
	public abstract Boards getBoards(String boardId) throws Exception;
	public abstract Boards getBoards(EntityManager mgr, String boardId) throws Exception;
	public abstract Boards insertBoards(Boards board) throws Exception;
	public abstract Boards updateBoards(Boards board) throws Exception;
	
	public abstract Boards updateBoardSettings(
			String boardId,
			PublicSearchRange publicSearchRange,
			CreateNoticeAuth createNoticeAuth,
			CreateTaskAuth createTaskAuth,
			CreateScheduleAuth createScheduleAuth) throws Exception;

	public abstract Boards openBoard(String boardId) throws Exception;
	public abstract Boards closeBoard(String boardId) throws Exception;
	public abstract boolean changeOrderBoards(List<String> boardIds) throws Exception;
	public abstract boolean isAvailableMemberAuth(String boardId, String userId);
	
//	public abstract Set<String> getUsersBoardForDashboard(EntityManager mgr, Users user, Collection<String> userIds) throws Exception;
	public abstract Set<String> getUserBoardIds(EntityManager mgr, Users user) throws Exception;
	public abstract Map<String, Boards> batchMapBoards(Collection<String> boardIds) throws Exception;
	
	public abstract Map<String, Object> getBoardItems(String boardId) throws Exception;
	public abstract void prepareBoardItems(String domainName, String userId) throws Exception;
	public abstract void prepareBoardItems(String domainName, String boardId, String userId) throws Exception;
	public abstract void prepareBoardItemsWithTaskQueue(String domainName, String userId) throws Exception;

//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract List<String> getUserBoardIdList(EntityManager mgr, String userId) throws Exception;//dashbard로 옮김
//	public abstract Users assignMember(String boardId, String userId/*, Auth auth*/) throws Exception;
//	public abstract Users unassignMember(String boardId, String userId) throws Exception;
////	Has no references.
//	public abstract boolean isMemberAuths(String boardId, Users user);
//	public abstract boolean isMemberAuths(MemberAuths memberAuth);
//	public abstract List<Users> getAssignedMemberList(Collection<String> boardIdList) throws Exception;
//	public abstract List<Users> getUnassignedMemberList(Collection<String> boardIdList) throws Exception;
//	public abstract Boards getBoards(EntityManager mgr, String boardId) throws Exception;
//	public abstract Boards renameBoards(String boardId, String title) throws Exception;
//	public abstract void removeBoards(String boardId) throws Exception;
//	public abstract Set<String> getUsersBoardForDashboard(Collection<String> userIdList) throws Exception;
//	public abstract Map<String, Boards> batchMapBoards(EntityManager mgr, Collection<String> boardIds) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}