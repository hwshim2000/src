package net.forecs.coconut.endpoint.board;

import net.forecs.coconut.endpoint.common.ICommonService;

@Deprecated
public interface ITasklistService extends ICommonService {
//	public abstract List<Tasklists> listBoardTasklists(EntityManager mgr, String boardId) throws Exception;
//	public abstract Map<String, List<Tasklists>> batchMapTasklists(EntityManager mgr, Collection<String> boardIds) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract Tasklists insertTasklists(EntityManager mgr, Tasklists tasklist) throws Exception;
//	public abstract Tasklists updateTasklists(Tasklists tasklist) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}