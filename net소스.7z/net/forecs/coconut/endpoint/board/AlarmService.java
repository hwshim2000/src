package net.forecs.coconut.endpoint.board;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.admin.UsageService;
import net.forecs.coconut.endpoint.calendar.ICalendarService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.taskqueue.InternalFailureException;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskAlreadyExistsException;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;


/**
 * @Project    : coconut
 * @Package    : net.forecs.coconut.endpoint.board
 * @FileName   : AlarmService.java
 * @Date       : 2015. 3. 26.
 * @Author     : hyeunwoo.shim@forecs.net
 * @Version    :
 * @Histories  :
 * @Description: alarm 발생 관련 서비스
 */
public class AlarmService extends CommonService implements IAlarmService {
	private static final Logger LOG = Logger.getLogger(AlarmService.class.getName());
	
	private final ICalendarService calendarService;
	private final IActivityService activityService;
	private final IUserService userService;
	
	@Inject
	public AlarmService(ICalendarService calendarService, IActivityService activityService, IUserService userService) {
		this.calendarService = calendarService;
		this.activityService = activityService;
		this.userService = userService;
	}
	
	/**
	 * TODO Checklist
	 * 1. 스케줄러에 invokeAlarmExecutor를 주기적으로 호출하기 위한 스케줄러를 등록
	 * 2. Property파일에 관련 property 등록
	 * 3. Channel을 같이 사용할 것인지 alarm 만을 위한 channel을 둘것인지 결정
	 * 4. 같이 쓸 경우, 서로 주고받는 Message 구조를 같이 활용해야하는 불편함
	 * 5. 다르게 쓸 경우, token 발행 및 alarm 채널을 별도 생성해야하는 부담감.
	 * 6. Task Queue에 한꺼번에 등록하는 limit 확인하여 코딩
	 */
	@Override
	public void invokeAlarmExecutor(EventType eventType) {
		try {
			QueryResult<Domains> queryResult = listDomains(null, null);
			List<Domains> domains = queryResult.getResultList();

			Queue queue = QueueFactory.getQueue(CommonProperty.ALARM_INVOKE_QUEUE_NAME);

			int invokedDomains = 0;
			for (Domains domain : domains) {
				TaskOptions taskOption = TaskOptions.Builder
			            .withUrl(CommonProperty.ALARM_EXECUTE_URL)
			            .param(PARAM.DOMAINNAME, domain.getDomainName())
			            .method(Method.POST);
			            //.taskName(domain.getDomainName());
				if (eventType != null) {
					taskOption = taskOption.param(PARAM.EVENTTYPE, eventType.toString());
				}

				// Noti가 발생해야할 시점을 계산하여 Queue에 넣는다.
				try { queue.add(taskOption); invokedDomains++; } catch (Exception ex) { LOG.warning(ex.getMessage()); }
			}
			LOG.warning(String.format("[INFO] Totoal Domains(%d) Invoked Domains(%d)", domains.size(), invokedDomains));
		} catch (TaskAlreadyExistsException ex) {
			//LOG.warning("[Alarm invoke failure]" + ex.getMessage());
		} catch (InternalFailureException ex) {
			LOG.warning("[Alarm invoke failure]" + ex.getMessage());
		} catch (IllegalStateException ex) {
			LOG.warning("[Alarm invoke failure]" + ex.getMessage());	
		} catch (Exception ex) {
			LOG.warning("[Alarm invoke failure]" + ex.getMessage());
		}
	}

	@Override
	public void executeAlarms(String domainName, EventType eventType) {
		if (StringUtils.isBlank(domainName)) {
			LOG.warning("[INFO] domainName is null.");
			return;
		}

		String prevNamespace = NamespaceManager.get();
		
		try {
			UsageService.validExpiration(domainName);
			NamespaceManager.set(domainName);
			
//			UsageService.validUsage();
			
			if (EventType.ANNIVERSARY.equals(eventType)) {
				executeAnniversaryAlarms(domainName);				
			} else {
				executeAlarms(domainName);	
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	private void executeAlarms(String domainName) {
		try {
			List<Events> eventAlarms = calendarService.queryNextAlarms(null);
			if (eventAlarms == null) { LOG.warning("[INFO] no more alarms!"); return; }
			
			for (Events event : eventAlarms) {
				Queue queue = QueueFactory.getQueue(CommonProperty.ALARM_QUEUE_NAME);
				// 등록되지 않은 Queue를 삭제시 Exception 발생하나, 무시해야 다음단계로 진행
				// why? queue에서 현재 등록된 eventId 에 해당하는 queue를 확인할 방법이 없는관계로 있던 없던간에 무조건 삭제시도
				try {
					removeAlarmTaskQueue(event, queue);
				} catch (Exception ex) {}
				
				if (Y.equals(event.getAlarmYN()) && event.getAlarmDateTime() != null) {
					TaskOptions taskOption = createAlarmTaskOptions(event);
					// 지정된 Alarm시간에 Alarm이 발생하도록 시간 설정
					//--> for alarm monitoring
					LOG.warning(String.format("[INFO] : %s %s %s", domainName, event.getEventId(), CalendarUtil.toString(event.getAlarmDateTime(), "yyyy-MM-dd HH:mm:ss")));
					//<--
					try {
						queue.add(taskOption.etaMillis(event.getAlarmDateTime().getTime()));
					} catch (Exception ex) {
						LOG.warning(ex.getMessage());
					}
				}
			}
			updateAlarmQueueTaskName(eventAlarms);
		} catch (TaskAlreadyExistsException ex) {
			//LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (InternalFailureException ex) {
			LOG.warning(String.format("[Alarm Internal failure] %s", ex.getMessage(), domainName));
		} catch (IllegalStateException ex) {
			LOG.warning(String.format("[Alarm IllegalState failure] %s", ex.getMessage(), domainName));
		} catch (Exception ex) {
			LOG.warning(String.format("[Alarm failure] %s", ex.getMessage(), domainName));
		}
	}

	@Override
	public void updateAlarmQueue(String eventId) {
		try {
			// 해당 이벤트의 현재 시점이후 최초로 발생하는 event instance를 가져온다.
			// 여기서의 event는 Recurrence에의 생성된 최초의 instance를 뜻한다.
			Events event =  calendarService.nextAlarm(eventId);
			// 등록되지 않은 Queue를 삭제시 Exception 발생하나, 무시해야 다음단계로 진행
			// why? queue에서 현재 등록된 eventId 에 해당하는 queue를 확인할 방법이 없는관계로 있던 없던간에 무조건 삭제시도
			if (event != null) {
				Queue queue = QueueFactory.getQueue(CommonProperty.ALARM_QUEUE_NAME);
				
				try {
					removeAlarmTaskQueue(event, queue);
				} catch (Exception ex) {}
				
				if (Y.equals(event.getAlarmYN()) && event.getAlarmDateTime() != null) {
					TaskOptions taskOption = createAlarmTaskOptions(event);
					// 지정된 Alarm시간에 Alarm이 발생하도록 시간 설정
					try { queue.add(taskOption.etaMillis(event.getAlarmDateTime().getTime())); } catch (Exception ex) { LOG.warning(ex.getMessage()); }
				}
				updateAlarmQueueTaskName(event);
			}
		} catch (TaskAlreadyExistsException ex) {
			//LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (InternalFailureException ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (IllegalStateException ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (Exception ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		}
	}

	@Override
	public void pushAlarms(String domainName, String eventId, String alarmDateTimeMillis) {
		String prevNamespace = NamespaceManager.get();

		try {
			NamespaceManager.set(domainName);

			if (StringUtils.isBlank(eventId)) { return; }

			Events event = calendarService.getEvents(eventId);
			if (event != null) {
				Date alarmDateTime = new Date(Long.parseLong(alarmDateTimeMillis));
				event.setAlarmDateTime(alarmDateTime);

				ActivityType activityType = ActivityType.ALARM;
//				if (AnniversaryType.BIRTH.equals(event.getAnniversaryType())) {
//					activityType = ActivityType.ALARM_BIRTH;
//				} else if (AnniversaryType.WEDDING.equals(event.getAnniversaryType())) {
//					activityType = ActivityType.ALARM_WEDDING;
//				}
				Activities activity = activityService.createEventActivity(event, event.getTitle(), activityType, null);
				activityService.insertActivities(activity);
			}
		} catch (Exception ex) {
			LOG.warning("[Alarm push failure]" + ex.getMessage());
		} finally {
//			// alarm을 실행후에 새로운 알람을 등록하는부분
//			// TODO : 곧바로 AlarmQueue에 event를 등록해야할 필요성부터 검토(오류 가능성은? 같은 이벤트를 발생할 수 있지 않을까?)
//			try {
//				updateAlarmQueue(eventId);
//			} catch (Exception ex) {
//				LOG.warning("[Alarm update failure]" + ex.getMessage());
//			}
			NamespaceManager.set(prevNamespace);
		}
	}
	
	/**
	 * @Description : Task Queue에 등록하기위한 Alarm TaskOption 설정
	 * @Method      : createAlarmTaskOptions
	 * @param event
	 * @return TaskOptions
	 * @Date        : 2015. 3. 26.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	private TaskOptions createAlarmTaskOptions(Events event) {
		// 큐에 Task 등록
		// 중복되어 발생한 예외는 정상. (없으면 등록/있으면 무시)
		// 단, Event의 알람이 변경되는 경우에는 Queue에서 제거 후 등록
		event.setTaskName(createAlarmQueueTaskName(event));
		
		TaskOptions taskOption = TaskOptions.Builder
	            .withUrl(CommonProperty.ALARM_PUSH_URL)
	            .param(PARAM.DOMAINNAME, event.getKey().getNamespace())
	            .param(PARAM.EVENTID, event.getEventId())
	            .param(PARAM.ALARMDATETIMEMILLS, String.valueOf(event.getAlarmDateTime().getTime()))
	            .method(Method.POST)
	            .taskName(event.getTaskName());
		
		return taskOption;
	}

	private String createAlarmQueueTaskName(Events event) {
		return String.format("%s-%d", event.getEventId(), new Date().getTime());
	}

	private void updateAlarmQueueTaskName(Events event) {
		EntityManager mgr = getEntityManager();
		
		try {
			doMergeTransaction(mgr, event);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void updateAlarmQueueTaskName(List<Events> eventList) {
		EntityManager mgr = getEntityManager();
		
		try {
			doMergeTransaction(mgr, eventList);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeAlarmTaskQueue(Events event) {
		if (event == null) { return; }
		try {
			removeAlarmTaskQueue(event, QueueFactory.getQueue(CommonProperty.ALARM_QUEUE_NAME));
		} catch (Exception ex) {
			LOG.warning("[INFO - DELETE Notification Queue Exception] : " + ex.getMessage());
		}
	}
	
	private void removeAlarmTaskQueue(Events event, Queue queue) {
		if (event == null) { return; }
		try {
			// 이전에 Queue에 Notification이 있었다면 지운다. 없을때 발생하는 에러는 무시한다.
			String taskName = event.getTaskName();
			if (StringUtils.isNotEmpty(taskName)) {
				queue.deleteTask(taskName);
			}
		} catch (Exception ex) {
			LOG.warning("[INFO - DELETE Notification Queue Exception] : " + ex.getMessage());
		}
	}
	
	//---------------------------------------------------------------------------------------------------------------------------------
	//--> User Anniversary Event Alarm Functions <--//
	private void executeAnniversaryAlarms(String domainName) {
		try {
			List<Events> eventAlarms = calendarService.listDomainAnniversaryNextAlarms();
			List<UserProfiles> profileList = new ArrayList<UserProfiles>();
			
			Map<String, Users> usersMap = batchMapAnniversaryAlarmUsers(eventAlarms);
			for (Events event : eventAlarms) {
				Users user = usersMap.get(event.getOwner());
				if (!isValid(user) || user.getUserProfiles() == null) { continue; }
				
				Queue queue = QueueFactory.getQueue(CommonProperty.ALARM_QUEUE_NAME);
				// 등록되지 않은 Queue를 삭제시 Exception 발생하나, 무시해야 다음단계로 진행
				// why? queue에서 현재 등록된 eventId 에 해당하는 queue를 확인할 방법이 없는관계로 있던 없던간에 무조건 삭제시도
				try {
					removeAnniversaryAlarmTaskQueue(user, event, queue);
				} catch (Exception ex) {}
				
				if (Y.equals(event.getAlarmYN()) && event.getAlarmDateTime() != null) {
					user.setUserProfiles(putAnniversaryTaskName(user, event));
					//profile.setTaskNames(createAnniversaryAlarmQueueTaskName(event));
					TaskOptions taskOption = createAnniversaryAlarmTaskOptions(user, event);
					// 지정된 Alarm시간에 Alarm이 발생하도록 시간 설정
					//--> for alarm monitoring
					LOG.warning(String.format("[INFO : %s] %s %s", domainName, event.getEventId(), CalendarUtil.toString(event.getAlarmDateTime(), "yyyy-MM-dd HH:mm:ss")));
					//<--
					try {
						queue.add(taskOption.etaMillis(event.getAlarmDateTime().getTime()));
						profileList.add(user.getUserProfiles());
					} catch (Exception ex) {
						LOG.warning(ex.getMessage());
					}
				}
			}
			updateAnniversaryAlarmTaskName(profileList);
		} catch (TaskAlreadyExistsException ex) {
			//LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (InternalFailureException ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (IllegalStateException ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (Exception ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		}
	}
	
	@Override
	public void updateAnniversaryAlarmQueue(String userId) {
		try {
			Users user = userService.getUsers(userId, true);
			if (user == null || user.getUserProfiles() == null) { return; }
			//if (!isValid(user) || user.getUserProfiles() == null) { return; } // inactive 사용자의 알람을 없애기 위해서 isValid를 이부분에서 사용하면 안됨.
			
			List<Events> eventAlarms = calendarService.listUserAnniversaryNextAlarm(userId);
			List<UserProfiles> profileList = new ArrayList<UserProfiles>();
			
			for (Events event : eventAlarms) {
				Queue queue = QueueFactory.getQueue(CommonProperty.ALARM_QUEUE_NAME);
				// 등록되지 않은 Queue를 삭제시 Exception 발생하나, 무시해야 다음단계로 진행
				// why? queue에서 현재 등록된 eventId 에 해당하는 queue를 확인할 방법이 없는관계로 있던 없던간에 무조건 삭제시도
				try {
					removeAnniversaryAlarmTaskQueue(user, event, queue);
				} catch (Exception ex) {}
				
				//--> 2016-05-09 : 사용자가 active일때만 알람을 등록하도록 변경
				if (user.isActive() && Y.equals(event.getAlarmYN()) && event.getAlarmDateTime() != null) {
					user.setUserProfiles(putAnniversaryTaskName(user, event));
					//profile.setTaskNames(createAnniversaryAlarmQueueTaskName(event));
					TaskOptions taskOption = createAnniversaryAlarmTaskOptions(user, event);
					// 지정된 Alarm시간에 Alarm이 발생하도록 시간 설정
					//--> for alarm monitoring
					LOG.warning(String.format("[INFO : %s] %s %s", event.getKey().getNamespace(), event.getEventId(), CalendarUtil.toString(event.getAlarmDateTime(), "yyyy-MM-dd HH:mm:ss")));
					//<--
					try {
						queue.add(taskOption.etaMillis(event.getAlarmDateTime().getTime()));
						profileList.add(user.getUserProfiles());
					} catch (Exception ex) {
						LOG.warning(ex.getMessage());
					}
				}
			}
			updateAnniversaryAlarmTaskName(profileList);
		} catch (TaskAlreadyExistsException ex) {
			//LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (InternalFailureException ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (IllegalStateException ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		} catch (Exception ex) {
			LOG.warning("[Alarm failure]" + ex.getMessage());
		}
	}
	
	@Override
	public void pushAnniversaryAlarms(String domainName, String userId, AnniversaryType anniversaryType, String eventDateTimeMills, String alarmDateTimeMillis) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);

		try {
			if (StringUtils.isBlank(userId)) { return; }
			final Users user = userService.getUsers(userId, false);
			if (user != null && !user.isActive()) { return; }

			Events event = calendarService.getUserAnniversaryEvent(userId, anniversaryType);
			if (event != null) {
				Date alarmDateTime = new Date(Long.parseLong(alarmDateTimeMillis));
				Date recurrenceDateTime = new Date(Long.parseLong(eventDateTimeMills));
				event.setAlarmDateTime(alarmDateTime);
				event.setRecurrenceDate(recurrenceDateTime);

				ActivityType activityType = ActivityType.ALARM_BIRTH;
				if (AnniversaryType.WEDDING.equals(anniversaryType)) {
					activityType = ActivityType.ALARM_WEDDING;
				}
				Activities activity = activityService.createEventActivity(event, event.getTitle(), activityType, null);
				activityService.insertActivities(activity);
			}
		} catch (Exception ex) {
			LOG.warning("[Anniversary Alarm push failure]" + ex.getMessage());
		} finally {
//			// alarm을 실행후에 새로운 알람을 등록하는부분
//			// TODO : 곧바로 AlarmQueue에 event를 등록해야할 필요성부터 검토(오류 가능성은? 같은 이벤트를 발생할 수 있지 않을까?)
//			try {
//				updateAlarmQueue(eventId);
//			} catch (Exception ex) {
//				LOG.warning("[Alarm update failure]" + ex.getMessage());
//			}
			NamespaceManager.set(prevNamespace);
		}
	}
	
	private TaskOptions createAnniversaryAlarmTaskOptions(Users user, Events event) {
		// 큐에 Task 등록
		// 중복되어 발생한 예외는 정상. (없으면 등록/있으면 무시)
		// 단, Event의 알람이 변경되는 경우에는 Queue에서 제거 후 등록
		TaskOptions taskOption = TaskOptions.Builder
	            .withUrl(CommonProperty.ALARM_PUSH_URL)
	            .param(PARAM.DOMAINNAME, user.getKey().getNamespace())
	            .param(PARAM.USERID, user.getUserId())
	            .param(PARAM.EVENTTYPE, EventType.ANNIVERSARY.toString())
	            .param(PARAM.ANNIVERSARYTYPE, event.getAnniversaryType().toString())
	            .param(PARAM.EVENTDATETIMEMILLS, String.valueOf(event.getRecurrenceDate().getTime()))
	            .param(PARAM.ALARMDATETIMEMILLS, String.valueOf(event.getAlarmDateTime().getTime()))
	            .method(Method.POST);
		String taskName = getAnniversaryTaskName(user, event);
		if (StringUtils.isNotBlank(taskName)) {
	           taskOption = taskOption.taskName(taskName);
		}
	           //.taskName(user.getUserProfiles().getTaskNames());
		
		return taskOption;
	}
	private UserProfiles putAnniversaryTaskName(Users user, Events event) throws Exception {
		try {
			ObjectMapper om = new ObjectMapper();
			Map<String, String> resultMap = null;
			UserProfiles profile = user.getUserProfiles();
			if (StringUtils.isNotBlank(profile.getTaskNames())) {
				resultMap = om.readValue(profile.getTaskNames(), new TypeReference<HashMap<String, String>>() {});
				if (resultMap == null) { resultMap = new HashMap<String, String>(); }
			} else {
				resultMap = new HashMap<String, String>();
			}
			String newTaskName = createAnniversaryAlarmQueueTaskName(event);
			resultMap.put(event.getAnniversaryType().toString(), newTaskName);
			profile.setTaskNames(om.writeValueAsString(resultMap));
			return profile;
		} catch (Exception ex) {
			throw ex;
		}
	}
	private String getAnniversaryTaskName(Users user, Events event) {
		try {
			UserProfiles profile = user.getUserProfiles();
			if (StringUtils.isBlank(profile.getTaskNames())) {
				return null;
			}
			ObjectMapper om = new ObjectMapper();
			Map<String, String> resultMap = om.readValue(profile.getTaskNames(), new TypeReference<HashMap<String, String>>() {});
			if (resultMap == null) { return null; }
			
			return resultMap.get(event.getAnniversaryType().toString());
		} catch (Exception ex) {
			return null;
		}
	}
	private String createAnniversaryAlarmQueueTaskName(Events event) throws Exception {
		return String.format("%s-%s-%d", event.getOwner(), event.getAnniversaryType(), new Date().getTime());
	}
	
	private void updateAnniversaryAlarmTaskName(List<UserProfiles> profileList) {
		EntityManager mgr = getEntityManager();
		
		try {
			doMergeTransaction(mgr, profileList);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void removeAnniversaryAlarmTaskQueue(Users user, Events event, Queue queue) {
		if (user == null || user.getUserProfiles() == null) { return; }
		try {
			// 이전에 Queue에 Notification이 있었다면 지운다. 없을때 발생하는 에러는 무시한다.
			//String taskName = user.getUserProfiles().getTaskNames();
			String taskName = getAnniversaryTaskName(user, event);
			if (StringUtils.isNotEmpty(taskName)) {
				queue.deleteTask(taskName);
			}
		} catch (Exception ex) {
			LOG.warning("[INFO - DELETE Notification Queue Exception] : " + ex.getMessage());
		}
	}
	
	private Map<String, Users> batchMapAnniversaryAlarmUsers(List<Events> eventAlarms) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Set<String> userIds = new HashSet<String>();
			for (Events event : eventAlarms) {
				userIds.add(event.getOwner());
			}
			return userService.batchMapUsers(mgr, userIds, true);
		} finally {
			finalizeTransaction(mgr);
		}
	}
}
