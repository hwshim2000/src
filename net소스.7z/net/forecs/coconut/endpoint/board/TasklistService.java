package net.forecs.coconut.endpoint.board;

import net.forecs.coconut.endpoint.common.CommonService;

@Deprecated
public class TasklistService extends CommonService implements ITasklistService {
//	@Override
//	public List<Tasklists> listBoardTasklists(EntityManager mgr, String boardId) throws Exception {
//		List<Key> keys = listTasklistKeys(boardId);
//		List<Tasklists> tasklists = batchListByKey(mgr, Tasklists.class, keys);
//			
//		return new ArrayList<Tasklists>(tasklists);
//	}

//	@Override
//	public Map<String, List<Tasklists>> batchMapTasklists(EntityManager mgr, Collection<String> boardIds) throws Exception {
//		try {
//			Map<String, List<Tasklists>> resultMap = new HashMap<String, List<Tasklists>>();
//			List<Key> keys = listTasklistKeys(boardIds);
//			List<Tasklists> results = batchListByKey(mgr, Tasklists.class, keys);
//			
//			for (Tasklists tasklist : results) {
//				if (!resultMap.containsKey(tasklist.getBoardId())) { resultMap.put(tasklist.getBoardId(), new ArrayList<Tasklists>()); }
//				resultMap.get(tasklist.getBoardId()).add(tasklist);
//			}
//			
//			return resultMap;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	
//	private static List<Key> listTasklistKeys(String boardId) {
//		List<Key> keys = new ArrayList<Key>();
//		for (TaskStage taskStage : TaskStage.values()) {
//			keys.add(KeyUtil.createTasklistKey(boardId, taskStage.toString()));
//		}
//		return keys;
//	}
//	
//	private static List<Key> listTasklistKeys(Collection<String> boardIds) {
//		List<Key> keys = new ArrayList<Key>();
//		for (String boardId : boardIds) {
//			keys.addAll(listTasklistKeys(boardId));
//		}
//		return keys;
//	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public Tasklists insertTasklists(EntityManager mgr, Tasklists tasklist) throws Exception {
//		try {
//			if (contains(mgr, Tasklists.class, tasklist.getKey())) {
//				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Tasklists.class, tasklist.getTasklistId()));
//			}
//			doPersist(mgr, tasklist);
//		} catch (Exception ex) {
//			throw ex;
//		}
//		return tasklist;
//	}
//	@Override
//	public Tasklists updateTasklists(Tasklists tasklist) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			valid(tasklist);
//			doMergeTransaction(mgr, tasklist);
//			return tasklist;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
