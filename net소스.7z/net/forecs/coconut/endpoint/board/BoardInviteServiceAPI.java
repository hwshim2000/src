package net.forecs.coconut.endpoint.board;


//@Api(name = API.BOARD_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.BOARD_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class BoardInviteServiceAPI {
//	private final IBoardInviteService boardInviteService;
//	
//	@Inject
//	public BoardInviteServiceAPI(IBoardInviteService boardInviteService) {
//		this.boardInviteService = boardInviteService;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "invite", path = "boards/invite", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public BoardInvites invite(BoardInvites boardInvite, HttpServletRequest request) throws Exception {
//		CommonService.validNamespace(boardInvite.getBoardId());
//		String baseUrl = ServletUtil.getBaseUrl(request);
//		
//		return boardInviteService.invite(boardInvite, baseUrl);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "confirmInvite", path = "boards/invite/{boardInviteId}/confirm", httpMethod = HttpMethod.POST)
//	public void confirmInvite(HttpServletRequest request, @Named(FLD.boardInviteId) String boardInviteId) throws Exception {
//		boardInviteService.confirmInvite(boardInviteId, request.getRemoteHost());
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "listBoardInvites", path = "boards/invite", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<BoardInvites> listBoardInvites(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.boardId) String boardId) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		QueryResult<BoardInvites> queryResult = boardInviteService.listBoardInvites(cursorString, limit, boardId);
//		List<BoardInvites> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<BoardInvites>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getBoardInvites", path = "boards/invite/{boardInviteId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public BoardInvites getBoardInvites(@Named(FLD.boardInviteId) String boardInviteId) throws UnavailableException {
//		CommonService.validNamespace(boardInviteId);
//		return boardInviteService.getBoardInvites(boardInviteId);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "updateBoardInvites", path = "boards/invite", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public BoardInvites updateBoardInvites(BoardInvites boardinvites) throws Exception {
//		CommonService.validNamespace(boardinvites);
//		return boardInviteService.updateBoardInvites(boardinvites);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "removeBoardInvites", path = "boards/invite/{boardInviteId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeBoardInvites(@Named(FLD.boardInviteId) String boardInviteId) throws UnavailableException {
//		CommonService.validNamespace(boardInviteId);
//		boardInviteService.removeBoardInvites(boardInviteId);
//	}
}