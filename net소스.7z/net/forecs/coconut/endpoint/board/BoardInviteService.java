package net.forecs.coconut.endpoint.board;

import net.forecs.coconut.endpoint.common.CommonService;

@Deprecated
public class BoardInviteService extends CommonService implements IBoardInviteService {
//	private static final Logger LOG = Logger.getLogger(BoardInviteService.class.getName());
//	
//	private final IBoardService boardService;
//	private final IDomainService domainService;
//	private final IUserService userService;
//	private final IMemberAuthService memberAuthService;
//	private final IActivityService activityService;
//	
//	@Inject
//	public BoardInviteService(IBoardService boardService,
//			IDomainService domainService,
//			IUserService userService,
//			IMemberAuthService memberAuthService,
//			IActivityService activityService) {
//		this.boardService = boardService;
//		this.domainService = domainService;
//		this.userService = userService;
//		this.memberAuthService = memberAuthService;
//		this.activityService = activityService;
//	}
//
//	@Override
//	public QueryResult<BoardInvites> listBoardInvites (
//			String cursorString,
//			Integer limit,
//			String boardId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Cursor cursor = null;
//			
//			TypedQuery<BoardInvites> query = new QueryBuilder<>(BoardInvites.class)
//					.addClause(FLD.boardId, boardId)
//					.build(mgr);
//
//			if (StringUtils.isNotBlank(cursorString)) {
//				cursor = Cursor.fromWebSafeString(cursorString);
//				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
//			}
//
//			if (limit != null) {
//				query.setFirstResult(0);
//				query.setMaxResults(limit);
//			}
//
//			List<BoardInvites> execute = query.getResultList();
//			cursor = JPACursorHelper.getCursor(execute);
//			
//			return new QueryResult<BoardInvites>(execute, cursor);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public BoardInvites invite(BoardInvites boardInvite, String baseUrl) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			boardInvite.setKey(KeyUtil.createBoardInviteKey(boardInvite));
//
//			if (boardInvite.getExpirationStartDate() == null) {
//				boardInvite.setExpirationStartDate(new Date());
//			}
//			if (boardInvite.getExpirationEndDate() == null) {
//				boardInvite.setExpirationEndDate(CalendarUtil.addDay(new Date(), CommonProperty.DEFAULT_BOARD_INVITE_EXPIRATION_DAY));
//			}
//
//			String subject = "Invite you CoCoNut.";
//			StringBuilder msgBody = new StringBuilder();
//
//			msgBody.append(
//					String.format("<a href=\"%s%s?inviteToken=%s\">Confirm Invite.(당신을 초대합니다.)</a>",
//							baseUrl,
//							CommonProperty.BOARD_INVITATION_URL,
//							boardInvite.getBoardInviteId()
//					)
//			);
//
//			executeInvitationEmail(boardInvite.getInviteEmail(), subject, msgBody.toString());
//			//sendEmail.send(boardInvite.getInviteEmail(), subject, msgBody.toString());
//
//			Users loginUser = getCurrentUser();
//			boardInvite.setCreator(loginUser.getUserId());
//			
//			if (contains(mgr, BoardInvites.class, boardInvite.getKey())) {
//				doMergeTransaction(mgr, boardInvite);
//			} else {
//				doPersistTransaction(mgr, boardInvite);
//			}
//			
//			return boardInvite;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public BoardInvites confirmInvite(String boardInviteId, String host) throws Exception {
//		EntityManager mgr = getEntityManager();
//	
//		try {
//			
//			Key boardInviteKey = KeyFactory.stringToKey(boardInviteId);
//			Key boardKey = boardInviteKey.getParent();
//			NamespaceManager.set(boardInviteKey.getNamespace());
//			
//			Boards board = boardService.getBoards(mgr, KeyFactory.keyToString(boardKey), false);
//			Domains domain = domainService.getDomains(mgr, board.getDomainId());
//			
//			BoardInvites boardInvite = getBoardInvites(mgr, boardInviteId);
//			
//			if (boardInvite == null) {
//				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage("초대 정보가 없습니다."));
//			}
//			
//			Date confirmDate = new Date();
//			
//			if (boardInvite.getExpirationStartDate().compareTo(confirmDate) > 0 || boardInvite.getExpirationEndDate().compareTo(confirmDate) < 0) {
//				throw new UnavailableException(ErrorCode.UNAVAILABLE.getMessage("유효기간 범위가 아닙니다."));
//			}
//
//			/**
//			 * User의 ID는 Unique한 구분이 될 수 있는 Guest의 Email을 사용한다.
//			 * 즉, ID와 Email이 동일.
//			 */
//			Users guestUser = new Users();
//			guestUser.setId(boardInvite.getInviteEmail());
//			guestUser.setPassword(SecurityUtils.getMD5(boardInvite.getInviteEmail()));
//			guestUser.setEmail(boardInvite.getInviteEmail());
//			guestUser.setNickName(boardInvite.getInviteName());
//			guestUser.setUserName(boardInvite.getInviteName());
//			guestUser.setKey(KeyUtil.createUserKey(guestUser.getId()));
//
//			if (N.equals(boardInvite.getConfirmYN())) {
//				Users memberUser = userService.getSimpleUsers(mgr, boardInvite.getCreator());
////				MemberAuths domainMemberAuth = domainService.getMemberAuth(board.getDomainId(), guestUser);
////				
////				if (domainMemberAuth==null) {
////					domainService.assignGuest(board.getDomainId(), guestUser);
////				} else if (!domainService.isMemberAuth(domainMemberAuth)) {
////					throw new UnauthenticatedException(ErrorCode.UNAUTHENTICATION.getMessage());
////				}
//				
//				MemberAuths boardMemberAuth = memberAuthService.getMemberAuths(mgr, board.getBoardId(), guestUser.getUserId());
//				if (boardMemberAuth == null) {
//					assignGuest(board.getBoardId(), guestUser.getUserId(), memberUser);
//				} else if (!isValid(boardMemberAuth)) {
//					throw new UnauthenticatedException(ErrorCode.UNAUTHENTICATION.getMessage());
//				}
//			
//			//if (!Y.equals(boardInvite.getConfirmYN())) {
//				boardInvite.setUserId(guestUser.getUserId());
//				boardInvite.setConfirmYN(Y);
//				boardInvite.setConfirmed(new Date());
//
//				doMergeTransaction(mgr, boardInvite);
//			//}
//			} else {
//				guestUser = userService.getSimpleUsers(mgr, guestUser.getUserId());
//				valid(guestUser);
////				MemberAuths domainMemberAuth = domainService.getMemberAuth(board.getDomainId(), guestUser);
////				valid(domainMemberAuth);
//				MemberAuths boardMemberAuth = memberAuthService.getMemberAuths(mgr, board.getBoardId(), guestUser.getUserId());
//				valid(boardMemberAuth);
//			}
//			
//			// Anyone logout
//			Users loginUser = getCurrentUser();
//			if (loginUser != null && StringUtils.isNotEmpty(loginUser.getUserId())) {
//				//userService.logout(loginUser.getUserId());
//				userService.logout();
//			}
//			// Guest login
//			userService.login(domain.getDomainName(), boardInvite.getInviteEmail(), SecurityUtils.getMD5(boardInvite.getInviteEmail()), true, host);
//			
//			return boardInvite;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public BoardInvites getBoardInvites(String boardInviteId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getBoardInvites(mgr, boardInviteId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private BoardInvites getBoardInvites(EntityManager mgr, String boardInviteId) {
//		return doFind(mgr, BoardInvites.class, boardInviteId);
//	}
//
//	@Override
//	public BoardInvites updateBoardInvites(BoardInvites boardInvite) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			valid(boardInvite);
//			doMergeTransaction(mgr, boardInvite);
//			return boardInvite;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public void removeBoardInvites(String boardInviteId) {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			BoardInvites boardInvite = doFind(mgr, BoardInvites.class, boardInviteId);
//			boardInvite.setDeleted(new Date());
//			boardInvite.setDeleteYN(Y);
//			
//			doMergeTransaction(mgr, boardInvite);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	
//	private void executeInvitationEmail(String email, String subject, String message) {
//		if (StringUtils.isNotEmpty(message)) {
//			List<String> messageList = new ArrayList<String>();
//			messageList.add(message);
//			executeInvitationEmail(email, subject, messageList);
//		}
//	}
//	
//	private void executeInvitationEmail(String email, String subject, List<String> messageList) {
//		if (StringUtils.isNotBlank(email)) {
//			Queue queue = QueueFactory.getQueue(CommonProperty.INVITATION_EMAIL_QUEUE_NAME);
//			TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.INVITATION_EMAIL_SEND_URL);
//		
//			taskOptions
//					.param(PARAM.DOMAINNAME, NamespaceManager.get())
//					.param(PARAM.EMAIL, email)
//					.param(PARAM.SUBJECT, subject);
//			for (String message : messageList) {
//				taskOptions = taskOptions.param(PARAM.MESSAGES, message);
//			}
//					
//			taskOptions = taskOptions.method(Method.POST);
//	
//			queue.add(taskOptions);
//		}
//	}
//	
//	private Users assignGuest(String boardId, String invitedUserId, Users memberUser) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Boards board = boardService.getBoards(mgr, boardId, false);
//			Domains domain = domainService.getDomains(mgr, board.getDomainId());
//			
//			Users invitedUser = userService.getUsers(mgr, invitedUserId);
//			
//			valid(domain);
//			valid(board);
//			valid(invitedUser);
//			
//			MemberAuths memberAuths = memberAuthService.getMemberAuths(mgr, boardId, invitedUser.getUserId());
//			if (memberAuths == null) {
//				memberAuths = new MemberAuths(board.getDomainId()
//						, boardId
//						, AuthKind.BOARDS
//						, boardId
//						, invitedUserId
//						, memberUser.getUserId()
//						, Auth.GUEST
//						, AuthStatus.ACTIVE);
//				
//				memberAuths.setKey(KeyUtil.createMemberAuthKey(board.getBoardId(), invitedUser.getUserId()));
//				
//				beginTransaction(mgr);
//				memberAuths = memberAuthService.insertMemberAuths(mgr, memberAuths);
//				commitTransaction(mgr);
//			}
//			
//			try {
//				activityService.insertActivities(activityService.createBoardActivity(board, memberAuths, ActivityType.ASSIGNED, memberUser));
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return (memberAuths != null) ? memberAuths.getUser() : null;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
}
