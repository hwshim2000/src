package net.forecs.coconut.endpoint.board;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PrepareManager;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.AuthKind;
import net.forecs.coconut.common.code.AuthStatus;
import net.forecs.coconut.common.code.CreateNoticeAuth;
import net.forecs.coconut.common.code.CreateScheduleAuth;
import net.forecs.coconut.common.code.CreateTaskAuth;
import net.forecs.coconut.common.code.PublicSearchRange;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IMemberAuthService;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.admin.UsageService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.endpoint.setting.UserSettingService;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.Tasks;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.api.server.spi.response.UnauthorizedException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


public class BoardService extends CommonService implements IBoardService {
	private static final Logger LOG = Logger.getLogger(BoardService.class.getName());
	
	private final IDomainService domainService;
	private final IMemberAuthService memberAuthService;
	private final IUserService userService;
	private final IActivityService activityService;
	private final ITaskService taskService;
	
	@Inject
	public BoardService(IDomainService domainService, IMemberAuthService memberAuthService,
			IUserService userService,
			IActivityService activityService,
			ITaskService taskService
			) {
		this.domainService = domainService;
		this.memberAuthService = memberAuthService;
		this.userService = userService;
		this.activityService = activityService;
		this.taskService = taskService;
	}

	@Override
	public List<Users> assignMemberList(String boardId, List<String> userIdList) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return assignMemberList(mgr, boardId, userIdList);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private List<Users> assignMemberList(EntityManager mgr, String boardId, List<String> userIdList) throws Exception {
		try {
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();

			Boards board = getBoards(mgr, boardId);
			Domains domain = domainService.getDomains(mgr, board.getDomainId());
			valid(domain);
			valid(board);

			List<Users> memberList = new ArrayList<Users>();
			List<Activities> activityList = new ArrayList<Activities>();
			
			Set<String> memberIds = new HashSet<String>();
			
			for (String userId : userIdList) {
				memberIds.add(KeyUtil.createMemberAuthKeyString(boardId, userId));
			}
			Map<String, MemberAuths> memberAuthMap = batchMapByKey(mgr, MemberAuths.class, memberIds);
			Map<String, Users> userMap = userService.batchMapUsers(mgr, userIdList, false);
			
			List<MemberAuths> batchTxReassingMemberList = new ArrayList<MemberAuths>();
			List<MemberAuths> batchTxInsertMemberList = new ArrayList<MemberAuths>();
			
			for (String userId : userIdList) {
				Users user = userMap.get(userId); // hyeunwoo.shim 2015-10-07 used batch query
				if (!isValid(user)) { continue; }
				memberList.add(user);
				
				String memberAuthId = KeyUtil.createMemberAuthKeyString(board.getBoardId(), user.getUserId());
				
				MemberAuths memberAuth = memberAuthMap.get(memberAuthId);
				
				if (memberAuth == null) {
					memberAuth = new MemberAuths(board.getDomainId(),
							boardId,
							AuthKind.BOARDS,
							boardId,
							userId,
							loginUserId,
							Auth.MEMBER,
							AuthStatus.ACTIVE);

					memberAuth.setMemberAuthId(memberAuthId);
					batchTxInsertMemberList.add(memberAuth);
				} else if (AuthStatus.INACTIVE.equals(memberAuth.getAuthStatus())){
					memberAuth.setDeleted(null);
					memberAuth.setDeleteYN(N);
					memberAuth.setAuthStatus(AuthStatus.ACTIVE);
					batchTxReassingMemberList.add(memberAuth);
				} else {
					continue;
				}

				memberAuth.setUser(user);
				activityList.add(activityService.createBoardActivity(board, memberAuth, ActivityType.ASSIGNED, loginUser));
			}
			
			doMergeTransaction(mgr, batchTxReassingMemberList);
			doPersistTransaction(mgr, batchTxInsertMemberList);
			
			try {
				activityService.insertActivities(activityList);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return memberList;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
//	private List<Users> assignMemberList(EntityManager mgr, String boardId, List<String> userIdList) throws Exception {
//	try {
//		Users loginUser = getCurrentUser();
//		String loginUserId = loginUser.getUserId();
//
//		Boards board = getBoards(mgr, boardId);
//		Domains domain = domainService.getDomains(mgr, board.getDomainId());
//		valid(domain);
//		valid(board);
//
//		List<MemberAuths> memberAuthsList = new ArrayList<MemberAuths>();
//		List<Users> memberList = new ArrayList<Users>();
//		List<Activities> activityList = new ArrayList<Activities>();
//		
//		Set<String> memberIds = new HashSet<String>();
//		
//		for (String userId : userIdList) {
//			memberIds.add(KeyUtil.createMemberAuthKeyString(boardId, userId));
//		}
//		Map<String, MemberAuths> memberAuthMap = batchMapByKey(mgr, MemberAuths.class, memberIds);
//		Map<String, Users> userMap = userService.batchMapUsers(mgr, userIdList, true);
//		
//		List<MemberAuths> batchTxReassingMemberList = new ArrayList<MemberAuths>();
//		List<MemberAuths> batchTxInsertMemberList = new ArrayList<MemberAuths>();
//		
//		for (String userId : userIdList) {
//			Users user = userMap.get(userId); // hyeunwoo.shim 2015-10-07 used batch query
//			valid(user);
//
//			MemberAuths memberAuths = new MemberAuths(board.getDomainId(),
//					boardId,
//					AuthKind.BOARDS,
//					boardId,
//					userId,
//					loginUserId,
//					Auth.MEMBER,
//					AuthStatus.ACTIVE);
//
//			memberAuths.setKey(KeyUtil.createMemberAuthKey(board.getBoardId(), user.getUserId()));
//			memberAuths.setUser(user);
//			
//			if (memberAuthMap.containsKey(memberAuths.getMemberAuthId())) {
//				memberAuths.setDeleted(null);
//				memberAuths.setDeleteYN(N);
//				memberAuths.setAuthStatus(AuthStatus.ACTIVE);
//				batchTxReassingMemberList.add(memberAuths);
//			} else {
//				batchTxInsertMemberList.add(memberAuths);
//			}
//
//			memberAuthsList.add(memberAuths);
//			memberList.add(user);
//
//			activityList.add(activityService.createBoardActivity(board, memberAuths, ActivityType.ASSIGNED, loginUser));
//		}
//		
//		doMergeTransaction(mgr, batchTxReassingMemberList);
//		doPersistTransaction(mgr, batchTxInsertMemberList);
//		
//		try {
//			// TODO : batch put에 대한 검토
//			activityService.insertActivities(activityList);
//		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//		
//		return memberList;
//	} catch (Exception ex) {
//		throw ex;
//	}
//}

	@Override
	public List<Users> unassignMemberList(String boardId, List<String> userIdList) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			List<Users> memberList = new ArrayList<Users>();
			List<Activities> activityList = new ArrayList<Activities>();
			
			Boards board = getBoards(mgr, boardId);
			Domains domain = domainService.getDomains(mgr, board.getDomainId());
			valid(domain);
			valid(board);
			
			Set<String> memberIds = new HashSet<String>();
			Set<String> userIds = new HashSet<String>(userIdList);
			for (String userId : userIdList) {
				memberIds.add(KeyUtil.createMemberAuthKeyString(boardId, userId));
			}
			Map<String, MemberAuths> memberAuthMap = batchMapByKey(mgr, MemberAuths.class, memberIds);
			Map<String, Users> usersMap = userService.batchMapUsers(mgr, userIds, false);
			
			List<MemberAuths> batchTxUnassignList = new ArrayList<MemberAuths>(); // 2015-10-07 batch transaction
			
			for (String userId : userIdList) {
				if (board.isOwner(userId)) {
					throw new UnauthorizedException(ErrorCode.OWNER_UNASSIGN_UNAVAILABLE.getMessage(Boards.class, userId));
				}
				
				MemberAuths memberAuth = memberAuthMap.get(KeyUtil.createMemberAuthKeyString(boardId, userId));
				if (memberAuth == null) { continue; }
				memberAuth.setUser(usersMap.get(userId));
				memberAuth.setAuthStatus(AuthStatus.INACTIVE);

				valid(memberAuth.getUser());

				batchTxUnassignList.add(memberAuth);
				memberList.add(memberAuth.getUser());
				
				activityList.add(activityService.createBoardActivity(board, memberAuth, ActivityType.UNASSIGNED, loginUser));
			}
			
			doMergeTransaction(mgr, batchTxUnassignList); // 2015-10-07 batch transaction
			
			try {
				activityService.insertActivities(activityList);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return memberList;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Users removeMember(String boardId, String userId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users user = null;
			MemberAuths memberAuth = memberAuthService.getMemberAuths(mgr, boardId, userId);
			if (memberAuth != null) {
				if (AuthStatus.INACTIVE.equals(memberAuth.getAuthStatus())) {
					memberAuthService.permanentRemoveMemberAuths(mgr, memberAuth.getMemberAuthId());
					user = memberAuth.getUser();
				} else {
					throw new UnavailableException(String.format("This user(%s) is not unassigned member.", userId));
				}
			} else {
				throw new UnavailableException(String.format("This user(%s) is not member of board(%s)", userId, boardId));
			}
			
			return user;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Users changeOwnership(String boardId, String targetUserId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			Boards board = getBoards(mgr, boardId);
			Domains domain = domainService.getDomains(mgr, board.getDomainId());
			Users targetUser = userService.getUsers(mgr, targetUserId, false);

			valid(domain);
			valid(board);
			valid(targetUser);
			
			MemberAuths targetMemberAuth = memberAuthService.getMemberAuths(mgr, boardId, targetUserId);
			if (/*originMemberAuth == null || */targetMemberAuth == null) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Member not found."));
			}

			board.setOwner(targetUserId);

			beginTransaction(mgr);
			board = updateBoards(mgr, board);
			commitTransaction(mgr);

			try {
				activityService.insertActivities(activityService.createBoardActivity(board, targetUser,
						ActivityType.CHANGED_OWNERSHIP, loginUser));
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());// Ignored. Not a critical part of application.
			}

			return targetMemberAuth.getUser();
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public List<Boards> listGroupBoards(EntityManager mgr, String groupId) throws Exception {
		return listBoards(mgr, groupId, null, null);
	}
	@Override
	public List<Boards> listBoards(
			String groupId,
			String closeYN,
			PublicSearchRange publicSearchRange) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return listBoards(mgr, groupId, closeYN, publicSearchRange);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private List<Boards> listBoards(
			EntityManager mgr,
			String groupId,
			String closeYN,
			PublicSearchRange publicSearchRange) throws Exception {
		try {
			DsQuery<Boards> dsQuery = new DsQuery<>(Boards.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.groupId, groupId)
					.eq(FLD.closeYN, closeYN)
					.eq(FLD.publicSearchRange, publicSearchRange);

			List<Boards> boardList = dsQuery.execute(mgr);
			Boards.sort(boardList);
			
			return boardList;
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public boolean changeOrderBoards(List<String> boardIds) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			//--> hyeunwoo.shim 2015-10-14 : applied batch query
			List<Boards> boardList = batchListByKey(mgr, Boards.class, boardIds);
			int orderNum = 0;
			
			for (Boards board : boardList) {
				board.setOrdernum(orderNum++);
			}
			boardList = doMergeTransaction(mgr, boardList);
			
			return true;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Boards> getMyBoards() throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return getMyBoards(mgr);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<Boards> getMyBoards(EntityManager mgr) throws Exception {
		Users loginUser = getCurrentUser();
		
		return getUserBoards(mgr, loginUser);
	}
	@Override
	public List<Boards> getUserBoards(EntityManager mgr, Users user) throws Exception {
		if (user.isSuper()) {
			return listBoards(mgr, null, N, null);
		} else {
			List<Boards> myBoards = getUserBoards(mgr, user.getUserId());
			List<Boards> publicBoards = getPublicBoards(mgr);

			List<Boards> myBoardList = new ArrayList<Boards>();
			if (myBoards != null) {
				for (Boards board : myBoards) { if (!containsBoards(myBoardList, board)) { myBoardList.add(board); } }
			}
			if (publicBoards != null) {
				for (Boards board : publicBoards) { if (!containsBoards(myBoardList, board)) { myBoardList.add(board); } }
			}
			
			return myBoardList;
		}
	}
	
	private List<Boards> getUserBoards(EntityManager mgr, String userId) throws Exception {
		try {
			List<Boards> boardList = new ArrayList<Boards>();
			List<MemberAuths> members = memberAuthService.listMemberAuths(mgr, null, null, AuthKind.BOARDS, null, AuthStatus.ACTIVE, userId, false);
			
			if (members != null && members.size() > 0) {
				Users user = userService.getUsers(mgr, userId, false);
//				boolean userIsAdmin = user.isAdmin();	
				boolean userIsSuper = user.isSuper();	// Admin has super authority.
				
				Set<String> boardIds = new HashSet<String>();
				for (MemberAuths member : members) {
					boardIds.add(member.getBoardId());
				}
				Map<String, Boards> boardsMap = batchMapByKey(mgr, Boards.class, boardIds);
				for (MemberAuths member : members) {
					Boards board = boardsMap.get(member.getBoardId());
					if (!isValid(board)){
						if (!Y.equals(board.getCloseYN())) {
							LOG.warning("[FIXME] Invalid MemberAuths : boardId=" + member.getBoardId());
						}
						continue;
					}
					
					boolean userIsOwner = board.isOwner(userId);
					if (isValid(board) || userIsSuper || userIsOwner) {
//					if (isValid(board) || userIsAdmin || userIsSuper || userIsOwner) {
						boardList.add(board);
					}
				}
			}
			
			return boardList;
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public boolean isAvailableMemberAuth(String boardId, String userId) {
		EntityManager mgr = getEntityManager();
		try {
			return isAvailableMemberAuth(mgr, boardId, userId);
		} catch (Exception e) {
			return false;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private boolean isAvailableMemberAuth(EntityManager mgr, String boardId, String userId) {
		try {
			Boards board = getBoards(mgr, boardId);
			if (!isValid(board)) { return false; }
			if (PublicSearchRange.DOMAIN.equals(board.getPublicSearchRange())) { return true; }
			
			Users user = userService.getUsers(mgr, userId, false);
			if (!isValid(user)) { return false; }
			if (user.isSuper() || board.isOwner(userId)) {	// Admin has super authority.
//			if (user.isAdmin() || user.isSuper() || board.isOwner(userId)) {
				return true;
			}
			
			MemberAuths memberAuth = memberAuthService.getMemberAuths(mgr, boardId, userId);
			return isValid(memberAuth);	
		} catch (Exception e) {
			return false;
		}
	}
	
	@SuppressWarnings("unused")
	private Set<String> batchListUsersBoard(EntityManager mgr, Collection<String> userIds) throws Exception {
		try {
			Set<String> userBoardIds = new HashSet<String>();
			
			Map<String, List<Boards>> usersBoardMap = memberAuthService.batchMapUserBoards(mgr, userIds);
			for (List<Boards> boardList : usersBoardMap.values()) {
				for (Boards board : boardList) {
					userBoardIds.add(board.getBoardId());
				}
			}
			
			return userBoardIds;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Map<String, Boards> batchMapBoards(Collection<String> boardIds) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return batchMapBoards(mgr, boardIds);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private Map<String, Boards> batchMapBoards(EntityManager mgr, Collection<String> boardIds) throws Exception {
		try {
			Map<String, Boards> boardMap = new HashMap<String, Boards>();
			for (Map.Entry<String, Boards> entry : batchMapByKey(mgr, Boards.class, boardIds).entrySet()) {
				Boards board = entry.getValue();
				if (isValid(board)) {
					boardMap.put(entry.getKey(), board);
				}
			}
			
			return boardMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@SuppressWarnings("unused")
	private List<String> getPublicBoardIdList(EntityManager mgr) throws Exception {
		List<Boards> boards = getPublicBoards(mgr);
		List<String> boardIdList = null;

		if (boards != null) {
			boardIdList = new ArrayList<String>();
			for (Boards board : boards) {
				boardIdList.add(board.getBoardId());
			}
		}
		return boardIdList;
	}

	private List<Boards> getPublicBoards(EntityManager mgr) throws Exception {
		return listBoards(mgr, null, N, PublicSearchRange.DOMAIN);
	}
	
	@Override
	public Boards getBoards(String boardId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getBoards(mgr, boardId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Boards getBoards(EntityManager mgr, String boardId) throws Exception {
		return doFind(mgr, Boards.class, boardId);
	}
	
	@Override
	public Boards insertBoards(Boards board) throws Exception {
		UsageService.validUsage(board);
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			
			validCreateBoardAuth(loginUser);
			
			board.setCreator(loginUser.getUserId());
			board.setOwner(loginUser.getUserId());
			
			beginTransaction(mgr);
			board = insertBoards(mgr, board);
			commitTransaction(mgr);
			
			try {
				activityService.insertActivities(activityService.createBoardActivity(board, null, ActivityType.CREATED, loginUser));
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }

			UsageService.increaseUsage(board);
			return board;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private Boards insertBoards(EntityManager mgr, Boards board) throws Exception {
		try {
			if (board.getKey() == null) {
				board.setKey(KeyFactory.createKey(Boards.class.getSimpleName(), KeyUtil.TIMESTAMP()));
			}
			if (contains(mgr, Boards.class, board.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Boards.class, board.getBoardId()));
			}

			doPersist(mgr, board);

//			List<Tasklists> batchTxtasklists = new ArrayList<Tasklists>();

//			for (TaskStage taskStage : TaskStage.values()) {
//				Tasklists tasklist = new Tasklists(board.getBoardId(), taskStage, board.getCreator());
//				batchTxtasklists.add(tasklist);
//			}
//			doPersist(mgr, board.getTasklists());

			MemberAuths boardAuth = new MemberAuths(
					board.getDomainId()
					, board.getBoardId()
					, AuthKind.BOARDS
					, board.getBoardId()
					, board.getCreator()
					, board.getCreator()
					, Auth.MEMBER
					, AuthStatus.ACTIVE);
			boardAuth.setKey(KeyUtil.createMemberAuthKey(board.getBoardId(), board.getCreator()));
			boardAuth = memberAuthService.insertMemberAuths(mgr, boardAuth);
			
//			board.setTasklists(batchTxtasklists);
			
			return board;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public Boards updateBoards(Boards board) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			valid(board);

			beginTransaction(mgr);
			board = updateBoards(mgr, board);
			commitTransaction(mgr);

			try {
				activityService.insertActivities(activityService.createBoardActivity(board, null,
						ActivityType.UPDATED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return board;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Boards updateBoards(EntityManager mgr, Boards board) throws Exception {
		doMerge(mgr, board);
		return board;
	}

	@Override
	public Boards updateBoardSettings(
			String boardId,
			PublicSearchRange publicSearchRange,
			CreateNoticeAuth createNoticeAuth,
			CreateTaskAuth createTaskAuth,
			CreateScheduleAuth createScheduleAuth) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Boards board = doFind(mgr, Boards.class, boardId);
			valid(board);

			List<ActivityType> activityList = new ArrayList<ActivityType>();
			
			if (!publicSearchRange.equals(board.getPublicSearchRange())) {
				ActivityType activityType = PublicSearchRange.DOMAIN
						.equals(publicSearchRange) ? ActivityType.UPDATE_PUBLIC_SEARCH_RANGE_DOMAIN
						: ActivityType.UPDATE_PUBLIC_SEARCH_RANGE_BOARD;
				activityList.add(activityType);
			}
			if (!createNoticeAuth.equals(board.getCreateNoticeAuth())) {
				ActivityType activityType = CreateNoticeAuth.OWNER
						.equals(createNoticeAuth) ? ActivityType.UPDATE_CREATE_NOTICE_AUTH_OWNER
						: ActivityType.UPDATE_CREATE_NOTICE_AUTH_MEMBER;
				activityList.add(activityType);
			}
			if (!createTaskAuth.equals(board.getCreateTaskAuth())) {
				ActivityType activityType = CreateTaskAuth.OWNER
						.equals(createTaskAuth) ? ActivityType.UPDATE_CREATE_TASK_AUTH_OWNER
						: ActivityType.UPDATE_CREATE_TASK_AUTH_MEMBER;
				activityList.add(activityType);
			}
			if (!createScheduleAuth.equals(board.getCreateScheduleAuth())) {
				ActivityType activityType = CreateScheduleAuth.OWNER
						.equals(createScheduleAuth) ? ActivityType.UPDATE_CREATE_SCHEDULE_AUTH_OWNER
						: ActivityType.UPDATE_CREATE_SCHEDULE_AUTH_MEMBER;
				activityList.add(activityType);
			}
			
			board.setPublicSearchRange(publicSearchRange);
			board.setCreateNoticeAuth(createNoticeAuth);
			board.setCreateTaskAuth(createTaskAuth);
			board.setCreateScheduleAuth(createScheduleAuth);

			doMergeTransaction(mgr, board);

			try {
				Users user = getCurrentUser();
				for (ActivityType activityType : activityList) {
					activityService.insertActivities(activityService.createBoardActivity(board, null,
						activityType, user));
				}
			} catch (Exception e) {
				LOG.warning(e.getMessage()); // Ignored. Not a critical part of application.
			}

			return board;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Boards openBoard(String boardId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			Boards board = getBoards(mgr, boardId);
			
			board.setCloseYN(N);

			beginTransaction(mgr);
			board = updateBoards(mgr, board);
			commitTransaction(mgr);

			try {
				//UsageService.increaseUsage(board);
				activityService.insertActivities(activityService.createBoardActivity(board, null,
						ActivityType.OPENED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return board;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Boards closeBoard(String boardId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			Boards board = getBoards(mgr, boardId);
			valid(board);

			board.setCloseYN(Y);
			
			beginTransaction(mgr);
			board = updateBoards(mgr, board);
			commitTransaction(mgr);
			
			try {
				//UsageService.decreaseUsage(board);
				activityService.insertActivities(activityService.createBoardActivity(board, null,
						ActivityType.CLOSED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return board;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public List<Users> getAssignedMemberList(String boardId) throws Exception {
		return getMemberList(Arrays.asList(new String[]{ boardId }), AuthStatus.ACTIVE);
	}
	@Override
	public List<Users> getAssignedMemberList(EntityManager mgr, String boardId) throws Exception {
		return getMemberList(mgr, Arrays.asList(new String[]{ boardId }), AuthStatus.ACTIVE);
	}
	@Override
	public List<Users> getUnassignedMemberList(String boardId) throws Exception {
		return getMemberList(Arrays.asList(new String[]{ boardId }), AuthStatus.INACTIVE);
	}
	@Override
	public List<Users> getAssignedMemberList(EntityManager mgr, List<Boards> boardList) throws Exception {
		List<String> boardIdList = getBoardIdList(mgr, boardList);
		return getMemberList(mgr, boardIdList, AuthStatus.ACTIVE);
	}
	
	private List<Users> getMemberList(Collection<String> boardIdList, AuthStatus authStatus) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getMemberList(mgr, boardIdList, authStatus);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<Users> getMemberList(EntityManager mgr, Collection<String> boardIdList, AuthStatus authStatus) throws Exception {
		List<MemberAuths> memberAuthList = memberAuthService.listMemberAuths(mgr, boardIdList, null, AuthKind.BOARDS, null, authStatus, null, true);
		
		List<Users> memberList = new ArrayList<Users>();
		for (MemberAuths memberAuth : memberAuthList) {
			Users user = memberAuth.getUser();
			if (AuthStatus.ACTIVE.equals(authStatus)) {
				if (!isValid(user)) { continue; }
			}
			
			if (user != null && !containsMember(memberList, user)) {
				memberList.add(user);
			}
		}
		return memberList;
	}
	private Map<String, List<Users>> getMembers(EntityManager mgr, String boardId) throws Exception {
		List<MemberAuths> memberAuthList = memberAuthService.listMemberAuths(mgr, Arrays.asList(new String[]{ boardId }), null, AuthKind.BOARDS, null, null, null, true);
		
		Map<String, List<Users>> members = new HashMap<String, List<Users>>();
		List<Users> assignedMembers = new ArrayList<Users>();
		List<Users> unassignedMembers = new ArrayList<Users>();
		
		for (MemberAuths memberAuth : memberAuthList) {
			Users user = memberAuth.getUser();
			if (user == null) { continue; }
			
			if (isValid(user) && AuthStatus.ACTIVE.equals(memberAuth.getAuthStatus())) {
				assignedMembers.add(user);
			} else {
				unassignedMembers.add(user);
			}
		}
		members.put(PrepareManager.PREFIX_ASSIGNED_MEMBERS, assignedMembers);
		members.put(PrepareManager.PREFIX_UNASSIGNED_MEMBERS,  unassignedMembers);
		return members;
	}
	
	private List<String> getBoardIdList(EntityManager mgr, List<Boards> boardList) throws Exception {
		List<String> boardIdList = new ArrayList<String>();

		if (boardList != null) {
			for (Boards board : boardList) {
				boardIdList.add(board.getBoardId());
			}
		}
		return boardIdList;
	}
	
	@Override
	public Set<String> getUserBoardIds(EntityManager mgr, Users user) throws Exception {
		try {
			Set<String> boardIdSet = new HashSet<String>();
			List<Boards> boards = getUserBoards(mgr, user);
			for (Boards board : boards) {
				boardIdSet.add(board.getBoardId());
			}
			return boardIdSet;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
//	@Override
//	public Set<String> getUsersBoardForDashboard(EntityManager mgr, Users user, Collection<String> userIds) throws Exception {
//		try {
//			Set<String> boardIdSet = null;
//			if (user.isSuper()
////					|| loginUser.isAdmin()	// Admin has super authority.
//					|| userIds == null
//					|| (userIds.size() == 1 && userIds.contains(user
//							.getUserId()))) {
//				boardIdSet = new HashSet<String>();
//				List<Boards> boardList = getUserBoards(mgr, user);
//				for (Boards board : boardList) {
//					boardIdSet.add(board.getBoardId());
//				}
//			} else {
//				if (userIds != null && userIds.size() > 0) {
//					boardIdSet = batchListUsersBoard(mgr, userIds);
//					List<String> publicBoardIdList = getPublicBoardIdList(mgr);
//					if (publicBoardIdList != null && publicBoardIdList.size() > 0) { boardIdSet.addAll(publicBoardIdList); }
//				}
//			}
//			return boardIdSet;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
	
	private boolean containsMember(List<Users> userList, Users user) {
		for (Users containUser : userList) {
			if (user.getUserId().equals(containUser.getUserId())) {	return true; }
		}
		return false;
	}
	private boolean containsBoards(List<Boards> boardList, Boards board) {
		for (Boards containBoard : boardList) {
			if (board.getBoardId().equals(containBoard.getBoardId())) {	return true; }
		}
		return false;
	}
	@Override
	public Map<String, Object> getBoardItems(String boardId) throws Exception {
		EntityManager mgr = getEntityManager();
		Users user = getCurrentUser();
		Map<String, Object> boardItems = new HashMap<String, Object>();
		try {
			if (user != null) {
				boardItems = getBoardItemsFromPreparedMemcache(mgr, boardId, user.getUserId());
			}
			
			return boardItems;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@SuppressWarnings("unchecked")
	private Map<String, Object> getBoardItemsFromPreparedMemcache(EntityManager mgr, String boardId, String userId) throws Exception {
		Map<String, Object> items = new HashMap<String, Object>();
		Key userKey = KeyFactory.stringToKey(userId);
		
		PrepareManager pm = new PrepareManager(userKey.getNamespace());
		items = pm.getBoardItemsFromPreparedMemcache(boardId, userId);
		List<Tasks> unarchivedTasks = (List<Tasks>)items.get(PrepareManager.PREFIX_UNARCHIVED_TASKS);
		List<Users> assignedMembers = (List<Users>)items.get(PrepareManager.PREFIX_ASSIGNED_MEMBERS);
		List<Users> unassignedMembers = (List<Users>)items.get(PrepareManager.PREFIX_UNASSIGNED_MEMBERS);
		List<String> mySubscribedTaskIds = (List<String>)items.get(PrepareManager.PREFIX_MY_SUBSCRIBED_TASKIDS);
		
		if (items.size() == 0) {
			LOG.warning("[PREPARE-BOARD] Data initialization did not become. " + userKey.getName());
		} else {
			LOG.warning("[PREPARE-BOARD] get data from memcache. " + userKey.getName());
		}
		
		if (unarchivedTasks == null) {
			QueryResult<Tasks> queryResults = taskService.queryTasks(mgr, null, null, Arrays.asList(new String[]{ boardId }), N, null, null);
			unarchivedTasks = queryResults.getResultList();
		}
		if (assignedMembers == null) {
			Map<String, List<Users>> members = getMembers(mgr, boardId);
			assignedMembers = members.get(PrepareManager.PREFIX_ASSIGNED_MEMBERS);
			unassignedMembers = members.get(PrepareManager.PREFIX_UNASSIGNED_MEMBERS);
		}
		if (mySubscribedTaskIds == null) {
			mySubscribedTaskIds = taskService.listSubscribedTaskIds(mgr, boardId, userId);
		}
		items.put(PrepareManager.PREFIX_UNARCHIVED_TASKS, unarchivedTasks);
		items.put(PrepareManager.PREFIX_ASSIGNED_MEMBERS, assignedMembers);
		items.put(PrepareManager.PREFIX_UNASSIGNED_MEMBERS, unassignedMembers);
		items.put(PrepareManager.PREFIX_MY_SUBSCRIBED_TASKIDS, mySubscribedTaskIds);		

		return items;
	}
	
	private Map<String, Object> getBoardItems(EntityManager mgr, String boardId, String userId) throws Exception {
		Map<String, Object> items = new HashMap<String, Object>();
		
		QueryResult<Tasks> queryResults = taskService.queryTasks(mgr, null, null, Arrays.asList(new String[]{ boardId }), N, null, null);
		List<Tasks> unarchivedTasks = queryResults.getResultList();
		items.put(PrepareManager.PREFIX_UNARCHIVED_TASKS, unarchivedTasks);
		
		Map<String, List<Users>> members = getMembers(mgr, boardId);
		List<Users> assignedMembers = members.get(PrepareManager.PREFIX_ASSIGNED_MEMBERS);
		List<Users> unassignedMembers = members.get(PrepareManager.PREFIX_UNASSIGNED_MEMBERS);
		items.put(PrepareManager.PREFIX_ASSIGNED_MEMBERS, assignedMembers);
		items.put(PrepareManager.PREFIX_UNASSIGNED_MEMBERS, unassignedMembers);
		
		List<String> mySubscribedTaskIds = taskService.listSubscribedTaskIds(mgr, boardId, userId);
		items.put(PrepareManager.PREFIX_MY_SUBSCRIBED_TASKIDS, mySubscribedTaskIds);

		return items;
	}

	@Override
	public void prepareBoardItems(String domainName, String userId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		try {
			PrepareManager pm = new PrepareManager(domainName);
			List<Boards> userBoards = pm.getUserBoardsFromPreparedMemcache(userId);
			
			if (userBoards == null) {
				Users user = userService.getUsers(mgr, userId, false);
				userBoards = getUserBoards(mgr, user);
			}

			if (userBoards == null) { return; }

			//--> 20160912 : 초기화 과정시 현재 사용자 셋팅 정보의 board를 로딩할 경우를 대비해, 가장 먼저 초기화가 될 수 있도록 하기 위해 
			String preparedDefaultBoardId = UserSettingService.getPreparedDefaultBoard(mgr, userId);
			if (StringUtils.isNotBlank(preparedDefaultBoardId)) {
				Map<String, Object> boardItems = getBoardItems(mgr, preparedDefaultBoardId, userId);
				pm.prepareBoardItems(preparedDefaultBoardId, userId, boardItems);
			}
			//<--
			
			for (Boards board : userBoards) {
				//--> 20160912 : 초기화 과정시 현재 사용자 셋팅 정보의 board를 로딩할 경우를 대비해, 가장 먼저 초기화가 될 수 있도록 하기 위해
				if (StringUtils.equals(preparedDefaultBoardId, board.getBoardId())) { continue; }
				//<--
				String boardId = board.getBoardId();
				Map<String, Object> boardItems = getBoardItems(mgr, boardId, userId);
				pm.prepareBoardItems(boardId, userId, boardItems);
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public void prepareBoardItemsWithTaskQueue(String domainName, String userId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		try {
//			Queue queue = QueueFactory.getQueue(CommonProperty.PREPARE_INIT_DATA_QUEUE);
//			TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.PREPARE_INIT_DATA_URL);
			
			PrepareManager pm = new PrepareManager(domainName);
			List<Boards> userBoards = pm.getUserBoardsFromPreparedMemcache(userId);
			
			if (userBoards == null) {
				Users user = userService.getUsers(mgr, userId, false);
				userBoards = getUserBoards(mgr, user);
			}

			if (userBoards == null) { return; }
			
			//--> 20160912 : 초기화 과정시 현재 사용자 셋팅 정보의 board를 로딩할 경우를 대비해, 가장 먼저 초기화가 될 수 있도록 하기 위해 
			String preparedDefaultBoardId = UserSettingService.getPreparedDefaultBoard(mgr, userId);
			if (StringUtils.isNotBlank(preparedDefaultBoardId)) {
				PrepareManager.addBoardItmesQueue(domainName, userId, preparedDefaultBoardId);
			}
			//<--
			
			for (Boards board : userBoards) {
				//--> 20160912 : 초기화 과정시 현재 사용자 셋팅 정보의 board를 로딩할 경우를 대비해, 가장 먼저 초기화가 될 수 있도록 하기 위해
				if (StringUtils.equals(preparedDefaultBoardId, board.getBoardId())) { continue; }
				//<--
				PrepareManager.addBoardItmesQueue(domainName, userId, board.getBoardId());
//				taskOptions.clearParams();
//				taskOptions = taskOptions
//						.param(PARAM.DOMAINNAME, domainName)
//						.param(PARAM.USERID, userId)
//						.param(PARAM.PREPARETYPE, PrepareType.BOARDS)
//						.param(PARAM.BOARDID, board.getBoardId());
//				
//				taskOptions = taskOptions.method(Method.POST);
//				
//				queue.add(taskOptions);
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void prepareBoardItems(String domainName, String boardId, String userId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		try {
			Map<String, Object> boardItems = getBoardItems(mgr, boardId, userId);

			PrepareManager pm = new PrepareManager(domainName);
			pm.prepareBoardItems(boardId, userId, boardItems);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private void validCreateBoardAuth(Users user) throws Exception {
		if (!hasCreateBoardAuth(user)) {
			throw new UnauthorizedException("Current user do not have board creation authority.");
		}
	}
	private boolean hasCreateBoardAuth(Users user) {
		if (user == null) { return false; }
		if (user.isAdmin() || user.isSuper() || user.isManager()) { return true; }
		Domains domain = getDomainFromUserNamespace(user.getDomainName());
		if (domain == null) { return false; }
		if (Auth.MEMBER.equals(domain.getCreateBoardAuth())) { return true; }
		return false;
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	Dashboard로 옮김
//	@Override
//	public List<String> getUserBoardIdList(EntityManager mgr, String userId) throws Exception {
//		List<Boards> boards = getUserBoards(mgr, userId, false);
//		List<String> boardIdList = new ArrayList<String>();
//
//		if (boards != null) {
//			for (Boards board : boards) {
//				boardIdList.add(board.getBoardId());
//			}
//		}
//		return boardIdList;
//	}
//	@Override
//	public Users assignMember(String boardId, String userId/*, Auth auth*/) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			Users loginUser = getCurrentUser();
//			String loginUserId = loginUser.getUserId();
//
//			Boards board = getSimpleBoards(mgr, boardId);
//			Domains domain = domainService.getDomains(mgr, board.getDomainId());
//
//			Users user = userService.getUsers(mgr, userId);
//
//			valid(domain);
//			valid(board);
//			valid(user);
//
//			MemberAuths memberAuths = new MemberAuths(board.getDomainId(),
//					boardId,
//					AuthKind.BOARDS,
//					boardId,
//					userId,
//					loginUserId,
//					Auth.MEMBER,//(auth == null) ? Auth.MEMBER : auth,
//					AuthStatus.ACTIVE);
//
//			memberAuths.setKey(KeyUtil.createMemberAuthKey(board.getBoardId(), user.getUserId()));
//			memberAuths.setUser(user);
//
//			beginTransaction(mgr);
//			if (doFind(mgr, MemberAuths.class, memberAuths.getKey()) != null) {
//				memberAuths = memberAuthService.reassignMemberAuths(mgr, memberAuths);
//			} else {
//				memberAuths = memberAuthService.insertMemberAuths(mgr, memberAuths);
//			}
//			commitTransaction(mgr);
//			
//			try {
//				activityService.insertActivities(activityService.createBoardActivity(board, memberAuths, ActivityType.ASSIGNED, loginUser));
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return (memberAuths != null) ? memberAuths.getUser() : null;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Users unassignMember(String boardId, String userId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			 //Board에 포함된 User의 모든 MeberAuth에대하여 unassign 하고자 할때
//			Boards board = getSimpleBoards(mgr, boardId);
//			if (board.isOwner(userId)) {
//				throw new UnauthorizedException(ErrorCode.OWNER_UNASSIGN_UNAVAILABLE.getMessage(Boards.class, userId));
//			}
//
//			Domains domain = domainService.getDomains(mgr, board.getDomainId());
//			MemberAuths memberAuth = memberAuthService.getMemberAuths(mgr, boardId, userId);
//			memberAuth.setAuthStatus(AuthStatus.INACTIVE);
//			
//			valid(domain);
//			valid(board);
//			valid(memberAuth.getUser());
//
//			beginTransaction(mgr);
//			memberAuth = memberAuthService.updateMemberAuths(mgr, memberAuth);
//			commitTransaction(mgr);
//			
//			try {
//				Users loginUser = getCurrentUser();
//				activityService.insertActivities(activityService.createBoardActivity(board, memberAuth, ActivityType.UNASSIGNED, loginUser));
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return memberAuth.getUser();
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Users> getAssignedMemberList(Collection<String> boardIdList) throws Exception {
//		return getMemberList(boardIdList, AuthStatus.ACTIVE);
//	}
//	@Override
//	public List<Users> getUnassignedMemberList(Collection<String> boardIdList) throws Exception {
//		return getMemberList(boardIdList, AuthStatus.INACTIVE);
//	}
//	@Override
//	public Boards getBoards(EntityManager mgr, String boardId) throws Exception {
//		return getBoards(mgr, boardId, true);
//	}
//	@Override
//	public Boards renameBoards(String boardId, String title) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Boards board = getBoards(mgr, boardId, true);
//			String originTitle = board.getTitle();
//
//			valid(board);
//			board.setTitle(title);
//			doMergeTransaction(mgr, board);
//
//			try {
//				Users loginUser = getCurrentUser();
//				activityService.insertActivities(activityService.createBoardActivity(board, originTitle,
//						ActivityType.RENAMED, loginUser));
//			} catch (Exception ex) {
//				LOG.warning(ex.getMessage());	// Ignored. Not a critical part of application.
//			}
//
//			return board;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public void removeBoards(String boardId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Boards board = doFind(mgr, Boards.class, boardId);
//			if (Y.equals(board.getDefaultYN())) {
//				throw new UnauthorizedException("Default board can't delete.");
//			}
//
//			board.setDeleted(new Date());
//			board.setDeleteYN(Y);
//
//			doMergeTransaction(mgr, board);
//			
//			UsageService.decreaseUsage(board);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Set<String> getUsersBoardForDashboard(Collection<String> userIdList) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getUsersBoardForDashboard(mgr, userIdList);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Map<String, Boards> batchMapBoards(EntityManager mgr, Collection<String> boardIds) throws Exception {
//		return batchMapBoards(mgr, boardIds, true);
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
