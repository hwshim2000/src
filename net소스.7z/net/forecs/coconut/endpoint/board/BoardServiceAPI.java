package net.forecs.coconut.endpoint.board;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.CreateNoticeAuth;
import net.forecs.coconut.common.code.CreateScheduleAuth;
import net.forecs.coconut.common.code.CreateTaskAuth;
import net.forecs.coconut.common.code.PublicSearchRange;
import net.forecs.coconut.common.query.QueryOption;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.shiro.annotation.RequiresMember;
import net.forecs.coconut.shiro.annotation.RequiresOwner;
import net.forecs.coconut.user.Role;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;


@Api(name = API.BOARD_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.BOARD_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class BoardServiceAPI {
	private final IBoardService boardService;
	
	private static final String Y = "Y";
	private static final String N = "N";

	@Inject
	public BoardServiceAPI(IBoardService boardService) {
		this.boardService = boardService;
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "boardItems", path = "boards/items/{boardId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<String, Object> getBoardItems(@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		return boardService.getBoardItems(boardId);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "assignMember", path = "boards/{boardId}/assignMember/{userId}", httpMethod = HttpMethod.POST)
//	@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
//	public Users assignMember(@Named(FLD.boardId) String boardId, @Named(FLD.userId) String userId/*, @Nullable @Named(FLD.auth) Auth auth*/) throws Exception {
//		CommonService.validNamespace(boardId);
//		return boardService.assignMember(boardId, userId/*, auth*/);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "assignMemberList", path = "boards/{boardId}/assignMemberList", httpMethod = HttpMethod.POST)
	@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public List<Users> assignMemberList(@Named(FLD.boardId) String boardId, @Named(FLD.userIdList) List<String> userIdList/*, @Nullable @Named(FLD.auth) Auth auth*/) throws Exception {
		CommonService.validNamespace(boardId);
		return boardService.assignMemberList(boardId, userIdList/*, auth*/);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "unassignMember", path = "boards/{boardId}/unassignMember/{userId}", httpMethod = HttpMethod.DELETE)
//	@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
//	public void unassignMember(@Named(FLD.boardId) String boardId, @Named(FLD.userId) String userId) throws Exception {
//		CommonService.validNamespace(boardId);
//		boardService.unassignMember(boardId, userId); 
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "unassignMemberList", path = "boards/{boardId}/unassignMemberList", httpMethod = HttpMethod.DELETE)
	@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public void unassignMemberList(@Named(FLD.boardId) String boardId, @Named(FLD.userIdList) List<String> userIdList) throws Exception {
		CommonService.validNamespace(boardId);
		boardService.unassignMemberList(boardId, userIdList); 
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeMember", path = "boards/{boardId}/removeMember/{userId}", httpMethod = HttpMethod.DELETE)
	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
	public void removeMember(@Named(FLD.boardId) String boardId, @Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(boardId);
		boardService.removeMember(boardId, userId); 
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "changeOwnership", path = "boards/{boardId}/changeOwnership/{targetUserId}", httpMethod = HttpMethod.PUT)
	@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public Users changeOwnership(@Named(FLD.boardId) String boardId, @Named(FLD.targetUserId) String targetUserId) throws Exception {
		CommonService.validNamespace(boardId);
		return boardService.changeOwnership(boardId, targetUserId); 
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryBoards", path = "boards/opened", httpMethod = HttpMethod.POST)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	public CollectionResponse<Boards> queryBoards(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.groupId) String groupId,
			@Nullable @Named(FLD.publicSearchRange) PublicSearchRange publicSearchRange,
			@Nullable QueryOption queryOption) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		} else if (StringUtils.isNotBlank(groupId)) {
			CommonService.validNamespace(groupId);
		}
		String closeYN = N;
		List<Boards> boardList = boardService.listBoards(groupId, closeYN, publicSearchRange);
		return CollectionResponse.<Boards>builder().setItems(boardList).setNextPageToken(null).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "myBoards", path = "boards/myBoards", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Boards> getMyBoards() throws Exception {
		List<Boards> boardList = boardService.getMyBoards();
		return CollectionResponse.<Boards>builder().setItems(boardList).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryClosedBoards", path = "boards/closed", httpMethod = HttpMethod.POST)
	@RequiresUser
	public CollectionResponse<Boards> queryClosedBoards(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.groupId) String groupId,
			@Nullable @Named(FLD.publicSearchRange) PublicSearchRange publicSearchRange,
			@Nullable QueryOption queryOption) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		} else if (StringUtils.isNotBlank(groupId)) {
			CommonService.validNamespace(groupId);
		}
		// ADMIN, SUPER, Board OWNER 만 가능
		String closeYN = Y;
		List<Boards> boardList = boardService.listBoards(groupId, closeYN, publicSearchRange);
		return CollectionResponse.<Boards>builder().setItems(boardList).setNextPageToken(null).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getAssignedMemberList", path = "boards/{boardId}/assignedMemberList", httpMethod = HttpMethod.GET)
	@RequiresUser
	//@RequiresMember(clazz = Boards.class, objectId = "{boardId}")
	// TODO @RequiresPermission({"board:read:{boardId}"})
	public CollectionResponse<Users> getAssignedMemberList(@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		List<Users> memberList = boardService.getAssignedMemberList(boardId);
		return CollectionResponse.<Users>builder().setItems(memberList).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getUnassignedMemberList", path = "boards/{boardId}/unassignedMemberList", httpMethod = HttpMethod.GET)
	@RequiresUser
	//@RequiresMember(clazz = Boards.class, objectId = "{boardId}")
	// TODO @RequiresPermission({"board:read:{boardId}"})
	public CollectionResponse<Users> getUnassignedMemberList(@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		List<Users> memberList = boardService.getUnassignedMemberList(boardId);
		return CollectionResponse.<Users>builder().setItems(memberList).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getBoards", path = "boards/{boardId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	@RequiresMember(clazz = Boards.class, objectId = "{boardId}")
	public Boards getBoards(@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		return boardService.getBoards(boardId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "insertBoards", path = "boards", httpMethod = HttpMethod.POST)
	//@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
	@RequiresUser
	public Boards insertBoards(Boards board) throws Exception {
		CommonService.validNamespace(board.getDomainId());
		return boardService.insertBoards(board);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateBoards", path = "boards", httpMethod = HttpMethod.PUT)
	@RequiresUser
	@RequiresMember(clazz = Boards.class)
	public Boards updateBoards(Boards board) throws Exception {
		CommonService.validNamespace(board);
		return boardService.updateBoards(board);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "renameBoards", path = "boards/{boardId}/rename", httpMethod = HttpMethod.PUT)
////	@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
//	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
//	public Boards renameBoards(@Named(FLD.boardId) String boardId, @Named(FLD.title) String title) throws Exception {
//		CommonService.validNamespace(boardId);
//		return boardService.renameBoards(boardId, title);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "removeBoards", path = "boards/{boardId}", httpMethod = HttpMethod.DELETE)
//	@RequiresRoles(value = { Role.SUPER, Role.MANAGER }, logical = Logical.OR)
//	public void removeBoards(@Named(FLD.boardId) String boardId) throws Exception {
//		CommonService.validNamespace(boardId);
//		boardService.removeBoards(boardId);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "closeBoard", path = "boards/{boardId}/close", httpMethod = HttpMethod.PUT)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)	// TODO Add board owner
	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
	public void closeBoard(@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		boardService.closeBoard(boardId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "openBoard", path = "boards/{boardId}/open", httpMethod = HttpMethod.PUT)
//	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)	// TODO Add board owner
	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
	public Boards openBoard(@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		return boardService.openBoard(boardId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateBoardSettings", path = "boards/{boardId}/settings", httpMethod = HttpMethod.PUT)
	//@RequiresRoles(value = { Role.ADMIN, Role.SUPER, Role.MANAGER }, logical = Logical.OR)	// TODO Add board owner
	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
	public Boards updateBoardSettings(
			@Named(FLD.boardId) String boardId,
			@Named(FLD.publicSearchRange) PublicSearchRange publicSearchRange,
			@Named(FLD.createNoticeAuth) CreateNoticeAuth createNoticeAuth,
			@Named(FLD.createTaskAuth) CreateTaskAuth createTaskAuth,
			@Named(FLD.createScheduleAuth) CreateScheduleAuth createScheduleAuth) throws Exception {
		CommonService.validNamespace(boardId);
		return boardService.updateBoardSettings(boardId, publicSearchRange, createNoticeAuth, createTaskAuth, createScheduleAuth);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "changeOrderBoards", path = "boards/order", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result changeOrderBoards(@Named(FLD.boardIds) List<String> boardIds) throws Exception {
		CommonService.validNamespace(boardIds.get(0));
		return new Result(boardService.changeOrderBoards(boardIds));
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "getPublicBoards", path = "boards/public", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Boards> getPublicBoards() throws Exception {
//		List<Boards> boardList = boardService.getPublicBoards();
//		return CollectionResponse.<Boards>builder().setItems(boardList).build();
//	}
	
	// ------------- Current service(Mobile) ----------------
	@ApiMethod(name = "isAvailableMemberAuth", path = "boards/{boardId}/isAvailableMember/{userId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result isAvailableMemberAuth(@Named(FLD.boardId) String boardId, @Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(boardId);
		if (StringUtils.isEmpty(userId)) {
			Users user = CommonService.getCurrentUser();
			userId = user.getUserId();
		}
		return new Result(boardService.isAvailableMemberAuth(boardId, userId));
	}
}