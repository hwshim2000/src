package net.forecs.coconut.endpoint.board;

import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.calendar.Events;

public interface IAlarmService extends ICommonService {

	/**
	 * @Description : 도메인 목록을 조회하여 alarm 대상이 발견되면 TaskQueue 해당 alarm시간을 지정하여 등록한다.
	 *              : 단, TaskQueue에 최대한 등록될수 있는 시간이 30일이기때문에 30일 이후에 발생할 Alarm을 지정하는것은 무의미하다.
	 *              : 또한, Alarm check 주기(스케줄러)는 Alarm 환경설정의 최소값과 같거나 작아야 한다.
	 *              : (현재 기획문서상으로는 최소값이 5분이므로 최소한 5분마다 스케줄러를 작동시켜야 한다.)
	 */
	public abstract void invokeAlarmExecutor(EventType eventType);
	
	/**
	 * @Description : 스케줄러에 의해 호출되며, 해당 도메인에 존재하는 alarm 목록을 조회하여 TaskQueue에 적재시킨다.
	 */
	public abstract void executeAlarms(String domainName, EventType eventType);
	
	/**
	 * @Description : TaskQueue에서 해당 알람시간이 되면 호출하는 함수. 
	 *              : 이부분에서 Activity를 생성하고, Notification 설정에 따라 alarm message를 생성하여 push 한다.
	 * @param alarmDateTimeMillis : alarm이 발생한 시간
	 */
	public abstract void pushAlarms(String domainName, String eventId, String alarmDateTimeMillis);
	
	/**
	 * @Description : Alarm 수정시 Alarm Push Queue에 있는 태스크 삭제
	 *              : 등록을 다시 할 필요가 있으면 등록하고, 다음 Alarm이 없으면 등록하지 않는다.
	 */
	public abstract void updateAlarmQueue(String eventId);
	public abstract void removeAlarmTaskQueue(Events event);
	
	public abstract void pushAnniversaryAlarms(String domainName, String userId, AnniversaryType anniversaryType, String eventDateTimeMills, String alarmDateTimeMillis);
	public abstract void updateAnniversaryAlarmQueue(String userId);
}
