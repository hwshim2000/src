package net.forecs.coconut.endpoint.billing;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.code.billing.CancelInfo;
import net.forecs.coconut.common.code.billing.IamportBill;
import net.forecs.coconut.common.code.billing.PaidStatus;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.admin.AdminCommonService;
import net.forecs.coconut.endpoint.admin.IAdminService;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.entity.billing.ServiceGrades;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;

import edu.emory.mathcs.backport.java.util.Arrays;

@SuppressWarnings("unchecked")
public class BillingService extends AdminCommonService implements IBillingService {
	private static final Logger LOG = Logger.getLogger(BillingService.class.getName());
	
	private final static int PAYMENT_CANCEL_TERMS = 7;
	private final static List<Integer> paymentTryDates;
	public final static String DEFAULT_SERVICE_GRADE = "DEFAULT";
	private final static boolean isChargeStoageUsage = false;
	
	static {
		//paymentTryDates = Arrays.asList(new Integer[] { 1 } );
		paymentTryDates = Arrays.asList(new Integer[] { 1, 2, 5, 7, 15, 21, 25, 27 } );
	}
	private final IAdminService adminService;
	
	@Inject
	public BillingService(IAdminService adminService) {
		this.adminService = adminService;
	}
	
	@Override
	public IamportBill getIamportBill(String merchant_uid) throws Exception {
		return IamportManager.getIamportBill(merchant_uid);
	}
	
	@Override
	public QueryResult<IamportBill> listIamportBills(PaidStatus paidStatus, String cursorString) throws Exception {
		return IamportManager.listIamportBills(paidStatus, cursorString);
	}
	
	@Override
	public QueryResult<Bills> listBills(
			String domainName,
			PaidStatus paidStatus,
			String cursorString,
			Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Bills> dsQuery = new DsQuery<>(Bills.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.domainName, domainName)
					.eq(FLD.paidStatus, paidStatus)
					.sort(FLD.created, SortDirection.DESC)
					.cursor(cursorString)
					.limit(limit);
			List<Bills> bills = dsQuery.execute(mgr);
			return new QueryResult<Bills>(bills, dsQuery.getCursor());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Bills getBills(String billId) {
		return getBills(billId, false);
	}
	@Override
	public Bills getBillsDetail(String billId) {
		return getBills(billId, true);
	}
	private Bills getBills(String billId, boolean includeIamportBill) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		try {
			Bills bill = doFind(mgr, Bills.class, billId);
			if (bill != null && includeIamportBill) {
				try {
					IamportBill iamportBill = getIamportBill(bill.getMerchant_uid());
					bill.setIamportBill(iamportBill);
				} catch (Exception ex) {}
			}
			return bill;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@SuppressWarnings("unused")
	private Bills findByMerchantUid(String merchant_uid) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Bills> dsQuery = new DsQuery<>(Bills.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.merchant_uid, merchant_uid);
					
			return dsQuery.single(mgr);
		} catch (Exception e) {
			return null;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	private Bills insertBills(Bills bill) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			return insertBills(mgr, bill);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private Bills insertBills(EntityManager mgr, Bills bill) throws Exception {
		if (bill.getKey() == null) { bill.setKey(KeyUtil.createBillKey(bill.getServiceEnd())); }
		if (contains(mgr, Bills.class, bill.getKey())) {
			throw new EntityExistsException("Object already exists");
		}
		
		doPersistTransaction(mgr, bill);
		return bill;
	}
	
	private Bills updateBills(Bills bill) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			valid(bill);

			doMergeTransaction(mgr, bill);
			
			return bill;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private Date getLastSummarizeDate(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Bills> dsQuery = new DsQuery<>(Bills.class)
					//.ne(FLD.paidStatus, PaidStatus.paid)
					.eq(FLD.domainName, domainName)
					.eq(FLD.deleteYN, N)
					.sort(FLD.serviceEnd, SortDirection.DESC)
					.limit(1);
			
			Bills bill = dsQuery.single(mgr);
			if (bill != null) { return bill.getServiceEnd(); }
			return null;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private List<String> listDeferredDomainNames() throws Exception {
		List<Domains> results = listDomains(ServiceType.DEFERRED, null);
		List<String> domainNames = new ArrayList<String>();
		for (Domains domain : results) {
			domainNames.add(domain.getDomainName());
		}
		return domainNames;
	}
	
	private List<Domains> listDomains(ServiceType serviceType, BlockType blockType) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Domains> dsQuery = new DsQuery<>(Domains.class)
					.eq(FLD.serviceType, serviceType)
					.eq(FLD.blockType, blockType);
			return dsQuery.execute(mgr);
			
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void summarizeBills() {
		try {
			Queue queue = QueueFactory.getQueue(CommonProperty.SUMARRIZE_DOMAIN_BILLS_QUEUE_NAME);
			List<String> domainNames = listDeferredDomainNames();
			
			long summarizeTime = new Date().getTime();
			
			if (MainModule.serviceMode) {
				for (String domainName : domainNames) {
					TaskOptions taskOption = TaskOptions.Builder
				            .withUrl(CommonProperty.SUMARRIZE_DOMAIN_BILLS_URL)
				            .param(PARAM.DOMAINNAME, domainName)
				            .etaMillis(summarizeTime)
				            .method(Method.POST);
				    
					summarizeTime += 10;
					
					try {
						queue.add(taskOption);
					} catch (Exception ex) {
						LOG.warning(String.format("[summarizeBills-%s] %s ", domainName, ex.getMessage()));
					}
				}
			} else {
				for (String domainName : domainNames) {
					summarizeUsageForBills(domainName, null);
				}
			}
		} catch (Exception ex) {
			LOG.severe("[surveyUsage] " + ex.getMessage());
			//ex.printStackTrace();
		}
	}
	
	@Override
	public void summarizeUsageForBills(String domainName, Date endDate) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);

		EntityManager mgr = getEntityManager();
		
		try {
			Date startDate = getLastSummarizeDate(domainName);		// 이전 과금 결재 수집일의 마지막 날짜(즉, 새로운 수집을 위한 시작일)
			if (endDate == null) {
				endDate = CalendarUtil.getEndDatePreviousMonth();	// 현재 달은 제외하고 이전달의 마지막일까지 수집
			}
			
			DsQuery<UsageLogs> dsQuery = new DsQuery<>(UsageLogs.class)
					//.ne(FLD.paidStatus, PaidStatus.paid)
					.eq(FLD.chargeable, true)
					.eq(FLD.frequency, Frequency.DAILY)
					.le(FLD.created, endDate)
					.gt(FLD.created, startDate)
					.sort(FLD.created, SortDirection.ASC);
			
			Map<String, List<UsageLogs>> usageLogMap = new HashMap<String, List<UsageLogs>>();
			
			List<UsageLogs> usageLogs = dsQuery.execute(mgr);
			for (UsageLogs log : usageLogs) {
				String key = CalendarUtil.toString(log.getCreated(), "yyyyMM");
				if (usageLogMap.get(key) == null) { usageLogMap.put(key, new ArrayList<UsageLogs>()); }
				usageLogMap.get(key).add(log);
			}
			makeBills(domainName, usageLogMap);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private List<Bills> makeBills(String domainName, Map<String, List<UsageLogs>> usageLogMap) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			List<Bills> bills = new ArrayList<Bills>();
			for (String key : usageLogMap.keySet()) {
				Bills bill = makeBillFromUsageLogs(domain, usageLogMap.get(key));
				
				insertBills(mgr, bill);
				bills.add(bill);
			}
			return bills;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private Bills makeBillFromUsageLogs(Domains domain, List<UsageLogs> usageLogs) throws Exception {
		try {
			String domainName = domain.getDomainName();
			Bills bill = new Bills();
			bill.setPaidStatus(PaidStatus.ready);
			bill.setSite(IamportManager.BILL_SITE);
			bill.setDomainName(domainName);
			bill.setCustomer(getCustomer(domainName));
			
			Long totBytes = 0L;
			Double avgBytes = 0D;
			Long totUsers = 0L;
			Double avgUsers = 0D;
			
			for(UsageLogs log : usageLogs) {
				totBytes += log.getTotalBytes();
				totUsers += log.getUserCount();
			}
			avgBytes = (double)totBytes / (double)usageLogs.size();
			avgUsers = (double)totUsers / (double)usageLogs.size();
			
			bill.setTotBytes(totBytes);
			bill.setTotUsers(totUsers);
			bill.setAvgBytes(avgBytes);
			bill.setAvgUsers(avgUsers);
			bill.setServiceDays(usageLogs.size());
			bill.setServiceStart(usageLogs.get(0).getCreated());
			bill.setServiceEnd(usageLogs.get(usageLogs.size()-1).getCreated());
			bill.setAmount(calculateAmount(bill, domain.getServiceGrade()));
			bill.setMerchant_uid(makeMerchant_uid(domainName, bill.getServiceEnd()));
			String billName = String.format("[Cocoworks] %s의 서비스 사용료 청구 내역" , domainName);
			bill.setName(billName);
			
			return bill;
		} catch (Exception ex) { throw ex; }
	}
	private int calculateAmount(Bills bill, String serviceGrade) {
		//----------------------------------------------------------------------------
		// [ 유저수에 따른 과금 정책 ]
		// 월평균 User수  * (서비스일수/월의일수) * 단가 (6900)
		// [ 스토리지 사용량에 따른 과금 정책 ]
		// (월평균 Bytes 수 - (월평균 User수 * 5GB)) * (서비스일수/월의일수) * 단가 (1000)
		//----------------------------------------------------------------------------
		ServiceGrades grade = getServiceGradeByCode(serviceGrade);
		
		int daysOnfMonth = CalendarUtil.diffDaysOfMonth(bill.getServiceStart(), bill.getServiceEnd());
		double amount = 0;
		double amountForUser = 0;
		double amountForByte = 0;
		
		amountForUser = bill.getAvgUsers()
				* ((double)bill.getServiceDays()/(double)daysOnfMonth)
				* grade.getPricePerUser();
		
		if (isChargeStoageUsage) {
			amountForByte = ((bill.getAvgBytes()/CommonProperty.GB) - (bill.getAvgUsers()*grade.getGigaPerUser()))	// 평균사용량 - 사용자당기본제공량
					* ((double)bill.getServiceDays()/(double)daysOnfMonth)
					* grade.getPricePerGiga();
			
			if (amountForByte < 0) { amountForByte = 0; }
		}
		amount = amountForUser + amountForByte;
		amount = Math.floor(amount);
		return (int)amount;
	}
	
	private static String makeMerchant_uid(String domainName, Date serviceEnd) throws Exception {
		if (serviceEnd == null) { serviceEnd = new Date(); }
		return String.format("%s_%s_%d", domainName, CalendarUtil.toString(serviceEnd, "yyyyMMdd"), new Date().getTime());
	}

	@Override
	public void removeBills(String billId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			removeBills(mgr, billId);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private void removeBills(EntityManager mgr, String billId) {
		doRemoveTransaction(mgr, Bills.class, billId);
	}

	@Override
	public Domains contractService(String domainName, String serviceGrade, Customers customer) throws Exception {
		customer.setCustomer_uid(domainName);
		boolean isValidCustomer = verifyCustomer(customer);
		if (isValidCustomer) {
			return adminService.changeDomainServiceType(domainName, ServiceType.DEFERRED, serviceGrade, true, true);
		} else {
			throw new Exception("Invalid customer information.");
		}
	}
	
	@Override
	public Domains cancelService(String domainName, String reason) throws Exception {
		// 서비스를 해지할 경우 현재까지의 서비스 금액에 대해 결재를 시도한다.(전에 지불하지 않은것에 대해서도)
		Date serviceEnd = new Date();
		// 서비스 중지일까지의 서비스 사용량 수집
		summarizeUsageForBills(domainName, serviceEnd);
		// 수집한 데이터에 대해서 결재 시도
		paymentDomain(domainName, false);
		
		// 결재 결과 목록 
		List<Bills> billResults = listBills(domainName, null, null, null).getResultList();
		Map<PaidStatus, List<Bills>> resultsMap = new HashMap<PaidStatus, List<Bills>>();
		
		for (Bills bill : billResults) {
			if (resultsMap.get(bill.getPaidStatus()) == null) { resultsMap.put(bill.getPaidStatus(), new ArrayList<Bills>()); }
			resultsMap.get(bill.getPaidStatus()).add(bill);
		}
		if (StringUtils.isBlank(reason)) { reason = "사용자 서비스 중지 요청"; }
		
		int paidCount = resultsMap.get(PaidStatus.paid).size();
		int readyCount = resultsMap.get(PaidStatus.ready).size();
		int failedCount = resultsMap.get(PaidStatus.failed).size();
		int cancelledCount = resultsMap.get(PaidStatus.cancelled).size();
		int subscribedCount = resultsMap.get(PaidStatus.subscribed).size();
		
		reason = String.format("%s [결재 -%d/미결재-%d/실패-%d/취소-%d/예약-%d]", reason, paidCount, readyCount, failedCount, cancelledCount, subscribedCount);
		Domains domain = adminService.disableDomainService(domainName, serviceEnd, reason);
		// TODO : 고객정보를 가지고 있을지는 좀더 검토
		//removeCustomer(KeyUtil.createCustomerKeyString(domainName));
		return domain;
	}
	
	@Override
	public Domains changeService(String domainName, String serviceGrade) throws Exception {
		return adminService.changeDomainServiceType(domainName, ServiceType.DEFERRED, serviceGrade, true, true);
	}
	
	@Override
	public Customers changeCustomer(String domainName, Customers customer) throws Exception {
		customer.setCustomer_uid(domainName);
		boolean isValidCustomer = verifyCustomer(customer);
		if (!isValidCustomer) {
			throw new Exception("Invalid customer information.");
		}
		return customer;
	}
	@Override
	public Customers changeCustomerContactInfo(String domainName, Customers customer) throws Exception {
		customer.setCustomer_uid(domainName);
		Customers origin = getCustomer(customer.getCustomerId());
		origin.setBuyer_name(customer.getBuyer_name());
		origin.setBuyer_email(customer.getBuyer_email());
		origin.setBuyer_tel(customer.getBuyer_tel());
		origin.setBuyer_addr(customer.getBuyer_addr());
		origin.setBuyer_postcode(customer.getBuyer_postcode());
		
		return insertOrUpdateCustomer(origin);
	}
	
	private boolean verifyCustomer(Customers customer) throws Exception {
//		customer.setCard_number("9410-1000-0934-8635"); // 04/19
//		customer.setBirth("700512");
//		customer.setExpiry("2019-04");
//		customer.setPwd_2digit("02");
//		customer.setCustomer_uid("MyDomain");
//		customer.setBuyer_name("심현우");
//		customer.setBuyer_email("hyeunwoo.shim@forecs.net");
//		customer.setBuyer_tel("01034600512");
//		customer.setBuyer_addr("경기도 성남시 판교로 253 이노밸리 C동 708호");
//		customer.setBuyer_postcode("12345");
		
		IamportManager.validCardInfo(customer);
		
		Bills verifiedBill = new Bills();
		
		verifiedBill.setAmount(1000);
		verifiedBill.setDomainName(customer.getCustomer_uid());
		verifiedBill.setName("Cocoworks 카드 결재 정상 확인");
		verifiedBill.setCustomer(customer);
		verifiedBill.setSite(IamportManager.BILL_SITE);
		
		try {
			verifiedBill = payment(verifiedBill, false);

			if (PaidStatus.paid.equals(verifiedBill.getPaidStatus())) {
				insertOrUpdateCustomer(customer);
				cancelPaymentQueue(verifiedBill);
				return true;
			} else {
				return false;
			}
			
//			if (PaidStatus.paid.equals(verifiedBill.getPaidStatus())) {
//				verifiedBill.setName("Cocoworks 카드 결재 정상 확인-승인취소");
//				IamportManager.cancelIamportPayment(new CancelInfo(verifiedBill, "Cocoworks 카드 결재 정상 확인-승인취소"));
//				insertOrUpdateCustomer(customer);
//				return true;
//			} else {
//				return false;
//			}
		} catch (Exception ex) {
			LOG.warning("[verifyCustomer error!] " + ex.getMessage());
			return false;
		}
	}
	
	@Override
	public void scheduledPayments() {
		try {
			Queue queue = QueueFactory.getQueue(CommonProperty.PAYMENT_DOMAIN_QUEUE_NAME);
			List<Domains> domains = listDomains(ServiceType.DEFERRED, BlockType.AUTO);
			long paymentTime = new Date().getTime();
			
			if (MainModule.serviceMode) {
				for (Domains domain : domains) {
					TaskOptions taskOption = TaskOptions.Builder
				            .withUrl(CommonProperty.PAYMENT_DOMAIN_URL)
				            .param(PARAM.DOMAINNAME, domain.getDomainName())
				            .etaMillis(paymentTime)
				            .method(Method.POST);
				    
					paymentTime += 10;
					
					try {
						queue.add(taskOption);
					} catch (Exception ex) {
						LOG.warning(String.format("[Scheduled payment queue - %s] %s ", domain.getDomainName(), ex.getMessage()));
					}
					//paymentDomain(domain.getDomainName(), true);
				}
			} else {
				for (Domains domain : domains) {
					scheduledPayments(domain.getDomainName());
				}
			}
		} catch (Exception ex) {
			LOG.warning("[Scheduled Payments]" + ex.getMessage());
		}
	}
	private void cancelPaymentQueue(Bills bill) {
		try {
			Queue queue = QueueFactory.getQueue(CommonProperty.PAYMENT_DOMAIN_QUEUE_NAME);
			String reason = "Cocoworks 카드 결재 정상 확인-승인취소";
			long cancelTime = new Date().getTime() + 10000;
			
			if (MainModule.serviceMode) {
				TaskOptions taskOption = TaskOptions.Builder
			            .withUrl(CommonProperty.PAYMENT_CANCEL_DOMAIN_URL)
			            .param(PARAM.DOMAINNAME, bill.getDomainName())
			            .param(PARAM.MERCHANT_UID, bill.getMerchant_uid())
			            .param(PARAM.AMOUNT, String.valueOf(bill.getAmount()))
			            .param(PARAM.REASON, reason)
			            .etaMillis(cancelTime)
			            .method(Method.POST);
			    
					queue.add(taskOption);
			} else {
				IamportManager.cancelIamportPayment(new CancelInfo(bill, reason));
			}
		} catch (Exception ex) {
			LOG.warning(String.format("[cancelPaymentQueue - %s] %s", bill.getDomainName(), ex.getMessage()));
		}
	}
	
	@Override
	public void scheduledPayments(String domainName) {
		paymentDomain(domainName, true);
	}
	
	// 예약 대신에 한번만 실시간으로 요청시에 사용
	private Bills payment(Bills bill, boolean isAgain) throws Exception {
		try {
			Bills onceBill = (Bills)CopyUtil.copyDeeply(bill);
			onceBill.setMerchant_uid(makeMerchant_uid(onceBill.getDomainName(), bill.getServiceEnd()));
			Customers customer = onceBill.getCustomer();
			if (isAgain) {
				customer = getCustomer(bill.getDomainName());
				onceBill.setCustomer(customer);
			}
			
			return IamportManager.oneTimePayment(onceBill, isAgain);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public List<Bills> paymentDomain(String domainName, boolean isScheduledMode) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			// 이전의 데이터를 모두 조회하는것이 아니라, 현재일보다 3개월전의 데이터만 조회를 한다.
			// 결재 실패한 뒤, 2개월이 지나면 더이상 결제 시도를 하지 않을 예정이므로, 이전의 데이터는 무의미하다.
			// 하지만, 사용자의 요청에 의한 결재는 결재가 안된 모든 데이터를 조회해야 하기때문에 조건에 포함시키지 않는다.
			Date queryStartDate = null;
			if (isScheduledMode) { queryStartDate = CalendarUtil.addMonth(new Date(), -3); }
			
			DsQuery<Bills> dsQuery = new DsQuery<>(Bills.class)
					.eq(FLD.domainName, domainName)
					.ge(FLD.serviceStart, queryStartDate)
					.sort(FLD.serviceEnd, SortDirection.ASC);
			
			List<Bills> results = dsQuery.execute(mgr);
			List<Bills> bills = new ArrayList<Bills>();
			for (Bills bill : results) {
				try {
					// 혹시 코코웤스가 아닌 사용자가 직접 카드 승인을 취소한 경우를 대비하여, 이미 승인이 완료된 건에 대해서 취소했을 경우, 해당 빌링 정보를 취소상태로 저장한다. 
					boolean isCanceled = false;
					if (PaidStatus.paid.equals(bill.getPaidStatus()) 
							|| PaidStatus.cancelled.equals(bill.getPaidStatus())) {
						
						if (IamportManager.isCanceledIamportBills(bill)) {
							bill.setPaidStatus(PaidStatus.cancelled);
							bill = updateBills(bill);
							isCanceled = true;
						} else {
							continue;
						}
					}
					
					// scheduled 모드가 아닌경우(즉, 사용자의 요청에 의해 결재가 이루어질것을 대비)는 결재 시도일에 상관없이 결재를 수행한다.
					// 결재 시도는 매일 하는것이 아니라, 결재 시도일에 해당될 경우 처리한다.
					// 결재가 취소된 경우에는 결재 재시도를 하지 않는다.
					if (!isCanceled &&
							(!isScheduledMode || (isScheduledMode && isPaymentTryDay()))) {
						bill = payment(bill, true);
						//bill.setPaidStatus(PaidStatus.failed);	// for test
						
						// 결재가 성공적으로 이루어지면 결재 정보 업데이트를 한다.
						if (bill != null) {
							bill = updateBills(bill);
							bills.add(bill);
						}
						// TODO : bill 실패시 이메일이나 문자 메시지 보내기
						// 결재가 성공적으로 이루어지면 도메인의 서비스 상태를 enable로 변경하거나 유지
						if (PaidStatus.paid.equals(bill.getPaidStatus())) {
							adminService.enableDomainService(domainName, bill.getServiceEnd(), "성공적으로 결재가 완료되었습니다.");
							//adminService.enableDomainService(domainName, bill.getPaymentDate(), "성공적으로 결재가 완료되었습니다.");
						}
					}
					
					// 결재정보가 성공적으로 되었을 경우에는 수행하지 않는다.
					// 결재가 실패하더라도 한달간 서비스를 유지시켜준다. 이후에도 결재가 진행되지 않았을 경우에는 해당 도메인을 Block 처리한다.
					// 또한, 취소한 결재건의 Service가 Available한지도 검사한다.
					if (!isServiceAvailable(bill)) {
						Date expirationDate = getServiceAvailableDate(bill);
						adminService.disableDomainService(domainName, expirationDate, "결재가 실패되었거나 취소되었습니다.");
						break;
					}
					
					//Thread.sleep(1000);
				} catch (Exception ex) { break; }
			}
			return bills;
		} catch (Exception ex) {
			LOG.warning("[paymentAllForDomain]" + ex.getMessage());
			return null;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private Date getServiceAvailableDate(Bills bill) {
		return CalendarUtil.addMonth(bill.getServiceStart(), 2);
	}
	private boolean isServiceAvailable(Bills bill) {
		if (PaidStatus.paid.equals(bill.getPaidStatus())
				|| PaidStatus.ready.equals(bill.getPaidStatus())
				) { return true; }
		
		Date availDate = CalendarUtil.addMonth(bill.getServiceStart(), 2);
		if (availDate.compareTo(new Date()) < 0) { return false; }
		return true;
	}
	private boolean isPaymentTryDay() {
		int currDay = CalendarUtil.getCurrentDay();
		return paymentTryDates.contains(currDay);
	}

	@Override
	public Customers getCustomer(String customerId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Customers customer = doFind(mgr, Customers.class, customerId);
			if (customer != null && IamportManager.getIamportCustomer(customer.getCustomer_uid()) != null) {
				return customer;
			} else {
				return null;
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private Customers insertOrUpdateCustomer(Customers customer) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Customers iamportCustomer = IamportManager.putIamportCustomer(customer);
			
			if (iamportCustomer != null) {
				customer.setKey(KeyUtil.createCustomerKey(customer.getCustomer_uid()));
				
				if (contains(mgr, Customers.class, customer.getKey())) {
					customer = doMergeTransaction(mgr, customer);
				} else {
					doPersistTransaction(mgr, customer);
				}
			}
			return customer;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@SuppressWarnings("unused")
	private void removeCustomer(String customerId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Customers customer = doFind(mgr, Customers.class, customerId);
			
			if (IamportManager.deleteIamportCustomer(customer.getCustomer_uid()) != null) {
				doRemoveTransaction(mgr, customer);
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Bills cancelPayment(String billId, String reason) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		try {
			Bills cancelBill = getBills(billId);
			
			if (cancelBill == null) {
				throw new UnavailableException("[cancelIamportBill] cannot found paid inforamtion.");
			}
			
			String merchant_uid = cancelBill.getMerchant_uid();
			IamportBill iamportBill = getIamportBill(merchant_uid);
			cancelBill.setIamportBill(iamportBill);
			
			if (!PaidStatus.paid.equals(PaidStatus.valueOf(iamportBill.getStatus()))) {
				throw new UnavailableException("Iamport payment status is not 'paid'("+iamportBill.getStatus()+")");
			}
			if (!PaidStatus.paid.equals(cancelBill.getPaidStatus())) {
				throw new UnavailableException("Payment information was not applied in domain.("+cancelBill.getPaidStatus()+")");
			}
			
			if (new Date().compareTo(CalendarUtil.addDay(iamportBill.getPaidDate(), PAYMENT_CANCEL_TERMS)) > 0) {
				throw new UnavailableException(String.format("Payment cancellation is possible within %d days!", PAYMENT_CANCEL_TERMS));
			}
			IamportBill iamportCancelledBill = IamportManager.cancelIamportPayment(new CancelInfo(cancelBill, reason));
			
			final PaidStatus cancelledBillStatus = PaidStatus.valueOf(iamportCancelledBill.getStatus());
			cancelBill.setPaidStatus(cancelledBillStatus);
			cancelBill.setIamportBill(iamportCancelledBill);
			cancelBill.setSite(IamportManager.BILL_SITE);
			
			if (!contains(Bills.class, cancelBill.getKey())) {
				cancelBill = insertBills(cancelBill);
			} else {
				cancelBill = updateBills(cancelBill);
			}
			
			return cancelBill;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	
	
	//
	@Override
	public ServiceGrades getServiceGrade(String serviceGradeId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			ServiceGrades serviceGrade = doFind(mgr, ServiceGrades.class, serviceGradeId);
			if (serviceGrade == null) { serviceGrade = createDefaultServiceGrades(); }
			return serviceGrade;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public ServiceGrades getServiceGradeByCode(String serviceGrade) {
		if (StringUtils.isBlank(serviceGrade)) { serviceGrade = DEFAULT_SERVICE_GRADE; }
		return getServiceGrade(KeyUtil.createServiceGradeKeyString(serviceGrade));
	}
	@Override
	public ServiceGrades insertOrUpdateServiceGrades(ServiceGrades serviceGrade) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			serviceGrade.setKey(KeyUtil.createServiceGradeKey(serviceGrade.getServiceGrade()));
				
			if (contains(mgr, ServiceGrades.class, serviceGrade.getKey())) {
				serviceGrade = doMergeTransaction(mgr, serviceGrade);
			} else {
				doPersistTransaction(mgr, serviceGrade);
			}
			return serviceGrade;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public void removeServiceGrade(String serviceGradeId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			ServiceGrades serviceGrade = doFind(mgr, ServiceGrades.class, serviceGradeId);
			if (serviceGrade != null) {
				serviceGrade.setDeleteYN(Y);
				doMergeTransaction(mgr, serviceGrade);
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public List<ServiceGrades> listServiceGrades() throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<ServiceGrades> dsQuery = new DsQuery<>(ServiceGrades.class)
					.eq(FLD.deleteYN, null);
			return dsQuery.execute(mgr);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private ServiceGrades createDefaultServiceGrades() {
		ServiceGrades serviceGrade = new ServiceGrades();
		serviceGrade.setServiceGrade(DEFAULT_SERVICE_GRADE);
		serviceGrade.setTitle("기본");
		serviceGrade.setPricePerUser(6900);
		serviceGrade.setPricePerGiga(150);
		serviceGrade.setGigaPerUser(5);
		
		try {
			insertOrUpdateServiceGrades(serviceGrade);
		} catch (Exception ex) {}
		
		return serviceGrade;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	public static Bills testUpdateBillPaidStatus(String billId, PaidStatus paidStatus) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		try {
			
			Bills bill = doFind(mgr, Bills.class, billId);
			bill.setPaidStatus(paidStatus);
			return doMergeTransaction(mgr, bill);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
}
