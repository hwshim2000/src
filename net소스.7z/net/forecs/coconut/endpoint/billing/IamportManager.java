package net.forecs.coconut.endpoint.billing;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.UnavailableException;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.billing.CancelInfo;
import net.forecs.coconut.common.code.billing.IamportBill;
import net.forecs.coconut.common.code.billing.PaidStatus;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.rest.JerseyClient;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.validator.routines.DateValidator;
import org.apache.commons.validator.routines.IntegerValidator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class IamportManager {
	private static final Logger LOG = Logger.getLogger(IamportManager.class.getName());
	public final static String BILL_SITE = "IAMPORT";
	
	private final static String IMP_KEY = "imp_key";
	private final static String IMP_SECRET = "imp_secret";
	private final static String ACCESS_TOKEN = "access_token";
	private final static String EXPIRED_AT = "expired_at";

	private final static String IAMPORT_IMP_KEY;
	private final static String IAMPORT_IMP_SECRET;

	private final static String IAMPORT_URL = "https://api.iamport.kr";
	private final static String IAMPORT_TOKEN_URL = IAMPORT_URL+"/users/getToken";
	private final static String IAMPORT_PAYMENTS_URL = IAMPORT_URL+"/payments";
	private final static String IAMPORT_PAYMENTS_CANCEL_URL = IAMPORT_PAYMENTS_URL+"/cancel";
	private final static String IAMPORT_PAYMENTS_FIND_URL = IAMPORT_URL+"/payments/find";
	private final static String IAMPORT_SUBSCRIBE_URL = IAMPORT_URL+"/subscribe";
	private final static String IAMPORT_SUBSCRIBE_PAYMENTS_URL = IAMPORT_SUBSCRIBE_URL+"/payments";
	private final static String IAMPORT_SUBSCRIBE_ONETIME_URL = IAMPORT_SUBSCRIBE_PAYMENTS_URL+"/onetime";
	private final static String IAMPORT_SUBSCRIBE_AGAIN_URL = IAMPORT_SUBSCRIBE_PAYMENTS_URL+"/again";
//	private final static String IAMPORT_SUBSCRIBE_SCHEDULE_URL = IAMPORT_SUBSCRIBE_PAYMENTS_URL+"/schedule";
//	private final static String IAMPORT_SUBSCRIBE_UNSCHEDULE_URL = IAMPORT_SUBSCRIBE_PAYMENTS_URL+"/unschedule";
	private final static String IAMPORT_CUSTOMER_URL = IAMPORT_SUBSCRIBE_URL+"/customers";
	
	private static String IAMPORT_TOKEN = null;
	private static int IAMPORT_EXPIRED_AT = 0;
	
	private final static String CODE = "code";
	private final static String MESSAGE = "message";
	private final static String RESPONSE = "response";
	private final static String NEXT = "next";
	private final static String LIST = "list";
	
	static {
		if (MainModule.serviceMode) {
			IAMPORT_IMP_KEY = "4821342432749395";	// REAL
			IAMPORT_IMP_SECRET = "5xdNBVv0KI988mDvDpXyMS51x7Z7RWqXtEL4zg5kZfs7C6DfwANitTk00j8SfyPJdBONSU8R9BZMHC1d";	// REAL
		} else {
			IAMPORT_IMP_KEY = "0318681255813968";	// TEST
			IAMPORT_IMP_SECRET = "fuAkmEfr2qlEhtTM0LTnJAba8lUKBCQQ7qbu4rW7RhL8KFVKrO8apjkxFeigR87YzjsEKpLBGwKrcFbD";	// TEST
		}
	}
	
	private static String getIamportToken() throws Exception {
		try {
			long now = (new Date().getTime()/1000) + 1;
			
			if (now < IAMPORT_EXPIRED_AT && StringUtils.isNotBlank(IAMPORT_TOKEN)) {
				return IAMPORT_TOKEN;
			}
			
			Map<String, Object> entities = new HashMap<String, Object>();
			entities.put(IMP_KEY, IAMPORT_IMP_KEY);
			entities.put(IMP_SECRET, IAMPORT_IMP_SECRET);
			
			String responseStr = post(IAMPORT_TOKEN_URL, null, entities);
			ObjectMapper om = new ObjectMapper();
			JsonNode jn = om.readTree(responseStr);
			validResponse(jn);
        	JsonNode tokenNode = jn.findValue(ACCESS_TOKEN);
        	JsonNode expiredAtNode = jn.findValue(EXPIRED_AT);
        	
        	IAMPORT_EXPIRED_AT = expiredAtNode.asInt();
        	IAMPORT_TOKEN = tokenNode.asText();
        	
			return IAMPORT_TOKEN;
		} catch (MalformedURLException ex) {
			throw ex;
		} catch (IOException ex) {
			throw ex;
		}
	}
	public static IamportBill getIamportBill(String merchant_uid) throws Exception {
		try {
			final String url = String.format("%s/%s", IAMPORT_PAYMENTS_FIND_URL, merchant_uid);
			
			String responseStr = get(url, getIamportToken());
			IamportBill bill = parseIamportBill(responseStr);
			
			return bill;
		} catch (MalformedURLException ex) {
			throw ex;
		} catch (RuntimeException ex) {
			throw ex;
		} catch (IOException ex) {
			throw ex;
		}
	}
	
	public static QueryResult<IamportBill> listIamportBills(PaidStatus paidStatus, String cursorString) throws Exception {
		try {
			final String imp_token = getIamportToken();
			String status = PaidStatus.all.toString();
			if (paidStatus != null) { status = paidStatus.toString(); }
			int page = 1;
			if (StringUtils.isNotBlank(cursorString)) {
				page = NumberUtils.isNumber(cursorString)?Integer.parseInt(cursorString):1;
			}
			
			final String url = String.format("%s/status/%s?page=%d", IAMPORT_PAYMENTS_URL, status, page); 
			String responseStr = get(url, imp_token);
			ObjectMapper om = new ObjectMapper();

			om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

			JsonNode jn = om.readTree(responseStr);
			validResponse(jn);
        	JsonNode responseNode = jn.get(RESPONSE);
        	if (responseNode == null) { return new QueryResult<IamportBill>(); }
//        	Integer total = responseNode.get("total").asInt();
//        	Boolean previous = responseNode.get("previous").asBoolean();
        	Boolean next = responseNode.get(NEXT).asBoolean();
        	JsonNode listNode = responseNode.get(LIST);
        	if (listNode == null) { return new QueryResult<IamportBill>(); }
        	
			String listStr = listNode.toString();
			
			List<IamportBill> billList = om.readValue(listStr, new TypeReference<ArrayList<IamportBill>>(){});
			if (next) {	cursorString = String.valueOf(++page); }
			else { cursorString = null; }
			 
			return new QueryResult<IamportBill>(billList, cursorString);
		} catch (MalformedURLException ex) {
			throw ex;
		} catch (IOException ex) {
			throw ex;
		}
	}
	
	public static Customers deleteIamportCustomer(String customer_uid) {
		try {
			final String imp_token = getIamportToken();
			final String url = String.format("%s/%s", IAMPORT_CUSTOMER_URL, customer_uid);
			String responseStr = delete(url, imp_token);
				
			return parseCustomer(responseStr);
		} catch (Exception ex) {
			LOG.warning("[deleteCustomer] : " + ex.getMessage());
			return null;
		}
	}
	
	// 예약 대신에 한번만 실시간으로 요청시에 사용
	public static Bills oneTimePayment(Bills onceBill, boolean isAgain) throws Exception {
		try {
			String imp_token = getIamportToken();
			Map<String, Object> entities = onceBill.toIamportEntities(isAgain);
			
			try {
				String responseStr = null;
				if (!isAgain) {
					responseStr = post(IAMPORT_SUBSCRIBE_ONETIME_URL, imp_token, entities);
				} else {
					responseStr = post(IAMPORT_SUBSCRIBE_AGAIN_URL, imp_token, entities);
				}
				IamportBill iamportBill = parseIamportBill(responseStr);
				validIamportBills(onceBill, iamportBill);
				
				onceBill.setIamportBill(iamportBill);
				onceBill.setPaidStatus(PaidStatus.valueOf(iamportBill.getStatus()));
				onceBill.setTryCount(onceBill.getTryCount()+1);
				onceBill.setPaymentDate(iamportBill.getPaidDate());
				
				return onceBill;
			} catch (Exception ex) {
				LOG.warning(String.format("[onetimePayment] %s : Faild onetime payment.", onceBill.getDomainName()));
				// 결제도중 예외 발생시, Socket Timeout등의 이유로 인해, 결제가 성공하였지만, 결과값을 제대로 못받아오는 경우가 있으므로
				// 결제도중 모든 예외에 대해서, 결제 취소를 무조건 실행 시킨다.
				try {
					cancelIamportPayment(new CancelInfo(onceBill, ex.getMessage()));
				} catch (Exception e) { LOG.warning("[CancelIamportBill] " + e.getMessage());}
				throw ex;
			}
		} catch (MalformedURLException ex) {
			throw ex;
		} catch (IOException ex) {
			throw ex;
		}
	}

	public static IamportBill cancelIamportPayment(CancelInfo cancelInfo) throws Exception {
		try {
			//CancelInfo cancelInfo = cancelBill.getCancelInfo();
			final String imp_token = getIamportToken();
			
			String responseStr = post(IAMPORT_PAYMENTS_CANCEL_URL, imp_token, cancelInfo);
			
			IamportBill cancelledBill = parseIamportBill(responseStr);
			final PaidStatus cancelledBillStatus = PaidStatus.valueOf(cancelledBill.getStatus());
			
			if (cancelledBill == null || !PaidStatus.cancelled.equals(cancelledBillStatus)) {
				throw new UnavailableException("Payment did not cancel."); 
			}
			//////////////////////////unschedulePaymentsSubscribe(cancelBill.getDomainName());
			
			return cancelledBill;
		} catch (MalformedURLException ex) {
			throw ex;
		} catch (IOException ex) {
			throw ex;
		}
	}
	
	public static Customers putIamportCustomer(Customers customer) throws Exception {
		try {
			final String imp_token = getIamportToken();
			final String url = String.format("%s/%s", IAMPORT_CUSTOMER_URL, customer.getCustomer_uid());
			
			String responseStr = post(url, imp_token, customer.toIamportEntities());
			return parseCustomer(responseStr);
		} catch (Exception ex) {
			LOG.warning("PutCustomer] : " + ex.getMessage());
			throw new UnavailableException(ex.getMessage());
		}
	}
	
	public static Customers getIamportCustomer(String customer_uid) {
		try {
			final String imp_token = getIamportToken();
			final String url = String.format("%s/%s", IAMPORT_CUSTOMER_URL, customer_uid);
			String responseStr = get(url, imp_token);
			//System.out.println("==========="+responseStr);
			return parseCustomer(responseStr);
		} catch (Exception ex) {
			LOG.warning("[getCustomer] : " + ex.getMessage());
			return null;
		}
	}
	
	private static void validIamportBills(Bills bill, IamportBill iamportBill) throws Exception {
		if (!isValidIamportBills(bill, iamportBill)) {
			throw new UnavailableException("Invalid payment information.");
		}
	}
	private static boolean isValidIamportBills(Bills bill, IamportBill iamportBill) {
		if (!PaidStatus.paid.equals(PaidStatus.valueOf(iamportBill.getStatus()))) { return false; }
		if (iamportBill.getAmount() == null || bill.getAmount() <= 0) { return false; }
		if (NumberUtils.compare(iamportBill.getAmount(), bill.getAmount()) != 0) { return false; }
		
		return true;
	}
	public static boolean isCanceledIamportBills(Bills bill) {
		try {
			IamportBill iamportBill = getIamportBill(bill.getMerchant_uid());
			if (iamportBill == null) { return false; }
			if (StringUtils.equals(PaidStatus.cancelled.toString(), iamportBill.getStatus()) &&
					!StringUtils.equals(bill.getPaidStatus().toString(), iamportBill.getStatus())) {
				return true;
			}
			
			return false;
		} catch (Exception ex) { 
			LOG.warning("[isCanceledIamportBills] " + ex.getMessage());
			return false;
		}
	}
	
	private static IamportBill parseIamportBill(String responseStr) throws JsonProcessingException, IOException, UnavailableException {
		ObjectMapper om = new ObjectMapper();

		om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

		JsonNode jn = om.readTree(responseStr);
		validResponse(jn);
    	JsonNode responseNode = jn.get(RESPONSE);
    	String resultStr = responseNode.toString();
    	//System.out.println(resultStr);
		return om.readValue(resultStr, IamportBill.class);
	}
	
	private static Customers parseCustomer(String responseStr) throws JsonProcessingException, IOException, UnavailableException {
		ObjectMapper om = new ObjectMapper();

		om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

		JsonNode jn = om.readTree(responseStr);
		validResponse(jn);
    	JsonNode responseNode = jn.get(RESPONSE);
    	
		String resultStr = responseNode.toString();
		return om.readValue(resultStr, Customers.class);
	}
	
	private static void validResponse(JsonNode jn) throws UnavailableException {
		if (!"0".equals(jn.get(CODE).asText())) {
			LOG.warning(jn.get(MESSAGE).asText());
			//System.out.println(jn.get(MESSAGE).asText());
			throw new UnavailableException(jn.get(MESSAGE).asText());
		}
	}
	
	private static String get(String url, String token) throws Exception {
		return JerseyClient.get(url, token);
//		return NetClient.get(url, token);
//		return ApacheHttpClient.get(url, token);
	}
	private static String post(String url, String token, Object entityObj) throws Exception {
		return JerseyClient.post(url, token, entityObj);
//		return NetClient.post(IAMPORT_TOKEN_URL, token, entityMap);
//		return ApacheHttpClient.post(IAMPORT_TOKEN_URL, token, entityMap);
	}
	private static String delete(String url, String token) throws Exception {
		return JerseyClient.delete(url, token);
//		return NetClient.delete(url, token);
//		return ApacheHttpClient.delete(url, token);
	}
	
	public static void validCardInfo(Customers customer) throws Exception {
		if (!cardNumberValidate(customer.getCard_number())) { throw new UnavailableException("Invalid card number.(dddd-dddd-dddd-dddd)"); }
		//if (StringUtils.isBlank(card_number) || card_number.length() != 19) { throw new UnavailableException("Invalid card number.(dddd-dddd-dddd-dddd)"); }
		if (!DateValidator.getInstance().isValid(customer.getExpiry(), "yyyy-MM")) { throw new UnavailableException("Invalid expiry.(yyy-MM)"); }
		//if (!DateValidator.getInstance().isValid(customer.getBirth(), "yyMMdd")) { throw new UnavailableException("Invalid birth.(yyMMdd)"); }
		if (!IntegerValidator.getInstance().isValid(customer.getPwd_2digit()) || customer.getPwd_2digit().length() != 2) { throw new UnavailableException("Invalid password.(dd)"); }
	}

	private static boolean cardNumberValidate(String number) {
		number = number.replaceAll("-", "");
		String reverse = new StringBuilder().append(number).reverse()
				.toString();

		int sum = 0;
		for (int i = 0; i < number.length(); i++) {
			int digit = Integer.parseInt("" + reverse.charAt(i));
			if (i % 2 == 1) {
				digit *= 2;
				if (digit > 9) {
					digit -= 9;
				}
			}
			sum += digit;
		}
		return sum % 10 == 0;

	}
}
