package net.forecs.coconut.endpoint.billing;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.billing.PaidStatus;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.entity.billing.ServiceGrades;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.user.Role;

import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.config.DefaultValue;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.BILLING_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.BILLING_SERVICE_PACKAGE), description = "billing", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class BillingServiceAPI {
	private final IBillingService billingService;
	
	@Inject
	public BillingServiceAPI(IBillingService billingService/*, IAdminService adminService*/) {
		this.billingService = billingService;
	}
	
	@ApiMethod(name = "contractService", path = "billing/service", httpMethod = HttpMethod.POST)
	@RequiresRoles(value = { Role.ADMIN })
	public Domains contractService(
			@Named(FLD.domainName) String domainName,
			@Nullable @DefaultValue(BillingService.DEFAULT_SERVICE_GRADE) @Named(FLD.serviceGrade) String serviceGrade,
			Customers customer) throws Exception {
		return billingService.contractService(domainName, serviceGrade, customer);
	}
	
	@ApiMethod(name = "changeService", path = "billing/service", httpMethod = HttpMethod.PUT)
	@RequiresRoles(value = { Role.ADMIN })
	public Domains changeService(
			@Named(FLD.domainName) String domainName,
			@Nullable @DefaultValue(BillingService.DEFAULT_SERVICE_GRADE) @Named(FLD.serviceGrade) String serviceGrade) throws Exception {
		return billingService.changeService(domainName, serviceGrade);
	}

	@ApiMethod(name = "cancelService", path = "billing/service", httpMethod = HttpMethod.DELETE)
	@RequiresRoles(value = { Role.ADMIN })
	public Domains cancelService(@Named(FLD.domainName) String domainName, @Nullable @Named(FLD.reason) String reason) throws Exception {
		return billingService.cancelService(domainName, reason);
	}

	@ApiMethod(name = "changeCustomer", path = "billing/customer", httpMethod = HttpMethod.PUT)
	@RequiresRoles(value = { Role.ADMIN })
	public Customers changeCustomer(
			@Named(FLD.domainName) String domainName,
			Customers customer) throws Exception {
		return billingService.changeCustomer(domainName, customer);
	}
	
	@ApiMethod(name = "paymentDomain", path = "billing/payment", httpMethod = HttpMethod.POST)
	@RequiresRoles(value = { Role.ADMIN })
	public List<Bills> paymentDomain(@Named(FLD.domainName) String domainName) {
		return billingService.paymentDomain(domainName, false);
	}
	
	@ApiMethod(name = "changeCustomerContactInfo", path = "billing/customer/contact", httpMethod = HttpMethod.PUT)
	@RequiresRoles(value = { Role.ADMIN })
	public Customers changeCustomerContactInfo(@Named(FLD.domainName) String domainName, Customers customer) throws Exception {
		return billingService.changeCustomerContactInfo(domainName, customer);
	}

	@ApiMethod(name = "listBills", path = "billing/bills", httpMethod = HttpMethod.GET)
	@RequiresRoles(value = { Role.ADMIN })
	public CollectionResponse<Bills> listBills(
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.paidStatus) PaidStatus paidStatus,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit
			) throws Exception {
		QueryResult<Bills> queryResult = billingService.listBills(domainName, paidStatus, cursorString, limit);
		List<Bills> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
	
		return CollectionResponse.<Bills>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "getBills", path = "billing/bills/{billId}", httpMethod = HttpMethod.GET)
	@RequiresRoles(value = { Role.ADMIN })
	public Bills getBills(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.billId) String billId
			) throws Exception {
		return billingService.getBills(billId);
	}
	
	@ApiMethod(name = "listServiceGrades", path = "billing/serviceGrades", httpMethod = HttpMethod.GET)
	@RequiresRoles(value = { Role.ADMIN })
	public List<ServiceGrades> listServiceGrades() throws Exception {
		return billingService.listServiceGrades();
	}
	
	//
	//
	//
	//
	
	@Deprecated
	@ApiMethod(name = "testUpdateBillPaidStatus", path = "billing/bills/paidStatus", httpMethod = HttpMethod.PUT)
	public Bills testUpdateBillPaidStatus(@Named(FLD.billId) String billId, @Named(FLD.paidStatus) PaidStatus paidStatus) throws Exception {
		return BillingService.testUpdateBillPaidStatus(billId, paidStatus);
	}
}
