package net.forecs.coconut.endpoint.billing;

import java.util.Date;
import java.util.List;

import net.forecs.coconut.common.code.billing.IamportBill;
import net.forecs.coconut.common.code.billing.PaidStatus;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.entity.billing.ServiceGrades;
import net.forecs.coconut.entity.domain.Domains;

public interface IBillingService extends ICommonService {
	public abstract Bills getBills(String billId);	// or merchant_uid;
	public abstract Bills getBillsDetail(String billId);	// or merchant_uid;
	public abstract IamportBill getIamportBill(String merchant_uid) throws Exception;
	public abstract void removeBills(String billId);
	public abstract QueryResult<Bills> listBills(
			String domainName,
			PaidStatus paidStatus,
			String cursorString,
			Integer limit) throws Exception;
	public abstract QueryResult<IamportBill> listIamportBills(PaidStatus paidStatus, String cursorString) throws Exception;
	public abstract Domains contractService(String domainName, String serviceGrade, Customers customer) throws Exception;
	public abstract Domains changeService(String domainName, String serviceGrade) throws Exception;
	public abstract Domains cancelService(String domainName, String reason) throws Exception;
	public abstract Customers getCustomer(String customerId) throws Exception;
	public abstract Customers changeCustomer(String domainName, Customers customer) throws Exception;
	
	public abstract void summarizeBills();
	public abstract void summarizeUsageForBills(String domainName, Date endDate);
	
	public abstract List<Bills> paymentDomain(String domainName, boolean isScheduledMode);
	public abstract void scheduledPayments();
	public abstract void scheduledPayments(String domainName);
	
	public abstract Bills cancelPayment(String billId, String reason) throws Exception;
	public abstract Customers changeCustomerContactInfo(String domainName, Customers customer) throws Exception;
	
	//------------------------- for service grades --------------------------------
	public abstract ServiceGrades getServiceGrade(String serviceGradeId);
	public abstract ServiceGrades getServiceGradeByCode(String grade);
	public abstract ServiceGrades insertOrUpdateServiceGrades(ServiceGrades serviceGrade) throws Exception;
	public abstract void removeServiceGrade(String serviceGradeId) throws Exception;
	public abstract List<ServiceGrades> listServiceGrades() throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract Bills applyIamportBill(Bills bill) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
