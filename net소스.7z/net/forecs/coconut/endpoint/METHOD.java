package net.forecs.coconut.endpoint;

public class METHOD {
	public final static String login = "login";
	public final static String serviceLogin = "serviceLogin";
}
