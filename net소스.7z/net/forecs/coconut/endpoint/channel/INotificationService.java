package net.forecs.coconut.endpoint.channel;

import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CountNotifications;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Notifications;
import net.forecs.coconut.entity.user.Users;


public interface INotificationService extends ICommonService {
	public abstract void executeNotification(String userId, String notificationSettingId);
	public abstract void prepareNotification(Activities activity) throws Exception;
	public abstract void prepareNotification(String domainName, String activityId, List<String> notificationUserIds) throws Exception;
	public abstract void prepareNotificationQueue(Activities activity) throws Exception;
	public abstract List<Users> getNotificationUsers(EntityManager mgr, Activities activity) throws UnavailableException, Exception;
	public abstract List<Notifications> updateNotificationsRead(List<String> notificationIdList, boolean isRead) throws Exception;
	public abstract void scheduledRemoveAllNotifications() throws Exception;
	public abstract QueryResult<Activities> listMyNotificationsByActivity(
			String cursorString,
			Integer limit,
			String boardId,
			Boolean mention) throws Exception;
	public abstract CountNotifications countUserNotifications(CountNotifications countNotification) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract void prepareNotification(Activities activity) throws Exception;
//	public abstract List<Users> getNotificationUsers(Activities activity) throws UnavailableException, Exception;
//	public abstract QueryResult<Notifications> listMyNotifications(
//			String cursorString,
//			Integer limit,
//			String boardId,
//			Boolean mention) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
