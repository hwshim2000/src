package net.forecs.coconut.endpoint.channel;

import java.util.List;
import java.util.Map;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.user.Users;


public interface ISyncService extends ICommonService {
	public abstract void sync(Activities activity);
//	@Deprecated
//	public abstract void syncMessage(String domainId, String syncMessage); 
//	@Deprecated
//	public abstract ChannelToken requestSyncToken() throws Exception;
//	@Deprecated
//	public abstract void removeAllUnavailableChannelToken();
//	@Deprecated
//	public abstract void onClientConnected(String channelId) throws Exception;
//	@Deprecated
//	public abstract void onClientDisconnected(String channelId) throws Exception;
//	@Deprecated
//	public abstract Activities getSyncMessage(String domainName, Date syncTime);
	
	public abstract ChannelToken requestFirebaseToken();
	public abstract Map<String, Object> getDomainOnlineUserChannels(String domainId) throws Exception;
	public abstract Map<String, Object> getOnlineUserChannels(String domainId, String userId) throws Exception;
	public abstract List<Users> getDomainOnlineUsers(String domainId) throws Exception;
	public abstract boolean verifyFirebaseIdToken(String token);
	
	public abstract void removeDomainChannel(String domainId) throws Exception;
	public abstract void removeOnlineUserChannel(String domainId, String userId) throws Exception;
	public abstract void removeAllUnavailableDomainChannels() throws Exception;
	public abstract void removeAllUnavailableOnlineUserChannels() throws Exception;
	//@Deprecated
	//public abstract void reconnectFirebaseChannel(ChannelToken channelToken) throws Exception;
}