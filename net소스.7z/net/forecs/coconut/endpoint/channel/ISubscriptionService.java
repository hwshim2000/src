package net.forecs.coconut.endpoint.channel;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.user.Users;


public interface ISubscriptionService extends ICommonService {
	public abstract List<Subscriptions> listSubscriptions(EntityManager mgr, String boardId, String taskId,	String userId, boolean includeUser) throws Exception;
	public abstract List<Subscriptions> listTaskSubscriptions(EntityManager mgr, String boardId, String userId, boolean includeUser) throws Exception;
	public abstract List<Users> getSubscriptionUserList(EntityManager mgr, String taskId) throws Exception;
	public abstract Subscriptions getTaskSubscription(EntityManager mgr, String taskId, String userId) throws Exception;
	public abstract Subscriptions insertSubscriptions(EntityManager mgr, Subscriptions subscription) throws Exception;
	public abstract void removeSubscriptions(EntityManager mgr, List<String> subscriptionIdList) throws Exception;
	public abstract void removeSubscriptions(EntityManager mgr, String subscriptionId) throws Exception;
	
	public abstract int bulkRemoveSubscriptions(String boardId,	String taskId, String userId) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract List<Subscriptions> listTaskSubscriptions(String boardId, String userId) throws Exception;
//	public abstract List<Users> getSubscriptionUserList(String taskId) throws Exception;
//	public abstract Subscriptions updateSubscriptions(EntityManager mgr, Subscriptions subscriptions) throws Exception;
//	public abstract Subscriptions insertTaskSubscription(String boardId, String taskId, String userId, String creatorId) throws Exception;
//	public abstract Subscriptions removeSubscriptions(String subscriptionId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
