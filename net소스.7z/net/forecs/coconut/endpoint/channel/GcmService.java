package net.forecs.coconut.endpoint.channel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.endpoint.account.IUserDeviceService;
import net.forecs.coconut.endpoint.common.ActivityService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.setting.IUserSettingService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.user.UserDevices;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.google.android.gcm.server.Constants;
import com.google.android.gcm.server.InvalidRequestException;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.Notification;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.appengine.api.datastore.Text;

public class GcmService extends CommonService implements IGcmService {
	private static final Logger LOG = Logger.getLogger(GcmService.class.getName());

	// Api Keys can be obtained from the google cloud console
	private static final String GCM_API_KEY = System.getProperty("gcm.api.key");
	
	private final IUserDeviceService userDeviceService;
	private final IUserSettingService userSettingService;

	@Inject
	public GcmService(IUserDeviceService userDeviceService,
			IUserSettingService userSettingService) {
		this.userDeviceService = userDeviceService;
		this.userSettingService = userSettingService;
	}
	
	@Override
	public void sendMessage(Set<String> targetUsers, String message) throws IOException {
        if (StringUtils.isEmpty(message)) {
        	LOG.warning("Not sending empty message.");
            return;
        }

		if (1000 < message.length()) {
			LOG.warning("Message too long. message=" + message);
			return;
		}

		Sender sender = new Sender(GCM_API_KEY);
		Message msg = buildGcmMessage(message);

		int retries = 5;
		QueryResult<UserDevices> queryResult = userDeviceService.listUserDevices(null, null);
		List<UserDevices> deviceList = queryResult.getResultList();
		for (UserDevices device : deviceList) {
			if (!targetUsers.contains(device.getOwner())) { continue; }
			
			String userDeviceId = device.getUserDeviceId();
			String gcmId = device.getGcmId();
			Result result;
			try {
				result = sender.send(msg, gcmId, retries);
			} catch (InvalidRequestException e) {
				LOG.warning("InvalidRequestException : " + e.getMessage());
            	try {
        			userDeviceService.removeUserDevices(userDeviceId);
				} catch (NotFoundException enf) {
                	LOG.warning("Device not found : " + userDeviceId);
				}
            	continue;
			}

			if (result.getMessageId() != null) {
				LOG.info("Message sent to " + gcmId);
				String canonicalRegId = result.getCanonicalRegistrationId();
                if (canonicalRegId != null) {
					LOG.info("GCM Registration ID changed for " + gcmId + " updating to " + canonicalRegId);
					try {
						userDeviceService.removeUserDevices(userDeviceId);
					} catch (NotFoundException e) {
	                	LOG.warning("Device not found : " + userDeviceId);
					}

                	device.setGcmId(canonicalRegId);
					try {
						userDeviceService.insertUserDevices(device);
					} catch (ConflictException e) {
	                	LOG.warning("GCM ID conflict : " + canonicalRegId);
					}
                }
            } else {
                String error = result.getErrorCodeName();
                if (Constants.ERROR_NOT_REGISTERED.equals(error)) {
                	LOG.warning("GCM Registration ID " + gcmId + " no longer registered, removing from datastore.");
                	try {
						userDeviceService.removeUserDevices(userDeviceId);
					} catch (NotFoundException e) {
	                	LOG.warning("Device not found : " + userDeviceId);
					}
                } else {
                	LOG.warning("Error when sending message : " + error);
                }
            }
        }
    }
	
	@Override
	public void sendMessage(Set<String> targetUsers, Activities activity) throws IOException {
	    Sender sender = new Sender(GCM_API_KEY);

		int retries = 5;
		QueryResult<UserDevices> queryResult = userDeviceService.listUserDevices(null, null);
		List<UserDevices> deviceList = new ArrayList<UserDevices>();
		deviceList.addAll(queryResult.getResultList());
		Map<String, UserSetting> settingMap = batchMapUserSettings(deviceList);

		if (MainModule.developmentServer) {
			targetUsers.add(activity.getOwner());
			deviceList.addAll(getTestTargetDevices(activity));
		}
		
		for (UserDevices device : deviceList) {
			if (!targetUsers.contains(device.getOwner())) { continue; }

			UserSetting userSetting = settingMap.get(device.getOwner());
			Message msg = buildGcmMessage(activity, userSetting);

			String userDeviceId = device.getUserDeviceId();
			String gcmId = device.getGcmId();

			Result result;
			try {
				result = sender.send(msg, gcmId, retries);
			} catch (InvalidRequestException e) {
				LOG.warning("InvalidRequestException : " + e.getMessage());
            	try {
        			userDeviceService.removeUserDevices(userDeviceId);
				} catch (NotFoundException enf) {
                	LOG.warning("Device not found : " + userDeviceId);
				}
            	continue;
			}

			if (result.getMessageId() != null) {
				LOG.info("Message sent to " + gcmId);
				String canonicalRegId = result.getCanonicalRegistrationId();
                if (canonicalRegId != null) {
					LOG.info("GCM Registration ID changed for " + gcmId + " updating to " + canonicalRegId);
					try {
						userDeviceService.removeUserDevices(userDeviceId);
					} catch (NotFoundException e) {
	                	LOG.warning("Device not found : " + userDeviceId);
					}

                	device.setGcmId(canonicalRegId);
					try {
						userDeviceService.insertUserDevices(device);
					} catch (ConflictException e) {
	                	LOG.warning("GCM ID conflict : " + canonicalRegId);
					}
                }
            } else {
                String error = result.getErrorCodeName();
                if (Constants.ERROR_NOT_REGISTERED.equals(error)) {
                	LOG.warning("GCM Registration ID " + gcmId + " no longer registered, removing from datastore.");
                	try {
						userDeviceService.removeUserDevices(userDeviceId);
					} catch (NotFoundException e) {
	                	LOG.warning("Device not found : " + userDeviceId);
					}
                } else {
                	LOG.warning("Error when sending message : " + error);
                }
            }
        }
    }

	// jongwook.yi@forecs.net 2015-12-22 : Support iOS notification
	private Notification buildGcmNotification(String message) {
		Notification.Builder nb = new Notification.Builder(null);
		return nb.title("cocoworks").body(message).build();
	}
	private Message buildGcmMessage(String message) {
		Notification notification = buildGcmNotification(message);
		Message.Builder mb = new Message.Builder();
		mb.notification(notification).priority(Message.Priority.HIGH);
		return mb.addData("data", message).build();
	}

	private Message buildGcmMessage(Activities activity, UserSetting userSetting) {
		Messages localeMessage = Messages.localeMessages(userSetting, WRAPPED_CHAR_TYPE.MOBILE);
		String message = localeMessage.getMessage(activity);
		//String message = Messages.getMessage(activity, userSetting);
		message = ActivityService.toLocaleStageString(message, localeMessage);
		
		Text description = activity.getDescription();
		if (description != null && StringUtils.isNotBlank(description.getValue())) {
			message = message + "\n" + description.getValue();
		}
		String mentionedUserNames = activity.getMentionedUserNames();
//		String mentionedUserNames = ActivityService.getMentionedUserNames(activity.getMentionIds());
		if (mentionedUserNames != null && StringUtils.isNotBlank(mentionedUserNames)) {
			message = message + "\n" + mentionedUserNames;
		}
		
		Notification notification = buildGcmNotification(message);
		Message.Builder mb = new Message.Builder();
		mb.notification(notification).priority(Message.Priority.HIGH);
		mb.addData(FLD.activityId, activity.getActivityId());
		mb.addData(FLD.activityKind, activity.getActivityKind().toString());
		mb.addData(FLD.activityType, activity.getActivityType().toString());
		mb.addData(FLD.domainId, activity.getDomainId());
		mb.addData(FLD.boardId, activity.getBoardId());
		mb.addData(FLD.taskId, activity.getTaskId());
		mb.addData(FLD.kindId, activity.getKindId());
		String taskTimelineId = activity.getTaskTimelineId();
		if (StringUtils.isNotBlank(taskTimelineId)) {
			mb.addData(FLD.taskTimelineId, taskTimelineId);
		}
		String taskTimelineCommentId = activity.getTaskTimelineCommentId();
		if (StringUtils.isNotBlank(taskTimelineCommentId)) {
			mb.addData(FLD.taskTimelineCommentId, taskTimelineCommentId);
		}
		
		return mb.build();
	}
	
	private Map<String, UserSetting> batchMapUserSettings(List<UserDevices> devices) {
		// batch로 데이터를 가져올때, settting키가 아닌 userId를 키로 변환해서 가져오도록 구현
		Set<String> userIds = new HashSet<String>();
		for (UserDevices device : devices) {
			userIds.add(device.getOwner());
		}
		return userSettingService.batchMapUserSettings(userIds, CommonProperty.USER_UI_SETTING_NAME);
	}
	
	private static List<UserDevices> getTestTargetDevices(Activities activity) {
		List<UserDevices> devices = new ArrayList<UserDevices>();
		Set<String> gcmKeys = new HashSet<String>();
		// 희라 
//		gcmKeys.add("fMenqbs5bbE:APA91bHvaESc-vv5a8sXSeYfYkIJaEU0A1Z04mEchZwTk2AosBkA2nKET3t3qanQnoTokzGsFNGEDuPDw25NmIYAplSzO-Z2V_qBDAXOKpXAOkH22z1WmohLhge1cg4BB3nEX2dVJszF");
		// 현우
		//gcmKeys.add("fz5bsXmuuXg:APA91bElGb-moMn7nDr-2DJl6SpE4k9r8BvqEDU5-yPuI-ZF5dbW__NONowdahjwaw37D2YnMps_p2B_pjbhuNiUWx703Q5A6HBuUSCZr0no0jpOP3-nBWVG1WXpznjGYgBfVjQwRs2K");
		gcmKeys.add("dm3aMg2Xb5w:APA91bEfG9FDzCsowLMFanGkMqhBhPDEQI4Sfn9EGZHxINEKNGrDpPBVpcuuibPaYrlsaJekrskI3cAf-fLI9A_vL9lftwXMJSJA1JNwa9LPMcTsXvXb0wYnZntIxMfs0oM1oNjzidEs");
		// 철홍 
//		gcmKeys.add("dTgxea8CZpk:APA91bEZxd45mXiGUJBMaXVPz8130sLAVovhnXUg5r5zA6ookk0CqFhxaxNxYteCB6Wyac_UE8fGJKnolDbP8XDCv65-OVxnwcvtCaUkyOA7tZfJjzoCl8lM3PzKhdOxaLlEyOHr3DhZ");
		// 태환
//		gcmKeys.add("e_lfchLphVk:APA91bFO72SSLA0jZcxDdvzyVsemAoIITKsN6vgqoxBddjYTu9w7oZwFKe3sDrufZ1EP8bYQw-cN8ZSa_Wsf8jcijOFAj_hDuAapOj3RD4XMdQVtJMS-JyI7xIQUI-12uv48wDYMP7zn");
		// 지훈
//		gcmKeys.add("cOHxVlsTCvg:APA91bFVMlinVmedKfLnSsXcwtvrq0npg_xml0pnyXKhimnzRqeLEQcd_aREVqcI0KmsetxyAeFvNWzjXuDWaU4Qb9NpcPatPlWuh-D8mDsWYiDoP2InX9xrkxyXzW4Cn_xZZF6ud2wf");
		
//		gcmKeys.add("dVOHe3ezRiI:APA91bEu9aKtsA2lp-23QSzEz7W0dTyXwipEV7a0DZtjoU_DvtGbMUBEqG1Zyhp_GMutWZNjdRdbvbV2--2tyd9eYPK3N-pkaC7J0LHHd93vSWQvHVm2r6pnDtRmWU_zvTPlOLitlhzR");
		
		for (String gcmKey : gcmKeys) {
			UserDevices dev = new UserDevices();
			dev.setOwner(activity.getOwner());
			dev.setGcmId(gcmKey);
			dev.setKey(KeyUtil.createUserDeviceKey(dev));
			devices.add(dev);
		}
		return devices;
	}
}
