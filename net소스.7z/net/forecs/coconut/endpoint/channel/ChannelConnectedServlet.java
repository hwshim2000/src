package net.forecs.coconut.endpoint.channel;

import javax.inject.Singleton;
import javax.servlet.http.HttpServlet;


@Deprecated
@Singleton
public class ChannelConnectedServlet extends HttpServlet {
	private static final long serialVersionUID = 2166371473975590010L;
//	private static final Logger LOG = Logger.getLogger(ChannelConnectedServlet.class.getName());
//
//	private final ISyncService syncService;
//
//	@Inject
//	public ChannelConnectedServlet(ISyncService syncService) {
//		this.syncService = syncService;
//	}
//
//	public void doPost(HttpServletRequest req, HttpServletResponse resp)
//			throws IOException, ServletException {
//		process(req, resp);
//	}
//
//	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		try {
//			ChannelService channelService = ChannelServiceFactory.getChannelService();
//			ChannelPresence presence = channelService.parsePresence(req);
//			String clientId = presence.clientId();
//			
//			syncService.onClientConnected(clientId);
//		} catch (Exception ex) {
//			LOG.warning("[Connection error]" + ex.getMessage());
//			throw new IOException(ex.getMessage());
//		}
//	}
}
