package net.forecs.coconut.endpoint.channel;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;


@Singleton
public class SyncService extends CommonService implements ISyncService {
	private static final Logger LOG = Logger.getLogger(SyncService.class.getName());

//	private final ChannelService channelService;
	private final ObjectMapper om;
	
//	private final static String SYNC_MESSAGE_PREFIX = "SYNC_";
//	private final static String SYNC_GROUP_PREFIX = "SYNCS_";
//	private final static int SYNC_MESSAGE_EXPIRATION_TIME = 3600; // seconds
	
	@Inject
	public SyncService() {
//		channelService = ChannelServiceFactory.getChannelService();

		om = new ObjectMapper();
		om.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
	}

//	@Deprecated
//	private String createChannelTokenId() {
//		return KeyUtil.createChannelTokenKeyString();
//	}
//	@Deprecated
//	private String toChannelId(String channelTokenId) {
//		Key key = KeyFactory.stringToKey(channelTokenId);
//		String channelId = key.getName();	// UUID
//		String domainName = key.getNamespace();
//		if (!StringUtils.isEmpty(domainName)) {
//			channelId += '@' + domainName;
//		}
//		return channelId;	// UUID[@domainName]
//	}
//	@Deprecated
//	private String toChannelTokenId(String channelId) {
//		String domainName = null;
//		int splitPos = channelId.lastIndexOf('@');
//		if (0 < splitPos) {
//			domainName = channelId.substring(splitPos + 1);
//			channelId = channelId.substring(0, splitPos);
//		}
//
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(domainName);
//		String channelTokenId = KeyUtil.createChannelTokenKeyString(channelId);
//		NamespaceManager.set(prevNamespace);
//		return channelTokenId;
//	}
//	
//	@Deprecated
//	@Override
//	public void syncMessage(String domainId, String syncMessage) {
//		String prevNamesapce = NamespaceManager.get();
//		String domainName = KeyFactory.stringToKey(domainId).getName();
//		NamespaceManager.set(domainName);
//		try {
//			List<ChannelToken> channelTokens;
//			try {
//				channelTokens = listChannelToken(domainId, null, null, true);
//			} catch (Exception e) {
//				// Ignored. Not a critical part of application.
//				return;
//			}
//			
//			//if (!MainModule.developmentServer) {
//				for (ChannelToken token : channelTokens) {
//					sync(syncMessage, toChannelId(token.getChannelTokenId()));
//				}
//			//} else {
//				/// if rabbitMQ 
//				/// 만약, 실제로 사용한다면, tasqQueue에 올려서 사용해야 아래 publish 할 경우 속도 저하가 발생할 수 있다.
//				/// 위의 내용 모두 제거후, 아래 publish 함수만 호출하면 된다.
//				//Rbmq.publish(KeyFactory.stringToKey(domainId).getName(), syncMessage);
//				//or
//				//try {
//				//	FirebaseChannel.getInstance().sendFirebaseMessage(domainId, syncMessage);
//				//} catch (Exception ex) {
//				//	LOG.warning("[Send Firebase Message Error] " + ex.getMessage());
//				//	return;
//				//}
//			//}
//		} finally {
//			NamespaceManager.set(prevNamesapce);
//		}
//	}
//	
//	/**
//	 * Sync Message를 TaskQueue에 넣어서 send
//	 * @param syncMessage
//	 */
//	@SuppressWarnings("unused")
//	@Deprecated
//	private void asyncMessage(String domainId, String syncMessage) {
//		try {
//			Queue queue = QueueFactory.getQueue(CommonProperty.ASYNC_MESSAGE_QUEUE_NAME);
//			String secCode = SecurityUtils.getMD5(domainId+syncMessage);
//			
//		    queue.add(TaskOptions.Builder
//		            .withUrl(CommonProperty.ASYNC_MESSAGE_SEND_URL)
//		            .param(PARAM.DOMAINID, domainId)
//		            .param(PARAM.MESSAGE, syncMessage)
//		            .param(PARAM.SECCODE, secCode)
//		            .method(Method.POST));
//		            //.etaMillis(new Date().getTime() + 5000));
//		} finally {}
//	}
//	@Deprecated
//	private void sync(String syncMessage, String channelId) {
//		try {
//			LOG.info("[Push Sync Channel] " + channelId);
//			LOG.info("[Push Sync Message] " + syncMessage);
//			channelService.sendMessage(new ChannelMessage(channelId, syncMessage));
//		} catch (ChannelFailureException ex) {
//			LOG.warning("[ChannelFailuserException] " + ex.getMessage());
//		} finally {}
//	}

	@Override
	public void sync(Activities activity) {
		// hyeunwoo.shim 2017-03-09 Firebase Channel만 사용하도록 변경
		// <!--
		//String syncMessage;
		//try {
		//	syncMessage = om.writeValueAsString(activity);
		//} catch (Exception e) {
		//	LOG.warning(String.format("[syncMessage] Failed to convert Activities(activityId=%s) to JSON.",
		//			activity.getActivityId()));
		//	return;	// Ignored. Activity is not a critical part of application.
		//}
		// -->
		
		String domainId = activity.getDomainId();
		if (StringUtils.isBlank(domainId)) {
			domainId = KeyUtil.createDomainKeyString(activity.getKey().getNamespace());
		}
		// <!--
		// hyeunwoo.shim 2017-03-09 Firebase Channel만 사용하도록 변경
		// //TODO : 향후 제거 대상
		////syncMessage(domainId, syncMessage);
		//asyncMessage(domainId, syncMessage);
		// -->
		
		try {
			sendFirebaseMessage(domainId, activity);
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.warning("[Send Firebase Message Error] " + ex.getMessage());
		}
	}
	
	public void sendFirebaseMessage(String domainId, Activities activity) throws IOException {
		if (null != activity) {
			String channelKey = domainId;
			Map<String, Object> msgMap = new HashMap<String, Object>();
			//msgMap.put(FLD.uid, UUID.randomUUID());
			msgMap.put(FLD.timestamp, new Date().getTime());
			msgMap.put(FLD.activity, activity);
			try {
				msgMap.put(FLD.domain, KeyFactory.stringToKey(domainId).getName());
			} catch (Exception ex) {}
			
			String syncMessage = om.writeValueAsString(msgMap);
			
//			if (MainModule.developmentServer) {
//				FirebaseChannel.getInstance().sendFirebaseMessage(channelKey, syncMessage);
//			} else {
				asyncSendFirebaseMessage(channelKey, syncMessage);
//			}
		}
	}
	
	private void asyncSendFirebaseMessage(String channelKey, String syncMessage) {
		try {
			Queue queue = QueueFactory.getQueue(CommonProperty.ASYNC_FIREBASE_MESSAGE_QUEUE_NAME);
			
		    queue.add(TaskOptions.Builder
		            .withUrl(CommonProperty.ASYNC_FIREBASE_MESSAGE_SEND_URL)
		            .param(PARAM.CHANNELKEY, channelKey)
		            .param(PARAM.MESSAGE, syncMessage)
		            .method(Method.POST));
		            //.etaMillis(new Date().getTime() + 5000));
		} finally {}
	}

//	@Deprecated
//	@Override
//	public ChannelToken requestSyncToken() throws Exception {
//		Users loginUser = getCurrentUser();
//		String domainName = loginUser.getDomainName();
//
//		String domainId = KeyUtil.createDomainKeyString(domainName);
//		String userId = loginUser.getUserId();
//
//		String channelTokenId = createChannelTokenId();
//		return insertChannelToken(createChannelToken(domainId, userId, channelTokenId));
//	}
//	@Deprecated
//	private ChannelToken createChannelToken(String domainId, String userId, String channelTokenId) {
//		ChannelToken channelToken = new ChannelToken(domainId, userId);
//		channelToken.setChannelTokenId(channelTokenId);
//
//		String token = channelService.createChannel(toChannelId(channelTokenId),
//				CommonProperty.CHANNEL_CONNECT_EXPIRATION_TIME);
//
//		channelToken.setToken(token);
//		channelToken.setExpirationDate(getChannelExpirationDate());
//
//		return channelToken;
//	}
//	@Deprecated
//	private Date getChannelExpirationDate() {
//		Calendar cal = Calendar.getInstance();
//		cal.add(Calendar.MINUTE, CommonProperty.CHANNEL_CONNECT_EXPIRATION_TIME);
//		return cal.getTime();
//	}
//
//	@Deprecated
//	private List<ChannelToken> listChannelToken(String domainId, String userId,
//			Boolean valid, Boolean connected) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			DsQuery<ChannelToken> dsQuery = new DsQuery<>(ChannelToken.class)
//					.eq(FLD.deleteYN, null)
//					.eq(FLD.userId, userId);
//
//			List<ChannelToken> resultList = dsQuery.execute(mgr);
//			List<ChannelToken> channelTokenList = new ArrayList<ChannelToken>();
//			
//			for (ChannelToken channelToken : resultList) {
//				if ((valid != null) && (valid != channelToken.isValid())) {
//					continue;
//				}
//				if ((connected != null) && (connected != channelToken.isConnected())) {
//					continue;
//				}
//
//				channelTokenList.add(channelToken);
//			}
//
//			return channelTokenList;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Deprecated
//	private Map<String, List<ChannelToken>> batchMapChannelToken(EntityManager mgr, Collection<String> userIds,
//			Boolean valid, Boolean connected) throws Exception {
//		List<ChannelToken> resultList = batchListByField(mgr, ChannelToken.class, userIds, FLD.userId);
//		Map<String, List<ChannelToken>> channelTokenMap = new HashMap<String, List<ChannelToken>>();
//		
//		for (ChannelToken channelToken : resultList) {
//			if ((valid != null) && (valid != channelToken.isValid())) {
//				continue;
//			}
//			if ((connected != null) && (connected != channelToken.isConnected())) {
//				continue;
//			}
//			if (channelTokenMap.get(channelToken.getUserId()) == null) {
//				channelTokenMap.put(channelToken.getUserId(), new ArrayList<ChannelToken>());
//			}
//			
//			channelTokenMap.get(channelToken.getUserId()).add(channelToken);
//		}
//
//		return channelTokenMap;
//	}
//	@Deprecated
//	private ChannelToken getChannelToken(String channelTokenId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, ChannelToken.class, channelTokenId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Deprecated
//	private ChannelToken insertChannelToken(ChannelToken channelToken) {
//		EntityManager mgr = getEntityManager();
//		try {
//			doPersistTransaction(mgr, channelToken);
//			return channelToken;
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Deprecated
//	private ChannelToken updateChannelToken(ChannelToken channelToken) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			valid(channelToken);
//			doMergeTransaction(mgr, channelToken);
//			return channelToken;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Deprecated
//	private void removeChannelToken(String channelTokenId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			doRemoveTransaction(mgr, ChannelToken.class, channelTokenId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Deprecated
//	@Override
//	public void removeAllUnavailableChannelToken() {
//		List<String> namespaceList = listNamespaces();
//		for (String namespace : namespaceList) {
//			removeAllUnavailableChannelToken(namespace);
//		}
//	}
//	
//	@Deprecated
//	private int removeAllUnavailableChannelToken(String namespace) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(namespace);
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TypedQuery<ChannelToken> query = new QueryBuilder<>(ChannelToken.class)
//					.addClause(FLD.deleteYN, null)
//					.addLTClause(FLD.expirationDate, new Date(), SortDirection.DESC)
//					.build(mgr);
//
//			List<ChannelToken> channelTokens = queryResults(query);
//			doRemoveTransaction(mgr, channelTokens);
//			
//			return channelTokens.size();
//		} catch (Exception ex) {
//			LOG.warning("[Remove all unavailable channel token error]" + ex.getMessage());
//			return 0;
//		} finally {
//			finalizeTransaction(mgr);
//			NamespaceManager.set(prevNamespace);
//		}
//	}
//
//	@SuppressWarnings("unused")
//	@Deprecated
//	private boolean isUserOnline(Users user) {
//		String domainId = KeyUtil.createDomainKeyString(user.getDomainName());
//		String userId = user.getUserId();
//		return isUserOnline(domainId, userId);
//	}
//	
//	@Deprecated
//	private boolean isUserOnline(String domainId, String userId) {
//		try {
//			List<ChannelToken> userTokens = listChannelToken(domainId, userId, null, true);
//			return (userTokens != null) && (0 < userTokens.size());
//		} catch (Exception ex) {
//			LOG.severe("[User online check failure]" + ex.getMessage());
//			return false;
//		}
//	}
//	
//	@Deprecated
//	@SuppressWarnings("unused")
//	private Map<String, Boolean> batchMapIsUserOnline(EntityManager mgr, Collection<String> userIds) {
//		try {
//			Map<String, List<ChannelToken>> userTokensMap = batchMapChannelToken(mgr, userIds, null, true);
//			Map<String, Boolean> userOnlineMap = new HashMap<String, Boolean>();
//			
//			for (String userId : userIds) {
//				if (userTokensMap.get(userId) != null && (0 < userTokensMap.get(userId).size())) {
//					userOnlineMap.put(userId, true);
//				} else {
//					userOnlineMap.put(userId, false);
//				}
//			}
//			return userOnlineMap;
//		} catch (Exception ex) {
//			LOG.severe("[Users online check failure]" + ex.getMessage());
//			return null;
//		}
//	}
//
//	@Deprecated
//	@Override
//	public void onClientConnected(String channelId) throws Exception {
//		String channelTokenId = toChannelTokenId(channelId);
//		ChannelToken channelToken = getChannelToken(channelTokenId);
//		String domainName = KeyFactory.stringToKey(channelToken.getDomainId()).getName();
//		
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(domainName);
//		
//		try {
//			if (channelToken != null) {
//				channelToken.setConnectedDate(new Date());
//				channelToken = updateChannelToken(channelToken);
//				
//				LOG.warning(String.format("[Connected] %s %s", domainName, channelToken.getUserId()));
//			}
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
//
//	@Deprecated
//	@Override
//	public void onClientDisconnected(String channelId) throws Exception {
//		String channelTokenId = toChannelTokenId(channelId);
//		ChannelToken channelToken = getChannelToken(channelTokenId);
//		String domainName = KeyFactory.stringToKey(channelToken.getDomainId()).getName();
//		
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(domainName);
//		
//		try {
//			if (channelToken != null) {
//				removeChannelToken(channelTokenId);
//				LOG.warning(String.format("[Disconnected] %s %s", domainName, channelToken.getUserId()));
//			}
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
//
//	//--> If use pubsub or polling/long polling instead of sync(Activities activity) function.
//	@SuppressWarnings({ "unchecked", "unused" })
//	private void putSyncMessage(Activities activity) {
//		//--> TODO : if pub/sub or polling
//		String domainName = NamespaceManager.get();
//		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(domainName);
//		
//		List<String> syncMessages = (List<String>)mcs.get(SYNC_GROUP_PREFIX + domainName);
//		List<String> activeMessages = new ArrayList<String>();
//		List<Activities> activities = new ArrayList<Activities>();
//		
//		if (syncMessages != null) {
//			for (String key : syncMessages) {
//				Activities a = (Activities)mcs.get(key); 
//				if (a != null) {
//					activities.add(a);
//				}	
//			}
//		}
//		
//		mcs.put(SYNC_MESSAGE_PREFIX + activity.getActivityId(), activity, Expiration.byDeltaSeconds(SYNC_MESSAGE_EXPIRATION_TIME));
//		
//		activities.add(0, activity);
//		sortByCreatedDesc(activities);
//		for (Activities a : activities) {
//			activeMessages.add(SYNC_MESSAGE_PREFIX + a.getActivityId());
//			LOG.warning("[Sync List] " + a.getActivityKind() + ":" + a.getActivityType() + ":" + CalendarUtil.toString(a.getCreated(), "yyyy-MM-dd HH:mm:ss"));
//		}
//		mcs.put(SYNC_GROUP_PREFIX + domainName, activeMessages);
//		
////		String key = SYNC_MESSAGE_PREFIX + activity.getActivityId();
////		activeMessages.add(0, key);
////		mcs.put(key, activity, Expiration.byDeltaSeconds(SYNC_MESSAGE_EXPIRATION_TIME));
////		mcs.put(SYNC_GROUP_PREFIX + domainName, activeMessages);
//	}
//	
//	@Deprecated
//	@SuppressWarnings("unchecked")
//	@Override
//	public Activities getSyncMessage(String domainName, Date syncTime) {
//		//--> TODO : if pub/sub or polling
//		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(domainName);
//		Activities activity = null;
//		
//		List<String> syncMessages = (List<String>)mcs.get(SYNC_GROUP_PREFIX + domainName);
//		if (syncMessages == null || syncMessages.size() == 0) { return null; }
//		
//		for (String key : syncMessages) {
//			Activities a = (Activities)mcs.get(key);
//			
//			if (a == null || a.getCreated().compareTo(syncTime) <= 0) { break; }
//			activity = a;
//		}
//
//		if (activity != null) { 
//			LOG.warning("[Current Activity] " + activity.getActivityKind() + ":" + activity.getActivityType() + ":" + CalendarUtil.toString(activity.getCreated(), "yyyy-MM-dd HH:mm:ss"));
//		} else {
//			LOG.warning("[Current Activity] NONE.");
//		}
//		
//		return activity;
//	}
//	
//	@SuppressWarnings("unused")
//	private static void sortByCreated(List<Activities> list) {
//		//--> TODO : if pub/sub or polling
//		Collections.sort(list, new Comparator<Activities>() {
//	        @Override
//	        public int compare(Activities first, Activities second) {
//	        	if (first.getCreated() == null && second.getCreated() == null) {
//	        		return 0;
//	        	} else if (first.getCreated() == null ) {
//	        		return 1;
//	        	} else if (second.getCreated() == null) {
//	        		return -1;
//	        	}
//	        	
//	        	return first.getCreated().compareTo(second.getCreated());
//	        }
//	    });
//	}
//	private static void sortByCreatedDesc(List<Activities> list) {
//		//--> TODO : if pub/sub or polling
//		Collections.sort(list, new Comparator<Activities>() {
//	        @Override
//	        public int compare(Activities first, Activities second) {
//	        	if (first.getCreated() == null && second.getCreated() == null) {
//	        		return 0;
//	        	} else if (first.getCreated() == null ) {
//	        		return -1;
//	        	} else if (second.getCreated() == null) {
//	        		return 1;
//	        	}
//	        	
//	        	return second.getCreated().compareTo(first.getCreated());
//	        }
//	    });
//	}
	
	@Override
	public ChannelToken requestFirebaseToken() {
		Users loginUser = getCurrentUser();
		String domainId = KeyUtil.createDomainKeyString(loginUser.getDomainName());
//		String token = FirebaseChannel.getInstance().createFirebaseToken(loginUser.getUserId());
		//String token = FirebaseChannel.getInstance().createFirebaseToken(loginUser.getId());
		String token = FirebaseChannel.getInstance().createFirebaseToken(loginUser.getEmail());
		
		ChannelToken channelToken = new ChannelToken(domainId, loginUser.getUserId());
		channelToken.setToken(token);
		channelToken.setConnectedDate(channelToken.getCreated());
		
		//<!--
		// TODO 만일 토큰 발행 후, 발행ChannelToken정보를 서버가 저장할 경우, 클라이언트에서 저장하는 부분을 제거해야 한다.  
		//try {
		//	FirebaseChannel.getInstance().firebaseOnlinePatch(channelToken);
		//} catch (Exception ex) { System.out.println("============================"+ex.getMessage()); }
		//-->
		
		return channelToken; 
	}
	
	@Override
	public Map<String, Object> getDomainOnlineUserChannels(String domainId) throws Exception {
		return FirebaseChannel.getInstance().getDomainOnlineUserChannels(domainId);
	}
	@Override
	public Map<String, Object> getOnlineUserChannels(String domainId, String userId) throws Exception {
		return FirebaseChannel.getInstance().getOnlineUserChannels(domainId, userId);
	}
	@Override
	public boolean verifyFirebaseIdToken(String token) {
		return FirebaseChannel.getInstance().verifyToken(token);
	}
	@Override
	public List<Users> getDomainOnlineUsers(String domainId) throws Exception {
		List<Users> results = new ArrayList<Users>();
		EntityManager mgr = getEntityManager();
		try {
			Map<String, Object> channels = FirebaseChannel.getInstance().getDomainOnlineUserChannels(domainId);
			for (Map.Entry<String, Object> entry : channels.entrySet()) {
				Users user = doFind(Users.class, entry.getKey());
				if (isValid(user)) {
					results.add(user);
				}
			}
			return results;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeDomainChannel(String domainId) throws Exception {
		if (StringUtils.isBlank(domainId)) { return; }
		FirebaseChannel.getInstance().deleteDomainChannel(domainId);
	}
	
	@Override
	public void removeOnlineUserChannel(String domainId, String userId) throws Exception {
		if (StringUtils.isBlank(domainId)) { return; }
		if (StringUtils.isNotBlank(userId)) {
			FirebaseChannel.getInstance().deleteOnlineUserChannel(domainId, userId);
		} else {
			FirebaseChannel.getInstance().deleteOnlineUserChannel(domainId);
		}
	}
	@Override
	public void removeAllUnavailableDomainChannels() throws Exception {
		FirebaseChannel.getInstance().removeAllUnavailableDomainChannels();
	}
	
	@Override
	public void removeAllUnavailableOnlineUserChannels() throws Exception {
		FirebaseChannel.getInstance().removeAllUnavailableOnlineUserChannels();
	}
	
//  @Deprecated	
//	@Override
//	public void reconnectFirebaseChannel(ChannelToken channelToken) throws Exception {
//		try {
//			FirebaseChannel.getInstance().firebaseOnlinePatch(channelToken);
//		} catch (Exception ex) { System.out.println("============================"+ex.getMessage()); }
//		
//	}
}
