package net.forecs.coconut.endpoint.channel;

import javax.inject.Singleton;
import javax.servlet.http.HttpServlet;

@Deprecated
@Singleton
public class ChannelDisconnectedServlet extends HttpServlet {
	private static final long serialVersionUID = -4720291300988210646L;
//	private static final Logger LOG = Logger.getLogger(ChannelDisconnectedServlet.class.getName());
//
//	private final ISyncService syncService;
//
//	@Inject
//	public ChannelDisconnectedServlet(ISyncService syncService) {
//		this.syncService = syncService;
//	}
//
//	public void doPost(HttpServletRequest req, HttpServletResponse resp)
//			throws IOException, ServletException {
//		process(req, resp);
//	}
//
//	private void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		try {
//			ChannelService channelService = ChannelServiceFactory.getChannelService();
//			ChannelPresence presence = channelService.parsePresence(req);
//			String clientId = presence.clientId();
//			
//			syncService.onClientDisconnected(clientId);
//		} catch (Exception ex) {
//			LOG.warning("[Disconnection error]" + ex.getMessage());
//			throw new IOException(ex.getMessage());
//		}
//	}
}
