package net.forecs.coconut.endpoint.channel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;
import javax.ws.rs.core.MultivaluedMap;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.rest.JerseyWebHookClient;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.channel.WebHook;
import net.forecs.coconut.entity.channel.WebHookLog;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.RetryOptions;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;
import com.sun.jersey.core.util.MultivaluedMapImpl;

@Singleton
public class WebHookService extends CommonService implements IWebHookService {
	private static final Logger LOG = Logger.getLogger(WebHookService.class.getName());
	private static final String ACTIVITY = "activity";
	private static final String ENTITIES = "entities";
	
	@Inject
	public WebHookService() {
	}
	
	@Override
	public List<WebHook> listWebHook(
			EntityManager mgr,
			ActivityKind activityKind,
			ActivityType activityType) throws Exception {
		try {
			DsQuery<WebHook> dsQuery = new DsQuery<>(WebHook.class)
					.eq(FLD.disable, false)
					.eq(FLD.activityKind, activityKind)
					.eq(FLD.activityType, activityType);

			return dsQuery.execute(mgr);
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public WebHook getWebHook(String webHookId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, WebHook.class, webHookId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public WebHook insertWebHook(WebHook webHook) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			if (webHook.getActivityKind() == null || webHook.getActivityType() == null) { throw new UnavailableException("invalid activity kind or type"); }
			if (StringUtils.isBlank(webHook.getUrl())) { throw new UnavailableException("Can not found webhook url"); }
			if (!isValidJSON(webHook.getHeaderMap())) { throw new UnavailableException("Invalid headers"); }
			if (!isValidJSON(webHook.getParamMap())) { throw new UnavailableException("Invalid parameters"); }
			
			Users loginUser = getCurrentUser();
			
			webHook.setKey(KeyUtil.createWebHookKey(webHook));
			if (contains(mgr, WebHook.class, webHook.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(webHook.getWebHookId()));
			}
			
			webHook.setCreator(loginUser.getUserId());
			webHook.setOwner(loginUser.getUserId());
			
			doPersistTransaction(mgr, webHook);
			return webHook;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeWebHook(String webHookId) throws NotFoundException {
		EntityManager mgr = getEntityManager();
		
		try {
			WebHook webHook = doFind(mgr, WebHook.class, webHookId);
			if (webHook == null) {
				throw new NotFoundException("Object does not exist.");
			}
			
			doRemoveTransaction(mgr, webHook);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public WebHook updateWebHook(WebHook webHook) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return doMergeTransaction(mgr, webHook);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	

	@Override
	public void hook(Activities activity) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			WebHook hook = doFind(mgr, WebHook.class, KeyUtil.createWebHookKey(activity.getActivityKind(), activity.getActivityType(), activity.getKindId()));
			
			if (hook != null) {
				if(!hook.isDisable()) {
					//executeHook(hook, activity);
					prepareHook(hook, activity);
				}
				if (hook.isLocal()) { return; }
			}
			 
			hook = doFind(mgr, WebHook.class, KeyUtil.createWebHookKey(activity.getActivityKind(), activity.getActivityType()));
			if (hook != null && !hook.isDisable()) {
				//executeHook(hook, activity);
				prepareHook(hook, activity); 
			}
		} catch (Exception ex) {
			LOG.warning(String.format("[hook-%s] %s-%s : %s",
					NamespaceManager.get(), activity.getActivityKind(),
					activity.getActivityType(), ex.getMessage()));
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void prepareHook(WebHook hook, Activities activity) throws Exception {
		Queue queue = QueueFactory.getQueue(CommonProperty.WEB_HOOK_QUEUE_NAME);
		
		int retryCount = hook.getRetryCount();
		long retryTerm = hook.getRetryTerm();
		
		TaskOptions taskOption = TaskOptions.Builder.withUrl(CommonProperty.WEB_HOOK_URL);
		taskOption = taskOption
				.param(PARAM.WEBHOOKID, hook.getWebHookId())
				.param(PARAM.ACTIVITYID, activity.getActivityId());
//				.param("retryCount", String.valueOf(retryCount))
//				.param("retryTerm", String.valueOf(retryTerm));
		
		
		RetryOptions retry = RetryOptions.Builder.withTaskRetryLimit(retryCount)
				//.taskAgeLimitSeconds(100)
			    .minBackoffSeconds(retryTerm).maxBackoffSeconds(retryTerm).maxDoublings(0);
			
		taskOption = taskOption.retryOptions(retry);
		taskOption = taskOption.method(Method.POST);
		
		queue.add(taskOption);
	}
	
	@Override
	public void executeHook(String webHookId, String activityId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		Key key = KeyFactory.stringToKey(webHookId);
		NamespaceManager.set(key.getNamespace());
		EntityManager mgr = getEntityManager();
		
		try {
			WebHook hook = doFind(mgr, WebHook.class, webHookId);
			Activities activity = doFind(mgr, Activities.class, activityId);
			executeHook(hook, activity);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	private void executeHook(WebHook hook, Activities activity) throws Exception {
		try {
			Map<String, Object> resultMap = new HashMap<String, Object>();
			
			ObjectMapper om = new ObjectMapper();
			
			if (!hook.isIncludeNull()) { om.setSerializationInclusion(JsonInclude.Include.NON_NULL); }
			if (!hook.isIncludeEmpty()) { om.setSerializationInclusion(JsonInclude.Include.NON_EMPTY); }
			
			Map<String, String> headerMap = jsonToMap(om, hook.getHeaderMap());
			MultivaluedMap<String, String> paramMap = jsonToMultiValuedMap(om, hook.getParamMap());
			
			Object entity = getEntity(activity.getActivityKind(), activity.getKindId());
			List<Map<String, Object>> entities = new ArrayList<Map<String, Object>>();
			if (entity != null) {
				Map<String, Object> entityAsMap = convertObjectAsMap(om, hook, entity);
				if (entityAsMap != null) { entities.add(entityAsMap); }
			}
			resultMap.put(ENTITIES, entities);
			Map<String, Object> activityAsMap = convertObjectAsMap(om, hook, activity);
			if (activityAsMap != null) { resultMap.put(ACTIVITY, activityAsMap); }
			
			String resultAsJson = om.writeValueAsString(resultMap);

			int returnCode = JerseyWebHookClient.hook(hook.getUrl(), headerMap, paramMap, resultAsJson, hook.getMethod());
			
			if (hook.isSaveLog()) {	insertOrUpdateWebHook(hook, activity, returnCode); }
				
			if (returnCode < 200 || returnCode > 299) {
				throw new RuntimeException("Failed : HTTP error code : " + returnCode);
			}
		} catch (Exception ex) {
			LOG.warning(String.format("[executeHook-%s] %s-%s : %s",
					NamespaceManager.get(), activity.getActivityKind(),
					activity.getActivityType(), ex.getMessage()));
			
			throw ex;
		}
	}
	
	
	
	private Map<String, String> jsonToMap(ObjectMapper om, String json) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		if (StringUtils.isNotBlank(json)) {
			map = om.readValue(json, new TypeReference<HashMap<String, String>>() {});
			// for test
//			for(Map.Entry<String, String> entry : headerMap.entrySet()) {
//				if (entry.getKey() != null && entry.getValue() != null) {
//					LOG.warning("jsonToMap (" + entry.getKey() + ":" + entry.getValue() +")");
//				}
//			}
		}
		return map;
	}
	private MultivaluedMap<String, String> jsonToMultiValuedMap(ObjectMapper om, String json) throws Exception {
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		MultivaluedMap<String, String> mvMap = new MultivaluedMapImpl();
		
		if (StringUtils.isNotBlank(json)) {
			map = om.readValue(json, new TypeReference<HashMap<String, List<String>>>() {});
		}
		
		for(Map.Entry<String, List<String>> entry : map.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				mvMap.put(entry.getKey(), entry.getValue());
				// for test
				//LOG.warning("jsonToMultiValuedMap (" + entry.getKey() + ":" + entry.getValue() +")");
			}
	    }
		return mvMap;
	}
	
	private Map<String, Object> convertObjectAsMap(ObjectMapper om, WebHook hook, Object obj) throws Exception {
		@SuppressWarnings("unchecked")
		Map<String, Object> objectAsMap = om.convertValue(obj, Map.class);
		Map<String, String> convertMap = jsonToMap(om, hook.getConvertMap());
		
		for (String attrKey : hook.getExcepts()) {
			if (objectAsMap.containsKey(attrKey)) {
				objectAsMap.remove(attrKey);
			}
		}
		for (Map.Entry<String, String> entry : convertMap.entrySet()) {
			if (objectAsMap.containsKey(entry.getKey())) {
				Object value = objectAsMap.remove(entry.getKey());
				if (value != null) { objectAsMap.put(entry.getValue(), value); }
			}
		}
		
		// for test
//		for(Map.Entry<String, Object> entry : objectAsMap.entrySet()) {
//			LOG.warning("Converted " + obj.getClass().getSimpleName()+ " Map : " + entry.getKey() + ":" + entry.getValue());
//		}
		
		return objectAsMap;
	}
	
	private Object getEntity(ActivityKind activityKind, String objectId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getEntity(mgr, activityKind, objectId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Object getEntity(EntityManager mgr, ActivityKind activityKind, String objectId) throws Exception {
		switch (activityKind) {
			case TASKS : return doFind(mgr, Tasks.class, objectId);
			case BOARDS : return doFind(mgr, Boards.class, objectId);
			case EVENTS : return doFind(mgr, Events.class, objectId);
			case TASK_TIMELINES : return doFind(mgr, TaskTimelines.class, objectId);
			case TASK_TIMELINE_COMMENTS : return doFind(mgr, TaskTimelineComments.class, objectId);
			case TASK_CHECKLISTS : return doFind(mgr, TaskChecklists.class, objectId);
			case USERS : return doFind(mgr, Users.class, objectId);
			case NOTICE : return doFind(mgr, Notice.class, objectId);
			case GROUPS : return doFind(mgr, Groups.class, objectId);
			default : return null;
		}
	}
	
	private WebHookLog insertOrUpdateWebHook(WebHook hook, Activities activity, int status) {
		EntityManager mgr = getEntityManager();
		try {
			Key logKey = KeyUtil.createWebHookLogKey(hook, activity);
			WebHookLog hookLog = doFind(mgr, WebHookLog.class, logKey);
			
			if (hookLog != null) {
				hookLog.setRetryCount(hookLog.getRetryCount()+1);
				hookLog.setStatus(status);
				
				doMergeTransaction(mgr, hookLog);
			} else {
				hookLog = new WebHookLog();
				hookLog.setWebHookId(hook.getWebHookId());
				hookLog.setActivityId(activity.getActivityId());
				hookLog.setKey(logKey);
				hookLog.setStatus(status);
				hookLog.setKindId(activity.getKindId());
				hookLog.setActivityKind(activity.getActivityKind());
				hookLog.setActivityType(activity.getActivityType());
				
				doPersistTransaction(mgr, hookLog);
			}
			
			return hookLog;	
		} catch (Exception ex) {
			LOG.warning("[InsertOrUpdateWebHook] " + ex.getMessage());
			return null;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private static boolean isValidJSON(final String json) throws IOException {
	    boolean valid = true;
	    try{
	    	if (StringUtils.isBlank(json)) { return true; }
	    	ObjectMapper om = new ObjectMapper();
	    	om.readTree(json);
	    } catch(JsonProcessingException e){
	        valid = false;
	    }
	    return valid;
	}
}