package net.forecs.coconut.endpoint.channel;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.channel.WebHook;

import com.google.api.server.spi.response.NotFoundException;

public interface IWebHookService extends ICommonService {

	public abstract List<WebHook> listWebHook(
			EntityManager mgr,
			ActivityKind activityKind,
			ActivityType activityType) throws Exception;
	public abstract WebHook getWebHook(String webHookId) throws Exception;
	public abstract WebHook insertWebHook(WebHook webHook) throws Exception;
	public abstract void removeWebHook(String webHookId) throws NotFoundException;
	public abstract WebHook updateWebHook(WebHook webHook) throws Exception;
	public abstract void hook(Activities activity) throws Exception;
	
	public abstract void executeHook(String webHookId, String activityId) throws Exception;
}
