package net.forecs.coconut.endpoint.channel;

import javax.inject.Inject;

import net.forecs.coconut.endpoint.API;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiNamespace;

@Api(name = API.CHANNEL_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.CHANNEL_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class WebHookServiceAPI {
	@SuppressWarnings("unused")
	private final IWebHookService webHookService;

	@Inject
	public WebHookServiceAPI(IWebHookService webHookService) {
		this.webHookService = webHookService;
	}

//	@ApiMethod(name = "getWebHook", path = "channel/webHook/{webHookId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public WebHook getWebHook(@Named(FLD.webHookId) String webHookId) throws Exception {
//		return webHookService.getWebHook(webHookId);
//	}
//
//	@ApiMethod(name = "insertWebHook", path = "channel/webHook", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public void insertWebHook(WebHook webHook) throws Exception {
//		webHookService.insertWebHook(webHook);
//	}
//	
//	@ApiMethod(name = "removeWebHook", path = "channel/webHook/{webHookId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeWebHook(@Named(FLD.webHookId) String webHookId) throws Exception {
//		webHookService.removeWebHook(webHookId);
//	}
//	
//	@ApiMethod(name = "updateWebHook", path = "channel/webHook", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public WebHook updateWebHook(WebHook webHook) throws Exception {
//		return webHookService.updateWebHook(webHook);
//	}
}
