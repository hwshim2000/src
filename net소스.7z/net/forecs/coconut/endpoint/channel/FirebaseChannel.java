package net.forecs.coconut.endpoint.channel;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.HtmlUtil;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.extensions.appengine.http.UrlFetchTransport;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.ByteArrayContent;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.common.io.CharStreams;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.tasks.Task;

/**
 * @Description: 중요!!!!!!!!!!!!!!!!!!!!!!!
 * Firebase에서는 Key의 값으로 다음의 character .$#[]/ 를 허용하지 않는다.
 * 따라서, Key(결국 path)의 값에 위에서 허용하지 안흔 캐릭터가 들거간 경우 제거하거나, 변환을 하여야한다.
 * 방법 1 : urlEncodeComponent를 사용하고, .을 최종적으로 변환하는 방법을 쓰는것이다.
 * 방법 2 : Google datastore key string은 위의 키들을 포함하지 않으므로 이 키값을 그대로 활용하는 방법 
 */
public class FirebaseChannel {
	private static final Logger LOG = Logger.getLogger(FirebaseChannel.class.getName());
	
	static final int AVAIL_CHECK_DAYS = -3;
	static final String FIREBASE_SECRETS_PATH = "/firebase_secrets.json";
	static final String FIREBASE_SNIPPET_PATH = "firebase/firebase_config.jspf";
	static final String FIREBASE_DEFAULT_DB_URL = "https://cocoworks-for-ecs.firebaseio.com/";
	static InputStream firebaseConfigStream = null;
	static final Collection<String> FIREBASE_SCOPES = Arrays.asList(
			"https://www.googleapis.com/auth/firebase.database"
			,"https://www.googleapis.com/auth/userinfo.email"
			);
	
	
//	private static final String IDENTITY_ENDPOINT = "https://identitytoolkit.googleapis.com/google.identity.identitytoolkit.v1.IdentityToolkit";

	private String firebaseDbUrl;
	private GoogleCredential credential;
	HttpTransport httpTransport;

	ObjectMapper om;
	 
	private static FirebaseChannel instance;
	// ==== Don't delete. ==============================
//	private String accessToken;
//	private boolean isDevelopmentServer = false;
	// =================================================
	
	static final Set<String> monitorTargets = new HashSet<String>();
	static {
		monitorTargets.add("agtjb2NvbnV0LWRldnIVCxIHRG9tYWlucyIITXlEb21haW4MogEITXlEb21haW4");		// localhost : MyDomain
		//monitorTargets.add("ahNzfmNvY293b3Jrcy1mb3ItZWNzchMLEgdEb21haW5zIgZmb3JlY3MMogEGZm9yZWNz");	// appengine : forecs
		//monitorTargets.add("ahNzfmNvY293b3Jrcy1mb3ItZWNzchALEgdEb21haW5zIgNkZXYMogEDZGV2");			// appengine : dev
	}
	
	/**
	 * FirebaseChannel is a singleton, since it's just utility functions.
	 * The class derives auth information when first instantiated.
	 */
	public static FirebaseChannel getInstance() {
		if (instance == null) {
			instance = new FirebaseChannel();
			LOG.warning("[Firebase Channel] : created new instance.");
		}
		return instance;
	}

	private FirebaseChannel() {
		try {
			firebaseDbUrl = getFirebaseDatabaseURL();
			
			FirebaseOptions options = new FirebaseOptions.Builder()
					.setServiceAccount(FirebaseChannel.class.getResourceAsStream(FIREBASE_SECRETS_PATH))
					.setDatabaseUrl(firebaseDbUrl)
					.build();
			FirebaseApp.initializeApp(options);
			
			om = new ObjectMapper();
			om.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
			
			
//			if (null == firebaseConfigStream) {
//				firebaseConfigStream = new FileInputStream(FIREBASE_SNIPPET_PATH);
//			}
//			String firebaseSnippet = CharStreams.toString(new InputStreamReader(firebaseConfigStream, StandardCharsets.UTF_8));
//			firebaseDbUrl = parseFirebaseUrl(firebaseSnippet);
			
			if (MainModule.developmentServer) {
				// 실제 cloud 환경에서도 적용가능, 하지만 개발 환경에서는 아래의 credential을 이용해야만 permission denied 예외가 발생하지 않는다.
				credential = GoogleCredential
						.fromStream(FirebaseChannel.class.getResourceAsStream(FIREBASE_SECRETS_PATH))
						.createScoped(FIREBASE_SCOPES);

				// =========================================================================
				// ***** 중요, 개발 서버에서는 아래와 같은 방법으로 하면 permission denied 예외가 발생한다.
				// https://groups.google.com/forum/#!topic/firebase-talk/s0wtW8wCwl8 참조
				//
				//				credential.refreshToken();
				//				accessToken = credential.getAccessToken();
				// =========================================================================
			//	onlineUserStatus();
				
				for(String target : monitorTargets) {
					//onlineUserStatus();
					onlineDomainStatus(target);
				}
			} else {
				credential = GoogleCredential.getApplicationDefault().createScoped(FIREBASE_SCOPES); // 개발서버에서는 작동하지 않는다.
			}
			httpTransport = UrlFetchTransport.getDefaultInstance();
		} catch (IllegalStateException e) {
			if (e.getMessage().contains("already exists")) {
				LOG.warning("[FirebaesApp init] " + e.getMessage());
			} else {
				throw new RuntimeException(e);
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	private static String getFirebaseDatabaseURL() {
		try {
			if (null == firebaseConfigStream) {
				firebaseConfigStream = new FileInputStream(FIREBASE_SNIPPET_PATH);
			}
	
			String firebaseSnippet = CharStreams.toString(new InputStreamReader(firebaseConfigStream, StandardCharsets.UTF_8));
			String dbUrl = parseFirebaseUrl(firebaseSnippet);
			if (StringUtils.isBlank(dbUrl)) { dbUrl = FIREBASE_DEFAULT_DB_URL; }
			return dbUrl;
		} catch (Exception ex) {
			return FIREBASE_DEFAULT_DB_URL;
		}
	}
	 
	private static String parseFirebaseUrl(String firebaseSnippet) {
		int idx = firebaseSnippet.indexOf("databaseURL");
		if (-1 == idx) {
			throw new RuntimeException("Please copy your Firebase web snippet into " + FIREBASE_SNIPPET_PATH);
		}
		idx = firebaseSnippet.indexOf(':', idx);
		int openQuote = firebaseSnippet.indexOf('"', idx);
		int closeQuote = firebaseSnippet.indexOf('"', openQuote + 1);
		return firebaseSnippet.substring(openQuote + 1, closeQuote);
	}

	public void sendFirebaseMessage(String channelKey, String syncMessage) throws IOException {
		HttpResponse response = null;
		try {
			if (StringUtils.isBlank(syncMessage)) {
				response = deleteDomainChannel(channelKey);
			} else {
				response = patchDomainChannel(channelKey, syncMessage);
			}

			if (response.getStatusCode() != 200) {
				throw new RuntimeException("Error code while updating Firebase: " + response.getStatusCode());
			}
		} finally {
			if (null != response) {
				response.disconnect();
			}
		}
	}
	
	public boolean verifyToken(String token) {
		Task<FirebaseToken> firebaseToken = FirebaseAuth.getInstance().verifyIdToken(token);
		if (firebaseToken.isComplete()) {
			LOG.warning("[Firebase Token Verification] " + firebaseToken.isSuccessful());
			LOG.warning("[Firebase Token Verification] " + firebaseToken.getResult().getUid());
		}
		return firebaseToken.isSuccessful();
	}
//	@SuppressWarnings("unused")
//	@Deprecated
//	private void verifyToken(String token) {
//		System.out.println("[Request verfiy Token] : " + token);
//		FirebaseAuth.getInstance().verifyIdToken(token).addOnSuccessListener(new OnSuccessListener<FirebaseToken>() {
//			String uid;
//			@Override
//			public void onSuccess(FirebaseToken decodedToken) {
//				uid = decodedToken.getUid();
//				System.out.println("VVVerify TOKEN : " + uid);
//				// ...
//			}
//		});
//	}
	public String createFirebaseToken(String uid) {
		HashMap<String, Object> additionalClaims = new HashMap<String, Object>();
		additionalClaims.put("premiumAccount", true);
		return FirebaseAuth.getInstance().createCustomToken(uid, additionalClaims);
	}
	
	private HttpResponse firebasePut(String path, String message) throws IOException {
		HttpRequestFactory requestFactory = httpTransport.createRequestFactory(credential);
		GenericUrl url = new GenericUrl(path);
		return requestFactory.buildPutRequest(url, new ByteArrayContent("application/json", message.getBytes(StandardCharsets.UTF_8))).execute();
	}
	private HttpResponse firebasePatch(String path, String message) throws IOException {
		HttpRequestFactory requestFactory = httpTransport.createRequestFactory(credential);
		GenericUrl url = new GenericUrl(path);
		return requestFactory.buildPatchRequest(url, new ByteArrayContent("application/json", message.getBytes(StandardCharsets.UTF_8))).execute();
	}
	private HttpResponse firebasePost(String path, String message) throws IOException {
		HttpRequestFactory requestFactory = httpTransport.createRequestFactory(credential);
		GenericUrl url = new GenericUrl(path);
		return requestFactory.buildPostRequest(url, new ByteArrayContent("application/json", message.getBytes(StandardCharsets.UTF_8))).execute();
	}
	private HttpResponse firebaseGet(String path) throws IOException {
		HttpRequestFactory requestFactory = httpTransport.createRequestFactory(credential);
		GenericUrl url = new GenericUrl(path);
		return requestFactory.buildGetRequest(url).execute();
	}
	private HttpResponse firebaseDelete(String path) throws IOException {
		HttpRequestFactory requestFactory = httpTransport.createRequestFactory(credential);
		GenericUrl url = new GenericUrl(path);
		return requestFactory.buildDeleteRequest(url).execute();
	}
	
	
	
	@SuppressWarnings("unused")
	private HttpResponse putDomainChannel(String channelKey, Object object) throws IOException {
		String syncMessage = new ObjectMapper().writeValueAsString(object);
		return putDomainChannel(channelKey, syncMessage);
	}
	private HttpResponse putDomainChannel(String channelKey, String syncMessage) throws IOException {
		String path = String.format("%s/channels/%s.json", firebaseDbUrl, channelKey);
		return firebasePut(path, syncMessage);
	}

	@SuppressWarnings("unused")
	private HttpResponse patchDomainChannel(String channelKey, Object object) throws IOException {
		String syncMessage = new ObjectMapper().writeValueAsString(object);
		return patchDomainChannel(channelKey, syncMessage);
	}
	private HttpResponse patchDomainChannel(String channelKey, String syncMessage) throws IOException {
		String path = String.format("%s/channels/%s.json", firebaseDbUrl, channelKey);
		return firebasePatch(path, syncMessage);
	}
	@SuppressWarnings("unused")
	private HttpResponse postDomainChannel(String channelKey, Object object) throws IOException {
		String syncMessage = new ObjectMapper().writeValueAsString(object);
		return postDomainChannel(channelKey, syncMessage);
	}
	private HttpResponse postDomainChannel(String channelKey, String syncMessage) throws IOException {
		String path = String.format("%s/channels/%s.json", firebaseDbUrl, channelKey);
		return firebasePost(path, syncMessage);
	}
	@SuppressWarnings("unused")
	private HttpResponse getDomainChannel(String channelKey) throws IOException {
		String path = String.format("%s/channels/%s.json", firebaseDbUrl, channelKey);
		return firebaseGet(path);
	}
	public HttpResponse deleteDomainChannel(String channelKey) throws IOException {
		String path = String.format("%s/channels/%s.json", firebaseDbUrl, channelKey);
		return firebaseDelete(path);
	}

	
	private Map<String, Object> getAllDomainChannels() throws IOException {
		String path = String.format("%s/channels.json", firebaseDbUrl);
		return getChannelData(path);
	}
	private Map<String, Object> getAllOnlineUserChannels() throws IOException {
		String path = String.format("%s/onlineUsers.json", firebaseDbUrl);
		return getChannelData(path);
	}
	public Map<String, Object> getDomainOnlineUserChannels(String domainId) throws IOException {
		String path = String.format("%s/onlineUsers/%s.json", firebaseDbUrl, domainId);
		return getChannelData(path);
	}
	public Map<String, Object> getOnlineUserChannels(String domainId, String userId) throws IOException {
		String path = String.format("%s/onlineUsers/%s/%s.json", firebaseDbUrl, domainId, userId);
		return getChannelData(path);
	}
	public HttpResponse deleteOnlineUserChannel(String domainId) throws IOException {
		String path = String.format("%s/onlineUsers/%s.json", firebaseDbUrl, domainId);
		return firebaseDelete(path);
	}
	public HttpResponse deleteOnlineUserChannel(String domainId, String userId) throws IOException {
		String path = String.format("%s/onlineUsers/%s/%s.json", firebaseDbUrl, domainId, userId);
		return firebaseDelete(path);
	}
	public HttpResponse deleteOnlineUserChannel(String domainId, String userId, String channelKey) throws IOException {
		String path = String.format("%s/onlineUsers/%s/%s/%s.json", firebaseDbUrl, domainId, userId, channelKey);
		return firebaseDelete(path);
	}
	
	
	private Map<String, Object> getChannelData(String path) throws IOException {
		HttpResponse response = firebaseGet(path);
		String contents = response.parseAsString();
		ObjectMapper om = new ObjectMapper();
		Map<String, Object> resultMap = om.readValue(contents, new TypeReference<HashMap<String, Object>>() {});
		
		return resultMap;
	}
	
	@SuppressWarnings("unused")
	private HttpResponse firebaseOnlinePatch(ChannelToken token) throws IOException {
		String json = new ObjectMapper().writeValueAsString(token);
		String path = String.format("%s/onlineUsers/%s/%s/%s.json", firebaseDbUrl, token.getDomainId(), token.getUserId(), token.getChannelKey());
		return firebasePatch(path, json);
	}

	@SuppressWarnings("unchecked")
	public void removeAllUnavailableOnlineUserChannels() throws IOException {
		Map<String, Object> domains = getAllOnlineUserChannels();
		Date availDate = CalendarUtil.addDay(new Date(), AVAIL_CHECK_DAYS);
		
		for (String domainId : domains.keySet()) {
			Map<String, Object> users = (Map<String, Object>)domains.get(domainId);
			for (String userId : users.keySet()) {
				Map<String, Object> channels = (Map<String, Object>)users.get(userId);
				for(String channelKey : channels.keySet()) {
					Map<String, Object> channel = (Map<String, Object>)channels.get(channelKey);
					ChannelToken token = new ChannelToken(channelKey, channel);
					Date created = new Date(Long.valueOf(channelKey));
					if (created.compareTo(availDate) < 0) {
						deleteOnlineUserChannel(domainId, userId, channelKey);
						LOG.warning(String.format("[expired online channel] %s/%s/%s/%s ",
								token.getDomainName(),
								token.getId(),
								channelKey,
								CalendarUtil.toString(token.getConnectedDate())));
					}
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public void removeAllUnavailableDomainChannels() throws IOException {
		Map<String, Object> domains = getAllDomainChannels();
		Date availDate = CalendarUtil.addDay(new Date(), AVAIL_CHECK_DAYS);
		
		for (String domainId : domains.keySet()) {
			Map<String, Object> channel = (Map<String, Object>)domains.get(domainId);
			long timestamp = (long)channel.get(FLD.timestamp);
			String domainName = (String)channel.get(FLD.domain);
			Date lastActivityDate = new Date(timestamp);
			if (lastActivityDate.compareTo(availDate) < 0) {
				deleteDomainChannel(domainId);
				LOG.warning(String.format("[expired channel] %s/%s",domainName, CalendarUtil.toString(lastActivityDate)));
			}
		}
	}
	
	@SuppressWarnings("unused")
	private void onlineUserStatus() {
		DatabaseReference onlineRef = FirebaseDatabase.getInstance().getReference("onlineUsers/");
		onlineRef.addValueEventListener(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot domains) {
				StringBuilder sb = new StringBuilder();
				sb.append("\n====================================================================");
				sb.append("\n=====\t Total Domain Count : " + domains.getChildrenCount());
				sb.append("\n====================================================================");
				for (DataSnapshot domain : domains.getChildren()) {
					sb.append("\n--------------------------------------------------------------------");
					if(!monitorTargets.contains(domain.getKey())) { continue; }
					sb.append("\n[Domain] : " + KeyFactory.stringToKey(domain.getKey()).getName());
					sb.append("(userCount=" + domain.getChildrenCount() + ")");
					for (DataSnapshot users : domain.getChildren()) {
						sb.append("\n  >> User : " + KeyFactory.stringToKey(users.getKey()).getName());
						sb.append("(channelCount=" + users.getChildrenCount() + ")");
						for (DataSnapshot channel : users.getChildren()) {
							sb.append("\n    * Channel(key/value)=" + channel.getKey() + " / " + channel.getValue());
						}
					}
					sb.append("\n--------------------------------------------------------------------\n");
				}
				
				LOG.info(sb.toString());
			}

			@Override
			public void onCancelled(DatabaseError firebaseError) {
				LOG.warning("DBCount : The read failed: " + firebaseError.getMessage());
			}
		});
	}
	
	private void onlineDomainStatus(String domainId) {
		DatabaseReference onlineRef = FirebaseDatabase.getInstance().getReference("onlineUsers/"+domainId);
		onlineRef.addValueEventListener(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot domain) {
				StringBuilder sb = new StringBuilder();
				sb.append("\n--------------------------------------------------------------------");
				sb.append("\n[Domain] : " + KeyFactory.stringToKey(domain.getKey()).getName());
				sb.append("(userCount=" + domain.getChildrenCount() + ")");
				for (DataSnapshot user : domain.getChildren()) {
					sb.append("\n  >> User : " + KeyFactory.stringToKey(user.getKey()).getName());
					sb.append("(channelCount=" + user.getChildrenCount() + ")");
					for (DataSnapshot channel : user.getChildren()) {
						sb.append("\n    * Channel(key/value) = " + channel.getKey() + " / " + channel.getValue());
					}
				}
				sb.append("\n--------------------------------------------------------------------\n");
				
				LOG.info(sb.toString());
			}

			@Override
			public void onCancelled(DatabaseError firebaseError) {
				LOG.warning("DBCount : The read failed: " + firebaseError.getMessage());
			}
		});
	}
	
	@Deprecated
	@SuppressWarnings("unused")
	private static String firebaseKey(String s) {
		return HtmlUtil.encodeURIComponent(s).replaceAll("\\.", "%2E");
	}

//	public void sendFirebaseMessage(String channelKey, String syncMessage) throws IOException {
////		HttpRequestFactory requestFactory = httpTransport.createRequestFactory(credential);
////		GenericUrl url = new GenericUrl(String.format("%s/channels/%s.json", firebaseDbUrl, channelKey));
//		
//		// =================================================================================================================
//		// ==== Don't delete. ==============================================================================================
//		// 개발 환경에서의 방법 테스트용도(나중에 활용할 수도 있음)
//		//
//		HttpRequestFactory requestFactory = null;
//		GenericUrl url = null;
//		if (isDevelopmentServer) {
//			requestFactory = httpTransport.createRequestFactory(credential);
//			url = new GenericUrl(String.format("%s/channels/%s.json?access_token="+accessToken, firebaseDbUrl, channelKey));
//		} else {
//			requestFactory = httpTransport.createRequestFactory(credential);
//			url = new GenericUrl(String.format("%s/channels/%s.json", firebaseDbUrl, channelKey));
//		}
//		// =================================================================================================================
//		HttpResponse response = null;
//
//		try {
//			if (StringUtils.isBlank(syncMessage)) {
//				response = requestFactory.buildDeleteRequest(url).execute();
//			} else {
//				response = requestFactory.buildPatchRequest(url,
//						new ByteArrayContent("application/json", syncMessage.getBytes(StandardCharsets.UTF_8))
//				).execute();
//			}
//
//			if (response.getStatusCode() != 200) {
//				throw new RuntimeException("Error code while updating Firebase: " + response.getStatusCode());
//			}
//		} finally {
//			if (null != response) {
//				response.disconnect();
//			}
//		}
//	}
	
	/*
 	public String createFirebaseToken(String userId) {
		final AppIdentityService appIdentity = AppIdentityServiceFactory
				.getAppIdentityService();
		final BaseEncoding base64 = BaseEncoding.base64();

		String header = base64.encode("{\"typ\":\"JWT\",\"alg\":\"RS256\"}"
				.getBytes());

		// Construct the claim String channelKey = "MyDomain"; // String
		clientEmail = appIdentity.getServiceAccountName();
		String clientEmail = "firebase@cocoworks-for-ecs.iam.gserviceaccount.com";

		long epochTime = System.currentTimeMillis() / 1000;
		long expire = epochTime + 60 * 60; // an hour from now

		Map<String, Object> claims = new HashMap<String, Object>();
		claims.put("iss", clientEmail);
		claims.put("sub", clientEmail);
		claims.put("aud", IDENTITY_ENDPOINT);
		claims.put("uid", channelKey);
		claims.put("iat", epochTime);
		claims.put("exp", expire);

		String payload = base64.encode(new Gson().toJson(claims).getBytes());
		String toSign = String.format("%s.%s", header, payload);
		AppIdentityService.SigningResult result = appIdentity.signForApp(toSign
				.getBytes());
		return String.format("%s.%s", toSign,
				base64.encode(result.getSignature()));
	}
	*/
	
	/** 또다른 인증 방법(id, password 사용)**/
/*
Java
FirebaseAuth auth = FirebaseAuth.getInstance();
auth.signInWithEmailAndPassword(email, password)
    .addOnCompleteListener(new OnCompleteListener() {
        @Override
        public void onComplete(Task task) {
            if (task.isSuccessful()) {
                FirebaseUser user = task.getResult().getUser();
                String email = user.getEmail();
                // ...
            }
        }
    });


JavaScript
firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        // User is signed in
        var email = user.email;
        // ...
    } else {
        // User is not signed in
        // ...
    }
});
firebase.auth().signInWithEmailAndPassword(email, password);
*/
}
