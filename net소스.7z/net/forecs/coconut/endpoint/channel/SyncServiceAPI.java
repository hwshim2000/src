package net.forecs.coconut.endpoint.channel;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.user.Users;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.config.Named;


@Api(name = API.CHANNEL_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.CHANNEL_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class SyncServiceAPI {
	private final ISyncService syncService;

	@Inject
	public SyncServiceAPI(ISyncService syncService) {
		this.syncService = syncService;
	}

	// ------------- Current service ----------------
//	@ApiMethod(name = "requestSyncToken", path = "channel/tokens/request", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	@Deprecated
//	public ChannelToken requestSyncToken() throws Exception {
//		return syncService.requestSyncToken();
//	}

	@ApiMethod(name = "requestFirebaseToken", path = "channel/tokens/request/firebase", httpMethod = HttpMethod.GET)
	@RequiresUser
	public ChannelToken requestFirebaseToken() throws Exception {
		return syncService.requestFirebaseToken();
	}
	
	@ApiMethod(name = "getDomainOnlineUserChannels", path = "channel/onlineUser/domains/{domainId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<String, Object> getDomainOnlineUserChannels(@Named(FLD.domainId) String domainId) throws Exception {
		return syncService.getDomainOnlineUserChannels(domainId);
	}
	
	@ApiMethod(name = "getOnlineUserChannels", path = "channel/onlineUser/domains/{domainId}/users/{userId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<String, Object> getOnlineUserChannels(@Named(FLD.domainId) String domainId, @Named(FLD.userId) String userId) throws Exception {
		return syncService.getOnlineUserChannels(domainId, userId);
	}
	
	@ApiMethod(name = "getDomainOnlineUsers", path = "channel/online/domains/{domainId}/users", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<Users> getDomainOnlineUsers(@Named(FLD.domainId) String domainId) throws Exception {
		return syncService.getDomainOnlineUsers(domainId);
	}
	
//	@Deprecated
//	@ApiMethod(name = "reconnectFirebaseChannel", path = "channel/firebase/reconnect", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public void reconnectFirebaseChannel(ChannelToken channelToken) throws Exception {
//		syncService.reconnectFirebaseChannel(channelToken);
//	}
	
//	<!-- 개발 서버에서는 작동하지 않는것인지, 아무 응답이 없어서 제외함 //-->
	@Deprecated
	@ApiMethod(name = "verifyToken", path = "channel/tokens/verify", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result verifyToken(@Named(FLD.token) String token) throws Exception {
		return new Result(FirebaseChannel.getInstance().verifyToken(token));
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "sync", path = "channel/sync", httpMethod = HttpMethod.POST)
//	public void sync(@Named(FLD.domainId) String domainId, @Named(FLD.message) String message) throws Exception {
//		syncService.syncMessage(domainId, message);
//	}
}
