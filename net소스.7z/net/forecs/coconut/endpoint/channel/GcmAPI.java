package net.forecs.coconut.endpoint.channel;

import java.io.IOException;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.endpoint.API;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;


@Api(name = API.CHANNEL_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.CHANNEL_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class GcmAPI {
	private final IGcmService gcmService;

	@Inject
    public GcmAPI(IGcmService gcmService) {
		this.gcmService = gcmService;
    }

    @ApiMethod(name = "sendMessage", path = "gcm/send/{message}", httpMethod = HttpMethod.POST)
	public void sendMessage(@Named(FLD.targetUsers) Set<String> targetUsers, @Named(FLD.message) String message) throws IOException {
        gcmService.sendMessage(targetUsers, message);
    }
}