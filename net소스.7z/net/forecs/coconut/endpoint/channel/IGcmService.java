package net.forecs.coconut.endpoint.channel;

import java.io.IOException;
import java.util.Set;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.activity.Activities;

public interface IGcmService extends ICommonService {
	public abstract void sendMessage(Set<String> targetUsers, String message) throws IOException;
	public abstract void sendMessage(Set<String> targetUsers, Activities activity) throws IOException;
}
