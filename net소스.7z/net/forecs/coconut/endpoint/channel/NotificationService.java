package net.forecs.coconut.endpoint.channel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.CountInfo;
import net.forecs.coconut.common.CountNotifications;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.NotificationType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.calendar.ICalendarService;
import net.forecs.coconut.endpoint.common.ActivityService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.setting.INotificationSettingService;
import net.forecs.coconut.endpoint.setting.NotificationSettingService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Notifications;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.freemarker.DocBuilder;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;
import com.ibm.icu.text.MessageFormat;


public class NotificationService extends CommonService implements INotificationService {
	private static final Logger LOG = Logger.getLogger(NotificationService.class.getName());

	private final static Set<String> forceNotificationActivities = new HashSet<String>();
	private final static Set<String> instantSendEmailActivities = new HashSet<String>();
	private final static Set<String> selfNotificationActivities = new HashSet<String>();
	
	static {
//		forceNotificationActivities.add(join(ActivityKind.USAGE));
		forceNotificationActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_EXPIRATION));
		forceNotificationActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_STORAGE_USAGE));
		forceNotificationActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_USERS_USAGE));
//		forceNotificationActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_BOARDS_USAGE));
		forceNotificationActivities.add(join(ActivityKind.NOTICE));
		forceNotificationActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM));
		forceNotificationActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_BIRTH));
		forceNotificationActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_WEDDING));
		
//		instantSendEmailActivities.add(join(ActivityKind.USAGE));
		instantSendEmailActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_EXPIRATION));
		instantSendEmailActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_STORAGE_USAGE));
		instantSendEmailActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_USERS_USAGE));
//		instantSendEmailActivities.add(join(ActivityKind.USAGE, ActivityType.WARNING_OF_BOARDS_USAGE));
		instantSendEmailActivities.add(join(ActivityKind.NOTICE));
		instantSendEmailActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM));
		instantSendEmailActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_BIRTH));
		instantSendEmailActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_WEDDING));
		
		selfNotificationActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM));
		selfNotificationActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_BIRTH));
		selfNotificationActivities.add(join(ActivityKind.SCHEDULE, ActivityType.ALARM_WEDDING));
	}
	
	private final static int FORCE_SEND_EMAIL_NOTIFICATION_MIN_SIZE = 25; 
	
	private final IActivityService activityService;
	private final IUserService userService;
	private final IBoardService boardService;
	private final ICalendarService calendarService;
	private final ISubscriptionService subscriptionService;
	private final INotificationSettingService notificationSettingService;
	
	private final IGcmService gcmService;
	private final DocBuilder docBuilder;

	@Inject
	public NotificationService(
			IActivityService activityService,
			IUserService userService,
			IBoardService boardService,
			ICalendarService calendarService,
			ISubscriptionService subscriptionService,
			INotificationSettingService notificationSettingService,
			IGcmService gcmService,
			DocBuilder docBuilder) {
		this.activityService = activityService;
		this.userService = userService;
		this.boardService = boardService;
		this.calendarService = calendarService;
		this.subscriptionService = subscriptionService;
		this.notificationSettingService = notificationSettingService;
		this.gcmService = gcmService;
		this.docBuilder = docBuilder;
	}
	
	private void invokeNotificationExecutor(
			List<Users> userList,
			Activities activity) throws Exception {
		if (userList == null || userList.size() == 0) { return; }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Set<String> notificationUserIds = new HashSet<String>();
			Map<String, NotificationSettings> notificationSettingMap = notificationSettingService.batchMapUserNotificationSetting(mgr, userList);
			
			for (Users user : userList) {
				try {
					if (!isValid(user)) { continue; }
					// Alarm일 경우에는 자기자신에게도 보낸다.
					// ****** Alarm은 자신을 포함한 모두에게 보내지만 생일인 경우에는 보내지 않는다.
					// 하지만, 대부분의 서비스에서는 자기 자신도 알람을 발생시키므로 생일 혹은 기타 개인적인 기념일도 알람 Noti를 발생
					if (!isSelfNotification(user, activity)) { continue; }
					
					NotificationSettings notificationSetting = notificationSettingMap
							.get(KeyUtil.createNotificationSettingKeyString(user
									.getUserId()));
					notificationUserIds.add(user.getUserId());
					
					// Notification 정보에서 email로 Notification을 받는 사용자 정보일 경우
					// Usage 관련 메일은 NotificationSetting설정 여부와 관계없이 무조건 보낸다.
					if (isSendEmailNotification(notificationSetting, activity)) {
						// notification을 즉시 받는 경우 user email로 즉시 보낸다(TaskQueue 활용)
						if (isInstantNotification(notificationSetting, activity)) {
							if (StringUtils.isNotBlank(user.getEmail())) {
								List<String> activityIdList = new ArrayList<String>();
								activityIdList.addAll(notificationSetting.getActivities());
								activityIdList.add(activity.getActivityId());
								notificationSettingService.resetNotificationActivities(mgr, notificationSetting);
								executeNotificationEmail(activity.getKey().getNamespace(), user, activityIdList);
							}
						} else {
							// !!!중요. 사용자의 NotificationSettings 정보에 noti가 발생한 ID를 계속 추가한다.
							notificationSetting = appendUserActivityId(notificationSetting, activity.getActivityId());
							
							// 누적되어 있는 Notification의 수가 30개 보다 넘으면 Noti설정과는 상관없이 강제로 보낸다.
							// FORCE_SEND_NOTIFICATION_MIN_SIZE = 30+@;
							if (notificationSetting.getActivities().size() >= FORCE_SEND_EMAIL_NOTIFICATION_MIN_SIZE) {
								List<String> activityList = new ArrayList<String>(notificationSetting.getActivities());
								notificationSettingService.resetNotificationActivities(mgr, notificationSetting);
								executeNotificationEmail(activity.getKey().getNamespace(), user, activityList);
							} else {
								notificationSettingService.updateNotificationSettings(mgr, notificationSetting);
								registNotificationExecuteTaskQueue(notificationSetting);
							}
						}
					}
				} catch (Exception ex) {
					LOG.severe(String.format("[Notification Error] domain[%s] userId[%s] id[%s] : %s", NamespaceManager.get(), user.getUserId(), user.getId(), ex.getMessage()));
					continue;
				}
			}
			try {
				if (!ActivityKind.USAGE.equals(activity.getActivityKind())) {
					gcmService.sendMessage(notificationUserIds, activity);
				}
			} catch (Exception ex) {
				LOG.severe("[GCM Error]" + ex.getMessage());
			}
			
			try {
				insertNotifications(mgr, activity, notificationUserIds);
			} catch (Exception ex) {
				LOG.severe("[Insert Notification Error] : " + ex.getMessage());
				throw ex;
			}
		} catch (Exception ex) {
			LOG.severe("[Invoke Notification Error] : " + ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private boolean isSendEmailNotification(NotificationSettings notificationSetting, Activities activity) {
		if (Y.equals(notificationSetting.getEmailPushYN())
				|| forceNotificationActivities.contains(join(activity.getActivityKind(), activity.getActivityType()))
				|| forceNotificationActivities.contains(join(activity.getActivityKind()))){
			return true;
		}
		return false;
	}
	
	private boolean isInstantNotification(NotificationSettings notificationSetting, Activities activity) {
		if (NotificationType.INSTANT.equals(notificationSetting.getNotificationType())
				|| instantSendEmailActivities.contains(join(activity.getActivityKind(), activity.getActivityType()))
				|| instantSendEmailActivities.contains(join(activity.getActivityKind()))) {
			return true;
		} 
		return false;
	}
	
	private boolean isSelfNotification(Users user, Activities activity) {
		if (!user.getUserId().equals(activity.getCreator())
				|| selfNotificationActivities.contains(join(activity.getActivityKind(), activity.getActivityType()))
				|| selfNotificationActivities.contains(join(activity.getActivityKind()))) {
			return true;
		} 
		return false;
	}
	
	@Override
	public void executeNotification(String userId, String notificationSettingId) {
		String prevNamespace = NamespaceManager.get();
		String domainName = KeyFactory.stringToKey(notificationSettingId).getNamespace();
		NamespaceManager.set(domainName);
		
		EntityManager mgr = getEntityManager();
		
		try {
			Users user = userService.getUsers(mgr, userId, false);
			valid(user);
			NotificationSettings notificationSetting = notificationSettingService.getUserNotificationSettings(mgr, userId);
			
			if (notificationSetting.getActivities().size() > 0) {
				if (StringUtils.isNotEmpty(user.getEmail())) {
					executeNotificationEmail(domainName, user, notificationSetting.getActivities());
				}
			}
			
			// Notification을 보내고 나서 목록을 지우고 업데이트한다.
			notificationSettingService.resetNotificationActivities(mgr, notificationSetting);
		} catch (Exception ex) {
			ex.printStackTrace();
			String id = KeyFactory.stringToKey(userId).getName();
			LOG.warning(ex.getMessage() + String.format(" : domainName[%s] user id[%s]", domainName, id));
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private NotificationSettings appendUserActivityId(NotificationSettings notificationSetting, String activityId) throws Exception {
		if (!notificationSetting.getActivities().contains(activityId)) {
			notificationSetting.getActivities().add(activityId);
		}
		return notificationSetting;
	}
	
//	@SuppressWarnings("unused")
//	@Deprecated
//	private void executeNotificationEmailQueue(String domainName, Users user, List<String> activityList) {
//		if (StringUtils.isNotBlank(user.getEmail())) {
//			Queue queue = QueueFactory.getQueue(CommonProperty.NOTIFICATION_EMAIL_QUEUE_NAME);
//			TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.NOTIFICATION_EMAIL_SEND_URL);
//		
//			taskOptions = taskOptions
//					.param(PARAM.DOMAINNAME, domainName)
//					.param(PARAM.USERID,  user.getUserId())
//					.param(PARAM.USERNAME, getDisplayUserName(user))
//					.param(PARAM.EMAIL, user.getEmail());
//			
//			for (String activity : activityList) {
//				taskOptions = taskOptions.param(PARAM.ACTIVITIES, activity);
//			}
//			taskOptions = taskOptions.method(Method.POST);
//	
//			queue.add(taskOptions);
//		}
//	}
	
	private void registNotificationExecuteTaskQueue(NotificationSettings notificationSetting) {
		Queue queue = QueueFactory.getQueue(CommonProperty.NOTIFICATION_QUEUE_NAME);
		// 이전 사용자의 Queue를 지운다.
		try {
			String taskName = notificationSetting.getTaskName();
			if (StringUtils.isNotEmpty(taskName)) {
				queue.deleteTask(taskName);
			}
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
		
		// 새로 큐 등록
		notificationSetting = notificationSettingService.updateNotificationQueueTaskName(notificationSetting);
		String newTaskName = notificationSetting.getTaskName();
		if (StringUtils.isNotBlank(newTaskName)) {
			TaskOptions taskOption = TaskOptions.Builder
		            .withUrl(CommonProperty.NOTIFICATION_EXECUTE_URL)
		            //.param("domainId", notificationSetting.getDomainId())
		            //.param("boardId", notificationSetting.getBoardId())
		            .param(PARAM.USERID, notificationSetting.getUserId())
		            .param(PARAM.NOTIFICATIONSETTINGID, notificationSetting.getNotificationSettingId())
		            .method(Method.POST)
		            .taskName(newTaskName);
			// Noti가 발생해야할 시점을 계산하여 Queue에 넣는다.
			try {
				queue.add(taskOption.etaMillis(NotificationSettingService.calculateNotificationTimeInMillis(notificationSetting)));
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
		}
	}
	
	@Override
	public void prepareNotification(String domainName, String activityId, List<String> notificationUserIds) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			Activities activity = activityService.getActivities(activityId);
			activity.setNotificationUserIds(notificationUserIds);
			prepareNotification(activity);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public void prepareNotification(Activities activity) throws Exception {
		List<Users> notificationUserList = new ArrayList<Users>();
		if (activity.getNotificationUserIds() == null || activity.getNotificationUserIds().size() == 0) {
			notificationUserList = getNotificationUsers(activity);
		} else {
			notificationUserList = batchListByKey(Users.class, activity.getNotificationUserIds());
		}
		invokeNotificationExecutor(notificationUserList, activity);
	}
	
	@Override
	public void prepareNotificationQueue(Activities activity) throws Exception {
		String namespace = NamespaceManager.get();
		if (StringUtils.isBlank(namespace)) { return; }
		
		Queue queue = QueueFactory.getQueue(CommonProperty.PREPARE_NOTIFICATION_QUEUE_NAME);
		TaskOptions taskOption = TaskOptions.Builder.withUrl(CommonProperty.PREPARE_NOTIFICATION_URL);
		
		taskOption = taskOption
				.param(PARAM.DOMAINNAME, namespace)
				.param(PARAM.ACTIVITYID, activity.getActivityId())
				.method(Method.POST);
		
		if (activity.getNotificationUserIds() != null) {
			for (String userId : activity.getNotificationUserIds()) {
				taskOption = taskOption.param(PARAM.USERID, userId);
			}
		}

		queue.add(taskOption);
	}
	
	private List<Users> getNotificationUsers(Activities activity) throws UnavailableException, Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getNotificationUsers(mgr, activity);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<Users> getNotificationUsers(EntityManager mgr, Activities activity) throws UnavailableException, Exception {
		try {
			List<Users> notificationUserList = null;
			ActivityKind activityKind = activity.getActivityKind();
			if (ActivityKind.TASKS.equals(activityKind)) {
				notificationUserList = getNotificationTaskUsers(mgr, activity);
			} else if (ActivityKind.SCHEDULE.equals(activityKind)) {
				notificationUserList = getNotificationEventUsers(mgr, activity);
			} else if (ActivityKind.BOARDS.equals(activityKind)) {
				notificationUserList = getNotificationBoardUsers(mgr, activity);
			} else if (ActivityKind.GROUPS.equals(activityKind)) {
				notificationUserList = getDomainUserListForNotification(mgr, activity);
			} else if (ActivityKind.USERS.equals(activityKind)) {
				notificationUserList = getDomainUserListForNotification(mgr, activity);
			} else if (ActivityKind.NOTICE.equals(activityKind)) {
				notificationUserList = getNotificationNoticeUsers(mgr, activity);
			} else if (ActivityKind.USAGE.equals(activityKind)) {
				notificationUserList = getNotificationUsageUsers(mgr, activity);
			} else if (ActivityKind.TASK_CHECKLISTS.equals(activityKind)) {
				notificationUserList = getNotificationTaskChecklistsUsers(mgr, activity);
//			} else if (ActivityKind.TASK_CHECKLIST_COMMENTS.equals(activityKind)) {
//				notificationUserList = getNotificationTaskChecklistCommentUsers(mgr, activity);
			} else if (ActivityKind.TASK_TIMELINES.equals(activityKind)) {
				notificationUserList = getNotificationTaskTimelineUsers(mgr, activity);
//			} else if (ActivityKind.TASK_COMMENTS.equals(activityKind)) {
//				notificationUserList = getNotificationTaskCommentUsers(mgr, activity);
			}  else if (ActivityKind.TASK_TIMELINE_COMMENTS.equals(activityKind)) {
				notificationUserList = getNotificationTaskTimelineCommentUsers(mgr, activity);
			}
	//		if (notificationMemberMap == null || notificationMemberMap.size() == 0) {
	//			throw new UnavailableException("Notification target user not found.");
	//		}
	
			return notificationUserList;
		} catch (Exception ex) {
			throw ex;
		}
	}

	private List<Users> getNotificationTaskUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();

		ActivityType activityType = activity.getActivityType();
		
		if (ActivityType.UPDATE_STARTDATE.equals(activityType)
				|| ActivityType.UPDATE_DUEDATE.equals(activityType)
				|| ActivityType.ATTACHED.equals(activityType) 
				|| ActivityType.MOVED.equals(activityType)
				|| ActivityType.MOVED_BOARD.equals(activityType)
				|| ActivityType.COPIED.equals(activityType)
				|| ActivityType.UPDATE_WIKI.equals(activityType)
				|| ActivityType.ARCHIVED.equals(activityType)
				|| ActivityType.UNARCHIVED.equals(activityType)
//				|| ActivityType.CLOSED.equals(activityType)
//				|| ActivityType.OPENED.equals(activityType)
				) {
			List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(mgr, activity.getTaskId());
			userList.addAll(subscriptionUserList);
		} else  if (ActivityType.ASSIGNED.equals(activityType) ||
				ActivityType.UNASSIGNED.equals(activityType) ||
				ActivityType.REQUEST_MEMBERS.equals(activityType) ||
				ActivityType.CHANGED_OWNERSHIP.equals(activityType)) {
			if (activity.getSyncEntity() != null) {
				userList.add((Users)activity.getSyncEntity());
				Tasks task = (Tasks)activity.getObj();
				if (task != null) {
					Users owner = doFind(mgr, Users.class, task.getOwner());
					userList.add(owner);
				}
			}
		} else if (ActivityType.CONFIRM_MEMBERS.equals(activityType) ||
				ActivityType.REJECT_MEMBERS.equals(activityType)) {
			if (activity.getSyncEntity() != null) {
				userList.add((Users)activity.getSyncEntity());
			}
		}
		
		return userList;
	}
	
	private List<Users> getNotificationTaskChecklistsUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();

		ActivityType activityType = activity.getActivityType();
		
		if (ActivityType.ADDED.equals(activityType)
				|| ActivityType.ASSIGNED.equals(activityType)) {
			List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(mgr, activity.getTaskId());
			userList.addAll(subscriptionUserList);
		} 
		
		return userList;
	}
	
	private List<Users> getNotificationTaskTimelineUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();

		ActivityType activityType = activity.getActivityType();
		
		if (ActivityType.ADDED.equals(activityType)
				|| ActivityType.ADDED_WITH_MENTION.equals(activityType)) {
			List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(mgr, activity.getTaskId());
			userList.addAll(subscriptionUserList);
		} 
		
		return userList;
	}
	
	private List<Users> getNotificationTaskTimelineCommentUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();

		ActivityType activityType = activity.getActivityType();
		
		if (ActivityType.ADDED.equals(activityType)
				|| ActivityType.ADDED_WITH_MENTION.equals(activityType)
//				|| ActivityType.UPDATED_WITH_MENTION.equals(activityType)
				) {
			List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(mgr, activity.getTaskId());
			userList.addAll(subscriptionUserList);
		} 
		
		return userList;
	}

	private List<Users> getNotificationEventUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();

		if (ActivityType.ALARM_BIRTH.equals(activity.getActivityType()) || ActivityType.ALARM_WEDDING.equals(activity.getActivityType())) {
			userList = getDomainUserListForNotification(mgr, activity);
		} else {
			Events event = calendarService.getEvents(mgr, activity.getKindId());
	
			if (EventType.TASK.equals(event.getEventType())) {
				// Task 이벤트일 경우 task subscription을 신청한 멤버에게 보낸다.
				List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(mgr, event.getTaskId());
				userList.addAll(subscriptionUserList);
			} else {
				List<Users> boardUserList = getBoardUserListForNotification(mgr, activity);
				if (boardUserList != null && boardUserList.size() > 0) {
					userList.addAll(boardUserList);
				}
			}
		}
		
		return userList;
	}

	private List<Users> getNotificationBoardUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();
		
		ActivityType activityType = activity.getActivityType();
		
		if (ActivityType.ASSIGNED.equals(activityType)
				|| ActivityType.UNASSIGNED.equals(activityType)
				|| ActivityType.CHANGED_OWNERSHIP.equals(activityType)) {
			if (activity.getSyncEntity() != null) {
				userList.add((Users)activity.getSyncEntity());
				
				Boards board = (Boards)activity.getObj();
				if (board != null) {
					Users owner = doFind(mgr, Users.class, board.getOwner());
					userList.add(owner);
				}
			}
		}

		return userList;
	}

	private List<Users> getBoardUserListForNotification(EntityManager mgr, Activities activity) throws Exception {
		if (StringUtils.isBlank(activity.getBoardId())) { return new ArrayList<Users>(); }

		List<Users> assignedMembers = boardService.getAssignedMemberList(mgr, activity.getBoardId());
		return assignedMembers;
	}

	private List<Users> getDomainUserListForNotification(EntityManager mgr, Activities activity) throws Exception {
		if (StringUtils.isBlank(activity.getDomainId())) { return new ArrayList<Users>(); }
		return userService.listUsers(mgr, true, false);
	}

	private List<Users> getNotificationNoticeUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();
		ActivityType activityType = activity.getActivityType();
		if (ActivityType.ADDED.equals(activityType)) {
			// Notification을 보낼 user 목록
			List<Users> boardUserList = getBoardUserListForNotification(mgr, activity);
			if (boardUserList != null && boardUserList.size() > 0) {
				userList.addAll(boardUserList);
			}
		} else if (ActivityType.SYSTEM_NOTICE_ADDED.equals(activityType)) {
			List<Users> domainUserList = getDomainUserListForNotification(mgr, activity);
			if (domainUserList != null && domainUserList.size() > 0) {
				userList.addAll(domainUserList);
			}
		}

		return userList;
	}

	private List<Users> getNotificationUsageUsers(EntityManager mgr, Activities activity) throws Exception {
		List<Users> userList = new ArrayList<Users>();

		List<Users> domainUserList = getDomainUserListForNotification(mgr, activity);
		for (Users user : domainUserList) {
			if (user.isSuper()) { userList.add(user); }	// Admin has super authority.
			//if (user.isAdmin() || user.isSuper()) { userList.add(user); }
		}

		return userList;
	}
	
	private List<Notifications> insertNotifications(EntityManager mgr, Activities activity, Collection<String> userIdList) throws Exception {
		try {
			List<Notifications> notificationList = new ArrayList<Notifications>();

			for (String userId : userIdList) {
				Notifications notification = new Notifications(activity, userId);
				notificationList.add(notification);
			}
			
			doPersistTransaction(mgr, notificationList);
			
			return notificationList;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public List<Notifications> updateNotificationsRead(List<String> activityIdList, boolean isRead) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users user = getCurrentUser();
			
			DsQuery<Notifications> dsQuery = new DsQuery<>(Notifications.class)
					.eq(FLD.deleteYN, null)
					.in(FLD.activityId, activityIdList)
					.eq(FLD.userId, user.getUserId());
			
			List<Notifications> notificationList = dsQuery.execute(mgr);;

			for (Notifications notification : notificationList) {
				notification.setRead(isRead);
			}
			
			doMergeTransaction(mgr, notificationList);
			
			return notificationList;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private int scheduledRemoveNotifications(String domainName) throws Exception {
		if (StringUtils.isBlank(domainName)) { return -1; }
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();

		try {
			Date createdBefore = CalendarUtil.addDay(new Date(), CommonProperty.REMOVE_NOTIFICATION_DAYS);
			
			TypedQuery<Notifications> query = new QueryBuilder<>(Notifications.class)
					.addClause(FLD.deleteYN, null)
					//.addClause(FLD.domainId, domainId)	// unnecessary condition
					.addLEClause(FLD.created, createdBefore, SortDirection.ASC)
					.build(mgr);
			List<Notifications> results = queryResults(query);
			doRemoveTransaction(mgr, results);
			return results.size();
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public void scheduledRemoveAllNotifications() throws Exception {
		try {
			QueryResult<Domains> results = listDomains(null, null);
			for (Domains domain : results.getResultList()) {
				scheduledRemoveNotifications(domain.getDomainName());
			}
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private QueryResult<Notifications> listNotifications(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			String boardId,
			String userId,
			Boolean mention) throws Exception {
		try {
			DsQuery<Notifications> dsQuery = new DsQuery<>(Notifications.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.boardId, boardId)
					.eq(FLD.userId, userId)
					.eq(FLD.mention, Boolean.TRUE.equals(mention)?true:null)
					.sort(FLD.created, SortDirection.DESC)
					.cursor(cursorString)
					.limit(limit);
		
			List<Notifications> results = dsQuery.execute(mgr);
			return new QueryResult<Notifications>(results, dsQuery.getCursor());
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public QueryResult<Activities> listMyNotificationsByActivity(
			String cursorString,
			Integer limit,
			String boardId,
			Boolean mention) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			return listNotificationsByActivitiy(mgr, cursorString, limit, boardId, loginUser.getUserId(), mention);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private QueryResult<Activities> listNotificationsByActivitiy(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			String boardId,
			String userId,
			Boolean mention) throws Exception {
		try {
			QueryResult<Notifications> results = listNotifications(mgr, cursorString, limit, boardId, userId, mention);
			List<String> activityIdList = new ArrayList<String>();
			List<Notifications> notificationList = results.getResultList();
			for (Notifications notification : notificationList) {
				if (StringUtils.isBlank(notification.getActivityId())) { continue; }
				activityIdList.add(notification.getActivityId());
			}
			Map<String, Activities> activitiesMap = batchMapByKey(mgr, Activities.class, activityIdList);
			List<Activities> activityList = new ArrayList<Activities>();
			
			Messages localeMessage = Messages.localeMessages(userId, WRAPPED_CHAR_TYPE.WEB);
			// 조회 결과값대로 정렬을 하기 위해 결과값 순서대로 다시 activityList에 넣는다.
			for (Notifications notification: notificationList) {
				Activities activity = activitiesMap.get(notification.getActivityId());
				if (activity == null) { continue; }
				activity.setRead(notification.isRead());
				String message = localeMessage.getMessage(activity);
				message = ActivityService.toLocaleStageString(message, localeMessage);
				activity.setMessage(message);
				activityList.add(activity);
			}
			return new QueryResult<Activities>(activityList, results.getCursorString());
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public CountNotifications countUserNotifications(CountNotifications countNotification) throws Exception {
		try {
			Users loginUser = getCurrentUser();
			for (CountInfo countInfo : countNotification.getCountInfos()) {
				Long count = countNotifications(loginUser.getUserId(), countInfo.getBoardId(), countInfo.getCheckDate());
				countInfo.setCount(count);
			}
			return countNotification;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private Long countNotifications(String userId, String boardId, Date checkedDate) {
		try {
			DsQuery<Notifications> dsQuery = new DsQuery<>(Notifications.class)
					.eq(FLD.userId, userId)
					.eq(FLD.boardId, boardId)
					.gt(FLD.created, checkedDate);
					
			return dsQuery.count();
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Notification Kind or entity not found.", ex.getMessage()));
			return 0L;
		}
	}
	
	// SendEmail
	private void executeNotificationEmail(String domainName, Users user, List<String> activities) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			String userId = user.getUserId();
			String userName = getDisplayUserName(user);
			String email = user.getEmail();
			
			Messages message = Messages.localeMessages(userId, WRAPPED_CHAR_TYPE.EMAIL);
		
			String subject = message.getMessage(Messages.NOTIFICATION_SUBJECT, domainName);
			String templateName = MessageFormat.format(CommonProperty.NOTIFICATION_EMAIL_TEMPLATE, message.getLocale());
			
			List<Activities> activityList = makeActivityMessage(activities, message);
			
			if (StringUtils.isNotBlank(email) && StringUtils.isNotBlank(subject) && activityList != null && activityList.size() > 0) {
				HashMap<String, Object> documentMap = new HashMap<String, Object>();
				TreeMap<String, List<Activities>> activityMap = getActivityMap(activityList, message);
				List<String> activityMapKeys = getKeyListCustomOrdered(activityMap);
				
				documentMap.put(PARAM.DOMAINNAME, domainName);
				//documentMap.put(PARAM.ACTIVITIES, activityList);
				documentMap.put(PARAM.ACTIVITYMAP, activityMap);
				documentMap.put(PARAM.ACTIVITYMAPKEYS, activityMapKeys);
				documentMap.put(PARAM.USERNAME, userName);
				documentMap.put(PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL);
				documentMap.put(PARAM.LOCALE, message.getLocale().toString());
				
				String htmlBody = docBuilder.createDocumentString(templateName, documentMap);
				
				SendEmail.sendEmailQueue(email, subject, htmlBody, CommonProperty.NOTIFICATION_EMAIL_QUEUE_NAME);
			}
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
//	private Messages getLocaleMessages(String userId) {
//		UserSetting userSetting = null;
//		if (StringUtils.isNotBlank(userId)) {
//			userSetting = userSettingService.getUserSetting(userId, CommonProperty.USER_UI_SETTING_NAME);
//		}
//		
//		return new Messages(userSetting);
//	}
	
	private List<Activities> makeActivityMessage(List<String> activities, Messages message) {
		if (activities == null) { return null; }
		
		Set<String> activityIds = new HashSet<String>(activities);
		List<Activities> activityList = activityService.batchListActivities(activityIds);
		if (activityList != null) {
			for (Activities activity : activityList) {
				activity.setMessage(message.getMessage(activity));
			}
		}
		return activityList;
	}
	
	private TreeMap<String, List<Activities>> getActivityMap(List<Activities> activityList, Messages message) throws Exception {
		try {
			TreeMap<String, List<Activities>> activityMap = new TreeMap<String, List<Activities>>();
			
			Set<String> boardIds = new HashSet<String>();
			
			for (Activities activity : activityList) {
				String boardId = activity.getBoardId();
				if (StringUtils.isNotBlank(boardId)) {
					boardIds.add(boardId);
				}
			}
			
			Map<String, Boards> boardMap = boardService.batchMapBoards(boardIds);
			
			for (Activities activity : activityList) {
				String boardId = activity.getBoardId();
				String key = null;
				if (StringUtils.isEmpty(boardId)) {
					key = message.getSourceMessage(Messages.NOTIFICATION_COMMON);
					//key = activity.getActivityKind().toString();
				} else {
					Boards board = boardMap.get(boardId);
					if (board == null) { key = boardId; }
					else { key = board.getTitle(); }
				}
				
				// 사용하지 않는 summary field에다가  @UserName, @UserName, @UserName, .... 형식으로 저장
				activity.setSummary(ActivityService.getMentionedUserNames(activity));
				
				if (!activityMap.containsKey(key)) { activityMap.put(key, new ArrayList<Activities>()); }
				activityMap.get(key).add(activity);
			}
			
			return activityMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<String> getKeyListCustomOrdered(TreeMap<String, List<Activities>> activityMap) {
		List<String> keyList = new ArrayList<String>(activityMap.keySet());
		
		if (keyList.contains(Messages.NOTIFICATION_COMMON)) {
			keyList.remove(Messages.NOTIFICATION_COMMON);
			keyList.add(0, Messages.NOTIFICATION_COMMON);
		}
		return keyList;
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public QueryResult<Notifications> listMyNotifications(
//			String cursorString,
//			Integer limit,
//			String boardId,
//			Boolean mention) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			Users loginUser = getCurrentUser();
//			return listNotifications(mgr, cursorString, limit, boardId, loginUser.getUserId(), mention);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@SuppressWarnings("unused")
//	@Deprecated
//	private List<Users> getNotificationTaskCommentUsers(EntityManager mgr, Activities activity) throws Exception {
//		List<Users> userList = new ArrayList<Users>();
//
//		ActivityType activityType = activity.getActivityType();
//		
//		if (ActivityType.ADDED.equals(activityType)) {
//			List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(mgr, activity.getTaskId());
//			userList.addAll(subscriptionUserList);
//		} 
//		
//		return userList;
//	}
//	@SuppressWarnings("unused")
//	@Deprecated
//	private List<Users> getNotificationTaskChecklistCommentUsers(EntityManager mgr, Activities activity) throws Exception {
//		List<Users> userList = new ArrayList<Users>();
//
//		ActivityType activityType = activity.getActivityType();
//		
//		if (ActivityType.ADDED.equals(activityType)) {
//			List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(mgr, activity.getTaskId());
//			userList.addAll(subscriptionUserList);
//		} 
//		
//		return userList;
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
