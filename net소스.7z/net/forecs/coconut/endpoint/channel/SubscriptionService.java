package net.forecs.coconut.endpoint.channel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;


public class SubscriptionService extends CommonService implements ISubscriptionService {
	private final IUserService userService;

	@Inject
	public SubscriptionService(IUserService userService) {
		this.userService = userService;
	}
	
	@Override
	public List<Subscriptions> listSubscriptions(
			EntityManager mgr,
			String boardId,
			String taskId,
			String userId,
			boolean includeUser) throws Exception {
		if (StringUtils.isNotBlank(taskId)) { boardId = null; }
		
		DsQuery<Subscriptions> dsQuery = new DsQuery<>(Subscriptions.class)
				.eq(FLD.boardId, boardId)
				.eq(FLD.taskId, taskId)
				.eq(FLD.userId, userId);
		
		List<Subscriptions> subscriptionList = dsQuery.execute(mgr);
		
		if (includeUser) {
			Map<String, Users> usersMap = batchMapSubscriptionUsers(mgr, subscriptionList);
			
			for (Subscriptions subscription : subscriptionList) {
				subscription.setUser(usersMap.get(subscription.getUserId()));
			}
		}
		
		return subscriptionList;
	}
	
	private Map<String, Users> batchMapSubscriptionUsers(EntityManager mgr, List<Subscriptions> subscriptionList) throws Exception {
		Set<String> userIds = new HashSet<String>();
		for (Subscriptions subscription : subscriptionList) {
			userIds.add(subscription.getUserId());
		}
		return userService.batchMapUsers(mgr, userIds, false);
	}
	
//	@Override
//	public List<Subscriptions> listSimpleTaskSubscriptions(EntityManager mgr, String boardId, String userId) throws Exception {
//		return listTaskSubscriptions(mgr, boardId, userId, true);
//	}

	@Override
	public List<Subscriptions> listTaskSubscriptions(EntityManager mgr,
			String boardId, String userId, boolean includeUser) throws Exception {
		DsQuery<Subscriptions> dsQuery = new DsQuery<>(Subscriptions.class)
				.eq(FLD.boardId, boardId)
				.eq(FLD.userId, userId);

		List<Subscriptions> subscriptionList = dsQuery.execute(mgr);
		
		if (includeUser) {
			Map<String, Users> usersMap = batchMapSubscriptionUsers(mgr, subscriptionList);
			
			for (Subscriptions subscription : subscriptionList) {
				subscription.setUser(usersMap.get(subscription.getUserId()));
			}
		}
		
		return subscriptionList;
	}

	@Override
	public List<Users> getSubscriptionUserList(EntityManager mgr, String taskId) throws Exception {
		if (StringUtils.isBlank(taskId)) { return new ArrayList<Users>(); }
		DsQuery<Subscriptions> dsQuery = new DsQuery<>(Subscriptions.class)
				.eq(FLD.taskId, taskId);

		List<Users> userList = new ArrayList<Users>();
		List<Subscriptions> subscriptionList = dsQuery.execute(mgr);
		
		if (subscriptionList != null && subscriptionList.size() > 0) {
			Map<String, Users> userMap = batchMapSubscriptionUsers(mgr, subscriptionList);
			
			for (Subscriptions subscription : subscriptionList) {
				Users user = userMap.get(subscription.getUserId());
				if (isValid(user) && !userList.contains(user)) {
					userList.add(user);
				}
			}
		}

		return userList;
	}

	private Subscriptions getSubscriptions(EntityManager mgr, String subscriptionId) {
		return doFind(mgr, Subscriptions.class, subscriptionId);
	}

	@Override
	public Subscriptions getTaskSubscription(EntityManager mgr, String taskId, String userId) throws Exception {
		String subscriptionId = KeyUtil.createSubscriptionKeyString(taskId, userId);
		Subscriptions subscription = getSubscriptions(mgr, subscriptionId);
		if (subscription != null) {
			subscription.setUser(userService.getUsers(mgr, userId, false));
		}
		
		return subscription;
	}

	@Override
	public Subscriptions insertSubscriptions(EntityManager mgr, Subscriptions subscription) throws Exception {
		try {
			subscription.setKey(KeyUtil.createSubscriptionKey(subscription));

			if (contains(mgr, Subscriptions.class, subscription.getKey())) {
				return null;
			}
			
			doPersist(mgr, subscription);
			return subscription;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public void removeSubscriptions(EntityManager mgr, List<String> subscriptionIdList) throws Exception {
		doRemoveTransaction(mgr, Subscriptions.class, subscriptionIdList);
	}

	@Override
	public void removeSubscriptions(EntityManager mgr, String subscriptionId) throws Exception {
		doRemove(mgr, Subscriptions.class, subscriptionId);
	}

	@Override
	public int bulkRemoveSubscriptions(
			String boardId,
			String taskId,
			String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			TypedQuery<Subscriptions> query = new QueryBuilder<>(Subscriptions.class)
//					.addClause(FLD.domainId, domainId)	// unnecessary condition
					.addClause(FLD.boardId, boardId)
					.addClause(FLD.taskId, taskId)
					.addClause(FLD.userId, userId)
					.build(mgr);
			List<Subscriptions> queryResults = queryResults(query);
			doRemoveTransaction(mgr, queryResults);
			return queryResults.size();
			// TODO bulkRemove시에도 activity를 남겨야 한다면..............................................
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public List<Subscriptions> listTaskSubscriptions(String boardId, String userId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			return listTaskSubscriptions(mgr, boardId, userId, false);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Users> getSubscriptionUserList(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getSubscriptionUserList(mgr, taskId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Subscriptions updateSubscriptions(EntityManager mgr, Subscriptions subscriptions) throws Exception {
//		try {
//			valid(subscriptions);
//			doMerge(mgr, subscriptions);
//			return subscriptions;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	@Override
//	public Subscriptions insertTaskSubscription(String boardId, String taskId, String userId, String creatorId) throws Exception {
//		Users user = getCurrentUser();
//		final String domainId = KeyUtil.createDomainKeyString(user.getDomainName());
//		if (StringUtils.isEmpty(userId)) {
//			userId = user.getUserId();
//		}
//		if (StringUtils.isEmpty(creatorId)) {
//			creatorId = userId;
//		}
//		return insertSubscriptions(new Subscriptions(domainId, boardId, taskId, userId, creatorId));
//	}
//	private Subscriptions insertSubscriptions(Subscriptions subscription) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			Users loginUser = getCurrentUser();
//			subscription.setCreator(loginUser.getUserId());
//
//			beginTransaction(mgr);
//			subscription = insertSubscriptions(mgr, subscription);
//			commitTransaction(mgr);
//			
//			return subscription;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Subscriptions removeSubscriptions(String subscriptionId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			beginTransaction(mgr);
//			Subscriptions subscription = removeSubscriptions(mgr, subscriptionId);
//			commitTransaction(mgr);
//
//			return subscription;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
