package net.forecs.coconut.endpoint.workspace;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.workspace.TaskLabelMap;


public interface ITaskLabelMapService extends ICommonService {
	public abstract List<TaskLabelMap> listTaskLabelMap(EntityManager mgr, String taskId) throws Exception;
	public abstract List<TaskLabelMap> listTaskLabelMapByValue(EntityManager mgr, String taskLabelId) throws Exception;
	public abstract List<TaskLabelMap> updateTaskLabelMap(String taskId, List<String> taskLabelIds) throws Exception;
	public abstract void removeTaskLabelMap(String taskId) throws Exception;
	public abstract void removeLabelMap(EntityManager mgr, String taskLabelId) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract List<TaskLabelMap> listTaskLabelMap(String taskId) throws Exception;
//	public abstract List<TaskLabelMap> listTaskLabelMapByValue(String taskLabelId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
