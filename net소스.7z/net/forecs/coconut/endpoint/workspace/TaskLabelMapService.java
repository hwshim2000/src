package net.forecs.coconut.endpoint.workspace;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.workspace.TaskLabelMap;

import com.google.appengine.api.datastore.Key;


public class TaskLabelMapService extends CommonService implements ITaskLabelMapService {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(TaskLabelMapService.class.getName());

	@Inject
	public TaskLabelMapService() {
	}

	@Override
	public List<TaskLabelMap> listTaskLabelMap(EntityManager mgr, String taskId) throws Exception {
		MemcacheManager<TaskLabelMap, List<TaskLabelMap>> mm = new MemcacheManager<>(TaskLabelMap.class, MemcacheManager.keySet(taskId));
		String memcacheKey = mm.createMemcacheKey(taskId);
		List<TaskLabelMap> labelList = mm.getMemcache(memcacheKey);
		if (labelList == null) {
			DsQuery<TaskLabelMap> dsQuery = new DsQuery<>(TaskLabelMap.class)
						.eq(FLD.deleteYN, N)
						.eq(FLD.taskId, taskId);
	
			labelList = dsQuery.execute(mgr);
			mm.setMemcache(memcacheKey, labelList);
		}
		return labelList;
	}

	@Override
	public List<TaskLabelMap> listTaskLabelMapByValue(EntityManager mgr, String taskLabelId) throws Exception {
		try {
			DsQuery<TaskLabelMap> dsQuery = new DsQuery<>(TaskLabelMap.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.taskLabelId, taskLabelId);

			return dsQuery.execute(mgr);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public List<TaskLabelMap> updateTaskLabelMap(String taskId, List<String> taskLabelIds) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			List<TaskLabelMap> taskLabelMapListToRemove = new ArrayList<TaskLabelMap>(listTaskLabelMap(mgr, taskId));
			List<TaskLabelMap> taskLabelMapListToPersist = new ArrayList<TaskLabelMap>();
			List<TaskLabelMap> taskLabelMapList = new ArrayList<TaskLabelMap>();

			for (String taskLabelId : taskLabelIds) {
				TaskLabelMap taskLabelMap = null;
				for (TaskLabelMap mapToRemove : taskLabelMapListToRemove) {
					if (mapToRemove.getTaskLabelId().equals(taskLabelId)) {
						taskLabelMap = mapToRemove;
						break;
					}
				}

				if (taskLabelMap != null) {
					taskLabelMapListToRemove.remove(taskLabelMap);	// Keep the same label
				} else {
					taskLabelMap = new TaskLabelMap(taskId, taskLabelId);
					Key taskLabelMapKey = KeyUtil.createTaskLabelMapKey(taskLabelMap);
					taskLabelMap.setKey(taskLabelMapKey);

					taskLabelMapListToPersist.add(taskLabelMap);
				}

				taskLabelMapList.add(taskLabelMap);
			}

			beginTransaction(mgr, false);
			doPersist(mgr, taskLabelMapListToPersist);
			doRemove(mgr, taskLabelMapListToRemove);
			commitTransaction(mgr);
			
			return taskLabelMapList;
		}  catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private int bulkRemoveTaskLabelMap(
			EntityManager mgr,
			String domainId,
			String boardId,
			String taskId,
			String taskLabelId) throws Exception {

		TypedQuery<TaskLabelMap> query = new QueryBuilder<>(TaskLabelMap.class)
//				.addClause(FLD.domainId, domainId)	// unnecessary condition
				.addClause(FLD.boardId, boardId)
				.addClause(FLD.taskId, taskId)
				.addClause(FLD.taskLabelId, taskLabelId)
				.build(mgr);

		List<TaskLabelMap> results = queryResults(query);
		doRemoveTransaction(mgr, results);
		return results.size();
	}
	
	@Override
	public void removeLabelMap(EntityManager mgr, String taskLabelId) throws Exception {
		try {
			bulkRemoveTaskLabelMap(mgr, null, null, null, taskLabelId);
		} catch (Exception ex) {
			throw ex;
		}
	}
	@Override
	public void removeTaskLabelMap(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			bulkRemoveTaskLabelMap(mgr, null, null, taskId, null);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public List<TaskLabelMap> listTaskLabelMap(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			return listTaskLabelMap(mgr, taskId);
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<TaskLabelMap> listTaskLabelMapByValue(String taskLabelId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return this.listTaskLabelMapByValue(mgr, taskLabelId);
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
