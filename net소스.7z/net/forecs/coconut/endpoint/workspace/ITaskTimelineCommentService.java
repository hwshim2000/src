package net.forecs.coconut.endpoint.workspace;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.search.index.CommentIndex;


public interface ITaskTimelineCommentService extends ICommonService {
	public abstract List<TaskTimelineComments> listTaskTimelineComments(EntityManager mgr, String taskTimelineId) throws Exception;
	public abstract TaskTimelineComments getTaskTimelineComments(String taskTimelineCommentId) throws Exception;
	public abstract TaskTimelineComments insertTaskTimelineComments(String parentTaskTimelineCommentId,
			TaskTimelineComments tasktimelinecomments) throws Exception;
	public abstract TaskTimelineComments updateTaskTimelineComments(TaskTimelineComments tasktimelinecomments) throws Exception;
	public abstract void removeTaskTimelineComments(String taskTimelineCommentId) throws Exception;
	public abstract int bulkRemoveTaskTimelineComments(String taskTimelineId) throws Exception;
	public abstract CommentIndex createOrUpdateTaskTimelineCommentIndex(TaskTimelineComments taskTimelineComment);
}
