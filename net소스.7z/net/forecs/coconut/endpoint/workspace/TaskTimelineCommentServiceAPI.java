package net.forecs.coconut.endpoint.workspace;

import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;


@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class TaskTimelineCommentServiceAPI {
	private final ITaskTimelineCommentService taskTimelineCommentService;
	
	@Inject
	public TaskTimelineCommentServiceAPI(ITaskTimelineCommentService taskTimelineCommentService) {
		this.taskTimelineCommentService = taskTimelineCommentService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getTaskTimelineComments", path = "tasks/timelines/comments/{taskTimelineCommentId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public TaskTimelineComments getTaskTimelineComments(@Named(FLD.taskTimelineCommentId) String taskTimelineCommentId) throws Exception {
		CommonService.validNamespace(taskTimelineCommentId);
		return taskTimelineCommentService.getTaskTimelineComments(taskTimelineCommentId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "insertTaskTimelineComments", path = "tasks/timelines/comments", httpMethod = HttpMethod.POST)
	@RequiresUser
	public TaskTimelineComments insertTaskTimelineComments(
			TaskTimelineComments taskTimelineComment) throws Exception {
		CommonService.validNamespace(taskTimelineComment.getTaskTimelineId());
		String parentId = taskTimelineComment.getParentId();
		if ("0".equals(parentId)) {
			parentId = "";
		}
		return taskTimelineCommentService.insertTaskTimelineComments(parentId, taskTimelineComment);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskTimelineComments", path = "tasks/timelines/comments", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public TaskTimelineComments updateTaskTimelineComments(
			TaskTimelineComments taskTimelineComment) throws Exception {
		CommonService.validNamespace(taskTimelineComment);
		return taskTimelineCommentService.updateTaskTimelineComments(taskTimelineComment);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeTaskTimelineComments", path = "tasks/timelines/comments/{taskTimelineCommentId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeTaskTimelineComments(@Named(FLD.taskTimelineCommentId) String taskTimelineCommentId) throws Exception {
		CommonService.validNamespace(taskTimelineCommentId);
		taskTimelineCommentService.removeTaskTimelineComments(taskTimelineCommentId);
	}
}