package net.forecs.coconut.endpoint.workspace;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.workspace.TaskLabels;


public interface ITaskLabelService extends ICommonService {
	public abstract List<TaskLabels> listTaskLabels(String boardId) throws Exception;
	public abstract List<TaskLabels> listTaskLabels(EntityManager mgr, String boardId) throws Exception;
	public abstract TaskLabels insertTaskLabels(TaskLabels taskLabel) throws Exception;
	public abstract TaskLabels updateTaskLabels(TaskLabels taskLabel) throws Exception;
	public abstract void removeTaskLabels(String taskLabelId) throws Exception;
	public abstract void forceRemoveTaskLabels(String taskLabelId) throws Exception;
	public abstract List<TaskLabels> listTaskLabelsTagged(EntityManager mgr, String taskId) throws Exception;
	public abstract List<TaskLabels> updateTaskLabelsTagged(String taskId, List<String> taskLabelIds) throws Exception;
	public abstract void removeTaskLabelsTagged(String taskId) throws Exception;
	public abstract Map<String, List<TaskLabels>> batchMapChildTaskLabels(EntityManager mgr, List<String> taskIdList) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract TaskLabels getTaskLabels(String taskLabelId);
//	public abstract List<TaskLabels> listTaskLabelsTagged(String taskId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
