package net.forecs.coconut.endpoint.workspace;

import net.forecs.coconut.endpoint.common.CommonService;


@Deprecated
public class TaskTimelineScoreService extends CommonService implements ITaskTimelineScoreService {
//	@Override
//	public List<TaskTimelineScores> listTaskTimelineScores(
//			String taskTimelineId,
//			EvaluateType evaluateType) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return listTaskTimelineScores(mgr, taskTimelineId, evaluateType);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	
//	@Override
//	public List<TaskTimelineScores> listTaskTimelineScores(
//			EntityManager mgr,
//			String taskTimelineId,
//			EvaluateType evaluateType) throws Exception {
//		TypedQuery<Key> query = new QueryBuilder<>(TaskTimelineScores.class)
//				.addClause(FLD.taskTimelineId, taskTimelineId)
//				.addClause(FLD.evaluateType, evaluateType)
//				.buildKeyOnlyRead(mgr);
//
//		return queryResults(mgr, TaskTimelineScores.class, query);
//	}
//
//	@SuppressWarnings("unused")
//	private TaskTimelineScores getTaskTimelineScores(String taskTimelineScoreId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, TaskTimelineScores.class, taskTimelineScoreId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public TaskTimelineScores insertTaskTimelineScores(TaskTimelineScores taskTimelineScore) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Users loginUser = getCurrentUser();
//			taskTimelineScore.setCreator(loginUser.getUserId());
//			taskTimelineScore.setKey(KeyUtil.createTaskTimelineScoreKey(taskTimelineScore.getTaskTimelineId(), loginUser));
//			
//			if (doFind(mgr, TaskTimelineScores.class, taskTimelineScore.getKey()) != null) {
//				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(taskTimelineScore.getTaskTimelineScoreId()));
//			}
//			
//			doPersistTransaction(mgr, taskTimelineScore);
//			
//			return taskTimelineScore;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public TaskTimelineScores removeTaskTimelineScores(Key taskTimelineScoreKey) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return permanentRemoveTaskTimelineScores(mgr, taskTimelineScoreKey);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	
//	private TaskTimelineScores permanentRemoveTaskTimelineScores(EntityManager mgr, Key taskTimelineScoreKey) {
//			TaskTimelineScores taskTimelineScore = doFind(mgr, TaskTimelineScores.class, taskTimelineScoreKey);
//			
//			if (taskTimelineScore != null) {
//				doRemoveTransaction(mgr, taskTimelineScore);
//			}
//			
//			return taskTimelineScore;
//	}
//
//	@Override
//	public int bulkRemoveTaskTimelineScores(String taskTimelineId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TypedQuery<Key> query = new QueryBuilder<>(TaskTimelineScores.class)
//					.addClause(FLD.taskTimelineId, taskTimelineId)
//					.buildKeyOnlyRead(mgr);
//			
//			List<Key> keys = listAllKeysForLimitedChunkSize(query);
//			for (Key key : keys) {
//				permanentRemoveTaskTimelineScores(mgr, key);
//			}
//			return keys.size();
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
}
