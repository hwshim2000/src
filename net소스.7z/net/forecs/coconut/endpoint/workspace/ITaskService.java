package net.forecs.coconut.endpoint.workspace;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.EditPermission;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.TaskIndex;

import com.google.appengine.api.datastore.Text;


public interface ITaskService extends ICommonService {
	public abstract QueryResult<Tasks> queryUserTasks(
			String cursorString,
			Integer limit,
			String userId,
			String archiveYN,
			SortType sortType,
			SortDirection sortDirection,
			Set<String> includes) throws Exception;
	
	public abstract QueryResult<Tasks> queryTasks(
			String cursorString,
			Integer limit,
			Collection<String> boardIdList,
			String archiveYN,
			SortType sortType,
			SortDirection sortDirection) throws Exception;
	public abstract QueryResult<Tasks> queryTasks(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> boardIdList,
			String archiveYN,
			SortType sortType,
			SortDirection sortDirection) throws Exception;
	public abstract List<String> listSubscribedTaskIds(EntityManager mgr, String boardId, String userId);
	public abstract List<String> listMySubscribedTaskIds(String boardId);
	public abstract boolean isMySubscribedTask(String taskId);
	public abstract Tasks getTasks(EntityManager mgr, String taskId);
	public abstract Tasks getTasks(String domainName, String taskId);
	public abstract Tasks insertTasks(Tasks task) throws Exception;
	public abstract List<Users> listTasksMembers(String taskId) throws Exception;
	public abstract List<Users> listTasksUnassignedMembers(String taskId) throws Exception;
	public abstract Users assignMember(String taskId, String userId, Auth auth) throws Exception;
	public abstract List<Users> assignMemberList(String taskId, List<String> userIdList, Auth auth) throws Exception;
	public abstract void unassignMemberList(String taskId, List<String> userIdList) throws Exception;
	public abstract Users changeOwnership(String taskId, String targetUserId) throws Exception;
	public abstract boolean isAvailableMemberAuth(String taskId, String userId);
	public abstract Map<String, Tasks> allTaskMap(EntityManager mgr) throws Exception;
		
	public abstract Tasks updateTaskTitle(String taskId, String title) throws Exception;
	public abstract Tasks updateTaskDescription(String taskId, Text description) throws Exception;
	public abstract Tasks updateTasksWiki(String taskId, Text wiki) throws Exception;
	public abstract Tasks updateTaskStartDate(String taskId, Date startDate) throws Exception;
	public abstract Tasks updateTaskDueDate(String taskId, Date dueDate) throws Exception;
	public abstract Tasks updateTaskImportance(String taskId, String importance) throws Exception;
	public abstract Tasks updateTaskLabelList(String taskId, List<String> taskLabelIds) throws Exception;
	public abstract Tasks updateTaskSubscription(String taskId, boolean subscribe) throws Exception;
	public abstract Tasks updateTaskEditChecklistPermission(String taskId, EditPermission editChecklistPermission) throws Exception;
	public abstract Tasks updateTaskEditDetailPermission(String taskId, EditPermission editDetailPermission) throws Exception;
	public abstract Tasks updateTaskDisplayInCalendar(String taskId, String displayInCalendarYN) throws Exception;
	
	public abstract Tasks archiveTask(String taskId, String archiveYN) throws Exception;
	public abstract List<Tasks> archiveTaskList(List<String> taskIds, String archiveYN) throws Exception;
	//@Deprecated
	//public abstract Tasks moveTask(String taskId, String tasklistId) throws Exception;
	public abstract Tasks moveStage(String taskId, String taskStage) throws Exception;
	public abstract List<Tasks> moveStageList(List<String> taskIds, String taskStage) throws Exception;
	public abstract List<Tasks> batchMoveStage(String boardId, String fromTaskStage, String toTaskStage) throws Exception;
	public abstract List<Tasks> batchMoveStage(EntityManager mgr, String boardId, Stages fromStage, Stages toStage) throws Exception;
	
	public abstract Tasks removeTasks(String taskId) throws Exception;
	public abstract Tasks getTasksDetail(String taskId) throws Exception;
	public abstract Attachments removeTaskAttachment(String taskId, String attachmentId) throws Exception;
	public abstract Attachments addTaskAttachment(String taskId, Attachments attachment) throws Exception;
	public abstract Tasks addTaskFinalAttachments(String taskId, String attachmentId) throws Exception;

	public abstract TaskIndex createOrUpdateTaskIndex(EntityManager mgr, String taskId);
	public abstract TaskIndex createOrUpdateTaskIndex(EntityManager mgr, Tasks task);
	
	public abstract boolean isLockTaskWiki(String taskId);
	public abstract Map<String, Object> lockTaskWiki(String taskId) throws Exception;
	public abstract void unlockTaskWiki(String taskId);
	
	public abstract List<String> listMyTaskIds(Collection<String> boardIdList) throws Exception;
	public abstract List<String> listMyTaskIds(EntityManager mgr, Collection<String> boardIdList) throws Exception;
	public abstract List<String> listMyTaskIds(EntityManager mgr, String userId, Collection<String> boardIdList) throws Exception;
	public abstract List<String> listMyTaskIds(EntityManager mgr, Users user, Collection<String> boardIdList) throws Exception;
	public abstract List<String> listUserTaskIds(List<String> boardIdList, List<String> userIdList) throws Exception;
	public abstract Tasks openTask(String taskId) throws Exception;
	public abstract Tasks closeTask(String taskId) throws Exception;
	
	public abstract void requestMembers(String taskId, String requestUserId) throws Exception;
	public abstract void confirmMembers(String taskId, String requestUserId) throws Exception;
	public abstract void rejectMembers(String taskId, String rejectUserId) throws Exception;
	
	public abstract Tasks moveTask(String taskId, String toBoardId, String toTaskStage) throws Exception;
	public abstract Tasks copyTask(String taskId, String toBoardId, String toTaskStage) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract long countTasks(
//			String boardId,
//			String tasklistId,
//			List<String> userIdList,
//			String archiveYN) throws Exception;
//	public abstract QueryResult<Tasks> listTasks (
//			String cursorString,
//			Integer limit,
//			String boardId,
//			String tasklistId) throws Exception;
//	public abstract List<String> listSubscribedTaskIds(String boardId, String userId);
//	public abstract List<String> listMySubscribedTaskIds(EntityManager mgr, String boardId);
//	public abstract Tasks getTasks(String taskId);
//	public abstract Users unassignMember(String taskId, String userId) throws Exception;
//	public abstract Tasks updateTasks(Tasks task) throws Exception;
//	public abstract Events insertOrUpdateTaskEvent(Tasks task) throws Exception;
//	public abstract void permanentRemoveTasks(String taskId) throws Exception;
//	public abstract Tasks recoverTaskWiki(String taskId, String taskHistoryId) throws Exception;
//	public abstract void removeTaskFinalAttachments(String taskId, String attachmentId) throws Exception;
//	public abstract void replaceTaskFinalAttachments(String taskId, String oldAttachmentId, String newAttachmentId) throws Exception;
//	public abstract TaskIndex createOrUpdateTaskIndex(String taskId);
//	public abstract TaskIndex createOrUpdateTaskIndex(Tasks task);
//	public abstract void activeYNTaskEvent(String taskId, String activeYN) throws Exception;
//	public abstract Map<String, Object> getTaskItems(String taskId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
