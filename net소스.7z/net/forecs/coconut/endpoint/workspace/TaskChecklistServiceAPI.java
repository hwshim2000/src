package net.forecs.coconut.endpoint.workspace;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;

@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class TaskChecklistServiceAPI {
	
	private final ITaskChecklistService taskChecklistService;

	@Inject
	public TaskChecklistServiceAPI(ITaskChecklistService taskChecklistService) {
		this.taskChecklistService = taskChecklistService;
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "listTaskChecklists", path = "tasks/checklists", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<TaskChecklists> listTaskChecklists(
//			@Named(FLD.taskId) String taskId) throws Exception {
//		CommonService.validNamespace(taskId);
//		List<TaskChecklists> list = taskChecklistService.listTaskChecklists(taskId, null);
//		return CollectionResponse.<TaskChecklists>builder().setItems(list).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getTaskChecklists", path = "tasks/checklists/{taskChecklistId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public TaskChecklists getTaskChecklists(@Named(FLD.taskChecklistId) String taskChecklistId) throws UnavailableException {
//		CommonService.validNamespace(taskChecklistId);
//		return taskChecklistService.getTaskChecklists(taskChecklistId);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "insertTaskChecklists", path = "tasks/checklists", httpMethod = HttpMethod.POST)
	@RequiresUser
	public TaskChecklists insertTaskChecklists(TaskChecklists taskchecklist) throws Exception {
		CommonService.validNamespace(taskchecklist.getTaskId());
		return taskChecklistService.insertTaskChecklists(taskchecklist);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskChecklists", path = "tasks/checklists", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public TaskChecklists updateTaskChecklists(TaskChecklists taskchecklist) throws Exception {
		CommonService.validNamespace(taskchecklist);
		return taskChecklistService.updateTaskChecklists(taskchecklist);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeTaskChecklists", path = "tasks/checklists/{taskChecklistId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeTaskChecklists(@Named(FLD.taskChecklistId) String taskChecklistId) throws Exception {
		CommonService.validNamespace(taskChecklistId);
		taskChecklistService.removeTaskChecklists(taskChecklistId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskChecklistAssignee", path = "tasks/checklists/assignee/{taskChecklistId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public TaskChecklists updateTaskChecklistAssignee(@Named(FLD.taskChecklistId) String taskChecklistId,
			@Named(FLD.userId) String userId) throws Exception {
		return taskChecklistService.updateTaskChecklistAssignee(taskChecklistId, userId);
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "recoverTaskChecklists", path = "tasks/checklists/recover/{taskChecklistHistoryId}", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public CollectionResponse<TaskChecklists> recoverTaskChecklists(@Named(FLD.taskId) String taskId, @Named(FLD.taskChecklistHistoryId) String taskChecklistHistoryId) throws Exception {
//		CommonService.validNamespace(taskId);
//		List<TaskChecklists> list = taskChecklistService.recoverHistory(taskId, taskChecklistHistoryId);
//		return CollectionResponse.<TaskChecklists>builder().setItems(list).build();
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "changeOrderChecklits", path = "tasks/checklists/order", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Result changeOrderChecklits(@Named(FLD.checklists) List<String> taskChecklistIds) throws Exception {
//		CommonService.validNamespace(taskChecklistIds.get(0));
//		return new Result(taskChecklistService.changeOrderChecklits(taskChecklistIds));
//	}
	
	@ApiMethod(name = "getMyTODOTaskChecklistsMap", path = "tasks/checklists/todo/my", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Map<String, List<TaskChecklists>> getMyTODOTaskChecklistsMap() throws Exception {
		return taskChecklistService.getMyTODOTaskChecklistsMap();
	}
	@ApiMethod(name = "getTODOTaskChecklists", path = "tasks/checklists/todo", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<TaskChecklists> getTODOTaskChecklists(@Named(FLD.assignee) String assignee) throws Exception {
		return taskChecklistService.getTODOTaskChecklists(assignee);
	}
	
	@Deprecated
	@ApiMethod(name = "resetTODOTaskChecklistsTemporaryAPI", path = "tasks/admin/checklists/todo", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void resetTODOTaskChecklistsTemporaryAPI(@Nullable @Named(FLD.domainName) String domainName, @Named(FLD.accessToken) String accessToken) throws Exception {
		if (StringUtils.isBlank(domainName)) {
			taskChecklistService.resetTODOTaskChecklists();
		} else {
			taskChecklistService.resetTODOTaskChecklists(domainName);
		}
	}
}