package net.forecs.coconut.endpoint.workspace;

import net.forecs.coconut.endpoint.common.ICommonService;


@Deprecated
public interface ITaskCommentService extends ICommonService {
//	public abstract QueryResult<TaskComments> listTaskComments(
//			String cursorString,
//			Integer limit,
//			String taskId) throws Exception;
//	public abstract TaskComments getTaskComments(String taskCommentId)throws Exception;
//	public abstract TaskComments insertTaskComments(String parentTaskCommentId, TaskComments taskcomments) throws Exception;
//	public abstract TaskComments updateTaskComments(TaskComments taskcomments) throws Exception;
//	public abstract void removeTaskComments(String taskCommentId) throws Exception;
//	public abstract int bulkRemoveTaskComments(String taskId) throws Exception;
//	
//	public abstract CommentIndex createOrUpdateTaskCommentIndex(TaskComments taskComment);
//	
//	public abstract Map<String, List<TaskComments>> batchMapTaskComments(EntityManager mgr, List<String> taskIdList) throws Exception;
}
