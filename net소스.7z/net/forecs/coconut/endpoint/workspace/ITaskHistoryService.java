package net.forecs.coconut.endpoint.workspace;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.workspace.TaskHistories;


public interface ITaskHistoryService extends ICommonService {
	public abstract TaskHistories insertTaskHistories(TaskHistories taskHistory) throws Exception;
	public abstract TaskHistories insertTaskHistories(EntityManager mgr, TaskHistories taskHistory) throws Exception;	
	public abstract int bulkRemoveTaskHistories(String taskId) throws Exception;	
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract QueryResult<TaskHistories> listTaskHistories(String cursorString, Integer limit, String taskId) throws Exception;
//	public abstract TaskHistories getTaskHistories(String taskHistoryId);
//	public abstract void removeTaskHistories(String taskHistoryId) throws Exception;
//	public abstract CompareResults compareWikiHistories(String sourceHistoryId,
//			String targetHistoryId, CompareMode compareMode,
//			String insertedColor, String deletedColor);
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}