package net.forecs.coconut.endpoint.workspace;

import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;


public interface ITaskChecklistHistoryService extends ICommonService {
	public abstract QueryResult<TaskChecklistHistories> listTaskChecklistHistories(
			String cursorString,
			Integer limit,
			String taskId) throws Exception;
	public abstract TaskChecklistHistories insertTaskChecklistHistories(TaskChecklistHistories taskchecklisthistories) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract TaskChecklistHistories getTaskChecklistHistories(String taskChecklistHistoryId);
//	public abstract TaskChecklistHistories insertTaskChecklistHistories(EntityManager mgr, TaskChecklistHistories taskchecklisthistories) throws Exception;
//	public abstract TaskChecklistHistories removeTaskChecklistHistories(String taskChecklistHistoryId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
