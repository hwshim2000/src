package net.forecs.coconut.endpoint.workspace;

import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;

import com.google.api.server.spi.response.ConflictException;


public class TaskChecklistHistoryService extends CommonService implements ITaskChecklistHistoryService {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(TaskChecklistHistoryService.class.getName());

	@Override
	public QueryResult<TaskChecklistHistories> listTaskChecklistHistories(
			String cursorString,
			Integer limit,
			String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<TaskChecklistHistories> dsQuery = new DsQuery<>(TaskChecklistHistories.class)
					.eq(FLD.taskId, taskId)
					.sort(FLD.created, SortDirection.DESC)
					.cursor(cursorString)
					.limit(limit);
			
			List<TaskChecklistHistories> taskChecklistHistoryList = dsQuery.execute(mgr);
						
			return new QueryResult<TaskChecklistHistories>(taskChecklistHistoryList, dsQuery.getCursor());
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public TaskChecklistHistories insertTaskChecklistHistories(
			TaskChecklistHistories taskChecklistHistory) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			beginTransaction(mgr);
			taskChecklistHistory = insertTaskChecklistHistories(mgr, taskChecklistHistory);
			commitTransaction(mgr);
			
			//createOrUpdateTaskChecklistHistoryIndex(taskChecklistHistory);

			return taskChecklistHistory;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private TaskChecklistHistories insertTaskChecklistHistories(
			EntityManager mgr,
			TaskChecklistHistories taskchecklisthistories) throws Exception {
		try {
			taskchecklisthistories.setKey(KeyUtil.createTaskChecklistHistoryKey());
			
			if (contains(mgr, TaskChecklistHistories.class, taskchecklisthistories.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(taskchecklisthistories.getTaskChecklistHistoryId()));
			}
			
			doPersist(mgr, taskchecklisthistories);
			
			return taskchecklisthistories;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public TaskChecklistHistories getTaskChecklistHistories(String taskChecklistHistoryId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, TaskChecklistHistories.class, taskChecklistHistoryId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public TaskChecklistHistories removeTaskChecklistHistories(String taskChecklistHistoryId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			doRemoveTransaction(mgr, TaskChecklistHistories.class, taskChecklistHistoryId);
////			try {
////				removeTaskChecklistHistoryIndex(taskChecklistHistoryId);
////			} catch (Exception ex) {}
//			return taskchecklisthistory;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@SuppressWarnings("unused")
//	private int bulkRemoveTaskChecklistHistories(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			TypedQuery<TaskChecklistHistories> query = new QueryBuilder<>(TaskChecklistHistories.class)
//					.addClause(FLD.taskId, taskId)
//					.build(mgr);
//			List<TaskChecklistHistories> taskChecklistHistoryList = queryResults(query);
//			doRemoveTransaction(mgr, taskChecklistHistoryList);
//			return taskChecklistHistoryList.size();
//			
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
	
//	@Override
//	public QueryResult<TaskChecklistHistories> listTaskChecklistHistories(
//			String cursorString,
//			Integer limit,
//			String taskId,
//			QueryOption queryOption) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			TypedQuery<Key> query = new QueryBuilder<>(TaskChecklistHistories.class)
//					.addClause(FLD.taskId, taskId)
//					.addQueryOption(queryOption)
//					.buildKeyOnlyRead(mgr);
//			
//			List<TaskChecklistHistories> taskChecklistHistoryList = new ArrayList<TaskChecklistHistories>();
//			int cursorPosition = QueryBuilder.getCursorPosition(cursorString);
//			
//			do {
//				query.setFirstResult(cursorPosition);
//				if (limit != null) { query.setMaxResults(limit); }
//				
//				List<TaskChecklistHistories> results = queryResults(mgr, TaskChecklistHistories.class, query);
//
//				for (TaskChecklistHistories history : results) {
//					cursorPosition++;
//					
//					taskChecklistHistoryList.add(history);
//					if (limit != null && taskChecklistHistoryList.size() == limit) { break; }
//				}
//				if (limit != null && (results.size() != limit || taskChecklistHistoryList.size() == limit)) { break; }
//			} while (limit != null);
//			
//			cursorString = QueryBuilder.getCursorString(cursorPosition);
//			return new QueryResult<TaskChecklistHistories>(taskChecklistHistoryList, cursorString, limit);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}

}
