package net.forecs.coconut.endpoint.workspace;

import net.forecs.coconut.endpoint.common.CommonService;


@Deprecated
public class TaskCommentService extends CommonService implements ITaskCommentService {
//	private static final Logger LOG = Logger.getLogger(TaskCommentService.class.getName());
//	
//	private IActivityService activityService;
//	private IUserService userService;
//	
//	@Inject
//	public TaskCommentService(IActivityService activityService, IUserService userService) {
//		this.activityService = activityService;
//		this.userService = userService;
//	}
//
//	@Override
//	public QueryResult<TaskComments> listTaskComments(
//			String cursorString,
//			Integer limit,
//			String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			TypedQuery<TaskComments> query = new QueryBuilder<>(TaskComments.class)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.taskId, taskId)
//					.addOrder(FLD.familyId, SortDirection.DESC)
//					.addOrder(FLD.depth, SortDirection.ASC)
//					//.addOrder("created", SortDirection.DESC)
//					.build(mgr);
//
//			Cursor cursor = null;
//			
//			if (StringUtils.isNotBlank(cursorString)) {
//				cursor = Cursor.fromWebSafeString(cursorString);
//				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
//			}
//
//			if (limit != null) {
//				query.setFirstResult(0);
//				query.setMaxResults(limit);
//			}
//
//			List<TaskComments> taskCommentList = query.getResultList();
//			cursor = JPACursorHelper.getCursor(taskCommentList);
//
//			Map<String, Users> usersMap = batchMapTaskCommentUsers(mgr, taskCommentList);
//			for (TaskComments comment : taskCommentList) {
//				comment.setUser(usersMap.get(comment.getCreator())); 
//			}
//			
//			return new QueryResult<TaskComments>(taskCommentList, cursor);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	
//	private Map<String, Users> batchMapTaskCommentUsers(EntityManager mgr, List<TaskComments> taskCommentList) throws Exception {
//		Set<String> userIds = new HashSet<String>();
//		for (TaskComments comment : taskCommentList) {
//			userIds.add(comment.getCreator());
//		}
//		return userService.batchMapUsers(mgr, userIds, false);
//	}
//
//	@Override
//	public Map<String, List<TaskComments>> batchMapTaskComments(EntityManager mgr, List<String> taskIdList) throws Exception {
//		try {
//			Map<String, List<TaskComments>> resultMap = new HashMap<String, List<TaskComments>>();
//			List<TaskComments> results = batchListByField(mgr, TaskComments.class, taskIdList, FLD.taskId);
//			
//			Set<String> userIds = new HashSet<String>();
//			for (TaskComments comment : results) {
//				userIds.add(comment.getCreator());
//			}
//			Map<String, Users> userMap = userService.batchMapUsers(mgr, userIds, false);
//			for (TaskComments comment : results) {
//				comment.setUser(userMap.get(comment.getCreator()));
//				if (!resultMap.containsKey(comment.getTaskId())) { resultMap.put(comment.getTaskId(), new ArrayList<TaskComments>()); }
//				resultMap.get(comment.getTaskId()).add(comment);
//			}
//			return resultMap;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	
//	private List<TaskComments> updateAllDepth(long familyId, int depth) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TypedQuery<TaskComments> query = new QueryBuilder<>(TaskComments.class)
//					.addClause(FLD.familyId, familyId)
//					.addGTClause(FLD.depth, depth, SortDirection.ASC)
//					.build(mgr);
//
//			List<TaskComments> taskCommentList = queryResults(query);
//			for (TaskComments taskComment : taskCommentList) {
//				taskComment.setDepth(taskComment.getDepth()+1);
//			}
//			doMergeTransaction(mgr, taskCommentList);
//			
//			return taskCommentList;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	private boolean hasChildComments(EntityManager mgr, String taskCommentId) throws Exception {
//		try {
//			Key taskCommentKey = KeyFactory.stringToKey(taskCommentId);
//			SimpleQuery<TaskComments> sq = new SimpleQuery<>(mgr, TaskComments.class);
//			sq.where(sq.equal(FLD.parentId, taskCommentKey.getId()));
//			TypedQuery<Long> query = sq.count();
//
//			Long childCount = query.getSingleResult();
//			if (childCount != null && childCount > 0) {
//				return true;
//			} else {
//				return false;
//			}
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//
//	@Override
//	public TaskComments getTaskComments(String taskCommentId) throws Exception{
//		EntityManager mgr = getEntityManager();
//		try {
//			return getTaskComments(mgr, taskCommentId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private TaskComments getTaskComments(EntityManager mgr, String taskCommentId) throws Exception{
//		TaskComments taskcomments = doFind(mgr, TaskComments.class, taskCommentId);
//		taskcomments.setUser(userService.getSimpleUsers(mgr, taskcomments.getCreator()));
//		//valid(TaskComments.class, taskcomments);
//		return taskcomments;
//	}
//
//	@Override
//	public TaskComments insertTaskComments(String parentTaskCommentId, TaskComments taskComment) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			Users loginUser = getCurrentUser();
//			taskComment.setCreator(loginUser.getUserId());
//			
//			Key taskKey = KeyFactory.stringToKey(taskComment.getTaskId());
//			
//			Tasks task = doFind(mgr, Tasks.class, taskKey);
//			Key taskCommentKey = KeyUtil.createTaskCommentKey(taskKey);
//			long familyId = taskCommentKey.getId();
//			
//			if (StringUtils.isEmpty(parentTaskCommentId)) {
//				//taskcomments.setNo(no);
//				taskComment.setFamilyId(familyId);
//				taskComment.setParentId(0);
//				taskComment.setDepth(0);
//				taskComment.setIndent(0);
//			} else {
//				TaskComments parentComments = getTaskComments(mgr, parentTaskCommentId);
//				
//				updateAllDepth(parentComments.getFamilyId(), parentComments.getDepth());
//				//taskcomments.setNo(no);
//				taskComment.setFamilyId(parentComments.getFamilyId());
//				taskComment.setParentId(parentComments.getKey().getId());
//				taskComment.setDepth(parentComments.getDepth()+1);
//				taskComment.setIndent(parentComments.getIndent()+1);
//			}
//			
//			taskComment.setKey(taskCommentKey);
//			taskComment.setBoardId(task.getBoardId());
//			taskComment.setUser(loginUser);
//
//			if (contains(mgr, TaskComments.class, taskComment.getKey())) {
//				throw new ConflictException(
//						ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(
//								TaskComments.class.getSimpleName(),
//								taskComment.getTaskCommentId()));
//			}
//
//			doPersistTransaction(mgr, taskComment);
//
//			try {
//				createOrUpdateTaskCommentIndex(taskComment);
//				
//				Activities activity = activityService.createTaskCommentActivity(taskComment, null, ActivityType.ADDED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return taskComment;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public TaskComments updateTaskComments(TaskComments taskComment) throws Exception {
//		EntityManager mgr = getEntityManager();
//	
//		try {
//			Users loginUser = getCurrentUser();
//			TaskComments originComment = taskComment;
//			valid(taskComment);
//			originComment.setUser(loginUser);
//			
//			doMergeTransaction(mgr, originComment);
//
//			try {
//				createOrUpdateTaskCommentIndex(originComment);
//				
//				Activities activity = activityService.createTaskCommentActivity(originComment, null, ActivityType.UPDATED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return originComment;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public void removeTaskComments(String taskCommentId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Users loginUser = getCurrentUser();
//			
//			TaskComments taskComment = doFind(mgr, TaskComments.class, taskCommentId);
//			valid(taskComment);
//			
//			if (hasChildComments(mgr, taskCommentId)) {
//				taskComment.setDeleted(new Date());
//				taskComment.setDeleteYN(Y);
//				
//				doMergeTransaction(mgr, taskComment);
//			} else {
//				doRemoveTransaction(mgr, taskComment);
//			}
//
//			try {
//				removeTaskCommentIndex(taskCommentId);
//				Activities activity = activityService.createTaskCommentActivity(taskComment, null, ActivityType.DELETED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) {
//				LOG.warning(ex.getMessage());
//			}
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@SuppressWarnings("unused")
//	private void permanentRemoveTaskComments(EntityManager mgr, String taskCommentId) throws Exception {
//		try {
//			TaskComments taskComment = doFind(mgr, TaskComments.class, taskCommentId);
//			permanentRemoveTaskComments(mgr, taskComment);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	private void permanentRemoveTaskComments(EntityManager mgr, TaskComments taskComment) throws Exception {
//		try {
//			doRemoveTransaction(mgr, taskComment);
//			
//			try {
//				removeTaskCommentIndex(taskComment.getTaskCommentId());
//				
//				Users loginUser = getCurrentUser();
//				Activities activity = activityService.createTaskCommentActivity(taskComment, null, ActivityType.DELETED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) {
//				LOG.warning(ex.getMessage());
//			}
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//
//
//	@Override
//	public int bulkRemoveTaskComments(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			int resultCount = 0;
//			
//			TypedQuery<TaskComments> query = new QueryBuilder<>(TaskComments.class)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.archiveYN, null)
//					.addClause(FLD.taskId, taskId)
//					.build(mgr);
//
//			List<TaskComments> taskCommentList = queryResults(query);
//			for (TaskComments taskComment : taskCommentList) {
//				permanentRemoveTaskComments(mgr, taskComment);
//				resultCount++;
//			}
//			
//			return resultCount;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public CommentIndex createOrUpdateTaskCommentIndex(TaskComments taskComment) {
//		try {
//			CommentIndex commentIndex = null;
//			if (taskComment != null) {
//				commentIndex = new CommentIndex(taskComment.getDomainId(), taskComment.getBoardId(), taskComment.getTaskId(), taskComment);
//				SearchManager sm = new SearchManager();
//				sm.createIndex(commentIndex);
//			}
//			return commentIndex;
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//			return null;
//		}
//	}
//	
//	private void removeTaskCommentIndex(String taskCommentId) {
//		try {
//			SearchManager searchManager = new SearchManager();
//			searchManager.deleteDocuments(CommentIndex.class, taskCommentId);
//		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//	}
}
