package net.forecs.coconut.endpoint.workspace;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.query.QueryOption;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklists;


public interface ITaskChecklistService extends ICommonService {
	public abstract List<TaskChecklists> listTaskChecklists(EntityManager mgr, String taskId, QueryOption queryOption) throws Exception;
	public abstract TaskChecklists insertTaskChecklists(TaskChecklists taskchecklists) throws Exception;
	public abstract TaskChecklists insertTaskChecklists(EntityManager mgr, TaskChecklists taskChecklist, Users loginUser) throws Exception;
	public abstract TaskChecklists updateTaskChecklists(TaskChecklists taskchecklists) throws Exception;
	public abstract TaskChecklists removeTaskChecklists(String taskChecklistId) throws Exception;
	public abstract int bulkRemoveTaskChecklist(String taskId) throws Exception;
	public abstract Map<String, List<TaskChecklists>> batchMapTaskChecklists(EntityManager mgr, List<String> taskIdList) throws Exception;
	public abstract Map<String, List<TaskChecklists>> batchMapTaskChecklists(EntityManager mgr, Collection<String> boardIds, List<String> taskIdList) throws Exception;
	public abstract TaskChecklists updateTaskChecklistAssignee(String taskChecklistId, String userId) throws Exception;
	
	public abstract Map<String, List<TaskChecklists>> getMyTODOTaskChecklistsMap() throws Exception;
	public abstract List<TaskChecklists> getTODOTaskChecklists(String assignee) throws Exception;
	
	@Deprecated
	public abstract void resetTODOTaskChecklists(String domainName) throws Exception;
	@Deprecated
	public abstract void resetTODOTaskChecklists() throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract List<TaskChecklists> listTaskChecklists(String taskId, QueryOption queryOption) throws Exception;
//	public abstract List<TaskChecklists> listTaskChecklists(EntityManager mgr, Collection<String> boardIds, List<String> taskIdList, QueryOption queryOption) throws Exception;
//	public abstract List<TaskChecklists> getTaskChecklistsForHistoryList (String taskId) throws Exception;
//	public abstract TaskChecklists getTaskChecklists(String taskChecklistId);
//	public abstract List<TaskChecklists> recoverHistory(String taskId, String taskChecklistHistoryId) throws Exception;
//	public abstract boolean changeOrderChecklits(List<String> taskChecklistIds) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}