package net.forecs.coconut.endpoint.workspace;

import net.forecs.coconut.endpoint.common.ICommonService;


@Deprecated
public interface ITaskTimelineScoreService extends ICommonService {
//	public abstract List<TaskTimelineScores> listTaskTimelineScores(
//			String taskTimelineId,
//			EvaluateType evaluateType) throws Exception;
//	public abstract List<TaskTimelineScores> listTaskTimelineScores(
//			EntityManager mgr,	
//			String taskTimelineId,
//			EvaluateType evaluateType) throws Exception;
//	public abstract TaskTimelineScores insertTaskTimelineScores(TaskTimelineScores tasktimelinescores) throws Exception;
//	public abstract TaskTimelineScores removeTaskTimelineScores(Key taskTimelineScoreKey) throws Exception;
//	public abstract int bulkRemoveTaskTimelineScores(String taskTimelineId) throws Exception;
}
