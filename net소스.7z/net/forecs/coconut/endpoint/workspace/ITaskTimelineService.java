package net.forecs.coconut.endpoint.workspace;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.search.index.TimelineIndex;

public interface ITaskTimelineService extends ICommonService {
	public abstract QueryResult<TaskTimelines> queryTaskTimelines(
			String cursorString,
			Integer limit,
			Collection<String> boardList,
			Collection<String> taskIdList,
			Collection<String> userIdList,
			SortType sortType,
			SortDirection sortDirection
			) throws Exception;
	public abstract QueryResult<TaskTimelines> queryTaskTimelines(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> boardList,
			Collection<String> taskIdList,
			Collection<String> userIdList,
			SortType sortType,
			SortDirection sortDirection
			) throws Exception;
	public abstract TaskTimelines getTaskTimelines(String taskTimelineId)throws Exception;
	public abstract TaskTimelines getTaskTimelines(String domainName, String taskTimelineId) throws Exception;
	public abstract TaskTimelines getParentTaskTimelines(String taskTimelineCommentId) throws Exception;
	public abstract TaskTimelines insertTaskTimelines(TaskTimelines tasktimelines) throws Exception;
	public abstract TaskTimelines insertTaskTimelines(TaskTimelines taskTimeline, Users user) throws Exception;
	public abstract TaskTimelines updateTaskTimelines(TaskTimelines tasktimelines) throws Exception;
	public abstract void removeTaskTimelines(String taskTimelineId) throws Exception;
	public abstract TaskTimelines copyTaskTimelines(String taskTimelineId, String toTaskId) throws Exception;
	
	public abstract TaskTimelines updateTasktimelinesLastCommented(String taskTimelineId, Date lastCommented) throws Exception;
	public abstract Attachments addTaskTimelineAttachment(String taskTimelineId, Attachments attachment) throws Exception;
	public abstract Attachments removeTaskTimelineAttachment(String taskTimelineId, String attachmentId) throws Exception;	
	
	public abstract TimelineIndex createOrUpdateTaskTimelineIndex(TaskTimelines taskTimeline);
	public abstract void setTaskTimelinesDetail(List<TaskTimelines> taskTimelineList) throws Exception;
	
	public abstract Map<String, List<Images>> batchMapTaskTimelineImages(EntityManager mgr, List<TaskTimelines> taskTimelineList) throws Exception;
	public abstract Map<String, List<Attachments>> batchMapTaskTimelineAttachments(EntityManager mgr, List<TaskTimelines> taskTimelineList) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract int bulkRemoveTaskTimelines(String taskId) throws Exception;
//	public abstract List<TaskTimelineScores> listEvaluateTaskTimelines(String taskTimelineId, EvaluateType evaluateType) throws Exception;
//	public abstract boolean isEvaluatedTaskTimeline(String taskTimelineId);
//	public abstract TaskTimelines evaluateTaskTimeline(String taskTimelineId, EvaluateType evaluateType) throws Exception;
//	public abstract TaskTimelines cancelEvaluateTaskTimeline(String taskTimelineId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
