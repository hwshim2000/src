package net.forecs.coconut.endpoint.workspace;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskHistories;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.datastore.Key;

public class TaskHistoryService extends CommonService implements ITaskHistoryService {
//	/** default inserted background color */
//	@Deprecated
//	public final static String WIKI_INSERTED_BACKGROUND_COLOR = "#e6ffe6";
//	/** default deleted background color */
//	@Deprecated
//	public final static String WIKI_DELETED_BACKGROUND_COLOR = "#ffe6e6";
	
	@Override
	public TaskHistories insertTaskHistories(TaskHistories taskHistory) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();
			taskHistory.setCreator(loginUserId);
		
			beginTransaction(mgr);
			insertTaskHistories(mgr, taskHistory);
			commitTransaction(mgr);
			
			return taskHistory;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public TaskHistories insertTaskHistories(EntityManager mgr, TaskHistories taskhistories) throws Exception {
		try {
			Key taskHistoriesKey = KeyUtil.createTaskHistoryKey();
			taskhistories.setKey(taskHistoriesKey);
			
			if (contains(mgr, TaskHistories.class, taskhistories.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(taskhistories.getTaskHistoryId()));
			}
			
			doPersist(mgr, taskhistories);
			
			return taskhistories;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public int bulkRemoveTaskHistories(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			TypedQuery<TaskHistories> query = new QueryBuilder<>(TaskHistories.class)
					.addClause(FLD.taskId, taskId)
					.build(mgr);
			
			List<TaskHistories> taskHistoryList = queryResults(query);
			doRemoveTransaction(mgr, taskHistoryList);
			return taskHistoryList.size();
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public QueryResult<TaskHistories> listTaskHistories(
//			String cursorString,
//			Integer limit,
//			String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			TypedQuery<Key> query = new QueryBuilder<>(TaskHistories.class)
//					.addClause(FLD.taskId, taskId)
//					.addOrder(SortType.created.toString(), SortDirection.DESC)
//					.buildKeyOnlyRead(mgr);
//			
//			List<TaskHistories> taskHistoryList = new ArrayList<TaskHistories>();
//			int cursorPosition = QueryBuilder.getCursorPosition(cursorString);
//			
//			do {
//				query.setFirstResult(cursorPosition);
//				if (limit != null) {
//					query.setMaxResults(limit);
//				}
//				
//				List<TaskHistories> results = queryResults(mgr, TaskHistories.class, query);
//
//				for (TaskHistories history : results) {
//					cursorPosition++;
//					
//					taskHistoryList.add(history);
//					if (limit != null && taskHistoryList.size() == limit) {
//						break;
//					}
//				}
//				if (limit != null && (results.size() != limit || taskHistoryList.size() == limit)) { break; }
//			} while (limit != null);
//			
//			cursorString = QueryBuilder.getCursorString(cursorPosition);
//			
//			return new QueryResult<TaskHistories>(taskHistoryList, cursorString);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public void removeTaskHistories(String taskHistoryId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			doRemoveTransaction(mgr, TaskHistories.class, taskHistoryId);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public CompareResults compareWikiHistories(String sourceHistoryId, String targetHistoryId, CompareMode compareMode, String insertedColor, String deletedColor) {
//		CompareResults compareResult = new CompareResults();
//		
//		TaskHistories sourceHistory = getTaskHistories(sourceHistoryId);
//		TaskHistories targetHistory = getTaskHistories(targetHistoryId);
//		
//		DiffMatchPatch dmp = new DiffMatchPatch();
//
//		String sourceValue = "";
//		String targetValue = "";
//		
//		if (sourceHistory.getDescription() != null && sourceHistory.getDescription().getValue() != null) {
//			sourceValue = sourceHistory.getDescription().getValue();
//		}
//		if (targetHistory.getDescription() != null && targetHistory.getDescription().getValue() != null) {
//			targetValue = targetHistory.getDescription().getValue();
//		}
//		
//		LinkedList<Diff> bothDiffList = dmp.diff_main(sourceValue, targetValue);
//		
//		LinkedList<Diff> sourceDiffList = new LinkedList<Diff>();
//		LinkedList<Diff> targetDiffList = new LinkedList<Diff>();
//		
//		for (Diff diff : bothDiffList) {
//			if (Operation.INSERT.equals(diff.operation)) { targetDiffList.add(diff); }
//			else if (Operation.DELETE.equals(diff.operation)) { sourceDiffList.add(diff); }
//			else {
//				sourceDiffList.add(diff);
//				targetDiffList.add(diff);
//			}
//		}
//		
//		if (StringUtils.isBlank(insertedColor)) { insertedColor = CommonProperty.WIKI_INSERTED_BACKGROUND_COLOR; }
//		if (StringUtils.isBlank(deletedColor)) { deletedColor = CommonProperty.WIKI_DELETED_BACKGROUND_COLOR; }
//		  
//		if (compareMode != null) {
//			if (CompareMode.SEMANTIC.equals(compareMode)) {
//				dmp.diff_cleanupSemantic(bothDiffList);
//				dmp.diff_cleanupSemantic(sourceDiffList);
//				dmp.diff_cleanupSemantic(targetDiffList);
//			} else if (CompareMode.EFFICIENCY.equals(compareMode)) {
//				dmp.diff_cleanupEfficiency(bothDiffList);
//				dmp.diff_cleanupEfficiency(sourceDiffList);
//				dmp.diff_cleanupEfficiency(targetDiffList);
//			}
//		}
//		
//		String bothText = dmp.diff_prettyHtml(bothDiffList, insertedColor, deletedColor);
//		String sourceText = dmp.diff_prettyHtml(sourceDiffList, insertedColor, deletedColor);
//		String targetText = dmp.diff_prettyHtml(targetDiffList, insertedColor, deletedColor);
//
//		String bothHtml = StringEscapeUtils.unescapeHtml(bothText);
//		String sourceHtml = StringEscapeUtils.unescapeHtml(sourceText);
//		String targetHtml = StringEscapeUtils.unescapeHtml(targetText);
//
//		compareResult.setBothHtml(bothHtml);
//		compareResult.setSourceHtml(sourceHtml);
//		compareResult.setTargetHtml(targetHtml);
//		compareResult.setBothText(bothText);
//		compareResult.setSourceText(sourceText);
//		compareResult.setTargetText(targetText);
//		compareResult.setSourceHistory(sourceHistory);
//		compareResult.setTargetHistory(targetHistory);
//		compareResult.setBothDiffList(bothDiffList);
//		compareResult.setSourceDiffList(sourceDiffList);
//		compareResult.setTargetDiffList(targetDiffList);
//		
//		return compareResult;
//	}
//	private TaskHistories getTaskHistories(String taskHistoryId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, TaskHistories.class, taskHistoryId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
