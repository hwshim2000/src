package net.forecs.coconut.endpoint.workspace;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.AuthKind;
import net.forecs.coconut.common.code.AuthStatus;
import net.forecs.coconut.common.code.EditPermission;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.CreateLetterIndexUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IMemberAuthService;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.calendar.ICalendarService;
import net.forecs.coconut.endpoint.channel.ISubscriptionService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.common.IAttachmentService;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.endpoint.domain.IStageService;
import net.forecs.coconut.endpoint.search.ISearchService;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Activities.ActivityData;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskHistories;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.CommentIndex;
import net.forecs.coconut.search.index.TaskIndex;
import net.forecs.coconut.search.index.TimelineIndex;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.BadRequestException;
import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.api.server.spi.response.ServiceUnavailableException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Text;


public class TaskService extends CommonService implements ITaskService {
	private static final Logger LOG = Logger.getLogger(TaskService.class.getName());

	private final IBoardService boardService;
	private final IDomainService domainService;
	private final IMemberAuthService memberAuthService;
	private final IUserService userService;
	private final ISubscriptionService subscriptionService;
	private final IActivityService activityService;
	private final ITaskChecklistService taskChecklistService;
	private final ITaskLabelService taskLabelService;
	private final ITaskHistoryService taskHistoryService;
	private final IAttachmentService attachmentService;
	private final ICalendarService calendarService;
	private final ITaskTimelineService taskTimelineService;
	//private final ITaskTimelineCommentService taskTimelineCommentService;
	private final IStageService stageService;
	private final ISearchService searchService;
	
	public final static String ITEM_ASSIGNED_MEMBERS = "assignedMembers";
	public final static String ITEM_UNASSIGNED_MEMBERS = "unassignedMembers";
	public final static String ITEM_TASK = "task";
	public final static String ITEM_ISSUBSCRIBED = "isSubscribed";
	public final static String ITEM_TIMELINES = "timelines";
	public final static String ITEM_LABELS = "labels";
	private final static String WELCOME_IMAGE_URL = "https://storage.googleapis.com/cocoworks-emoticons/defaults/e-welcome.png";
	private final static String QUERY_INCLUDE_ALL = "__ALL__";
	public final static String QUERY_INCLUDE_MEMBER_IDS = "__MemberIds__";
	public final static String QUERY_INCLUDE_REQUEST_MEMBER = "__RequestMember__";

	@Inject
	public TaskService(IBoardService boardService,
			IDomainService domainService,
			IMemberAuthService memberAuthService,
			IUserService userService,
			ISubscriptionService subscriptionService,
			IActivityService activityService,
			ITaskChecklistService taskChecklistService,
			ITaskLabelService taskLabelService,
			ITaskHistoryService taskHistoryService,
			IAttachmentService attachmentService,
			ICalendarService calendarService,
			ITaskTimelineService taskTimelineService,
			//ITaskTimelineCommentService taskTimelineCommentService,
			IStageService stageService,
			ISearchService searchService
			) {
		this.boardService = boardService;
		this.domainService = domainService;
		this.memberAuthService = memberAuthService;
		this.userService = userService;
		this.subscriptionService = subscriptionService;
		this.activityService = activityService;
		this.taskChecklistService = taskChecklistService;
		this.taskLabelService = taskLabelService;
		this.taskHistoryService = taskHistoryService;
		this.attachmentService = attachmentService;
		this.calendarService = calendarService;
		this.taskTimelineService = taskTimelineService;
		//this.taskTimelineCommentService = taskTimelineCommentService;
		this.stageService = stageService;
		this.searchService = searchService;
	}
	
	@Override
	public List<String> listSubscribedTaskIds(EntityManager mgr, String boardId, String userId) {
		List<String> subscribedTaskIds = new ArrayList<String>();

		try {
			List<Subscriptions> qr = subscriptionService.listTaskSubscriptions(mgr, boardId, userId, false);
			for (Subscriptions s : qr) {
				subscribedTaskIds.add(s.getTaskId());
			}
		} catch (Exception e) {	// Ignored. Empty list will be returned.
		}

		return subscribedTaskIds;
	}
	
	private List<String> listMySubscribedTaskIds(EntityManager mgr, String boardId) {
		Users user = getCurrentUser();
		String userId = user.getObjectId();
		return listSubscribedTaskIds(mgr, boardId, userId);
	}
	
	@Override
	public List<String> listMySubscribedTaskIds(String boardId) {
		EntityManager mgr = getEntityManager();
		try {
			return listMySubscribedTaskIds(mgr, boardId);
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public boolean isMySubscribedTask(String taskId) {
		EntityManager mgr = getEntityManager();
		
		try {
			return isMySubscribedTask(mgr, taskId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private boolean isMySubscribedTask(EntityManager mgr, String taskId) {
		Tasks task = getTasks(mgr, taskId);
		if (task == null) {
			return false;
		}

		Users user = getCurrentUser();
		String userId = user.getObjectId();
		try {
			Subscriptions taskSubscription = subscriptionService.getTaskSubscription(mgr, taskId, userId);
			return (taskSubscription != null);
		} catch (Exception e) {
			LOG.warning("Exception ignored : " + e.getMessage());
			return false;
		}
	}

	private Events getTaskEvent(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();	
		
		try {
			DsQuery<Events> dsQuery = new DsQuery<>(Events.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.taskId, taskId);
					
			return dsQuery.single(mgr);
		} catch (Exception e) {
			return null;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public QueryResult<Tasks> queryUserTasks(
			String cursorString,
			Integer limit,
			String userId,
			String archiveYN,
			SortType sortType,
			SortDirection sortDirection,
			Set<String> includes) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users user = userService.getUsers(userId, false);
			Set<String> boardIds = boardService.getUserBoardIds(mgr, user);
			return queryTasks(mgr, cursorString, limit, boardIds, archiveYN, sortType, sortDirection, includes);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public QueryResult<Tasks> queryTasks(
			String cursorString,
			Integer limit,
			Collection<String> boardIdList,
			String archiveYN,
			SortType sortType,
			SortDirection sortDirection) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Set<String> includes = new HashSet<String>();
			includes.add(QUERY_INCLUDE_ALL);
			return queryTasks(mgr, cursorString, limit, boardIdList, archiveYN, sortType, sortDirection, includes);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public QueryResult<Tasks> queryTasks(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> boardIdList,
			String archiveYN,
			SortType sortType,
			SortDirection sortDirection) throws Exception {
		Set<String> includes = new HashSet<String>();
		includes.add(QUERY_INCLUDE_ALL);
		return queryTasks(mgr, cursorString, limit, boardIdList, archiveYN, sortType, sortDirection, includes);
	}
	
	private QueryResult<Tasks> queryTasks(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> boardIdList,
			String archiveYN,
			SortType sortType,
			SortDirection sortDirection,
			Set<String> includes) throws Exception {
		try {
			MemcacheManager<Tasks, List<Tasks>> mm = new MemcacheManager<>(Tasks.class, MemcacheManager.keySet(boardIdList));
			String memcacheKey = mm.createMemcacheKey(cursorString, limit, boardIdList, archiveYN, sortType, sortDirection, includes);
//			String memcacheKey = mm.createMemcacheKey(boardIdList, archiveYN);
			List<Tasks> taskList = mm.getMemcache(memcacheKey);
			
			if (taskList == null) {
				Set<String> boardIdSet = null;
				
				if (boardIdList != null && boardIdList.size() > CommonProperty.SUBQUERY_PARAM_COUNT) {
					boardIdSet = new HashSet<String>();
					for (String boardId : boardIdList) { boardIdSet.add(boardId); }
					boardIdList = null;
				}
				
				DsQuery<Tasks> dsQuery = new DsQuery<>(Tasks.class)
						.eq(FLD.deleteYN, N)
						.in(FLD.boardId, boardIdList)
						.eq(FLD.archiveYN, archiveYN == null ? N : archiveYN)
						.cursor(cursorString)
						.limit(limit);
				 
				int bulkFetchAmount = 1;	// 검색 속도를 높이기 위해 한꺼번에 많은 양을 가져와서 해당되는 값들을 필터링하기 위해, 즉 , limit보다  bulkFetchAmount배 많이 가져온뒤에 필터링
				if (boardIdSet != null) { bulkFetchAmount = 5; } 
				
				do {
					dsQuery.nextFetch(mgr, bulkFetchAmount++);
					while(dsQuery.hasEntity()) {
						Tasks task = dsQuery.nextEntity();
						if (boardIdSet != null && !boardIdSet.contains(task.getBoardId())) { continue; }
						dsQuery.addResult(task);
					}
				} while (dsQuery.hasNextFetch());
				
				cursorString = dsQuery.getCursor();
				taskList = dsQuery.getResults();
				mm.setMemcache(memcacheKey, taskList, cursorString);
			} else {
				cursorString = mm.getCursorString(memcacheKey);
			}
		
			taskList = getDetailsForQuery(mgr, boardIdList, taskList, includes);
			putStageObject(taskList);
			
			return new QueryResult<Tasks>(taskList, cursorString);
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public List<String> listMyTaskIds(Collection<String> boardIdList) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return listMyTaskIds(mgr, boardIdList);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<String> listMyTaskIds(EntityManager mgr, Collection<String> boardIdList) throws Exception {
		Users loginUser = getCurrentUser();
		return listMyTaskIds(mgr, loginUser, boardIdList);
	}
	@Override
	public List<String> listMyTaskIds(EntityManager mgr, String userId , Collection<String> boardIdList) throws Exception {
		Users user = userService.getUsers(mgr, userId, false);
		return listMyTaskIds(mgr, user, boardIdList);
	}
	@Override
	public List<String> listMyTaskIds(EntityManager mgr, Users user, Collection<String> boardIdList) throws Exception {
		List<String> myTaskIds = new ArrayList<String>();
		
		if (user.isAdmin()) {	// Admin has super authority.
			List<Tasks> taskList = null;
			QueryResult<Tasks> taskResults = queryTasks(mgr, null, null, boardIdList, N, null, null, null);
			
			taskList = taskResults.getResultList();
			if (taskList != null) {
				for (Tasks task : taskList) {
					if (isValid(task)) {
						myTaskIds.add(task.getTaskId());
					}
				}
			}
		} else if (user.isSuper()) {
			List<Tasks> taskList = null;
			QueryResult<Tasks> taskResults = queryTasks(mgr, null, null, boardIdList, N, null, null, null);
			
			//----------------------------------------------------------------------------------------------
			// 실제로 공개되지 않은 tasks가 내가 속한 태스크가 아닌것만 추출
			List<String> assignedTaskIds = listUserTaskIds(mgr, boardIdList, user.getUserId());
			List<String> closedTaskIds = listCloseTaskIds(mgr, boardIdList);
			for (String taskId : assignedTaskIds) {
				if (closedTaskIds.contains(taskId)) { closedTaskIds.remove(taskId); }
			}
			//----------------------------------------------------------------------------------------------
			
			// 전체 태스크에서 공개되지 않은 태스크는 제외시킴
			taskList = taskResults.getResultList();
			if (taskList != null) {
				for (Tasks task : taskList) {
					if (!task.getOwner().equals(user.getUserId()) && closedTaskIds.contains(task.getTaskId())) { continue; }
					if (isValid(task)) { myTaskIds.add(task.getTaskId()); }
				}
			}
		} else {
			List<String> assignedTaskIds = listUserTaskIds(mgr, boardIdList, user.getUserId());
			//--> hyeunwoo.shim 2015-12-24 : subscribed task도 포함시킬려고 했으나, 공개 Task를 가져온것만으로도 해결되기때문에 고려대상에서 제외
			// 비공개의 경우 subscription을 해제하기때문에 별도로 가져와도 의미가 없음.
			//<--
			List<String> validTaskIds = listValidTaskIds(mgr, assignedTaskIds);
			
			myTaskIds.addAll(validTaskIds);
			List<String> publicTaskIds = listPublicTaskIds(mgr, boardIdList);
			
			for (String taskId : publicTaskIds) {
				if (myTaskIds.contains(taskId)) { continue; }
				myTaskIds.add(taskId);
			}
		}
		
		return myTaskIds;
	}
	
	private List<String> listUserTaskIds(EntityManager mgr, Collection<String> boardIdList, String userId) throws Exception {
		List<MemberAuths> memberAuthList = memberAuthService.listMemberAuths(mgr, boardIdList, null, AuthKind.TASKS, null, AuthStatus.ACTIVE, userId, false);
		
		List<String> taskIdList = new ArrayList<String>();
		for (MemberAuths memberAuth : memberAuthList) {
			taskIdList.add(memberAuth.getKindId());
		}
		return taskIdList;
	}
	
	@Override
	public List<String> listUserTaskIds(List<String> boardIdList, List<String> userIdList) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			if (userIdList != null && userIdList.size() == 1) {
				return listUserTaskIds(mgr, boardIdList, userIdList.get(0));
			} else {
				return memberAuthService.batchMapUserTaskIds(mgr, boardIdList, userIdList);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private List<String> listValidTaskIds(EntityManager mgr, List<String> taskIdList) throws Exception {
		List<String> validTaskIds = new ArrayList<String>();
		List<Tasks> taskList = batchListTasks(mgr, taskIdList);
		for (Tasks task : taskList) {
			validTaskIds.add(task.getTaskId());
		}
		return validTaskIds;
	}
	private List<Tasks> batchListTasks(EntityManager mgr, List<String> taskIdList) throws Exception {
		// 이 과정에서 archive되었거나 삭제된 데이터는 걸러진다.
		return batchListByKey(mgr, Tasks.class, taskIdList);
	}
	
	private List<String> listPublicTaskIds(EntityManager mgr, Collection<String> boardIdList) throws Exception {
		List<String> taskIdList = new ArrayList<String>();
		List<Tasks> taskList = listTasks(mgr, boardIdList, true);
		for (Tasks task : taskList) {
			taskIdList.add(task.getTaskId());
		}
		return taskIdList;
	}
	
	private List<String> listCloseTaskIds(EntityManager mgr, Collection<String> boardIdList) throws Exception {
		List<String> taskIdList = new ArrayList<String>();
		List<Tasks> taskList = listTasks(mgr, boardIdList, false);
		for (Tasks task : taskList) {
			taskIdList.add(task.getTaskId());
		}
		return taskIdList;
	}
	
	private List<Tasks> listTasks(
			EntityManager mgr,
			Collection<String> boardIdList,
			boolean isPublic) throws Exception {

		try {
			MemcacheManager<Tasks, List<Tasks>> mm = new MemcacheManager<>(Tasks.class, MemcacheManager.keySet(boardIdList));
			String memcacheKey = mm.createMemcacheKey(isPublic?"public":"close", boardIdList);
			List<Tasks> taskList = mm.getMemcache(memcacheKey);
			
			if (taskList == null) {
				taskList = new ArrayList<Tasks>();
				Set<String> boardIdSet = null;

				if (boardIdList != null && boardIdList.size() > CommonProperty.SUBQUERY_PARAM_COUNT) {
					boardIdSet = new HashSet<String>();
					boardIdSet.addAll(boardIdList);
					boardIdList = null;
				}
				
				DsQuery<Tasks> dsQuery = new DsQuery<>(Tasks.class)
						.eq(FLD.deleteYN, N)
						.eq(FLD.archiveYN, N)
						.in(FLD.boardId, boardIdList);
		
				List<Tasks> results  = dsQuery.execute(mgr);		
			
				for (Tasks a : results) {
					if (boardIdSet != null && !boardIdSet.contains(a.getBoardId())) { continue; }
					if (isPublic) {
						if (Y.equals(a.getCloseYN())) { continue; }
					} else {
						if (N.equals(a.getCloseYN())) { continue; }
					}
					
					taskList.add(a);
				}
				mm.setMemcache(memcacheKey, taskList);
			}
		
			return taskList;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Map<String, Tasks> allTaskMap(EntityManager mgr) throws Exception {
		Map<String, Tasks> taskMap = new HashMap<String, Tasks>();
		List<Tasks> tasks = listAllTasks(mgr);
		for (Tasks task : tasks) {
			taskMap.put(task.getTaskId(), task);
		}
		return taskMap;
	}
	private List<Tasks> listAllTasks(EntityManager mgr) throws Exception {
		try {
			DsQuery<Tasks> dsQuery = new DsQuery<>(Tasks.class).eq(FLD.deleteYN, null);
			return dsQuery.execute(mgr);		
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public List<Users> listTasksMembers(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<MemberAuths> memberAuthList = memberAuthService.listMemberAuths(mgr, null, null, AuthKind.TASKS, taskId, AuthStatus.ACTIVE, null, true);
			
			List<Users> memberList = new ArrayList<Users>();
			for (MemberAuths memberAuth : memberAuthList) {
				memberList.add(memberAuth.getUser());
			}
			return memberList;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<Users> listTasksUnassignedMembers(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<MemberAuths> memberAuthList = memberAuthService.listMemberAuths(mgr, null, null, AuthKind.TASKS, taskId, AuthStatus.INACTIVE, null, true);
			
			List<Users> memberList = new ArrayList<Users>();
			for (MemberAuths memberAuth : memberAuthList) {
				memberList.add(memberAuth.getUser());
			}
			return memberList;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks getTasksDetail(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getTasksDetail(mgr, taskId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Tasks getTasksDetail(EntityManager mgr, String taskId) throws Exception {
		Tasks task = getTasks(mgr, taskId);
		return getDetail(mgr, task);
	}

	private Tasks getTasks(String taskId) {
		EntityManager mgr = getEntityManager();
		try {
			return getTasks(mgr, taskId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Tasks getTasks(String domainName, String taskId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			return getTasks(taskId);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public Tasks getTasks(EntityManager mgr, String taskId) {
		Tasks task = doFind(mgr, Tasks.class, taskId);
		if (task != null) { task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage())); }
		
		return task;
	}
	
	private Tasks getDetail(EntityManager mgr, Tasks task) {
		return getDetailListForTask(mgr, task);
	}

	private void putStageObject(List<Tasks> taskList) {
		try {
			Map<String, Stages> stageMap = stageService.stageMapByTaskStageCode();
			for (Tasks task : taskList) {
				task.setStage(stageMap.get(task.getTaskStage()));
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	private List<Tasks> getDetailsForQuery(EntityManager mgr, Collection<String> boardIds, List<Tasks> taskList, Set<String> includes) {
		if (taskList == null || taskList.size() == 0 || includes == null) { return taskList; }
	
		try {
			List<String> taskIdList = new ArrayList<String>();
			for (Tasks task : taskList) { taskIdList.add(task.getTaskId()); }
			
			Map<String, List<TaskChecklists>> checklistsMap = null;
			Map<String, List<TaskLabels>> labelsMap = null;
			Map<String, List<Users>> usersMap = null;
			Map<String, List<Attachments>> attachmentsMap = null;
			Map<String, List<Users>> requestUsersMap = null;
			Map<String, List<String>> memberIdsMap = null;
			
			if (includes.contains(QUERY_INCLUDE_ALL) || includes.contains(TaskChecklists.class.getSimpleName())) {
				checklistsMap = taskChecklistService.batchMapTaskChecklists(mgr, boardIds, taskIdList);
			}
			if (includes.contains(QUERY_INCLUDE_ALL) || includes.contains(TaskLabels.class.getSimpleName())) {
				labelsMap = taskLabelService.batchMapChildTaskLabels(mgr, taskIdList);
			}
			if (includes.contains(QUERY_INCLUDE_ALL) || includes.contains(MemberAuths.class.getSimpleName())) {
				usersMap = memberAuthService.batchMapTaskMembers(mgr, boardIds, taskIdList);
			}
			if (includes.contains(QUERY_INCLUDE_ALL) || includes.contains(Attachments.class.getSimpleName())) {
				attachmentsMap = attachmentService.batchMapChildAttachments(mgr, taskIdList);
			}
			if (includes.contains(QUERY_INCLUDE_ALL) || includes.contains(QUERY_INCLUDE_REQUEST_MEMBER)) {
				requestUsersMap = batchMapRequestMembers(mgr, taskList);
			}
			if (includes.contains(QUERY_INCLUDE_MEMBER_IDS)) {
				memberIdsMap = memberAuthService.batchMapTaskMemberIds(mgr, boardIds, taskIdList);
			}
			
			for (Tasks task : taskList) {
				if (checklistsMap != null) { task.setChecklists(checklistsMap.get(task.getTaskId())); }
				if (labelsMap != null) { task.setLabels(labelsMap.get(task.getTaskId())); }
				if (usersMap != null) { task.setMembers(usersMap.get(task.getTaskId())); }
				if (attachmentsMap != null) { task.setAttachments(attachmentsMap.get(task.getTaskId())); }
				if (requestUsersMap != null) { task.setRequestMembers(requestUsersMap.get(task.getTaskId())); }
				if (memberIdsMap != null) { task.setMemberIds(memberIdsMap.get(task.getTaskId())); }
			}
			
			return taskList;
		} catch (Exception ex) {
			LOG.warning("[getDetailListForQuery] : "+ex.getMessage());
			return taskList;
		}
	}
	
	private Tasks getDetailListForTask(EntityManager mgr, Tasks task) {
		if (task == null) { return null; }
		try {
			List<String> taskIdList = new ArrayList<String>();
			taskIdList.add(task.getTaskId());
			
			Map<String, List<TaskChecklists>> checklistsMap = taskChecklistService.batchMapTaskChecklists(mgr, taskIdList);
			Map<String, List<TaskLabels>> labelsMap = taskLabelService.batchMapChildTaskLabels(mgr, taskIdList);
			Map<String, List<Users>> usersMap = memberAuthService.batchMapTaskMembers(mgr, taskIdList);
			Map<String, List<Attachments>> attachmentsMap = attachmentService.batchMapChildAttachments(mgr, taskIdList);
			Map<String, Users> requestMembersMap = userService.batchMapUsers(mgr, task.getMemberRequests(), true);
			
			task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
			task.setChecklists(checklistsMap.get(task.getTaskId()));
			task.setLabels(labelsMap.get(task.getTaskId()));
			task.setMembers(usersMap.get(task.getTaskId()));
			task.setAttachments(attachmentsMap.get(task.getTaskId()));
			task.setRequestMembers(new ArrayList<Users>(requestMembersMap.values()));
			
			return task;
		} catch (Exception ex) {
			LOG.warning("[getDetailListForTask] : "+ex.getMessage());
			return task;
		}
	}
	
	private Map<String, List<Users>> batchMapRequestMembers(EntityManager mgr, List<Tasks> taskList) throws Exception {
		try {
			Map<String, List<Users>> resultMap = new HashMap<String, List<Users>>();
			List<String> requestLists = new ArrayList<String>();
			
			for (Tasks task : taskList) {
				requestLists.addAll(task.getMemberRequests());
			}
			
			Map<String, Users> requestMembersMap = userService.batchMapUsers(mgr, requestLists, true);
			for (Tasks task : taskList) {
				if (!resultMap.containsKey(task.getTaskId())) {
					resultMap.put(task.getTaskId(), new ArrayList<Users>());
				}
				for (String requestUserId : task.getMemberRequests()) {
					resultMap.get(task.getTaskId()).add(requestMembersMap.get(requestUserId));
				}
			}
			
			return resultMap;
		} catch (Exception ex) {
			throw ex;
		}
	}

	/**
	 * 아직 미완성 - 현재는 Task만 복사
	 * 새로 생성된 targetTaskId로 
	 *	 Alarm..... 
	 *	 Members
	 *	 Subscription
	 *	 Labels
	 *....
	 * @param tasks
	 * @return
	 * @throws Exception
	 */
	
	@Override
	public Tasks copyTask(String taskId, String toBoardId, String toTaskStage) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks originTask = getTasksDetail(mgr, taskId);
			String fromBoardId = originTask.getBoardId();
			boolean isSameBoard = StringUtils.equals(fromBoardId, toBoardId);

			Tasks targetTask = new Tasks();
			
			CopyUtil.copy(targetTask, originTask);
			
			Stages fromStage = originTask.getStage();
			Stages toStage = doFind(mgr, Stages.class, KeyUtil.createStageKey(toTaskStage));
			
			targetTask.setKey(KeyUtil.createTaskKey());
			targetTask.setBoardId(toBoardId);
			targetTask.setTaskStage(toTaskStage);
			targetTask.setRequestMembers(null);
			targetTask.setMemberRequests(null);
			//targetTask.setAttachments(null);
			
			targetTask.setTitle("[복사본]"+targetTask.getTitle());
			
			doPersistTransaction(mgr, targetTask);

			try {
				targetTask.setStage(toStage);

			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			// 실제로는 Board에 해당 사용자가 없으면 등록
			
			copyMemberList(mgr, targetTask, isSameBoard);
//			//searchService.moveBoardOfTaskAttachments(taskId, toBoardId);
			copyTaskLabels(mgr, targetTask, isSameBoard);
//			// Checklists 이동
			copyTaskChecklists(mgr, targetTask);
			updateTaskAttachments(targetTask);
			
			try {
				createOrUpdateTaskIndex(mgr, targetTask);
				Users loginUser = getCurrentUser();
				fromStage.setBoardId(fromBoardId);
				toStage.setBoardId(toBoardId);
				ActivityData activityData = new ActivityData(fromStage, toStage);
				activityService.insertActivities(activityService.createTaskActivity(targetTask, activityData, ActivityType.COPIED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			return targetTask;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void copyMemberList(EntityManager mgr, Tasks task, boolean isSameBoard) throws Exception {
		try {
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();
			
			Domains domain = domainService.getDomains(mgr, task.getDomainId());
			Boards board = boardService.getBoards(mgr, task.getBoardId());
			valid(domain);
			valid(board);
			valid(task);
		
			List<String> userIds = new ArrayList<String>();
			for (Users user : task.getMembers()) { userIds.add(user.getUserId()); }
			
			if (!isSameBoard) { boardService.assignMemberList(task.getBoardId(), userIds); }
			
			for (Users user : task.getMembers()) {
				if (!isValid(user)) { continue; }
				
				MemberAuths memberAuth = new MemberAuths(task.getDomainId()
						, task.getBoardId()
						, AuthKind.TASKS
						, task.getTaskId()
						, user.getUserId()
						, loginUserId
						, Auth.MEMBER
						, AuthStatus.ACTIVE);
				
				memberAuth.setKey(KeyUtil.createMemberAuthKey(task.getTaskId(), user.getUserId()));
				memberAuth.setUser(user);
				
				beginTransaction(mgr);
				if (doFind(mgr, MemberAuths.class, memberAuth.getKey()) == null) {
					memberAuthService.insertMemberAuths(mgr, memberAuth);
					Subscriptions subscription = new Subscriptions(task.getDomainId(), task.getBoardId(), task.getTaskId(), user.getUserId(), loginUserId);
					subscriptionService.insertSubscriptions(mgr, subscription);
				}
				
				commitTransaction(mgr);
			}
		} catch (Exception ex) {
			throw ex;
		}
	}
	private List<TaskLabels> copyTaskLabels(EntityManager mgr, Tasks task, boolean isSameBoard) throws Exception {
		try {
			if (!isSameBoard) {
				List<TaskLabels> oldLabels = task.getLabels();
				List<TaskLabels> newLabels = new ArrayList<TaskLabels>();
				List<TaskLabels> toBoardLabels = taskLabelService.listTaskLabels(mgr, task.getBoardId());
					
				for (TaskLabels oldLabel : oldLabels) {
					TaskLabels newLabel = getTaskLabelByName(toBoardLabels, oldLabel.getLabel());
					if (newLabel == null) {
						newLabel = new TaskLabels();
							
						newLabel.setBoardId(task.getBoardId());
						newLabel.setColor(oldLabel.getColor());
						newLabel.setLabel(oldLabel.getLabel());
						newLabel.setCreator(task.getCreator());
						newLabel.setKey(KeyUtil.createTaskLabelKey(newLabel));
						
						doPersistTransaction(mgr, newLabel);
					}
					
					if (newLabel != null) { newLabels.add(newLabel); }
				}
				task.setLabels(newLabels);
			}
			updateTaskLabelList(task);

			return task.getLabels();
		} catch (Exception ex) {
			throw ex;
		}
	}
	private List<TaskChecklists> copyTaskChecklists(EntityManager mgr, Tasks task) throws Exception {
		try {
			List<TaskChecklists> checklists = new ArrayList<TaskChecklists>();
			
			for (TaskChecklists oldChecklist : task.getChecklists()) {
				TaskChecklists newChecklist = new TaskChecklists();
				CopyUtil.copy(newChecklist, oldChecklist);
				
				newChecklist.setKey(KeyUtil.createTaskChecklistKey());
				newChecklist.setTaskId(task.getTaskId());
				newChecklist.setBoardId(task.getBoardId());
				newChecklist.setCheckYN(N);
				
				doPersistTransaction(mgr, newChecklist);
			}
			task.setChecklists(checklists);
			return checklists;
		} catch (Exception ex) {
			throw ex;
		}
	}
	@SuppressWarnings("unused")
	private Tasks copyTasks(Tasks tasks) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			
			Tasks originTask = getTasksDetail(mgr, tasks.getTaskId());
			valid(originTask);
			Tasks targetTask = new Tasks();
			
			CopyUtil.copy(targetTask, originTask);
			targetTask.setKey(null);
			targetTask.setAttachments(null);
			targetTask.setCreator(loginUser.getUserId());
			targetTask.setCreated(new Date());
			targetTask.setOwner(loginUser.getUserId());
			
			targetTask = insertTasks(mgr, targetTask);

			for (Users user : originTask.getMembers()) {
				// Member중 Copy Owner는 제외 (Owner는 creat를 하면서 발생)
				if (!user.getUserId().equals(loginUser.getUserId())) {
					assignMember(targetTask.getTaskId(), user.getUserId(), Auth.MEMBER);
					Thread.sleep(1);
				}
			}
			
			createOrUpdateTaskIndex(mgr, targetTask);
			
			// TODO
			// 키 제거외에 필요한 Copy 대상들 복사
			// 새로 생성된 targetTaskId로 
			// Alarm..... 
			// 기타 등등

			return targetTask;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks insertTasks(Tasks task) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return insertTasks(mgr, task);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Tasks insertTasks(EntityManager mgr, Tasks task) throws Exception {
		//UsageService.validUsage(task);
		String boardId = task.getBoardId();
		//String tasklistId = task.getTasklistId();
		String title = task.getTitle();
		if (StringUtils.isEmpty(boardId) /*|| StringUtils.isEmpty(tasklistId)*/ || StringUtils.isEmpty(title)) {
			throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage(Tasks.class));
		}

		try {
			Users loginUser = getCurrentUser();
			
			Boards board = boardService.getBoards(mgr, boardId);
			valid(board);
			task.setDomainId(board.getDomainId());
			
			List<Users> memberList = task.getMembers();
			List<Activities> activityList = new ArrayList<Activities>();
			
			task.setCreator(loginUser.getUserId());
			task.setOwner(loginUser.getUserId());
			task.setKey(KeyUtil.createTaskKey());

			if (contains(mgr, Tasks.class, task.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Tasks.class, task.getTaskId()));
			}

			MemberAuths memberAuth = new MemberAuths(task.getDomainId(),
					task.getBoardId(), AuthKind.TASKS, task.getTaskId(), task.getCreator(), task.getCreator(),
					Auth.MEMBER,
					AuthStatus.ACTIVE);
			memberAuth.setKey(KeyUtil.createMemberAuthKey(task.getTaskId(), loginUser.getUserId()));
			
			beginTransaction(mgr);
			memberAuth = memberAuthService.insertMemberAuths(mgr, memberAuth);
			subscriptionService.insertSubscriptions(mgr,
					new Subscriptions(task.getDomainId(), task.getBoardId(), task.getTaskId(), task.getCreator(), task.getCreator()));
			activityList.add(activityService.createTaskActivity(task, null, ActivityType.ADDED, loginUser));
			activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.SUBSCRIBE, loginUser));
			doPersist(mgr, task);
			commitTransaction(mgr);

			try {
				if (memberList.size() > 0) {
					List<String> userIdList = new ArrayList<String>();
					for (Users member : memberList) { userIdList.add(member.getUserId()); }
					assignMemberList(task.getTaskId(), userIdList, Auth.MEMBER);
				}
				task.getMembers().add(loginUser);
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				updateTaskLabelList(task);
				updateTaskAttachments(task);
				batchInsertTaskChecklists(task, loginUser);
			} catch (Exception ex) {
				LOG.info("[Merge task error.]" + ex.getLocalizedMessage());
			}
			
			try {
				createOrUpdateTaskIndex(mgr, task);
				
				activityList = activityService.insertActivities(activityList);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			//UsageService.increaseUsage(task);
			return task;
		} catch (Exception ex) {
			throw ex;
		}
	}

	private void updateTaskLabelList(Tasks task) throws Exception {
		if (task.getLabels() == null) { return; }
		String taskId = task.getTaskId();
		List<String> taskLabelIds = new ArrayList<String>();
		for (TaskLabels taskLabel : task.getLabels()) {
			taskLabelIds.add(taskLabel.getTaskLabelId());
		}
		List<TaskLabels> taskLabels = taskLabelService.updateTaskLabelsTagged(taskId, taskLabelIds);
		task.setLabels(taskLabels);
	}

	private void updateTaskAttachments(Tasks task) throws Exception {
		String taskId = task.getTaskId();
		List<Attachments> attachments = task.getAttachments();
		attachmentService.updateChildAttachments(taskId, attachments);
	}
	
	public void batchInsertTaskChecklists(Tasks task, Users loginUser) throws Exception {
		if (task.getChecklists() == null) return;
		EntityManager mgr = getEntityManager();
		try {
			List<TaskChecklists> results = new ArrayList<TaskChecklists>();
			 
			for (TaskChecklists checklist : task.getChecklists()) {
				checklist.setDomainId(task.getDomainId());
				checklist.setBoardId(task.getBoardId());
				checklist.setTaskId(task.getTaskId());
				checklist.setCheckYN(N);
				
				checklist = taskChecklistService.insertTaskChecklists(mgr, checklist, loginUser);
				results.add(checklist);
			}
			task.setChecklists(results);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private void removeTaskEvent(Tasks task) throws Exception {
		try {
			Events taskEvent = getTaskEvent(task.getTaskId());
			
			if (taskEvent != null) {
				calendarService.removeEvents(taskEvent.getEventId());
			}
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public Users changeOwnership(String taskId, String targetUserId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			Tasks task = getTasks(mgr, taskId);

			Domains domain = domainService.getDomains(mgr, task.getDomainId());
			Boards board = boardService.getBoards(mgr, task.getBoardId());
			Users targetUser = userService.getUsers(mgr, targetUserId, false);

			valid(domain);
			valid(board);
			valid(task);
			valid(targetUser);

			MemberAuths targetMemberAuth = memberAuthService.getMemberAuths(mgr, taskId, targetUserId);

			if (targetMemberAuth == null) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Member not found."));
			}

			task.setOwner(targetUser.getUserId());
			
			doMergeTransaction(mgr, task);

			try {
				createOrUpdateTaskIndex(mgr, taskId);
				activityService.insertActivities(activityService.createTaskActivity(task, targetUser,
						ActivityType.CHANGED_OWNERSHIP, loginUser));
			} catch (Exception e) {	// Ignored. Not a critical part of application.
			}
			
			return targetMemberAuth.getUser();
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Users assignMember(String taskId, String userId, Auth auth) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();
			
			List<Activities> activityList = new ArrayList<Activities>();
			
			Tasks task = getTasks(mgr, taskId);
			Domains domain = domainService.getDomains(mgr, task.getDomainId());
			Boards board = boardService.getBoards(mgr, task.getBoardId());
			
			Users user = userService.getUsers(mgr, userId, true);
			
			valid(domain);
			valid(board);
			valid(task);
			valid(user);
			
			MemberAuths memberAuth = new MemberAuths(task.getDomainId()
					, task.getBoardId()
					, AuthKind.TASKS
					, taskId
					, userId
					, loginUserId
					, auth==null?Auth.MEMBER:auth
					, AuthStatus.ACTIVE);
			
			memberAuth.setKey(KeyUtil.createMemberAuthKey(task.getTaskId(), user.getUserId()));
			memberAuth.setUser(user);
			
			beginTransaction(mgr);
			if (doFind(mgr, MemberAuths.class, memberAuth.getKey()) != null) {
				memberAuthService.reassignMemberAuths(mgr, memberAuth);				
			} else {
				memberAuthService.insertMemberAuths(mgr, memberAuth);
			}
			Subscriptions subscription = new Subscriptions(task.getDomainId(), task.getBoardId(), task.getTaskId(), user.getUserId(), loginUserId);
			subscription = subscriptionService.insertSubscriptions(mgr, subscription);
			
			List<String> memberRequests = task.getMemberRequests();
			if (memberRequests.contains(userId)) {
				memberRequests.remove(userId);
				task.setMemberRequests(memberRequests);
				doMerge(mgr, task);
			}
			
			commitTransaction(mgr);
			
			activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.ASSIGNED, loginUser));
			if (subscription != null) {
				activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.SUBSCRIBE, loginUser));
			}
			
			try {
				createOrUpdateTaskIndex(mgr, taskId);
				activityList = activityService.insertActivities(activityList);
				insertWelcomeTasktimeline(taskId, user);
			} catch (Exception ex) { LOG.warning(ex.getMessage());}
			
			return (memberAuth != null) ? memberAuth.getUser() : null;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public List<Users> assignMemberList(String taskId, List<String> userIdList, Auth auth) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			List<Users> memberList = new ArrayList<Users>();
			List<MemberAuths> memberAuthList = new ArrayList<MemberAuths>();
			List<Activities> activityList = new ArrayList<Activities>();
			List<Subscriptions> subscriptionList = new ArrayList<Subscriptions>();
			
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();
			
			Tasks task = getTasks(mgr, taskId);
			Domains domain = domainService.getDomains(mgr, task.getDomainId());
			Boards board = boardService.getBoards(mgr, task.getBoardId());
			valid(domain);
			valid(board);
			valid(task);
		
			Map<String, Users> usersMap = userService.batchMapUsers(mgr, userIdList, true);
			List<String> memberRequests = new ArrayList<String>(task.getMemberRequests());
			
			for (Users user : usersMap.values()) {
				//Users user = userService.getUsers(userId);
				if (!isValid(user)) { memberList.add(user); continue; }
				
				MemberAuths memberAuth = new MemberAuths(task.getDomainId()
						, task.getBoardId()
						, AuthKind.TASKS
						, taskId
						, user.getUserId()
						, loginUserId
						, auth==null?Auth.MEMBER:auth
						, AuthStatus.ACTIVE);
				
				memberAuth.setKey(KeyUtil.createMemberAuthKey(task.getTaskId(), user.getUserId()));
				memberAuth.setUser(user);
				
				beginTransaction(mgr);
				if (doFind(mgr, MemberAuths.class, memberAuth.getKey()) != null) {
					memberAuthService.reassignMemberAuths(mgr, memberAuth);
				} else {
					memberAuthService.insertMemberAuths(mgr, memberAuth);
				}
				Subscriptions subscription = new Subscriptions(task.getDomainId(), task.getBoardId(), task.getTaskId(), user.getUserId(), loginUserId);
				subscription = subscriptionService.insertSubscriptions(mgr, subscription);
				
				if (memberRequests.contains(user.getUserId())) {
					memberRequests.remove(user.getUserId());
				}
				commitTransaction(mgr);
				
				if (subscription != null) { subscriptionList.add(subscription); }
				memberAuthList.add(memberAuth);
				memberList.add(user);
				activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.ASSIGNED, loginUser));
				if (subscription != null) {
					activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.SUBSCRIBE, loginUser));
				}
			}
			
			try {
				if (memberRequests.size() != task.getMemberRequests().size()) {
					task.setMemberRequests(memberRequests);
					doMergeTransaction(mgr, task);
				}
				createOrUpdateTaskIndex(mgr, taskId);
				activityService.insertActivities(activityList);
				insertWelcomeTasktimeline(taskId, memberList);
			} catch (Exception ex) { LOG.warning(ex.getMessage());}
			
			return memberList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public void unassignMemberList(String taskId, List<String> userIdList) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			//List<Users> memberList = new ArrayList<Users>();
			List<Activities> activityList = new ArrayList<Activities>();
			Users loginUser = getCurrentUser();
			
			Tasks task = getTasks(mgr, taskId);
			valid(task);
			
			List<MemberAuths> memberAuthList = memberAuthService.batchListMemberAuthsOfTask(mgr, taskId, userIdList);
			
			for (MemberAuths memberAuth : memberAuthList) {
				String userId = memberAuth.getUserId();
				if (task.isOwner(userId)) {
					throw new ServiceUnavailableException(ErrorCode.OWNER_UNASSIGN_UNAVAILABLE.getMessage(Tasks.class, taskId));
				}

				memberAuth.setAuthStatus(AuthStatus.INACTIVE);
				
				beginTransaction(mgr);
				memberAuth = memberAuthService.updateMemberAuths(mgr, memberAuth);
				subscriptionService.removeSubscriptions(mgr, KeyUtil.createSubscriptionKeyString(task, userId));
				commitTransaction(mgr);
				
				activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.UNASSIGNED, loginUser));
				activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.UNSUBSCRIBE, loginUser));
			}

			try {
				createOrUpdateTaskIndex(mgr, taskId);
				activityService.insertActivities(activityList);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void insertWelcomeTasktimeline(String taskId, List<Users> users) {
		for (Users user : users) {
			insertWelcomeTasktimeline(taskId, user);
		}
	}
	private void insertWelcomeTasktimeline(String taskId, Users user) {
		try {
			String welcomeStr = String.format("%s님이 업무방에 가입하셨습니다.", getDisplayUserName(user));
			TaskTimelines taskTimeline = new TaskTimelines();
			taskTimeline.setTaskId(taskId);
			taskTimeline.setDescription(new Text(welcomeStr));
			taskTimeline.setEmoticon(WELCOME_IMAGE_URL);
			taskTimelineService.insertTaskTimelines(taskTimeline, user);
		} catch (Exception ex) {
			LOG.warning("insertWelcomeTasktimeline error : " + ex.getMessage());
		}
	}
	
	@Override
	public boolean isAvailableMemberAuth(String taskId, String userId) {
		try {
			Tasks task = getTasks(taskId);
			if (!isValid(task)) { return false; }
			return boardService.isAvailableMemberAuth(task.getBoardId(), userId);
		} catch (Exception e) {
			return false;
		}
	}

	@SuppressWarnings("unused")
	private Tasks updateTasks(Tasks task) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks originTask = task;
			valid(originTask);
			
//			insertOrUpdateTaskEvent(mgr, originTask);
			doMergeTransaction(mgr, originTask);

			try {
				originTask.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				updateTaskLabelList(originTask);
				updateTaskAttachments(originTask);
			} catch (Exception ex) {
				LOG.warning("[Merge task error]" + ex.getMessage());
				throw ex;
			}

			try {
				createOrUpdateTaskIndex(mgr, originTask);

				Users loginUser = getCurrentUser();
				activityService.insertActivities(activityService.createTaskActivity(originTask, null, ActivityType.UPDATED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			
			return originTask;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskTitle(String taskId, String title) throws Exception {
		if (StringUtils.isEmpty(title)) {
    		throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage(
    				"Task title should not be empty."));
		}

		EntityManager mgr = getEntityManager();
	
		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getTitle(), title);
			task.setTitle(title);

			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				objMap.put(FLD.title, CreateLetterIndexUtil.createLetterIndex(title));
				objMap.put(FLD.modified, task.getModified());
				updateTaskIndexField(taskId, objMap);
				//createOrUpdateTaskIndex(mgr, task);
				
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskActivity(task, activityData, ActivityType.RENAMED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskDescription(String taskId, Text description) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getDescription(), description);
			task.setDescription(description);
			
			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				objMap.put(FLD.description, CreateLetterIndexUtil.createLetterIndex(description));
				objMap.put(FLD.modified, task.getModified());
				updateTaskIndexField(taskId, objMap);
			
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskActivity(task, activityData,
						ActivityType.UPDATE_DESCRIPTION, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTasksWiki(String taskId, Text wiki) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks originTask = getTasks(mgr, taskId);
			valid(originTask);

			originTask.setWiki(wiki);
			unlockTaskWiki(originTask);
			
			doMergeTransaction(mgr, originTask);

			Users loginUser = getCurrentUser();
			try {
//				unlockTaskWiki(taskId);
				taskHistoryService.insertTaskHistories(new TaskHistories(
						originTask.getTaskId(), 
						String.format("[%s] Task wiki[%s] edited.",
								getDisplayUserName(loginUser), originTask.getTitle()),
						loginUser.getUserId(),
						originTask.getWiki()));
			} catch (Exception ex) { throw ex; }

			try {
				originTask.setStage(stageService.getStageByTaskStageCode(originTask.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				objMap.put(FLD.wiki, CreateLetterIndexUtil.createLetterIndex(wiki));
				objMap.put(FLD.modified, originTask.getModified());
				updateTaskIndexField(taskId, objMap);
			
				activityService.insertActivities(activityService.createTaskActivity(originTask, null,
						ActivityType.UPDATE_WIKI, loginUser));
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());	// Ignored. Not a critical part of application.
			}

			return originTask;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskStartDate(String taskId, Date startDate) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getStartDate(), startDate);
			task.setStartDate(startDate);

			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				objMap.put(FLD.startDate, startDate);
				objMap.put(FLD.modified, task.getModified());
				updateTaskIndexField(taskId, objMap);
		
				if (startDate != null) {
					Users loginUser = getCurrentUser();
					Activities activity = activityService.createTaskActivity(task, activityData,
							ActivityType.UPDATE_STARTDATE, loginUser);
					activityService.insertActivities(activity);
				}
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskDueDate(String taskId, Date dueDate) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getDueDate(), dueDate);
			task.setDueDate(dueDate);
			
			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				objMap.put(FLD.dueDate, dueDate);
				objMap.put(FLD.modified, task.getModified());
				updateTaskIndexField(taskId, objMap);
			
				if (dueDate != null) {
					Users loginUser = getCurrentUser();
					Activities activity = activityService.createTaskActivity(task, activityData,
							ActivityType.UPDATE_DUEDATE, loginUser);
					activityService.insertActivities(activity);
				}
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskImportance(String taskId, String importance) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getImportance(), importance);
			task.setImportance(importance);

			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				objMap.put(FLD.importance, importance);
				objMap.put(FLD.modified, task.getModified());
				updateTaskIndexField(taskId, objMap);
				
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskActivity(task, activityData,
						ActivityType.UPDATE_IMPORTANCE, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskLabelList(String taskId, List<String> taskLabelIds) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			if (taskLabelIds == null) taskLabelIds = new ArrayList<String>();

			List<TaskLabels> oldTaskLabels = taskLabelService.listTaskLabelsTagged(mgr, taskId);
			List<String> oldTaskLabelIds = new ArrayList<String>();
			for (TaskLabels label : oldTaskLabels) {
				oldTaskLabelIds.add(label.getTaskLabelId());
			}
			ActivityData activityData = new ActivityData(oldTaskLabelIds, taskLabelIds);

			List<TaskLabels> taskLabels = taskLabelService.updateTaskLabelsTagged(taskId, taskLabelIds);
			task.setLabels(taskLabels);

			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				// TODO : In case of need label indexing by task
				//createOrUpdateTaskIndex(mgr, task);
				
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskActivity(task, activityData,
						ActivityType.UPDATE_LABEL, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskSubscription(String taskId, boolean subscribe) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			Users loginUser = getCurrentUser();
			String userId = loginUser.getUserId();

			Subscriptions taskSubscription = subscriptionService.getTaskSubscription(mgr, taskId, userId);
			if (subscribe && (taskSubscription != null)) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Subscriptions.class, taskSubscription.getObjectId()));
			} else if (!subscribe && (taskSubscription == null)) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage(
						"Task subscription not found."));
			}
			
			beginTransaction(mgr);
			if (subscribe) {
				subscriptionService.insertSubscriptions(mgr, new Subscriptions(task.getDomainId(), task.getBoardId(), task.getTaskId(), userId, userId));
			} else {
				subscriptionService.removeSubscriptions(mgr, taskSubscription.getObjectId());
			}
			doMerge(mgr, task);
			commitTransaction(mgr);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				// TODO : In case of need subscription members indexing by task
				//createOrUpdateTaskIndex(mgr, task);
				
				Activities activity = activityService.createTaskActivity(task, loginUser,
						subscribe ? ActivityType.SUBSCRIBE : ActivityType.UNSUBSCRIBE, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskEditChecklistPermission(String taskId, EditPermission editChecklistPermission) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getEditChecklistPermission(), editChecklistPermission);
			task.setEditChecklistPermission(editChecklistPermission);

			doMergeTransaction(mgr, task);
			
			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				//createOrUpdateTaskIndex(mgr, task); // There is no index change.
				Users loginUser = getCurrentUser();
				ActivityType activityType = EditPermission.OWNER.equals(editChecklistPermission) ?
						ActivityType.CHANGED_CHECKLIST_EDIT_OWNER_PERMISSION
						: ActivityType.CHANGED_CHECKLIST_EDIT_MEMBER_PERMISSION;
				Activities activity = activityService.createTaskActivity(task, activityData, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskEditDetailPermission(String taskId, EditPermission editDetailPermission) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getEditDetailPermission(), editDetailPermission);
			task.setEditDetailPermission(editDetailPermission);

			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				//createOrUpdateTaskIndex(mgr, task); // There is no index change.
				Users loginUser = getCurrentUser();
				ActivityType activityType = EditPermission.OWNER.equals(editDetailPermission) ?
						ActivityType.CHANGED_DETAIL_EDIT_OWNER_PERMISSION
						: ActivityType.CHANGED_DETAIL_EDIT_MEMBER_PERMISSION;
				Activities activity = activityService.createTaskActivity(task, activityData, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks updateTaskDisplayInCalendar(String taskId, String displayInCalendarYN) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getDisplayInCalendarYN(), displayInCalendarYN);
			task.setDisplayInCalendarYN(displayInCalendarYN);

			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				//createOrUpdateTaskIndex(mgr, task);	// There is no index change.
				Users loginUser = getCurrentUser();
				ActivityType activityType = StringUtils.equals(Y, displayInCalendarYN)?
						ActivityType.SHOW_IN_CALENDAR:ActivityType.HIDE_IN_CALENDAR;
				Activities activity = activityService.createTaskActivity(task, activityData, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks archiveTask(String taskId, String archiveYN) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return archiveTask(mgr, taskId, archiveYN);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Tasks> archiveTaskList(List<String> taskIds, String archiveYN) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<Tasks> results = new ArrayList<Tasks>();
			
			for (String taskId : taskIds) {
				try {
					Tasks task = archiveTask(mgr, taskId, archiveYN);
					results.add(task);
				} catch (Exception ex) {
					LOG.warning(Y.equals(archiveYN)?"archive":"unarchive" + " task error : " + taskId);
				}
			}
			
			return results;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Tasks archiveTask(EntityManager mgr, String taskId, String archiveYN) throws Exception {
		try {
			Tasks task = doFind(mgr, Tasks.class, taskId);
			if (StringUtils.isNotBlank(archiveYN) && Y.equals(archiveYN)) {
				valid(task);
			}

			task.setArchiveYN(archiveYN);
			task.setArchived(new Date());

			boolean archived = Y.equals(task.getArchiveYN());
			boolean deleted = Y.equals(task.getDeleteYN());
			attachmentService.markChildAttachments(taskId, archived, deleted);

			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				objMap.put(FLD.archiveYN, archiveYN);
				objMap.put(FLD.modified, task.getModified());
				updateTaskIndexField(taskId, objMap);
			
				Users loginUser = getCurrentUser();
				if (Y.equals(archiveYN)) {
					//UsageService.decreaseUsage(task);
					activityService.insertActivities(activityService.createTaskActivity(task, null, ActivityType.ARCHIVED, loginUser));
				} else {
					//UsageService.increaseUsage(task);
					activityService.insertActivities(activityService.createTaskActivity(task, null, ActivityType.UNARCHIVED, loginUser));
				}
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
			if (Y.equals(archiveYN)) {
				return task;
			} else {
				return getDetailListForTask(mgr, task);
			}
		} catch (Exception ex) {
			throw ex;
		}
	}


	@Override
	public Attachments addTaskAttachment(String taskId, Attachments attachment) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			Tasks task = doFind(mgr, Tasks.class, taskId);
			valid(task);

			attachment = attachmentService.addChildAttachment(taskId, attachment);
			
			try {
				// TODO : In case of need attached file indexing by task
				//createOrUpdateTaskIndex(mgr, task);
				activityService.insertActivities(activityService.createTaskActivity(task, attachment, ActivityType.ATTACHED, loginUser));
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
			
			return attachment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Attachments removeTaskAttachment(String taskId, String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			Tasks task = doFind(mgr, Tasks.class, taskId);
			valid(task);

			Attachments attachment = attachmentService.removeChildAttachment(taskId, attachmentId);
		
			try {
				// TODO : In case of need appended file indexing by task
				//createOrUpdateTaskIndex(mgr, task);

				activityService.insertActivities(activityService.createTaskActivity(task,
						attachment, ActivityType.UNATTACHED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			
			return attachment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks removeTasks(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			
			if (!Y.equals(task.getArchiveYN())) {
				valid(task);
			}
			Users loginUser = getCurrentUser();
			
			removeTaskEvent(task);
			task.setDeleteYN(Y);
			task.setDeleted(new Date());
			
			beginTransaction(mgr);
			taskHistoryService.insertTaskHistories(mgr,
					new TaskHistories(task.getTaskId(),
							String.format("[%s] Task wiki[%s] removed.", getDisplayUserName(loginUser), task.getTitle()),
							loginUser.getUserId(),
							task.getWiki())
			);
			doMerge(mgr, task);
			commitTransaction(mgr);
		
			try {
				removeTaskIndex(taskId);

				boolean archived = Y.equals(task.getArchiveYN());
				boolean deleted = Y.equals(task.getDeleteYN());
				attachmentService.markChildAttachments(taskId, archived, deleted);
				taskLabelService.removeTaskLabelsTagged(taskId);
				//UsageService.decreaseUsage(task);
			} catch (Exception ex) {
				throw ex;
			}
			try {
				activityService.insertActivities(activityService.createTaskActivity(task, null, ActivityType.DELETED, loginUser));
			} catch (Exception ex) { LOG.warning(ex.getMessage());}
				
			// TODO
			// Task를 참조하고 있는 Kind중에서 task가 삭제되었을 경우 문제가 발생할 소지가 있는 entity들을 삭제 처리해 주어야 한다.
			// 주의할 점은 archive/unarchive 기능때문에 완전히 삭제하는것이 아니고 삭제 flag값만 설정해야 한다.
			// 영구 삭제 시 실제로 삭제
			
			return task;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Tasks moveStage(String taskId, String taskStage) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return moveStage(mgr, taskId, taskStage);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private Tasks moveStage(EntityManager mgr, String taskId, String taskStage) throws Exception {
		Tasks task = getTasks(mgr, taskId);
		String fromTaskStage = task.getTaskStage();
		Stages fromStage = doFind(mgr, Stages.class, KeyUtil.createStageKey(fromTaskStage));
		Stages toStage = doFind(mgr, Stages.class, KeyUtil.createStageKey(taskStage));
		valid(task);

		task.setTaskStage(taskStage);
		
		doMergeTransaction(mgr, task);

		try {
			task.setStage(toStage);
			Map<String, Object> objMap = new HashMap<String, Object>();
			objMap.put(FLD.taskStage, taskStage);	// 현재 TaskIndex에서는 사용되지 않는다. 이전에 taskListId를 사용했을때 쓰던 부분이다.
			objMap.put(FLD.stageOrdinal, toStage.getStageOrdinal());
			objMap.put(FLD.modified, task.getModified());
			updateTaskIndexField(taskId, objMap);
			
			Users loginUser = getCurrentUser();
			ActivityData activityData = new ActivityData(fromStage.getTitle(), toStage.getTitle());
			activityService.insertActivities(activityService.createTaskActivity(task, activityData, ActivityType.MOVED, loginUser));
		} catch (Exception e) {
			LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
		}
		
		return task;
	}
	@Override
	public List<Tasks> moveStageList(List<String> taskIds, String taskStage) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<Tasks> results = new ArrayList<Tasks>();
			for (String taskId : taskIds) {
				Tasks task = moveStage(mgr, taskId, taskStage);
				results.add(task);
			}
			return results;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Tasks> batchMoveStage(String boardId, String fromTaskStage, String toTaskStage) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Stages toStage = doFind(mgr, Stages.class, KeyUtil.createStageKey(toTaskStage));
			Stages fromStage = doFind(mgr, Stages.class, KeyUtil.createStageKey(fromTaskStage));
			
			return batchMoveStage(mgr, boardId, fromStage, toStage);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<Tasks> batchMoveStage(EntityManager mgr, String boardId, Stages fromStage, Stages toStage) throws Exception {
		Users loginUser = getCurrentUser();
		
		DsQuery<Tasks> dsQuery = new DsQuery<>(Tasks.class)
				.eq(FLD.boardId, boardId);

		List<Tasks> results = dsQuery.execute(mgr);
		
		for (Tasks task : results) {
			if (!StringUtils.equals(task.getTaskStage(), fromStage.getTaskStage())) { continue; }
			task.setTaskStage(toStage.getTaskStage());
			task = doMergeTransaction(mgr, task);
			task.setStage(toStage);
			
			Map<String, Object> objMap = new HashMap<String, Object>();
			
			objMap.put(FLD.taskStage, toStage.getTaskStage());	// 현재 TaskIndex에서는 사용되지 않는다. 이전에 taskListId를 사용했을때 쓰던 부분이다.
			objMap.put(FLD.stageOrdinal, toStage.getStageOrdinal());
			objMap.put(FLD.modified, task.getModified());
			updateTaskIndexField(task.getTaskId(), objMap);
			
			ActivityData activityData = new ActivityData(fromStage.getTitle(), toStage.getTitle());
			activityService.insertActivities(activityService.createTaskActivity(task, activityData, ActivityType.MOVED, loginUser));
		}
		return results;
	}
	
	@Deprecated
	public Tasks moveTask_old(String taskId, String tasklistId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			String originTaskStage = task.getTaskStage();
			Stages originStage = doFind(mgr, Stages.class, KeyUtil.createStageKey(originTaskStage));
			//String originTaskStage = task.getTaskStage();
			//String originTasklistId = task.getTasklistId();

			valid(task);
			task.setTasklistId(tasklistId);
			
			doMergeTransaction(mgr, task);

			try {
				task.setStage(stageService.getStageByTaskStageCode(task.getTaskStage()));
				Map<String, Object> objMap = new HashMap<String, Object>();
				String taskStage = task.getTaskStage();
				Stages stage = doFind(mgr, Stages.class, KeyUtil.createStageKey(taskStage));
				objMap.put(FLD.taskStage, taskStage);
				objMap.put(FLD.stageOrdinal, stage.getStageOrdinal());
				//objMap.put(FLD.stageOrdinal, TaskStage.valueOf(KeyFactory.stringToKey(tasklistId).getName()).ordinal());
				objMap.put(FLD.modified, task.getModified());
				updateTaskIndexField(taskId, objMap);
				
				Users loginUser = getCurrentUser();
				ActivityData activityData = new ActivityData(originStage.getTitle(), stage.getTitle());
				activityService.insertActivities(activityService.createTaskActivity(task, activityData, ActivityType.MOVED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			
			return task;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public TaskIndex createOrUpdateTaskIndex(EntityManager mgr, String taskId) {
		try {
			Tasks task = getTasks(mgr, taskId);
			
			return createOrUpdateTaskIndex(mgr, task);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}
	
	private TaskIndex createOrUpdateTaskIndex(Tasks task) {
		EntityManager mgr = getEntityManager();
		try {
			return createOrUpdateTaskIndex(mgr, task);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Tasks addTaskFinalAttachments(String taskId, String attachmentId) throws Exception {
		try {
			Tasks task = getTasks(taskId);
			if (task != null) {
				Attachments attachment = attachmentService.addFinalAttachment(taskId, attachmentId);
				try {
					if (attachment != null) {
						createOrUpdateTaskIndex(task);
						Users loginUser = getCurrentUser();
						Activities activity = activityService.createTaskActivity(task, attachment, ActivityType.FINAL_ATTACHED, loginUser);
						activityService.insertActivities(activity);
					}
				} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			}
			
			return task;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public boolean isLockTaskWiki(String taskId) {
		try {
			Tasks task = getTasks(taskId);
			if (task == null) { return true; }
			Users user = getCurrentUser();
			
			return !user.getUserId().equals(task.getWikiLockUserId());
		} catch (Exception ex) {
			return true;
		}
	}
	
	@Override
	public Map<String, Object> lockTaskWiki(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Tasks task = getTasks(mgr, taskId);
			Users user = getCurrentUser();
			
			Map<String, Object> result = new HashMap<String, Object>();
			
			if (StringUtils.isNotBlank(task.getWikiLockUserId())) {
				if (user.getUserId().equals(task.getWikiLockUserId())) {
					result.put(FLD.editable, true);
				} else {
					result.put(FLD.editable, false);
				}
			} else {
				task.setWikiLockDate(new Date());
				task.setWikiLockUserId(user.getUserId());
				
				task = doMergeTransaction(mgr, task);
				
				result.put(FLD.editable, true);
			}
			
			result.put(FLD.wikiLockDate, task.getWikiLockDate());
			result.put(FLD.wikiLockUserId, task.getWikiLockUserId());
			if (StringUtils.isNotBlank(task.getWikiLockUserId())) {
				Users lockUser = userService.getUsers(mgr, task.getWikiLockUserId(), false);
				result.put(FLD.userName, lockUser.getUserName());
			}
			
			return result;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void unlockTaskWiki(String taskId) {
		EntityManager mgr = getEntityManager();
		
		try {
			Tasks task = getTasks(mgr, taskId);
			
			if (task != null) {
				unlockTaskWiki(task);
				
				doMergeTransaction(mgr, task);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void unlockTaskWiki(Tasks task) {
		task.setWikiLockDate(null);
		task.setWikiLockUserId(null);
	}
	
	private List<Users> listUnsubscribedUsersForCloseTask(Tasks task) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			String taskId = task.getTaskId();
			List<MemberAuths> assignedUsers = memberAuthService.listMemberAuths(mgr, null, null, AuthKind.TASKS, taskId, AuthStatus.ACTIVE, null, false);
			List<Subscriptions> subscribedUsers = subscriptionService.listSubscriptions(mgr, null, taskId, null, false);
			
			List<String> assignedUserIds = new ArrayList<String>();
			List<String> unsubscribedUserIds = new ArrayList<String>();
			
			for (MemberAuths auth : assignedUsers) {
				if (auth.getUserId().equals(task.getOwner())) { continue; }
				assignedUserIds.add(auth.getUserId());
			}
			for (Subscriptions sub : subscribedUsers) {
				if (sub.getUserId().equals(task.getOwner())) { continue; }
				if (!assignedUserIds.contains(sub.getUserId())) {
					unsubscribedUserIds.add(sub.getUserId());
				}
			}
			
			return batchListByKey(mgr, Users.class, unsubscribedUserIds);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Tasks closeTask(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			List<Activities> activityList = new ArrayList<Activities>();
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getCloseYN(), Y);
			task.setCloseYN(Y);

			doMergeTransaction(mgr, task);

			try {
				//createOrUpdateTaskIndex(mgr, task);	// There is no index change.
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskActivity(task, activityData,
						ActivityType.CLOSED, loginUser);
				activityList.add(activity);
				
				List<Users> unsubscribedUsers = listUnsubscribedUsersForCloseTask(task);
				List<String> subscriptionIdList = new ArrayList<String>();
				for (Users user : unsubscribedUsers) {
					subscriptionIdList.add(KeyUtil.createSubscriptionKeyString(task, user));
					//subscriptionService.removeSubscriptions(KeyUtil.createSubscriptionKeyString(task, user));
					activityList.add(activityService.createTaskActivity(task, user, ActivityType.UNSUBSCRIBE, loginUser));
				}
				subscriptionService.removeSubscriptions(mgr, subscriptionIdList);
				activityService.insertActivities(activityList);	
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Tasks openTask(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);

			ActivityData activityData = new ActivityData(task.getCloseYN(), N);
			task.setCloseYN(N);

			doMergeTransaction(mgr, task);

			try {
				//createOrUpdateTaskIndex(mgr, task);	// There is no index change.
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskActivity(task, activityData,
						ActivityType.OPENED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}

			return task;
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void requestMembers(String taskId, String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users requestUser = null;
			if (StringUtils.isNotBlank(userId)) {
				requestUser = userService.getUsers(mgr, userId, false);
			} else {
				requestUser = getCurrentUser();
				userId = requestUser.getUserId();
			} 
			Tasks task = getTasks(mgr, taskId);
			valid(task);
			
			List<String> memberRequests = task.getMemberRequests();
			if (memberRequests.contains(userId)) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Tasks.class, task.getTaskId()));
			}
			
			memberRequests.add(userId);
			task.setMemberRequests(memberRequests);
			doMergeTransaction(mgr, task);

			try {
				activityService.insertActivities(activityService.createTaskActivity(task, null, ActivityType.REQUEST_MEMBERS, requestUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void confirmMembers(String taskId, String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);
			
			List<String> memberRequests = task.getMemberRequests();
			Users requestUser = userService.getUsers(mgr, userId, false);
			if (!memberRequests.contains(userId)) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Request Member not found."));
			}
//			memberRequests.remove(userId);
//			task.setMemberRequests(memberRequests);
//			doMergeTransaction(mgr, task);

			try {
				Users loginUser = getCurrentUser();
				assignMember(taskId, userId, Auth.MEMBER);
				List<String> userIdList = new ArrayList<String>();
				userIdList.add(userId);
				boardService.assignMemberList(task.getBoardId(), userIdList);
				activityService.insertActivities(activityService.createTaskActivity(task, requestUser, ActivityType.CONFIRM_MEMBERS, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void rejectMembers(String taskId, String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasks(mgr, taskId);
			valid(task);
			
			List<String> memberRequests = task.getMemberRequests();
			Users rejectUser = userService.getUsers(mgr, userId, false);
			if (!memberRequests.contains(userId)) {
				throw new NotFoundException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Request Member not found."));
			}
			memberRequests.remove(userId);
			task.setMemberRequests(memberRequests);
			
			doMergeTransaction(mgr, task);

			try {
				Users loginUser = getCurrentUser();
				activityService.insertActivities(activityService.createTaskActivity(task, rejectUser, ActivityType.REJECT_MEMBERS, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void removeTaskIndex(String taskId) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.deleteDocuments(TaskIndex.class, taskId);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}
	
	@SuppressWarnings("unused")
	private void updateTaskIndexField(String taskId, String fieldName, Object fieldValue, Date modified) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.updateIndexField(TaskIndex.class, taskId, fieldName, fieldValue, modified);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}
	
	private void updateTaskIndexField(String taskId, Map<String, Object> objMap) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.updateIndexField(TaskIndex.class, taskId, objMap);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}

	@Override
	public Tasks moveTask(String taskId, String toBoardId, String toTaskStage) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Tasks task = getTasksDetail(mgr, taskId);
			String fromBoardId = task.getBoardId();
			if (StringUtils.equals(toBoardId, fromBoardId)) { 
				throw new Exception("Can not move to same board.");
			}
			
			Stages fromStage = task.getStage();
			Stages toStage = doFind(mgr, Stages.class, KeyUtil.createStageKey(toTaskStage));
			
			task.setBoardId(toBoardId);
			task.setTaskStage(toTaskStage);
			
			valid(task);
			
			doMergeTransaction(mgr, task);

			try {
				task.setStage(toStage);
				Map<String, Object> objMap = new HashMap<String, Object>();
				
				objMap.put(FLD.taskStage, toTaskStage);
				objMap.put(FLD.stageOrdinal, toStage.getStageOrdinal());
				objMap.put(FLD.modified, task.getModified());
				
				updateTaskIndexField(taskId, objMap);

			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			// 실제로는 Board에 해당 사용자가 없으면 등록
			// MemberAuth boardId 변경 : 보드에 해당 사용자 없으면 등록
			moveBoardsOfTaskMembers(mgr, task);
			// Subscription 이동 : boardId 변경
			moveBoardOfTaskSubscriptions(mgr, task);
			// Timelines 이동	: TimelineIndex 이동
			moveBoardOfTaskTimelines(mgr, task);
			// Comments 이동 : CommentIndex 이동
			moveBoardOfTaskTimelineComments(mgr, task);
			// AttachmentsIndex 변경 (Task/Timeline)
			searchService.moveBoardOfTaskAttachments(taskId, toBoardId);
			// Labels 이동(기존 Tasks에서 삭제/신규 보드에 등록  또는 삭제처리만)
			moveBoardsOfTaskLabels(mgr, task, toBoardId);
			// Checklists 이동
			moveBoardOfTaskChecklists(mgr, task);
			// Checklists History 이동
			moveBoardOfTaskChecklistHistories(mgr, task);
			// TaskHistory 이동(하지 않아도 될듯)
			// Events 이동 : EventIndex 이동
			// 2017-06-06 : 현재는 task의 이벤트를 사용하지 않으므로 일단은 적용하지 않는다.
			//moveBoardOfTaskEvents(mgr, task, toBoardId);
			
			// Memory Cache 초기화
			// Task, Board, Attachment, Images, Checklist, Comments, Labels, MemberAuth, Users, Events 등 이전 보드에 적용된 캐시 클리어
			// 신규 보드는 이미 위 입력/수정 과정에서 캐시 클리어 과정 포함됨
			clearMemcacheForFromBoard(fromBoardId);
			//MemcacheManager.clearAll();
			
			try {
				Users loginUser = getCurrentUser();
				fromStage.setBoardId(fromBoardId);
				toStage.setBoardId(toBoardId);
				ActivityData activityData = new ActivityData(fromStage, toStage);
				activityService.insertActivities(activityService.createTaskActivity(task, activityData, ActivityType.MOVED_BOARD, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Not a critical part of application.
			}
			return task;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private List<TaskLabels> moveBoardsOfTaskLabels(EntityManager mgr, Tasks task, String toBoardId) throws Exception {
		try {
			List<TaskLabels> oldLabels = task.getLabels();
			List<TaskLabels> newLabels = new ArrayList<TaskLabels>();
			taskLabelService.removeTaskLabelsTagged(task.getTaskId());
			List<TaskLabels> toBoardLabels = taskLabelService.listTaskLabels(mgr, toBoardId);
			
			for (TaskLabels oldLabel : oldLabels) {
				TaskLabels newLabel = getTaskLabelByName(toBoardLabels, oldLabel.getLabel());
				if (newLabel == null) {
					newLabel = new TaskLabels();
					
					newLabel.setBoardId(toBoardId);
					newLabel.setColor(oldLabel.getColor());
					newLabel.setLabel(oldLabel.getLabel());
					newLabel.setCreator(task.getCreator());
					newLabel.setKey(KeyUtil.createTaskLabelKey(newLabel));
					
					doPersistTransaction(mgr, newLabel);
				}
				
				if (newLabel != null) { newLabels.add(newLabel); }
			}
			task.setLabels(newLabels);
			
			updateTaskLabelList(task);
			return task.getLabels();
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private static TaskLabels getTaskLabelByName(List<TaskLabels> toBoardLabels, String label) {
		if (toBoardLabels == null || toBoardLabels.size() == 0) { return null; }
		for (TaskLabels taskLabel : toBoardLabels) {
			if (StringUtils.equalsIgnoreCase(taskLabel.getLabel(), label)) { return taskLabel; }
		}
		return null;
	}
	
	private List<Users> moveBoardsOfTaskMembers(EntityManager mgr, Tasks task) throws Exception {
		try {
			DsQuery<MemberAuths> dsQuery = new DsQuery<>(MemberAuths.class)
					.eq(FLD.deleteYN, null)
					//.eq(FLD.authKind, AuthKind.TASKS)
					.eq(FLD.kindId, task.getTaskId());
			List<MemberAuths> results = dsQuery.execute(mgr);

			List<String> userIds = new ArrayList<String>();
			for (MemberAuths member : results) {
				member.setBoardId(task.getBoardId());
				doMergeTransaction(mgr, member);
				userIds.add(member.getUserId());
			}
			
			List<Users> members = new ArrayList<Users>(userService.batchMapUsers(mgr, userIds, false).values());
			
			// 보드의 멤버가 아닐경우 멤버로 할당하기 위해
			userIds.clear();
			for (Users member : members) { userIds.add(member.getUserId());	}
			members = boardService.assignMemberList(task.getBoardId(), userIds);
			task.setMembers(members);
			
			return members;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<Subscriptions> moveBoardOfTaskSubscriptions(EntityManager mgr, Tasks task) throws Exception {
		try {
			DsQuery<Subscriptions> dsQuery = new DsQuery<>(Subscriptions.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.taskId, task.getTaskId());
			
			List<Subscriptions> subscriptions = dsQuery.execute(mgr);
			for (Subscriptions subscription : subscriptions) {
				subscription.setBoardId(task.getBoardId());
				doMergeTransaction(mgr, subscription);
			}
			return subscriptions;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<TaskTimelines> moveBoardOfTaskTimelines(EntityManager mgr, Tasks task) throws Exception {
		try {
			SearchManager sm = new SearchManager();
			DsQuery<TaskTimelines> dsQuery = new DsQuery<>(TaskTimelines.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.taskId, task.getTaskId());
				
			
			List<TaskTimelines> results = dsQuery.execute(mgr);
			for (TaskTimelines timeline : results) {
				timeline.setBoardId(task.getBoardId());
				doMergeTransaction(mgr, timeline);
				sm.updateIndexField(TimelineIndex.class, timeline.getTaskTimelineId(), FLD.boardId, task.getBoardId());
				//taskTimelineService.createOrUpdateTaskTimelineIndex(timeline);
			}
			
			return results;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<TaskTimelineComments> moveBoardOfTaskTimelineComments(EntityManager mgr, Tasks task) throws Exception {
		try {
			SearchManager sm = new SearchManager();
			DsQuery<TaskTimelineComments> dsQuery = new DsQuery<>(TaskTimelineComments.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.taskId, task.getTaskId());
					
			List<TaskTimelineComments> results = dsQuery.execute(mgr);
			for (TaskTimelineComments comment : results) {
				comment.setBoardId(task.getBoardId());
				doMergeTransaction(mgr, comment);
				sm.updateIndexField(CommentIndex.class, comment.getTaskTimelineCommentId(), FLD.boardId, task.getBoardId());
				//taskTimelineCommentService.createOrUpdateTaskTimelineCommentIndex(comment);
			}
			
			return results;
		} catch (Exception ex) {
			throw ex;
		}
	}

	private List<TaskChecklists> moveBoardOfTaskChecklists(EntityManager mgr, Tasks task) throws Exception {
		try {
			//SearchManager sm = new SearchManager();
			DsQuery<TaskChecklists> dsQuery = new DsQuery<>(TaskChecklists.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.taskId, task.getTaskId());
					
			List<TaskChecklists> results = dsQuery.execute(mgr);
			for (TaskChecklists checklist : results) {
				checklist.setBoardId(task.getBoardId());
				doMergeTransaction(mgr, checklist);
				//sm.updateIndexField(TaskChecklists.class, checklist.getTaskChecklistId(), FLD.boardId, task.getBoardId());
			}
			task.setChecklists(results);
			return results;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<TaskChecklistHistories> moveBoardOfTaskChecklistHistories(EntityManager mgr, Tasks task) throws Exception {
		try {
			//SearchManager sm = new SearchManager();
			DsQuery<TaskChecklistHistories> dsQuery = new DsQuery<>(TaskChecklistHistories.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.taskId, task.getTaskId());
					
			List<TaskChecklistHistories> results = dsQuery.execute(mgr);
			for (TaskChecklistHistories history : results) {
				history.setBoardId(task.getBoardId());
				doMergeTransaction(mgr, history);
				//sm.updateIndexField(TaskChecklists.class, checklist.getTaskChecklistId(), FLD.boardId, task.getBoardId());
			}
			
			return results;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@SuppressWarnings("unused")
	private List<Events> moveBoardOfTaskEvents(EntityManager mgr, Tasks task) throws Exception {
		try {
			SearchManager sm = new SearchManager();
			DsQuery<Events> dsQuery = new DsQuery<>(Events.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.taskId, task.getTaskId());
					
			List<Events> results = dsQuery.execute(mgr);
			for (Events event : results) {
				event.setBoardId(task.getBoardId());
				doMergeTransaction(mgr, event);
				sm.updateIndexField(Events.class, event.getEventId(), FLD.boardId, task.getBoardId());
			}
			
			return results;
		} catch (Exception ex) {
			throw ex;
		}
	}
	

	private void clearMemcacheForFromBoard(String fromBoardId) {
		MemcacheManager.removeAllMemcache(Tasks.class, fromBoardId);
		MemcacheManager.removeAllMemcache(MemberAuths.class, fromBoardId);
		MemcacheManager.removeAllMemcache(TaskChecklists.class, fromBoardId);
		MemcacheManager.removeAllMemcache(Stages.class, fromBoardId);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public TaskIndex createOrUpdateTaskIndex(EntityManager mgr, Tasks task) {
		try {
			TaskIndex taskIndex = null;
			if (task != null) {
				//String memberIndexStr = null;
				//String userIdIndexStr = null;
				String checklistIndexStr = null;
				//String subscriptionMembersIndexStr = null;

				taskIndex = new TaskIndex();

				//List<Users> members = listTasksMembers(task.getTaskId());
				List<TaskChecklists> taskChecklists = taskChecklistService.listTaskChecklists(mgr, task.getTaskId(), null);
				//List<Users> subscriptionUserList = subscriptionService.getSubscriptionUserList(task.getTaskId());

//				if (members != null && members.size() > 0) {
//					List<String> memberList = new ArrayList<String>();
//					List<String> userIdList = new ArrayList<String>();
//					for (Users user : members) {
//						userIdList.add(user.getUserId());
//						if (StringUtils.isNotBlank(user.getEmail())) 	{ memberList.add(user.getEmail()); }
//						if (StringUtils.isNotBlank(user.getNickName())) { memberList.add(user.getNickName()); }
//						if (StringUtils.isNotBlank(user.getUserName())) { memberList.add(user.getUserName()); }
//						if (StringUtils.isNotBlank(user.getId())) 		{ memberList.add(user.getId()); }
//					}
//					memberIndexStr = StringUtils.join(memberList, " ");
//					userIdIndexStr = StringUtils.join(userIdList, " ");
//				}

				if (taskChecklists != null) {
					List<String> taskChecklistIndexList = new ArrayList<String>();
					
					for (TaskChecklists taskChecklist : taskChecklists) {
						if (StringUtils.isNotBlank(taskChecklist.getTitle())) { taskChecklistIndexList.add(taskChecklist.getTitle()); }
						if (taskChecklist.getDescription() != null && StringUtils.isNotBlank(taskChecklist.getDescription().getValue())) {
							taskChecklistIndexList.add(taskChecklist.getDescription().getValue());
						}
					}
					
					checklistIndexStr = CreateLetterIndexUtil.createLetterIndex(StringUtils.join(taskChecklistIndexList, " "));
				}

//				if (subscriptionUserList != null) {
//					List<String> userIds = new ArrayList<String>();
//					for (Users user: subscriptionUserList) { userIds.add(user.getUserId()); }
//
//					subscriptionMembersIndexStr = StringUtils.join(userIds, " ");
//				}
				/**
				 *  !!!! Date & Geopoint 값은 Null을 허용하지 않는다.
				 *  null일경우 Date(0) : 1970-01-01 로 설정.
				 */
				Date modifyDate = task.getCreated();
				Date dueDate = new Date(0);
				Date completeDate = new Date(0);
				if (task.getModified() != null) { modifyDate = task.getModified(); }
				if (task.getDueDate() != null) { dueDate = task.getDueDate(); }
				if (task.getCompleteDate() != null) { completeDate = task.getCompleteDate(); }
			

				taskIndex.setKey(task.getKey());
				taskIndex.setDomainId(task.getDomainId());
				taskIndex.setBoardId(task.getBoardId());
				taskIndex.setTasklistId(task.getTasklistId());
				
				taskIndex.setTaskId(task.getTaskId());
				//taskIndex.setArchived(task.getArchived());
				taskIndex.setArchiveYN(task.getArchiveYN());
				
				taskIndex.setTitle(CreateLetterIndexUtil.createLetterIndex(task.getTitle()));
				taskIndex.setDescription(CreateLetterIndexUtil.createLetterIndex(task.getDescription()));
				
				taskIndex.setCreated(task.getCreated());
				taskIndex.setCreator(task.getCreator());
				
				taskIndex.setModified(modifyDate);
				taskIndex.setDueDate(dueDate);
				taskIndex.setCompleteDate(completeDate);
				
				//taskIndex.setAssignMembers(memberIndexStr);
				//taskIndex.setAssignUserIds(userIdIndexStr);
				taskIndex.setChecklists(checklistIndexStr);
				taskIndex.setWiki(CreateLetterIndexUtil.createLetterIndex(task.getWiki()));
				
				//taskIndex.setSubscriptionMembers(subscriptionMembersIndexStr);
				taskIndex.setImportance(task.getImportance());
				
				Boards board = boardService.getBoards(mgr, task.getBoardId());
				
				//taskIndex.setStageOrdinal(TaskStage.valueOf(KeyFactory.stringToKey(task.getTasklistId()).getName()).ordinal());
				Stages stage = task.getStage(); 
				if (stage == null) { stage = doFind(mgr, Stages.class, KeyUtil.createStageKey(task.getTaskStage())); }
				taskIndex.setStageOrdinal(stage.getStageOrdinal());
				//taskIndex.setStageOrdinal(task.getTaskStage().ordinal());
				taskIndex.setBoardTitle(board.getTitle());
				taskIndex.setBoardCreated(board.getCreated());
			}
			
			SearchManager sm = new SearchManager();
			if (taskIndex != null) { sm.createIndex(taskIndex); }
			
			return taskIndex;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public long countTasks(
//			String boardId,
//			String tasklistId,
//			List<String> userIdList,
//			String archiveYN) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			SimpleQuery<Tasks> sq = new SimpleQuery<>(mgr, Tasks.class);
//			sq.where(sq.and(
//					sq.equal(FLD.boardId, boardId),
//					sq.equal(FLD.tasklistId, tasklistId),
//					sq.in(FLD.owner, userIdList),
//					sq.equal(FLD.archiveYN, archiveYN == null ? N : archiveYN)
//			));
//			TypedQuery<Long> query = sq.count();
//			return query.getSingleResult();
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public QueryResult<Tasks> listTasks(
//			String cursorString,
//			Integer limit,
//			String boardId,
//			String tasklistId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return queryTasks(mgr, cursorString, limit, null, Arrays.asList(new String[]{ boardId }), N, null, null, true);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<String> listSubscribedTaskIds(String boardId, String userId) {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			return listSubscribedTaskIds(mgr, boardId, userId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Users unassignMember(String taskId, String userId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			List<Activities> activityList = new ArrayList<Activities>();
//			Users loginUser = getCurrentUser();
//			
//			Tasks task = doFind(mgr, Tasks.class, taskId);
//
//			if (task.isOwner(userId)) {
//				throw new ServiceUnavailableException(ErrorCode.OWNER_UNASSIGN_UNAVAILABLE.getMessage(Tasks.class, taskId));
//			}
//			MemberAuths memberAuth = memberAuthService.getMemberAuths(mgr, taskId, userId);
//
//			if (memberAuth == null) {
//				throw new NotFoundException(ErrorCode.MEMBER_NOT_FOUND.getMessage(MemberAuths.class));
//			}
//
//			memberAuth.setAuthStatus(AuthStatus.INACTIVE);
//			
//			beginTransaction(mgr);
//			memberAuth = memberAuthService.updateMemberAuths(mgr, memberAuth);
//			subscriptionService.removeSubscriptions(mgr, KeyUtil.createSubscriptionKeyString(task, memberAuth.getUser()));
//			commitTransaction(mgr);
//			
//			activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.UNASSIGNED, loginUser));
//			activityList.add(activityService.createTaskActivity(task, memberAuth.getUser(), ActivityType.UNSUBSCRIBE, loginUser));
//			
//			try {
//				createOrUpdateTaskIndex(mgr, taskId);
//				activityService.insertActivities(activityList);	
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return memberAuth.getUser();
//		} catch (Exception e) {
//			throw e;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Events insertOrUpdateTaskEvent(Tasks task) throws Exception {
//		try {
//			Events taskEvent = task.getEvent();
//			
//			if (taskEvent != null) {
//				taskEvent.setTitle(task.getTitle());
//				taskEvent.setDescription(task.getDescription());
//				taskEvent.setSummary(task.getSummary());
//				Events originTaskEvent = getTaskEvent(task.getTaskId());
//				if(originTaskEvent != null) {
//					taskEvent.setEventId(originTaskEvent.getEventId());
//					taskEvent = calendarService.updateEvents(taskEvent);
//				} else {
//					taskEvent.setDomainId(task.getDomainId());
//					taskEvent.setBoardId(task.getBoardId());
//					taskEvent.setTaskId(task.getTaskId());
//					taskEvent.setEventType(EventType.TASK);					
//					taskEvent = calendarService.insertEvents(taskEvent);
//				}
//				task.setEvent(taskEvent);
//			}
//			
//			return taskEvent;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	@Override
//	public void permanentRemoveTasks(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			Tasks task = doFind(mgr, Tasks.class, taskId);
//			
//			if (task != null) {
//				taskLabelService.removeTaskLabelsTagged(taskId);
//				subscriptionService.bulkRemoveSubscriptions(null, taskId, null);
//				memberAuthService.bulkRemoveMemberAuths(null, null, AuthKind.TASKS, taskId, null, null);
//				taskHistoryService.bulkRemoveTaskHistories(taskId);
//				attachmentService.removeTaskAttachments(taskId);
//				taskTimelineService.bulkRemoveTaskTimelines(taskId);
//				taskChecklistService.bulkRemoveTaskChecklist(taskId);
//
//				// TODO 기타 등등 관련 Object 모두 제거
//				
//				doRemoveTransaction(mgr, task);
//			}
//
//			try {
//				removeTaskIndex(taskId);
//				//UsageService.decreaseUsage(task);
//			} catch (Exception ex) {
//				LOG.warning(ex.getMessage());
//			}
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Tasks recoverTaskWiki(String taskId, String taskHistoryId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			boolean recovered = false;
//			Tasks recoverTask = getTasks(mgr, taskId);
//			TaskHistories taskHistory = doFind(mgr, TaskHistories.class, taskHistoryId);
//			if ((recoverTask != null) && (taskHistory != null)) {
//				Text wiki = taskHistory.getWiki();
//				recoverTask.setWiki(wiki);
//				
//				doMergeTransaction(mgr, recoverTask);
//				recovered = true;
//			}
//
//			if (recovered) {
//				try {
//					createOrUpdateTaskIndex(mgr, recoverTask);
//				} catch (Exception ex) {
//					LOG.warning(ex.getMessage());
//				}
//			}
//
//			return recoverTask;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public void removeTaskFinalAttachments(String taskId, String attachmentId) throws Exception {
//		removeTaskAttachment(taskId, attachmentId);
//	}
//	@Override
//	public void replaceTaskFinalAttachments(String taskId, String oldAttachmentId, String newAttachmentId) throws Exception {
//		removeTaskAttachment(taskId, oldAttachmentId);
//		addTaskFinalAttachments(taskId, newAttachmentId);
//	}
//	@Override
//	public TaskIndex createOrUpdateTaskIndex(String taskId) {
//		try {
//			Tasks task = getTasks(taskId);
//			
//			return createOrUpdateTaskIndex(task);
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//			return null;
//		}
//	}
//	@Override
//	public void activeYNTaskEvent(String taskId, String activeYN) throws Exception {
//		try {
//			Events taskEvent = getTaskEvent(taskId);
//			
//			taskEvent.setActiveYN(activeYN);
//			calendarService.updateEvents(taskEvent);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	// Task(Workspace)의 페이지 구성시, 단계적으로 필요한 항목을 가져오는것을, 한번의 조회로 필요한 항목을 모두 조회하여 리턴
//	// (단계별 요청시 네트워크 오버헤드가 많이 발생하므로, 하나의 요청으로 처리하는것이 성능상 더 유리함)
//	@Override
//	public Map<String, Object> getTaskItems(String taskId) throws Exception {
//		Map<String, Object> taskItems = new HashMap<String, Object>();
//		EntityManager mgr = getEntityManager();
//		try {
//			Tasks task = getTasks(mgr, taskId);
//			List<String> taskIdList = new ArrayList<String>();
//			taskIdList.add(taskId);
//			
//			Map<String, List<TaskChecklists>> checklistsMap = taskChecklistService.batchMapTaskChecklists(mgr, taskIdList);
//			Map<String, List<TaskLabels>> labelsMap = taskLabelService.batchMapChildTaskLabels(mgr, taskIdList);
//			Map<String, List<Users>> usersMap = memberAuthService.batchMapTaskAllMembers(mgr, taskId);
//			Map<String, List<Attachments>> attachmentsMap = attachmentService.batchMapTaskAttachments(mgr, taskIdList);
//		
//			task.setChecklists(checklistsMap.get(taskId));
//			task.setLabels(labelsMap.get(taskId));
//			task.setMembers(usersMap.get(ITEM_ASSIGNED_MEMBERS));
//			task.setAttachments(attachmentsMap.get(taskId));
//			
//			taskItems.put(ITEM_TASK, task);
//			taskItems.put(ITEM_ASSIGNED_MEMBERS, usersMap.get(ITEM_ASSIGNED_MEMBERS));
//			taskItems.put(ITEM_UNASSIGNED_MEMBERS, usersMap.get(ITEM_UNASSIGNED_MEMBERS));
//			taskItems.put(ITEM_ISSUBSCRIBED, isMySubscribedTask(mgr, taskId));
//			
//			QueryResult<TaskTimelines> results = taskTimelineService.queryTaskTimelines(mgr, null, 15, null, null, Arrays.asList(new String[] {taskId}),SortType.lastCommented, SortDirection.DESC);
//			List<TaskTimelines> list = results.getResultList();
//			String nextPageToken = results.getNextPageToken();
//			CollectionResponse<TaskTimelines> timelineResults = CollectionResponse.<TaskTimelines>builder().setItems(list).setNextPageToken(nextPageToken).build();
//			
//			taskItems.put(ITEM_TIMELINES, timelineResults);
//			taskItems.put(ITEM_LABELS, taskLabelService.listTaskLabels(mgr, task.getBoardId()));
//			
//			return taskItems;
//		} catch (Exception ex) {
//			LOG.warning("[getTaskItems] : "+ex.getMessage());
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}

//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}