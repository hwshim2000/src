package net.forecs.coconut.endpoint.workspace;

//@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
//@RequiresUser
public class TaskHistoryServiceAPI {
//	private final ITaskHistoryService taskHistoryService;
//
//	@Inject
//	public TaskHistoryServiceAPI(ITaskHistoryService taskHistoryService) {
//		this.taskHistoryService = taskHistoryService;
//	}

	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "listTaskWikiHistories", path = "tasks/wiki/histories", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<TaskHistories> listTaskWikiHistories(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.taskId) String taskId) throws Exception {
//		if (StringUtils.isNotBlank(taskId)) {
//			CommonService.validNamespace(taskId);
//		}
//		QueryResult<TaskHistories> queryResult = taskHistoryService.listTaskHistories(cursorString, limit, taskId);
//		List<TaskHistories> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<TaskHistories> builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getTaskWikiHistory", path = "tasks/wiki/histories/{taskHistoryId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public TaskHistories getTaskWikiHistory(@Named(FLD.taskHistoryId) String taskHistoryId) throws UnavailableException {
//		CommonService.validNamespace(taskHistoryId);
//		return taskHistoryService.getTaskHistories(taskHistoryId);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "removeTaskWikiHistory", path = "tasks/wiki/histories/{taskHistoryId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeTaskWikiHistory(@Named(FLD.taskHistoryId) String taskHistoryId) throws Exception {
//		CommonService.validNamespace(taskHistoryId);
//		taskHistoryService.removeTaskHistories(taskHistoryId);
//	}

	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "compareWikiHistories", path = "tasks/wiki/histories/compare/{sourceHistoryId}/{targetHistoryId}", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public CompareResults compareWikiHistories(
//			@Named(FLD.sourceHistoryId) String sourceHistoryId,
//			@Named(FLD.targetHistoryId) String targetHistoryId,
//			@Nullable @Named(FLD.compareMode) CompareMode compareMode,
//			@Nullable @Named(FLD.insertedColor) String insertedColor,
//			@Nullable @Named(FLD.deletedColor) String deletedColor) throws UnavailableException {
//		CommonService.validNamespace(sourceHistoryId);
//		return taskHistoryService.compareWikiHistories(sourceHistoryId, targetHistoryId, compareMode, insertedColor, deletedColor);
//	}
}