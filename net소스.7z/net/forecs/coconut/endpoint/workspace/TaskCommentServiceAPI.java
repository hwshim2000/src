package net.forecs.coconut.endpoint.workspace;

@Deprecated
//@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
//@RequiresUser
public class TaskCommentServiceAPI {
//	private final ITaskCommentService taskCommentService;
//
//	@Inject
//	public TaskCommentServiceAPI(ITaskCommentService taskCommentService) {
//		this.taskCommentService = taskCommentService;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "listTaskWikiComments", path = "tasks/wiki/comments", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<TaskComments> listTaskWikiComments(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.taskId) String taskId) throws Exception {
//		if (StringUtils.isNotBlank(taskId)) {
//			CommonService.validNamespace(taskId);
//		}
//		QueryResult<TaskComments> queryResult = taskCommentService.listTaskComments(cursorString, limit, taskId);
//		List<TaskComments> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<TaskComments>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}

//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "getTaskWikiComment", path = "tasks/wiki/comments/{commentId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public TaskComments getTaskWikiComment(@Named(FLD.commentId) String commentId) throws Exception {
//		CommonService.validNamespace(commentId);
//		return taskCommentService.getTaskComments(commentId);
//	}
//
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "insertTaskWikiComment", path = "tasks/wiki/comments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public TaskComments insertTaskWikiComment(@Nullable @Named(FLD.parentTaskCommentId) String parentTaskCommentId,
//			TaskComments taskComment) throws Exception {
//		CommonService.validNamespace(taskComment.getTaskId());
//		return taskCommentService.insertTaskComments(parentTaskCommentId, taskComment);
//	}
//
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "updateTaskWikiComment", path = "tasks/wiki/comments", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public TaskComments updateTaskWikiComment(TaskComments taskComment) throws Exception {
//		CommonService.validNamespace(taskComment);
//		return taskCommentService.updateTaskComments(taskComment);
//	}
//
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "removeTaskWikiComment", path = "tasks/wiki/comments/{commentId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeTaskWikiComment(@Named(FLD.commentId) String commentId) throws Exception {
//		CommonService.validNamespace(commentId);
//		taskCommentService.removeTaskComments(commentId);
//	}
}