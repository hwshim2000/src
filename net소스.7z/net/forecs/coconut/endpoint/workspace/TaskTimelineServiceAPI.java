package net.forecs.coconut.endpoint.workspace;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.LinkParseOptions;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.rest.HtmlParser;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.workspace.TaskTimelines;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;


@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class TaskTimelineServiceAPI {
	private final ITaskTimelineService taskTimelineService;

	@Inject
	public TaskTimelineServiceAPI(ITaskTimelineService taskTimelineService) {
		this.taskTimelineService = taskTimelineService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryTaskTimelines", path = "tasks/timelines/query", httpMethod = HttpMethod.POST)
	@RequiresUser
	public CollectionResponse<TaskTimelines> queryTaskTimelines(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.taskId) String taskId,
			@Nullable @Named(FLD.userIdList) List<String> userIdList,
			@Nullable @Named(FLD.sortType) SortType sortType,
			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection) throws Exception {
		CommonService.validNamespace(taskId);
		List<String> taskIdList = new ArrayList<String>();
		taskIdList.add(taskId);
		sortType = SortType.lastCommented;
		sortDirection = SortDirection.DESC;
		QueryResult<TaskTimelines> queryResult = taskTimelineService.queryTaskTimelines(cursorString, limit, null, taskIdList, userIdList, sortType, sortDirection);
		List<TaskTimelines> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<TaskTimelines>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "getTaskTimelines", path = "tasks/timelines/{taskTimelineId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public TaskTimelines getTaskTimelines(@Named(FLD.taskTimelineId) String taskTimelineId) throws Exception {
		CommonService.validNamespace(taskTimelineId);
		return taskTimelineService.getTaskTimelines(taskTimelineId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "getParentTaskTimelines", path = "tasks/timelines/parent/{taskTimelineCommentId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public TaskTimelines getParentTaskTimelines(@Named(FLD.taskTimelineCommentId) String taskTimelineCommentId) throws Exception {
		CommonService.validNamespace(taskTimelineCommentId);
		return taskTimelineService.getParentTaskTimelines(taskTimelineCommentId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "insertTaskTimelines", path = "tasks/timelines", httpMethod = HttpMethod.POST)
	@RequiresUser
	public TaskTimelines insertTaskTimelines(TaskTimelines taskTimeline) throws Exception {
		CommonService.validNamespace(taskTimeline.getTaskId());
		return taskTimelineService.insertTaskTimelines(taskTimeline);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskTimelines", path = "tasks/timelines", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public TaskTimelines updateTaskTimelines(TaskTimelines taskTimeline) throws Exception {
		CommonService.validNamespace(taskTimeline);
		return taskTimelineService.updateTaskTimelines(taskTimeline);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeTaskTimelines", path = "tasks/timelines/{taskTimelineId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeTaskTimelines(@Named(FLD.taskTimelineId) String taskTimelineId) throws Exception {
		CommonService.validNamespace(taskTimelineId);
		taskTimelineService.removeTaskTimelines(taskTimelineId);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "isEvaluatedTaskTimeline", path = "tasks/timelines/{taskTimelineId}/isEvaluated", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Result isEvaluatedTaskTimeline(@Named(FLD.taskTimelineId) String taskTimelineId) throws UnavailableException {
//		CommonService.validNamespace(taskTimelineId);
//		return new Result(taskTimelineService.isEvaluatedTaskTimeline(taskTimelineId));
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "listEvaluateTaskTimelines", path = "tasks/timelines/evaluations", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public List<TaskTimelineScores> listEvaluateTaskTimelines(
//			@Nullable @Named(FLD.taskTimelineId) String taskTimelineId,
//			@Nullable @Named(FLD.evaluateType) EvaluateType evaluateType) throws Exception {
//		if (StringUtils.isNotBlank(taskTimelineId)) {
//			CommonService.validNamespace(taskTimelineId);
//		}
//		return taskTimelineService.listEvaluateTaskTimelines(taskTimelineId, evaluateType);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "evaluateTaskTimelines", path = "tasks/timelines/{taskTimelineId}/evaluate", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public TaskTimelines evaluateTaskTimeline(@Named(FLD.taskTimelineId) String taskTimelineId, @Named(FLD.evaluateType) EvaluateType evaluateType) throws Exception {
//		CommonService.validNamespace(taskTimelineId);
//		return taskTimelineService.evaluateTaskTimeline(taskTimelineId, evaluateType);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "cancelEvaluateTaskTimelines", path = "tasks/timelines/{taskTimelineId}/cancelEvaluate", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public TaskTimelines cancelEvaluateTaskTimelines(@Named(FLD.taskTimelineId) String taskTimelineId) throws Exception {
//		CommonService.validNamespace(taskTimelineId);
//		return taskTimelineService.cancelEvaluateTaskTimeline(taskTimelineId);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "addTaskTimelineAttachment", path = "tasks/timelines/{taskTimelineId}/attachments", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Attachments addTaskTimelineAttachment(@Named(FLD.taskTimelineId) String taskTimelineId, Attachments attachment) throws Exception {
		CommonService.validNamespace(taskTimelineId);
		return taskTimelineService.addTaskTimelineAttachment(taskTimelineId, attachment);
	}

	// ------------- Current service ----------------
	@ApiMethod(name="removeTaskTimelineAttachment", path = "tasks/timelines/{taskTimelineId}/attachments/{attachmentId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public Attachments removeTaskTimelineAttachment(@Named(FLD.taskTimelineId) String taskTimelineId, @Named(FLD.attachmentId) String attachmentId) throws Exception {
		CommonService.validNamespace(taskTimelineId);
		return taskTimelineService.removeTaskTimelineAttachment(taskTimelineId, attachmentId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "parse", path = "parse", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Map<String, Object> parseLink(@Named(FLD.source) String source, LinkParseOptions options, HttpServletRequest request) throws Exception {
		if (options.isUseUserAgent()) {
			options.setUserAgent(request.getHeader("User-Agent"));
		}
		return HtmlParser.execute(source, options);
	}
	
	@ApiMethod(name = "copyTaskTimelines", path = "tasks/timelines/copy", httpMethod = HttpMethod.POST)
	@RequiresUser
	public TaskTimelines copyTaskTimelines(@Named(FLD.taskTimelineId) String taskTimelineId, @Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskTimelineId);
		return taskTimelineService.copyTaskTimelines(taskTimelineId, taskId);
	}
}