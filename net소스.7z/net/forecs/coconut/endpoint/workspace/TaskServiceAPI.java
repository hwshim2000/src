package net.forecs.coconut.endpoint.workspace;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.EditPermission;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.shiro.annotation.RequiresOwner;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.appengine.api.datastore.Text;


@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class TaskServiceAPI {
//	private static final Logger LOG = Logger.getLogger(TaskServiceAPI.class.getName());
	private static final String Y = "Y";
	private static final String N = "N";


	private final ITaskService taskService;

	@Inject
	public TaskServiceAPI(ITaskService taskService) {
		this.taskService = taskService;
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "countTasks", path = "tasks/count", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public Result countTasks(
//			@Nullable @Named(FLD.domainId) String domainId,
//			@Nullable @Named(FLD.boardId) String boardId,
//			@Nullable @Named(FLD.tasklistId) String tasklistId,
//			@Nullable @Named(FLD.userIdList) List<String> userIdList) throws Exception {
//		String archiveYN = N;
//		return new Result(taskService.countTasks(domainId, boardId, tasklistId, userIdList, archiveYN));
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "listTasks", path = "tasks", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Tasks> listTasks(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.boardId) String boardId,
//			@Nullable @Named(FLD.tasklistId) String tasklistId) throws Exception {
//		if (StringUtils.isNotBlank(boardId)) {
//			CommonService.validNamespace(boardId);
//		}
//		QueryResult<Tasks> queryResult = taskService.listTasks(cursorString, limit, boardId, tasklistId);
//		List<Tasks> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//
//		return CollectionResponse.<Tasks>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "listSubscribedTaskIds", path = "tasks/subscribedIds", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<String> listSubscribedTaskIds(
//			@Nullable @Named(FLD.domainId) String domainId,
//			@Named(FLD.boardId) String boardId, @Nullable @Named(FLD.userId) String userId) throws Exception {
//		CommonService.validNamespace(boardId);
//		List<String> queryResult = taskService.listSubscribedTaskIds(boardId, userId);
//		return CollectionResponse.<String>builder().setItems(queryResult).setNextPageToken(null).build();
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listMySubscribedTaskIds", path = "tasks/mySubscribedIds", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<String> listMySubscribedTaskIds(
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.boardId) String boardId) throws Exception {
		if (StringUtils.isNotBlank(boardId)) { CommonService.validNamespace(boardId); }
		List<String> queryResult = taskService.listMySubscribedTaskIds(boardId);
		return CollectionResponse.<String>builder().setItems(queryResult).setNextPageToken(null).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "isMySubscribedTask", path = "tasks/isMySubscribed", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result isMySubscribedTask(@Named(FLD.taskId) String taskId) throws UnavailableException {
		CommonService.validNamespace(taskId);
		boolean subscribed = taskService.isMySubscribedTask(taskId);
		return new Result(subscribed);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryTasks", path = "tasks/unarchived", httpMethod = HttpMethod.POST)
	@RequiresUser
	public CollectionResponse<Tasks> queryTasks(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.domainId) String domainId,
			@Named(FLD.boardId) String boardId,
			@Nullable @Named(FLD.sortType) SortType sortType,
			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection
			) throws Exception {
		CommonService.validNamespace(boardId);
		QueryResult<Tasks> queryResult = taskService.queryTasks(cursorString, limit, Arrays.asList(new String[]{ boardId }), N, sortType, sortDirection);

		List<Tasks> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Tasks>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "queryMyTasks", path = "tasks/unarchived/my", httpMethod = HttpMethod.POST)
	@RequiresUser
	public CollectionResponse<Tasks> queryMyTasks(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.sortType) SortType sortType,
			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection
			) throws Exception {
		Users loginUser = CommonService.getCurrentUser();
		String userId = loginUser.getUserId();
		CommonService.validNamespace(userId);
		Set<String> includes = new HashSet<String>();
		includes.add(TaskService.QUERY_INCLUDE_MEMBER_IDS);
		QueryResult<Tasks> queryResult = taskService.queryUserTasks(cursorString, limit, userId, N, sortType, sortDirection, includes);

		List<Tasks> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Tasks>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "listUserTaskIds", path = "tasks/users/taskIds", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<String> listUserTaskIds(
			@Named(FLD.boardIdList) List<String> boardIdList,
			@Named(FLD.userIdList) List<String> userIdList) throws Exception {
		Users loginUser = CommonService.getCurrentUser();
		String userId = loginUser.getUserId();
		CommonService.validNamespace(userId);
		return taskService.listUserTaskIds(boardIdList, userIdList);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryArchivedTasks", path = "tasks/archived", httpMethod = HttpMethod.POST)
	@RequiresUser
	public CollectionResponse<Tasks> queryArchivedTasks(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.domainId) String domainId,
			@Named(FLD.boardIdList) List<String> boardIdList,
			@Nullable @Named(FLD.sortType) SortType sortType,
			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection
			) throws Exception {
		CommonService.validNamespace(boardIdList.get(0));
		QueryResult<Tasks> queryResult = taskService.queryTasks(cursorString, limit, boardIdList, Y, sortType, sortDirection);

		List<Tasks> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Tasks>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getAssignedMemberList", path = "tasks/{taskId}/assignedMembers", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Users> getAssignedMemberList(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		List<Users> list = taskService.listTasksMembers(taskId);
		return CollectionResponse.<Users>builder().setItems(list).build();
	}
	// ------------- Current service ----------------
	@ApiMethod(name = "getUnassignedMemberList", path = "tasks/{taskId}/unassignedMembers", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Users> getUnassignedMemberList(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		List<Users> list = taskService.listTasksUnassignedMembers(taskId);
		return CollectionResponse.<Users>builder().setItems(list).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getTask", path = "tasks/{taskId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Tasks getTask(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.getTasksDetail(taskId);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "taskItems", path = "tasks/items/{taskId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Map<String, Object> getTaskItems(@Named(FLD.taskId) String taskId) throws Exception {
//		CommonService.validNamespace(taskId);
//		return taskService.getTaskItems(taskId);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "insertTasks", path = "tasks", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Tasks insertTasks(Tasks task) throws Exception {
		CommonService.validNamespace(task.getBoardId());
		return taskService.insertTasks(task);
	}

//	@ApiMethod(name = "updateTasks", path = "tasks", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Tasks updateTasks(Tasks task) throws Exception {
//		CommonService.validNamespace(task);
//		return taskService.updateTasks(task);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "insertOrUpdateTaskEvent", path = "tasks/events", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Events insertOrUpdateTaskEvent(Tasks task) throws Exception {
//		CommonService.validNamespace(task);
//		return taskService.insertOrUpdateTaskEvent(task);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskEditChecklistPermission", path = "tasks/permissions/checklists", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskEditChecklistPermission(
			@Named(FLD.taskId) String taskId,
			@Named(FLD.editChecklistPermission) EditPermission editChecklistPermission
			) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskEditChecklistPermission(taskId, editChecklistPermission);
		return new Result(task != null);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskEditDetailPermission", path = "tasks/permissions/detail", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskEditDetailPermission(
			@Named(FLD.taskId) String taskId,
			@Named(FLD.editDetailPermission) EditPermission editDetailPermission
			) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskEditDetailPermission(taskId, editDetailPermission);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskTitle", path = "tasks/{taskId}/title", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskTitle(@Named(FLD.taskId) String taskId, @Named(FLD.title) String title) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskTitle(taskId, title);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskDescription", path = "tasks/{taskId}/description", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskDescription(@Named(FLD.taskId) String taskId, Text description) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskDescription(taskId, description);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTasksWiki", path = "tasks/{taskId}/wiki", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTasksWiki(@Named(FLD.taskId) String taskId, Text wiki) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTasksWiki(taskId, wiki);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskStartDate", path = "tasks/{taskId}/startDate", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskStartDate(@Named(FLD.taskId) String taskId, @Nullable @Named(FLD.startDate) Date startDate) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskStartDate(taskId, startDate);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskDueDate", path = "tasks/{taskId}/dueDate", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskDueDate(@Named(FLD.taskId) String taskId, @Nullable @Named(FLD.dueDate) Date dueDate) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskDueDate(taskId, dueDate);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskImportance", path = "tasks/{taskId}/importance", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskImportance(@Named(FLD.taskId) String taskId, @Named(FLD.importance) String importance) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskImportance(taskId, importance);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskLabelList", path = "tasks/{taskId}/labels", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskLabelList(@Named(FLD.taskId) String taskId, @Nullable @Named(FLD.taskLabelIds) List<String> taskLabelIds) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskLabelList(taskId, taskLabelIds);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskSubscription", path = "tasks/{taskId}/subscription", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskSubscription(@Named(FLD.taskId) String taskId, @Named(FLD.subscribe) boolean subscribe) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskSubscription(taskId, subscribe);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskDisplayInCalendar", path = "tasks/{taskId}/displayInCalendar", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Result updateTaskDisplayInCalendar(@Named(FLD.taskId) String taskId, @Named(FLD.displayInCalendarYN) String displayInCalendarYN) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.updateTaskDisplayInCalendar(taskId, displayInCalendarYN);
		return new Result(task != null);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeTasks", path = "tasks/{taskId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeTasks(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.removeTasks(taskId);
	}

	// ------------- Current service ----------------
	//@Deprecated
//	@ApiMethod(name = "moveTasks", path = "tasks/{taskId}/move/{tasklistId}", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	@Deprecated
//	public Result moveTask(@Named(FLD.taskId) String taskId, @Named(FLD.tasklistId) String tasklistId) throws Exception {
//		CommonService.validNamespace(taskId);
//		Tasks task = taskService.moveTask(taskId, tasklistId);
//		return new Result(task != null);
//	}
	@ApiMethod(name = "moveStage", path = "tasks/{taskId}/stages/move/{taskStage}", httpMethod = HttpMethod.PUT)
	//@RequiresOwner(clazz = Tasks.class, objectId = "{taskId}")
	@RequiresUser
	public Result moveStage(@Named(FLD.taskId) String taskId, @Named(FLD.taskStage) String taskStage) throws Exception {
		CommonService.validNamespace(taskId);
		Tasks task = taskService.moveStage(taskId, taskStage);
		return new Result(task != null);
	}
	@ApiMethod(name = "moveStageList", path = "tasks/stages/move/{taskStage}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	//@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
	public List<Tasks> moveStageList(@Named(FLD.boardId) String boardId,
			@Named(FLD.taskIds) List<String> taskIds,
			@Named(FLD.taskStage) String taskStage) throws Exception {
		CommonService.validNamespace(boardId);
		return taskService.moveStageList(taskIds, taskStage);
	}
//	@ApiMethod(name = "batchMoveStage", path = "tasks/stages/move/batch/{fromTaskStage}/{toTaskStage}", httpMethod = HttpMethod.PUT)
//	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
//	public List<Tasks> batchMoveStage(@Named(FLD.boardId) String boardId,
//			@Named(FLD.fromTaskStage) String fromTaskStage,
//			@Named(FLD.toTaskStage) String toTaskStage) throws Exception {
//		return taskService.batchMoveStage(boardId, fromTaskStage, toTaskStage);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "recoverTaskWiki", path = "tasks/{taskId}/recover/{tasklistId}", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Result recoverTaskWiki(@Named(FLD.taskId) String taskId, @Named(FLD.taskHistoryId) String taskHistoryId) throws Exception {
//		CommonService.validNamespace(taskId);
//		Tasks task = taskService.recoverTaskWiki(taskId, taskHistoryId);
//		return new Result(task.getWiki());
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "assignMember", path = "tasks/{taskId}/assignMember/{userId}", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Users assignMember(@Named(FLD.taskId) String taskId, @Named(FLD.userId) String userId, @Nullable @Named(FLD.auth) Auth auth) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.assignMember(taskId, userId, auth);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "assignMemberList", path = "tasks/{taskId}/assignMemberList", httpMethod = HttpMethod.POST)
	@RequiresUser
	public List<Users> assignMemberList(@Named(FLD.taskId) String taskId, @Named(FLD.userIdList) List<String> userIdList, @Nullable @Named(FLD.auth) Auth auth) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.assignMemberList(taskId, userIdList, auth);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "unassignMember", path = "tasks/{taskId}/unassignMember/{userId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public Users unassignMember(@Named(FLD.taskId) String taskId, @Named(FLD.userId) String userId) throws Exception {
//		CommonService.validNamespace(taskId);
//		return taskService.unassignMember(taskId, userId);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "unassignMemberList", path = "tasks/{taskId}/unassignMemberList", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void unassignMemberList(@Named(FLD.taskId) String taskId, @Named(FLD.userIdList) List<String> userIdList) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.unassignMemberList(taskId, userIdList);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "changeOwnership", path = "tasks/{taskId}/changeOwnership/{targetUserId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	// chulhong.kim 2016-01-18 : The policy of changeOwnership has been changed
	//@RequiresOwner(clazz = Tasks.class, objectId = "{taskId}")
	public void changeOwnership(@Named(FLD.taskId) String taskId, @Named(FLD.targetUserId) String targetUserId) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.changeOwnership(taskId, targetUserId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "isAvailableMemberAuth", path = "tasks/{taskId}/isAvailableMember/{userId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result isAvailableMemberAuth(@Named(FLD.taskId) String taskId, @Named(FLD.userId) String userId) throws UnavailableException {
		CommonService.validNamespace(taskId);
		if (StringUtils.isEmpty(userId)) {
			Users user = CommonService.getCurrentUser();
			userId = user.getUserId();
		}
		
		return new Result(taskService.isAvailableMemberAuth(taskId, userId));
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "archiveTasks", path = "tasks/{taskId}/archive", httpMethod = HttpMethod.POST)
	@RequiresUser
	@RequiresOwner(clazz = Tasks.class, objectId = "{taskId}")
	public void archiveTasks(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.archiveTask(taskId, Y);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "unarchiveTasks", path = "tasks/{taskId}/unarchive", httpMethod = HttpMethod.POST)
	@RequiresUser
	@RequiresOwner(clazz = Tasks.class, objectId = "{taskId}")
	public Tasks unarchiveTasks(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.archiveTask(taskId, N);
	}
	
	@ApiMethod(name = "archiveTaskList", path = "tasks/archive/tasklists", httpMethod = HttpMethod.POST)
	@RequiresUser
	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
	public void archiveTaskList(@Named(FLD.boardId) String boardId, @Named(FLD.tasklists) List<String> tasklists) throws Exception {
		CommonService.validNamespace(boardId);
		taskService.archiveTaskList(tasklists, Y);
	}
	
	@ApiMethod(name = "unarchiveTaskList", path = "tasks/unarchive/tasklists", httpMethod = HttpMethod.POST)
	@RequiresUser
	@RequiresOwner(clazz = Boards.class, objectId = "{boardId}")
	public List<Tasks> unarchiveTaskList(@Named(FLD.boardId) String boardId, @Named(FLD.tasklists) List<String> tasklists) throws Exception {
		CommonService.validNamespace(boardId);
		return taskService.archiveTaskList(tasklists, N);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "removeTaskAttachment", path = "tasks/{taskId}/attachments/{attachmentId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeTaskAttachment(@Named(FLD.taskId) String taskId, @Named(FLD.attachmentId) String attachmentId) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.removeTaskAttachment(taskId, attachmentId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "addTaskAttachment", path = "tasks/{taskId}/attachments", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Attachments addTaskAttachment(@Named(FLD.taskId) String taskId, Attachments attachment) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.addTaskAttachment(taskId, attachment);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "addTaskFinalAttachments", path = "tasks/{taskId}/finalAttachments/{attachmentId}", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Tasks addTaskFinalAttachments(@Named(FLD.taskId) String taskId, @Named(FLD.attachmentId) String attachmentId) throws Exception{
		CommonService.validNamespace(taskId);
		return taskService.addTaskFinalAttachments(taskId, attachmentId);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "removeTaskFinalAttachments", path = "tasks/{taskId}/finalAttachments/{attachmentId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeTaskFinalAttachments(@Named(FLD.taskId) String taskId, @Named(FLD.attachmentId) String attachmentId) throws Exception {
//		CommonService.validNamespace(taskId);
//		taskService.removeTaskFinalAttachments(taskId, attachmentId);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "replaceTaskFinalAttachments", path = "tasks/{taskId}/replaceAttachments/{oldAttachmentId}/{newAttachmentId}", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public void replaceTaskFinalAttachments(@Named(FLD.taskId) String taskId,
//			@Named(FLD.oldAttachmentId) String oldAttachmentId,
//			@Named(FLD.newAttachmentId) String newAttachmentId) throws Exception {
//		CommonService.validNamespace(taskId);
//		taskService.replaceTaskFinalAttachments(taskId, oldAttachmentId, newAttachmentId);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "activeYNTaskEvent", path = "tasks/{taskId}/events/activate", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public void activeYNTaskEvent(@Named(FLD.taskId) String taskId, @Named(FLD.activeYN) String activeYN) throws Exception {
//		CommonService.validNamespace(taskId);
//		taskService.activeYNTaskEvent(taskId, activeYN);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "permanentRemoveTasks", path = "tasks/{taskId}/permanent", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	@RequiresOwner(clazz = Tasks.class, objectId = "{taskId}")
//	public void permanentRemoveTasks(@Named(FLD.taskId) String taskId) throws Exception {
//		CommonService.validNamespace(taskId);
//		taskService.permanentRemoveTasks(taskId);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "isLockTaskWiki", path = "tasks/{taskId}/wiki/isLock", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result isLockTaskWiki(@Named(FLD.taskId) String taskId) throws UnavailableException {
		CommonService.validNamespace(taskId);
		return new Result(taskService.isLockTaskWiki(taskId));
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "lockTaskWiki", path = "tasks/{taskId}/wiki/lock", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Map<String, Object> lockTaskWiki(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.lockTaskWiki(taskId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "unlockTaskWiki", path = "tasks/{taskId}/wiki/unlock", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public void unlockTaskWiki(@Named(FLD.taskId) String taskId) throws UnavailableException {
		CommonService.validNamespace(taskId);
		taskService.unlockTaskWiki(taskId);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "listMyTaskIds", path = "tasks/myTaskIds", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public List<String> listMyTaskIds(@Named(FLD.domainId) String domainId, @Named(FLD.boardIdList) List<String> boardIdList) throws Exception {
//		CommonService.validNamespace(domainId);
//		
//		return taskService.listMyTaskIds(boardIdList);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "openTask", path = "tasks/{taskId}/open", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Tasks openTask(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.openTask(taskId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "closeTask", path = "tasks/{taskId}/close", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Tasks closeTask(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.closeTask(taskId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "requestMembers", path = "tasks/{taskId}/requestMembers", httpMethod = HttpMethod.POST)
	@RequiresUser
	public void requestMembers(@Named(FLD.taskId) String taskId, @Nullable @Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.requestMembers(taskId, userId);
	}
	// ------------- Current service ----------------
	@ApiMethod(name = "confirmMembers", path = "tasks/{taskId}/confirmMembers/{userId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public void confirmMembers(@Named(FLD.taskId) String taskId, @Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.confirmMembers(taskId, userId);
	}
	// ------------- Current service ----------------
	@ApiMethod(name = "rejectMembers", path = "tasks/{taskId}/rejectMembers/{userId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void rejectMembers(@Named(FLD.taskId) String taskId, @Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(taskId);
		taskService.rejectMembers(taskId, userId);
	}
	
	@ApiMethod(name = "requestDowonloadKey", path = "tasks/download/key/{taskId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result requestDowonload(@Named(FLD.taskId) String taskId) throws Exception {
		CommonService.validNamespace(taskId);
		return new Result(MemcacheManager.createAccessKey(taskId));
	}
	
	@ApiMethod(name = "moveTask", path = "tasks/move/boards/{boardId}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Tasks moveTask(@Named(FLD.taskId) String taskId, @Named(FLD.boardId) String boardId, @Named(FLD.taskStage) String taskStage) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.moveTask(taskId, boardId, taskStage);
	}
	
	@ApiMethod(name = "copyTask", path = "tasks/copy", httpMethod = HttpMethod.POST)
	@RequiresUser
	public Tasks copyTask(@Named(FLD.taskId) String taskId, @Named(FLD.boardId) String boardId, @Named(FLD.taskStage) String taskStage) throws Exception {
		CommonService.validNamespace(taskId);
		return taskService.copyTask(taskId, boardId, taskStage);
	}	
}
