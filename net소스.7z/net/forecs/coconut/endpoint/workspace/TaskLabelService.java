package net.forecs.coconut.endpoint.workspace;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Activities.ActivityData;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskLabelMap;
import net.forecs.coconut.entity.workspace.TaskLabels;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.BadRequestException;


public class TaskLabelService extends CommonService implements ITaskLabelService {
	private static final Logger LOG = Logger.getLogger(TaskLabelService.class.getName());
	
	private final IBoardService boardService;
	private final IActivityService activityService;
	private final ITaskLabelMapService taskLabelMapService;

	@Inject
	public TaskLabelService(IBoardService boardService,
			IActivityService activityService,
			ITaskLabelMapService taskLabelMapService) {
		this.boardService = boardService;
		this.activityService = activityService;
		this.taskLabelMapService = taskLabelMapService;
	}

	@Override
	public List<TaskLabels> listTaskLabels(String boardId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return listTaskLabels(mgr, boardId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<TaskLabels> listTaskLabels(EntityManager mgr, String boardId) throws Exception {
		DsQuery<TaskLabels> dsQuery = new DsQuery<>(TaskLabels.class)
				.eq(FLD.boardId, boardId);

		return dsQuery.execute(mgr);
	}

	private List<TaskLabels> listTaskLabels(List<String> taskLabelIds) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return this.listTaskLabels(mgr, taskLabelIds);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<TaskLabels> listTaskLabels(EntityManager mgr, List<String> taskLabelIds) throws Exception {
		List<TaskLabels> taskLabelList = new ArrayList<TaskLabels>();
		
		if (taskLabelIds != null) {
			for (TaskLabels taskLabel : batchListByKey(mgr, TaskLabels.class, taskLabelIds)) {
				if (isValid(taskLabel)) {
					taskLabelList.add(taskLabel);
				}
			}
		}

		return taskLabelList;
	}

	@Override
	public TaskLabels insertTaskLabels(TaskLabels taskLabel) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return insertTaskLabels(mgr, taskLabel);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private TaskLabels insertTaskLabels(EntityManager mgr, TaskLabels taskLabel) throws Exception {
		try {
			Users loginUser = getCurrentUser();

			if (StringUtils.isBlank(taskLabel.getBoardId())) {
				throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Require boardId."));
			}

			if (StringUtils.isBlank(taskLabel.getColor())) {
				throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Require color."));
			}

			taskLabel.setKey(KeyUtil.createTaskLabelKey(taskLabel));
			taskLabel.setCreator(loginUser.getUserId());

			if (contains(mgr, TaskLabels.class, taskLabel.getTaskLabelId())) {
				taskLabel.setDeleted(null);
				taskLabel.setDeleteYN(N);

				doMergeTransaction(mgr, taskLabel);
				//throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(TaskLabels.class));
			} else {
				doPersistTransaction(mgr, taskLabel);
			}

			try {
				Boards board = boardService.getBoards(mgr, taskLabel.getBoardId());
				ActivityData activityData = new ActivityData(null, taskLabel);
				Activities activity = activityService.createBoardActivity(board, activityData,
						ActivityType.CREATED_LABEL, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Activity is not a critical part of application.
			}
			
			return taskLabel;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public TaskLabels updateTaskLabels(TaskLabels taskLabel) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return updateTaskLabels(mgr, taskLabel);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private TaskLabels updateTaskLabels(EntityManager mgr, TaskLabels taskLabel) throws Exception {
		try {
			TaskLabels originTaskLabel = taskLabel;
			valid(originTaskLabel);

			ActivityData activityData = new ActivityData(
					CopyUtil.clone(originTaskLabel), originTaskLabel);
			
			doMergeTransaction(mgr, originTaskLabel);

			try {
				Boards board = boardService.getBoards(mgr, taskLabel.getBoardId());
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createBoardActivity(board, activityData,
						ActivityType.UPDATE_LABEL, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception e) {
				LOG.warning(e.getMessage());	// Ignored. Activity is not a critical part of application.
			}
			
			return originTaskLabel;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public void removeTaskLabels(String taskLabelId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			List<TaskLabelMap> taskLabelList = taskLabelMapService.listTaskLabelMapByValue(mgr, taskLabelId);

			if (taskLabelList != null && 0 < taskLabelList.size()) {
				throw new UnavailableException("This label is being used by other tasks.");
			}
			
			TaskLabels taskLabel = doFind(mgr, TaskLabels.class, taskLabelId);
			doRemoveTransaction(mgr, taskLabel);
			
			try {
				ActivityData activityData = new ActivityData(taskLabel, null);
				Boards board = boardService.getBoards(mgr, taskLabel.getBoardId());
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createBoardActivity(board, activityData,
						ActivityType.DELETED_LABEL, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) {
				
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void forceRemoveTaskLabels(String taskLabelId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			
			TaskLabels taskLabel = doFind(mgr, TaskLabels.class, taskLabelId);
			doRemoveTransaction(mgr, taskLabel);
			
			taskLabelMapService.removeLabelMap(mgr, taskLabelId);
			
			try {
				ActivityData activityData = new ActivityData(taskLabel, null);
				Boards board = boardService.getBoards(mgr, taskLabel.getBoardId());
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createBoardActivity(board, activityData,
						ActivityType.DELETED_LABEL, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) {
				
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<TaskLabels> listTaskLabelsTagged(EntityManager mgr, String taskId) throws Exception {
		List<String> taskLabelIds = new ArrayList<String>();

		List<TaskLabelMap> taskLabelMaps = taskLabelMapService.listTaskLabelMap(mgr, taskId);
		for (TaskLabelMap map : taskLabelMaps) {
			taskLabelIds.add(map.getTaskLabelId());
		}

		return listTaskLabels(mgr, taskLabelIds);
	}

	@Override
	public Map<String, List<TaskLabels>> batchMapChildTaskLabels(EntityManager mgr, List<String> taskIdList) throws Exception {
		// 1. 부모 ID 목록에 포함된 모든 attachmentMap 데이터를 가져온다.
//		List<TaskLabelMap> taskLabelMapList = taskLabelMapService.listTaskLabelMap(mgr, taskIdList);
		List<TaskLabelMap> taskLabelMapList = null;
		if (taskIdList.size() == 1) {
			taskLabelMapList = listAll(mgr, TaskLabelMap.class);
		} else {
			taskLabelMapList = batchListByField(mgr, TaskLabelMap.class, taskIdList, FLD.taskId);
		}
		Map<String, List<TaskLabels>> labelListMap = new HashMap<String, List<TaskLabels>>();
		
		List<String> labelIdList = new ArrayList<String>();
		Map<String, List<String>> labelIdListMap = new HashMap<String, List<String>>();
		
		// 2. 가져온 모든 taskLabelMap에서  taskLabel ID 리스트를 만들고, 각 taskLabel의 부모(taskId) map을 만든다.
		for (TaskLabelMap map : taskLabelMapList) {
			if (taskIdList.size() > 1 && !taskIdList.contains(map.getTaskId())) { continue; }
			labelIdList.add(map.getTaskLabelId());
			if (!labelIdListMap.containsKey(map.getTaskId())) { labelIdListMap.put(map.getTaskId(), new ArrayList<String>()); }
			labelIdListMap.get(map.getTaskId()).add(map.getTaskLabelId());
		}
		
		// 3. taskLabelId 리스트에 해당하는 모든 taskLabel를 가져온다.
		List<TaskLabels> results = batchListByKey(mgr, TaskLabels.class, labelIdList);
		Map<String, TaskLabels> resultsMap = new HashMap<String, TaskLabels>();
		
		// 4. taskLabel ID 에 대응하는 map 데이터를 만든다.
		// (taskLabelMap과는 별개의 값이다. 나중에 각 task(parent)에 해당하는taskLabel를 찾아서 넣어주기 위한 map 데이터이다)
		for (TaskLabels label : results) {
			if (!resultsMap.containsKey(label.getTaskLabelId())) { resultsMap.put(label.getTaskLabelId(), label); }
		}
		 
		// 5. taskId - taskLabel ID List 에 mapping
		// 2단계에서 만든 taskIdListMap을 순환하면서 taskId에 대응하는 살제 taskLabel를 찾아 넣어준다.
		for (Map.Entry<String, List<String>> entry : labelIdListMap.entrySet()) {
			String key = entry.getKey();
			if (!labelListMap.containsKey(key)) { labelListMap.put(key, new ArrayList<TaskLabels>()); }
			for (String val : entry.getValue()) {
				TaskLabels label = resultsMap.get(val);
				if (label != null) { labelListMap.get(key).add(label); }
			}
		}
		
		// 6. 최종으로 taskId별 taskLabel List를 리턴한다.
		return labelListMap;
	}

	@Override
	public List<TaskLabels> updateTaskLabelsTagged(String taskId, List<String> taskLabelIds) throws Exception {
		List<TaskLabelMap> taskLabelMaps = taskLabelMapService.updateTaskLabelMap(taskId, taskLabelIds);
		taskLabelIds.clear();
		for (TaskLabelMap map : taskLabelMaps) {
			taskLabelIds.add(map.getTaskLabelId());
		}
		return listTaskLabels(taskLabelIds);
	}

	@Override
	public void removeTaskLabelsTagged(String taskId) throws Exception {
		taskLabelMapService.removeTaskLabelMap(taskId);
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public TaskLabels getTaskLabels(String taskLabelId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, TaskLabels.class, taskLabelId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<TaskLabels> listTaskLabelsTagged(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return this.listTaskLabelsTagged(mgr, taskId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
