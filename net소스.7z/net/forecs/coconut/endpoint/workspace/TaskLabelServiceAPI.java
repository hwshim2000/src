package net.forecs.coconut.endpoint.workspace;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.workspace.TaskLabels;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;


@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class TaskLabelServiceAPI {
	private final ITaskLabelService taskLabelService;

	@Inject
	public TaskLabelServiceAPI(ITaskLabelService taskLabelService) {
		this.taskLabelService = taskLabelService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listTaskLabels", path = "tasks/labels", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<TaskLabels> listTaskLabels(@Named(FLD.boardId) String boardId) throws Exception {
		CommonService.validNamespace(boardId);
		List<TaskLabels> list = taskLabelService.listTaskLabels(boardId);
		return CollectionResponse.<TaskLabels>builder().setItems(list).build();
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getTaskLabels", path = "tasks/labels/{taskLabelId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public TaskLabels getTaskLabels(@Named(FLD.taskLabelId) String taskLabelId) throws UnavailableException {
//		CommonService.validNamespace(taskLabelId);
//		return taskLabelService.getTaskLabels(taskLabelId);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "insertTaskLabels", path = "tasks/labels", httpMethod = HttpMethod.POST)
	@RequiresUser
	public TaskLabels insertTaskLabels(TaskLabels taskLabel) throws Exception {
		CommonService.validNamespace(taskLabel.getBoardId());
		return taskLabelService.insertTaskLabels(taskLabel);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateTaskLabels", path = "tasks/labels", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public TaskLabels updateTaskLabels(TaskLabels taskLabel) throws Exception {
		CommonService.validNamespace(taskLabel);
		return taskLabelService.updateTaskLabels(taskLabel);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "removeTaskLabels", path = "tasks/labels/{taskLabelId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeTaskLabels(@Named(FLD.taskLabelId) String taskLabelId) throws Exception {
		CommonService.validNamespace(taskLabelId);
		taskLabelService.removeTaskLabels(taskLabelId);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "forceRemoveTaskLabels", path = "tasks/labels/force/{taskLabelId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void forceRemoveTaskLabels(@Named(FLD.taskLabelId) String taskLabelId) throws Exception {
		CommonService.validNamespace(taskLabelId);
		taskLabelService.forceRemoveTaskLabels(taskLabelId);
	}
}
