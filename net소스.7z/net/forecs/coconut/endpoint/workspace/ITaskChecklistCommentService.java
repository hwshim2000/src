package net.forecs.coconut.endpoint.workspace;

import net.forecs.coconut.endpoint.common.ICommonService;

@Deprecated
public interface ITaskChecklistCommentService extends ICommonService {
//	public abstract QueryResult<TaskChecklistComments> listTaskChecklistComments(
//			String cursorString,
//			Integer limit,
//			String taskId
//			) throws Exception;
//	public abstract TaskChecklistComments getTaskChecklistComments(String taskChecklistCommentId);
//	public abstract TaskChecklistComments insertTaskChecklistComments(
//			String parentTaskChecklistCommentId, 
//			TaskChecklistComments taskchecklistcomments) throws Exception;	
//	public abstract TaskChecklistComments updateTaskChecklistComments(
//			TaskChecklistComments taskchecklistcomments) throws Exception;
//	public abstract void removeTaskChecklistComments(String taskChecklistCommentId) throws Exception;
//	public abstract int bulkRemoveTaskChecklistComments(String taskId) throws Exception;
//	public abstract CommentIndex createOrUpdateTaskChecklistCommentIndex(TaskChecklistComments taskChecklistComment);
}
