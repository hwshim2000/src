package net.forecs.coconut.endpoint.workspace;


@Deprecated
//@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
//@RequiresUser
public class TaskChecklistCommentServiceAPI {
//	private final ITaskChecklistCommentService taskChecklistCommentService;
//
//	@Inject
//	public TaskChecklistCommentServiceAPI(ITaskChecklistCommentService taskChecklistCommentService) {
//		this.taskChecklistCommentService = taskChecklistCommentService;
//	}
//
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "listTaskChecklistComments", path = "tasks/checklists/comments", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<TaskChecklistComments> listTaskChecklistComments(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.taskId) String taskId) throws Exception {
//		if (StringUtils.isNotBlank(taskId)) {
//			CommonService.validNamespace(taskId);
//		}
//		QueryResult<TaskChecklistComments> queryResult = taskChecklistCommentService.listTaskChecklistComments(cursorString, limit, taskId);
//		List<TaskChecklistComments> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<TaskChecklistComments>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}
//
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "getTaskChecklistComments", path = "tasks/checklists/comments/{taskChecklistCommentId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public TaskChecklistComments getTaskChecklistComments(@Named(FLD.taskChecklistCommentId) String taskChecklistCommentId) throws UnavailableException {
//		CommonService.validNamespace(taskChecklistCommentId);
//		return taskChecklistCommentService.getTaskChecklistComments(taskChecklistCommentId);
//	}
//
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "insertTaskChecklistComments", path = "tasks/checklists/comments", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public TaskChecklistComments insertTaskChecklistComments(
//			@Nullable @Named(FLD.parentTaskChecklistCommentId) String parentTaskChecklistCommentId,
//			TaskChecklistComments taskchecklistcomment) throws Exception {
//		CommonService.validNamespace(taskchecklistcomment.getTaskId());
//		return taskChecklistCommentService.insertTaskChecklistComments(parentTaskChecklistCommentId, taskchecklistcomment);
//	}
//	
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "updateTaskChecklistComments", path = "tasks/checklists/comments", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public TaskChecklistComments updateTaskChecklistComments(
//			TaskChecklistComments taskchecklistcomment) throws Exception {
//		CommonService.validNamespace(taskchecklistcomment);
//		return taskChecklistCommentService.updateTaskChecklistComments(taskchecklistcomment);
//	}
//	
//	// ------------- Current service(Mobile) ----------------
//	@ApiMethod(name = "removeTaskChecklistComments", path = "tasks/checklists/comments/{taskChecklistCommentId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeTaskChecklistComments(@Named(FLD.taskChecklistCommentId) String taskChecklistCommentId) throws Exception {
//		CommonService.validNamespace(taskChecklistCommentId);
//		taskChecklistCommentService.removeTaskChecklistComments(taskChecklistCommentId);
//	}
}
