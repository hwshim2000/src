package net.forecs.coconut.endpoint.workspace;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.WORKSPACE_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.WORKSPACE_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class TaskChecklistHistoryServiceAPI {

	private final ITaskChecklistHistoryService taskChecklistHistoryService;
	
	@Inject
	public TaskChecklistHistoryServiceAPI(ITaskChecklistHistoryService taskChecklistHistoryService) {
		this.taskChecklistHistoryService = taskChecklistHistoryService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listTaskChecklistHistories", path = "tasks/checklists/histories", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<TaskChecklistHistories> listTaskChecklistHistories(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.taskId) String taskId) throws Exception {
		if (StringUtils.isNotBlank(taskId)) {
			CommonService.validNamespace(taskId);
		}
		QueryResult<TaskChecklistHistories> queryResult = taskChecklistHistoryService.listTaskChecklistHistories(cursorString, limit, taskId);
		List<TaskChecklistHistories> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<TaskChecklistHistories>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getTaskChecklistHistories", path = "tasks/checklists/histories/{taskChecklistHistoryId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public TaskChecklistHistories getTaskChecklistHistories(@Named(FLD.taskChecklistHistoryId) String taskChecklistHistoryId) throws UnavailableException {
//		CommonService.validNamespace(taskChecklistHistoryId);
//		return taskChecklistHistoryService.getTaskChecklistHistories(taskChecklistHistoryId);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "removeTaskChecklistHistories", path = "tasks/checklists/histories/{taskChecklistHistoryId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeTaskChecklistHistories(@Named(FLD.taskChecklistHistoryId) String taskChecklistHistoryId) throws Exception {
//		CommonService.validNamespace(taskChecklistHistoryId);
//		taskChecklistHistoryService.removeTaskChecklistHistories(taskChecklistHistoryId);
//	}
}
