package net.forecs.coconut.endpoint.workspace;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryOption;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.Tasks;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;


public class TaskChecklistService extends CommonService implements ITaskChecklistService {
	private static final Logger LOG = Logger.getLogger(TaskChecklistService.class.getName());
	
	private final ITaskChecklistHistoryService taskChecklistHistoryService;
	private final IActivityService activityService;
	private final ITaskService taskService;
	
	@Inject
	public TaskChecklistService(ITaskChecklistHistoryService taskChecklistHistoryService
			, IActivityService activityService, ITaskService taskService) {
		this.taskChecklistHistoryService = taskChecklistHistoryService;
		this.activityService = activityService;
		this.taskService = taskService;
	}

	@Override
	public List<TaskChecklists> listTaskChecklists(
			EntityManager mgr,
			String taskId,
			QueryOption queryOption
			) throws Exception {
		try {
			MemcacheManager<TaskChecklists, List<TaskChecklists>> mm = new MemcacheManager<>(TaskChecklists.class, MemcacheManager.keySet(taskId));
			String memcacheKey = mm.createMemcacheKey(taskId);
			List<TaskChecklists> taskChecklists = mm.getMemcache(memcacheKey);
			
			if (taskChecklists == null) {
				DsQuery<TaskChecklists> dsQuery = new DsQuery<>(TaskChecklists.class)
						.eq(FLD.deleteYN, N)
						.eq(FLD.taskId, taskId);
//						.sort(FLD.created, SortDirection.ASC);
				
				taskChecklists = dsQuery.execute(mgr);
				sort(taskChecklists);
				mm.setMemcache(memcacheKey, taskChecklists);
			}
			
			return taskChecklists;
		} catch (Exception ex) {
			LOG.warning("[listTaskChecklists] : "+ex.getMessage());
			throw ex;
		}
	}
	
	private List<TaskChecklists> listTaskChecklists(
			EntityManager mgr,
			Collection<String> boardIds,
			List<String> taskIdList,
			QueryOption queryOption
			) throws Exception {
		try {
			//Collections.sort(taskIdList);
			List<String> boards = new ArrayList<String>(boardIds);
			Collections.sort(boards);
			MemcacheManager<TaskChecklists, List<TaskChecklists>> mm = new MemcacheManager<>(TaskChecklists.class, MemcacheManager.keySet(boards));
			String memcacheKey = mm.createMemcacheKey(boards);
			List<TaskChecklists> taskChecklists = mm.getMemcache(memcacheKey);
			
			if (taskChecklists == null) {
				taskChecklists = new ArrayList<TaskChecklists>();
				int fetchCount = 30;
				for (int fromIndex = 0; fromIndex < boards.size(); fromIndex = fromIndex + fetchCount) {
					int toIndex = fromIndex + fetchCount;
					if (toIndex >= boards.size()) { toIndex = boards.size(); }
					
					DsQuery<TaskChecklists> dsQuery = new DsQuery<>(TaskChecklists.class)
					.eq(FLD.deleteYN, N)
					//.in(FLD.taskId, taskIdList.subList(fromIndex, toIndex))
					.in(FLD.boardId, boards.subList(fromIndex, toIndex));
//					.sort(FLD.created, SortDirection.ASC);
					
					List<TaskChecklists> results = dsQuery.execute(mgr);
					
					taskChecklists.addAll(results);
				}
				//sort(taskChecklists);
				mm.setMemcache(memcacheKey, taskChecklists);
			}
			
			List<TaskChecklists> checklistResults = new ArrayList<TaskChecklists>();
			for (TaskChecklists checklist : taskChecklists) {
				if (taskIdList.contains(checklist.getTaskId())) {
					checklistResults.add(checklist);
				}
			}
			
			return checklistResults;
		} catch (Exception ex) {
			LOG.warning("[listTaskChecklists] : "+ex.getMessage());
			throw ex;
		}
	}
	
	@Override
	public Map<String, List<TaskChecklists>> batchMapTaskChecklists(EntityManager mgr, List<String> taskIdList) throws Exception {
		try {
			Map<String, List<TaskChecklists>> resultMap = new HashMap<String, List<TaskChecklists>>();
			
			for (String taskId : taskIdList) {
				List<TaskChecklists> result = listTaskChecklists(mgr, taskId, null);
				if (result == null || result.size() == 0) { continue; }
				if (!resultMap.containsKey(taskId)) { resultMap.put(taskId, new ArrayList<TaskChecklists>()); }
				resultMap.get(taskId).addAll(result);
			}
			
			return resultMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Map<String, List<TaskChecklists>> batchMapTaskChecklists(EntityManager mgr, Collection<String> boardIds, List<String> taskIdList) throws Exception {
		try {
			Map<String, List<TaskChecklists>> resultMap = new HashMap<String, List<TaskChecklists>>();
			
			List<TaskChecklists> result = listTaskChecklists(mgr, boardIds, taskIdList, null);
			for (TaskChecklists checklist : result) {
				if (!resultMap.containsKey(checklist.getTaskId())) {
					resultMap.put(checklist.getTaskId(), new ArrayList<TaskChecklists>());
				}
				resultMap.get(checklist.getTaskId()).add(checklist);
			}
			
			sort(resultMap);
			
			return resultMap;
		} catch (Exception ex) {
			throw ex;
		}
	}

	private List<TaskChecklists> getTaskChecklistsForHistoryList(EntityManager mgr, String taskId) throws Exception {
		List<TaskChecklists> checklists = new ArrayList<TaskChecklists>();
		
		List<TaskChecklists> list = listTaskChecklists(mgr, taskId, null);
		for (TaskChecklists oldChecklist : list) {
			TaskChecklists newChecklist = new TaskChecklists();
			CopyUtil.copy(newChecklist, oldChecklist);
			checklists.add(newChecklist);
		}
		
		return checklists;
	}

	@Override
	public TaskChecklists insertTaskChecklists(TaskChecklists taskChecklist) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			return insertTaskChecklists(mgr, taskChecklist, loginUser);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public TaskChecklists insertTaskChecklists(EntityManager mgr, TaskChecklists taskChecklist, Users loginUser) throws Exception {
		try {
			String loginUserId = loginUser.getUserId();
			taskChecklist.setCreator(loginUserId);
			
			List<TaskChecklists> checklists = getTaskChecklistsForHistoryList(mgr, taskChecklist.getTaskId());

			Tasks task = doFind(mgr, Tasks.class, taskChecklist.getTaskId());
			taskChecklist.setKey(KeyUtil.createTaskChecklistKey());
			taskChecklist.setBoardId(task.getBoardId());
			if (contains(mgr, TaskChecklists.class, taskChecklist.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(TaskChecklists.class));
			}
			if (taskChecklist.getDueDate() == null) { taskChecklist.setDueDate(task.getDueDate()); }
			if (StringUtils.isBlank(taskChecklist.getAssignee())) { taskChecklist.setAssignee(loginUserId); }
			
			doPersistTransaction(mgr, taskChecklist);

			try {
				if (checklists != null && checklists.size() > 0) {
					taskChecklistHistoryService.insertTaskChecklistHistories(new TaskChecklistHistories(ActivityType.ADDED, taskChecklist, checklists, "Checklist added.", loginUserId));
				}
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }

			try {
				taskService.createOrUpdateTaskIndex(mgr, task);

				Activities activity = activityService.createTaskChecklistActivity(taskChecklist, null, ActivityType.ADDED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return taskChecklist;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public TaskChecklists updateTaskChecklists(TaskChecklists taskChecklist) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			valid(taskChecklist);
			Tasks task = doFind(mgr, Tasks.class, taskChecklist.getTaskId());
			List<TaskChecklists> checklists = getTaskChecklistsForHistoryList(mgr, taskChecklist.getTaskId());
			TaskChecklists originTaskChecklist = doFind(mgr, TaskChecklists.class, taskChecklist.getTaskChecklistId());
			ActivityType activityType = ActivityType.UPDATED;
			if (originTaskChecklist != null &&
					!StringUtils.equals(taskChecklist.getCheckYN(), originTaskChecklist.getCheckYN())) {
				activityType = StringUtils.equals(Y, taskChecklist.getCheckYN()) ? ActivityType.CHECKED : ActivityType.UNCHECKED; 
			}
			if (taskChecklist.getDueDate() == null) { taskChecklist.setDueDate(task.getDueDate()); }
			if (StringUtils.isBlank(taskChecklist.getAssignee())) { taskChecklist.setAssignee(loginUser.getUserId()); }
			
			doMergeTransaction(mgr, taskChecklist);

			try {
				updateHistories(activityType, taskChecklist, checklists, loginUser.getUserId());
				if (ActivityType.UPDATED.equals(activityType)) {
					// activityType이 update가 아닐 경우엔 궂이 taskIndex를 수정할 필요는 없다. taskIndex에는 checklist의 title과 description만 인덱싱을 한다.
					// checked나 unchecked는 인덱싱에 포함되어 있지 않다.
					taskService.createOrUpdateTaskIndex(mgr, taskChecklist.getTaskId());
				}

				Activities activity = activityService.createTaskChecklistActivity(taskChecklist, null, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return taskChecklist;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public TaskChecklists updateTaskChecklistAssignee(String taskChecklistId, String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			
			TaskChecklists taskChecklist = doFind(mgr, TaskChecklists.class, taskChecklistId);
			Tasks task = doFind(mgr, Tasks.class, taskChecklist.getTaskId());
			List<TaskChecklists> checklists = getTaskChecklistsForHistoryList(mgr, taskChecklist.getTaskId());
			
			if (taskChecklist.getDueDate() == null) { taskChecklist.setDueDate(task.getDueDate()); }
			if (StringUtils.isBlank(taskChecklist.getAssignee())) { taskChecklist.setAssignee(loginUser.getUserId()); }
			
			taskChecklist.setAssignee(userId);
			doMergeTransaction(mgr, taskChecklist);

			ActivityType activityType = ActivityType.ASSIGNED;
			
			try {
				updateHistories(activityType, taskChecklist, checklists, loginUser.getUserId());
				// task index에 할당자는 포함이 안되므로 궂이 인덱스를 재 생성할 필요는 없다.
				//taskService.createOrUpdateTaskIndex(mgr, taskChecklist.getTaskId());

				Activities activity = activityService.createTaskChecklistActivity(taskChecklist, null, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return taskChecklist;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void updateHistories(ActivityType activityType, TaskChecklists taskChecklist, List<TaskChecklists> checklists, String userId) {
		try {
			if (checklists != null && checklists.size() > 0) {
				taskChecklistHistoryService
						.insertTaskChecklistHistories(new TaskChecklistHistories(
								activityType, taskChecklist,
								checklists, "Checklist edited.", userId));
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}

	@Override
	public TaskChecklists removeTaskChecklists(String taskChecklistId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();
			
			TaskChecklists taskChecklist = doFind(mgr, TaskChecklists.class, taskChecklistId);
			
			valid(taskChecklist);
			
			List<TaskChecklists> checklists = getTaskChecklistsForHistoryList(mgr, taskChecklist.getTaskId());
			
			taskChecklist.setDeleted(new Date());
			taskChecklist.setDeleteYN(Y);

			doMergeTransaction(mgr, taskChecklist);

			try {
				if (checklists != null && checklists.size() > 0) {
					taskChecklistHistoryService
							.insertTaskChecklistHistories(new TaskChecklistHistories(
									ActivityType.DELETED, taskChecklist,
									checklists, "Checklist deleted.",
									loginUserId));
				}
			} catch (Exception ex) { ex.printStackTrace(); LOG.warning("1. "+ex.getMessage()); }
			try {
				taskService.createOrUpdateTaskIndex(mgr, taskChecklist.getTaskId());

				Activities activity = activityService.createTaskChecklistActivity(taskChecklist, null, ActivityType.DELETED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { ex.printStackTrace(); LOG.warning("2. "+ex.getMessage()); }
			
			return taskChecklist;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@SuppressWarnings("unused")
	private void permanentRemoveTaskChecklists(String taskChecklistId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			String loginUserId = loginUser.getUserId();

			TaskChecklists taskChecklist = doFind(mgr, TaskChecklists.class, taskChecklistId);
			List<TaskChecklists> checklists = getTaskChecklistsForHistoryList(mgr, taskChecklist.getTaskId());
			valid(taskChecklist);

			doRemoveTransaction(mgr, taskChecklist);
			
			try {
				if (checklists != null && checklists.size() > 0) {
					taskChecklistHistoryService
							.insertTaskChecklistHistories(new TaskChecklistHistories(
									ActivityType.DELETED, taskChecklist,
									checklists, "Checklist deleted.",
									loginUserId));
				}
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			try {
				//removeTaskChecklistIndex(taskChecklistId);
				taskService.createOrUpdateTaskIndex(mgr, taskChecklist.getTaskId());

				Activities activity = activityService.createTaskChecklistActivity(taskChecklist, null, ActivityType.DELETED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public int bulkRemoveTaskChecklist(String taskId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return bulkRemoveTaskChecklist(mgr, taskId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private int bulkRemoveTaskChecklist(EntityManager mgr, String taskId) throws Exception {
		try {
			TypedQuery<TaskChecklists> query = new QueryBuilder<>(TaskChecklists.class)
					.addClause(FLD.taskId, taskId)
					.addClause(FLD.deleteYN, null)
					.addClause(FLD.archiveYN, null)
					.addClause(FLD.permanentDeleteYN, null)
					.build(mgr);

			List<TaskChecklists> taskChecklists = queryResults(query);
			doRemoveTransaction(mgr, taskChecklists);

			return taskChecklists.size();
		} catch (Exception ex) {
			throw ex;
		}
	}

	private static void sort(Map<String, List<TaskChecklists>> checklistMap) {
		for(Map.Entry<String, List<TaskChecklists>> entry : checklistMap.entrySet()) {
			sort(entry.getValue());
		}
	}
	private static void sortByCreated(List<TaskChecklists> list) {
		Collections.sort(list, new Comparator<TaskChecklists>() {
	        @Override
	        public int compare(TaskChecklists first, TaskChecklists second) {
	        	if (first.getCreated() == null && second.getCreated() == null) {
	        		return 0;
	        	} else if (first.getCreated() == null ) {
	        		return 1;
	        	} else if (second.getCreated() == null) {
	        		return -1;
	        	}
	        	
	        	return first.getCreated().compareTo(second.getCreated());
	        }
	    });
	}
	private static void sort(List<TaskChecklists> list) {
		sortByCreated(list);
		Collections.sort(list, new Comparator<TaskChecklists>() {
	        @Override
	        public int compare(TaskChecklists first, TaskChecklists second) {
	        	if (first.getOrdernum() == null && second.getOrdernum() == null) {
	        		return 0;
	        	} else if (first.getOrdernum() == null ) {
	        		return 1;
	        	} else if (second.getOrdernum() == null) {
	        		return -1;
	        	}
	        	
	        	if (first.getOrdernum() > second.getOrdernum()) {
	        		return 1;
	        	} else if (first.getOrdernum() < second.getOrdernum()) {
	        		return -1;
	        	} else {
	        		return 0;
	        	}
	        }
	    });
	}
	
	@Override
	public Map<String, List<TaskChecklists>> getMyTODOTaskChecklistsMap() throws Exception {
		Users currentUser = getCurrentUser();
		return getTODOTaskChecklistsMap(currentUser.getUserId());
	}
	private Map<String, List<TaskChecklists>> getTODOTaskChecklistsMap(String assignee) throws Exception {
		List<TaskChecklists> taskChecklists = getTODOTaskChecklists(assignee);
		
		Map<String, List<TaskChecklists>> results = new HashMap<String, List<TaskChecklists>>();
		results.put("future", new ArrayList<TaskChecklists>());
		results.put("tomorrow", new ArrayList<TaskChecklists>());
		results.put("present", new ArrayList<TaskChecklists>());
		results.put("yesterday", new ArrayList<TaskChecklists>());
		results.put("past", new ArrayList<TaskChecklists>());
		results.put("none", new ArrayList<TaskChecklists>());
		
		Date present = new Date();
		for (TaskChecklists checklist : taskChecklists) {
			Long diffDays = CalendarUtil.diffDays(checklist.getDueDate(), present);
			
			if (diffDays == null) { results.get("none").add(checklist); }
			else if (diffDays == 0) { results.get("present").add(checklist); }
			else if (diffDays == -1) { results.get("yesterday").add(checklist); }
			else if (diffDays < -1) { results.get("past").add(checklist); }
			else if (diffDays == 1) { results.get("tomorrow").add(checklist); }
			else if (diffDays > 1) { results.get("future").add(checklist); }
		}
		
		return results;
	}
	@Override
	public List<TaskChecklists> getTODOTaskChecklists(String assignee) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			DsQuery<TaskChecklists> dsQuery = new DsQuery<>(TaskChecklists.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.checkYN, N)
					.eq(FLD.assignee, assignee);
//					.sort(FLD.created, SortDirection.ASC);
			
			List<TaskChecklists> taskChecklists = dsQuery.execute(mgr);
			
			Set<String> myTaskIds = new HashSet<String>();
			for (TaskChecklists checklist : taskChecklists) {
				myTaskIds.add(checklist.getTaskId());
			}
			Map<String, Tasks> myTaskMap = batchMapByKey(mgr, Tasks.class, myTaskIds);
			for (TaskChecklists checklist : taskChecklists) {
				if (checklist.getDueDate() == null) { checklist.setDueDate(myTaskMap.get(checklist.getTaskId()).getDueDate()); }
			}
			
			sortByDueDate(taskChecklists);
			
			return taskChecklists;
		} catch (Exception ex) {
			LOG.warning("[listTaskChecklists] : "+ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private static void sortByDueDate(List<TaskChecklists> list) {
		Collections.sort(list, new Comparator<TaskChecklists>() {
	        @Override
	        public int compare(TaskChecklists first, TaskChecklists second) {
	        	if (first.getDueDate() == null && second.getDueDate() == null) {
	        		return 0;
	        	} else if (first.getDueDate() == null ) {
	        		return 1;
	        	} else if (second.getDueDate() == null) {
	        		return -1;
	        	}
	        	
	        	return first.getDueDate().compareTo(second.getDueDate());
	        }
	    });
	}
	
	
	/*
	 * 이전에 생성된 checklist에 대해 dueDate와 assignee 정보를 현 기능에 맞는 데이터로 재 배치
	 */
	@Override
	@Deprecated
	public void resetTODOTaskChecklists() throws Exception {
		List<Domains> domains = listDomains(null, null).getResultList();
		for (Domains domain : domains) {
			resetTODOTaskChecklists(domain.getDomainName());
		}
	}
	@Deprecated
	@Override
	public void resetTODOTaskChecklists(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<TaskChecklists> dsQuery = new DsQuery<>(TaskChecklists.class)
					.eq(FLD.deleteYN, N);
			List<TaskChecklists> taskChecklists = dsQuery.execute(mgr);
			
			Set<String> taskIds = new HashSet<String>();
			for (TaskChecklists checklist : taskChecklists) {
				taskIds.add(checklist.getTaskId());
			}
			Map<String, Tasks> taskMap = taskService.allTaskMap(mgr);
			for (TaskChecklists checklist : taskChecklists) {
				if (checklist.getDueDate() == null) { checklist.setDueDate(taskMap.get(checklist.getTaskId()).getDueDate()); }
				if (StringUtils.isBlank(checklist.getAssignee())) { checklist.setAssignee(checklist.getCreator()); }
				doMergeTransaction(mgr, checklist);
			}
		} catch (Exception ex) {
			LOG.warning("[resetTODOTaskChecklists] : "+ex.getMessage());
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public List<TaskChecklists> listTaskChecklists(
//			String taskId,
//			QueryOption queryOption
//			) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			return listTaskChecklists(mgr, taskId, queryOption);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<TaskChecklists> getTaskChecklistsForHistoryList(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getTaskChecklistsForHistoryList(mgr, taskId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public TaskChecklists getTaskChecklists(String taskChecklistId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, TaskChecklists.class, taskChecklistId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<TaskChecklists> recoverHistory(String taskId, String taskChecklistHistoryId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TaskChecklistHistories taskChecklistHistory = doFind(mgr, TaskChecklistHistories.class, taskChecklistHistoryId);
//			List<TaskChecklists> taskChecklists = taskChecklistHistory.getTaskChecklists();
//			
//			if (taskChecklistHistory != null && taskChecklists != null && taskChecklists.size() > 0) {
//				bulkRemoveTaskChecklist(mgr, taskId);
//	
//				doPersistTransaction(mgr, taskChecklists);
//				
//	//			for (TaskChecklists rmChecklist : taskChecklist) {
//	//				removeTaskChecklistIndex(rmChecklist.getTaskChecklistId());
//	//			}
//	//			for (TaskChecklists inChecklist : taskChecklistHistory.getTaskChecklists()) {
//	//				createOrUpdateTaskChecklistIndex(inChecklist);
//	//			}
//				
//				// TODO : hyeunwoo.shim 2015-10-08 
//				// recover history에 대한 activity 가 필요할듯....
//				// simple하게는 삭제 checklist 마다  DELETE activity 를 보내고, 추가하는 checklist 마다 INSERT activity를 보내는 방법이 있다.
//				// 문제점 : checklist의 갯수에 따라 많은 activity가 발생한다.
//				// 새로운 방법으로는 activityType을 새로 만들고, 삭제되었거나 혹은 복구된 checklist 목록을 한꺼번에 보내는것이다.
//				taskService.createOrUpdateTaskIndex(mgr, taskId);
//			}
//			
//			return taskChecklists;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public boolean changeOrderChecklits(List<String> taskChecklistIds) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			int orderCount = 0;
//
//			Map<String, TaskChecklists> checklistMap = batchMapByKey(mgr, TaskChecklists.class, taskChecklistIds);
//			List<TaskChecklists> checklists = new ArrayList<TaskChecklists>();
//
//			for (String checklistId : taskChecklistIds) {
//				TaskChecklists checklist = checklistMap.get(checklistId);
//				checklist.setOrdernum(orderCount++);
//				checklists.add(checklist);
//			}
//			
//			doMergeTransaction(mgr, checklists);
//			
//			return true;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
