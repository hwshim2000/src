package net.forecs.coconut.endpoint.workspace;

import net.forecs.coconut.endpoint.common.CommonService;

@Deprecated
public class TaskChecklistCommentService extends CommonService implements ITaskChecklistCommentService {
//	private static final Logger LOG = Logger.getLogger(TaskChecklistCommentService.class.getName());
//	
//	private final IUserService userService;
//	private final IActivityService activityService;
//	
//	@Inject
//	public TaskChecklistCommentService(IUserService userService, IActivityService activityService) {
//		this.userService = userService;
//		this.activityService = activityService;
//	}
//
//	@Override
//	public QueryResult<TaskChecklistComments> listTaskChecklistComments(
//			String cursorString,
//			Integer limit,
//			String taskId
//			) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			TypedQuery<TaskChecklistComments> query = new QueryBuilder<>(TaskChecklistComments.class)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.taskId, taskId)
//					.addOrder(FLD.familyId, SortDirection.DESC)
//					.addOrder(FLD.depth, SortDirection.ASC)
//					.build(mgr);
//			
//			Cursor cursor = null;
//			
//			if (StringUtils.isNotBlank(cursorString)) {
//				cursor = Cursor.fromWebSafeString(cursorString);
//				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
//			}
//
//			if (limit != null) {
//				query.setFirstResult(0);
//				query.setMaxResults(limit);
//			}
//
//			List<TaskChecklistComments> taskChecklistCommentList = query.getResultList();
//			cursor = JPACursorHelper.getCursor(taskChecklistCommentList);
//
//			Map<String, Users> usersMap = batchMapTaskChecklistCommentUsers(mgr, taskChecklistCommentList);
//			for (TaskChecklistComments comment : taskChecklistCommentList) {
//				comment.setUser(usersMap.get(comment.getCreator()));
//			}
//			
//			return new QueryResult<TaskChecklistComments>(taskChecklistCommentList, cursor);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	
//	private Map<String, Users> batchMapTaskChecklistCommentUsers(
//			EntityManager mgr,
//			List<TaskChecklistComments> taskChecklistCommentList) throws Exception {
//		Set<String> userIds = new HashSet<String>();
//		for (TaskChecklistComments comment : taskChecklistCommentList) {
//			userIds.add(comment.getCreator());
//		}
//		return userService.batchMapUsers(mgr, userIds, false);
//	}
//
//	private boolean hasChildComments(EntityManager mgr, String taskChecklistCommentId) throws Exception {
//		try {
//			Key taskChecklistCommentKey = KeyFactory.stringToKey(taskChecklistCommentId);
//
//			SimpleQuery<TaskChecklistComments> sq = new SimpleQuery<>(mgr, TaskChecklistComments.class);
//			sq.where(sq.equal(FLD.parentId, taskChecklistCommentKey.getId()));
//			TypedQuery<Long> query = sq.count();
//			
//			Long childCount = query.getSingleResult();
//			
//			if (childCount != null && childCount > 0) {
//				return true;
//			} else {
//				return false;
//			}
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//
//	private List<TaskChecklistComments> updateAllDepth(long familyId, int depth) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TypedQuery<TaskChecklistComments> query = new QueryBuilder<>(TaskChecklistComments.class)
//					.addClause(FLD.familyId, familyId)
//					.addGTClause(FLD.depth, depth, SortDirection.ASC)
//					.build(mgr);
//
//			List<TaskChecklistComments>  taskChecklistCommentList = queryResults(query);
//
//			for (TaskChecklistComments taskChecklistComment : taskChecklistCommentList) {
//				taskChecklistComment.setDepth(taskChecklistComment.getDepth() + 1);
//			}
//			doMergeTransaction(mgr, taskChecklistCommentList);
//			
//			return taskChecklistCommentList;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public TaskChecklistComments getTaskChecklistComments(String taskChecklistCommentId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getTaskChecklistComments(mgr, taskChecklistCommentId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private TaskChecklistComments getTaskChecklistComments(EntityManager mgr, String taskChecklistCommentId) {
//		return doFind(mgr, TaskChecklistComments.class, taskChecklistCommentId);
//	}
//
//
//	@Override
//	public TaskChecklistComments insertTaskChecklistComments(
//			String parentTaskChecklistCommentId, 
//			TaskChecklistComments taskChecklistComment) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			Users loginUser = getCurrentUser();
//			taskChecklistComment.setCreator(loginUser.getUserId());
//
//			Key taskKey = KeyFactory.stringToKey(taskChecklistComment.getTaskId());
//			Tasks task = doFind(mgr, Tasks.class, taskKey);
//			Key taskChecklistCommentKey = KeyUtil.createTaskChecklistCommentKey(taskKey);
//			long familyId = taskChecklistCommentKey.getId();
//
//			if (StringUtils.isEmpty(parentTaskChecklistCommentId)) {
//				//taskchecklistcomments.setNo(no);
//				taskChecklistComment.setFamilyId(familyId);
//				taskChecklistComment.setParentId(0);
//				taskChecklistComment.setDepth(0);
//				taskChecklistComment.setIndent(0);
//			} else {
//				TaskChecklistComments parentComment = getTaskChecklistComments(mgr, parentTaskChecklistCommentId);
//
//				updateAllDepth(parentComment.getFamilyId(), parentComment.getDepth());
//
//				//taskchecklistcomments.setNo(no);
//				taskChecklistComment.setFamilyId(parentComment.getFamilyId());
//				taskChecklistComment.setParentId(parentComment.getKey().getId());
//				taskChecklistComment.setDepth(parentComment.getDepth()+1);
//				taskChecklistComment.setIndent(parentComment.getIndent()+1);
//			}
//
//			taskChecklistComment.setKey(taskChecklistCommentKey);
//			taskChecklistComment.setBoardId(task.getBoardId());
//			taskChecklistComment.setUser(loginUser);
//
//			if (contains(mgr, TaskChecklistComments.class, taskChecklistComment.getKey())) {
//				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(TaskChecklistComments.class, taskChecklistComment.getTaskChecklistCommentId()));
//			}
//
//			doPersistTransaction(mgr, taskChecklistComment);
//
//			try {
//				createOrUpdateTaskChecklistCommentIndex(taskChecklistComment);
//				Activities activity = activityService.createTaskChecklistCommentActivity(taskChecklistComment, null, ActivityType.ADDED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return taskChecklistComment;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public TaskChecklistComments updateTaskChecklistComments(
//			TaskChecklistComments taskChecklistComment) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			Users loginUser = getCurrentUser();
//			TaskChecklistComments originTaskChecklistComment = taskChecklistComment;
//			valid(originTaskChecklistComment);
//
//			originTaskChecklistComment.setUser(loginUser);
//			
//			doMergeTransaction(mgr, originTaskChecklistComment);
//
//			try {
//				createOrUpdateTaskChecklistCommentIndex(originTaskChecklistComment);
//				Activities activity = activityService.createTaskChecklistCommentActivity(originTaskChecklistComment, null, ActivityType.UPDATED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return originTaskChecklistComment;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Override
//	public void removeTaskChecklistComments(String taskChecklistCommentId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TaskChecklistComments taskChecklistComment = doFind(mgr, 
//					TaskChecklistComments.class, taskChecklistCommentId);
//			valid(taskChecklistComment);
//
//			if (hasChildComments(mgr, taskChecklistCommentId)) {
//				taskChecklistComment.setDeleted(new Date());
//				taskChecklistComment.setDeleteYN(Y);
//				doMergeTransaction(mgr, taskChecklistComment);
//			} else {
//				doRemoveTransaction(mgr, taskChecklistComment);
//			}
//
//			try {
//				removeTaskChecklistCommentIndex(taskChecklistCommentId);
//				
//				Users loginUser = getCurrentUser();
//				Activities activity = activityService.createTaskChecklistCommentActivity(taskChecklistComment, null, ActivityType.DELETED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@SuppressWarnings("unused")
//	private void permanentRemoveTaskChecklistComments(EntityManager mgr, String taskChecklistCommentId) throws Exception {
//		try {
//			TaskChecklistComments taskChecklistComment = doFind(mgr, 
//					TaskChecklistComments.class, taskChecklistCommentId);
//			permanentRemoveTaskChecklistComments(mgr, taskChecklistComment);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	
//	private void permanentRemoveTaskChecklistComments(EntityManager mgr, TaskChecklistComments taskChecklistComment) throws Exception {
//		try {
//			doRemoveTransaction(mgr, taskChecklistComment);
//			
//			try {
//				removeTaskChecklistCommentIndex(taskChecklistComment.getTaskChecklistCommentId());
//				
//				Users loginUser = getCurrentUser();
//				Activities activity = activityService.createTaskChecklistCommentActivity(taskChecklistComment, null, ActivityType.DELETED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//
//	@Override
//	public int bulkRemoveTaskChecklistComments(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			int resultCount = 0;
//			TypedQuery<TaskChecklistComments> query = new QueryBuilder<>(TaskChecklistComments.class)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.archiveYN, null)
//					.addClause(FLD.taskId, taskId)
////					.addOrder(FLD.familyId, SortDirection.DESC)
//					.build(mgr);
//			//***************************************************
//			// 만일 taskChecklistCommentList를 다른 객체로 변경하지 않았다면 바로 해당 객체를 삭제할 수 있다.
//			// 하지만 다른 객체로 옮겨담았거나 하면  attach/detach 관련 에러가 발생하기때문에 
//			// 해당 객체를 다시한번 읽어서 삭제해야 한다.(comment size가 많을 경우에는 이런식으로 해야한다.)
//			//***************************************************
//			List<TaskChecklistComments> taskChecklistCommentList = queryResults(query); 
//			for (TaskChecklistComments taskChecklistComment : taskChecklistCommentList) {
//				permanentRemoveTaskChecklistComments(mgr, taskChecklistComment);
//				resultCount++;
//			}
//			
//			return resultCount;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//
//	@Deprecated
//	@Override
//	public CommentIndex createOrUpdateTaskChecklistCommentIndex(TaskChecklistComments taskChecklistComment) {
//		try {
//			CommentIndex commentIndex = null;
//			
//			if (taskChecklistComment != null) {
//				commentIndex = new CommentIndex(taskChecklistComment.getDomainId(), taskChecklistComment.getBoardId(), taskChecklistComment.getTaskId(), taskChecklistComment);
//				SearchManager sm = new SearchManager();
//				sm.createIndex(commentIndex);
//			}
//			
//			return commentIndex;
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//			return null;
//		}
//	}
//	
//	private void removeTaskChecklistCommentIndex(String taskChecklistCommentId) {
//		try {
//			SearchManager searchManager = new SearchManager();
//			searchManager.deleteDocuments(CommentIndex.class, taskChecklistCommentId);
//		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//	}
}
