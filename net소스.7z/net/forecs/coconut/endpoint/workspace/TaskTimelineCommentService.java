package net.forecs.coconut.endpoint.workspace;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.CommentIndex;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;


public class TaskTimelineCommentService extends CommonService implements ITaskTimelineCommentService {
	private static final Logger LOG = Logger.getLogger(TaskTimelineCommentService.class.getName());
	
	private final IUserService userService;
	private final IActivityService activityService;
	private final ITaskTimelineService taskTimelineService;
	
	@Inject
	public TaskTimelineCommentService(IUserService userService,
			IActivityService activityService,
			ITaskTimelineService taskTimelineService) {
		this.userService = userService;
		this.activityService = activityService;
		this.taskTimelineService = taskTimelineService;
	}

	@Override
	public List<TaskTimelineComments> listTaskTimelineComments(
			EntityManager mgr,
			String taskTimelineId) throws Exception {
		try {
			// taskTimelineComments는 부모 즉, taskTimelineId를 그룹키 단위로 결과값을 저장시킨다.
			MemcacheManager<TaskTimelineComments, List<TaskTimelineComments>> mm = new MemcacheManager<>(TaskTimelineComments.class, taskTimelineId);
			String memcacheKey = mm.createMemcacheKey(taskTimelineId);
			List<TaskTimelineComments> taskTimelineCommentList = mm.getMemcache(memcacheKey);
		
			if (taskTimelineCommentList == null) {
				DsQuery<TaskTimelineComments> dsQuery = new DsQuery<>(TaskTimelineComments.class)
						.eq(FLD.deleteYN, null)
						.eq(FLD.taskTimelineId, taskTimelineId);
//						.sort(FLD.created, SortDirection.ASC);	// sorted by client
	
				taskTimelineCommentList = dsQuery.execute(mgr);
				mm.setMemcache(memcacheKey, taskTimelineCommentList);
			} 

			Map<String, Users> userMap = batchMapTaskTimelineCommentUsers(mgr, taskTimelineCommentList, false);
			for (TaskTimelineComments taskTimelineComment : taskTimelineCommentList) {
				taskTimelineComment.setUser(userMap.get(taskTimelineComment.getCreator()));
			}
			
			return taskTimelineCommentList;
		} catch (Exception ex) {
			throw ex;
		}
	}

	private Map<String, Users> batchMapTaskTimelineCommentUsers(EntityManager mgr, List<TaskTimelineComments> taskTimelineCommentList, boolean includeProfile) throws Exception {
		Set<String> userIds = new HashSet<String>();
		for (TaskTimelineComments taskTimelineComment : taskTimelineCommentList) {
			if (StringUtils.isNotBlank(taskTimelineComment.getCreator())) {
				userIds.add(taskTimelineComment.getCreator());
			}
		}
		return userService.batchMapUsers(mgr, userIds, includeProfile);
	}

	
	private boolean hasChildComments(String taskTimelineCommentId) throws Exception {
		Key taskTimelineCommentKey = KeyFactory.stringToKey(taskTimelineCommentId);
		DsQuery<TaskTimelineComments> query = new DsQuery<>(TaskTimelineComments.class)
				.eq(FLD.parentId, taskTimelineCommentKey.getId());
		
		Long childCount = query.count();
		if (childCount != null && childCount > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public TaskTimelineComments getTaskTimelineComments(String taskTimelineCommentId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			TaskTimelineComments taskTimelineComment = doFind(mgr, TaskTimelineComments.class, taskTimelineCommentId);
			valid(taskTimelineComment);
			Users user = userService.getUsers(mgr, taskTimelineComment.getCreator(), false);
			taskTimelineComment.setUser(user);
			
			return taskTimelineComment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public TaskTimelineComments insertTaskTimelineComments(String parentTaskTimelineCommentId, TaskTimelineComments taskTimelineComment) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			taskTimelineComment.setCreator(loginUser.getUserId());
			
			Key taskKey = KeyFactory.stringToKey(taskTimelineComment.getTaskId());
			
			Tasks task = doFind(mgr, Tasks.class, taskKey);
			Key taskTimelineCommentKey = KeyUtil.createTaskTimelineCommentKey(taskKey);

			if (StringUtils.isNotBlank(parentTaskTimelineCommentId)) {
				taskTimelineComment.setParentId(parentTaskTimelineCommentId);
			}
			
			taskTimelineComment.setKey(taskTimelineCommentKey);
			taskTimelineComment.setDomainId(task.getDomainId());
			taskTimelineComment.setBoardId(task.getBoardId());
			
			if (contains(mgr, TaskTimelineComments.class, taskTimelineComment.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(TaskTimelineComments.class, taskTimelineComment.getTaskTimelineCommentId()));
			}
			
			doPersistTransaction(mgr, taskTimelineComment);
			taskTimelineComment.setUser(loginUser);

			try {
				createOrUpdateTaskTimelineCommentIndex(taskTimelineComment);
				
				taskTimelineService.updateTasktimelinesLastCommented(taskTimelineComment.getTaskTimelineId(), taskTimelineComment.getCreated());
				ActivityType activityType = ActivityType.ADDED;
				if (taskTimelineComment.getMentionIds() != null && taskTimelineComment.getMentionIds().size() > 0) {
					activityType = ActivityType.ADDED_WITH_MENTION;
				}
				Activities activity = activityService.createTaskTimelineCommentActivity(taskTimelineComment, null, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return taskTimelineComment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public TaskTimelineComments updateTaskTimelineComments(TaskTimelineComments taskTimelineComment) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			TaskTimelineComments originComment = doFind(mgr, TaskTimelineComments.class, taskTimelineComment.getTaskTimelineCommentId());
			valid(taskTimelineComment);

			List<String> originMentions = originComment.getMentionIds();
			List<String> currentMentions = taskTimelineComment.getMentionIds();
			
			beginTransaction(mgr);
			taskTimelineComment = doMerge(mgr, taskTimelineComment);
			taskTimelineComment.setMentionIds(currentMentions);	// List 타입등 Collection or Array 타입등은 추가적으로 attach를 시켜줘야 제대로 merge가 된다.
			commitTransaction(mgr);
			
			taskTimelineComment.setUser(loginUser);

			try {
				taskTimelineService.updateTasktimelinesLastCommented(taskTimelineComment.getTaskTimelineId(), taskTimelineComment.getModified());
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
			try {
				createOrUpdateTaskTimelineCommentIndex(taskTimelineComment);
				ActivityType activityType = ActivityType.UPDATED;
				List<String> newMentions = getNewMentions(originMentions, currentMentions);
				if (newMentions != null && newMentions.size() > 0) {
					activityType = ActivityType.UPDATED_WITH_MENTION;
				}
				Activities activity = activityService.createTaskTimelineCommentActivity(taskTimelineComment, newMentions, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return taskTimelineComment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public void removeTaskTimelineComments(String taskTimelineCommentId) throws Exception {
		EntityManager mgr = getEntityManager();
		TaskTimelineComments taskTimelineComment = null;
		
		try {
			taskTimelineComment = doFind(mgr, TaskTimelineComments.class, taskTimelineCommentId);
			// hyeunwoo.shim 2017-03-15
			//valid(taskTimelineComment);
			
			Date lastCommented = new Date();
			if (hasChildComments(taskTimelineCommentId)) {
				taskTimelineComment.setDeleted(new Date());
				taskTimelineComment.setDeleteYN(Y);
				taskTimelineComment = doMergeTransaction(mgr, taskTimelineComment);
				lastCommented = taskTimelineComment.getModified();
			} else {
				doRemoveTransaction(mgr, taskTimelineComment);
				//removeAndCheckParentComments(taskTimelineComment.getParentId());
			}

			try {
				taskTimelineService.updateTasktimelinesLastCommented(taskTimelineComment.getTaskTimelineId(), lastCommented);
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
			try {
				removeTaskTimelineCommentIndex(taskTimelineCommentId);
				
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskTimelineCommentActivity(taskTimelineComment, null, ActivityType.DELETED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
			removeAndCheckParentComments(taskTimelineComment.getParentId());
		}
	}
	
	private void removeAndCheckParentComments(String parentTaskTimelineCommentId) {
		if (StringUtils.equals("0", parentTaskTimelineCommentId)) { return; }
		EntityManager mgr = getEntityManager();	
		try {
			TaskTimelineComments parent = doFind(mgr, TaskTimelineComments.class, parentTaskTimelineCommentId);
			// 부모가 삭제된것인지 판단하여, 삭제된것일 경우, 자식이 더 이상 없는지 확인하여 완전 삭제를 한다.
			if (StringUtils.equals(N, parent.getDeleteYN())) { return; }
			if (!hasChildComments(parentTaskTimelineCommentId)) {
				doRemoveTransaction(mgr, parent);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private void permanentTaskTimelineComments(EntityManager mgr, String taskTimelineCommentId) throws Exception {
		try {
			TaskTimelineComments taskTimelineComment = doFind(mgr, TaskTimelineComments.class, taskTimelineCommentId);
			doRemoveTransaction(mgr, taskTimelineComment);
			try {
				removeTaskTimelineCommentIndex(taskTimelineCommentId);
				
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskTimelineCommentActivity(taskTimelineComment, null, ActivityType.DELETED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public int bulkRemoveTaskTimelineComments(String taskTimelineId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Query query = new DsQuery<>(TaskTimelineComments.class)
					.eq(FLD.deleteYN, null)
					.eq(FLD.archiveYN, null)
					.eq(FLD.taskTimelineId, taskTimelineId)
					.keysOnly();

			List<Key> keys = listAllKeysForLimitedChunkSize(query);
			for (Key key : keys) {
				permanentTaskTimelineComments(mgr, KeyFactory.keyToString(key));
			}
			
			return keys.size();
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public CommentIndex createOrUpdateTaskTimelineCommentIndex(TaskTimelineComments taskTimelineComment) {
		try {
			CommentIndex commentIndex = null;
			
			if (taskTimelineComment != null) {
				commentIndex = new CommentIndex(taskTimelineComment.getDomainId(), taskTimelineComment.getBoardId(), taskTimelineComment.getTaskId(), taskTimelineComment);
				SearchManager sm = new SearchManager();
				sm.createIndexAsync(commentIndex);
				//sm.createIndex(commentIndex);
			}
			
			return commentIndex;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}
	
	private void removeTaskTimelineCommentIndex(String taskTimelineCommentId) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.deleteDocuments(CommentIndex.class, taskTimelineCommentId);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}
	
//	@Override
//	public int bulkRemoveTaskTimelineComments(String taskTimelineId) throws Exception {
//		EntityManager mgr = getEntityManager();
//
//		try {
//			TypedQuery<Key> query = new QueryBuilder<>(TaskTimelineComments.class)
//					.addClause(FLD.deleteYN, null)
//					.addClause(FLD.archiveYN, null)
//					.addClause(FLD.taskTimelineId, taskTimelineId)
//					.buildKeyOnlyRead(mgr);
//
//			List<Key> keys = listAllKeysForLimitedChunkSize(query);
//			for (Key key : keys) {
//				permanentTaskTimelineComments(mgr, KeyFactory.keyToString(key));
//			}
//			
//			return keys.size();
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
	
//	@Deprecated
//	private boolean hasChildComments(EntityManager mgr, String taskTimelineCommentId) throws Exception {
//		Key taskTimelineCommentKey = KeyFactory.stringToKey(taskTimelineCommentId);
//
//		SimpleQuery<TaskTimelineComments> sq = new SimpleQuery<>(mgr, TaskTimelineComments.class);
//		sq.where(sq.equal(FLD.parentId, taskTimelineCommentKey.getId()));
//		TypedQuery<Long> query = sq.count();
//
//		Long childCount = query.getSingleResult();
//		if (childCount != null && childCount > 0) {
//			return true;
//		} else {
//			return false;
//		}
//	}
}
