package net.forecs.coconut.endpoint.workspace;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.common.IAttachmentService;
import net.forecs.coconut.endpoint.common.IImageService;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.TimelineIndex;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;


public class TaskTimelineService extends CommonService implements ITaskTimelineService {
	private static final Logger LOG = Logger.getLogger(TaskTimelineService.class.getName());
	
	private final IUserService userService;
//	private final ITaskTimelineScoreService taskTimelineScoreService;
	private final IAttachmentService attachmentService;
	private final IImageService imageService;
	private final IActivityService activityService;
	private final ITaskTimelineCommentService taskTimelineCommentService;
	
	@Inject
	public TaskTimelineService(
			IUserService userService,
//			ITaskTimelineScoreService taskTimelineScoreService,
			IAttachmentService attachmentService,
			IImageService imageService,
			IActivityService activityService,
			ITaskTimelineCommentService taskTimelineCommentService) {
		this.userService = userService;
//		this.taskTimelineScoreService = taskTimelineScoreService;
		this.attachmentService = attachmentService;
		this.imageService = imageService;
		this.activityService = activityService;
		this.taskTimelineCommentService = taskTimelineCommentService;
	}

	@Override
	public QueryResult<TaskTimelines> queryTaskTimelines(
			String cursorString,
			Integer limit,
			Collection<String> boardIdList,
			Collection<String> taskIdList,
			Collection<String> userIdList,
			SortType sortType,
			SortDirection sortDirection
			) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return queryTaskTimelines(mgr, cursorString, limit, boardIdList, taskIdList, userIdList, sortType, sortDirection);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public QueryResult<TaskTimelines> queryTaskTimelines(
			EntityManager mgr,
			String cursorString,
			Integer limit,
			Collection<String> boardIdList,
			Collection<String> taskIdList,
			Collection<String> userIdList,
			SortType sortType,
			SortDirection sortDirection
			) throws Exception {
		try {
			MemcacheManager<TaskTimelines, List<TaskTimelines>> mm = new MemcacheManager<>(TaskTimelines.class, MemcacheManager.keySet(taskIdList));
			String taskTimelineKey = mm.createMemcacheKey(cursorString, limit, boardIdList, taskIdList, userIdList, sortType, sortDirection);
			
			Set<String> boardIdSet = null;
			Set<String> taskIdSet = null;
			Set<String> userIdSet = null;
			
			if (boardIdList != null && boardIdList.size() > 1) {
				boardIdSet = new HashSet<String>(boardIdList);
				boardIdList = null;
			}
			
			if (taskIdList != null && taskIdList.size() > 1) {
				taskIdSet = new HashSet<String>(taskIdList);
				boardIdList = null;
				boardIdSet = null;
				taskIdList = null;
			}
			
			if (userIdList != null && userIdList.size() > 1) {
				userIdSet = new HashSet<String>(userIdList);
				userIdList = null;
			}
			
			List<TaskTimelines>  taskTimelineList = mm.getMemcache(taskTimelineKey);
			if (taskTimelineList == null) {
				//taskTimelineList = new ArrayList<TaskTimelines>();
				
				DsQuery<TaskTimelines> dsQuery = new DsQuery<>(TaskTimelines.class)
						.eq(FLD.deleteYN, N)
						.in(FLD.boardId, boardIdList)
						.in(FLD.taskId, taskIdList)
						.in(FLD.creator, userIdList)
						.sort(sortType != null ? sortType.toString() : null, sortDirection)
						.cursor(cursorString)
						.limit(limit);
				
				int bulkFetchAmount = 1;	// 검색 속도를 높이기 위해 한꺼번에 많은 양을 가져와서 해당되는 값들을 필터링하기 위해, 즉 , limit보다  bulkFetchAmount배 많이 가져온뒤에 필터링
				if (boardIdSet != null || taskIdSet != null) { bulkFetchAmount = 2; }
				if (userIdSet != null) { bulkFetchAmount++; }
				
				do {
					dsQuery.nextFetch(mgr, bulkFetchAmount++);
					while (dsQuery.hasEntity()) {
						TaskTimelines timeline = dsQuery.nextEntity();
						if (boardIdSet != null && !boardIdSet.contains(timeline.getBoardId())) { continue; }
						if (taskIdSet != null && !taskIdSet.contains(timeline.getTaskId())) { continue; }
						if (userIdSet != null && !userIdSet.contains(timeline.getCreator())) { continue; }
						dsQuery.addResult(timeline);
					}
				} while (dsQuery.hasNextFetch());
				
				taskTimelineList = dsQuery.getResults();
//				List<TaskTimelines> timelineList = dsQuery.getResults();
//				
//				if (timelineList != null && timelineList.size() > 0) {
//					Map<String, List<Images>> imagesMap = batchMapTaskTimelineImages(mgr, timelineList);
//					Map<String, List<Attachments>> attachmentsMap = batchMapTaskTimelineAttachments(mgr, timelineList);
//					for (TaskTimelines taskTimeline : timelineList) {
//						taskTimeline.setImages(imagesMap.get(taskTimeline.getTaskTimelineId()));
//						taskTimeline.setAttachments(attachmentsMap.get(taskTimeline.getTaskTimelineId()));
//						taskTimelineList.add(taskTimeline);
//					}
//				}
				cursorString = dsQuery.getCursor();
				mm.setMemcache(taskTimelineKey, taskTimelineList, cursorString);
			} else {
				cursorString = mm.getCursorString(taskTimelineKey);
			}
			
			if (taskTimelineList != null && taskTimelineList.size() > 0) {
				setTaskTimelinesDetail(mgr, taskTimelineList);
			}
			
			return new QueryResult<TaskTimelines>(taskTimelineList, cursorString);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public void setTaskTimelinesDetail(List<TaskTimelines> taskTimelineList) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			setTaskTimelinesDetail(mgr, taskTimelineList);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void setTaskTimelinesDetail(EntityManager mgr, List<TaskTimelines> taskTimelineList) throws Exception {
		if (taskTimelineList != null && taskTimelineList.size() > 0) {
			Set<String> resultTaskIds = new HashSet<String>();
			Set<String> resultBoardIds = new HashSet<String>();
			for (TaskTimelines taskTimeline : taskTimelineList) {
				resultTaskIds.add(taskTimeline.getTaskId());
				resultBoardIds.add(taskTimeline.getBoardId());
			}
			
			Map<String, Tasks> taskMap = batchMapByKey(mgr, Tasks.class, resultTaskIds);
			Map<String, Boards> boardMap = batchMapByKey(mgr, Boards.class, resultBoardIds);
			Map<String, Users> userMap = batchMapTaskTimelineUsers(mgr, taskTimelineList, false);
			Map<String, List<TaskTimelineComments>> commentsMap = batchMapTaskTimelineComments(mgr, taskTimelineList);
			Map<String, List<Images>> imagesMap = batchMapTaskTimelineImages(mgr, taskTimelineList);
			Map<String, List<Attachments>> attachmentsMap = batchMapTaskTimelineAttachments(mgr, taskTimelineList);
			
			for (TaskTimelines taskTimeline : taskTimelineList) {
				Tasks task = taskMap.get(taskTimeline.getTaskId());
				taskTimeline.setTaskTitle(task.getTitle());
				Boards board = boardMap.get(taskTimeline.getBoardId());
				taskTimeline.setBoardTitle(board.getTitle());
				taskTimeline.setUser(userMap.get(taskTimeline.getCreator()));
				taskTimeline.setComments(commentsMap.get(taskTimeline.getTaskTimelineId()));
				taskTimeline.setImages(imagesMap.get(taskTimeline.getTaskTimelineId()));
				taskTimeline.setAttachments(attachmentsMap.get(taskTimeline.getTaskTimelineId()));
//				List<Images> images = batchListByField(mgr, Images.class, taskTimeline.getTaskTimelineId(), FLD.parentId);
//				List<Attachments> attachments = batchListByField(mgr, Attachments.class, taskTimeline.getTaskTimelineId(), FLD.parentId);
//				taskTimeline.setImages(images);
//				taskTimeline.setAttachments(attachments);
			}
		}
	}
	
	@Override
	public Map<String, List<Images>> batchMapTaskTimelineImages(EntityManager mgr, List<TaskTimelines> taskTimelineList) throws Exception {
		if (taskTimelineList == null || taskTimelineList.size() == 0) { return new HashMap<String, List<Images>>(); }
		List<String> taskTimelineIds = new ArrayList<String>();
		for (TaskTimelines taskTimeline : taskTimelineList) {
			taskTimelineIds.add(taskTimeline.getTaskTimelineId());
		}
		return imageService.batchMapChildImages(mgr, taskTimelineIds);
	}
	@Override
	public Map<String, List<Attachments>> batchMapTaskTimelineAttachments(EntityManager mgr, List<TaskTimelines> taskTimelineList) throws Exception {
		if (taskTimelineList == null || taskTimelineList.size() == 0) { return new HashMap<String, List<Attachments>>(); }
		List<String> taskTimelineIds = new ArrayList<String>();
		for (TaskTimelines taskTimeline : taskTimelineList) {
			taskTimelineIds.add(taskTimeline.getTaskTimelineId());
		}
		return attachmentService.batchMapChildAttachments(mgr, taskTimelineIds);
		
	}
	private Map<String, Users> batchMapTaskTimelineUsers(EntityManager mgr, List<TaskTimelines> taskTimelineList, boolean includeProfile) throws Exception {
		if (taskTimelineList == null || taskTimelineList.size() == 0) { return new HashMap<String, Users>(); }
		Set<String> userIds = new HashSet<String>();
		for (TaskTimelines taskTimeline : taskTimelineList) {
			userIds.add(taskTimeline.getCreator());
		}
		return userService.batchMapUsers(mgr, userIds, includeProfile);
	}
	
	private Map<String, List<TaskTimelineComments>> batchMapTaskTimelineComments(EntityManager mgr, List<TaskTimelines> taskTimelineList) throws Exception {
		if (taskTimelineList == null || taskTimelineList.size() == 0) { return new HashMap<String, List<TaskTimelineComments>>(); }
		Map<String, List<TaskTimelineComments>> commentsMap = new HashMap<String, List<TaskTimelineComments>>();

		for (TaskTimelines taskTimeline : taskTimelineList) {
			String taskTimelineId = taskTimeline.getTaskTimelineId();
			List<TaskTimelineComments> commentResults = taskTimelineCommentService
					.listTaskTimelineComments(mgr, taskTimelineId);
			
			if (!commentsMap.containsKey(taskTimelineId)) { commentsMap.put(taskTimelineId, new ArrayList<TaskTimelineComments>()); }
			commentsMap.get(taskTimelineId).addAll(commentResults);
		}
		
		return commentsMap;
	}
	
	@Override
	public TaskTimelines getTaskTimelines(String taskTimelineId) throws Exception{
		EntityManager mgr = getEntityManager();
		try {
			return getTaskTimelines(mgr, taskTimelineId, false);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public TaskTimelines getTaskTimelines(String domainName, String taskTimelineId) throws Exception{
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			return getTaskTimelines(taskTimelineId);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
		
	}
	
	private TaskTimelines getTaskTimelines(EntityManager mgr, String taskTimelineId, boolean simpleMode) throws Exception{
		TaskTimelines taskTimeline = doFind(mgr, TaskTimelines.class, taskTimelineId);
		if (taskTimeline == null) {	return null; }
		if (!simpleMode) {
			Boards board = doFind(mgr, Boards.class, taskTimeline.getBoardId());
			Tasks task = doFind(mgr, Tasks.class, taskTimeline.getTaskId());
			
			List<Attachments> attachments = attachmentService.listChildAttachments(mgr, taskTimelineId);
			List<Images> images = imageService.listChildImages(mgr, taskTimelineId);
			List<TaskTimelineComments> comments = taskTimelineCommentService.listTaskTimelineComments(mgr, taskTimelineId);
//			List<TaskTimelineComments> comments = taskTimelineCommentService
//					.listTaskTimelineComments(mgr, null, null,
//							Arrays.asList(new String[] { taskTimelineId }))
//					.getResultList();
			
			taskTimeline.setAttachments(attachments);
			taskTimeline.setImages(images);
			taskTimeline.setComments(comments);
			if (board != null) { taskTimeline.setBoardTitle(board.getTitle()); }
			if (task != null) { taskTimeline.setTaskTitle(task.getTitle()); }
			
			Users user = userService.getUsers(mgr, taskTimeline.getCreator(), false);
			taskTimeline.setUser(user);
		}
		
		return taskTimeline;
	}

	@Override
	public TaskTimelines getParentTaskTimelines(String taskTimelineCommentId) throws Exception{
		EntityManager mgr = getEntityManager();
		try {
			TaskTimelineComments comment = doFind(mgr, TaskTimelineComments.class, taskTimelineCommentId);
			return getTaskTimelines(mgr, comment.getTaskTimelineId(), false);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public TaskTimelines insertTaskTimelines(TaskTimelines taskTimeline) throws Exception {
		Users loginUser = getCurrentUser();
		return insertTaskTimelines(taskTimeline, loginUser);
	}
	
	@Override
	public TaskTimelines insertTaskTimelines(TaskTimelines taskTimeline, Users user) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			taskTimeline.setCreator(user.getUserId());
			taskTimeline.setOwner(user.getUserId());
			
			Tasks task = doFind(mgr, Tasks.class, taskTimeline.getTaskId());
			Boards board = doFind(mgr, Boards.class, task.getBoardId());
			
			taskTimeline.setKey(KeyUtil.createTaskTimelineKey());
			taskTimeline.setDomainId(task.getDomainId());
			taskTimeline.setBoardId(task.getBoardId());
//			taskTimeline.setModified(taskTimeline.getCreated());
			taskTimeline.setLastCommented(taskTimeline.getCreated());
			taskTimeline.setUser(user);
			taskTimeline.setBoardTitle(board.getTitle());
			taskTimeline.setTaskTitle(task.getTitle());
			
			if (contains(mgr, TaskTimelines.class, taskTimeline.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(TaskTimelines.class, taskTimeline.getTaskTimelineId()));
			}
			
			try {
				createOrUpdateTaskTimelineIndex(taskTimeline);
				updateTaskTimelineAttachments(taskTimeline);
				updateTaskTimelineImages(taskTimeline);
			} catch (Exception ex) {
				removeTaskTimelineIndex(taskTimeline.getTaskTimelineId());
				LOG.warning(ex.getMessage());
				throw ex;
			}
			
			doPersistTransaction(mgr, taskTimeline);

			try {
				ActivityType activityType = ActivityType.ADDED;
				if (taskTimeline.getMentionIds() != null && taskTimeline.getMentionIds().size() > 0) {
					activityType = ActivityType.ADDED_WITH_MENTION;
				}
				Activities activity = activityService.createTaskTimelineActivity(taskTimeline, null, activityType, user);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return taskTimeline;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public TaskTimelines copyTaskTimelines(String taskTimelineId, String toTaskId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Users loginUser = getCurrentUser();
			
			TaskTimelines originTimeline = getTaskTimelines(taskTimelineId);
			TaskTimelines targetTimeline = new TaskTimelines();
			
			CopyUtil.copy(targetTimeline, originTimeline);
			
			targetTimeline.setCreator(loginUser.getUserId());
			targetTimeline.setOwner(loginUser.getUserId());
			
			Tasks targetTask = doFind(mgr, Tasks.class, toTaskId);
			Boards targetBoard = doFind(mgr, Boards.class, targetTask.getBoardId());
			
			targetTimeline.setKey(KeyUtil.createTaskTimelineKey());
			targetTimeline.setDomainId(targetTask.getDomainId());
			targetTimeline.setBoardId(targetTask.getBoardId());
			targetTimeline.setTaskId(toTaskId);
			targetTimeline.setModified(null);
			targetTimeline.setLastCommented(null);
			targetTimeline.setLastCommented(targetTimeline.getCreated());
			targetTimeline.setUser(loginUser);
			targetTimeline.setBoardTitle(targetBoard.getTitle());
			targetTimeline.setTaskTitle(targetTask.getTitle());
			
			if (contains(mgr, TaskTimelines.class, targetTimeline.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(TaskTimelines.class, targetTimeline.getTaskTimelineId()));
			}
			
			try {
				createOrUpdateTaskTimelineIndex(targetTimeline);
				updateTaskTimelineAttachments(targetTimeline);
				updateTaskTimelineImages(targetTimeline);
			} catch (Exception ex) {
				removeTaskTimelineIndex(targetTimeline.getTaskTimelineId());
				LOG.warning(ex.getMessage());
				throw ex;
			}
			
			doPersistTransaction(mgr, targetTimeline);

			try {
				ActivityType activityType = ActivityType.COPIED;
				Activities activity = activityService.createTaskTimelineActivity(targetTimeline, null, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return targetTimeline;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public TaskTimelines updateTaskTimelines(TaskTimelines taskTimeline) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			Users loginUser = getCurrentUser();
			TaskTimelines originTasktimeline = doFind(mgr, TaskTimelines.class, taskTimeline.getTaskTimelineId()); 
			valid(taskTimeline);
			Tasks task = doFind(mgr, Tasks.class, taskTimeline.getTaskId());
			Boards board = doFind(mgr, Boards.class, task.getBoardId());
			
			List<String> originMentions = originTasktimeline.getMentionIds();
			List<String> currentMentions = taskTimeline.getMentionIds();
			
			taskTimeline.setLastCommented(new Date());
			
			try {
				createOrUpdateTaskTimelineIndex(taskTimeline);
				updateTaskTimelineAttachments(taskTimeline);
				updateTaskTimelineImages(taskTimeline);
			} catch (Exception ex) {
				removeTaskTimelineIndex(taskTimeline.getTaskTimelineId());
				LOG.warning(ex.getMessage());
				throw ex;
			}
			
			beginTransaction(mgr);
			List<Images> images = taskTimeline.getImages();
			List<Attachments> attachments = taskTimeline.getAttachments();
			taskTimeline = doMerge(mgr, taskTimeline);
			taskTimeline.setMentionIds(currentMentions);	// List 타입등 Collection or Array 타입등은 추가적으로 attach를 시켜줘야 제대로 merge가 된다.
			commitTransaction(mgr);
			
			taskTimeline.setImages(images);
			taskTimeline.setAttachments(attachments);
			taskTimeline.setUser(loginUser);
			taskTimeline.setBoardTitle(board.getTitle());
			taskTimeline.setTaskTitle(task.getTitle());
			
			try {
				ActivityType activityType = ActivityType.UPDATED;
				List<String> newMentions = getNewMentions(originMentions, currentMentions);
				if (newMentions != null && newMentions.size() > 0) {
					activityType = ActivityType.UPDATED_WITH_MENTION;
				}
				Activities activity = activityService.createTaskTimelineActivity(taskTimeline, newMentions, activityType, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return taskTimeline;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public TaskTimelines updateTasktimelinesLastCommented(String taskTimelineId, Date lastCommented) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			TaskTimelines taskTimeline = doFind(mgr, TaskTimelines.class, taskTimelineId);
			valid(taskTimeline);
			
			taskTimeline.setLastCommented(lastCommented);
			doMergeTransaction(mgr, taskTimeline, false);
			
			try {
				createOrUpdateTaskTimelineIndex(taskTimeline);
			} catch (Exception ex) {
			}
			return taskTimeline;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public void removeTaskTimelines(String taskTimelineId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			TaskTimelines taskTimeline = doFind(mgr, TaskTimelines.class, taskTimelineId);
			valid(taskTimeline);

			taskTimeline.setDeleteYN(Y);
			taskTimeline.setDeleted(new Date());

			doMergeTransaction(mgr, taskTimeline);

			try {
				removeTaskTimelineIndex(taskTimelineId);
				boolean archived = Y.equals(taskTimeline.getArchiveYN());
				boolean deleted = Y.equals(taskTimeline.getDeleteYN());
				attachmentService.markChildAttachments(taskTimelineId, archived, deleted);
				imageService.removeChildImages(taskTimelineId);
			} catch (Exception ex) { LOG.warning(ex.getMessage());  }
			try {
				Users loginUser = getCurrentUser();
				Activities activity = activityService.createTaskTimelineActivity(taskTimeline, null, ActivityType.DELETED, loginUser);
				activityService.insertActivities(activity);
			} catch (Exception ex) { LOG.warning(ex.getMessage());}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public TimelineIndex createOrUpdateTaskTimelineIndex(TaskTimelines taskTimeline) {
		try {
			TimelineIndex timelineIndex = null;
			
			if (taskTimeline != null) {
				timelineIndex = new TimelineIndex(taskTimeline);

//				String userIdIndexStr = null;
//				CollectionResponse<MemberAuths> members = taskService.listTasksMembers(taskTimeline.getTaskId());
//				if (members != null && members.getItems() != null && members.getItems().size() > 0) {
//					List<String> memberList = new ArrayList<String>();
//					for (MemberAuths member : members.getItems()) {
////						if (member.getUser()!=null) {
////							if (StringUtils.isNotBlank(member.getUser().getEmail())) { memberList.add(member.getUser().getEmail()); }
////							if (StringUtils.isNotBlank(member.getUser().getNickName())) { memberList.add(member.getUser().getNickName()); }
////							if (StringUtils.isNotBlank(member.getUser().getId())) { memberList.add(member.getUser().getId()); }
////						}
//						memberList.add(member.getUserId());
//					}
//					userIdIndexStr = StringUtils.join(memberList, " ");
//				}
//				
//				timelineIndex.setAssignUserIds(userIdIndexStr);
				
				SearchManager sm = new SearchManager();
				sm.createIndexAsync(timelineIndex);
				//sm.createIndex(timelineIndex);
			}
			return timelineIndex;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}
	
	private void removeTaskTimelineIndex(String taskTimelineId) {
		try {
			SearchManager searchManager = new SearchManager();
			searchManager.deleteDocuments(TimelineIndex.class, taskTimelineId);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}
	
	@Override
	public Attachments addTaskTimelineAttachment(String taskTimelineId, Attachments attachment) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			TaskTimelines taskTimeline = doFind(mgr, TaskTimelines.class, taskTimelineId);
			valid(taskTimeline);

			attachment = attachmentService.addChildAttachment(taskTimelineId, attachment);

			doMergeTransaction(mgr, taskTimeline);

			try {
				createOrUpdateTaskTimelineIndex(taskTimeline);
				
				Users loginUser = getCurrentUser();
				activityService.insertActivities(activityService.createTaskTimelineActivity(taskTimeline,
						attachment, ActivityType.ATTACHED, loginUser));
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			
			return attachment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Attachments removeTaskTimelineAttachment(String taskTimelineId, String attachmentId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			TaskTimelines taskTimeline = doFind(mgr, TaskTimelines.class, taskTimelineId);
			valid(taskTimeline);

			Attachments attachment = attachmentService.removeChildAttachment(taskTimelineId, attachmentId);
			
			doMergeTransaction(mgr, taskTimeline);
			
			try {
				createOrUpdateTaskTimelineIndex(taskTimeline);
				Users loginUser = getCurrentUser();
				activityService.insertActivities(activityService.createTaskTimelineActivity(taskTimeline,
						attachment, ActivityType.UNATTACHED, loginUser));
			} catch (Exception e) {
				LOG.warning(e.getMessage());
				// Ignored. Not a critical part of application.
			}
			
			return attachment;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private void updateTaskTimelineAttachments(TaskTimelines taskTimeline) throws Exception {
		String taskTimelineId = taskTimeline.getTaskTimelineId();
		List<Attachments> attachments = new ArrayList<Attachments>();
		List<Attachments> addAttachments = new ArrayList<Attachments>();
		List<Attachments> updateAttachments = new ArrayList<Attachments>();
		
		EntityManager mgr = getEntityManager();
		try {
			for (Attachments attachment : taskTimeline.getAttachments()) {
				Key attachmentKey = attachment.getKey();
				if (attachmentKey == null) { attachmentKey = KeyUtil.createAttachmentKey(attachment); }
				
				if (doFind(mgr, Attachments.class, attachmentKey) == null) {
					addAttachments.add(attachment);
				} else {
					attachment.setKey(attachmentKey);
					updateAttachments.add(attachment);
				}
				
//				if (StringUtils.isBlank(attachment.getAttachmentId()) ) {
//					addAttachments.add(attachment);
//				} else {
//					updateAttachments.add(attachment);
//				}
			}
		} finally {
			finalizeTransaction(mgr);
		}
		
		attachments.addAll(attachmentService.updateChildAttachments(taskTimelineId, updateAttachments));
		attachments.addAll(attachmentService.addChildAttachments(taskTimelineId, addAttachments));
		
		taskTimeline.setAttachments(attachments);
//		String taskTimelineId = taskTimeline.getTaskTimelineId();
//		List<Attachments> attachments = taskTimeline.getAttachments();
//		attachmentService.updateTaskTimelineAttachments(taskTimelineId, attachments);
	}
	
	private void updateTaskTimelineImages(TaskTimelines taskTimeline) throws Exception {
		String taskTimelineId = taskTimeline.getTaskTimelineId();
		List<Images> images = taskTimeline.getImages();
		imageService.appendOrRemoveImages(taskTimelineId, images);
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public int bulkRemoveTaskTimelines(String taskId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			TypedQuery<Key> query = new QueryBuilder<>(TaskTimelines.class)
//					.addClause(FLD.taskId, taskId)
//					.buildKeyOnlyRead(mgr);
//
//			List<Key> keys = listAllKeysForLimitedChunkSize(query);
//			
//			for (Key key : keys) {
//				permanentRemoveTaskTimelines(mgr, KeyFactory.keyToString(key));
//			}
//
//			return keys.size();
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	private void permanentRemoveTaskTimelines(EntityManager mgr, String taskTimelineId) throws Exception {
//		try {
//			TaskTimelines taskTimeline = doFind(mgr, TaskTimelines.class, taskTimelineId);
//			doRemoveTransaction(mgr, taskTimeline);
//
//			try {
//				removeTaskTimelineIndex(taskTimelineId);
////				taskTimelineScoreService.bulkRemoveTaskTimelineScores(taskTimelineId);
//				taskTimelineCommentService.bulkRemoveTaskTimelineComments(taskTimelineId);
//				attachmentService.removeTaskTimelineAttachments(taskTimelineId);
//				imageService.removeTaskTimelineImages(taskTimelineId);
//			} catch (Exception ex) { LOG.warning(ex.getMessage());  }
//			try {
//				Users loginUser = getCurrentUser();
//				Activities activity = activityService.createTaskTimelineActivity(taskTimeline, null, ActivityType.DELETED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	@Override
//	public List<TaskTimelineScores> listEvaluateTaskTimelines(String taskTimelineId, EvaluateType evaluateType) throws Exception {
//		return taskTimelineScoreService.listTaskTimelineScores(taskTimelineId, evaluateType);
//	}
//	@Override
//	public TaskTimelines evaluateTaskTimeline(String taskTimelineId, EvaluateType evaluateType) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Users loginUser = getCurrentUser();
//			
////			if (loginUser.getNuts() <= 0) {
////				throw new UnavailableException(ErrorCode.UNAVAILABLE.getMessage("Nuts is lacking."));
////			}
//			
//			TaskTimelines taskTimeline = getTaskTimelines(mgr, taskTimelineId, true);
//			valid(taskTimeline);
//			
////			switch(evaluateType) {
////				case Excellent : taskTimeline.setEvalExcellents(taskTimeline.getEvalExcellents()+1);
////					break;
////				case Good : taskTimeline.setEvalGoods(taskTimeline.getEvalGoods()+1);
////					break;
////				case Effort : taskTimeline.setEvalEfforts(taskTimeline.getEvalEfforts()+1);
////					break;
////			}
//
//			taskTimelineScoreService.insertTaskTimelineScores(new TaskTimelineScores(
//					 taskTimeline.getTaskId()
//					, taskTimeline.getTaskTimelineId()
//					, loginUser.getUserId()
//					, evaluateType));
//			
//			int excellentCount = 0;
//			int goodCount = 0;
//			int effortCount = 0;
//			
//			List<TaskTimelineScores> listScores = taskTimelineScoreService.listTaskTimelineScores(mgr, taskTimelineId, null);
//			for (TaskTimelineScores score : listScores) {
//				switch(score.getEvaluateType()) {
//					case Excellent : excellentCount++; break;
//					case Good : goodCount++; break;
//					case Effort : effortCount++; break;
//				}
//			}
//			taskTimeline.setEvalExcellents(excellentCount);
//			taskTimeline.setEvalGoods(goodCount);
//			taskTimeline.setEvalEfforts(effortCount);
//			taskTimeline.setLastCommented(new Date());
//
//			
//			doMergeTransaction(mgr, taskTimeline);
////			Users user = userService.getSimpleUsers(mgr, loginUser.getUserId());
////			user.setNuts(user.getNuts()-1);
////			doMergeTransaction(mgr, user);
//
//			try {
//				Activities activity = activityService.createTaskTimelineActivity(taskTimeline, null, ActivityType.EVALUATED, loginUser);
//				activityService.insertActivities(activity);
//			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			
//			return taskTimeline;
//		} catch (UnavailableException ex) {
//			throw ex;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public TaskTimelines cancelEvaluateTaskTimeline(String taskTimelineId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Users loginUser = getCurrentUser();
//			
//			TaskTimelines taskTimeline = getTaskTimelines(mgr, taskTimelineId, false);
//			valid(taskTimeline);
//			
////			switch(evaluateType) {
////				case Excellent : taskTimeline.setEvalExcellents(taskTimeline.getEvalExcellents()-1);
////					break;
////				case Good : taskTimeline.setEvalGoods(taskTimeline.getEvalGoods()-1);
////					break;
////				case Effort : taskTimeline.setEvalEfforts(taskTimeline.getEvalEfforts()-1);
////					break;
////			}
//
//			Key taskTimelineScoreKey = KeyUtil.createTaskTimelineScoreKey(taskTimelineId, loginUser);
//			
//			TaskTimelineScores taskTimelineScore = taskTimelineScoreService.removeTaskTimelineScores(taskTimelineScoreKey);
//			if (taskTimelineScore != null) {
//				int excellentCount = 0;
//				int goodCount = 0;
//				int effortCount = 0;
//				
//				List<TaskTimelineScores> listScores = taskTimelineScoreService.listTaskTimelineScores(mgr, taskTimelineId, null);
//				for (TaskTimelineScores score : listScores) {
//					if (score.getTaskTimelineScoreId().equals(taskTimelineScore.getTaskTimelineScoreId())) { continue; }
//					switch(score.getEvaluateType()) {
//						case Excellent : excellentCount++; break;
//						case Good : goodCount++; break;
//						case Effort : effortCount++; break;
//					}
//				}
//				taskTimeline.setEvalExcellents(excellentCount);
//				taskTimeline.setEvalGoods(goodCount);
//				taskTimeline.setEvalEfforts(effortCount);
//
//				doMergeTransaction(mgr, taskTimeline);
////				Users user = userService.getSimpleUsers(mgr, loginUser.getUserId());
////				user.setNuts(user.getNuts()+1);
////				doMergeTransaction(mgr, user);
//				
//				try {
//					Activities activity = activityService.createTaskTimelineActivity(taskTimeline, null, ActivityType.CANCEL_EVALUATED, loginUser);
//					activityService.insertActivities(activity);
//				} catch (Exception ex) { LOG.warning(ex.getMessage()); }
//			}
//			
//			return taskTimeline;
//		} catch (UnavailableException ex) {
//			throw ex;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public boolean isEvaluatedTaskTimeline(String taskTimelineId) {
//		return contains(TaskTimelineScores.class, taskTimelineId);
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
