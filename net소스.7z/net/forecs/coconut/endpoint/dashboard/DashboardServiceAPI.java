package net.forecs.coconut.endpoint.dashboard;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelines;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;


@Api(name = API.DASHBOARD_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.DASHBOARD_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class DashboardServiceAPI {
	private final IDashboardService dashboardService;
//	private static final String N = "N";
	
	@Inject
	public DashboardServiceAPI(IDashboardService dashboardService) {
		this.dashboardService = dashboardService;
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getMyDashbordMemberList", path = "dashboard/my/members", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Users> getMyDashbordMemberList(@Nullable @Named(FLD.domainId) String domainId)
//			throws Exception {
//		if (StringUtils.isNotBlank(domainId)) {
//			CommonService.validNamespace(domainId);
//		}
//		List<Users> list = dashboardService.getMyDashbordMemberList(domainId);
//		return CollectionResponse.<Users>builder().setItems(list).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getDashbordMemberList", path = "dashboard/members", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Users> getDashbordMemberList(@Nullable @Named(FLD.domainId) String domainId, @Named(FLD.userId) String userId) throws Exception{
//		CommonService.validNamespace(userId);
//		List<Users> list = dashboardService.getDashbordMemberList(domainId, userId);
//		return CollectionResponse.<Users>builder().setItems(list).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "queryMyDashboardTasks", path = "dashboard/my/tasks", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Tasks> queryMyDashboardTasks(@Nullable @Named(FLD.domainId) String domainId) throws Exception {
//		if (StringUtils.isNotBlank(domainId)) {
//			CommonService.validNamespace(domainId);
//		}
//		QueryResult<Tasks> queryResult = dashboardService.queryMyDashboardTasks(null, null, domainId, N, null, null);
//		List<Tasks> list = queryResult.getResultList();
//		return CollectionResponse.<Tasks>builder().setItems(list).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "queryDashboardTasks", path = "dashboard/tasks", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Tasks> queryDashboardTasks(
//			@Nullable @Named(FLD.domainId) String domainId,
//			@Named(FLD.userIdList) List<String> userIdList) throws Exception {
//		if (StringUtils.isNotBlank(domainId)) {
//			CommonService.validNamespace(domainId);
//		} else {
//			CommonService.validNamespace(userIdList.get(0));
//		}
//		QueryResult<Tasks> queryResult = dashboardService.queryDashboardTasks(null, null, domainId, N, userIdList, null, null);
//		List<Tasks> list = queryResult.getResultList();
//		return CollectionResponse.<Tasks>builder().setItems(list).build();
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryMyDashboardTimelines", path = "dashboard/my/timelines", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<TaskTimelines> queryMyDashboardTimelines(	
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.userIdList) List<String> userIdList, 
			@Nullable @Named(FLD.sortType) SortType sortType,
			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		}
		sortType = SortType.lastCommented;
		sortDirection = SortDirection.DESC;
		QueryResult<TaskTimelines> queryResult = dashboardService.queryMyDashboardTimelines(cursorString, limit, userIdList, sortType, sortDirection);
		List<TaskTimelines> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<TaskTimelines>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "queryDashboardTimelines", path = "dashboard/timelines", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<TaskTimelines> queryDashboardTimelines(	
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.domainId) String domainId,
//			@Nullable @Named(FLD.userIdList) List<String> userIdList,
//			@Nullable @Named(FLD.sortType) SortType sortType,
//			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection) throws Exception {
//		if (StringUtils.isNotBlank(domainId)) {
//			CommonService.validNamespace(domainId);
//		} else if (userIdList != null && userIdList.size() > 0) {
//			CommonService.validNamespace(userIdList.get(0));
//		}
//		sortType = SortType.lastCommented;
//		sortDirection = SortDirection.DESC;
//		
//		QueryResult<TaskTimelines> queryResult = dashboardService.queryDashboardTimelines(cursorString, limit, domainId, userIdList, sortType, sortDirection);
//		List<TaskTimelines> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<TaskTimelines>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "queryMyDashboardEvents", path = "dashboard/my/events", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Events> queryMyDashboardEvents(	
//			@Nullable @Named(FLD.domainId) String domainId,
//			@Nullable @Named(FLD.eventType) List<EventType> eventTypeList,
//			@Named(FLD.startDate) Date startDate,
//			@Named(FLD.endDate) Date endDate) throws Exception {
//		if (StringUtils.isNotBlank(domainId)) {
//			CommonService.validNamespace(domainId);
//		}
//		List<Events> list = dashboardService.queryMyDashboardInstances(domainId, eventTypeList, startDate, endDate);
//		return CollectionResponse.<Events>builder().setItems(list).build();
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryDashboardEvents", path = "dashboard/events", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Events> queryDashboardEvents(	
			@Nullable @Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.userIdList) List<String> userIdList,
			@Nullable @Named(FLD.eventType) List<EventType> eventTypeList,
			@Named(FLD.startDate) Date startDate,
			@Named(FLD.endDate) Date endDate) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		} else if (userIdList != null && userIdList.size() > 0) {
			CommonService.validNamespace(userIdList.get(0));
		}
		List<Events> list = dashboardService.queryDashboardInstances(userIdList, eventTypeList, startDate, endDate);
		return CollectionResponse.<Events>builder().setItems(list).build();
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "queryDashboardActivities", path = "dashboard/activities", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Activities> queryDashboardActivities(
//			@Nullable @Named(FLD.cursor) String cursorString, 
//			@Nullable @Named(FLD.limit) Integer limit, 
//			@Nullable @Named(FLD.domainId) String domainId, 
//			@Named(FLD.userIdList) List<String> userIdList) throws Exception {
//		if (StringUtils.isNotBlank(domainId)) {
//			CommonService.validNamespace(domainId);
//		} else if (userIdList != null && userIdList.size() > 0) {
//			CommonService.validNamespace(userIdList.get(0));
//		}
//		QueryResult<Activities> queryResult = dashboardService.queryDashboardActivities(cursorString, limit, domainId, userIdList);
//		List<Activities> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryMyDashboardActivities", path = "dashboard/my/activities", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Activities> queryMyDashboardActivities(
			@Nullable @Named(FLD.cursor) String cursorString, 
			@Nullable @Named(FLD.limit) Integer limit, 
			@Nullable @Named(FLD.domainId) String domainId) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		}
		QueryResult<Activities> queryResult = dashboardService.queryMyDashboardActivities(cursorString, limit);
		List<Activities> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "queryMyDashboardNotice", path = "dashboard/my/notice", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Notice> queryMyDashboardNotice(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainId) String domainId) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		}
		QueryResult<Notice> queryResult = dashboardService.queryMyDashboardNotice(cursorString, limit);
		List<Notice> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Notice>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "queryDashboardNotice", path = "dashboard/notice", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<Notice> queryDashboardNotice(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Nullable @Named(FLD.domainId) String domainId,
//			@Named(FLD.userIdList) List<String> userIdList) throws Exception {
//		if (StringUtils.isNotBlank(domainId)) {
//			CommonService.validNamespace(domainId);
//		} else if (userIdList.size() > 0) {
//			CommonService.validNamespace(userIdList.get(0));
//		}
//		QueryResult<Notice> queryResult = dashboardService.queryDashboardNotice(cursorString, limit, domainId, userIdList);
//		List<Notice> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<Notice>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}
	
	@ApiMethod(name = "listMyDashboardMembers", path = "dashboard/my/members", httpMethod = HttpMethod.GET)
	@RequiresUser
	public List<Users> listMyDashboardMembers(@Nullable @Named(FLD.domainId) String domainId) throws Exception {
		if (StringUtils.isNotBlank(domainId)) {
			CommonService.validNamespace(domainId);
		}
		return dashboardService.listMyDashboardMembers();
	}
}