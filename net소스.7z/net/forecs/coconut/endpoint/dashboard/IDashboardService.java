package net.forecs.coconut.endpoint.dashboard;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelines;


public interface IDashboardService extends ICommonService {
	public abstract QueryResult<TaskTimelines> queryMyDashboardTimelines(
			String cursorString,
			Integer limit,
			List<String> userIdList,
			SortType sortType,
			SortDirection sortDirection) throws Exception;
	public abstract List<Events> queryDashboardInstances (
			Collection<String> userIdList,
			Collection<EventType> eventTypeList,
			Date startDate,
			Date endDate) throws Exception;
	public abstract QueryResult<Activities> queryMyDashboardActivities(String cursorString, Integer limit) throws Exception;
	public abstract QueryResult<Notice> queryMyDashboardNotice(String cursorString, Integer limit) throws Exception;
	public abstract void prepareMyDashboardTimelines(String domainName, String userId, String cursorString, Integer limit, SortType sortType, SortDirection sortDirection) throws Exception;
	public abstract List<Users> listMyDashboardMembers() throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract List<Users> getMyDashbordMemberList(String domainId) throws Exception;
//	public abstract List<Users> getDashbordMemberList(String domainId, String userId) throws Exception;
//	public abstract QueryResult<Tasks> queryMyDashboardTasks(
//			String cursorString, 
//			Integer limit, 
//			String domainId, 
//			String archiveYN, 
//			SortType sortType, 
//			SortDirection sortDirection) throws Exception;
//	public abstract QueryResult<Tasks> queryDashboardTasks(
//			String cursorString, 
//			Integer limit, 
//			String domainId, 
//			String archiveYN, 
//			List<String> userIdList, 
//			SortType sortType, 
//			SortDirection sortDirection) throws Exception;
//	public abstract QueryResult<TaskTimelines> queryDashboardTimelines(
//			String cursorString,
//			Integer limit,
//			String domainId,
//			List<String> userIdList,
//			SortType sortType,
//			SortDirection sortDirection) throws Exception;
//	public abstract List<Events> queryMyDashboardInstances (
//			String domainId,
//			Collection<EventType> eventTypeList,
//			Date startDate,
//			Date endDate) throws Exception;
	/**
	 * @Description : My Dashboard에 속한 Board들의 멤버를 대상으로 캘린더 인스턴스를 생성
	 * @Method      : queryDashboardInstances
	 */
//	public abstract List<Events> queryDashboardInstances (
//			String domainId,
//			Users user,
//			Collection<String> userIdList,
//			Collection<EventType> eventTypeList,
//			Date startDate,
//			Date endDate) throws Exception;
//	public abstract QueryResult<Activities> queryDashboardActivities (
//			String cursorString, 
//			Integer limit, 
//			String domainId, 
//			List<String> userIdList) throws Exception;
//	public abstract QueryResult<Notice> queryDashboardNotice(String cursorString, Integer limit, String domainId, List<String> userIdList) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}