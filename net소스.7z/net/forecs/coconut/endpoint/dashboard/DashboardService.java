package net.forecs.coconut.endpoint.dashboard;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PrepareManager;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.calendar.ICalendarService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.common.INoticeService;
import net.forecs.coconut.endpoint.common.NoticeService;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelines;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;


public class DashboardService extends CommonService implements IDashboardService {
	private static final Logger LOG = Logger.getLogger(DashboardService.class.getName());
	private final IBoardService boardService;
	private final ITaskService taskService;
	private final ITaskTimelineService taskTimelineService;
	private final INoticeService noticeService;
	private final ICalendarService calendarService;
	private final IActivityService activityService;
	
	@Inject
	public DashboardService(
			IBoardService boardService,
			ITaskService taskService,
			ITaskTimelineService taskTimelineService,
			INoticeService noticeService,
			ICalendarService calendarService,
			IActivityService activityService) {
		this.boardService = boardService;
		this.taskService = taskService;
		this.taskTimelineService = taskTimelineService;
		this.noticeService = noticeService;
		this.calendarService = calendarService;
		this.activityService = activityService;
	}
	
	@Override
	public QueryResult<TaskTimelines> queryMyDashboardTimelines(String cursorString, Integer limit, List<String> userIdList, SortType sortType, SortDirection sortDirection) throws Exception {
		QueryResult<TaskTimelines> results = getMyDashboardTimelinesFromMemcache(cursorString, limit, userIdList, sortType, sortDirection);
		if (results != null) { return results; }
		return queryDashboardTimelines(cursorString, limit, userIdList, sortType, sortDirection);
	}
	
	private QueryResult<TaskTimelines> queryDashboardTimelines(String cursorString, Integer limit, List<String> userIdList, SortType sortType, SortDirection sortDirection) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			
			Set<String> boardIdSet = boardService.getUserBoardIds(mgr, loginUser);
//			Set<String> boardIdSet = boardService.getUsersBoardForDashboard(mgr, loginUser, userIdList);
			if (boardIdSet == null || boardIdSet.size() == 0) { return new QueryResult<TaskTimelines>(); }
			List<String> taskIdList = taskService.listMyTaskIds(mgr, boardIdSet);
			QueryResult<TaskTimelines> results = taskTimelineService.queryTaskTimelines(mgr, cursorString, limit, boardIdSet, taskIdList, userIdList, sortType, sortDirection);
			return results;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private QueryResult<TaskTimelines> getMyDashboardTimelinesFromMemcache(String cursorString, Integer limit, List<String> userIdList, SortType sortType, SortDirection sortDirection) throws Exception {
		if (StringUtils.isNotBlank(cursorString)) { return null; }
		if (!SortType.lastCommented.equals(sortType)) { return null; }
		if (!SortDirection.DESC.equals(sortDirection)) { return null; }
		if (userIdList != null) { return null; }
		
		Users loginUser = getCurrentUser();
		PrepareManager pm = new PrepareManager(loginUser.getDomainName());
		QueryResult<TaskTimelines> results = pm.getMyDashboardTimelinesFromMemcache(loginUser.getUserId());
		if (results == null) {
			LOG.warning("[PREPARE-TIMELINE] Data initialization did not become. " + loginUser.getId());
		} else {
			LOG.warning("[PREPARE-TIMELINE] get data from memcache. " + loginUser.getId());
		}
		return results;
	}
	
	@Override
	public void prepareMyDashboardTimelines(String domainName, String userId, String cursorString, Integer limit, SortType sortType, SortDirection sortDirection) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		try {
			PrepareManager pm = new PrepareManager(domainName);
			
			sortType = SortType.lastCommented;
			sortDirection = SortDirection.DESC;
			
			Users user = doFind(mgr, Users.class, userId);
			Set<String> boardIdSet = boardService.getUserBoardIds(mgr, user);
			//Set<String> boardIdSet = boardService.getUsersBoardForDashboard(mgr, user, null);
			if (boardIdSet == null || boardIdSet.size() == 0) { return; }
			
			List<String> taskIdList = taskService.listMyTaskIds(mgr, userId, boardIdSet);
			QueryResult<TaskTimelines> results = taskTimelineService.queryTaskTimelines(mgr, cursorString, limit, boardIdSet, taskIdList, null, sortType, sortDirection);
			
			pm.prepareMyDashboardTimelines(userId, results);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public List<Events> queryDashboardInstances (
			Collection<String> userIdList,
			Collection<EventType> eventTypeList,
			Date startDate,
			Date endDate) throws Exception {
		return calendarService.queryInstanceForDashboard(userIdList, eventTypeList, startDate, endDate);
	}
	
	@Override
	public QueryResult<Activities> queryMyDashboardActivities(String cursorString, Integer limit) throws Exception {
		return queryDashboardActivities(cursorString, limit, null);
	}
	
	private QueryResult<Activities> queryDashboardActivities(String cursorString, Integer limit, List<String> userIdList) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			Set<String> boardIdSet = boardService.getUserBoardIds(mgr, loginUser);
//			Set<String> boardIdSet = boardService.getUsersBoardForDashboard(mgr, loginUser, userIdList);
			if (boardIdSet == null || boardIdSet.size() == 0) { return new QueryResult<Activities>(); }

			return activityService.listDashboardActivities(mgr, cursorString, limit, new ArrayList<String>(boardIdSet), null, true);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public QueryResult<Notice> queryMyDashboardNotice(String cursorString, Integer limit) throws Exception {
		return queryDashboardNotice(cursorString, limit, null);
	}
	
	private QueryResult<Notice> queryDashboardNotice(String cursorString, Integer limit, List<String> userIdList) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			Set<String> boardIdSet = boardService.getUserBoardIds(mgr, loginUser);
//			Set<String> boardIdSet = boardService.getUsersBoardForDashboard(mgr,s loginUser, userIdList);
			if (boardIdSet == null || boardIdSet.size() == 0) { return new QueryResult<Notice>(); }
			
			boardIdSet.add(NoticeService.KINDID_DOMAIN_NOTICE);
			boardIdSet.add(NoticeService.KINDID_SYSTEM_NOTICE);
			return noticeService.queryNotice(mgr, cursorString, limit, boardIdSet);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public List<Users> listMyDashboardMembers() throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			Users loginUser = getCurrentUser();
			List<Boards> userBoards = boardService.getUserBoards(mgr, loginUser);
			return boardService.getAssignedMemberList(mgr, userBoards);	
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public List<Users> getMyDashbordMemberList(String domainId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getMyDashbordMemberList(mgr, domainId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Users> getDashbordMemberList(String domainId, String userId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return getDashbordMemberList(mgr, domainId, userId);
//		} catch (Exception ex) {
//			LOG.severe(ex.getMessage());
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public QueryResult<Tasks> queryMyDashboardTasks(String cursorString, Integer limit, String domainId, String archiveYN, SortType sortType, SortDirection sortDirection) throws Exception {
//		return queryDashboardTasks(cursorString, limit, domainId, archiveYN, null, sortType, sortDirection);
//	}
//	@Override
//	public QueryResult<Tasks> queryDashboardTasks(String cursorString, Integer limit, String domainId, String archiveYN, List<String> userIdList, SortType sortType, SortDirection sortDirection) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			Users loginUser = getCurrentUser();
//			Set<String> boardIdSet = boardService.getUsersBoardForDashboard(mgr, loginUser, userIdList);
//			if (boardIdSet == null || boardIdSet.size() == 0) { return new QueryResult<Tasks>(); }
//			
//			return taskService.queryTasks(mgr, cursorString, limit, domainId, boardIdSet, archiveYN, sortType, sortDirection);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Events> queryMyDashboardInstances(String domainId, Collection<EventType> eventTypeList, Date startDate, Date endDate) throws Exception {
//		Users loginUser = getCurrentUser();
//		return queryDashboardInstances(domainId, loginUser, null, eventTypeList, startDate, endDate);
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
