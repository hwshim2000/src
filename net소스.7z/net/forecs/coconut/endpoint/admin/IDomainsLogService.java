package net.forecs.coconut.endpoint.admin;

import net.forecs.coconut.common.code.DomainsLogType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.domain.DomainsLog;

public interface IDomainsLogService extends ICommonService {

	public abstract QueryResult<DomainsLog> listDomainsLog(
			String domainName,
			DomainsLogType logType,
			String cursorString,
			Integer limit) throws Exception;
	public abstract DomainsLog getDomainsLog(String domainLogId);
	public abstract DomainsLog insertDomainsLog(DomainsLog domainslog);
	public abstract void removeDomainsLog(String domainLogId);
	public abstract DomainsLog findByRegistedCouponCode(String couponCode);
//	public abstract DomainsLog findByRegistedImpUid(String imp_uid);
}
