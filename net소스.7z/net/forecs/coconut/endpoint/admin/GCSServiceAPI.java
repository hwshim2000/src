package net.forecs.coconut.endpoint.admin;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.util.GcsTree.Node;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.services.storage.model.Objects;
import com.google.api.services.storage.model.StorageObject;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class GCSServiceAPI {
	private final IGCSService gcsService;
	
	@Inject
	public GCSServiceAPI(IGCSService gcsService) {
		this.gcsService = gcsService;
	}
	
	@ApiMethod(name = "requestDowonloadKey", path = "gcs/download/key", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Result requestDowonload(HttpServletRequest req, @Named(FLD.accessToken) String accessToken) throws Exception {
		return new Result(MemcacheManager.createAccessKey(req));
	}
	
	@ApiMethod(name = "emoticonList", path = "gcs/emoticons/list", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Objects emoticonList(
			@Nullable @Named(FLD.prefix) String prefix,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Long limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return gcsService.emoticonList(prefix, cursorString, limit);
	}
	
	@ApiMethod(name = "emoticonNode", path = "gcs/emoticons/node", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Node emoticonNode(
			@Nullable @Named(FLD.prefix) String prefix,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Long limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return gcsService.emoticonNode(prefix, cursorString, limit);
	}
	
	@ApiMethod(name = "attachmentList", path = "gcs/attachments/list", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Objects attachmentList(
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.boardId) String boardId,
			@Nullable @Named(FLD.taskId) String taskId,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Long limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return gcsService.attachmentList(domainName, boardId, taskId, cursorString, limit);
	}
	
	@ApiMethod(name = "attachmentNode", path = "gcs/attachments/node", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Node attachmentNode(
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.boardId) String boardId,
			@Nullable @Named(FLD.taskId) String taskId,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Long limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return gcsService.attachmentNode(domainName, boardId, taskId, cursorString, limit);
	}
	
	@ApiMethod(name = "getStorageObject", path = "gcs/objects", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public StorageObject getStorageObject(
			@Named(FLD.bucket) String bucket,
			@Named(FLD.name) String name,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return gcsService.getStorageObject(bucket, name);
	}
	
	@ApiMethod(name = "deleteStorageObject", path = "gcs/objects", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void deleteStorageObject(
			@Named(FLD.bucket) String bucket,
			@Named(FLD.prefix) String prefix,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		gcsService.deleteStorageObject(bucket, prefix);
	}
	
	@ApiMethod(name = "deleteDomainObject", path = "gcs/objects/domains", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void deleteDomainObject(@Named(FLD.domainName) String domainName, @Named(FLD.accessToken) String accessToken) throws Exception {
		gcsService.deleteDomainObject(domainName);
	}
	
	@ApiMethod(name = "deleteBoardObject", path = "gcs/objects/boards", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void deleteBoardObject(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.boardId) String boardId,
			@Named(FLD.accessToken) String accessToken, HttpServletResponse res) throws Exception {
		gcsService.deleteBoardObject(domainName, boardId);
	}
	
	@ApiMethod(name = "deleteTaskObject", path = "gcs/objects/tasks", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void deleteTaskObject(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.boardId) String boardId,
			@Named(FLD.taskId) String taskId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		gcsService.deleteTaskObject(domainName, boardId, taskId);
	}
}
