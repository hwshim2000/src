package net.forecs.coconut.endpoint.admin;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.entity.backup.Backups;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;
import com.google.appengine.api.utils.SystemProperty;
import com.google.appengine.datanucleus.query.JPACursorHelper;

public class BackupService extends AdminCommonService implements IBackupService {
	private static final Logger LOG = Logger.getLogger(BackupService.class.getName());
	private static final String GS_BACKUP_URL = "/_ah/datastore_admin/backup.create";
	
	@Override
	public void dataBackupToGCS(String domainName) {
		dataBackupToGCS(domainName, null);
	}
	
	@Override
	public void dataBackupToGCS(String domainName, Long backupTimeMillis) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		try {
			// 중요!!!!
			// bucket name은 프로젝트 내에서 유일한 값이 아니기때문에, 운영모드와 테스트모드에서 모두 적용하기 위해서 각 project마다 backup-projectId 로 생성
			String applicationId = SystemProperty.applicationId.get();
			
			Queue queue = QueueFactory.getQueue(CommonProperty.BACKUP_QUEUE_NAME);
			//final String taskName = String.format("%s", domainName);
			final String bucketName = String.format("backup-%s", applicationId);
			final Date backupDate = new Date();
			final String backupNamePrefix = String.format("%s_%s_", domainName, CalendarUtil.toString(backupDate, "HHmm"));
			final String backupDateTime = CalendarUtil.toString(backupDate, "yyyy/MM/dd/HHmm");
			final String backupPath = String.format("%s/%s/%s", bucketName, domainName, backupDateTime);
			final String backupName = String.format("%s%s",backupNamePrefix, CalendarUtil.toString(backupDate, "yyyy_MM_dd"));
			//LOG.warning(backupBucketName);
			//try { queue.deleteTask(taskName); } catch (Exception ex) {}
			// 새로 큐 등록
			TaskOptions taskOption = TaskOptions.Builder
		            .withUrl(GS_BACKUP_URL)
		            .param(PARAM.NAME, backupNamePrefix)				// backupName-prefix
		            .param(PARAM.QUEUE, queue.getQueueName())	// if null, use default queue
		            .param(PARAM.FILESYSTEM, "gs")				// gs:GogleCloudStorage, blobstore : Google BlobStore
		            .param(PARAM.GS_BUCKET_NAME, backupPath)
		            .param(PARAM.NAMESPACE, domainName)
		            .method(Method.GET);
		            //.taskName(taskName);
			
			List<String> kindList = listKinds(domainName);
			
			for (String kind : kindList) {
				taskOption = taskOption.param(PARAM.KIND, kind);
			}
			
			if (backupTimeMillis != null) {
				taskOption = taskOption.etaMillis(backupTimeMillis);
			}
	
			queue.add(taskOption);
			
			Backups backup = new Backups(bucketName, backupName, domainName, backupPath, backupDate);
			insertBackups(backup);
			LOG.warning("[KINDS] : " + StringUtils.join(kindList, ","));
			LOG.warning(String.format("[%s] backup started.", domainName));
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] %s", domainName, ex.getMessage()));
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public QueryResult<Backups> listBackups(
			String cursorString,
			Integer limit,
			String domainName,
			Date startDate,
			Date endDate) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();

		try {
			Cursor cursor = null;
			
			TypedQuery<Backups> query = new QueryBuilder<>(Backups.class)
					.addClause(FLD.domainName, domainName)
					.addGEClause(FLD.created, startDate, SortDirection.DESC)
					.addLEClause(FLD.created, endDate, SortDirection.DESC)
					.build(mgr);
			
			if (StringUtils.isNotBlank(cursorString)) {
				cursor = Cursor.fromWebSafeString(cursorString);
				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
			}

			if (limit != null) {
				query.setFirstResult(0);
				query.setMaxResults(limit);
			}

			List<Backups> backupList = (List<Backups>) query.getResultList();
			cursor = JPACursorHelper.getCursor(backupList);
			
			return new QueryResult<Backups>(backupList, cursor);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Backups getBackups(String backupId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			return doFind(mgr, Backups.class, backupId);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Backups insertBackups(Backups backup) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			if (backup.getKey() == null) {
				backup.setKey(KeyUtil.createBackupKey());
			}
			
			if (contains(mgr, Backups.class, backup.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Backups.class, backup.getBackupId()));
			}
			
			doPersistTransaction(mgr, backup);
			
			return backup;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public Backups updateBackups(Backups backup) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			valid(backup);
			
			Backups originBackup = backup;
		
			doMergeTransaction(mgr, originBackup);
			
			return originBackup;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public void removeBackups(String backupId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			doRemoveTransaction(mgr, Backups.class, backupId);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
}
