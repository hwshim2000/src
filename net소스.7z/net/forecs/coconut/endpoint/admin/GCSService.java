package net.forecs.coconut.endpoint.admin;

import java.util.ListIterator;

import javax.inject.Inject;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.GcsTree;
import net.forecs.coconut.common.util.GcsTree.Node;
import net.forecs.coconut.common.util.security.OAuthUtils;
import net.forecs.coconut.endpoint.common.CommonService;

import org.apache.commons.lang.StringUtils;

import com.google.api.services.storage.Storage;
import com.google.api.services.storage.model.Objects;
import com.google.api.services.storage.model.StorageObject;

public class GCSService extends CommonService implements IGCSService {
	private static final Logger LOG = Logger.getLogger(GCSService.class.getName());
	
	public static final String EMOTICONS_BUCKET = "cocoworks-emoticons";
	public static final String ATTACHMENT_BUCKET = "cocoworks-task-attachments";
	
	@Inject
	public GCSService() {}
	
	@Override
	public Objects listStorageObjects(String bucket, String delimiter,
			Long maxResults, String pageToken, String prefix,
			String projection, String userProject, String versions)
			throws Exception {
		Storage storage = OAuthUtils.loadGCS();
		com.google.api.services.storage.Storage.Objects.List list = storage.objects().list(bucket);
		
		if (StringUtils.isNotBlank(prefix)) { list = list.setPrefix(prefix); }
		if (maxResults != null) {
			list.setMaxResults(maxResults);
			if (StringUtils.isNotBlank(pageToken)) { list = list.setPageToken(pageToken); }
		}
		if (StringUtils.isNotBlank(projection)) { list = list.setProjection(projection); }
		if (StringUtils.isNotBlank(userProject)) { list = list.setProjection(userProject); }
		if (StringUtils.isNotBlank(versions)) { list = list.setProjection(versions); }
		
		return list.execute();
	}

	@Override
	public void deleteDomainObject(String domainName) {
		try {
			if (StringUtils.isNotBlank(domainName)) {
				throw new UnavailableException("Domain name is required.");
			}
			deleteStorageObject(ATTACHMENT_BUCKET, domainName);
		} catch (Exception ex) {
			LOG.warning("[deleteDomainObject] " + ex.getMessage());
		}
	}
	
	@Override
	public void deleteBoardObject(String domainName, String boardId) {
		try {
			if (StringUtils.isNotBlank(domainName)) {
				throw new UnavailableException("Domain name is required.");
			}
			if (StringUtils.isNotBlank(boardId)) {
				throw new UnavailableException("Board id is required.");
			}
			deleteStorageObject(ATTACHMENT_BUCKET, domainName+"/"+boardId);
		} catch (Exception ex) {
			LOG.warning("[deleteBoardObject] " + ex.getMessage());
		}
	}
	
	@Override
	public void deleteTaskObject(String domainName, String boardId, String taskId) {
		try {
			if (StringUtils.isNotBlank(domainName)) {
				throw new UnavailableException("Domain name is required.");
			}
			if (StringUtils.isNotBlank(boardId)) {
				throw new UnavailableException("Board id is required.");
			}
			if (StringUtils.isNotBlank(taskId)) {
				throw new UnavailableException("Task id is required.");
			}
			deleteStorageObject(ATTACHMENT_BUCKET, domainName+"/"+boardId+"/"+taskId);
		} catch (Exception ex) {
			LOG.warning("[deleteTaskObject] " + ex.getMessage());
		}
	}
	
	@Override
	public Objects emoticonList(String prefix, String cursorString, Long limit) throws Exception {
		return listStorageObjects(EMOTICONS_BUCKET, null, limit, cursorString, prefix, null, null, null);
	}
	@Override
	public Node emoticonNode(String prefix, String cursorString, Long limit) throws Exception {
		Objects gcsList = emoticonList(prefix, cursorString, limit);
		
		GcsTree tree = new GcsTree(EMOTICONS_BUCKET);
		for (StorageObject obj : gcsList.getItems()) {
			tree.add(obj.getName(), obj);
		}
		Node treeNode = tree.getNode();
		treeNode.setNextPageToken(gcsList.getNextPageToken());
		return treeNode;
	}
	@Override
	public Objects attachmentList(String domainName, String boardId, String taskId, String cursorString, Long limit) throws Exception {
		String prefix = null;
		if (StringUtils.isNotBlank(domainName)) { prefix = domainName; }
		if (StringUtils.isNotBlank(boardId)) {
			if (StringUtils.isNotBlank(prefix)) {
				prefix = prefix + "/" + boardId;
			} else {
				prefix = boardId;
			}
		}
		if (StringUtils.isNotBlank(taskId)) {
			if (StringUtils.isNotBlank(prefix)) {
				prefix = prefix + "/" + taskId;
			} else {
				prefix = taskId;
			}
		}
		
		return listStorageObjects(ATTACHMENT_BUCKET, null, limit, cursorString, prefix, null, null, null);
	}
	@Override
	public Node attachmentNode(String domainName, String boardId, String taskId, String cursorString, Long limit) throws Exception {
		Objects gcsList = attachmentList(domainName, boardId, taskId, cursorString, limit);
		
		GcsTree tree = new GcsTree(ATTACHMENT_BUCKET);
		for (StorageObject obj : gcsList.getItems()) {
			tree.add(obj.getName(), obj);
		}
		Node treeNode = tree.getNode();
		treeNode.setNextPageToken(gcsList.getNextPageToken());
		
		return treeNode;
	}
	
	@Override
	public StorageObject getStorageObject(String bucket, String name) throws Exception {
		Storage storage = OAuthUtils.loadGCS();
		StorageObject obj = storage.objects().get(bucket, name).execute();
		return obj;
	}
	@Override
	public void deleteStorageObject(String bucket, String prefix) throws Exception {
		Storage storage = OAuthUtils.loadGCS();
		com.google.api.services.storage.Storage.Objects.List list = storage.objects().list(bucket);
		if (StringUtils.isNotBlank(prefix)) { list = list.setPrefix(prefix); }
		
		Objects objs = list.execute();
		if (objs == null || objs.getItems() == null || objs.getItems().size() == 0) {
			LOG.warning("File or folder not founded.");
			return;
		}
		ListIterator<StorageObject> li = objs.getItems().listIterator(objs.getItems().size());
		while (li.hasPrevious()) {
			String name = li.previous().getName();
			storage.objects().delete(bucket, name).execute();
			LOG.warning("Deleted object : " + name);
		}
	}
}
