package net.forecs.coconut.endpoint.admin;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.billing.IamportBill;
import net.forecs.coconut.common.code.billing.PaidStatus;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.billing.IBillingService;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.entity.billing.ServiceGrades;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class BillingAdminServiceAPI {
	private final IBillingService billingService;
	
	@Inject
	public BillingAdminServiceAPI(IBillingService billingService) {
		this.billingService = billingService;
	}
	
	@ApiMethod(name = "getIamportBill", path = "admin/billing/iamport/{merchant_uid}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public IamportBill getIamportBill(
			@Nullable @Named(FLD.domainName) String domainName,
			@Named(FLD.merchant_uid) String merchant_uid,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return billingService.getIamportBill(merchant_uid);
	}
	
	@ApiMethod(name = "getBills", path = "admin/billing/bills/{billId}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Bills getBills(@Named(FLD.billId) String billId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return billingService.getBills(billId);
	}
	
	@ApiMethod(name = "getBillsDetail", path = "admin/billing/bills/detail/{billId}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Bills getBillsDetail(@Named(FLD.billId) String billId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return billingService.getBillsDetail(billId);
	}
	
	@ApiMethod(name = "listBills", path = "admin/billing/bills", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Bills> listBills(
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.paidStatus) PaidStatus paidStatus,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Bills> queryResult = billingService.listBills(domainName, paidStatus, cursorString, limit);
		List<Bills> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Bills>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "listIamportBills", path = "admin/billing/iamport", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<IamportBill> listIamportBills(
			@Nullable @Named(FLD.status) PaidStatus paidStatus,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<IamportBill> queryResult = billingService.listIamportBills(paidStatus, cursorString);
		List<IamportBill> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<IamportBill>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "removeBills", path = "admin/billing/iamport/{billId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeBills(@Named(FLD.billId) String billId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		billingService.removeBills(billId);
	}

	@ApiMethod(name = "getCustomer", path = "admin/billing/customers/{domainName}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Customers getCustomer(@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return billingService.getCustomer(domainName);
	}
	
	@ApiMethod(name = "changeService", path = "admin/billing/service", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains changeService(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.serviceGrade) String serviceGrade) throws Exception {
		return billingService.changeService(domainName, serviceGrade);
	}

	@ApiMethod(name = "cancelService", path = "admin/billing/service", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains cancelService(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.reason) String reason) throws Exception {
		return billingService.cancelService(domainName, reason);
	}
	
	@ApiMethod(name = "changeCustomerContactInfo", path = "admin/billing/customer/contact", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Customers changeCustomerContactInfo(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.domainName) String domainName,
			Customers customer) throws Exception {
		return billingService.changeCustomerContactInfo(domainName, customer);
	}
	
	@ApiMethod(name = "changeCustomer", path = "billing/customer", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Customers changeCustomer(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.domainName) String domainName,
			Customers customer) throws Exception {
		return billingService.changeCustomer(domainName, customer);
	}
	
//	@ApiMethod(name = "deleteCustomer", path = "billing/iamport/customers/{customer_uid}", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Customers deleteCustomer(@Named(FLD.customer_uid) String customer_uid,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return billingService.deleteCustomer(customer_uid);
//	}
	
	@ApiMethod(name = "paymentAllDomains", path = "admin/billing/paymentAll", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void paymentAll(@Named(FLD.accessToken) String accessToken) throws Exception {
		billingService.scheduledPayments();
	}
	
	@ApiMethod(name = "paymentDomain", path = "admin/billing/payment", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void paymentDomain(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.domainName) String domainName) throws Exception {
		billingService.paymentDomain(domainName, false);
	}
	
	@ApiMethod(name = "cancelPayment", path = "admin/billing/cancel/{billId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Bills cancelPayment(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.billId) String billId,
			@Named(FLD.reason) String reason) throws Exception {
		return billingService.cancelPayment(billId, reason);
	}
	
	@ApiMethod(name = "summarizeBillsAll", path = "admin/billing/summarize/all", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void summarizeBillsAll(
			@Named(FLD.accessToken) String accessToken) {
		billingService.summarizeBills();
	}
	
	@ApiMethod(name = "summarizeBillsDomain", path = "admin/billing/summarize/domain", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void summarizeUsageForBills(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.domainName) String domainName) {
		billingService.summarizeUsageForBills(domainName, null);
	}
	
	@ApiMethod(name = "getServiceGrade", path = "admin/billing/serviceGrades/{serviceGradeId}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public ServiceGrades getServiceGrade(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.serviceGradeId) String serviceGradeId) {
		return billingService.getServiceGrade(serviceGradeId);
	}
	
	@ApiMethod(name = "getServiceGradeByCode", path = "admin/billing/serviceGradesByCode/{serviceGrade}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public ServiceGrades getServiceGradeByCode(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.serviceGrade) String serviceGrade) {
		return billingService.getServiceGradeByCode(serviceGrade);
	}
	
	@ApiMethod(name = "insertOrUpdateServiceGrades", path = "admin/billing/serviceGrades", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public ServiceGrades insertOrUpdateServiceGrades(
			@Named(FLD.accessToken) String accessToken,
			ServiceGrades serviceGrade) throws Exception {
		return billingService.insertOrUpdateServiceGrades(serviceGrade);
	}
	
	@ApiMethod(name = "removeServiceGrade", path = "admin/billing/serviceGrades/{serviceGradeId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeServiceGrade(
			@Named(FLD.accessToken) String accessToken,
			@Named(FLD.serviceGradeId) String serviceGradeId) throws Exception {
		billingService.removeServiceGrade(serviceGradeId);
	}
	
	@ApiMethod(name = "listServiceGrades", path = "admin/billing/serviceGrades", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<ServiceGrades> listServiceGrades(@Named(FLD.accessToken) String accessToken) throws Exception {
		return billingService.listServiceGrades();
	}
}
