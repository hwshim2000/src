package net.forecs.coconut.endpoint.admin;

import java.util.Date;

import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.entity.backup.Backups;

public interface IBackupService extends IAdminCommonService {
	public abstract void dataBackupToGCS(String domainName);
	public abstract void dataBackupToGCS(String domainName, Long backupTimeMillis);
	
	public abstract QueryResult<Backups> listBackups(
			String cursorString,
			Integer limit,
			String domainName,
			Date startDate,
			Date endDate) throws Exception;
	public abstract Backups getBackups(String backupId);
	public abstract Backups insertBackups(Backups backup) throws Exception;
	public abstract Backups updateBackups(Backups backup) throws Exception;
	public abstract void removeBackups(String backupId) throws Exception;
}
