package net.forecs.coconut.endpoint.admin;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.IndexKind;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.appengine.api.datastore.Entity;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class DataServiceAPI {
	private final IDataService dataService;
	
	@Inject
	public DataServiceAPI(IDataService dataService) {
		this.dataService = dataService;
	}
	
	@ApiMethod(name = "removeKindData", path = "datastore/kinds/{kind}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeKindData(
			@Nullable @Named(FLD.namespace) String namespace,
			@Named(FLD.kind) String kind,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.removeKindData(namespace, kind);
	}
	
	@ApiMethod(name = "removeNamespace", path = "datastore", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeNamespace(
			@Nullable @Named(FLD.namespace) String namespace,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.removeNamespace(namespace);
	}
	
	@ApiMethod(name = "removeAllNamespace", path = "datastore/all", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeAllNamespace(
			@Nullable @Named(FLD.includeDefault) Boolean includeDefault,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		if (includeDefault == null) includeDefault = false;
		dataService.removeAllNamespace(includeDefault);
	}
	
	@ApiMethod(name = "removeIndex", path = "index/{indexKind}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeIndex(
			@Nullable @Named(FLD.namespace) String namespace,
			@Named(FLD.indexKind) IndexKind indexKind,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.removeIndex(namespace, indexKind.toString());
	}
	
	@ApiMethod(name = "removeNamespaceIndex", path = "index", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeNamespaceIndex(
			@Nullable @Named(FLD.namespace) String namespace,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.removeNamespaceIndex(namespace);
	}
	
	@ApiMethod(name = "removeAllIndex", path = "index/all", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeAllIndex(
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.removeAllIndex();
	}
	
	@ApiMethod(name = "recreateAllIndex", path = "index/reindex/all", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void recreateAllIndex(
			@Nullable @Named(FLD.indexKind) IndexKind indexKind,
			@Named(FLD.accessToken) String accessToken) throws Exception {
//		dataService.recreateAllIndex();
		dataService.invokeRecreateAllIndex(indexKind);
	}
	
	@ApiMethod(name = "recreateIndexNoTaskQueue", path = "index/noTaskQueue", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void recreateIndexNoTaskQueue(
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.indexKind) IndexKind indexKind,
			@Named(FLD.accessToken) String accessToken) throws Exception {

		if (StringUtils.isBlank(domainName) && indexKind == null) {
			dataService.recreateAllIndex();
		} else if (StringUtils.isNotBlank(domainName) && indexKind == null) {
			dataService.recreateNamespaceIndex(domainName);
		} else if (StringUtils.isNotBlank(domainName) && indexKind != null) {
			switch (indexKind) {
				//case UserIndex : recreateUserIndex(namespace); break;
				case TaskIndex : dataService.recreateTaskIndex(domainName); break;
				case EventIndex : dataService.recreateEventIndex(domainName); break;
				case NoticeIndex : dataService.recreateNoticeIndex(domainName); break;
				case TimelineIndex : dataService.recreateTimelineIndex(domainName); break;
				case CommentIndex : dataService.recreateCommentIndex(domainName); break;
				//case ChecklistHistoryIndex : recreateChecklistHistoryIndex(namespace); break;
				//case ChecklistIndex : recreateChecklistIndex(namespace); break;
				case AttachmentIndex : dataService.recreateAttachmentIndex(domainName); break;
				default : break;
			}
		}
	}
	
	@ApiMethod(name = "removeIndexSchema", path = "index/schema/{indexKind}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeIndexSchema(
			@Named(FLD.namespace) String namespace,
			@Named(FLD.indexKind) IndexKind indexKind,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.removeIndexSchema(namespace, indexKind.toString());
	}
	
	@ApiMethod(name = "removeNamespaceIndexSchema", path = "index/schema", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeNamespaceIndexSchema(
			@Named(FLD.namespace) String namespace,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.removeNamespaceIndexSchema(namespace);
	}
	
	@ApiMethod(name = "recreateNamespaceIndex", path = "index/reindex", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void recreateNamespaceIndex(
			@Named(FLD.namespace) String namespace,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		//dataService.recreateNamespaceIndex(namespace);
		dataService.invokeRecreateNamespaceIndex(namespace);
	}
	
	@ApiMethod(name = "recreateIndex", path = "index/reindex/{indexKind}", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void recreateIndex(
			@Named(FLD.namespace) String namespace,
			@Named(FLD.indexKind) IndexKind indexKind,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		dataService.invokeRecreateIndex(namespace, indexKind);
		
//		switch (indexKind) {
//			//case UserIndex : dataService.recreateUserIndex(namespace); break;
//			case TaskIndex : dataService.recreateTaskIndex(namespace); break;
//			case EventIndex : dataService.recreateEventIndex(namespace); break;
//			case NoticeIndex : dataService.recreateNoticeIndex(namespace); break;
//			case TimelineIndex : dataService.recreateTimelineIndex(namespace); break;
//			case CommentIndex : dataService.recreateCommentIndex(namespace); break;
//			//case ChecklistHistoryIndex : dataService.recreateChecklistHistoryIndex(namespace); break;
//			//case ChecklistIndex : dataService.recreateChecklistIndex(namespace); break;
//			case AttachmentIndex : dataService.recreateAttachmentIndex(namespace); break;
//			default : break;
//		}
	}
	
	@ApiMethod(name = "clearAllMemcache", path = "memcache/clear", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void clearAllMemcache(
			@Named(FLD.accessToken) String accessToken) throws Exception {
		AdminCommonService.clearAllMemcache();
	}
	
//	@Deprecated
//	@ApiMethod(name = "findUnavailableAllNamspaceData", path = "namespaces/{namespace}/unavailable/kinds", httpMethod = HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, List<String>> findUnavailableAllNamspaceData(
//			@Named(FLD.namespace) String namespace,
//			@Nullable @Named(FLD.deleteYN) String deleteYN,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		boolean remove = false;
//		if ("Y".equals(deleteYN)) { remove = true; }
//		return dataService.findUnavailableAllNamespaceData(namespace, remove);
//	}
//	@Deprecated
//	@ApiMethod(name = "findUnavailableNamspaceData", path = "namespaces/{namespace}/unavailable/kinds/{kind}", httpMethod = HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public List<String> findUnavailableNamspace(
//			@Named(FLD.namespace) String namespace,
//			@Named(FLD.kind) Kind kind,
//			@Nullable @Named(FLD.deleteYN) String deleteYN,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		boolean remove = false;
//		if ("Y".equals(deleteYN)) { remove = true; }
//		return dataService.findUnavailableNamspaceData(namespace, kind, remove);
//	}
//	@Deprecated
//	@ApiMethod(name = "removeUnavailableNamspaceData", path = "namespaces/{namespace}/unavailable", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, String> removeUnavailableNamspaceData(
//			@Named(FLD.namespace) String namespace,
//			@Named(FLD.keys) List<String> keys,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return dataService.removeUnavailableNamspaceData(namespace, keys);
//	}
	
	@ApiMethod(name = "getEntity", path = "namespaces/{namespace}/entities", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<Entity> getEntity(@Named(FLD.namespace) String namespace,
			@Named(FLD.keys) List<String> keys,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return dataService.getEntity(namespace, keys);
	}
}
