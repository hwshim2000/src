package net.forecs.coconut.endpoint.admin;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.email.AdminEMailNotice;
import net.forecs.coconut.entity.user.Users;

import com.google.appengine.api.datastore.Text;			// for mail description data


public interface IAdminService extends ICommonService {
	public abstract Map<String, Object> getDomainInfo(String domainName) throws Exception;
	public abstract QueryResult<Domains> listDomains(String cursorString, Integer limit, boolean isDefault) throws Exception;

	public abstract Domains updateDomainLabel(String domainName, String label, boolean isDefault, boolean isOverwrite) throws Exception;
	public abstract Domains updateDomainNote(String domainName, String note, boolean isDefault, boolean isOverwrite) throws Exception;
	
	public abstract Domains changeDomainBlockType(String domainName, BlockType blockType, boolean isDefault, boolean isOverwrite) throws Exception;
	public abstract Domains changeDomainServiceType(String domainName, ServiceType serviceType, String serviceGrade, boolean isDefault, boolean isOverwrite) throws Exception;
	public abstract Domains resetDomainExpirationDate(String domainName, Date expirationDate, boolean isDefault, boolean isOverwrite) throws Exception;
	public abstract Domains changeCreateBoardAuth(String domainName, Auth createBoardAuth, boolean isDefault, boolean isOverwrite) throws Exception;
	
	public abstract Domains resetDomainUsageQuota(String domainName,
			Long userQuota,
			Long storageQuota,
			Long boardQuota
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			, Long groupQuota,
			Long taskQuota
			*/
			//<-- ===== DOMAIN STATISTICS =====
			, boolean isDefault, boolean isOverwrite
			) throws Exception;
	
	public abstract QueryResult<Users> listDomainUsers(String domainName, String cursorString, Integer limit, Boolean active, boolean includeProfile, String deleteYN) throws Exception;
	@Deprecated
	public abstract List<Users> updateAllDomainUserLowerId() throws Exception;
	@Deprecated
	public abstract List<Users> updateDomainUserLowerId(String domainName) throws Exception;
	@Deprecated
	public abstract Domains updateDomainCaseInsensitive(String domainName, boolean caseInsensitive, boolean isDefault, boolean isOverwrite) throws Exception;
	@Deprecated
	public abstract List<Domains> updateAllDomainCaseInsensitive(boolean caseInsensitive, boolean isDefault, boolean isOverwrite) throws Exception;
	@Deprecated
	public abstract void permanentRemoveDomainUsers(String domainName, String userId) throws Exception;
	public abstract void permanentRemoveDefaultDomainUsers(String id) throws Exception;
	
	public abstract QueryResult<Activities> listActivities(
			String domainName,
			String cursorString,
			Integer limit) throws Exception;
	public abstract void bulkRemoveDomainActivities(String domainName, String boardId, String kindId, ActivityKind activityKind, ActivityType activityType, String userId) throws Exception;
	
	@Deprecated
	public abstract int bulkUpdateTaskTimelinesForModified(String domainName) throws Exception;
	public abstract void sendRandomPassword(String domainName, String id, String email, String password) throws Exception;
	@Deprecated
	public abstract Map<String, Integer> updateAllActivitiesShow(Integer limit) throws Exception;
	@Deprecated
	public abstract int updateActivitiesShow(String domainName, Integer limit) throws Exception;
	@Deprecated
	public abstract int bulkUpdateTasksForPublic(String domainName) throws Exception;
	public abstract Users assignUserAuth(String domainName, String userId, Auth auth) throws Exception;
	@Deprecated
	public abstract void createAndRevokeAdminAll() throws Exception;
	@Deprecated
	public abstract void createAndRevokeAdmin(String domainName) throws Exception;
	
	public abstract Map<String, Map<String, String>> getAllUserEmailInfo() throws Exception;
	public abstract Map<String, String> getDomainUserEmailInfo(String domainName) throws Exception;
	public abstract void sendAllNoticeEmail(List<String> domainNames, String subject, Text message) throws Exception;
	public abstract void sendAllNoticeEmailtoAdmin(List<String> domainNames, String subject, Text message) throws Exception;
	public abstract void sendDomainNoticeEmail(String domainName, String subject, Text message, List<String> emailList) throws Exception;
	public abstract void sendDomainNoticeEmailtoAdmin(String domainName, String subject, Text message, List<String> emailList) throws Exception;
	public abstract Domains changeDomainUseStorage(String domainName, boolean useStorage, boolean isDefault, boolean isOverwrite) throws Exception;
	public abstract List<String> getDomainUserEmails(String domainName) throws Exception;
	public abstract List<String> getDomainUserEmailsbyAdmin(String domainName) throws Exception;
	public abstract AdminEMailNotice insertAdminEMailNotice(AdminEMailNotice adminEMailNotice) throws Exception;
	public abstract void permanentRemoveAdminEMailNotice(String adminEMailNoticeId) throws Exception;
	public abstract QueryResult<AdminEMailNotice> getAdminEMailNoticeList(String cursorString, Integer limit, boolean isDefault) throws Exception;
	
	@Deprecated
	public abstract void overwriteToAllUserDomain() throws Exception;
	@Deprecated
	public abstract void overwriteToUserDomain(String domainName) throws Exception;
	@Deprecated
	public abstract void overwriteToAllDefaultDomain() throws Exception;
	@Deprecated
	public abstract void overwriteToDefaultDomain(String domainName) throws Exception;
	@Deprecated
	public abstract void overwriteToDefaultDomain(EntityManager mgr, Domains domain) throws Exception;
	
	@Deprecated
	public abstract void initializeTaskImportance() throws Exception;
	@Deprecated
	public abstract void initializeTaskImportance(String domainName) throws Exception;
	public abstract <T extends Base> void initializeEntity(String domainName, String kind, HashMap<String, Object> initMap) throws Exception;
	
//	@Deprecated
//	public abstract Domains resetDomainUsageForBills(Domains domain, DomainsLogType domainsLogType, boolean isDefault, boolean isOverwrite) throws Exception;
	public abstract Map<String, Object> listLastDomainAccess(Date accessDate) throws Exception;
	
	public abstract Domains enableDomainService(String domainName, Date paymentEnd, String reason) throws Exception;
	public abstract Domains disableDomainService(String domainName, Date expirationDate, String reason) throws Exception;
}
