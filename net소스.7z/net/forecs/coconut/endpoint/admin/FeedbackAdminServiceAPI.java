package net.forecs.coconut.endpoint.admin;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.manage.IFeedbackService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.manage.Feedbacks;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.appengine.api.datastore.Text;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class FeedbackAdminServiceAPI {
	private final IFeedbackService feedbackService;
	
	@Inject
	public FeedbackAdminServiceAPI(IFeedbackService feedbackService) {
		this.feedbackService = feedbackService;
	}
	
	@ApiMethod(name = "queryFeedbacks", path = "manage/feedbacks", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Feedbacks> queryFeedbacks(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.id) String id,
			@Nullable @Named(FLD.email) String email,
			@Nullable @Named(FLD.category) List<String> categories,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Feedbacks> queryResult = feedbackService.queryFeedbacks(cursorString, limit, domainName, id, email, categories);
		
		List<Feedbacks> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Feedbacks>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "getFeedback", path = "manage/feedbacks/{feedbackId}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Feedbacks getFeedback(@Named(FLD.feedbackId) String feedbackId, @Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.getFeedback(feedbackId);
	}
	
	@ApiMethod(name = "insertFeedback", path = "manage/feedbacks", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Feedbacks insertFeedback(Feedbacks feedback, @Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.insertFeedback(feedback);
	}
	
	@ApiMethod(name = "updateFeedback", path = "manage/feedbacks", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Feedbacks updateFeedback(Feedbacks feedback, @Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.updateFeedback(feedback);
	}
	
	@ApiMethod(name = "answerFeedback", path = "manage/feedbacks/answer", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Feedbacks answerFeedback(@Named(FLD.feedbackId) String feedbackId,
			@Named(FLD.answerer) String answerer,
			Text answer,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.answerFeedback(feedbackId, answerer, answer);
	}
	
	@ApiMethod(name = "evaluateSatisfaction", path = "manage/feedbacks/satisfaction", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Feedbacks evaluateSatisfaction(@Named(FLD.feedbackId) String feedbackId,
			@Named(FLD.satisfaction) int satisfaction,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.evaluateSatisfaction(feedbackId, satisfaction);
	}
	
	@ApiMethod(name = "removeFeedback", path = "manage/feedbacks/{feedbackId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeFeedback(@Named(FLD.feedbackId) String feedbackId, @Named(FLD.accessToken) String accessToken) throws Exception {
		feedbackService.removeFeedback(feedbackId);
	}
	
	@ApiMethod(name = "permanentRemoveFeedback", path = "manage/feedbacks/permanent", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void permanentRemoveFeedback(@Named(FLD.feedbackId) String feedbackId, @Named(FLD.accessToken) String accessToken) throws Exception {
		feedbackService.permanentRemoveFeedback(feedbackId);
	}
	
	@ApiMethod(name = "addFeedbackAttachment", path = "manage/feedbacks/{feedbackId}/attachments", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Attachments addFeedbackAttachment(@Named(FLD.feedbackId) String feedbackId,
			Attachments attachment,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.addFeedbackAttachment(feedbackId, attachment);
	}

	@ApiMethod(name="removeFeedbackAttachment", path = "manage/feedbacks/{taskTimelineId}/attachments/{attachmentId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Attachments removeFeedbackAttachment(@Named(FLD.feedbackId) String feedbackId,
			@Named(FLD.attachmentId) String attachmentId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.removeFeedbackAttachment(feedbackId, attachmentId);
	}
	
	@ApiMethod(name="addFeedbackImage", path = "manage/feedbacks/{feedbackId}/images", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Images addFeedbackImage(@Named(FLD.feedbackId) String feedbackId, Images image, @Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.addFeedbackImage(feedbackId, image);
	}
	
	@ApiMethod(name="removeFeedbackImage", path = "manage/feedbacks/{feedbackId}/images/{imageId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Images removeFeedbackImage(@Named(FLD.imageId) String imageId, @Named(FLD.accessToken) String accessToken) throws Exception {
		return feedbackService.removeFeedbackImage(imageId);
	}
}
