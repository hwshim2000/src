package net.forecs.coconut.endpoint.admin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryMode;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.query.SimpleQuery;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;

/**
 * @Project    : coconut
 * @FileName   : UsageService.java
 * @Date       : 2015. 3. 27.
 * @Author     : hyeunwoo.shim@forecs.net
 * @Version    :
 * @Histories  :
 * @Description: 용량 체크 및 서비스 차단 관련 서비스
 */
public class UsageService extends AdminCommonService implements IUsageService {
	private static final Logger LOG = Logger.getLogger(UsageService.class.getName());
	
	public final static String __STAT_NAMESPACE__ = "__Stat_Namespace__";
	public final static String __STAT_NS_TOTAL__ = "__Stat_Ns_Total__";
	public final static String SUBJECT_NAMESPACE = "subject_namespace";
	
	public final static boolean STORAGE_USAGE_CHECK = false;
	public final static boolean EXPIRATION_CHECK = true;
	public final static boolean USER_USAGE_CHECK = true;
	public final static boolean GROUP_USAGE_CHECK = false;
	public final static boolean BOARD_USAGE_CHECK = true;
	public final static boolean TASK_USAGE_CHECK = false;

	/**
	 * @Description : usage check & notification points
	 *              : 사용량(백분율) 체크 목록 및 Noti를 알리는 시점들.(예, 80, 85 이면 80%, 85% 를 초과하는 시점에 Notification 메시지를 보낸다.)
	 * @Author      : hyeunwoo.shim@forecs.net 2015. 3. 26.
	 */
	//public final static List<Integer> USAGE_CHECK_POINTS;// = {80,85,90,95,100,1,2,3,4,5}; // 1,2,3,4,5는 사용량 체크를 제대로 하는지 테스트하기 위해 넣은값.(테스트용임)
	public final static List<Integer> USAGE_CHECK_POINTS;// = {80,85,90,95,100};
	/**
	 * @Description : expiration check & notification points
	 *              : 서비스 만료일 체크일 목록. (예, -28, -21 이면, 만료일 28일전 21일전에 만료일 관련  Notification 메시지를 보낸다)
	 *              : Notification 메일은 해당 도메인을 생성한 사용자(또는 Owner)
	 * @Author      : hyeunwoo.shim@forecs.net 2015. 3. 26.
	 * @History		: 2015. 04. 27. type changed.(Array -> List) : this field is mutable array. 
	 */
	public final static List<Integer> EXPIRATION_CHECK_POINTS;// = {-28,-21,-14,-7,-3,-1};
	/**
	 * @Description : default expiration days = 90 days(3 months)
	 *              : 해당 도메인에 지정된 서비스 만료일이 없을 경우, 기본적으로 제공되는 서비스 기간
	 *              : 기간 계산은 도메인이 생성된 시점으로부터의 값이다.
	 *              : (ex, 도메인 생성 3월 1일 이면 기본적으로 90일을 더한 대략 5월 30일전후가 서비스 만료일이 된다.)
	 * @Author      : hyeunwoo.shim@forecs.net 2015. 3. 26.
	 * @History		: 2015. 04. 27. type changed.(Array -> List) : this field is mutable array.
	 */
	
	static {
		Integer[] usageCheckPoints = {50,70,80,90,95,100};
		Integer[] expirationCheckPoints = {-28,-21,-14,-7,-3,-1};
		
		Arrays.sort(usageCheckPoints, new IntegerComparator());
		Arrays.sort(expirationCheckPoints, new IntegerComparator());
		
		USAGE_CHECK_POINTS = Collections.unmodifiableList(Arrays.asList(usageCheckPoints));
		EXPIRATION_CHECK_POINTS = Collections.unmodifiableList(Arrays.asList(expirationCheckPoints));
	}
	
	private final IActivityService activityService;
	
	@Inject
	public UsageService(IActivityService activityService) {
		this.activityService = activityService;
	}

	@Override
	public void surveyUsage() {
		try {
			Queue queue = QueueFactory.getQueue(CommonProperty.SURVEY_DOMAIN_USAGE_QUEUE_NAME);
			List<String> domainNames = listNamespaces();
			
			long surveyTime = new Date().getTime();
			
			if (MainModule.serviceMode) {
				for (String domainName : domainNames) {
					TaskOptions taskOption = TaskOptions.Builder
				            .withUrl(CommonProperty.SURVEY_DOMAIN_USAGE_URL)
				            .param(PARAM.DOMAINNAME, domainName)
				            .etaMillis(surveyTime)
				            .method(Method.POST);
				    
					surveyTime += 10;
					
					try {
						queue.add(taskOption);
					} catch (Exception ex) {
						LOG.warning(String.format("[surveyUsage-%s] %s ", domainName, ex.getMessage()));
					}
				}
			} else {
				for (String domainName : domainNames) {
					surveyUsage(domainName);
				}
			}
		} catch (Exception ex) {
			LOG.severe("[surveyUsage] " + ex.getMessage());
			//ex.printStackTrace();
		}
	}
//	@Override
//	public void surveyUsage() {
//		String prevNamespace = NamespaceManager.get();
//		EntityManager mgr = getEntityManager();
//		try {
//			List<String> domainNames = listNamespaces();
//			
//			for (String domainName : domainNames) {
//				NamespaceManager.set(domainName);
//				surveyUsage(mgr, domainName);
//			}
//		} catch (Exception ex) {
//			LOG.severe(ex.getMessage());
//			//ex.printStackTrace();
//		} finally {
//			finalizeTransaction(mgr, prevNamespace);
//		}
//	}
//	@Override
//	public void surveyUsage(String domainName) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(domainName);
//		
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			surveyUsage(mgr, domainName);
//		} catch (Exception ex) {
//			LOG.severe(ex.getMessage());
//			//ex.printStackTrace();
//		} finally {
//			finalizeTransaction(mgr, prevNamespace);
//		}
//	}
	public static boolean isChargeable(Domains domain) {
		if (!ServiceType.DEFERRED.equals(domain.getServiceType())) { return false; }
		if (!BlockType.AUTO.equals(domain.getBlockType())) { return false; }
		
		return true;
	}
	public void surveyUsage(String domainName) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFindNoCache(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			if (domain == null) { return; }
			
			// 현재 사용량 정보를 가져온다.
			Usage currentUsage = summarizeUsageInfo(mgr, domainName);
			// 이전 사용량 정보를 가져온다.
			Usage prevUsage = doFind(mgr, Usage.class, KeyUtil.createUsageKey(domainName));
			
			// 사용량 체크 도중에 Activity와 Notification을 처리하기위한 ActivityType을 담을 객체
			List<ActivityType> activityTypeList = new ArrayList<ActivityType>();
			
			/** -------------------------------------------------------- */
			if (EXPIRATION_CHECK) { checkExpiration(domain, prevUsage, currentUsage, activityTypeList); }
			
			// 후불제인 경우에는 사용량 체크를 하지 않는다.
			if (ServiceType.DEFERRED.equals(domain.getServiceType())) {
				// 사용량(로그 포함)을 기록할때 charging 대상인지 여부를 판별한다.)
				currentUsage.setChargeable(isChargeable(domain));
			} else {
				if (USER_USAGE_CHECK) { checkUserUsage(domain, prevUsage, currentUsage, activityTypeList); }
				if (STORAGE_USAGE_CHECK) { checkStorageUsage(domain, prevUsage, currentUsage, activityTypeList); }
				if (BOARD_USAGE_CHECK) { checkBoardUsage(domain, prevUsage, currentUsage, activityTypeList); }
			}
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			if (CommonProperty.GROUP_USAGE_CHECK) { checkGroupUsage(domain, prevUsage, currentUsage, activityTypeList); }
			if (CommonProperty.TASK_USAGE_CHECK) { checkTaskUsage(domain, prevUsage, currentUsage, activityTypeList); }
			*/
			//<-- ===== DOMAIN STATISTICS =====

			/** -------------------------------------------------------- */
			
			// 현재 Usage 및 Noti 상태 정보를 입력하거나 수정한다.
			insertOrUpdateUsage(mgr, currentUsage);
			//--> hyeunwoo.shim 2015-10-20 : moved setDomainUsage
//				try { insertUsageLog(currentUsage); } catch (Exception ex) {}
			//<--
			/** Activity를 발생시킬 목록에서 해당 Activity를 기록하고 Noti를 발생시킨다.(사용자 NotificationSetting정보와 무관하게 발생시켜야한다) */
			try {
				List<Activities> activityList = new ArrayList<Activities>();
				ObjectMapper om = new ObjectMapper();
				ObjectWriter prettyPrinter = om.writerWithDefaultPrettyPrinter();
				
				for (ActivityType activityType : activityTypeList) {
					//**********************************************************************************
					//--> hyeunwoo.shim 2016-01-19 : 보드 사용량 초과는 activity 및 Notification을 하지 않는다.
					if (ActivityType.WARNING_OF_BOARDS_USAGE.equals(activityType)) { continue; }
					//<--
					//**********************************************************************************
					
					Activities activity = activityService.createUsageActivity(currentUsage, domain, activityType);
					activityList.add(activity);
					LOG.warning(String.format("[USAGE EXCESS INFO] DOMAIN(%s) TYPE(%s)", domain.getDomainName(), activityType));
					LOG.warning(prettyPrinter.writeValueAsString(currentUsage));
				}
				activityService.insertActivities(activityList);
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
		} catch (Exception ex) {
			LOG.severe(ex.getMessage());
			//ex.printStackTrace();
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private void checkExpiration(Domains domain, Usage prevUsage, Usage currentUsage, List<ActivityType> activityTypeList) {
		if (domain.getExpirationDate() == null) { return; }	// Do not check if value is null.
		
		/** !!! (주)-------------------------------------------------------- */
		/** 요금제 사용 종료일 안내(EXPIRATION_CHECK_POINTS 참조. 기획문서에는 1주일만 되어있으나, 15~1일전내에서 여러번 알려주어야 하지 않을까?) */
		List<Integer> expirationCheckDays = null;
		Date expirationDate = domain.getExpirationDate();
		Date currentDate = new Date();
		// 도메인의 서비스 만료일이 없으면 DEFAULT_EXPIRATION_MONTH에 해당하는 일자를 도메인 생성일에 더하여 서비스 만료일을 정한다.
		if (expirationDate == null) {
			expirationDate = CalendarUtil.addMonth(domain.getCreated(), CommonProperty.DEFAULT_EXPIRATION_MONTH);
		}
		
		// 중복으로 메시지를 알리는것을 방지하기 위해, 이전 사용량 정보에서 ExpirationChekDay 정보를 가져온다. 
		if (prevUsage != null && prevUsage.getExpirationCheckDays() != null) {
			expirationCheckDays = prevUsage.getExpirationCheckDays();
		} else {
			expirationCheckDays = new ArrayList<Integer>();
		}
		
		// 만료일 체크 리스트
		for (int prevDay : EXPIRATION_CHECK_POINTS) {
			if (CalendarUtil.addDay(expirationDate, prevDay).compareTo(currentDate) < 0) {
				// 만료일 체크 시점에 도달하고 한번도 Noti를 발생시키지 않았다면 Noti를 발생시키고 만료일 체크 목록에 추가한다.
				if (!expirationCheckDays.contains(prevDay)) {
					// 만료일 체크 시점에  포함될 경우, 경고 Activity를 추가한다.
					activityTypeList.add(ActivityType.WARNING_OF_EXPIRATION);
					
					LOG.info(String.format("요금제 사용 %d일전  Noti임:",prevDay));
					expirationCheckDays.add(prevDay);
				}
				break;
			}
		}
		// 현재 사용량 정보에 만료일을 기록한다.
		currentUsage.setExpirationDate(expirationDate);
		// 만료일 체크를 했던 시점 목록을 기록한다.
		currentUsage.setExpirationCheckDays(expirationCheckDays);
	}
	
	private void checkUserUsage(Domains domain, Usage prevUsage, Usage currentUsage, List<ActivityType> activityTypeList) {
		if (domain.getUserQuota() == null) { return; }	// Do not check if value is null.
		
		List<Integer> usageCheckPointsOfUser = null;
		
		// 이전 사용량 체크 시점 정보를 가져온다.
		if (prevUsage != null && prevUsage.getUsageCheckPointsOfUser() != null) {
			usageCheckPointsOfUser = prevUsage.getUsageCheckPointsOfUser();	
		} else {
			usageCheckPointsOfUser = new ArrayList<Integer>();
		}
		
		for (Integer checkPoint : USAGE_CHECK_POINTS) {
			Long userQuota = domain.getUserQuota();
			if (userQuota == null || userQuota == 0) { userQuota = CommonProperty.DEFAULT_USER_QUOTA; }
			// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
			int userUsagePoint = ((int)(100*currentUsage.getUserCount()/userQuota))/checkPoint;
			if (userUsagePoint >= 1) {
				// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
				if (!usageCheckPointsOfUser.contains(checkPoint)) {
					activityTypeList.add(ActivityType.WARNING_OF_USERS_USAGE);
					LOG.info("Noti - users limit:"+checkPoint);
					// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
					usageCheckPointsOfUser.add(checkPoint);
				}
				break;
			}
		}
		currentUsage.setUsageCheckPointsOfUser(usageCheckPointsOfUser);
	}
	
	private void checkStorageUsage(Domains domain, Usage prevUsage, Usage currentUsage, List<ActivityType> activityTypeList) {
		if (domain.getStorageQuota() == null) { return; }	// Do not check if value is null.
		
		List<Integer> usageCheckPointsOfStorage = null;
		
		// 이전 사용량 체크 시점 정보를 가져온다.
		if (prevUsage != null && prevUsage.getUsageCheckPointsOfStorage() != null) {
			usageCheckPointsOfStorage = prevUsage.getUsageCheckPointsOfStorage();	
		} else {
			usageCheckPointsOfStorage = new ArrayList<Integer>();
		}
		
		for (Integer checkPoint : USAGE_CHECK_POINTS) {
			Long storageQuota = domain.getStorageQuota();
			if (storageQuota == null || storageQuota == 0) { storageQuota = CommonProperty.DEFAULT_STORAGE_QUOTA; }
			// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
			int storageUsagePoint = ((int)(100*currentUsage.getTotalBytes()/storageQuota))/checkPoint;
			if (storageUsagePoint>=1) {
				// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
				if (!usageCheckPointsOfStorage.contains(checkPoint)) {
					activityTypeList.add(ActivityType.WARNING_OF_STORAGE_USAGE);
					LOG.info("Noti - storage limit:"+checkPoint);
					// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
					usageCheckPointsOfStorage.add(checkPoint);
				}
				break;
			}
		}
		currentUsage.setUsageCheckPointsOfStorage(usageCheckPointsOfStorage);
	}
	
	private void checkBoardUsage(Domains domain, Usage prevUsage, Usage currentUsage, List<ActivityType> activityTypeList) {
		if (!ServiceType.TRIAL.equals(domain.getServiceType()) && domain.getBoardQuota() == null) { return; }	// Do not check if value is null and service type is not TRIAL.
		
		List<Integer> usageCheckPointsOfBoard = null;
		
		// 이전 사용량 체크 시점 정보를 가져온다.
		if (prevUsage != null && prevUsage.getUsageCheckPointsOfBoard() != null) {
			usageCheckPointsOfBoard = prevUsage.getUsageCheckPointsOfBoard();	
		} else {
			usageCheckPointsOfBoard = new ArrayList<Integer>();
		}
		
		for (Integer checkPoint : USAGE_CHECK_POINTS) {
			// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
			Long boardQuota = domain.getBoardQuota();
			if (boardQuota == null || boardQuota == 0) { boardQuota = CommonProperty.DEFAULT_BOARD_QUOTA; }
			int boardUsagePoint = ((int)(100*currentUsage.getBoardCount()/boardQuota))/checkPoint;
			if (boardUsagePoint>=1) {
				// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
				if (!usageCheckPointsOfBoard.contains(checkPoint)) {
					activityTypeList.add(ActivityType.WARNING_OF_BOARDS_USAGE);
					LOG.info("Noti - boards limit:"+checkPoint);
					// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
					usageCheckPointsOfBoard.add(checkPoint);
				}
				break;
			}
		}
		currentUsage.setUsageCheckPointsOfBoard(usageCheckPointsOfBoard);
	}
	
	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	private void checkGroupUsage(Domains domain, Usage prevUsage, Usage currentUsage, List<ActivityType> activityTypeList) {
		List<Integer> usageCheckPointsOfGroup = null;
		
		// 이전 사용량 체크 시점 정보를 가져온다.
		if (prevUsage != null && prevUsage.getUsageCheckPointsOfGroup() != null) {
			usageCheckPointsOfGroup = prevUsage.getUsageCheckPointsOfGroup();	
		} else {
			usageCheckPointsOfGroup = new ArrayList<Integer>();
		}
		
		for (Integer checkPoint : CommonProperty.USAGE_CHECK_POINTS) {
			// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
			Long groupQuota = domain.getGroupQuota();
			if (groupQuota == null || groupQuota == 0) { groupQuota = CommonProperty.DEFAULT_GROUP_QUOTA; }
			int groupUsagePoint = ((int)(100*currentUsage.getGroupCount()/groupQuota))/checkPoint;
			if (groupUsagePoint>=1) {
				// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
				if (!usageCheckPointsOfGroup.contains(checkPoint)) {
					activityTypeList.add(ActivityType.WARNING_OF_GROUPS_USAGE);
					LOG.info("Noti - groups limit:"+checkPoint);
					// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
					usageCheckPointsOfGroup.add(checkPoint);
				}
				break;
			}
		}
		currentUsage.setUsageCheckPointsOfGroup(usageCheckPointsOfGroup);
	}
	
	private void checkTaskUsage(Domains domain, Usage prevUsage, Usage currentUsage, List<ActivityType> activityTypeList) {
		List<Integer> usageCheckPointsOfTask = null;
		
		// 이전 사용량 체크 시점 정보를 가져온다.
		if (prevUsage != null && prevUsage.getUsageCheckPointsOfTask() != null) {
			usageCheckPointsOfTask = prevUsage.getUsageCheckPointsOfTask();	
		} else {
			usageCheckPointsOfTask = new ArrayList<Integer>();
		}
		
		for (Integer checkPoint : CommonProperty.USAGE_CHECK_POINTS) {
			// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
			Long taskQuota = domain.getTaskQuota();
			if (taskQuota == null || taskQuota == 0) { taskQuota = CommonProperty.DEFAULT_TASK_QUOTA; }
			int taskUsagePoint = ((int)(100*currentUsage.getTaskCount()/taskQuota))/checkPoint;
			if (taskUsagePoint>=1) {
				// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
				if (!usageCheckPointsOfTask.contains(checkPoint)) {
					activityTypeList.add(ActivityType.WARNING_OF_TASKS_USAGE);
					LOG.info("Noti - tasks limit:"+checkPoint);
					// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
					usageCheckPointsOfTask.add(checkPoint);
				}
				break;
			}
		}
		currentUsage.setUsageCheckPointsOfTask(usageCheckPointsOfTask);
	}
	*/
	//<-- ===== DOMAIN STATISTICS =====
	public static void validUsage() throws Exception {
		validUsage(NamespaceManager.get(), null);
	}
	public static void validUsage(String domainName) throws Exception {
		validUsage(domainName, null);
	}
	public static <T extends Base> void validUsage(T object) throws Exception {
		validUsage(NamespaceManager.get(), object);
	}
	public static <T extends Base> void validUsage(String domainName, T object) throws Exception {
		//String namespace = NamespaceManager.get();
		if (StringUtils.isBlank(domainName)) { return; }
		
		BlockType blockType = CommonProperty.DEFAULT_BLOCK_TYPE;
		Domains domain = getDomainFromDefaultNamespace(domainName);
		
		if (domain == null) {
			throw new UnavailableException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Domain info not found."));
		}
		// 도메인에 설정된 blockType 적용
		if (domain.getBlockType() != null) { blockType = domain.getBlockType(); }
		
		if (BlockType.PASS.equals(blockType)) {
			//========= blockType이 Pass(사용량 초과여부에 상관없이 서비스 제공) =========
			return; 
		} else if (BlockType.BLOCK.equals(blockType)) {
			//========= 서비스 사용량 초과여부에 상관없이 무조건 서비스 차단. =========
			throw new UnavailableException(ErrorCode.UNAVAILABLE.getMessage("This domain was blocked."));
		} else {
			//========= 서비스 사용량을 체크하여 초과 항목에 대해 서비스 차단 =========
			Usage usage = getDomainUsage(domainName);
			
			if (EXPIRATION_CHECK) { validExpiration(usage, domain); }
			if (ServiceType.DEFERRED.equals(domain.getServiceType())) { return; }
			
			if (object == null) {
				if (USER_USAGE_CHECK) { validUserQuota(usage, domain); }
				if (STORAGE_USAGE_CHECK) { validStorageQuota(usage, null, domain); }
				if (BOARD_USAGE_CHECK) { validBoardQuota(usage, domain); }
				
				//--> ===== DOMAIN STATISTICS =====
				/* Later, I may use this code.
				if (CommonProperty.GROUP_USAGE_CHECK) { validGroupQuota(usage, domain); }
				if (CommonProperty.TASK_USAGE_CHECK) { validTaskQuota(usage, domain); }
				*/
				//<-- ===== DOMAIN STATISTICS =====
			} else if (object.getClass().equals(Users.class)) {
				if (USER_USAGE_CHECK) {
					if (((Users)object).isAdmin()) { return; }
					validUserQuota(usage, domain);
				}
			} else if (object.getClass().equals(Attachments.class) || object.getClass().equals(Images.class)) {
				if (STORAGE_USAGE_CHECK) { validStorageQuota(usage, object, domain); }
			} else if (object.getClass().equals(Boards.class)) {
				if (BOARD_USAGE_CHECK) { validBoardQuota(usage, domain); }
			}
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			else if (object.getClass().equals(Groups.class)) {
				if (CommonProperty.GROUP_USAGE_CHECK) { validGroupQuota(usage, domain); }
			} else if (object.getClass().equals(Tasks.class)) {
				if (CommonProperty.TASK_USAGE_CHECK) { validTaskQuota(usage, domain); }
			}
			*/
			//<-- ===== DOMAIN STATISTICS =====
		}
	}
	public static void validExpiration(String domainName) throws UnavailableException {
		Usage usage = null;
		//Fees fee = null;
		BlockType blockType = CommonProperty.DEFAULT_BLOCK_TYPE;
		Domains domain = getDomainFromDefaultNamespace(domainName);
		
		if (domain == null) {
			throw new UnavailableException(ErrorCode.ENTITY_NOT_FOUND.getMessage("Domain info not found."));
		}
		// 도메인에 설정된 blockType 적용
		if (domain.getBlockType() != null) { blockType = domain.getBlockType(); }
		
		if (BlockType.PASS.equals(blockType)) {
			//========= blockType이 Pass(사용량 초과여부에 상관없이 서비스 제공) =========
			return; 
		} else if (BlockType.BLOCK.equals(blockType)) {
			//========= 서비스 사용량 초과여부에 상관없이 무조건 서비스 차단. =========
			throw new UnavailableException(ErrorCode.UNAVAILABLE.getMessage("This domain was blocked."));
		} else {
			//========= 서비스 사용량을 체크하여 초과 항목에 대해 서비스 차단 =========
			usage = getDomainUsage(domainName);
			
			if (EXPIRATION_CHECK) { validExpiration(usage, domain); }
		}
	}
	private static void validExpiration(Usage usage, Domains domain) throws UnavailableException {
		if (domain.getExpirationDate() == null) { return; }	// Do not check if value is null.
		
		// 서비스 만료일 정보를 가져온다.
		Date expirationDate = domain.getExpirationDate();
		Date currentDate = new Date();
		if (expirationDate == null) {
			// 서비스 만료일 정보가 없으면 도메인 생성일 + DEFAULT_EXPIRATION_MONTH 을 더한값을  서비스 만료일로 정한다.
			expirationDate = CalendarUtil.addMonth(domain.getCreated(), CommonProperty.DEFAULT_EXPIRATION_MONTH);
		}
		
		// 현재값이 만료일을 초과했는지 체크한다.
		if (expirationDate.compareTo(currentDate) < 0) {
			LOG.info("[Blocking] service expiration.");
			throw new UnavailableException(ErrorCode.SERVICE_EXPIRATION.getMessage());
		}
	}
	private static void validUserQuota(Usage usage, Domains domain) throws UnavailableException {
		if (domain.getUserQuota() == null) { return; }	// Do not check if value is null.
		
		Long userQuota = domain.getUserQuota();
		if (userQuota == null || userQuota == 0) { userQuota = CommonProperty.DEFAULT_USER_QUOTA; }
		//------- 사용자 허용수 체크
		if (usage.getUserCount() >= userQuota) {
			LOG.info("[Blocking] exceed user count.");
			throw new UnavailableException(ErrorCode.EXCESS_USERS_LIMIT.getMessage());
		}
	}
	
	private static void validStorageQuota(Usage usage, Object object, Domains domain) throws UnavailableException {
		if (domain.getStorageQuota() == null) { return; }	// Do not check if value is null.
		
		Long storageQuota = domain.getStorageQuota();
		Long attachFileSize = 0L;
		if (object != null) {
			if (object.getClass().equals(Attachments.class)) { attachFileSize = ((Attachments)object).getFileSize(); }
			else if (object.getClass().equals(Images.class)) { attachFileSize = ((Images)object).getFileSize(); }
		}
		if (storageQuota == null || storageQuota == 0) { storageQuota = CommonProperty.DEFAULT_STORAGE_QUOTA; }
		//------- 스토리지 허용량 체크
		if ((usage.getTotalBytes() + attachFileSize) >= storageQuota) {
			LOG.info("[Blocking] exceed storage capacity.");
			throw new UnavailableException(ErrorCode.EXCESS_STORAGE_LIMIT.getMessage());
		}
	}
	
	private static void validBoardQuota(Usage usage, Domains domain) throws UnavailableException {
		if (ServiceType.TRIAL.equals(domain.getServiceType())) {
			Long boardQuota = domain.getBoardQuota();
			if (boardQuota == null || boardQuota == 0) { boardQuota = CommonProperty.DEFAULT_BOARD_QUOTA; }
			//------- 사용자 허용수 체크
			if (usage.getBoardCount() >= boardQuota) {
				LOG.info("[Blocking] exceed board count.");
				throw new UnavailableException(ErrorCode.EXCESS_BOARDS_LIMIT.getMessage());
			}
		}
	}
	
	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	private static void validGroupQuota(Usage usage, Domains domain) throws UnavailableException {
		Long groupQuota = domain.getGroupQuota();
		if (groupQuota == null || groupQuota == 0) { groupQuota = CommonProperty.DEFAULT_GROUP_QUOTA; }
		//------- 사용자 허용수 체크
		if (usage.getGroupCount() >= groupQuota) {
			LOG.info("[Blocking] exceed group count.");
			throw new UnavailableException(ErrorCode.EXCESS_GROUPS_LIMIT.getMessage());
		}
	}
	
	private static void validTaskQuota(Usage usage, Domains domain) throws UnavailableException {
		Long taskQuota = domain.getTaskQuota();
		if (taskQuota == null || taskQuota == 0) { taskQuota = CommonProperty.DEFAULT_TASK_QUOTA; }
		//------- 사용자 허용수 체크
		if (usage.getTaskCount() >= taskQuota) {
			LOG.info("[Blocking] exceed task count.");
			throw new UnavailableException(ErrorCode.EXCESS_TASKS_LIMIT.getMessage());
		}
	}
	*/
	//<-- ===== DOMAIN STATISTICS =====
	
	public static <T extends Base> void increaseUsage(T object) {
		//String namespace = ((Base)object).getKey().getNamespace();
		String domainName = NamespaceManager.get();
		EntityManager mgr = getEntityManager();
		
		try {
			BlockType blockType = CommonProperty.DEFAULT_BLOCK_TYPE;
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			
			if (object == null || domain == null) { return; }
			if (domain.getBlockType() != null) { blockType = domain.getBlockType(); }
			
			if (BlockType.PASS.equals(blockType) || BlockType.BLOCK.equals(blockType)) { return; }
			else {
				Usage usage = getDomainUsage(mgr, domainName);
				
				if (object.getClass().equals(Users.class)) {
					if (((Users)object).isAdmin()) { return; }
					usage.setUserCount(usage.getUserCount()+1);
				} else if (object.getClass().equals(Attachments.class)) {
					Long attachSize = ((Attachments)object).getFileSize();
					if (attachSize != null) { usage.setAttachmentBytes(usage.getAttachmentBytes() + attachSize); }
				} else if (object.getClass().equals(Images.class)) {
					Long attachSize = ((Images)object).getFileSize();
					if (attachSize != null) { usage.setImageBytes(usage.getImageBytes() + attachSize); }
				} else if (object.getClass().equals(Boards.class)) {
					usage.setBoardCount(usage.getBoardCount()+1);
				}
				//--> ===== DOMAIN STATISTICS =====
				/* Later, I may use this code.
				else if (object.getClass().equals(Groups.class)) {
					usage.setGroupCount(usage.getGroupCount()+1);
				} else if (object.getClass().equals(Tasks.class)) {
					usage.setTaskCount(usage.getTaskCount()+1);
				}
				*/
				//<-- ===== DOMAIN STATISTICS =====

				setDomainUsage(usage);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	public static <T extends Base> void decreaseUsage(T object) {
		String domainName = NamespaceManager.get();
		if (StringUtils.isBlank(domainName)) { return; }
		EntityManager mgr = getEntityManager();
		try {
			BlockType blockType = CommonProperty.DEFAULT_BLOCK_TYPE;
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			
			if (object == null || domain == null) { return; }
			if (domain.getBlockType() != null) { blockType = domain.getBlockType(); }
			
			if (BlockType.PASS.equals(blockType) || BlockType.BLOCK.equals(blockType)) { return; }
			else {
				Usage usage = getDomainUsage(mgr, domainName);
				
				if (object.getClass().equals(Users.class)) {
					if (((Users)object).isAdmin()) { return; }
					usage.setUserCount(usage.getUserCount()-1);
				} else if (object.getClass().equals(Attachments.class)) {
					usage.setAttachmentBytes(usage.getAttachmentBytes() - ((Attachments)object).getFileSize());
				} else if (object.getClass().equals(Images.class)) {
					usage.setImageBytes(usage.getImageBytes() - ((Images)object).getFileSize());
				} else if (object.getClass().equals(Boards.class)) {
					usage.setBoardCount(usage.getBoardCount()-1);
				}
				//--> ===== DOMAIN STATISTICS =====
				/* Later, I may use this code.
				else if (object.getClass().equals(Groups.class)) {
					usage.setGroupCount(usage.getGroupCount()-1);
				} else if (object.getClass().equals(Tasks.class)) {
					usage.setTaskCount(usage.getTaskCount()-1);
				}
				*/
				//<-- ===== DOMAIN STATISTICS =====
		
				setDomainUsage(usage);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	/**
	 * @Description : 해당 도메인의 사용량 정보를 수집한다.
	 * @Method      : summarizeUsageInfo
	 * @param domainName
	 * @return Usage
	 * @Date        : 2015. 3. 27.
	 * @Author      : hyeunwoo.shim@forecs.net
	 */
	public static Usage summarizeUsageInfo(String domainName) {
		String prevNamespace = NamespaceManager.get();
		EntityManager mgr = getEntityManager();
		NamespaceManager.set(domainName);
		try {
			return summarizeUsageInfo(mgr, domainName);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	public static Usage summarizeUsageInfo(EntityManager mgr, String domainName) {
		try {
			// Datastore usage
			Usage usage = getNamespaceUsage(domainName);
			
			// Domain usage
			usage.setUserCount(countUsers(mgr));
			usage.setAttachmentBytes(sumAttachmentFileSize(mgr));
			usage.setAttachmentCount(countAttachments());
			usage.setImageBytes(sumImageFileSize(mgr));
			usage.setImageCount(countImages());
			usage.setBoardCount(countBoards());
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			usage.setGroupCount(countGroups());
			usage.setTaskCount(countTasks());
			*/
			//<-- ===== DOMAIN STATISTICS =====

			//--> hoyeunwoo.shim 2015-11-11 : not used
			//// Search index usage
			//SearchStorageUsage ssu = SearchManager.getSearchIndexUsage(domainName);
			//usage.setSearchIndexBytes(ssu.getStorageUsage());
			//usage.setSearchIndexCount(ssu.getIndexCount());
			//<--
			
			return usage;
		} catch (Exception ex) {
			LOG.warning("[Summarization error]"+ ex.getMessage());
			return null;
		} finally {
		}
	}
	
	@Override
	public QueryResult<Usage> listUsages(String cursorString, Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		try {
			QueryResult<Domains> queryResult = listDomains(cursorString, limit);
			List<Usage> usages = new ArrayList<Usage>();
			
			for (Domains domain : queryResult.getResultList()) {
				Usage usage = getDomainUsage(domain.getDomainName());
				if (usage == null) { continue; }
				usages.add(usage);
			}
			return new QueryResult<Usage>(usages, queryResult.getCursorString());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override	
	public QueryResult<UsageLogs> queryUsageLogs(
			String cursorString,
			Integer limit,
			String domainName,
			Frequency frequency,
			Date startDate,
			Date endDate) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<UsageLogs> dsQuery = new DsQuery<>(UsageLogs.class)
				.eq(FLD.frequency, frequency)
				.le(FLD.created, endDate)
				.ge(FLD.created, startDate)
				.sort(FLD.created, SortDirection.DESC)
				.cursor(cursorString)
				.limit(limit);

			List<UsageLogs> logs = dsQuery.execute(mgr);
			return new QueryResult<UsageLogs>(logs, dsQuery.getCursor());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private static Usage insertOrUpdateUsage(EntityManager mgr, Usage usage) throws Exception {
		try {
			usage.setKey(KeyUtil.createUsageKey(usage));
			// 기존 Usage 정보가 아닌 새로운 Usage 정보를 입력하거나 업데이트 하게 되면 merge가 되지를 않는다.
			// increaseUsage로부터 생성된 경우의 usage와 surveyUsage로부터 생성된 usage의 성격이 다르기때문에
			// 새로 객체를 생성한뒤에 persist를 시켜준다.
			Usage newUsage = new Usage(usage);
			
			doPersistTransaction(mgr, newUsage);
		
			////////////////////////////////////////////////////////////////////////////////////
			// 2017-05-29 다시 기록하도록 변경
			try {
				//insertUsageLog(mgr, usage, Frequency.HOURLY);
				insertUsageLog(mgr, usage, Frequency.DAILY);
				insertUsageLog(mgr, usage, Frequency.MONTHLY);
				insertUsageLog(mgr, usage, Frequency.YEARLY);
			} catch (Exception ex) {}
			////////////////////////////////////////////////////////////////////////////////////
			return usage;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private static UsageLogs insertUsageLog(EntityManager mgr, Usage usage, Frequency frequency) {
		try {
			// 사용량 로그 정보를 기록한다.
			if (usage.getKey() == null) { usage.setKey(KeyUtil.createUsageKey(usage)); }
			UsageLogs usageLog = new UsageLogs(usage, frequency);
			doPersistTransaction(mgr, usageLog);
			return usageLog;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Usage resetUsageCheckpoints(Domains originDomain, Domains domain) {
		try {
			boolean resetExpireCheckpoint = false;
			boolean resetUserCheckpoint = false;
			boolean resetStorageCheckpoint = false;
			boolean resetBoardCheckpoint = false;
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			boolean resetGroupCheckpoint = false;
			boolean resetTaskCheckpoint = false;
			*/
			//<-- ===== DOMAIN STATISTICS =====
		
			if (originDomain.getExpirationDate() != null && domain.getExpirationDate() != null) {
				if (originDomain.getExpirationDate().compareTo(domain.getExpirationDate()) != 0) { resetExpireCheckpoint = true; }
			} else if (originDomain.getExpirationDate() != null || domain.getExpirationDate() != null) {
				resetExpireCheckpoint = true;
			}
			
			if (originDomain.getUserQuota() != null && domain.getUserQuota() != null) {
				if (originDomain.getUserQuota().compareTo(domain.getUserQuota()) != 0) { resetUserCheckpoint = true; }
			} else if (originDomain.getUserQuota() != null || domain.getUserQuota() != null) {
				resetUserCheckpoint = true;
			}
			
			if (originDomain.getStorageQuota() != null && domain.getStorageQuota() != null) {
				if (originDomain.getStorageQuota().compareTo(domain.getStorageQuota()) != 0) { resetStorageCheckpoint = true; }
			} else if (originDomain.getStorageQuota() != null || domain.getStorageQuota() != null) {
				resetStorageCheckpoint = true;
			}
			
			if (originDomain.getBoardQuota() != null && domain.getBoardQuota() != null) {
				if (originDomain.getBoardQuota().compareTo(domain.getBoardQuota()) != 0) { resetBoardCheckpoint = true; }
			} else if (originDomain.getBoardQuota() != null || domain.getBoardQuota() != null) {
				resetBoardCheckpoint = true;
			}
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			if (originDomain.getGroupQuota() != null && domain.getGroupQuota() != null) {
				if (originDomain.getGroupQuota().compareTo(domain.getGroupQuota()) != 0) { resetGroupCheckpoint = true; }
			} else if (originDomain.getGroupQuota() != null || domain.getGroupQuota() != null) {
				resetGroupCheckpoint = true;
			}
			if (originDomain.getTaskQuota() != null && domain.getTaskQuota() != null) {
				if (originDomain.getTaskQuota().compareTo(domain.getTaskQuota()) != 0) { resetTaskCheckpoint = true; }
			} else if (originDomain.getTaskQuota() != null || domain.getTaskQuota() != null) {
				resetTaskCheckpoint = true;
			}
			*/
			//<-- ===== DOMAIN STATISTICS =====
			
			Usage usage = resetUsageCheckpoints(domain.getDomainName(),
					resetExpireCheckpoint,
					resetUserCheckpoint,
					resetStorageCheckpoint,
					resetBoardCheckpoint
					//--> ===== DOMAIN STATISTICS =====
					/* Later, I may use this code.
					, resetGroupCheckpoint,
					resetTaskCheckpoint
					*/
					//<-- ===== DOMAIN STATISTICS =====
					);
			
			return usage;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		}
	}

	@Override
	public Usage resetUsageCheckpoints(String domainName,
			boolean resetExpireCheckpoint,
			boolean resetUserCheckpoint,
			boolean resetStorageCheckpoint,
			boolean resetBoardCheckpoint
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			, boolean resetGroupCheckpoint,
			boolean resetTaskCheckpoint
						*/
			//<-- ===== DOMAIN STATISTICS =====
			) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		EntityManager mgr = getEntityManager();
		
		try {
			Usage usage = doFind(mgr, Usage.class, KeyUtil.createUsageKey(domainName));
			
			if (usage != null && 
					(resetExpireCheckpoint ||
							resetUserCheckpoint ||
							resetStorageCheckpoint ||
							resetBoardCheckpoint
							//--> ===== DOMAIN STATISTICS =====
							/* Later, I may use this code.
							resetGroupCheckpoint ||
							resetTaskCheckpoint
							*/
							//<-- ===== DOMAIN STATISTICS =====
							)) {
				
				if (resetExpireCheckpoint) { usage.setExpirationCheckDays(null); }
				if (resetUserCheckpoint) { usage.setUsageCheckPointsOfUser(null); }
				if (resetStorageCheckpoint) { usage.setUsageCheckPointsOfStorage(null); }
				if (resetBoardCheckpoint) { usage.setUsageCheckPointsOfBoard(null); }
				//--> ===== DOMAIN STATISTICS =====
				/* Later, I may use this code.
				if (resetGroupCheckpoint) { usage.setUsageCheckPointsOfGroup(null); }
				if (resetTaskCheckpoint) { usage.setUsageCheckPointsOfTask(null); }
				*/
				//<-- ===== DOMAIN STATISTICS =====
				
				usage = doMergeTransaction(mgr, usage);
			}
			
			return usage;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public void removeAllUsage() throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			List<String> domainNames = listNamespaces();
			for (String domainName : domainNames) {
				removeUsage(mgr, domainName);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private static Long countUsers(EntityManager mgr) {
		try {
			long count = 0;
		
			DsQuery<Users> dsQuery = new DsQuery<>(Users.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.active, true);
			
			List<Users> users = dsQuery.execute(mgr);
			for (Users user : users) {
				if (user.isAdmin()) { continue; }
				count++;
			}
			return count;
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Users Kind or entity not found.", ex.getMessage()));
			return 0L;
		}
	}

//	private static Long countUsers20160224(EntityManager mgr) {
//		try {
//			long count = 0;
//		
//			TypedQuery<Key> query = new QueryBuilder<>(Users.class)
//					.addClause(FLD.active, true)
//					.buildKeyOnlyRead(mgr);
//			
//			List<Users> users = queryResults(mgr, Users.class, query);
//			for (Users user : users) {
//				if (user.isAdmin()) { continue; }
//				count++;
//			}
//			return count;
//		} catch (Exception ex) {
//			LOG.warning(String.format("[%s] Users Kind or entity not found.", ex.getMessage()));
//			return 0L;
//		}
//	}
//	private static Long countUsers(EntityManager mgr) {
//	try {
//		SimpleQuery<Users> sq = new SimpleQuery<>(mgr, Users.class);
//		sq.where(sq.equal(FLD.active, true));
//		TypedQuery<Long> countQuery = sq.count();
//		
//		Long count = countQuery.getSingleResult();
//		if (count > 0) { count--; }	// Admin is not included in user's count.
//		return count;
//	} catch (Exception ex) {
//		LOG.warning(String.format("[%s] Users Kind or entity not found.", ex.getMessage()));
//		return 0L;
//	}
//}
	private static Long countBoards() {
		try {
			DsQuery<Boards> dsQuery = new DsQuery<>(Boards.class);
			return dsQuery.count();
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Boards or entity not found.", ex.getMessage()));
			return 0L;
		}
	}
//	private static Long countBoards20160224(EntityManager mgr) {
//		try {
//			SimpleQuery<Boards> sq = new SimpleQuery<>(mgr, Boards.class);
//			//sq.where( sq.equal("closeYN", null));
//			TypedQuery<Long> countQuery = sq.count();
//			
//			return countQuery.getSingleResult();
////			Query query = new QueryBuilder<>(Boards.class, FetchType.COUNT)
////					.addClause("closeYN", null)
////					.build(mgr);
////
////			count = (Long)query.getSingleResult();
//			//boardList = query.getResultList();
//		} catch (Exception ex) {
//			LOG.warning(String.format("[%s] Boards or entity not found.", ex.getMessage()));
//			return 0L;
//		}
//	}
//	private static Long countUsers(EntityManager mgr) {
//		try {
//			TypedQuery<Users> query = new QueryBuilder<>(Users.class).build(mgr);
//			List<Users> users = queryResults(query);
//			return new Long(users.size());
//		} catch (Exception ex) {
//			LOG.warning(String.format("[%s] Users Kind or entity not found.", ex.getMessage()));
//			return 0L;
//		}
//	}

	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	private static Long countGroups() {
		EntityManager mgr = getEntityManager();
		//List<Groups> groupList = null;
		
		Long count = 0L;
		try {
			SimpleQuery<Groups> sq = new SimpleQuery<>(mgr, Groups.class);
			//sq.where(sq.equal(FLD.deleteYN, null));
			TypedQuery<Long> countQuery = sq.count();
			count = countQuery.getSingleResult();
			
//			Query query = new QueryBuilder<>(Groups.class, FetchType.COUNT)
//					.addClause(FLD.deleteYN, null)
//					.build(mgr);
//			
//			count = (Long)query.getSingleResult();
			//groupList = query.getResultList();
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Kind or entity not found.", ex.getMessage()));
		} finally {
			finalizeTransaction(mgr);
		}

		return count;
	}
	
	private static Long countTasks () {
		EntityManager mgr = getEntityManager();
		//List<Tasks> taskList = null;
		
		Long count = 0L;
		try {
			SimpleQuery<Tasks> sq = new SimpleQuery<>(mgr, Tasks.class);
//			sq.where(sq.and(
//						sq.equal(FLD.archiveYN, null),
//						sq.equal(FLD.deleteYN, null)
//					));
			TypedQuery<Long> countQuery = sq.count();
			
			count = countQuery.getSingleResult();
//			Query query = new QueryBuilder<>(Tasks.class, FetchType.COUNT)
//					.addClause(FLD.archiveYN, N)
//					.addClause(FLD.deleteYN, null)
//					.build(mgr);
//
//			count = (Long)query.getSingleResult();
			//taskList = query.getResultList();
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Kind or entity not found.", ex.getMessage()));
		} finally {
			finalizeTransaction(mgr);
		}

		return count;
	}
	*/
	//<-- ===== DOMAIN STATISTICS =====

	@SuppressWarnings("unused")
	private static List<Attachments> listAttachment () {
		EntityManager mgr = getEntityManager();
		
		try {
			TypedQuery<Attachments> query = new QueryBuilder<>(Attachments.class)
					//.addClause(FLD.archiveYN, N)
					//.addClause(FLD.deleteYN, null)
					.build(mgr);
			return queryResults(query);
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Attachments Kind or entity not found.", ex.getMessage()));
			return null;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private static Long sumAttachmentFileSize(EntityManager mgr) {
		try {
			SimpleQuery<Attachments> sq = new SimpleQuery<>(mgr, Attachments.class);
			//sq.where(sq.isNotNull(FLD.fileSize));
//			sq.where(sq.and(
//						sq.equal(FLD.archiveYN, N),
//						sq.equal(FLD.deleteYN, null)
//					));
			TypedQuery<Number> sumQuery = sq.sum(FLD.fileSize);
			
			return sumQuery.getSingleResult().longValue();
		} catch (Exception ex) {
			LOG.warning(String.format("[Summarize %s] Attachments Kind or entity not found.", NamespaceManager.get()));
			return 0L;
		}
	}
//	private static Long sumAttachmentFileSize(EntityManager mgr) {
//		try {
//			TypedQuery<Attachments> query = new QueryBuilder<>(Attachments.class).build(mgr);
//			List<Attachments> attachments = queryResults(query);
//			Long totalFileSize = 0L;
//			for (Attachments attachment : attachments) {
//				totalFileSize += attachment.getFileSize();
//			}
//			return totalFileSize;
//		} catch (Exception ex) {
//			LOG.warning(String.format("[Summarize %s] Attachments Kind or entity not found.", NamespaceManager.get()));
//			return 0L;
//		}
//	}
	
	private static Long countAttachments() {
		try {
			DsQuery<Attachments> dsQuery = new DsQuery<>(Attachments.class);
			return dsQuery.count();
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Attachments Kind or entity not found.", ex.getMessage()));
			return 0L;
		}
	}
//	private static Long countAttachments20160224(EntityManager mgr) {
//		try {
//			SimpleQuery<Attachments> sq = new SimpleQuery<>(mgr, Attachments.class);
////			sq.where(sq.and(
////						sq.equal(FLD.archiveYN, N),
////						sq.equal(FLD.deleteYN, null)
////					));
//			TypedQuery<Long> countQuery = sq.count();
//			
//			return countQuery.getSingleResult();
//		} catch (Exception ex) {
//			LOG.warning(String.format("[%s] Attachments Kind or entity not found.", ex.getMessage()));
//			return 0L;
//		}
//	}
	
//	private static Long countAttachments(EntityManager mgr) {
//		try {
//			TypedQuery<Attachments> query = new QueryBuilder<>(Attachments.class).build(mgr);
//			List<Attachments> attachments = queryResults(query);
//			return new Long(attachments.size());
//		} catch (Exception ex) {
//			LOG.warning(String.format("[%s] Attachments Kind or entity not found.", ex.getMessage()));
//			return 0L;
//		}
//	}
	
	private static Long sumImageFileSize(EntityManager mgr) {
		try {
			SimpleQuery<Images> sq = new SimpleQuery<>(mgr, Images.class);
//			sq.where(sq.and(
//						sq.equal(FLD.archiveYN, N),
//						sq.equal(FLD.deleteYN, null)
//					));
			TypedQuery<Number> sumQuery = sq.sum(FLD.fileSize);
			
			return sumQuery.getSingleResult().longValue();
		} catch (Exception ex) {
			LOG.warning(String.format("[Summarize %s] Images Kind or entity not found.", NamespaceManager.get()));
			return 0L;
		}
	}
//	private static Long sumImageFileSize(EntityManager mgr) {
//		try {
//			TypedQuery<Images> query = new QueryBuilder<>(Images.class).build(mgr);
////			
//			List<Images> images = queryResults(query);
//			Long totalFileSize = 0L;
//			for (Images image : images) {
//				totalFileSize += image.getFileSize();
//			}
//			
//			return totalFileSize;
//		} catch (Exception ex) {
//			LOG.warning(String.format("[Summarize %s] Images Kind or entity not found.", NamespaceManager.get()));
//			return 0L;
//		}
//	}
	private static Long countImages() {
		try {
			DsQuery<Images> dsQuery = new DsQuery<>(Images.class);
			return dsQuery.count();
		} catch (Exception ex) {
			LOG.warning(String.format("[%s] Images Kind or entity not found.", ex.getMessage()));
			return 0L;
		}
	}
//	private static Long countImages20160224(EntityManager mgr) {
//		try {
//			SimpleQuery<Images> sq = new SimpleQuery<>(mgr, Images.class);
////			sq.where(sq.and(
////						sq.equal(FLD.archiveYN, N),
////						sq.equal(FLD.deleteYN, null)
////					));
//			TypedQuery<Long> countQuery = sq.count();
//			
//			return countQuery.getSingleResult();
//		} catch (Exception ex) {
//			LOG.warning(String.format("[%s] Images Kind or entity not found.", ex.getMessage()));
//			return 0L;
//		}
//	}
	
//	private static Long countImages(EntityManager mgr) {
//		try {
//			TypedQuery<Images> query = new QueryBuilder<>(Images.class).build(mgr);
//			List<Images> images = queryResults(query);
//			
//			return new Long(images.size());
//		} catch (Exception ex) {
//			LOG.warning(String.format("[%s] Images Kind or entity not found.", ex.getMessage()));
//			return 0L;
//		}
//	}
	
	@Override
	public void removeAllUsageLog() throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			List<String> domainNames = listNamespaces();
			for (String domainName : domainNames) {
				removeUsageLog(mgr, domainName);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeUsageLog(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		try {
			removeUsageLog(mgr, domainName);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private void removeUsageLog(EntityManager mgr, String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			TypedQuery<UsageLogs> query = new QueryBuilder<>(UsageLogs.class, QueryMode.DELETE)
					.build(mgr);
		
			query.executeUpdate();
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public void removeUsageLogByDate(Date created) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			List<String> domainNames = listNamespaces();
			for (String domainName : domainNames) {
				removeUsageLogByDate(mgr, domainName, created);
			}
					
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private void removeUsageLogByDate(EntityManager mgr, String domainName, Date created) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			TypedQuery<UsageLogs> query = new QueryBuilder<>(UsageLogs.class, QueryMode.DELETE)
					.addLEClause(FLD.created, created, SortDirection.ASC)
					.build(mgr);
		
			query.executeUpdate();
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	
	@Override
	public void removeUsage(String domainName) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			removeUsage(mgr, domainName);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private void removeUsage(EntityManager mgr, String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			doRemoveTransaction(mgr, Usage.class, KeyUtil.createDomainKey(domainName));
			
			try {
				removeUsageLog(domainName);
			} catch (Exception ex) {}
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}

	public static Usage getDomainUsage(String domainName) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		EntityManager mgr = getEntityManager();;
		
		try {
			return getDomainUsage(mgr, domainName);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private static Usage getDomainUsage(EntityManager mgr, String domainName) {
		Usage usage = doFind(mgr, Usage.class, KeyUtil.createUsageKey(domainName));
		
		if (usage == null) {
			usage = summarizeUsageInfo(mgr, domainName);
		}
		
		return usage;
	}
	
	private static void setDomainUsage(Usage usage) {
		putMemcache(usage);
	}
	
	@SuppressWarnings("unused")
	private static List<Usage> listNamespaceUsages() {
		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
		Query query = new Query(__STAT_NAMESPACE__);
		
		List<Usage> usageList = new ArrayList<Usage>();
		
		for (final Entity entity : datastore.prepare(query).asIterable()) {
			String domainName = (String)entity.getProperty(SUBJECT_NAMESPACE);
			usageList.add(new Usage(domainName, entity));
		}
		
		return usageList;
	}
	
	private static Usage getNamespaceUsage(String domainName) {
		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
		Query query = new Query(__STAT_NS_TOTAL__);
		
		Entity entity = datastore.prepare(query).asSingleEntity();
		
		return new Usage(domainName, entity);
	}
	
	@SuppressWarnings("unused")
	private Usage getUsage(String domainName) {
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, Usage.class, KeyUtil.createUsageKey(domainName));
		} finally {
			finalizeTransaction(mgr);
		}
	}
	/*
	 * public void surveyUsage()  {
	String prevNamespace = NamespaceManager.get();
	try {
		QueryResult<Domains> queryResult = listDomains(null, null);
		List<Domains> domains = queryResult.getResultList();

		for (Domains domain : domains) {
			// survey할 Namespace 셋팅
			NamespaceManager.set(domain.getDomainName());

			// 사용량 체크 도중에 Activity와 Notification을 처리하기위한 ActivityType을 담을 객체
			List<ActivityType> activityTypeList = new ArrayList<ActivityType>();

			// 현재 사용량 정보를 가져온다.
			Usage currentUsage = summarizeUsageInfo(domain.getDomainName());
			// 이전 사용량 정보를 가져온다.
			Usage prevUsage = getUsage(domain.getDomainName());
			List<Integer> expirationCheckDays = null;
			Fees fee = getFee(domain.getFeeId());

			if (fee == null) { fee = feeService.insertDefaultFees(); }
			
			currentUsage.setFee(fee);
			currentUsage.setFeeId(fee.getFeeId());
			*//** !!! (주)-------------------------------------------------------- *//*
			*//** 요금제 사용 종료일 안내(EXPIRATION_CHECK_POINTS 참조. 기획문서에는 1주일만 되어있으나, 15~1일전내에서 여러번 알려주어야 하지 않을까?) *//*
			Date expirationDate = domain.getExpirationDate();
			Date currentDate = new Date();
			// 도메인의 서비스 만료일이 없으면 DEFAULT_EXPIRATION_MONTH에 해당하는 일자를 도메인 생성일에 더하여 서비스 만료일을 정한다.
			if (expirationDate == null) {
				expirationDate = CalendarUtil.addMonth(domain.getCreated(), CommonProperty.DEFAULT_EXPIRATION_MONTH);
			}
			
			// 중복으로 메시지를 알리는것을 방지하기 위해, 이전 사용량 정보에서 ExpirationChekDay 정보를 가져온다. 
			if (prevUsage != null && prevUsage.getExpirationCheckDays() != null) {
				expirationCheckDays = prevUsage.getExpirationCheckDays();
			} else {
				expirationCheckDays = new ArrayList<Integer>();
			}
			
			// 만료일 체크 리스트
			for (int prevDay : CommonProperty.EXPIRATION_CHECK_POINTS) {
				if (CalendarUtil.addDay(expirationDate, prevDay).compareTo(currentDate) < 0) {
					// 만료일 체크 시점에 도달하고 한번도 Noti를 발생시키지 않았다면 Noti를 발생시키고 만료일 체크 목록에 추가한다.
					if (!expirationCheckDays.contains(prevDay)) {
						// 만료일 체크 시점에  포함될 경우, 경고 Activity를 추가한다.
						activityTypeList.add(ActivityType.WARNING_OF_EXPIRATION);
						
						LOG.info(String.format("요금제 사용 %d일전  Noti임:",prevDay));
						expirationCheckDays.add(prevDay);
					}
					break;
				}
			}
			// 현재 사용량 정보에 만료일을 기록한다.
			currentUsage.setExpirationDate(expirationDate);
			// 만료일 체크를 했던 시점 목록을 기록한다.
			currentUsage.setExpirationCheckDays(expirationCheckDays);
			*//** -------------------------------------------------------- *//*
			
			*//** -------------------------------------------------------- *//*
			*//** 사용량 80% 이상일때 알림(기획문서상에는 80%만 존재하나, 80~100% 내에서 체크 시점을 여러번 두어야 하지 않을까?) *//*
			if (fee.getFeeType().equals(FeeType.FlatRate)) {
				List<Integer> usageCheckPointsOfUser = null;
				List<Integer> usageCheckPointsOfGroup = null;
				List<Integer> usageCheckPointsOfBoard = null;
				List<Integer> usageCheckPointsOfTask = null;
				List<Integer> usageCheckPointsOfStorage = null;
				
				// 이전 사용량 체크 시점 정보를 가져온다.
				if (prevUsage != null && prevUsage.getUsageCheckPointsOfUser() != null) {
					usageCheckPointsOfUser = prevUsage.getUsageCheckPointsOfUser();	
				} else {
					usageCheckPointsOfUser = new ArrayList<Integer>();
				}
				if (prevUsage != null && prevUsage.getUsageCheckPointsOfGroup() != null) {
					usageCheckPointsOfGroup = prevUsage.getUsageCheckPointsOfGroup();	
				} else {
					usageCheckPointsOfGroup = new ArrayList<Integer>();
				}
				if (prevUsage != null && prevUsage.getUsageCheckPointsOfBoard() != null) {
					usageCheckPointsOfBoard = prevUsage.getUsageCheckPointsOfBoard();	
				} else {
					usageCheckPointsOfBoard = new ArrayList<Integer>();
				}
				if (prevUsage != null && prevUsage.getUsageCheckPointsOfTask() != null) {
					usageCheckPointsOfTask = prevUsage.getUsageCheckPointsOfTask();	
				} else {
					usageCheckPointsOfTask = new ArrayList<Integer>();
				}
				if (prevUsage != null && prevUsage.getUsageCheckPointsOfStorage() != null) {
					usageCheckPointsOfStorage = prevUsage.getUsageCheckPointsOfStorage();	
				} else {
					usageCheckPointsOfStorage = new ArrayList<Integer>();
				}
				
				*//****************************************************************************//*
				*//** Noti를 발생시키기 위해 사용률 체크 목록을 가져와서, 각각의 사용률에 도달했는지 체크한다. *//*
				*//** (주) 사용률은 큰값부터 작은값 순서로 체크한다.(당연히, 큰값에 도달한경우면 그 이하값들도 다 체크 시점에 부합되는 값이기때문) *//*
				*//****************************************************************************//*
				for (Integer checkPoint : CommonProperty.USAGE_CHECK_POINTS) {
					// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
					int userUsagePoint = ((int)(100*currentUsage.getUserCount()/fee.getUsersLimit()))/checkPoint;
					if (userUsagePoint>=1) {
						// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
						if (!usageCheckPointsOfUser.contains(checkPoint)) {
							activityTypeList.add(ActivityType.WARNING_OF_USERS_USAGE);
							LOG.info("Noti - users limit:"+checkPoint);
							// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
							usageCheckPointsOfUser.add(checkPoint);
						}
						break;
					}
				}
				for (Integer checkPoint : CommonProperty.USAGE_CHECK_POINTS) {
					// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
					int groupUsagePoint = ((int)(100*currentUsage.getGroupCount()/fee.getGroupsLimit()))/checkPoint;
					if (groupUsagePoint>=1) {
						// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
						if (!usageCheckPointsOfGroup.contains(checkPoint)) {
							activityTypeList.add(ActivityType.WARNING_OF_GROUPS_USAGE);
							LOG.info("Noti - groups limit:"+checkPoint);
							// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
							usageCheckPointsOfGroup.add(checkPoint);
						}
						break;
					}
				}
				for (Integer checkPoint : CommonProperty.USAGE_CHECK_POINTS) {
					// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
					int boardUsagePoint = ((int)(100*currentUsage.getBoardCount()/fee.getBoardsLimit()))/checkPoint;
					if (boardUsagePoint>=1) {
						// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
						if (!usageCheckPointsOfBoard.contains(checkPoint)) {
							activityTypeList.add(ActivityType.WARNING_OF_BOARDS_USAGE);
							LOG.info("Noti - boards limit:"+checkPoint);
							// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
							usageCheckPointsOfBoard.add(checkPoint);
						}
						break;
					}
				}
				for (Integer checkPoint : CommonProperty.USAGE_CHECK_POINTS) {
					// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
					int taskUsagePoint = ((int)(100*currentUsage.getTaskCount()/fee.getTasksLimit()))/checkPoint;
					if (taskUsagePoint>=1) {
						// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
						if (!usageCheckPointsOfTask.contains(checkPoint)) {
							activityTypeList.add(ActivityType.WARNING_OF_TASKS_USAGE);
							LOG.info("Noti - tasks limit:"+checkPoint);
							// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
							usageCheckPointsOfTask.add(checkPoint);
						}
						break;
					}
				}
				for (Integer checkPoint : CommonProperty.USAGE_CHECK_POINTS) {
					// 사용량 체크 각 시점마다 한계점(userUsagePoint)를 초과했는지를 체크한다.
					int storageUsagePoint = ((int)(100*currentUsage.getStorageSize()/fee.getStorageLimit()))/checkPoint;
					if (storageUsagePoint>=1) {
						// 사용량 체크 시점을 기록해둔 목록과 현재 사용량 체크 시점을 비교하여 한번도 기록되지 않았으면 Noti를 수행하고 체크 시점을 저장해둔다.
						if (!usageCheckPointsOfStorage.contains(checkPoint)) {
							activityTypeList.add(ActivityType.WARNING_OF_STORAGE_USAGE);
							LOG.info("Noti - storage limit:"+checkPoint);
							// checkpoint 임계점을 최초로 초과한 시점을 기록한다.
							usageCheckPointsOfStorage.add(checkPoint);
						}
						break;
					}
				}
				
				// 사용량 체크 시점들을 현재 사용량 정보에 기록한다.
				currentUsage.setUsageCheckPointsOfUser(usageCheckPointsOfUser);
				currentUsage.setUsageCheckPointsOfGroup(usageCheckPointsOfGroup);
				currentUsage.setUsageCheckPointsOfBoard(usageCheckPointsOfBoard);
				currentUsage.setUsageCheckPointsOfTask(usageCheckPointsOfTask);
				currentUsage.setUsageCheckPointsOfStorage(usageCheckPointsOfStorage);
			}
			*//** -------------------------------------------------------- *//*
			
			// 현재 Usage 및 Noti 상태 정보를 입력하거나 수정한다.
			setDomainUsage(currentUsage, true);
			//--> hyeunwoo.shim 2015-10-20 : moved setDomainUsage
//			try { insertUsageLog(currentUsage); } catch (Exception ex) {}
			//<--
			*//** Activity를 발생시킬 목록에서 해당 Activity를 기록하고 Noti를 발생시킨다.(사용자 NotificationSetting정보와 무관하게 발생시켜야한다) *//*
			try {
				List<Activities> activityList = new ArrayList<Activities>();
				for (ActivityType activityType : activityTypeList) {
					Activities activity = activityService.createUsageActivity(currentUsage, null, activityType);
					activityList.add(activity);
				}
				activityService.insertActivities(activityList);
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
		}
	} catch (Exception ex) {
		LOG.severe(ex.getMessage());
		//ex.printStackTrace();
	} finally {
		NamespaceManager.set(prevNamespace);
	}
}
*/
}

class IntegerComparator implements Comparator<Integer> {
    @Override
    public int compare(Integer o1, Integer o2) {
        return o2.compareTo(o1);
    }
}
