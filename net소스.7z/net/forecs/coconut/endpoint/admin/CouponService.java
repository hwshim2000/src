package net.forecs.coconut.endpoint.admin;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.DomainsLogType;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.TermType;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.entity.billing.Coupons;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.DomainsLog;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.datanucleus.query.JPACursorHelper;


public class CouponService extends AdminCommonService implements ICouponService {
	private final IAdminService adminService;
	private final IUsageService usageService;
	private final IDomainsLogService domainsLogService;
	
	@Inject
	public CouponService(IAdminService adminService, IUsageService usageService, IDomainsLogService domainsLogService) {
		this.adminService = adminService;
		this.usageService = usageService;
		this.domainsLogService = domainsLogService;
	}
	
	@Override
	public QueryResult<Coupons> listCoupons(
		String cursorString,
		Integer limit,
		String domainName,
		String useYN,
		String issueYN
		) throws Exception {

		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			Cursor cursor = null;
			
			TypedQuery<Coupons> query = new QueryBuilder<>(Coupons.class)
					.addClause(FLD.domainName, domainName)
					.addClause(FLD.useYN, useYN)
					.addClause(FLD.issueYN, issueYN)
					.build(mgr);

			if (StringUtils.isNotBlank(cursorString)) {
				cursor = Cursor.fromWebSafeString(cursorString);
				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
			}

			if (limit != null) {
				query.setFirstResult(0);
				query.setMaxResults(limit);
			}

			List<Coupons> couponList = query.getResultList();
			cursor = JPACursorHelper.getCursor(couponList);
			
			return new QueryResult<Coupons>(couponList, cursor);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Coupons getCoupons(String couponCode) {
		if (StringUtils.isBlank(couponCode)) { return null; }
		
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();

		try {
			return doFind(mgr, Coupons.class, KeyUtil.createCouponKey(couponCode));
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Coupons insertCoupons(Coupons coupon) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			if (contains(mgr, Coupons.class, coupon.getKey())) {
				throw new EntityExistsException("Object already exists");
			}
			
			doPersistTransaction(mgr, coupon);
			
			return coupon;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Coupons updateCoupons(Coupons coupon) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return updateCoupons(mgr, coupon);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Coupons updateCoupons(EntityManager mgr, Coupons coupon) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		try {
			valid(coupon);
			doMergeTransaction(mgr, coupon);
			return coupon;
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public List<Coupons> issueCoupons(List<String> couponCodes) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();

		try {
			List<Coupons> coupons = new ArrayList<Coupons>();
			for(String couponCode : couponCodes) {
				Coupons coupon = doFind(mgr, Coupons.class, KeyUtil.createCouponKey(couponCode));
				coupon.setIssueYN(Y);
				coupons.add(coupon);
			}
			doMergeTransaction(mgr, coupons);
			
			return coupons;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Coupons issueCoupon(String couponCode, String issuer, String issueTarget) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();

		try {
			Coupons coupon = doFind(mgr, Coupons.class, KeyUtil.createCouponKey(couponCode));
			coupon.setIssueYN(Y);
			coupon.setIssuer(issuer);
			coupon.setIssueTarget(issueTarget);
			
			doMergeTransaction(mgr, coupon);
			return coupon;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public Coupons updateIssuer(String couponCode, String issuer) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();

		try {
			Coupons coupon = doFind(mgr, Coupons.class, KeyUtil.createCouponKey(couponCode));
			coupon.setIssueYN(Y);
			coupon.setIssuer(issuer);
			
			doMergeTransaction(mgr, coupon);
			return coupon;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public Coupons updateIssueTarget(String couponCode, String issueTarget) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();

		try {
			Coupons coupon = doFind(mgr, Coupons.class, KeyUtil.createCouponKey(couponCode));
			coupon.setIssueYN(Y);
			coupon.setIssueTarget(issueTarget);
			
			doMergeTransaction(mgr, coupon);
			return coupon;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void removeCoupons(String couponCode) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			Coupons coupon = doFind(mgr, Coupons.class, KeyUtil.createCouponKey(couponCode));
			if (coupon != null) {
				coupon.setDeleted(new Date());
				coupon.setDeleteYN(Y);

				doMergeTransaction(mgr, coupon);
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void permanentRemoveCoupons(String couponCode) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			doRemoveTransaction(mgr, Coupons.class, KeyUtil.createCouponKey(couponCode));
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public List<Coupons> createCoupons(
			ServiceType serviceType,
			Long userQuota,
			Long storageQuota,
			Long boardQuota,
//			Long groupQuota,
//			Long taskQuota,
			Date validDate,
			TermType termType,
			Integer term,
			Date expirationDate,
			int couponCount) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			if (TermType.FIXED.equals(termType) && (expirationDate == null || expirationDate.compareTo(new Date()) < 0)) {
				throw new IllegalArgumentException("Expiration date is not null or should be large than current time.");
			}
//			if (TermType.APPEND.equals(termType) && (term == null || term <= 0)) {
//				throw new IllegalArgumentException("Term value should be bigger than 0.");
//			}
			List<Coupons> couponList = new ArrayList<Coupons>();
			// 발행할 쿠폰수 만큼 선택한 요금제와 기간만큼 쿠폰을 발행한다.
			if (couponCount > 0) {
				int publishCount = 0;
				
				if (validDate == null || validDate.compareTo(new Date()) < 0) {
					throw new UnavailableException("Invalid out-of-date.");
				}
				if (userQuota != null && (storageQuota == null || storageQuota == 0L)) {
					if (ServiceType.TRIAL.equals(serviceType)) {
						storageQuota = userQuota * CommonProperty.UNIT_STORAGE_PER_USER;
					} else {
						storageQuota = 5 * CommonProperty.GB;
					}
				}
				
				while(true) {
					Key couponKey = KeyUtil.createCouponKey();
					
					if (doFind(mgr, Coupons.class, couponKey) == null) {
						Coupons coupon = new Coupons();
						coupon.setKey(couponKey);
						coupon.setCreator(CommonProperty.SYSTEM_USER_NAME);
						coupon.setUserQuota(userQuota);
						coupon.setStorageQuota(storageQuota);
						coupon.setBoardQuota(boardQuota);
						coupon.setServiceType(serviceType);
												
						//--> ===== DOMAIN STATISTICS =====
						/* Later, I may use this code.
						coupon.setGroupQuota(groupQuota);
						coupon.setTaskQuota(taskQuota);
						*/
						//<-- ===== DOMAIN STATISTICS =====
						
						coupon.setValidDate(validDate);
						coupon.setTermType(termType);
						coupon.setTerm(term);
						coupon.setExpirationDate(expirationDate);
						
						coupon.setUseYN(N);
						coupon.setIssueYN(N);
						
						doPersistTransaction(mgr, coupon);
						
						couponList.add(coupon);
						publishCount++;
					} else { continue; }
					
					if (publishCount == couponCount) { break; }
				}
			}
			
			return couponList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public boolean isValidCoupon(String couponCode) {
		if (StringUtils.isBlank(couponCode)) { return false; }
		
		Coupons coupon = getCoupons(couponCode);
		
		return isValidCoupon(coupon);
	}
	private boolean isValidCoupon(Coupons coupon) {
		if (!isValid(coupon)) { return false; }
		
		if (StringUtils.isNotBlank(coupon.getUseYN()) && N.equals(coupon.getUseYN()) && coupon.getValidDate().compareTo(new Date()) >= 0) {
			return true;
		} else {
			return false;
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public Coupons registCoupon(String domainName, String couponCode) throws Exception {
		String prevNamespace = NamespaceManager.get();
		EntityManager mgr = getEntityManager();
		
		try {
			Coupons coupon = getCoupons(couponCode);
			
			if (!isValidCoupon(coupon)) { 
				throw new UnavailableException("This coupon was used or out of date.");
			}
			
			NamespaceManager.set(domainName);
			//Domains domain = adminService.applyDomainFee(domainName, fee, coupon.getTerm());
			Date expirationDate = null;
			
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			Domains originDomain = (Domains)CopyUtil.copyDeeply(domain);
			DomainsLog domainLog = new DomainsLog(originDomain, DomainsLogType.REGIST_COUPON, couponCode);
			
			valid(domain);
			
			if (TermType.APPEND.equals(coupon.getTermType())) {
				// 아직 만료일이 남아 있다면, 만료일에 추가, 지났거나 한번도 설정이 안되어 있었다면, 현재 시간부터 만료일 설정
				if (coupon.getTerm() != null) {
					if (domain.getExpirationDate() != null && domain.getExpirationDate().compareTo(new Date()) >= 0) {
						expirationDate = domain.getExpirationDate();
					} else {
						expirationDate = new Date();
					}
					
					expirationDate = CalendarUtil.addMonth(expirationDate, coupon.getTerm());
				}
			} else if (TermType.FIXED.equals(coupon.getTermType())) {
				expirationDate = coupon.getExpirationDate();
//				if (expirationDate == null && coupon.getTerm() != null) {
//					expirationDate = CalendarUtil.addMonth(new Date(), coupon.getTerm());
//				}
			}
			
			if (coupon.getUserQuota() != null && domain.getUserQuota() != null) {
				if (domain.getUserQuota() < coupon.getUserQuota()) {
					domain.setUserQuota(coupon.getUserQuota());
				}
			}
			if (coupon.getStorageQuota() != null && domain.getStorageQuota() != null) {
				if (domain.getStorageQuota() < coupon.getStorageQuota()) {
					domain.setStorageQuota(coupon.getStorageQuota());
				}
			}
			if (coupon.getBoardQuota() != null && domain.getBoardQuota() != null) {
				if (domain.getBoardQuota() < coupon.getBoardQuota()) {
					domain.setBoardQuota(coupon.getBoardQuota());
				}
			}	
			
			domain.setServiceType(coupon.getServiceType());
			
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			if (coupon.getGroupQuota() != null) {
				domain.setGroupQuota(coupon.getGroupQuota());
			}
			if (coupon.getTaskQuota() != null) {
				domain.setTaskQuota(coupon.getTaskQuota());
			}
			*/
			//<-- ===== DOMAIN STATISTICS =====
			
			domain.setExpirationDate(expirationDate);
			//domain.setBlockType(DEFAULT_BLOCK_TYPE);
			//domain.setBlockReason(null);
			
			coupon.setUseYN(Y);
			coupon.setIssueYN(Y);
			coupon.setIssueDate(new Date());
			coupon.setUsedDate(new Date());
			coupon.setDomainName(domainName);
			
			doMergeTransaction(mgr, domain);
//			doMergeTransaction(mgr, domain, domainLog);
			adminService.overwriteToDefaultDomain(mgr, domain);
			updateCoupons(mgr, coupon);
			usageService.resetUsageCheckpoints(originDomain, domain);
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return coupon;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public Coupons revokeCoupon(String domainName, String couponCode) throws Exception {
		String prevNamespace = NamespaceManager.get();
		EntityManager mgr = getEntityManager();
		
		try {
			Coupons coupon = getCoupons(couponCode);
			if (coupon == null) { return null; }
			
			NamespaceManager.set(domainName);
			
			DomainsLog prevDomainLog = domainsLogService.findByRegistedCouponCode(couponCode);
			if (prevDomainLog == null) { return coupon; }
			
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			Domains originDomain = (Domains)CopyUtil.copyDeeply(domain);
			DomainsLog domainLog = new DomainsLog(originDomain, DomainsLogType.REVOKE_COUPON, couponCode);
			
			valid(domain);
			
			domain.setExpirationDate(prevDomainLog.getExpirationDate());
			domain.setBlockType(prevDomainLog.getBlockType());
			domain.setUserQuota(prevDomainLog.getUserQuota());
			domain.setStorageQuota(prevDomainLog.getStorageQuota());
			domain.setBoardQuota(prevDomainLog.getBoardQuota());
			domain.setCaseInsensitive(prevDomainLog.isCaseInsensitive());
			domain.setServiceType(prevDomainLog.getServiceType());
			
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			domain.setGroupQuota(prevDomainLog.getGroupQuota());
			domain.setTaskQuota(prevDomainLog.getTaskQuota());
			*/
			//<-- ===== DOMAIN STATISTICS =====
			
			coupon.setUseYN(N);
			coupon.setIssueYN(null);
			coupon.setUsedDate(null);
			coupon.setDomainName(null);
			
			doMergeTransaction(mgr, domain);
//			doMergeTransaction(mgr, domain, domainLog);
			adminService.overwriteToDefaultDomain(mgr, domain);
			updateCoupons(mgr, coupon);
			
			usageService.resetUsageCheckpoints(originDomain, domain);
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return coupon;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
}
