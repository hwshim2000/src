package net.forecs.coconut.endpoint.admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.code.IndexKind;
import net.forecs.coconut.common.code.Kind;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.ClassUtil;
import net.forecs.coconut.endpoint.calendar.ICalendarService;
import net.forecs.coconut.endpoint.channel.FirebaseChannel;
import net.forecs.coconut.endpoint.common.IAttachmentMapService;
import net.forecs.coconut.endpoint.common.INoticeService;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineCommentService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineService;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.AttachmentIndex;
import net.forecs.coconut.search.index.CommentIndex;
import net.forecs.coconut.search.index.EventIndex;
import net.forecs.coconut.search.index.NoticeIndex;
import net.forecs.coconut.search.index.TaskIndex;
import net.forecs.coconut.search.index.TimelineIndex;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.QueryResultList;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;


public class DataService extends AdminCommonService implements IDataService {
	private static final Logger LOG = Logger.getLogger(DataService.class.getName());
//	private static Set<String> notEMFEntities = new HashSet<String>();
//	static {
//		notEMFEntities.add(UserCounter.class.getSimpleName());
//	}
	
	private final ITaskService taskService;
	//private final IUserService userService;
	private final ITaskTimelineService taskTimelineService;
	private final INoticeService noticeService;
	private final ICalendarService calendarService;
	private final ITaskTimelineCommentService taskTimelineCommentService;
//	private final ITaskChecklistHistoryService taskChecklistHistoryService;
	private final IAttachmentMapService attachmentMapService;
//	private final IUsageService usageService;
	private final IGCSService gcsService;
	
	@Inject
	public DataService(
			ITaskService taskService, 
			//IUserService userService,
			ITaskTimelineService taskTimelineService,
			INoticeService noticeService,
			ICalendarService calendarService,
			ITaskTimelineCommentService taskTimelineCommentService,
			//ITaskChecklistHistoryService taskChecklistHistoryService,
			IAttachmentMapService attachmentMapService,
//			IUsageService usageService,
			IGCSService gcsService
			) {
		this.taskService = taskService;
		//this.userService = userService;
		this.taskTimelineService = taskTimelineService;
		this.noticeService = noticeService;
		this.calendarService = calendarService;
		this.taskTimelineCommentService = taskTimelineCommentService;
		//this.taskChecklistHistoryService = taskChecklistHistoryService;
		this.attachmentMapService = attachmentMapService;
//		this.usageService = usageService;
		this.gcsService = gcsService;
	}

	@Override
	public void removeKindData(String namespace, String kind) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		
		try {
			deleteAllObjectsUseDatastoreService(kind);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public void removeNamespace(String namespace) {
		try {
			List<String> kindList = listKinds(namespace);
		
			for (String kind : kindList) {
				removeKindData(namespace, kind);
			}
			
			removeDomainAndUserFromDefaultNamespace(namespace);
			removeNamespaceMemcache(namespace);
//			usageService.removeUsage(namespace);
			removeNamespaceIndex(namespace);
			
			// Remove all domain files
			gcsService.deleteDomainObject(namespace);
			
			// Remove all domain sync message and online user channels
			FirebaseChannel fc = FirebaseChannel.getInstance();
			fc.deleteDomainChannel(namespace);
			fc.deleteOnlineUserChannel(namespace);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void removeAllNamespace(boolean includeDefault) {
		try {
			List<String> namespaceList = listNamespaces();
			for (String namespace : namespaceList) {
				removeNamespace(namespace);
			}
			if (includeDefault) {
				removeNamespace(null);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void removeIndex(String namespace, String indexName) {
		try {
			SearchManager sm = new SearchManager(namespace);
			Class<?> indexClass = ClassUtil.findIndexClass(indexName);
			sm.deleteAllDocuments(indexClass);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void removeNamespaceIndex(String namespace) {
		try {
			SearchManager sm = new SearchManager(namespace);
			List<String> indexNameList = sm.getAllIndexNameList();
			
			for (String indexName: indexNameList) {
				Class<?> indexClass = ClassUtil.findIndexClass(indexName);
				sm.deleteAllDocuments(indexClass);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void removeIndexSchema(String namespace, String indexName) {
		try {
			SearchManager sm = new SearchManager(namespace);
			Class<?> indexClass = ClassUtil.findIndexClass(indexName);
			sm.deleteDocumentsSchema(indexClass);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void removeNamespaceIndexSchema(String namespace) {
		try {
			SearchManager sm = new SearchManager(namespace);
			List<String> indexNameList = sm.getAllIndexNameList();
			
			for (String indexName: indexNameList) {
				Class<?> indexClass = ClassUtil.findIndexClass(indexName);
				sm.deleteDocumentsSchema(indexClass);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void removeAllIndex() {
		try {
			List<String> namespaceList = listNamespaces();
			
			for (String namespace: namespaceList) {
				removeNamespaceIndex(namespace);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void recreateAllIndex() throws Exception {
		try {
			List<String> namespaceList = listNamespaces();
			
			for (String namespace: namespaceList) {
				recreateNamespaceIndex(namespace);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	@Override
	public void recreateNamespaceIndex(String namespace) throws Exception {
		try {
			for (IndexKind indexKind : IndexKind.values()) {
				switch (indexKind) {
					//case UserIndex : recreateUserIndex(namespace); break;
					case TaskIndex : recreateTaskIndex(namespace); break;
					case EventIndex : recreateEventIndex(namespace); break;
					case NoticeIndex : recreateNoticeIndex(namespace); break;
					case TimelineIndex : recreateTimelineIndex(namespace); break;
					case CommentIndex : recreateCommentIndex(namespace); break;
					//case ChecklistHistoryIndex : recreateChecklistHistoryIndex(namespace); break;
					//case ChecklistIndex : recreateChecklistIndex(namespace); break;
					case AttachmentIndex : recreateAttachmentIndex(namespace); break;
					default : break;
				}
			}
		} catch (Exception ex) { throw ex; }
	}
	
	@Override
	public void invokeRecreateAllIndex(IndexKind indexKind) {
		try {
			List<String> namespaceList = listNamespaces();
			
			for (String namespace: namespaceList) {
				invokeRecreateIndexTaskQueue(namespace, indexKind);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	@Override
	public void invokeRecreateNamespaceIndex(String namespace) {
		try {
			invokeRecreateIndexTaskQueue(namespace, null);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	@Override
	public void invokeRecreateIndex(String namespace, IndexKind indexKind) {
		try {
			invokeRecreateIndexTaskQueue(namespace, indexKind);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}

	private void invokeRecreateIndexTaskQueue(String domainName, IndexKind indexKind) {
		//--> hyeuwoo.shim 2016-02-12
		// Deadlines
		// 60-second deadline for HTTP requests,
		// 10-minute deadline for tasks Requests to backends can run indefinitely.
		// A backend can choose to handle `/_ah/start` and execute a program or script for many hours without returning an HTTP response code. 
		//<--
		Queue queue = QueueFactory.getQueue(CommonProperty.RECREATE_INDEX_QUEUE_NAME);
		TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.RECREATE_INDEX_URL);
	
		if (StringUtils.isNotBlank(domainName)) {
			taskOptions = taskOptions.param(PARAM.DOMAINNAME, domainName);
		}
		if (indexKind != null) {
			taskOptions = taskOptions.param(PARAM.KIND, indexKind.toString());
		}
		
		taskOptions = taskOptions.method(Method.POST);

		queue.add(taskOptions);
	}
	
	@Override
	public void recreateTaskIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		EntityManager mgr = getEntityManager();
		
		try {
			removeIndex(namespace, TaskIndex.class.getSimpleName());
			
			DsQuery<Tasks> dsQuery = new DsQuery<>(Tasks.class)
					.eq(FLD.deleteYN, N);
					
			List<Tasks> results = dsQuery.execute(mgr);
			for (Tasks task : results) {
				taskService.createOrUpdateTaskIndex(mgr, task);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
//	public void recreateTaskIndex20160224(String namespace) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(namespace);
//		
//		try {
//			removeIndex(namespace, TaskIndex.class.getSimpleName());
//		
//			EntityManager mgr = getEntityManager();
//			List<Tasks> taskList = null;
//			
//			try {
//				TypedQuery<Tasks> query = new QueryBuilder<>(Tasks.class).build(mgr);
//				taskList = queryResults(query);
//			} finally {
//				finalizeTransaction(mgr);
//			}
//			
//			if (taskList != null) {
//				for (Tasks task : taskList) {
//					taskService.createOrUpdateTaskIndex(task);
//				}
//			}
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
	
	/*
	@Override
	@Deprecated
	public void recreateUserIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		EntityManager mgr = getEntityManager();
		
		List<Users> userList = null;
		
		try {
			removeIndex(namespace, UserIndex.class.getSimpleName());
			
			TypedQuery<Users> query = new QueryBuilder<>(Users.class).build(mgr);
			
			userList = queryResults(query);
			
			for(Users user : userList) {
				try { userService.createOrUpdateUserIndex(user); } catch (Exception ex) { LOG.warning(ex.getMessage()); }
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finaliz
		}
	}
	*/
	
	@Override
	public void recreateTimelineIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		EntityManager mgr = getEntityManager();
		
		try {
			removeIndex(namespace, TimelineIndex.class.getSimpleName());
			
			DsQuery<TaskTimelines> dsQuery = new DsQuery<>(TaskTimelines.class)
					.eq(FLD.deleteYN, N);
			List<TaskTimelines> results = dsQuery.execute(mgr);
			for(TaskTimelines taskTimeline : results) {
				taskTimelineService.createOrUpdateTaskTimelineIndex(taskTimeline);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
//	public void recreateTimelineIndex20160224(String namespace) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(namespace);
//		
//		try {
//			removeIndex(namespace, TimelineIndex.class.getSimpleName());
//			
//			EntityManager mgr = getEntityManager();
//			List<TaskTimelines> taskTimelineList = null;
//			try {
//				TypedQuery<TaskTimelines> query = new QueryBuilder<>(TaskTimelines.class).build(mgr);
//				
//				taskTimelineList = queryResults(query);
//			} finally {
//				finalizeTransaction(mgr);
//			}
//			
//			if (taskTimelineList != null) {
//				for(TaskTimelines taskTimeline : taskTimelineList) {
//					taskTimelineService.createOrUpdateTaskTimelineIndex(taskTimeline);
//				}
//			}
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
	
	@Override
	public void recreateNoticeIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		EntityManager mgr = getEntityManager();
		
		try {
			removeIndex(namespace, NoticeIndex.class.getSimpleName());
			
			DsQuery<Notice> dsQuery = new DsQuery<>(Notice.class)
					.eq(FLD.deleteYN, N);
			List<Notice> results = dsQuery.execute(mgr);
			for(Notice notice : results) {
				noticeService.createOrUpdateNoticeIndex(notice);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
//	public void recreateNoticeIndex20160224(String namespace) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(namespace);
//		
//		try {
//			removeIndex(namespace, NoticeIndex.class.getSimpleName());
//			
//			EntityManager mgr = getEntityManager();
//			List<Notice> noticeList = null;
//			try {
//				TypedQuery<Notice> query = new QueryBuilder<>(Notice.class).build(mgr);
//				
//				noticeList = queryResults(query);
//			} finally {
//				finalizeTransaction(mgr);
//			}
//			
//			if (noticeList != null) {
//				for(Notice notice : noticeList) {
//					noticeService.createOrUpdateNoticeIndex(notice);
//				}
//			}
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
	
	@Override
	public void recreateEventIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		EntityManager mgr = getEntityManager();
		
		try {
			removeIndex(namespace, EventIndex.class.getSimpleName());
			
			DsQuery<Events> dsQuery = new DsQuery<>(Events.class)
					.eq(FLD.deleteYN, N);
			List<Events> results = dsQuery.execute(mgr);
			for(Events event : results) {
				calendarService.createOrUpdateEventIndex(event);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
//	public void recreateEventIndex20160224(String namespace) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(namespace);
//		
//		try {
//			removeIndex(namespace, EventIndex.class.getSimpleName());
//			
//			EntityManager mgr = getEntityManager();
//			List<Events> eventList = null;
//			try {
//				TypedQuery<Events> query = new QueryBuilder<>(Events.class).build(mgr);
//				
//				eventList = queryResults(query);
//			} finally {
//				finalizeTransaction(mgr);
//			}
//			
//			if (eventList != null) {
//				for(Events event : eventList) {
//					calendarService.createOrUpdateEventIndex(event);
//				}
//			}
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}

	/*
	@Override
	@Deprecated
	public void recreateChecklistIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		
		try {
			removeIndex(namespace, ChecklistIndex.class.getSimpleName());
			
			EntityManager mgr = getEntityManager();
			List<TaskChecklists> checklist = null;
			try {
				TypedQuery<TaskChecklists> query = new QueryBuilder<>(TaskChecklists.class).build(mgr);
				checklist = queryResults(query);
			} finally {
				finalizeTransaction(mgr);
			}
			
			if (checklist != null) {
				for(TaskChecklists list : checklist) {
					try { taskService.createOrUpdateTaskIndex(list.getTaskId()); } catch (Exception ex) { LOG.warning(ex.getMessage()); }
				}
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	*/
	
	@Override
	public void recreateCommentIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		EntityManager mgr = getEntityManager();
		
		try {
			removeIndex(namespace, CommentIndex.class.getSimpleName());
			
			DsQuery<TaskTimelineComments> dsQuery = new DsQuery<>(TaskTimelineComments.class)
					.eq(FLD.deleteYN, N);
			List<TaskTimelineComments> results = dsQuery.execute(mgr);
			for(TaskTimelineComments timelineComment : results) {
				taskTimelineCommentService.createOrUpdateTaskTimelineCommentIndex(timelineComment);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public void recreateAttachmentIndex(String namespace) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		EntityManager mgr = getEntityManager();
		
		try {
			removeIndex(namespace, AttachmentIndex.class.getSimpleName());
			String cursorString = null;
			Integer limit = 1000;
			while(true) {
				DsQuery<AttachmentsMap> dsQuery = new DsQuery<>(AttachmentsMap.class);
				List<AttachmentsMap> results = dsQuery.cursor(cursorString).limit(limit).execute(mgr);
				
				for(AttachmentsMap attachmentMap : results) {
					attachmentMapService.createOrUpdateAttachmentIndex(attachmentMap);
				}
				cursorString = dsQuery.getCursor();
				if (results == null || results.size() == 0 || results.size() < limit) { break; }
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
//	public void recreateAttachmentIndex(String namespace) {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(namespace);
//		try {
//			removeIndex(namespace, AttachmentIndex.class.getSimpleName());
//			
//			EntityManager mgr = getEntityManager();
//			List<AttachmentsMap> attachmentMapList = null;
//			try {
//				TypedQuery<AttachmentsMap> query = new QueryBuilder<>(AttachmentsMap.class)
//						.addClause(FLD.archiveYN, null)
//						.build(mgr);
//				
//				attachmentMapList = queryResults(query);
//			} finally {
//				finalizeTransaction(mgr);
//			}
//			
//			if (attachmentMapList != null) {
//				for(AttachmentsMap attachmentMap : attachmentMapList) {
//					attachmentMapService.createOrUpdateAttachmentIndex(attachmentMap);
//				}
//			}
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
	
	@Override
	public Map<String, List<String>> findUnavailableAllNamespaceData(String namespace, boolean remove) throws Exception {
		Map<String, List<String>> unavailableMap = new HashMap<String, List<String>>();
		
		for (Kind kind : Kind.values()) {
			List<String> unavailableList = findUnavailableNamspaceData(namespace, kind, remove);
			unavailableMap.put(kind.toString(), unavailableList);
		}
		
		return unavailableMap;
	}
	
	@Override
	public List<String> findUnavailableNamspaceData(String namespace, Kind kind, boolean remove) throws Exception {
		if (ClassUtil.findKIndClass(kind.toString())== null) { return null; }
		
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		
		Set<String> keyIds = new HashSet<String>();
		List<String> invalidList = new ArrayList<String>();
		
		final int limit = 1000;
		
		keyIds.add(FLD.activityId);
		keyIds.add(FLD.attachmentId);
//		keyIds.add(FLD.backupId);
//		keyIds.add(FLD.billId);
		keyIds.add(FLD.boardId);
//		keyIds.add(FLD.boardInviteId);
//		keyIds.add(FLD.boardLinkId);
//		keyIds.add(FLD.calendarId);
//		keyIds.add(FLD.channelTokenId);
		keyIds.add(FLD.checklistId);
//		keyIds.add(FLD.commentId);
		keyIds.add(FLD.couponId);
		keyIds.add(FLD.domainId);
//		keyIds.add(FLD.domainsLogId);
//		keyIds.add(FLD.eventGroupId);
//		keyIds.add(FLD.eventId);
//		keyIds.add(FLD.familyId);
//		keyIds.add(FLD.feeId);
		keyIds.add(FLD.groupId);
//		keyIds.add(FLD.guestId);
//		keyIds.add(FLD.imageId);
		keyIds.add(FLD.kindId);
//		keyIds.add(FLD.memberAuthId);
//		keyIds.add(FLD.noticeCommentId);
		keyIds.add(FLD.noticeId);
//		keyIds.add(FLD.notificationId);
//		keyIds.add(FLD.notificationSettingId);
		keyIds.add(FLD.objectId);
//		keyIds.add(FLD.parentId);
		keyIds.add(FLD.restoreRequestUserId);
//		keyIds.add(FLD.subscriptionId);
//		keyIds.add(FLD.taskChecklistCommentId);
//		keyIds.add(FLD.taskChecklistHistoryId);
		keyIds.add(FLD.taskChecklistId);
//		keyIds.add(FLD.taskCommentId);
//		keyIds.add(FLD.taskHistoryId);
		keyIds.add(FLD.taskId);
		keyIds.add(FLD.taskLabelId);
//		keyIds.add(FLD.taskTimelineCommentId);
		keyIds.add(FLD.taskTimelineId);
//		keyIds.add(FLD.taskTimelineScoreId);
		keyIds.add(FLD.tasklistId);
//		keyIds.add(FLD.usageId);
//		keyIds.add(FLD.usageLogId);
//		keyIds.add(FLD.userDeviceId);
		keyIds.add(FLD.userId);
//		keyIds.add(FLD.userProfileId);
		keyIds.add(FLD.wikiLockUserId);
		keyIds.add(FLD.creator);
		keyIds.add(FLD.owner);
		
//		String domainId = (String)entity.getProperty(FLD.domainId);
//		String boardId = (String)entity.getProperty(FLD.boardId);
//		String groupId = (String)entity.getProperty(FLD.groupId);
//		String tasklistId = (String)entity.getProperty(FLD.tasklistId);
//		String taskId = (String)entity.getProperty(FLD.taskId);
//		String taskTimelineId = (String)entity.getProperty(FLD.taskTimelineId);
//		String taskTimelineCommentId = (String)entity.getProperty(FLD.taskTimelineCommentId);
//		String taskChecklistId = (String)entity.getProperty(FLD.taskChecklistId);
//		String taskChecklistCommentId = (String)entity.getProperty(FLD.taskChecklistCommentId);
//		String taskCommentId = (String)entity.getProperty(FLD.taskCommentId);
//		
//		String eventId = (String)entity.getProperty(FLD.eventId);
//		String noticeId = (String)entity.getProperty(FLD.noticeId);
//		String noticeCommentId = (String)entity.getProperty(FLD.noticeCommentId);
//		String taskLabelId = (String)entity.getProperty(FLD.taskLabelId);
//		String attachmentId = (String)entity.getProperty(FLD.attachmentId);
//		String imageId = (String)entity.getProperty(FLD.imageId);
//		String userId = (String)entity.getProperty(FLD.userId);
//		String owner = (String)entity.getProperty(FLD.owner);
//		String activityId = (String)entity.getProperty(FLD.activityId);
//		String notificationId = (String)entity.getProperty(FLD.notificationId);
//		String boardInviteId = (String)entity.getProperty(FLD.boardInviteId);
//		String channelTokenId = (String)entity.getProperty(FLD.channelTokenId);
//		String memberAuthId = (String)entity.getProperty(FLD.memberAuthId);
//		String notificationSettingId = (String)entity.getProperty(FLD.notificationSettingId);
//		//String userSettingId = (String)entity.getProperty(FLD.userSettingId);
//		String subscriptionId = (String)entity.getProperty(FLD.subscriptionId);
//		String userDeviceId = (String)entity.getProperty(FLD.userDeviceId);
//		String userProfileId = (String)entity.getProperty(FLD.userProfileId);
		
		try {
			final DatastoreService dss = DatastoreServiceFactory.getDatastoreService();
			final Query query = new Query(kind.toString());

			String startCursor = null;
			
			PreparedQuery pq = dss.prepare(query);
			
			while(true) {
				FetchOptions fetchOptions = FetchOptions.Builder.withLimit(limit);
				if (startCursor != null) {
			      fetchOptions.startCursor(Cursor.fromWebSafeString(startCursor));
			    }
			    QueryResultList<Entity> results = pq.asQueryResultList(fetchOptions);
			    
			    startCursor = results.getCursor().toWebSafeString();
			    
	//			query.setKeysOnly();
				//Iterable<Entity> iterEntities = dss.prepare(query).asIterable(FetchOptions.Builder.withLimit(1000));
				for (Entity entity : results) {
					Map<String, Object> props = entity.getProperties();
					List<String> invalidProps = new ArrayList<String>();
					for(Map.Entry<String, Object> entry : props.entrySet()) {
						if (keyIds.contains(entry.getKey())) {
							String keyStr = (String)entry.getValue();
							if (StringUtils.isNotBlank(keyStr)) {
								Key key = KeyFactory.stringToKey(keyStr);
								if (!StringUtils.equals(namespace, key.getNamespace())) {
									invalidProps.add(String.format("[%s/%s/%s]",key.getNamespace(), entry.getKey(), keyStr));
								}
							}
						}
					}
					if (invalidProps.size() > 0) {
						String invalidProperty = String.format("[%s/%s/%s] --> %s", namespace, kind, KeyFactory.keyToString(entity.getKey()), StringUtils.join(invalidProps, ","));
						invalidList.add(invalidProperty);
						if (remove) { dss.delete(entity.getKey()); }
//						LOG.warning(invalidProperty);
					}
				}
				if (results == null || results.size() == 0 || results.size() != limit) { break; }
			}
			return invalidList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public Map<String, String> removeUnavailableNamspaceData(String namespace, List<String> keys) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		
		Map<String, String> removeResults = new HashMap<String, String>();
		
		Map<String, String> indexMap = new HashMap<String, String>();
		indexMap.put(TaskTimelines.class.getSimpleName(), TimelineIndex.class.getSimpleName());
		indexMap.put(Attachments.class.getSimpleName(), AttachmentIndex.class.getSimpleName());
//		indexMap.put(TaskChecklistHistories.class.getSimpleName(), ChecklistHistoryIndex.class.getSimpleName());
//		indexMap.put(TaskChecklists.class.getSimpleName(), ChecklistIndex.class.getSimpleName());
		indexMap.put(Events.class.getSimpleName(), EventIndex.class.getSimpleName());
		indexMap.put(Notice.class.getSimpleName(), NoticeIndex.class.getSimpleName());
		indexMap.put(Tasks.class.getSimpleName(), TaskIndex.class.getSimpleName());
//		indexMap.put(TaskComments.class.getSimpleName(), CommentIndex.class.getSimpleName());
		indexMap.put(TaskTimelineComments.class.getSimpleName(), CommentIndex.class.getSimpleName());
//		indexMap.put(TaskChecklistComments.class.getSimpleName(), CommentIndex.class.getSimpleName());
//		indexMap.put(Users.class.getSimpleName(), UserIndex.class.getSimpleName());
		
		try {
			final DatastoreService dss = DatastoreServiceFactory.getDatastoreService();
			final SearchManager sm = new SearchManager();
			
			List<Key> keyList = new ArrayList<Key>();
			for (String keyStr : keys) {
				LOG.warning("removing... " + keyStr);
				try {
					Key key = KeyFactory.stringToKey(keyStr);
					dss.get(key);
					String kind = key.getKind();
					keyList.add(key);
					
	//				Class<?> cls = ClassUtil.findKIndClass(kind);
					
					String indexName = indexMap.get(kind);
					if (StringUtils.isNotBlank(indexName)) {
						sm.deleteDocuments(indexName, keyStr);
					}
					dss.delete(key);
				} catch (EntityNotFoundException ex) {
					LOG.warning("KEY(" + keyStr + ") : " + ex.getMessage());
					removeResults.put(keyStr, ex.getMessage());
					continue;
				} catch (Exception ex) {
					removeResults.put(keyStr, ex.getMessage());
					LOG.warning("KEY(" + keyStr + ") : " + ex.getMessage());
					continue;
				}
				
				removeResults.put(keyStr, "Removed");
			}
//			dss.delete(keyList);
			
			return removeResults;
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public List<Entity> getEntity(String namespace, List<String> keys) throws EntityNotFoundException {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(namespace);
		List<Entity> entities = new ArrayList<Entity>();
		try {
			final DatastoreService dss = DatastoreServiceFactory.getDatastoreService();
			for (String keyStr : keys) {
				Key key = KeyFactory.stringToKey(keyStr);
				entities.add(dss.get(key));
			}
			return entities;
		} catch (EntityNotFoundException ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
}
