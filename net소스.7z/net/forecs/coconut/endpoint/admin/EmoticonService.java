package net.forecs.coconut.endpoint.admin;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.rest.ApacheHttpClient;
import net.forecs.coconut.endpoint.common.AttachmentService.GcsSignedUrlUtil;
import net.forecs.coconut.endpoint.common.IImageService;
import net.forecs.coconut.endpoint.common.ImageService;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.attachment.Uploads;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;

public class EmoticonService extends AdminCommonService implements IEmoticonService {
	private static final Logger LOG = Logger.getLogger(EmoticonService.class.getName());
	private final IImageService imageService;
	
	@Inject
	public EmoticonService(IImageService imageService) {
		this.imageService = imageService;
	}
	
	@Override
	public String getEmoticonUploadUrl(String filePath, String contentType, Integer expiresIn) throws Exception {
		//filePath = StringUtils.stripStart(filePath, "/");
		//String domainName = NamespaceManager.get();
		//if (StringUtils.isEmpty(domainName)) {
		//	objectName = filePath;
		//} else {
		//	objectName = domainName + "/" + filePath;
		//}
		String objectName = filePath;

		GcsSignedUrlUtil gcsUtils = new GcsSignedUrlUtil(GcsSignedUrlUtil.EMOTICONS_SITE);
		String uploadUrl = gcsUtils.getUploadUrl(objectName, contentType, expiresIn);
		
		standbyUploadingFile(filePath);
		
		return uploadUrl;
	}
	
	@Override
	public QueryResult<Emoticons> queryEmoticons(
				String cursorString,
				Integer limit,
				String domainName,
				SortType sortType,
				SortDirection sortDirection) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			List<String> domainNames = new ArrayList<String>();
			domainNames.add("COMMON");
			if (StringUtils.isNotBlank(domainName)) { domainNames.add(domainName); }
			
			DsQuery<Emoticons> dsQuery = new DsQuery<>(Emoticons.class)
					.eq(FLD.deleteYN, N)
					.in(FLD.domainName, domainNames)
					.sort(sortType != null ? sortType.toString() : null, sortDirection)
					.cursor(cursorString)
					.limit(limit);
			
			List<Emoticons> results = dsQuery.execute(mgr);
			
//			List<String> emoticonIds = new ArrayList<String>();
//			for (Emoticons emoticon : results) {
//				emoticonIds.add(emoticon.getEmoticonId());
//			}
//			
//			Map<String, List<Images>> imagesMap = imageService.batchMapChildImages(mgr, emoticonIds);
//			for (Emoticons emoticon : results) {
//				emoticon.setImages(imagesMap.get(emoticon.getEmoticonId()));
//			} 
			
			return new QueryResult<Emoticons>(results, dsQuery.getCursor());
			
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Emoticons getEmoticons(String emoticonId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Emoticons emoticons = doFind(mgr, Emoticons.class, emoticonId);
//			List<Images> images = imageService.batchListChildImages(mgr, emoticonId);
//			emoticons.setImages(images);
			return emoticons;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public List<Emoticons> listEmoticons(List<String> emoticonIds) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		try {
			List<Emoticons> emoticons = batchListByKey(Emoticons.class, emoticonIds);
			return emoticons;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	
	@Override
	public Emoticons insertEmoticons(Emoticons emoticons) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			emoticons.setCreator(CommonProperty.SYSTEM_USER_ID);
			emoticons.setKey(KeyUtil.createEmoticonKey());
			if (StringUtils.isBlank(emoticons.getDomainName())) { emoticons.setDomainName("COMMON"); }
			
			if (contains(mgr, Emoticons.class, emoticons.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(Emoticons.class, emoticons.getEmoticonId()));
			}
			
			setEmoticonServingUrls(emoticons);
			doPersistTransaction(mgr, emoticons);
			
			return emoticons;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Emoticons updateEmoticons(Emoticons emoticons) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			valid(emoticons);
			setEmoticonServingUrls(emoticons);
			
			beginTransaction(mgr);
		//	List<Images> images = emoticons.getImages();
			emoticons = doMerge(mgr, emoticons);
			commitTransaction(mgr);
			
		//	emoticons.setImages(images);
			
			return emoticons;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void removeEmoticons(String emoticonId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		try {
			Emoticons emoticon = doFind(mgr, Emoticons.class, emoticonId);
			valid(emoticon);

			emoticon.setDeleteYN(Y);
			emoticon.setDeleted(new Date());

			doMergeTransaction(mgr, emoticon);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	/**
	 * @deprecated
	 * 개발 서버의 환경에서는 파일을 GCS로 저장을 시킬 수는 있지만, 이미지 관련 서비스는 개발 환경에서 제공되지 않는다.
	 * 운영중인 서버(serviceHost)를 활용하여, 이미지 정보를 분석하고, 분석된 정보를 db에 저장하는 임시 API
	 */
	@Deprecated
	@Override
	public List<Images> insertEmoticonImagesFromGCS(Emoticons emoticons,
			String serviceHost, String bucket, String filePath,
			List<String> fileNames, int imageSize) throws Exception {
		emoticons = insertEmoticons(emoticons);
		return appendEmoticonImagesFromGCS(emoticons.getEmoticonId(), serviceHost, bucket, filePath, fileNames, imageSize);
	}
	
	
	/**
	 * @deprecated
	 * 개발 서버의 환경에서는 파일을 GCS로 저장을 시킬 수는 있지만, 이미지 관련 서비스는 개발 환경에서 제공되지 않는다.
	 * 운영중인 서버(serviceHost)를 활용하여, 이미지 정보를 분석하고, 분석된 정보를 db에 저장하는 임시 API
	 */
	@Deprecated
	@Override
	public List<Images> appendEmoticonImagesFromGCS(String emoticonId,
			String serviceHost, String bucket, String filePath,
			List<String> fileNames, int imageSize) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			List<Images> images = new ArrayList<Images>();
			//String url = "https://performance-dot-cocoworks-for-ecs.appspot.com"+CommonProperty.IMAGE_INFO_URL;
			if (StringUtils.isBlank(serviceHost)) { serviceHost = "https://performance-dot-cocoworks-for-ecs.appspot.com"; }
			String url = serviceHost + CommonProperty.IMAGE_INFO_URL;
			
			ObjectMapper mapper = new ObjectMapper();

			for (String fileName : fileNames) {
				String filePathName = filePath + "/" + fileName;
				Map<String, String> entityMap = new HashMap<String, String>();
				entityMap.put(FLD.filePath, filePathName);
				entityMap.put(FLD.bucket, bucket);
				entityMap.put(FLD.imageSize, String.valueOf(imageSize));
				entityMap.put(FLD.secretKey, ImageService.SECRET_KEY);
				
//				url += "?" + FLD.bucket +"=" + URLEncoder.encode(bucket, CommonProperty.UTF_8);
//				url += "&" + FLD.filePath +"=" + URLEncoder.encode(filePath, CommonProperty.UTF_8);
//				url += "&" + FLD.imageSize +"=" + imageSize;
//				url += "&" + FLD.secretKey +"=" + SECRET_KEY;
				
				String result = ApacheHttpClient.postToAppengine(url, null, entityMap);
				Map<String, String> map = mapper.readValue(result, new TypeReference<Map<String, String>>(){});
				
				Images image = new Images();
				image.setBucket(bucket);
				image.setParentId(emoticonId);
				image.setFilePath(filePathName);
				image.setMimeType(map.get(FLD.mimeType));
				image.setFileSize(Long.valueOf(map.get(FLD.fileSize)));
				image.setServingUrl(map.get(FLD.servingUrl));
				image.setImageSize(imageSize);
				image.setCreator(CommonProperty.SYSTEM_USER_ID);
				
				image = insertOrUpdateEmoticonImageFromGCS(mgr, image);
				images.add(image);
			}
			return images;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Deprecated
	private Images insertOrUpdateEmoticonImageFromGCS(EntityManager mgr, Images image) throws Exception {
		try {
			Key key = KeyUtil.createImageKey(image);

			String filePath = image.getFilePath();
			image.setKey(key);
			
			if (StringUtils.isNotBlank(filePath)) {
				String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
				image.setFileName(fileName);
			}
			
			if (contains(mgr, Images.class, image.getKey())) {
				doMergeTransaction(mgr, image);
			} else {
				doPersistTransaction(mgr, image);
			}
			
			return image;
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	
	private void setEmoticonServingUrls(Emoticons emoticon) throws Exception {
		try {
			List<Images> images = emoticon.getImages();
			for (Images image : images) {
				if (StringUtils.isBlank(image.getServingUrl())) {
					String filePath = image.getFilePath();

					if (StringUtils.isNotBlank(filePath)) {
						String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
						image.setFileName(fileName);
					}
					if (MainModule.developmentServer) {
						image.setServingUrl(getServingUrlForDev(image));
					} else {
						image.setServingUrl(getServingUrl(image));
					}
					
					completeUploadedFile(filePath);
				}
			}
			emoticon.setImages(images);
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Deprecated
	private String getServingUrlForDev(Images image) {
		String bucketName = image.getBucket();
		if (StringUtils.isBlank(bucketName)) { image.setBucket(GcsSignedUrlUtil.EMOTICON_BUCKET_NAME); }
		return imageService.getServingUrlForDev(image);
	}
	
	private String getServingUrl(Images image) {
		String bucketName = image.getBucket();
		if (StringUtils.isBlank(bucketName)) { bucketName =  GcsSignedUrlUtil.EMOTICON_BUCKET_NAME; }
		return imageService.getServingUrl(bucketName, image.getFilePath(), image.getImageSize());
 	}
	
	private void standbyUploadingFile(String filePath) {
		if (StringUtils.isBlank(filePath)) { return; }
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			filePath = GcsSignedUrlUtil.EMOTICON_BUCKET_NAME + "/" + filePath;
			String uploadPath = URLDecoder.decode(filePath, CommonProperty.UTF_8);
			Key key = KeyUtil.createUploadKey(uploadPath);
			Uploads upload = new Uploads();
			upload.setKey(key);
			upload.setFilePath(filePath);
			
			doPersistTransaction(mgr, upload);
		} catch (Exception e) {
			LOG.warning("Upload standby error : " + e.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	private void completeUploadedFile(String filePath) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
	
		filePath = GcsSignedUrlUtil.EMOTICON_BUCKET_NAME + "/" + filePath;
		try {
			String uploadPath = URLDecoder.decode(filePath, CommonProperty.UTF_8);
			Key key = KeyUtil.createUploadKey(uploadPath);
			
			doRemoveTransaction(mgr, Uploads.class, key);
			//removeTrashUploads(mgr, CalendarUtil.addDay(new Date(), -1));
		} catch (Exception e) {
			LOG.warning("Upload complete error : " + e.getMessage());
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	// TODO : 이모티콘 이미지 지우는건 보류
	@SuppressWarnings("unused")
	private void deleteEmoticonGcsFile(String filePath) {
		try {
			GcsSignedUrlUtil gcsUtils = new GcsSignedUrlUtil(GcsSignedUrlUtil.EMOTICONS_SITE);
			String deleteUrl = gcsUtils.getSignedUrl("DELETE", filePath, null, null);
			LOG.info("DELETE Request URL : " + deleteUrl);
			URL url = new URL(deleteUrl);
			HttpURLConnection connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod("DELETE");
			int statusCode = connection.getResponseCode();
			LOG.info("DELETE Response code : " + statusCode);
			// TODO : Handle status code
			if (300 <= statusCode) {
				//renderResponse(connection.getInputStream());
			}
			connection.disconnect();
		} catch (Exception e) {
			// TODO : Handle exceptions
			LOG.warning("Exception while deleting the file : " + e);
		}
	}
}
