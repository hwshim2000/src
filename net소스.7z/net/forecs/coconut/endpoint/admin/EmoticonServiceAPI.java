package net.forecs.coconut.endpoint.admin;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class EmoticonServiceAPI {
	private final IEmoticonService emoticonService;
	
	@Inject
	public EmoticonServiceAPI(IEmoticonService emoticonService) {
		this.emoticonService = emoticonService;
	}
	// ------------- Current service ----------------
	@ApiMethod(name = "getEmoticonUploadUrl", path = "emoticons/uploadUrl", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Result getEmoticonUploadUrl(@Named(FLD.filePath) String filePath,
			@Nullable @Named(FLD.contentType) String contentType,
			@Nullable @Named(FLD.expiresIn) Integer expiresIn) throws Exception {
		return new Result(emoticonService.getEmoticonUploadUrl(filePath, contentType, expiresIn));
	}
		
	@ApiMethod(name = "queryEmoticons", path = "emoticons", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Emoticons> queryEmoticons(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.sortType) SortType sortType,
			@Nullable @Named(FLD.sortDirection) SortDirection sortDirection,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Emoticons> result = emoticonService.queryEmoticons(cursorString, limit, domainName, sortType, sortDirection);
		return CollectionResponse.<Emoticons>builder().setItems(result.getResultList()).setNextPageToken(result.getNextPageToken()).build();
	}
	
	@ApiMethod(name = "getEmoticons", path = "emoticons/{emoticonId}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Emoticons getEmoticons(@Named(FLD.emoticonId) String emoticonId, @Named(FLD.accessToken) String accessToken) throws Exception {
		return emoticonService.getEmoticons(emoticonId);
	}
	
	@ApiMethod(name = "listEmoticons", path = "emoticons/list", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<Emoticons> listEmoticons(@Named(FLD.emoticonId) List<String> emoticonIds, @Named(FLD.accessToken) String accessToken) throws Exception {
		return emoticonService.listEmoticons(emoticonIds);
	}
	
	@ApiMethod(name = "insertEmoticons", path = "emoticons", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Emoticons insertEmoticons(Emoticons emoticons, @Named(FLD.accessToken) String accessToken) throws Exception {
		return emoticonService.insertEmoticons(emoticons);
	}

	@ApiMethod(name = "updateEmoticons", path = "emoticons", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Emoticons updateEmoticons(Emoticons emoticons, @Named(FLD.accessToken) String accessToken) throws Exception {
		return emoticonService.updateEmoticons(emoticons);
	}
	
	@ApiMethod(name = "removeEmoticons", path = "emoticons/{emoticonId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeEmoticons(@Named(FLD.emoticonId) String emoticonId, @Named(FLD.accessToken) String accessToken) throws Exception {
		emoticonService.removeEmoticons(emoticonId);
	}
	
	@ApiMethod(name = "insertEmoticonImagesFromGCS", path = "emoticons/images/fromGcs", httpMethod = HttpMethod.POST)
	@Deprecated
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<Images> insertEmoticonImagesFromGCS(
			@Named(FLD.title) String title,
			@Nullable @Named(FLD.serviceLevel) String serviceLevel,
			@Nullable @Named(FLD.expirationDate) Date expirationDate,
			@Nullable @Named(FLD.domainName) String domainName,
//			Emoticons emoticons,
			@Nullable @Named(FLD.serviceHost) String serviceHost,
			@Named(FLD.bucket) String bucket,
			@Named(FLD.filePath) String filePath,
			@Named(FLD.fileName) List<String> fileNames,
			@Named(FLD.imageSize) int imageSize,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		Emoticons emoticons = new Emoticons(title, serviceLevel, expirationDate);
		emoticons.setDomainName(domainName);
		return emoticonService.insertEmoticonImagesFromGCS(emoticons, serviceHost, bucket, filePath, fileNames, imageSize);
	}
	@ApiMethod(name = "appendEmoticonImagesFromGCS", path = "emoticons/images/fromGcs", httpMethod = HttpMethod.PUT)
	@Deprecated
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<Images> appendEmoticonImagesFromGCS(
			@Named(FLD.emoticonId) String emoticonId,
			@Nullable @Named(FLD.serviceHost) String serviceHost,
			@Named(FLD.bucket) String bucket,
			@Named(FLD.filePath) String filePath,
			@Named(FLD.fileName) List<String> fileNames,
			@Named(FLD.imageSize) int imageSize,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return emoticonService.appendEmoticonImagesFromGCS(emoticonId, serviceHost, bucket, filePath, fileNames, imageSize);
	}
}
