package net.forecs.coconut.endpoint.admin;

import java.util.Date;

import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.domain.Domains;

/**
 * @Project    : coconut
 * @Package    : net.forecs.coconut.endpoint.admin
 * @FileName   : IUsageService.java
 * @Date       : 2015. 3. 27.
 * @Author     : hyeunwoo.shim@forecs.net
 * @Version    :
 * @Histories  :
 * @Description: 사용량 체크 및 서비스 차단 관련 서비스 인터페이스
 */
public interface IUsageService extends IAdminCommonService {
	public abstract void surveyUsage();
	public abstract void surveyUsage(String domainName);
	//public abstract Usage getDomainUsage(String domainName) throws Exception;
	public abstract Usage resetUsageCheckpoints(Domains originDomain, Domains domain);
	public abstract Usage resetUsageCheckpoints(String domainName,
			boolean resetExpireCheckpoint,
			boolean resetUserCheckpoint,
			boolean resetStorageCheckpoint,
			boolean resetBoardCheckpoint
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			, boolean resetGroupCheckpoint,
			boolean resetTaskCheckpoint
			*/
			//<-- ===== DOMAIN STATISTICS =====
			) throws Exception;
	public abstract void removeUsage(String domainName) throws Exception;
	public abstract void removeAllUsage () throws Exception;
	public abstract void removeUsageLog(String domainName) throws Exception;
	public abstract void removeAllUsageLog() throws Exception;
	public abstract void removeUsageLogByDate(Date created) throws Exception;
	
	public abstract QueryResult<Usage> listUsages(String cursorString, Integer limit) throws Exception;
	
	public abstract QueryResult<UsageLogs> queryUsageLogs(
			String cursorString,
			Integer limit,
			String domainName,
			Frequency frequency,
			Date startDate,
			Date endDate) throws Exception;
}
