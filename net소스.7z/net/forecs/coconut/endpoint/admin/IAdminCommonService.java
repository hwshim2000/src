package net.forecs.coconut.endpoint.admin;

import net.forecs.coconut.endpoint.common.ICommonService;

public interface IAdminCommonService extends ICommonService {

}
