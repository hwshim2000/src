package net.forecs.coconut.endpoint.admin;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.backup.Backups;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class BackupServiceAPI {
	private final IBackupService backupService;
	
	@Inject
	public BackupServiceAPI(IBackupService backupService) {
		this.backupService = backupService;
	}

	@ApiMethod(name = "dataBackupToGCS", path = "backups/domains/{domainName}", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void dataBackupToGCS(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		backupService.dataBackupToGCS(domainName);
	}
	
	@ApiMethod(name = "listBackups", path = "backups", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Backups> listBackups(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.startDate) Date startDate,
			@Nullable @Named(FLD.endDate) Date endDate,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Backups> queryResult =  backupService.listBackups(cursorString, limit, domainName, startDate, endDate);
		List<Backups> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Backups>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "getBackups", path = "backups/{backupId}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Backups getBackups(@Named(FLD.backupId) String backupId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return backupService.getBackups(backupId);
	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "insertBackups",
//			scopes = {CommonProperty.EMAIL_SCOPE, CalendarScopes.CALENDAR },
//		    clientIds = {CommonProperty.WEB_CLIENT_ID,
//			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	@Deprecated
//	public Backups insertBackups(Backups backup, User user) throws Exception {
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		return backupService.insertBackups(backup);
//	}
	
	@ApiMethod(name = "updateBackups", path = "backups", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Backups updateBackups(
			Backups backup,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return backupService.updateBackups(backup);
	}
	
	@ApiMethod(name = "removeBackups", path = "backups/{backupId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeBackups(
			@Named(FLD.backupId) String backupId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		backupService.removeBackups(backupId);
	}
}
