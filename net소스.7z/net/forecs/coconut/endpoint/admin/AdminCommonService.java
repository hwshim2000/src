package net.forecs.coconut.endpoint.admin;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskLabelMap;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;

import com.google.api.server.spi.response.UnauthorizedException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;
import com.google.appengine.api.users.User;

public class AdminCommonService extends CommonService implements IAdminCommonService {
	private static final Logger LOG = Logger.getLogger(AdminCommonService.class.getName());
	private static final int dataFetchSize = 1000000;
	
	private static final Set<String> authEmails;
	static {
		authEmails = new HashSet<String>();
		authEmails.add("example@example.com");
		authEmails.add("hyeunwoo.shim@forecs.net");
		authEmails.add("gcp-admin@forecs.net");
		authEmails.add("chulhong.kim@forecs.net");
		authEmails.add("noreply@cocoworks.net");
	}
	public final static String secCode = "gkaqnfhtlfgodgkwlaktldh-wndlsqor-"; // 함부로실행하지마시오-주인백-
	protected static void deleteAllObjectsUseDatastoreService(String kind) {
		try {
			final DatastoreService dss = DatastoreServiceFactory.getDatastoreService();
			final Query query = new Query(kind);
			query.setKeysOnly();
			final ArrayList<Key> keys = new ArrayList<Key>();
			for (final Entity entity : dss.prepare(query).asIterable(FetchOptions.Builder.withLimit(dataFetchSize))) {
				keys.add(entity.getKey());
			}
			dss.delete(keys);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	public static Domains removeDomainAndUserFromDefaultNamespace(String domainName) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
				
		try {
			
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			if (domain != null) {
				doRemoveTransaction(mgr, Users.class, domain.getCreator());
				doRemoveTransaction(mgr, domain);
			}
			
			return domain;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	public static void removeNamespaceMemcache(String namespace) {
		MemcacheManager.removeAllMemcache(MemberAuths.class, null, namespace);
		MemcacheManager.removeAllMemcache(Events.class, null, namespace);
		MemcacheManager.removeAllMemcache(Events.class, EventType.PRIVATE_ANNIVERSARY.toString(), namespace);
		MemcacheManager.removeAllMemcache(Events.class, EventType.SYSTEM_HOLIDAY.toString(), namespace);
//		MemcacheManager.removeAllMemcache(Notice.class, null, namespace);
		MemcacheManager.removeAllMemcache(Tasks.class, null, namespace);
		MemcacheManager.removeAllMemcache(TaskTimelines.class, null, namespace);
		MemcacheManager.removeAllMemcache(TaskTimelineComments.class, null, namespace);
//		MemcacheManager.removeAllMemcache(TaskComments.class, null, namespace);				// deprecated
//		MemcacheManager.removeAllMemcache(TaskChecklistComments.class, null, namespace);	// deprecated
//		MemcacheManager.removeAllMemcache(TaskChecklists.class, null, namespace);
		MemcacheManager.removeAllMemcache(UserProfiles.class, null, namespace);
		MemcacheManager.removeAllMemcache(TaskChecklists.class, null, namespace);
		MemcacheManager.removeAllMemcache(TaskLabelMap.class, null, namespace);
		MemcacheManager.removeAllMemcache(AttachmentsMap.class, null, namespace);
	}
	
	public static void clearAllMemcache() {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService();
		mcs.clearAll();
	}
	
	public static void validGAuthUser(User user) throws Exception{
		if (user == null) throw new UnauthorizedException("Can not found user information.");
		if (!authEmails.contains(user.getEmail())) throw new UnauthorizedException("User is not valid.");  
	}
	
	
	/*public static QueryResult<AdminEMailNotice> listAdminEMailNotice(
			String cursorString,
			Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);

		EntityManager mgr = getEntityManager();
		
		try {
			return listAdminEMailNotice(mgr, cursorString, limit);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	public static QueryResult<AdminEMailNotice> listAdminEMailNotice(EntityManager mgr,
			String cursorString,
			Integer limit) throws Exception {
		try {
			DsQuery<AdminEMailNotice> dsQuery = new DsQuery<>(AdminEMailNotice.class)
				.cursor(cursorString)
				.limit(limit);
			
			List<AdminEMailNotice> results = dsQuery.execute(mgr);
			return new QueryResult<AdminEMailNotice>(results, dsQuery.getCursor());
		} catch (Exception ex) {
			throw ex;
		}
	}
*/	
}
