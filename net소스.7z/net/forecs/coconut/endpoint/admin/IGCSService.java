package net.forecs.coconut.endpoint.admin;

import com.google.api.services.storage.model.Objects;
import com.google.api.services.storage.model.StorageObject;

import net.forecs.coconut.common.util.GcsTree.Node;
import net.forecs.coconut.endpoint.common.ICommonService;

public interface IGCSService extends ICommonService {
	public abstract Objects listStorageObjects(String bucket, String delimiter,
			Long maxResults, String pageToken, String prefix,
			String projection, String userProject, String versions)
			throws Exception;
	public abstract Objects emoticonList(String prefix, String cursorString, Long limit) throws Exception;
	public abstract Node emoticonNode(String prefix, String cursorString, Long limit) throws Exception;
	public abstract Objects attachmentList(String domainName, String boardId, String taskId, String cursorString, Long limit) throws Exception;
	public abstract Node attachmentNode(String domainName, String boardId, String taskId, String cursorString, Long limit) throws Exception;
	public abstract StorageObject getStorageObject(String bucket, String name) throws Exception;
	public abstract void deleteStorageObject(String bucket, String prefix) throws Exception;
	public abstract void deleteDomainObject(String domainName);
	public abstract void deleteBoardObject(String domainName, String boardId);
	public abstract void deleteTaskObject(String domainName, String boardId, String taskId);
}
