package net.forecs.coconut.endpoint.admin;

import java.util.List;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.DomainsLogType;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.domain.DomainsLog;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.datanucleus.query.JPACursorHelper;


public class DomainsLogService extends CommonService implements IDomainsLogService {
	
	@SuppressWarnings("unused")
	@Override
	public QueryResult<DomainsLog> listDomainsLog(
			String domainName,
			DomainsLogType logType,
			String cursorString,
			Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			Cursor cursor = null;
			
			TypedQuery<DomainsLog> query = new QueryBuilder<>(DomainsLog.class)
					.addClause(FLD.domainName, domainName)
					.addClause(FLD.logType, logType)
					.build(mgr);

			if (StringUtils.isNotBlank(cursorString)) {
				cursor = Cursor.fromWebSafeString(cursorString);
				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
			}

			if (limit != null) {
				query.setFirstResult(0);
				query.setMaxResults(limit);
			}

			List<DomainsLog> domainLogList = (List<DomainsLog>) query.getResultList();
			cursor = JPACursorHelper.getCursor(domainLogList);
			//-->dead store
//			if (cursor != null) {
//				cursorString = cursor.toWebSafeString();
//			}

			// Tight loop for fetching all entities from datastore and accomodate
			// for lazy fetch.
			for (DomainsLog obj : domainLogList)
				;
			
			return new QueryResult<DomainsLog>(domainLogList, cursor);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public DomainsLog getDomainsLog(String domainLogId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			return doFind(mgr, DomainsLog.class, domainLogId);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public DomainsLog insertDomainsLog(DomainsLog domainsLog) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			domainsLog.setKey(KeyUtil.createDomainsLogKey());
			if (contains(mgr, DomainsLog.class, domainsLog.getDomainsLogId())) {
				throw new EntityExistsException("Object already exists");
			}
			
			doPersistTransaction(mgr, domainsLog);
			
			return domainsLog;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void removeDomainsLog(String domainLogId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			doRemoveTransaction(mgr, DomainsLog.class, domainLogId);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public DomainsLog findByRegistedCouponCode(String couponCode) {
		if (StringUtils.isEmpty(couponCode)) {
			return null;
		}

		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		EntityManager mgr = getEntityManager();
		
		try {
			TypedQuery<DomainsLog> query = new QueryBuilder<>(DomainsLog.class)
					.addClause(FLD.couponCode, couponCode)
					.addClause(FLD.logType, DomainsLogType.REGIST_COUPON)
					.build(mgr);
			return query.getSingleResult();
		} catch (Exception e) {
			return null;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
//	@Override
//	public DomainsLog findByRegistedImpUid(String imp_uid) {
//		if (StringUtils.isEmpty(imp_uid)) {
//			return null;
//		}
//
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(null);
//		
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			TypedQuery<DomainsLog> query = new QueryBuilder<>(DomainsLog.class)
////					.addClause(FLD.imp_uid, imp_uid)
//					.addClause(FLD.logType, DomainsLogType.SUBSCRIBE_BILL)
//					.build(mgr);
//			return query.getSingleResult();
//		} catch (Exception e) {
//			return null;
//		} finally {
//			finalizeTransaction(mgr, prevNamespace);
//		}
//	}
}
