package net.forecs.coconut.endpoint.admin;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.TermType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.billing.Coupons;


public interface ICouponService extends ICommonService {
	public abstract QueryResult<Coupons> listCoupons(
		String cursorString,
		Integer limit,
		String domainName,
		String useYN,
		String issueYN) throws Exception;

	public abstract Coupons getCoupons(String couponCode);
	public abstract Coupons insertCoupons(Coupons coupon);
	public abstract Coupons updateCoupons(Coupons coupon) throws Exception;
	public abstract Coupons updateCoupons(EntityManager mgr, Coupons coupon) throws Exception;
	public abstract void removeCoupons(String couponCode);
	
	public abstract List<Coupons> createCoupons(
			ServiceType serviceType,
			Long userQuota,
			Long storageQuota,
			Long boardQuota,
//			Long groupQuota,
//			Long taskQuota,
			Date validDate,
			TermType termType,
			Integer term,
			Date expirationDate,
			int couponCount) throws Exception;
	public abstract boolean isValidCoupon(String couponCode);
	public abstract Coupons registCoupon(String domainName, String couponCode) throws Exception;
	public abstract Coupons revokeCoupon(String domainName, String couponCode) throws Exception;
	public abstract List<Coupons> issueCoupons(List<String> couponCodes) throws Exception;
	public abstract Coupons issueCoupon(String couponCode, String issuer, String issueTarget) throws Exception;
	public abstract Coupons updateIssuer(String couponCode, String issuer) throws Exception;
	public abstract Coupons updateIssueTarget(String couponCode, String issueTarget) throws Exception;
	public abstract void permanentRemoveCoupons(String couponCode);
}
