package net.forecs.coconut.endpoint.admin;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class UsageServiceAPI {
	
	private final IUsageService usageService;
	
	@Inject
	public UsageServiceAPI(IUsageService usageService) {
		this.usageService = usageService;
	}
	
	@ApiMethod(name = "listUsages", path = "usage", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Usage> listUsages(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Usage> results = usageService.listUsages(cursorString, limit);
		List<Usage> list = results.getResultList();
		String nextPageToken = results.getNextPageToken();
		
		return CollectionResponse.<Usage>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "queryUsageLogs", path = "usageLogs", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<UsageLogs> queryUsageLogs(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.frequency) Frequency frequency,
			@Nullable @Named(FLD.startDate) Date startDate,
			@Nullable @Named(FLD.endDate) Date endDate,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<UsageLogs> results = usageService.queryUsageLogs(cursorString, limit, domainName, frequency, startDate, endDate);
		List<UsageLogs> list = results.getResultList();
		String nextPageToken = results.getNextPageToken();
		
		return CollectionResponse.<UsageLogs>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "summarizeUsageInfo", path = "usage/summarize", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Usage summarizeUsageInfo(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return UsageService.summarizeUsageInfo(domainName);
	}

	@ApiMethod(name = "resetUsageCheckpointsAll", path="usage/resetCheckpoints/all", httpMethod=HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Usage resetUsageCheckpointsAll(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return usageService.resetUsageCheckpoints(domainName, true, true, true, true);
		//return usageService.resetUsageCheckpoints(domainName, true, true, true, true, true, true);
	}
	@ApiMethod(name = "resetUsageCheckpointsOfExpirationDate", path="usage/resetCheckpoints/expirationDate", httpMethod=HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Usage resetUsageCheckpointsOfExpirationDate(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return usageService.resetUsageCheckpoints(domainName, true, false, false, false);
		//return usageService.resetUsageCheckpoints(domainName, true, false, false, false, false, false);
	}
	@ApiMethod(name = "resetUsageCheckpointsOfUser", path="usage/resetCheckpoints/users", httpMethod=HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Usage resetUsageCheckpointsOfUser(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return usageService.resetUsageCheckpoints(domainName, false, true, false, false);
		//return usageService.resetUsageCheckpoints(domainName, false, true, false, false, false, false);
	}
	
	@ApiMethod(name = "resetUsageCheckpointsOfStorage", path="usage/resetCheckpoints/storage", httpMethod=HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Usage resetUsageCheckpointsOfStorage(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return usageService.resetUsageCheckpoints(domainName, false, false, true, false);
		//return usageService.resetUsageCheckpoints(domainName, false, false, true, false, false, false);
	}
	@ApiMethod(name = "resetUsageCheckpointsOfBoard", path="usage/resetCheckpoints/boards", httpMethod=HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Usage resetUsageCheckpointsOfBoard(@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return usageService.resetUsageCheckpoints(domainName, false, false, false, true);
	}
	
	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	@ApiMethod(name = "resetUsageCheckpointsOfGroup", path="resetUsageCheckpointsOfGroup", httpMethod=HttpMethod.PUT,
			scopes = {CommonProperty.EMAIL_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	public Usage resetUsageCheckpointsOfGroup(@Named(FLD.domainName) String domainName, User user) throws Exception {
		if (user == null) throw new UnauthorizedException("User is Not Valid");
		return usageService.resetUsageCheckpoints(domainName, false, false, false, true, false, false);
	}
	
	@ApiMethod(name = "resetUsageCheckpointsOfTask", path="resetUsageCheckpointsOfTask", httpMethod=HttpMethod.PUT,
			scopes = {CommonProperty.EMAIL_SCOPE},
		    clientIds = {CommonProperty.WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	public Usage resetUsageCheckpointsOfTask(@Named(FLD.domainName) String domainName, User user) throws Exception {
		if (user == null) throw new UnauthorizedException("User is Not Valid");
		return usageService.resetUsageCheckpoints(domainName, false, false, false, false, false, true);
	}
	*/
	//<-- ===== DOMAIN STATISTICS =====
	
	@ApiMethod(name = "getDomainUsage", path = "usage/domains/{domainName}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Usage getDomainUsage(@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return UsageService.getDomainUsage(domainName);
	}
	
	// TODO - 추후 삭제 예정 (Client에 공개할 API 가 아님)
	@ApiMethod(name = "surveyUsage", path = "usage/survey", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	@Deprecated
	public void surveyUsage(
			@Named(FLD.accessToken) String accessToken) throws Exception {
		usageService.surveyUsage();
	}
	// TODO - 추후 삭제 예정 (Client에 공개할 API 가 아님)
	@ApiMethod(name = "surveyDomainUsage", path = "usage/survey/{domainName}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	@Deprecated
	public void surveyDomainUsage(@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		usageService.surveyUsage(domainName);
	}

	@ApiMethod(name = "removeUsage", path = "usage/domains", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	@Deprecated
	public void removeUsage(
			@Nullable @Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		usageService.removeUsage(domainName);
	}
	
	@ApiMethod(name = "removeAllUsage", path = "usage", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	@Deprecated
	public void removeAllUsage (
			@Named(FLD.accessToken) String accessToken) throws Exception {
		usageService.removeAllUsage();
	}
	
	@ApiMethod(name = "removeUsageLog", path = "usageLog/domains", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	@Deprecated
	public void removeUsageLog(
			@Nullable @Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		usageService.removeUsageLog(domainName);
	}
	
	@ApiMethod(name = "removeAllUsageLog", path = "usageLog", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	@Deprecated
	public void removeAllUsageLog(
			@Named(FLD.accessToken) String accessToken) throws Exception {
		usageService.removeAllUsageLog();
	}
	
	@ApiMethod(name = "removeUsageLogByDate", path = "usageLog/byDate", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	@Deprecated
	public void removeUsageLogByDate(
			@Named(FLD.created) Date created,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		usageService.removeUsageLogByDate(created);
	}
	
//	@Deprecated
//	@ApiMethod(name = "testStatisticNamespace", path="testStatisticNamespace", httpMethod=HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, Object> testStatisticNamespace(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		// ...
//		//NamespaceManager.set("MyDomain");
//		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
//	//	Entity globalStat = datastore.prepare(new Query("__Stat_Namespace__")).asSingleEntity();
//		//ObjectMapper om = new ObjectMapper();
//		Query query = new Query("__Stat_Namespace__");
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		for (final Entity entity : datastore.prepare(query).asIterable()) {
//			resMap.put((String)entity.getProperty("subject_namespace"), entity.getProperties());
//		}
//		return resMap;
//	}
//	@Deprecated
//	@ApiMethod(name = "testStatisticKind", path="testStatisticKind", httpMethod=HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, Object> testStatisticKind(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		// ...
//		//NamespaceManager.set("MyDomain");
//		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
//	//	Entity globalStat = datastore.prepare(new Query("__Stat_Namespace__")).asSingleEntity();
//		//ObjectMapper om = new ObjectMapper();
//		Query query = new Query("__Stat_Kind__");
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		for (final Entity entity : datastore.prepare(query).asIterable()) {
//			resMap.put((String)entity.getProperty("kind_name"), entity.getProperties());
//		}
//		return resMap;
//	}
//	@Deprecated
//	@ApiMethod(name = "testStatisticNsKind", path="testStatisticNsKind", httpMethod=HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, Object> testStatisticNsKind(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		// ...
//		//NamespaceManager.set("MyDomain");
//		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
//	//	Entity globalStat = datastore.prepare(new Query("__Stat_Namespace__")).asSingleEntity();
//		//ObjectMapper om = new ObjectMapper();
//		Query query = new Query("__Stat_Ns_Kind__");
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		for (final Entity entity : datastore.prepare(query).asIterable()) {
//			resMap.put((String)entity.getProperty("kind_name"), entity.getProperties());
//		}
//		return resMap;
//	}
//	@Deprecated
//	@ApiMethod(name = "testStatisticTotal", path="testStatisticTotal", httpMethod=HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, Object> testStatisticTotal(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
//		Query query = new Query("__Stat_Total__");
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		Entity globalStat = datastore.prepare(query).asSingleEntity();
//		resMap.putAll(globalStat.getProperties());
//		return resMap;
//	}
//	@Deprecated
//	@ApiMethod(name = "testStatisticNsTotal", path="testStatisticNsTotal", httpMethod=HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, Object> testStatisticNsTotal(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
//		Query query = new Query("__Stat_Ns_Total__");
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		Entity globalStat = datastore.prepare(query).asSingleEntity();
//		resMap.putAll(globalStat.getProperties());
//		return resMap;
//	}
}
