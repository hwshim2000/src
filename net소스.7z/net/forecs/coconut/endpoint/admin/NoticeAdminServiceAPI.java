package net.forecs.coconut.endpoint.admin;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.INoticeService;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.appengine.api.datastore.Text;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class NoticeAdminServiceAPI {
	private final INoticeService noticeService;
	
	@Inject
	public NoticeAdminServiceAPI(INoticeService noticeService) {
		this.noticeService = noticeService;
	}
	
	@ApiMethod(name = "querySystemNotice", path = "notice/system", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Notice> querySystemNotice(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Notice> queryResult = noticeService.querySystemNotice(cursorString, limit);
		List<Notice> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Notice>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	@ApiMethod(name = "getSystemNotice", path = "notice/system/{noticeId}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Notice getSystemNotice(
			@Named(FLD.noticeId) String noticeId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return noticeService.getSystemNotice(noticeId);
	}
	
	@ApiMethod(name = "insertSystemNotice", path = "notice/system", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Notice insertSystemNoticeForAllDomain(
			@Nullable @Named(FLD.domainNames) List<String> domainNames,
			Notice notice,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return noticeService.insertSystemNotice(domainNames, notice);
	}

	@ApiMethod(name = "updateSystemNotice", path = "notice/system", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Notice updateSystemNotice(
			Notice notice,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return noticeService.updateSystemNotice(notice);
	}
	
	@ApiMethod(name = "updateSystemNoticeTitle", path = "notice/system/title", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Notice updateSystemNoticeTitle(
			@Named(FLD.noticeId) String noticeId,
			@Named(FLD.title) String title,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return noticeService.updateSystemNoticeTitle(noticeId, title);
	}
	
	@ApiMethod(name = "updateSystemNoticeDescription", path = "notice/system/description", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Notice updateSystemNoticeDescription(
			@Named(FLD.noticeId) String noticeId,
			Text description,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return noticeService.updateSystemNoticeDescription(noticeId, description);
	}
	
	@ApiMethod(name = "removeSystemNotice", path = "notice/system/{noticeId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeSystemNotice(
			@Named(FLD.noticeId) String noticeId,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		noticeService.removeSystemNotice(noticeId);
	}
}
