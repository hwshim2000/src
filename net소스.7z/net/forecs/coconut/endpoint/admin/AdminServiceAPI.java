package net.forecs.coconut.endpoint.admin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.DomainsLogType;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.channel.ISyncService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IAttachmentService;
import net.forecs.coconut.endpoint.search.SearchManager;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.DomainsLog;
import net.forecs.coconut.entity.email.AdminEMailNotice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.search.SearchStorageUsage;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class AdminServiceAPI {
	private static final Logger LOG = Logger.getLogger(AdminServiceAPI.class.getName()); 

	private final IAdminService adminService;
//	private final ICalendarService calendarService;
//	private final IMemberAuthService memberAuthService;
//	private final IDomainService domainService;
	private final IUserService userService;
	private final IDomainsLogService domainsLogService;
	private final IAttachmentService attachmentService;
	private final ISyncService syncService;
	
//	private final SendEmail sendEmail;
	
	@Inject
	public AdminServiceAPI(IAdminService adminService,
//			ICalendarService calendarService,
//			IMemberAuthService memberAuthService,
//			IDomainService domainService,
			IUserService userService,
			IDomainsLogService domainsLogService,
			IAttachmentService attachmentService,
			ISyncService syncService
			//SendEmail sendEmail
			) {
		this.adminService = adminService;
//		this.calendarService = calendarService;
//		this.memberAuthService = memberAuthService;
//		this.domainService = domainService;
		this.userService = userService;
//		this.sendEmail = sendEmail;
		this.domainsLogService = domainsLogService;
		this.attachmentService = attachmentService;
		this.syncService = syncService;
	}

	@ApiMethod(name = "getDomainInfo", path = "domains/{domainName}/info", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}"/*, roles = { "AFAFAF", Role.SUPER }*/ )
	public Map<String, Object> getDomainInfo(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.getDomainInfo(domainName);
	}
	
	@ApiMethod(name = "listDomains", path = "domains", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Domains> listDomains(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.isDefault) boolean isDefault,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		LOG.warning("listDomains ++ " + limit + ", " + cursorString + ", " + isDefault);
		QueryResult<Domains> queryResult = adminService.listDomains(cursorString, limit, isDefault);
		List<Domains> list = queryResult.getResultList();
		
//		for (Domains domain : queryResult.getResultList()) {
//			LOG.warning("listDomains +++ :" + domain.getDomainName());
//		}
		
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Domains>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "listDomainUsers", path = "domains/users/{domainName}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Users> listDomainUsers(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.active) Boolean active,
			@Named(FLD.includeProfile) Boolean includeProfile,
			@Nullable @Named(FLD.deleteYN) String deleteYN,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Users> queryResult = adminService.listDomainUsers(domainName, cursorString, limit, active, includeProfile, deleteYN);
		List<Users> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Users>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	@ApiMethod(name = "updateDomainLabel", path = "domains/{domainName}/label", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains updateDomainLabel(@Named(FLD.domainName) String domainName,
			@Named(FLD.label) String label,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.updateDomainLabel(domainName, label, true, true);
	}
	
	@ApiMethod(name = "updateDomainNote", path = "domains/{domainName}/note", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains updateDomainNote(@Named(FLD.domainName) String domainName,
			@Named(FLD.note) String note,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.updateDomainNote(domainName, note, true, true);
	}

	@ApiMethod(name = "changeDomainBlockType", path = "domains/{domainName}/block", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains changeDomainBlockType(
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.blockType) BlockType blockType,
			@Named(FLD.isDefault) boolean isDefault,
			@Named(FLD.isOverwrite) boolean isOverwrite,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.changeDomainBlockType(domainName, blockType, isDefault, isOverwrite);
	}
	
	@ApiMethod(name = "changeDomainServiceType", path = "domains/{domainName}/service", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains changeDomainServiceType(
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.serviceType) ServiceType serviceType,
			@Nullable @Named(FLD.serviceGrade) String serviceGrade,
			@Nullable @Named(FLD.isDefault) boolean isDefault,
			@Nullable @Named(FLD.isOverwrite) boolean isOverwrite,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.changeDomainServiceType(domainName, serviceType, serviceGrade, isDefault, isOverwrite);
	}

	@ApiMethod(name = "changeCreateBoardAuth", path = "domains/{domainName}/createBoardAuth", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains changeCreateBoardAuth(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.createBoardAuth) Auth createBoardAuth,
			@Nullable @Named(FLD.isDefault) boolean isDefault,
			@Nullable @Named(FLD.isOverwrite) boolean isOverwrite,
			@Named(FLD.accessToken) String accessToken
			) throws Exception {
		return adminService.changeCreateBoardAuth(domainName, createBoardAuth, isDefault, isOverwrite);
	}
	
	@ApiMethod(name = "listNamespaces", path = "namespaces", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<String> listNamespaces(
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return CommonService.listNamespaces();
	}
	
	@ApiMethod(name = "listKinds", path = "kinds", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<String> listNamespace(@Nullable @Named(FLD.namespace) String namespace,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return CommonService.listKinds(namespace);
	}
	
	@ApiMethod(name = "listProperties", path = "properties", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Map<String, List<String>> listProperties(@Nullable @Named(FLD.namespace) String namespace,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return CommonService.listProperties(namespace);
	}
	
	@ApiMethod(name = "representationsOfProperty", path = "properties/kinds/{kind}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Collection<String> representationsOfProperty(
			@Nullable @Named(FLD.namespace) String namespace,
			@Named(FLD.kind) String kind, 
			@Named(FLD.property) String property,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return CommonService.representationsOfProperty(namespace, kind, property);
	}
	
	@ApiMethod(name = "resetDomainExpirationDate", path = "domains/{domainName}/expirationDate", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains resetDomainExpirationDate(
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.expirationDate) Date expirationDate,
//			@Named(FLD.isDefault) boolean isDefault,
//			@Named(FLD.isOverwrite) boolean isOverwrite,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.resetDomainExpirationDate(domainName, expirationDate, true, true);
	}
	
	@ApiMethod(name = "resetDomainUsageQuota", path = "domains/{domainName}/usageQuota", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains resetDomainUsageQuota(@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.userQuota) Long userQuota,
			@Nullable @Named(FLD.storageQuota) Long storageQuota,
			@Nullable @Named(FLD.boardQuota) Long boardQuota,
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			, @Nullable @Named(FLD.groupQuota) Long groupQuota,
			@Nullable @Named(FLD.taskQuota) Long taskQuota,
			*/
			//<-- ===== DOMAIN STATISTICS =====
//			@Named(FLD.isDefault) boolean isDefault,
//			@Named(FLD.isOverwrite) boolean isOverwrite,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.resetDomainUsageQuota(domainName, userQuota, storageQuota, boardQuota, true, true);
		//return adminService.resetDomainUsageQuota(domainName, userQuota, storageQuota, groupQuota, boardQuota, taskQuota);
	}
	
	@ApiMethod(name = "getSearchIndexUsage", path = "domains/{domainName}/indexUsage", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public SearchStorageUsage getSearchIndexUsage(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return SearchManager.getSearchIndexUsage(domainName);
	}
	
	@ApiMethod(name = "listSearchIndexUsage", path = "domains/indexUsage", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<SearchStorageUsage> listSearchIndexUsage(
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return SearchManager.listSearchIndexUsage();
	}
	
	//TODO : 나중에 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "updateAllDomainUserLowerId", path = "domains/userLowerId/all", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public List<Users> updateAllDomainUserLowerId(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return adminService.updateAllDomainUserLowerId();
//	}
	//TODO : 나중에 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "updateDomainUserLowerId", path = "domains/userLowerId", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public List<Users> updateDomainUserLowerId(
//			@Nullable @Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return adminService.updateDomainUserLowerId(domainName);
//	}
	//TODO : 나중에 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "updateDomainCaseInsensitive", path = "domains/caseInsensitive", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Domains updateDomainCaseInsensitive(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.caseInsensitive) boolean caseInsensitive,
//			@Named(FLD.isDefault) boolean isDefault,
//			@Named(FLD.isOverwrite) boolean isOverwrite,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return adminService.updateDomainCaseInsensitive(domainName, caseInsensitive, isDefault, isOverwrite);
//	}
	//TODO : 나중에 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "updateAllDomainCaseInsensitive", path = "domains/caseInsensitive/all", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public List<Domains> updateAllDomainCaseInsensitive(
//			@Named(FLD.caseInsensitive) boolean caseInsensitive,
//			@Named(FLD.isDefault) boolean isDefault,
//			@Named(FLD.isOverwrite) boolean isOverwrite,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return adminService.updateAllDomainCaseInsensitive(caseInsensitive, isDefault, isOverwrite);
//	}
	//TODO : 나중에 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "permanentRemoveDomainUsers", path = "domains/{domainName}/users/{userId}", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void permanentRemoveDomainUsers(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.userId) String userId,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.permanentRemoveDomainUsers(domainName, userId);
//	}
	// TODO : 나중에 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "permanentRemoveDefaultDomainUsers", path = "default/users", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void permanentRemoveDefaultDomainUsers(
//			@Named(FLD.id) String id,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.permanentRemoveDefaultDomainUsers(id);
//	}
	
	@ApiMethod(name = "listActivities", path = "domains/{domainName}/activities", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Activities> listActivities(
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Activities> queryResult = adminService.listActivities(domainName, cursorString, limit);
		List<Activities> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Activities>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	//TODO : 나중에 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "bulkRemoveDomainActivities", path = "domains/{domainName}/activities", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void bulkRemoveDomainActivities(
//			@Named(FLD.domainName) String domainName,
//			@Nullable @Named(FLD.boardId) String boardId,
//			@Nullable @Named(FLD.kindId) String kindId,
//			@Nullable @Named(FLD.activityKind) ActivityKind activityKind,
//			@Nullable @Named(FLD.activityType) ActivityType activityType,
//			@Nullable @Named(FLD.userId) String userId,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.bulkRemoveDomainActivities(domainName, boardId, kindId, activityKind, activityType, userId);
//	}
	
	// TODO : 삭제 예정
	// Alarm은 시스템 내부에서 사용할 목적이므로 사용자 인증 체크를 하지 않는다.
//	@Deprecated
//	@ApiMethod(name = "nextAlarm", path = "events/{eventId}/nextAlarm", httpMethod = HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Events nextAlarm(@Named(FLD.eventId) String eventId,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		NamespaceManager.set(KeyFactory.stringToKey(eventId).getNamespace());
//		return calendarService.nextAlarm(eventId);
//	}
	
	// TODO : 삭제 예정
	// Alarm은 시스템 내부에서 사용할 목적이므로 사용자 인증 체크를 하지 않는다.
//	@Deprecated
//	@ApiMethod(name = "queryNextAlarms", path = "domains/{domainId}/nextAlarms", httpMethod = HttpMethod.GET)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public CollectionResponse<Events> queryNextAlarms (
//			@Named(FLD.domainId) String domainId,
//			@Nullable @Named(FLD.boardId) String boardId,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		NamespaceManager.set(KeyFactory.stringToKey(domainId).getNamespace());
//		List<Events> list = calendarService.queryNextAlarms(domainId, boardId);
//		return CollectionResponse.<Events>builder().setItems(list).build();
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "unassignAllMemberAuths", path = "domains/{domainName}/users/{userId}/unassign", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void unassignAllMemberAuths (
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.userId) String userId,
//			@Named(FLD.authKind) AuthKind authKind,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		NamespaceManager.set(domainName);
//		memberAuthService.unassignAllMemberAuth(userId, authKind);
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "reassignAllMemberAuth", path = "domains/{domainName}/users/{userId}/reassign", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void reassignAllMemberAuth (
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.userId) String userId,
//			@Named(FLD.authKind) AuthKind authKind,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		NamespaceManager.set(domainName);
//		memberAuthService.reassignAllMemberAuth(userId, authKind);
//	}
	
	// TODO : 삭제 예정
	// Alarm은 시스템 내부에서 사용할 목적이므로 사용자 인증 체크를 하지 않는다.
//	@Deprecated
//	@ApiMethod(name = "permanentRemoveUnusedMemberAuths", path = "domains/{domainName}/users/unused", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void permanentRemoveUnusedMemberAuths (
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.authKind) AuthKind authKind,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		NamespaceManager.set(domainName);
//		memberAuthService.bulkRemoveMemberAuths(null, null, null, AuthKind.DOMAINS, null, null, null);
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "updateDomainNameForDefaultUser", path = "default/users/{id}/domainName/{domainName}", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Users updateDomainNameForDefaultUser(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.id) String id,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return domainService.updateDomainNameForDefaultUser(domainName, id);
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "bulkUpdateTaskTimelinesForModified", path = "domains/{domainName}/taskTimelines/modified", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Result bulkUpdateTaskTimelinesForModified(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return new Result(adminService.bulkUpdateTaskTimelinesForModified(domainName));
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "sendEmailUseAppengineMailService", path = "sendEmailUseAppengineMailService", httpMethod = HttpMethod.POST)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void sendEmailUseAppengineMailService(@Named(FLD.title) String title, Text message, @Named(FLD.toAddress) String toAddress,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		sendEmail.send(toAddress, title, message.getValue());
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "sendEmailUseGmailSmtp", path = "sendEmailUseGmailSmtp", httpMethod = HttpMethod.POST)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void sendEmailUseGmailSmtp(@Named(FLD.title) String title, Text message, @Named(FLD.toAddress) String toAddress,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		MailUtil.send(toAddress, title, message.getValue());
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "sendEmailUseNaverSmtp", path = "sendEmailUseNaverSmtp", httpMethod = HttpMethod.POST)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void sendEmailUseNaverSmtp(@Named(FLD.title) String title, Text message, @Named(FLD.toAddress) String toAddress,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		SmtpSendEMail.send(toAddress, title, message.getValue());
//	}
	
	@ApiMethod(name = "sendRandomPassword", path = "users/sendRandomPassword", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void sendRandomPassword(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.id) String id,
			@Nullable @Named(FLD.email) String email,
			@Nullable @Named(FLD.password) String password,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		adminService.sendRandomPassword(domainName, id, email, password);
	}

	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	@ApiMethod(name = "setRole", path = "domains/{domainName}/users/{userId}/role", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Users setRole(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.userId) String userId,
			@Named(FLD.role) String role,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		NamespaceManager.set(domainName);
		return userService.setRole(userId, role);
	}
	//<--

	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "addPermissions", path = "domains/{domainName}/users/{userId}/permissions", httpMethod = HttpMethod.POST)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Users addPermissions(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.userId) String userId,
//			@Named(FLD.permissions) Set<String> permissions,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		NamespaceManager.set(domainName);
//		return userService.addPermissions(userId, permissions);
//	}

	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "removePermissions", path = "domains/{domainName}/users/{userId}/permissions", httpMethod = HttpMethod.DELETE)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Users removePermissions(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.userId) String userId,
//			@Named(FLD.permissions) Set<String> permissions,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		NamespaceManager.set(domainName);
//		return userService.removePermissions(userId, permissions);
//	}
	
	@ApiMethod(name = "assignUserAuth", path = "domains/{domainName}/users/{userId}/auth/{auth}", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Users assignUserAuth(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.userId) String userId,
			@Named(FLD.auth) Auth auth,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.assignUserAuth(domainName, userId, auth);
	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "createAndRevokeAdminAll", path = "domains/admin/createAndRevoke", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void createAndRevokeAdminAll(@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.createAndRevokeAdminAll();
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "createAndRevokeAdmin", path = "domains/admin/createAndRevoke/{domainName}", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void createAndRevokeAdmin(@Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.createAndRevokeAdmin(domainName);
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "updateAllActivitiesShow", path = "activities/show", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Map<String, Integer> updateAllActivitiesShow(
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		return adminService.updateAllActivitiesShow(limit);
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "updateActivitiesShow", path = "domains/{domainName}/activities/show", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Result updateActivitiesShow(
//			@Named(FLD.domainName) String domainName,
//			@Nullable @Named(FLD.limit) Integer limit,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		int resultCount = adminService.updateActivitiesShow(domainName, limit);
//		return new Result(resultCount);
//	}
	
	@ApiMethod(name = "resolveKeyString", path = "utils/resolveKey", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Map<String, Object> resolveKeyString(@Named(FLD.keys) List<String> keys,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		List<String> allKeys = new ArrayList<String>();
		
		for (String keyString : keys) {
			String[] arr = keyString.split(",");
			for (String str : arr) {
				if (StringUtils.isNotBlank(str)) {
					allKeys.add(str.trim());
				}
			}
		}
		Map<String, Object> keyMap = new HashMap<String, Object>();
		for (String keyString : allKeys) {
			try {
				keyMap.put(keyString, KeyFactory.stringToKey(keyString));
			} catch (Exception ex) {
				keyMap.put(keyString, ex.getMessage());
			}
		}
		return keyMap;
	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "bulkUpdateTasksForPublic", path = "domains/{domainName}/public", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public Result bulkUpdateTasksForPublic(@Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		int resultCount = adminService.bulkUpdateTasksForPublic(domainName);
//		return new Result(resultCount);
//	}
	
	@ApiMethod(name = "getAllUserEmailInfo", path = "domains/users/emailInfo", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Map<String, Map<String, String>> getAllUserEmailInfo(
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.getAllUserEmailInfo();
	}
	
	@ApiMethod(name = "getDomainUserEmailInfo", path = "domains/{domainName}/users/emailInfo", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Map<String, String> getDomainUserEmailInfo(@Named(FLD.domainName) String domainName,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.getDomainUserEmailInfo(domainName);
	}
	
	@ApiMethod(name = "sendAllNoticeEmail", path = "email/domains", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void sendAllNoticeEmail(
			@Nullable @Named(FLD.domainNames) List<String> domainNames,
			@Named(FLD.title) String title,
			Text message,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		if (message == null || StringUtils.isBlank(message.getValue())) { return; }
		
		//String htmlMessage = message.getValue().replaceAll("\n", "<br>").replaceAll(" ", "&nbsp;");
		//String htmlMessage = HtmlUtil.escape(message.getValue());
		adminService.sendAllNoticeEmail(domainNames, title, message);	// replace message.getValue()
	}
	
	@ApiMethod(name = "sendAllNoticeEmailtoAdmin", path = "email/domains/admin", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void sendAllNoticeEmailtoAdmin(
			@Nullable @Named(FLD.domainNames) List<String> domainNames,
			@Named(FLD.title) String title,
			Text message,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		if (message == null || StringUtils.isBlank(message.getValue())) { return; }
		
		//String htmlMessage = message.getValue().replaceAll("\n", "<br>").replaceAll(" ", "&nbsp;");
		//String htmlMessage = HtmlUtil.escape(message.getValue());
		adminService.sendAllNoticeEmailtoAdmin(domainNames, title, message);		// replace message.getValue()
	}
	
	
	@ApiMethod(name = "sendDomainNoticeEmail", path = "email/domains/{domainName}", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void sendDomainNoticeEmail(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.title) String title,
			Text message,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		LOG.warning("sendDomainNoticeEmail: " + domainName);
		LOG.warning("sendDomainNoticeEmail: " + title);
		if (message == null || StringUtils.isBlank(message.getValue())) { 
			LOG.warning("sendDomainNoticeEmail: message NULL");
			return; 
		}
		LOG.warning("sendDomainNoticeEmail: message " + message.getValue());
		
		//String htmlMessage = message.getValue().replaceAll("\n", "<br>").replaceAll(" ", "&nbsp;");
//		String htmlMessage = HtmlUtil.escape(message.getValue());
		adminService.sendDomainNoticeEmail(domainName, title, message, null);
	}
	
	@ApiMethod(name = "sendDomainNoticeEmailtoAdmin", path = "email/domains/admin/{domainName}", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void sendDomainNoticeEmailtoAdmin(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.title) String title,
			Text message,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		LOG.warning("sendDomainNoticeEmail: " + domainName);
		LOG.warning("sendDomainNoticeEmail: " + title);
		if (message == null || StringUtils.isBlank(message.getValue())) { 
			LOG.warning("sendDomainNoticeEmailtoAdmin: message NULL");
			return; 
		}
		LOG.warning("sendDomainNoticeEmailtoAdmin: message " + message.getValue());
		
		adminService.sendDomainNoticeEmailtoAdmin(domainName, title, message, null);
	}
	
	@ApiMethod(name = "sendUserNoticeEmail", path = "email/domains/emails", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void sendUserNoticeEmail(
			@Named(FLD.title) String title,
			Text message,
			@Named(FLD.emails) List<String> emailList,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		if (message == null || StringUtils.isBlank(message.getValue())) { return; }
		
		//String htmlMessage = message.getValue().replaceAll("\n", "<br>").replaceAll(" ", "&nbsp;");
//		String htmlMessage = HtmlUtil.escape(message.getValue());
		adminService.sendDomainNoticeEmail(null, title, message, emailList);
	}

	@ApiMethod(name = "insertAdminEMailNotice", path = "admin/notice/email", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public AdminEMailNotice insertAdminEMailNotice(AdminEMailNotice adminEMailNotice, @Named(FLD.accessToken) String accessToken) throws Exception {
		
//		LOG.warning("insertAdminEMailNotice : " + adminEMailNotice.getDomainName());
//		LOG.warning("insertAdminEMailNotice : " + adminEMailNotice.getTitle());
//		LOG.warning("insertAdminEMailNotice : " + adminEMailNotice.getDescription());
//		LOG.warning("insertAdminEMailNotice : " + adminEMailNotice.getSendDate().toString());
		
		return adminService.insertAdminEMailNotice(adminEMailNotice);
	}
	
	
	@ApiMethod(name = "getAdminEmailNoticeList", path = "admin/notice/email", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<AdminEMailNotice> getAdminEMailNoticeList(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.isDefault) boolean isDefault,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<AdminEMailNotice> queryResult = adminService.getAdminEMailNoticeList(cursorString, limit, isDefault);
		List<AdminEMailNotice> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<AdminEMailNotice>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}	
	
	@ApiMethod(name = "permanentRemoveAdminEMailNotice", path = "admin/notice/email", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void permanentRemoveAdminEMailNotice(
			@Named(FLD.id) String objectId,									// id -> objectId
			@Named(FLD.accessToken) String accessToken) throws Exception {
//		LOG.warning("permanentRemoveAdminEMailNotice id : " + objectId);			// for check ID value
		adminService.permanentRemoveAdminEMailNotice(objectId);
	}
	
	
	
	@ApiMethod(name = "changeDomainUseStorage", path = "domains/{domainName}/useStorage", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Domains changeDomainUseStorage(
			@Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.useStorage) Boolean useStorage,
			@Named(FLD.isDefault) boolean isDefault,
			@Named(FLD.isOverwrite) boolean isOverwrite,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return adminService.changeDomainUseStorage(domainName, useStorage, isDefault, isOverwrite);
	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "overwriteToAllUserDomain", path = "domains/toUser/overwrite", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void overwriteToAllUserDomain(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.overwriteToAllUserDomain();
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "overwriteToUserDomain", path = "domains/overwrite/toUser/{domainName}", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void overwriteToUserDomain(@Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.overwriteToUserDomain(domainName);
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "overwriteToAllDefaultDomain", path = "domains/overwrite/toDefault", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void overwriteToAllDefaultDomain(
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.overwriteToAllDefaultDomain();
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "overwriteToDefaultDomain", path = "domains/overwrite/toDefault/{domainName}", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void overwriteToDefaultDomain(@Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.overwriteToDefaultDomain(domainName);
//	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "initializeAllTaskImportance", path = "domains/tasks/initImportance", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void initializeAllTaskImportance(
//			@Nullable @Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.initializeTaskImportance();
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "initializeTaskImportance", path = "domains/{domainName}/tasks/initImportance", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void initializeTaskImportance(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.initializeTaskImportance(domainName);
//	}
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "initializeEntity", path = "domains/entity/init", httpMethod = HttpMethod.PUT)
//	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
//	public void initializeEntity(
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.kind) String kind,
//			HashMap<String, Object> initMap, 
//			@Named(FLD.accessToken) String accessToken) throws Exception {
//		adminService.initializeEntity(domainName, kind, initMap);
//	}
	
	@ApiMethod(name = "listDomainsLog", path = "domains/logs", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<DomainsLog> listDomainsLog(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.logType) DomainsLogType logType, 
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<DomainsLog> queryResult = domainsLogService.listDomainsLog(domainName, logType, cursorString, limit);
		List<DomainsLog> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<DomainsLog>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "googleLogin", path = "admin/auths/googleLogin", httpMethod = HttpMethod.GET,
//			scopes = {CommonProperty.EMAIL_SCOPE},
//		    clientIds = {CommonProperty.WEB_CLIENT_ID,
//			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public void test(HttpServletRequest request, HttpServletResponse response, User user) throws Exception {
//		
//		UserService userService = UserServiceFactory.getUserService();
//		//String userName = request.getUserPrincipal().getName();
//		//LOG.warning(userName);
//		LOG.warning(request.getHeader("Authorization"));
//		if (userService.getCurrentUser() != null) {
//			LOG.warning(userService.getCurrentUser().getEmail());
//		}
//		LOG.warning("==============");
//		
//		LOG.warning(user.getEmail());
//		LOG.warning(user.getAuthDomain());
//		LOG.warning(user.getFederatedIdentity());
//		LOG.warning(user.getNickname());
//		LOG.warning(user.getUserId());
//		
//	}
	
	// TODO : 삭제 예정
//	@SuppressWarnings("unchecked")
//	@Deprecated
//	@ApiMethod(name = "sessionInfo", path = "admin/sessions/info", httpMethod = HttpMethod.GET)
//	public void getUserFromSessionInDatastore(HttpServletRequest request, @Nullable @Named("jSessionId") String jSessionId) {
//        String entityId = "_ahs" + jSessionId;
//        String memcacheId = "cacheduser/" + entityId;
//        NamespaceManager.set(null);
//        DatastoreService datastoreService = DatastoreServiceFactory.getDatastoreService();
//        MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(null);
//        Entity session = null;
//        try {
//        	CoconutServlet.getServletInfo(request, null);
//            session = datastoreService.get(KeyFactory.createKey("_ah_SESSION", entityId));
//            if (session == null) { return; }
//        } catch (EntityNotFoundException e) {
//        } catch (IOException e) {
//        } catch (ServletException e) {
//        }
//        Long expires = (Long) session.getProperty("_expires");
//        Blob values = (Blob) session.getProperty("_values");
//        Map<String, Object> valuesMap;
//        try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(values.getBytes())) {
//            try (ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream)) {
//                valuesMap = (Map<String, Object>) objectInputStream.readObject();
//            } catch (ClassNotFoundException e) {
//                throw new RuntimeException(e);
//            }
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//        
//        if (valuesMap != null) {
//	        for (Map.Entry<String, Object> entry : valuesMap.entrySet()) {
//	        	LOG.warning(entry.getKey() + ":"+ entry.getValue());
//	        }
//        }
//        
//        if (mcs.get(memcacheId) != null) {
//        	LOG.warning("Memcached value is not null");
//        }
//        
//        if (expires != null) {
//	        Date d = new Date(expires);
//	        LOG.warning(d.toString());
//        }
//    }
	
	// TODO : 삭제 예정
//	@Deprecated
//	@ApiMethod(name = "dongbuLogin", path = "admin/dongbuLogin", httpMethod = HttpMethod.POST,
//			scopes = {CommonProperty.EMAIL_SCOPE},
//		    clientIds = {CommonProperty.WEB_CLIENT_ID,
//			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public Users dongbuLogin(HttpServletRequest request,
//			@Nullable @Named(FLD.domainName) String domainName,
//			@Named(FLD.id) String id, @Named(FLD.password) String password,
//			@Nullable @Named(FLD.rememberMe) String rememberMe, User guser) throws Exception {
//		if (guser != null) {
//			// TODO 동부 유저 context 테스트를 위해
//	LoginContext.create(domainName);
//			// 만일 guser 가 null이면 아래 단계로 진행, guser가 null이 아니면 UserMap 테이블에서 해당유저의 domain과 id password를 검색한후 login진행
//			LOG.warning(guser.getEmail());
//			LOG.warning(guser.getAuthDomain());
//			LOG.warning(guser.getFederatedIdentity());
//			LOG.warning(guser.getNickname());
//			LOG.warning(guser.getUserId());
//		}
//		
//		String host = request.getRemoteHost();
//		Users user = userService.login(domainName, id, password,
//				Boolean.parseBoolean(rememberMe), host);
//		return user;
//	}
//	
//	@Deprecated
//	@ApiMethod(name = "queryUsers", path = "domains/queryUsers", httpMethod = HttpMethod.GET,
//			scopes = {CommonProperty.EMAIL_SCOPE},
//		    clientIds = {CommonProperty.WEB_CLIENT_ID,
//			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public List<Users> queryUsers(
//			@Named(FLD.domainName) String domainName,
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit, 
//			@Named(FLD.code) String code,
//			User user) throws Exception {
//		if (!StringUtils.equals(code, AdminCommonService.secCode)) { throw new UnavailableException("Invalid code"); }
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		
//		NamespaceManager.set(domainName);
//		Cursor cursor = null;;
//		if (StringUtils.isNotBlank(cursorString)) {
//			cursor = Cursor.fromWebSafeString(cursorString);
//		}
//		return AdminService.queryUsers(cursor, limit, "-created").getResultList();
//	}
	
	
//	@ApiMethod(name = "testBuklInsertImages", path = "testBuklInsertImages", httpMethod = HttpMethod.POST,
//			scopes = {CommonProperty.EMAIL_SCOPE},
//		    clientIds = {CommonProperty.WEB_CLIENT_ID,
//			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public void testBuklInsertImages(User user) throws Exception {
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		adminService.testBuklInsertImages();
//	}
//	@Deprecated
//	@ApiMethod(name = "testRemoveMemberAuthMemcacheKey", path = "testRemoveMemberAuthMemcacheKey", httpMethod = HttpMethod.DELETE,
//	scopes = {CommonProperty.EMAIL_SCOPE},
//    clientIds = {CommonProperty.WEB_CLIENT_ID,
//	com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public void testRemoveMemberAuthMemcacheKey(
//			@Named(FLD.domainName) String domainName,
//			User user) throws Exception {
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		MemcacheManager.removeMemcacheKey(MemberAuths.class, null, domainName);
//	}
//	
//	@Deprecated
//	@ApiMethod(name = "testMultiPersist", path = "testMultiPersist", httpMethod = HttpMethod.PUT,
//	scopes = {CommonProperty.EMAIL_SCOPE},
//    clientIds = {CommonProperty.WEB_CLIENT_ID,
//	com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public void testMultiPersist(User user) throws Exception {
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		ConvertingUtil.test();
//	}
//	@Deprecated
//	@ApiMethod(name = "testFetchTimeCompareWithMultiManager", path = "testFetchTimeCompareWithMultiManager", httpMethod = HttpMethod.PUT,
//	scopes = {CommonProperty.EMAIL_SCOPE},
//    clientIds = {CommonProperty.WEB_CLIENT_ID,
//	com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public void testFetchTimeCompareWithMultiManager(User user) throws Exception {
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		AdminService.testFetchTimeCompareWithMultiManager();
//	}
//	@Deprecated
//	@ApiMethod(name = "testFetchTimeCompareWithSingleManager", path = "testFetchTimeCompareWithSingleManager", httpMethod = HttpMethod.PUT,
//	scopes = {CommonProperty.EMAIL_SCOPE},
//    clientIds = {CommonProperty.WEB_CLIENT_ID,
//	com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public void testFetchTimeCompareWithSingleManager(User user) throws Exception {
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		AdminService.testFetchTimeCompareWithSingleManager();
//	}
//	@Deprecated
//	@ApiMethod(name = "relocationUserImageToGCS", path = "domains/{domainName}/users/{userId}/relocationImage", httpMethod = HttpMethod.PUT,
//	scopes = {CommonProperty.EMAIL_SCOPE},
//    clientIds = {CommonProperty.WEB_CLIENT_ID,
//	com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
//	public Users relocationUserImageToGCS(
//			@Named(FLD.bucket) String bucket,
//			@Named(FLD.domainName) String domainName,
//			@Named(FLD.userId) String userId,
//			@Named(FLD.imageSize) int imageSize,
//			@Named(FLD.code) String code,
//			User user) throws Exception {
//		if (!StringUtils.equals(code, AdminCommonService.secCode)) { throw new UnavailableException("Invalid code"); }
//		if (user == null) throw new UnauthorizedException("User is not valid.");
//		return adminService.relocationUserImageToGCS(bucket, domainName, userId, imageSize);
//	}
//	
	
	@ApiMethod(name = "removeUploadedTrashFiles", path = "attachments/trash", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeUploadedTrashFiles(@Named(FLD.accessToken) String accessToken, @Nullable @Named(FLD.created) Date date) throws Exception {
		attachmentService.removeUploadedTrashFiles(date);
	}
	
	@Deprecated
	@ApiMethod(name = "listLastDomainAccess", path = "activities/lastAccess", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Map<String, Object> listLastDomainAccess(@Named(FLD.accessToken) String accessToken, @Nullable @Named(FLD.accessDate) Date accessDate) throws Exception {
		return adminService.listLastDomainAccess(accessDate);
	}
	
	@ApiMethod(name = "removeDomainChannel", path = "channel/domains/{domainId}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeDomainChannel(@Named(FLD.accessToken) String accessToken, @Named(FLD.domainId) String domainId) throws Exception {
		syncService.removeDomainChannel(domainId);
	}
	@ApiMethod(name = "removeOnlineUserChannel", path = "channel/onlineUsers", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeOnlineUserChannel(@Named(FLD.accessToken) String accessToken,
			@Named(FLD.domainId) String domainId,
			@Nullable @Named(FLD.userId) String userId) throws Exception {
		syncService.removeOnlineUserChannel(domainId, userId);
	}
	@ApiMethod(name = "removeAllUnavailableDomainChannels", path = "channel/removeAllUnavailableDomainChannels", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeAllUnavailableDomainChannels(@Named(FLD.accessToken) String accessToken) throws Exception {
		syncService.removeAllUnavailableDomainChannels();
	}
	@ApiMethod(name = "removeAllUnavailableOnlineUserChannels", path = "channel/removeAllUnavailableOnlineUserChannels", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void removeAllUnavailableOnlineUserChannels(@Named(FLD.accessToken) String accessToken) throws Exception {
		syncService.removeAllUnavailableOnlineUserChannels();
	}
}
