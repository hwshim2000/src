package net.forecs.coconut.endpoint.admin;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.DomainsLogType;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.ClassUtil;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.DomainsLog;
import net.forecs.coconut.entity.email.AdminEMailNotice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.user.Role;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.BadRequestException;
import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.datanucleus.query.JPACursorHelper;
import com.google.appengine.api.datastore.Text;					// for mail description


public class AdminService extends AdminCommonService implements IAdminService {
	private static final Logger LOG = Logger.getLogger(AdminService.class.getName());
	
	private final IUsageService usageService;
	private final IUserService userService;
	private final IActivityService activityService;
//	private final IImageService imageService;
	private final IDomainService domainService;
	private final IDomainsLogService domainsLogService;
	
	private final static Set<String> excludeProperties = new HashSet<String>();
	static {
		excludeProperties.add(FLD.creator);
		excludeProperties.add(FLD.owner);
		excludeProperties.add(FLD.key);
		excludeProperties.add(FLD.domainId);
		excludeProperties.add(FLD.objectId);
//		excludeProperties.add("keyStr");
		excludeProperties.add(FLD.created);
		excludeProperties.add(FLD.domainName);
//		excludeProperties.add(FLD.modified);
//		excludeProperties.add(FLD.expirationDate);
		
		excludeProperties.add(FLD.usageId);
		excludeProperties.add(FLD.usageLogId);
	}
	
//	private final GcsService gcsService = GcsServiceFactory
//			.createGcsService(new RetryParams.Builder()
//					.initialRetryDelayMillis(10).retryMaxAttempts(10)
//					.totalRetryPeriodMillis(15000).build());
	
	@Inject
	public AdminService(IUsageService usageService,
			IUserService userService,
			IActivityService activityService,
//			IImageService imageService,
			IDomainService domainService,
			IDomainsLogService domainsLogService
			) {
		this.usageService = usageService;
		this.userService = userService;
		this.activityService = activityService;
//		this.imageService = imageService;
		this.domainService = domainService;
		this.domainsLogService = domainsLogService;
	}
	
	@Override
	public QueryResult<Domains> listDomains(String cursorString, Integer limit, boolean isDefault) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			QueryResult<Domains> queryResult = listDomains(mgr, cursorString, limit);
			
			if (isDefault) {
				return queryResult;
			} else {
				List<Domains> userDomains = new ArrayList<Domains>();
				
				for (Domains domain : queryResult.getResultList()) {
					NamespaceManager.set(domain.getDomainName());
					Domains userDomain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domain.getDomainName()));
					if (userDomain != null) { userDomains.add(userDomain); }
				}
				
				return new QueryResult<Domains>(userDomains, queryResult.getCursorString());
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public QueryResult<Users> listDomainUsers(String domainName, String cursorString, Integer limit, Boolean active, boolean includeProfile, String deleteYN) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			return userService.queryUsers(cursorString, limit, active, includeProfile, deleteYN);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public Domains updateDomainLabel(String domainName, String label, boolean isDefault, boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			domain.setLabel(label);
			
			beginTransaction(mgr);
			domain = doMerge(mgr, domain);
			commitTransaction(mgr);

			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public Domains updateDomainNote(String domainName, String note, boolean isDefault, boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();

		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			domain.setNote(note);
			
			beginTransaction(mgr);
			domain = doMerge(mgr, domain);
			commitTransaction(mgr);
			
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Domains changeDomainBlockType(String domainName, BlockType bloclType, boolean isDefault, boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			valid(domain);
			
			DomainsLog domainLog = new DomainsLog(domain, DomainsLogType.UPDATE_BLOCK);
			
			domain.setBlockType(bloclType);
			
			beginTransaction(mgr);
			doMerge(mgr, domain);
//			doMerge(mgr, domain, domainLog);
			domain.setBlockType(bloclType);
			commitTransaction(mgr);
			
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Domains changeCreateBoardAuth(String domainName, Auth createBoardAuth, boolean isDefault, boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			valid(domain);
			
			DomainsLog domainLog = new DomainsLog(domain, DomainsLogType.CREATE_BOARD_AUTH);
			
			domain.setCreateBoardAuth(createBoardAuth);
			
			beginTransaction(mgr);
			doMerge(mgr, domain);
//			doMerge(mgr, domain, domainLog);
			domain.setCreateBoardAuth(createBoardAuth);
			commitTransaction(mgr);
			
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	@Override
	public Domains changeDomainServiceType(String domainName, ServiceType serviceType, String serviceGrade, boolean isDefault, boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			valid(domain);
			DomainsLog domainLog = new DomainsLog(domain, DomainsLogType.UPDATE_SERVICE_TYPE);
			
			domain.setServiceType(serviceType);
			domain.setServiceGrade(serviceGrade);
			
			if (ServiceType.TRIAL.equals(serviceType)) {
				domain.setUserQuota(CommonProperty.DEFAULT_USER_QUOTA);
				domain.setStorageQuota(CommonProperty.DEFAULT_STORAGE_QUOTA);
				domain.setBoardQuota(CommonProperty.DEFAULT_BOARD_QUOTA);
				//domain.setExpirationDate(CalendarUtil.addMonth(domain.getCreated(), CommonProperty.DEFAULT_EXPIRATION_MONTH));
			} else if (ServiceType.DEFERRED.equals(serviceType)) {
				domain.setUserQuota(null);
				domain.setStorageQuota(null);
				domain.setBoardQuota(null);
				domain.setExpirationDate(null);
			}
			
			beginTransaction(mgr);
			doMerge(mgr, domain);
			domain.setServiceType(serviceType);
			domain.setServiceGrade(serviceGrade);
			commitTransaction(mgr);
			
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Domains resetDomainExpirationDate(String domainName, Date expirationDate, boolean isDefault, boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			valid(domain);
			Domains originDomain = (Domains)CopyUtil.copyDeeply(domain);
			DomainsLog domainLog = new DomainsLog(originDomain, DomainsLogType.UPDATE_EXPIRATION);

			domain.setExpirationDate(expirationDate);
		
			doMergeTransaction(mgr, domain);
//			doMergeTransaction(mgr, domain, domainLog);
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			usageService.resetUsageCheckpoints(originDomain, domain);
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Domains resetDomainUsageQuota(String domainName, Long userQuota, Long storageQuota, Long boardQuota
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			, Long groupQuota, Long taskQuota
			*/
			//<-- ===== DOMAIN STATISTICS =====
			, boolean isDefault, boolean isOverwrite
			) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
//			if (userQuota == null) { userQuota = CommonProperty.DEFAULT_USER_QUOTA; }
//			if (storageQuota == null) { storageQuota = userQuota * CommonProperty.UNIT_STORAGE_PER_USER; }
//			if (boardQuota == null) { boardQuota = CommonProperty.DEFAULT_BOARD_QUOTA; }
			
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			valid(domain);
			Domains originDomain = (Domains)CopyUtil.copyDeeply(domain);
			DomainsLog domainLog = new DomainsLog(originDomain, DomainsLogType.UPDATE_QUOTA);
			
			domain.setUserQuota(userQuota);
			domain.setStorageQuota(storageQuota);
			domain.setBoardQuota(boardQuota);
			//--> ===== DOMAIN STATISTICS =====
			/* Later, I may use this code.
			domain.setGroupQuota(groupQuota);
			domain.setTaskQuota(taskQuota);
			*/
			//<-- ===== DOMAIN STATISTICS =====
			doMergeTransaction(mgr, domain);
//			doMergeTransaction(mgr, domain, domainLog);
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			usageService.resetUsageCheckpoints(originDomain, domain);
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

//	@Deprecated
//	@Override
//	public Domains resetDomainUsageForBills(Domains resetDomain, DomainsLogType domainsLogType, boolean isDefault, boolean isOverwrite) throws Exception {
//		String prevNamespace = NamespaceManager.get();
//		String domainName = resetDomain.getDomainName();
//		if (isDefault) { NamespaceManager.set(null); }
//		else {  NamespaceManager.set(domainName); }
//		
//		EntityManager mgr = getEntityManager();
//		
//		try {
////			if (userQuota == null) { userQuota = CommonProperty.DEFAULT_USER_QUOTA; }
////			if (storageQuota == null) { storageQuota = userQuota * CommonProperty.UNIT_STORAGE_PER_USER; }
////			if (boardQuota == null) { boardQuota = CommonProperty.DEFAULT_BOARD_QUOTA; }
//			
//			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
//			valid(domain);
//			Domains originDomain = (Domains)CopyUtil.copyDeeply(domain);
//			DomainsLog domainLog = new DomainsLog(originDomain, domainsLogType);
//			
//			if (DomainsLogType.UNSUBSCRIBE_BILL.equals(domainsLogType)) {
//				domain.setExpirationDate(resetDomain.getExpirationDate());
//				domain.setPaymentEnd(new Date());
//			} else {
//				domain.setExpirationDate(resetDomain.getExpirationDate());
//				domain.setUserQuota(resetDomain.getUserQuota());
//				domain.setStorageQuota(resetDomain.getStorageQuota());
//				domain.setBoardQuota(resetDomain.getBoardQuota());
//				domain.setCaseInsensitive(resetDomain.isCaseInsensitive());
//				domain.setServiceType(resetDomain.getServiceType());
//				domain.setBlockType(resetDomain.getBlockType());
//				if (DomainsLogType.CANCEL_BILL.equals(domainsLogType)) {
//					domain.setPaymentEnd(new Date());
//				} else {
//					domain.setPaymentEnd(resetDomain.getPaymentEnd());	
//				}
////				domain.setPaymentStart(resetDomain.getPaymentStart());
////				domain.setTerm(resetDomain.getTerm());
////				domain.setPeriod(resetDomain.getPeriod());
//			}
//			
//			//--> ===== DOMAIN STATISTICS =====
//			/* Later, I may use this code.
//			domain.setGroupQuota(groupQuota);
//			domain.setTaskQuota(taskQuota);
//			*/
//			//<-- ===== DOMAIN STATISTICS =====
//			doMergeTransaction(mgr, domain);
////			doMergeTransaction(mgr, domain, domainLog);
//			if (isOverwrite) {
//				overwriteDomain(mgr, domain, isDefault);
//			}
//			
//			usageService.resetUsageCheckpoints(originDomain, domain);
//			
//			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
//			
//			return domain;
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr, prevNamespace);
//		}
//	}
	
	@Override
	public Map<String, Object> getDomainInfo(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		EntityManager mgr = getEntityManager();
		try {
			if (StringUtils.isBlank(domainName)) { return null; }
			Map<String, Object> domainInfoMap = new HashMap<String, Object>();
			
//			Domains domain = getDomainFromDefaultNamespace(domainName);
			Domains domain = doFindNoCache(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			valid(domain);
			// 도메인의 서비스 만료일이 없으면 DEFAULT_EXPIRATION_MONTH에 해당하는 일자를 도메인 생성일에 더하여 서비스 만료일을 정한다.
//			if (domain.getExpirationDate() == null) {
//				domain.setExpirationDate(CalendarUtil.addMonth(domain.getCreated(), CommonProperty.DEFAULT_EXPIRATION_MONTH));
//			}
			//usage = UsageService.getUsage(domainName); // from datastore Usage entity or memcache
			Usage usage = UsageService.summarizeUsageInfo(mgr, domainName); // from Domain statistics(__Stat_Ns_Total)
			
			domainInfoMap.put(FLD.domain, domain);
			domainInfoMap.put(FLD.usage, usage);
			
			return domainInfoMap;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public List<Users> updateAllDomainUserLowerId() throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<Users> resultList = new ArrayList<Users>();
			List<String> domainNames = listNamespaces();
			
			updateDomainUserLowerId(null);
			for (String domainName : domainNames) {
				List<Users> userList = updateDomainUserLowerId(mgr, domainName);
				resultList.addAll(userList);
			}
			return resultList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Deprecated
	@Override
	public List<Users> updateDomainUserLowerId(String domainName) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return updateDomainUserLowerId(mgr, domainName);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Deprecated
	private List<Users> updateDomainUserLowerId(EntityManager mgr, String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			TypedQuery<Users> query = new QueryBuilder<>(Users.class)
						.addClause(FLD.deleteYN, null)
						.addClause(FLD.archiveYN, null)
						.build(mgr);
			
			List<Users> results = query.getResultList();
			List<Users> userList = new ArrayList<Users>();

			for (Users user : results) {
				user.setLowerId(user.getId().toLowerCase());
				userList.add(user);
			}
			
			doMergeTransaction(mgr, userList);
			
			return userList;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public List<Domains> updateAllDomainCaseInsensitive(boolean caseInsensitive, boolean isDefault, boolean isOverwrite) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<String> domainNames = listNamespaces();
			List<Domains> resultList = new ArrayList<Domains>();
			
			for (String domainName : domainNames) {
				Domains domain = updateDomainCaseInsensitive(mgr, domainName, caseInsensitive, isDefault, isOverwrite);
				if (domain != null) {
					resultList.add(domain);
				}
			}
			return resultList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Deprecated
	@Override
	public Domains updateDomainCaseInsensitive(String domainName, boolean caseInsensitive, boolean isDefault,
			boolean isOverwrite) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return updateDomainCaseInsensitive(mgr, domainName, caseInsensitive, isDefault, isOverwrite);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Deprecated
	private Domains updateDomainCaseInsensitive(EntityManager mgr,
			String domainName, boolean caseInsensitive, boolean isDefault,
			boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			if (domain == null)  { return null; }
			
			DomainsLog domainLog = new DomainsLog(domain, DomainsLogType.UPDATE_CASE);
			domain.setCaseInsensitive(caseInsensitive);
			doMergeTransaction(mgr, domain);
//			doMergeTransaction(mgr, domain, domainLog);
			
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			try { domainsLogService.insertDomainsLog(domainLog); } catch (Exception ex) {}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public void permanentRemoveDomainUsers(String domainName, String userId) throws Exception{
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			userService.permanentRemoveUsers(userId);
			activityService.bulkRemoveActivities(null, null, null, null, userId);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public void permanentRemoveDefaultDomainUsers(String id) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			doRemoveTransaction(mgr, Users.class, KeyUtil.createUserKey(id));
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void bulkRemoveDomainActivities(String domainName, String boardId, String kindId, ActivityKind activityKind, ActivityType activityType, String userId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			activityService.bulkRemoveActivities(boardId, kindId, activityKind, activityType, userId);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public int bulkUpdateTaskTimelinesForModified(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		int resultCount = 0;
		try {
			TypedQuery<TaskTimelines> query = new QueryBuilder<>(TaskTimelines.class).build(mgr);

			List<TaskTimelines> taskTimelineList = queryResults(query);

			for (TaskTimelines taskTimeline : taskTimelineList) {
				taskTimeline.setModified(taskTimeline.getCreated());
				if (taskTimeline.getLastCommented() == null) { taskTimeline.setLastCommented(taskTimeline.getCreated()); }
				resultCount++;
			}
			doMergeTransaction(mgr, taskTimelineList);

			return resultCount;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public void sendRandomPassword(String domainName, String id, String email, String password) throws Exception {
		if (StringUtils.isEmpty(id)) {
			throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage("User ID should not be empty."));
		}
		
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		try {
			Users user = userService.getUsers(mgr, KeyUtil.createUserKeyString(id), false);
			valid(user);
			if (StringUtils.isBlank(password)) {
				password = KeyUtil.generateRandomPassword();
			}
			if (StringUtils.isBlank(email)) {
				email = user.getEmail();
			}
			user.setPasswordHash(password);
			user.setForcePasswordChangeYN(Y);
		
			//user.setPassword(password);
			doMergeTransaction(mgr, user);
			
			userService.sendRandomPassword(user, email, password);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public Map<String, Integer> updateAllActivitiesShow(Integer limit) throws Exception {
		List<String> domainNames = listNamespaces();
		Map<String, Integer> resultMap = new HashMap<String, Integer>();
		
		for (String domainName : domainNames) {
			int resultCount = updateActivitiesShow(domainName, limit);
			resultMap.put(domainName, resultCount);
		}
		return resultMap;
	}
	
	@Override
	public QueryResult<Activities> listActivities(
			String domainName,
			String cursorString,
			Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Activities> dsQuery = new DsQuery<>(Activities.class)
					.sort(FLD.created, SortDirection.DESC)
					.cursor(cursorString)
					.limit(limit);
			
			List<Activities> results = dsQuery.execute(mgr);
			return new QueryResult<Activities>(results, dsQuery.getCursor());
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public int updateActivitiesShow(String domainName, Integer limit) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			String cursorString = null;
			int updateCount = 0;
			while(true) {
				QueryResult<Activities> queryResults = queryAndUpdateActivities(cursorString, limit);
				
				cursorString = queryResults.getNextPageToken();
				updateCount += queryResults.getResultList().size();
				
				if (StringUtils.isBlank(cursorString) || queryResults.getResultList() == null) { break; }
				if (queryResults.getResultList().size() != limit) { break; }
			}
			
			LOG.warning("[INFO] : find " + updateCount + " entities.");
			return updateCount;
		} catch (Exception ex) {
			throw ex;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Deprecated
	private QueryResult<Activities> queryAndUpdateActivities(
			String cursorString,
			Integer limit
			) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Cursor cursor = null;
			
			TypedQuery<Activities> query = new QueryBuilder<>(Activities.class)
					.addClause(FLD.deleteYN, null)
					.addNullClause(FLD.modified)
					.build(mgr);

			if (StringUtils.isNotBlank(cursorString)) {
				cursor = Cursor.fromWebSafeString(cursorString);
				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
			}

			if (limit != null) {
				query.setFirstResult(0);
				query.setMaxResults(limit);
			}

			List<Activities> results = query.getResultList();
			cursor = JPACursorHelper.getCursor(results);

			for (Activities activity : results) {
				activity.setShow(activityService.isShowActivity(activity));
			}
			
			doMergeTransaction(mgr, results);
			
			return new QueryResult<Activities>(results, cursor);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Deprecated
	@Override
	public int bulkUpdateTasksForPublic(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		int resultCount = 0;
		try {
			TypedQuery<Tasks> query = new QueryBuilder<>(Tasks.class).build(mgr);

			List<Tasks> results = queryResults(query);
			List<Tasks> taskList = new ArrayList<Tasks>();
			
			for (Tasks task : results) {
				if (StringUtils.isBlank(task.getCloseYN())) {
					task.setCloseYN(N);
					taskList.add(task);
					resultCount++;
				}
			}
			doMergeTransaction(mgr, taskList);

			return resultCount;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@SuppressWarnings("deprecation")
	public Users assignUserAuth(String domainName, String userId, Auth auth) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			String role;
			
			switch (auth) {
				case ADMIN :
					role = Role.ADMIN;
					break;
				case MANAGER :
					role = Role.MANAGER;
					break;
				case SUPER :
					role = Role.SUPER;
					break;
				case MEMBER :
					role = Role.MEMBER;
					break;
				case GUEST :
					role = Role.GUEST;
					break;
				default :
					role = Role.DEFAULT_ROLE;
					break;
			}
			
			Users user = userService.getUsers(userId, true);
			user.setRole(role);
			
			return userService.updateUsers(user);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public void createAndRevokeAdminAll() throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			List<String> domainNames = listNamespaces();
			
			for (String domainName : domainNames) {
				createAndRevokeAdmin(mgr, domainName);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Deprecated
	@Override
	public void createAndRevokeAdmin(String domainName) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			createAndRevokeAdmin(mgr, domainName);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Deprecated
	private void createAndRevokeAdmin(EntityManager mgr, String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			String adminId = String.format(CommonProperty.ADMINID_FORMAT, domainName);
			String email = null;
			
			List<Users> results = listDomainUsers(domainName);
			List<Users> prevAdminList = new ArrayList<Users>();
			for (Users user : results) {
				if (user.isAdmin() && !adminId.equals(user.getId())) {
					user.setRole(Role.SUPER);
//					password = user.getPassword();
					email = user.getEmail();
					prevAdminList.add(user);
				}
			}
			
			Users admin = doFind(mgr, Users.class, KeyUtil.createUserKeyString(adminId));
			if (admin == null) {
				admin = domainService.assignAdmin(mgr, domainName, adminId, null, email, null, null);
			}
			
			if (admin != null) {
				doMergeTransaction(mgr, prevAdminList);
			}
			
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public Map<String, Map<String, String>> getAllUserEmailInfo() throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<String> domainList = listNamespaces();
			Map<String, Map<String, String>> domainUserEmailMap = new HashMap<String, Map<String, String>>();
			for (String domainName : domainList) {
				Map<String, String> userEmailMap = getDomainUserEmailInfo(mgr, domainName);
				domainUserEmailMap.put(domainName, userEmailMap);
			}
			return domainUserEmailMap;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public AdminEMailNotice insertAdminEMailNotice(AdminEMailNotice adminEMailNotice) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
//		LOG.warning("DB_oper_insertAdminEMailNotice : " + adminEMailNotice.getTitle());
//		LOG.warning("DB_oper_insertAdminEMailNotice : " + adminEMailNotice.getDescription());
		try {
			adminEMailNotice.setCreator(CommonProperty.SYSTEM_USER_ID);
			adminEMailNotice.setKey(KeyUtil.createAdminEMailNoticeKey());
			
			
			if (StringUtils.isBlank(adminEMailNotice.getDomainName())) { adminEMailNotice.setDomainName("ALL"); }
			
			if (contains(mgr, AdminEMailNotice.class, adminEMailNotice.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(AdminEMailNotice.class, adminEMailNotice.getAdminEMailNoticeId()));
			}
			
//			LOG.warning("DB_oper_insertAdminEMailNotice ** : " + adminEMailNotice.getDescription());
			doPersistTransaction(mgr, adminEMailNotice);
			
			return adminEMailNotice;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}	
		
	@Override
	public void permanentRemoveAdminEMailNotice(String adminEMailNoticeId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		EntityManager mgr = getEntityManager();
		
		try {
			doRemoveTransaction(mgr, AdminEMailNotice.class, adminEMailNoticeId);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public QueryResult<AdminEMailNotice> getAdminEMailNoticeList(String cursorString, Integer limit, boolean isDefault) throws Exception {
		EntityManager mgr = getEntityManager();
		
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);
		
		try {
			DsQuery<AdminEMailNotice> dsQuery = new DsQuery<>(AdminEMailNotice.class)
					.cursor(cursorString)
					.limit(limit);
				
			List<AdminEMailNotice> results = dsQuery.execute(mgr);
			QueryResult<AdminEMailNotice> queryResult = new QueryResult<AdminEMailNotice>(results, dsQuery.getCursor());
				
			if (isDefault) {
				return queryResult;
			} else {
				LOG.warning("getEmailNoticesInfo ++ is return NULL because of isDefault" + isDefault);
				
				return null;
			}

		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Map<String, String> getDomainUserEmailInfo(String domainName) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return getDomainUserEmailInfo(mgr, domainName);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private Map<String, String> getDomainUserEmailInfo(EntityManager mgr, String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			TypedQuery<Users> query = new QueryBuilder<>(Users.class).build(mgr);

			List<Users> results = queryResults(query);
			Map<String, String> userEmailMap = new HashMap<String, String>();
			
			for (Users user : results) {
				if (user.isActive()) {
					userEmailMap.put(user.getEmail(), user.getUserName());
				}
			}
			
			return userEmailMap;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public List<String> getDomainUserEmails(String domainName) throws Exception {
		List<Users> results = listDomainUsers(domainName);
		List<String> emails = new ArrayList<String>();
		
		for (Users user : results) {
			emails.add(user.getEmail());
		}
		
		return emails;
	}
	
	/* for Notice eMail */
	@Override
	public List<String> getDomainUserEmailsbyAdmin(String domainName) throws Exception {
		List<Users> results = listDomainUsers(domainName);
		List<String> emails = new ArrayList<String>();
		
		for (Users user : results) {
			//LOG.warning("getDomainUserEmailsbyAdmin: " + user.getRole());
			if ( user.getRole().equals(new String("admin")) )		
				emails.add(user.getEmail());
		}
		
		return emails;
	}
	
	private List<Users> listDomainUsers(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		
		try {
			return userService.listUsers(true, false);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public void sendAllNoticeEmail(List<String> domainNames, String subject, Text message) throws Exception {
		if (domainNames == null || domainNames.size() == 0) {
			domainNames = listNamespaces();
//			LOG.info("sendAllNoticeEmail():domainNames:" + domainNames);	// debug
		}
		
		for (String domainName : domainNames) {
			sendDomainNoticeEmail(domainName, subject, message, null);
//			LOG.debug("AdminService", "sendAllNoticeEmail()", "domainName" + domainNames);
		}
	}
	
	@Override
	public void sendAllNoticeEmailtoAdmin(List<String> domainNames, String subject, Text message) throws Exception {
		if (domainNames == null || domainNames.size() == 0) {
			domainNames = listNamespaces();
//			LOG.info("sendAllNoticeEmailtoAdmin():domainNames:" + domainNames);	 
		}
		
		for (String domainName : domainNames) {
			sendDomainNoticeEmailtoAdmin(domainName, subject, message, null);
//			LOG.debug("AdminService", "sendAllNoticeEmailtoAdmin()", "domainName" + domainNames);
		}
	}
	
	@Override
	public void sendDomainNoticeEmail(String domainName, String subject, Text message, List<String> emailList) throws Exception {
		if (StringUtils.isNotBlank(domainName) || emailList == null) {
//			LOG.warning("sendDomainNoticeEmail():domainName:" + domainName);		 
			emailList = getDomainUserEmails(domainName); 
//			LOG.warning("sendDomainNoticeEmail:emailList:" + emailList);
		}
		/* sendEmailQueue() ==> sendNoticeEmailQueue() 20170808 */
		
		SendEmail.sendNoticeEmailQueue(emailList, subject, message, CommonProperty.DEFAULT_EMAIL_QUEUE_NAME);
	}
	
	@Override
	public void sendDomainNoticeEmailtoAdmin(String domainName, String subject, Text message, List<String> emailList) throws Exception {
		if (StringUtils.isNotBlank(domainName) || emailList == null) {
//			LOG.warning("sendDomainNoticeEmailtoAdmin():domainName:" + domainName);		// for debug 
			emailList = getDomainUserEmailsbyAdmin(domainName); 
//			LOG.warning("sendDomainNoticeEmailtoAdmin:emailList:" + emailList);
		}
		/* sendEmailQueue() ==> sendNoticeEmailQueue() 20170808 */
		
		SendEmail.sendNoticeEmailQueue(emailList, subject, message, CommonProperty.DEFAULT_EMAIL_QUEUE_NAME);
	}
//	@SuppressWarnings("unused")
//	@Deprecated
//	private void sendDomainNoticeEmailQueue(String domainName, String subject, String message, List<String> emailList) throws Exception {
//		Queue queue = QueueFactory.getQueue(CommonProperty.NOTICE_EMAIL_QUEUE_NAME);
//		TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.NOTICE_EMAIL_SEND_URL);
//	
//		if (StringUtils.isNotBlank(domainName) || emailList == null) {
//			emailList = getDomainUserEmails(domainName);
//		}
//		taskOptions = taskOptions
//				.param(PARAM.SUBJECT, subject)
//				.param(PARAM.MESSAGE, message);
//		for (String email : emailList) {
//			taskOptions = taskOptions.param(PARAM.EMAIL, email);
//		}
//		
//		taskOptions = taskOptions.method(Method.POST);
//
//		queue.add(taskOptions);
//	}
	
	@Override
	public Domains changeDomainUseStorage(String domainName, boolean useStorage, boolean isDefault, boolean isOverwrite) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			domain.setUseStorage(useStorage);
			
			beginTransaction(mgr);
			domain = doMerge(mgr, domain);
			domain.setUseStorage(useStorage);
			commitTransaction(mgr);
			
			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			return domain;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public void initializeTaskImportance() throws Exception {
		List<String> domainNames = listNamespaces();
		HashMap<String, Object> initMap = new HashMap<String, Object>();
		initMap.put(FLD.importance, null);
		for (String domainName : domainNames) {
			initializeTaskImportance(domainName);
		}
	}
	
	@Deprecated
	@Override
	public void initializeTaskImportance(String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		try {
			TypedQuery<Tasks> query = new QueryBuilder<>(Tasks.class)
					.addClause(FLD.deleteYN, null)
					.addClause(FLD.archiveYN, null)
					.build(mgr);
		
		List<Tasks> results = query.getResultList();
		List<Tasks> objects = new ArrayList<Tasks>();
		
		for (Tasks obj : results) {
			obj.setImportance(null);
			//CopyUtil.init(obj, initMap);
			objects.add(obj);
		}
		
		doMergeTransaction(mgr, objects);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	@Override
	public <T extends Base> void initializeEntity(String domainName, String kind, HashMap<String, Object> initMap) throws Exception {
		Class<T> clazz = ClassUtil.findKIndClass(kind);
		
		initializeEntity(domainName, clazz, initMap);
	}
	private <T extends Base> void initializeEntity(String domainName, Class<T> clazz, HashMap<String, Object> initMap) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		try {
			TypedQuery<T> query = new QueryBuilder<>(clazz)
					.addClause(FLD.deleteYN, null)
					.addClause(FLD.archiveYN, null)
					.build(mgr);
		
		List<T> results = queryResults(query);
		List<T> objects = new ArrayList<T>();
		
		for (T obj : results) {
			CopyUtil.init(obj, initMap);
			objects.add(obj);
		}
		
		doMergeTransaction(mgr, objects);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	private void overwriteDomain(EntityManager mgr, Domains source, boolean isUserDomain) throws Exception {
		String prevNamespace = NamespaceManager.get();
		if (isUserDomain) { NamespaceManager.set(source.getDomainName());}
		else { NamespaceManager.set(null); }
		
		try {
			Domains target = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(source.getDomainName()));
			CopyUtil.merge(target, source, excludeProperties);
			doMergeTransaction(mgr, target);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public void overwriteToAllUserDomain() throws Exception {
		EntityManager mgr = getEntityManager();
		NamespaceManager.set(null);
		try {
			for (Domains defaultDomain : listAllDomains(mgr)) {
				overwriteToUserDomain(mgr, defaultDomain);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Deprecated
	public void overwriteToUserDomain(String domainName) throws Exception {
		EntityManager mgr = getEntityManager();
		NamespaceManager.set(null);
		try {
			Domains defaultDomain  = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName)); 
			overwriteToUserDomain(mgr, defaultDomain);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Deprecated
	private void overwriteToUserDomain(EntityManager mgr, Domains defaultDomain) throws Exception {
		overwriteDomain(mgr, defaultDomain, true);
	}
	
	@Override
	@Deprecated
	public void overwriteToAllDefaultDomain() throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<String> domainNames = listNamespaces();
			
			for (String domainName : domainNames) {
				overwriteToDefaultDomain(mgr, domainName);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Deprecated
	@Override
	public void overwriteToDefaultDomain(String domainName) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			overwriteToDefaultDomain(mgr, domainName);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Deprecated
	private void overwriteToDefaultDomain(EntityManager mgr, String domainName) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			overwriteToDefaultDomain(mgr, domain);
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Deprecated
	@Override
	public void overwriteToDefaultDomain(EntityManager mgr, Domains domain) throws Exception {
		overwriteDomain(mgr, domain, false);
	}
	
	@Override
	public Map<String, Object> listLastDomainAccess(Date accessDate) throws Exception {
		EntityManager mgr = getEntityManager();
		String prevNamespace = NamespaceManager.get();
		try {
			Map<String, Object> resultsMap = new HashMap<String, Object>();
			List<String> domains = listNamespaces();
			Map<String, String> access = new HashMap<String, String>();
			Map<String, String> noAccess = new HashMap<String, String>();
			for (String domain : domains) {
				NamespaceManager.set(domain);
				DsQuery<Activities> dsQuery = new DsQuery<>(Activities.class)
						.ge(FLD.created, accessDate)
						.sort(FLD.created, SortDirection.DESC)
						.limit(1);
				
				List<Activities> results = dsQuery.execute(mgr);
				if (results.size()==1) { access.put(domain, CalendarUtil.toString(results.get(0).getCreated())); }
				else { noAccess.put(domain,"-"); }
			}
			resultsMap.put("access", access);
			resultsMap.put("noAccess", noAccess);
			return resultsMap;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Domains enableDomainService(String domainName, Date paymentEnd, String reason) throws Exception {
		boolean isDefault = true;
		boolean isOverwrite = true;
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			domain.setBlockType(BlockType.AUTO);
			domain.setBlockReason(reason);
			domain.setExpirationDate(null);
			domain.setPaymentEnd(paymentEnd);	// 최종 결제일
			beginTransaction(mgr);
			domain = doMerge(mgr, domain);
			commitTransaction(mgr);

			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Domains disableDomainService(String domainName, Date expirationDate, String reason) throws Exception {
		boolean isDefault = true;
		boolean isOverwrite = true;
		String prevNamespace = NamespaceManager.get();
		if (isDefault) { NamespaceManager.set(null); }
		else {  NamespaceManager.set(domainName); }
		
		EntityManager mgr = getEntityManager();
		
		try {
			Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKey(domainName));
			
			domain.setBlockType(BlockType.BLOCK);
			domain.setBlockReason(reason);
			domain.setExpirationDate(expirationDate);
			beginTransaction(mgr);
			domain = doMerge(mgr, domain);
			commitTransaction(mgr);

			if (isOverwrite) {
				overwriteDomain(mgr, domain, isDefault);
			}
			
			return domain;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
//	@Override
//	public void testBuklInsertImages() {
//		NamespaceManager.set("MyDomain");
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			List<Images> images = new ArrayList<Images>();
//			for (int i=0; i < 1100; i++) {
//				Images image = new Images();
//				image.setKey(KeyFactory.createKey("Images", KeyUtil.UUID()));
//				image.setFileSize(i);
//				image.setCreated(new Date());
//				image.setCreator("ADMIN");
//				image.setFileName(String.valueOf(i));
//				image.setFilePath(String.valueOf(i));
//				image.setDeleteYN("N");
//				image.setArchiveYN("N");
//				
//				images.add(image);
//			}
//			
//			doPersistTransaction(mgr, images);
//		}finally {
//			finalizeTransaction(mgr);
//		}
//		
//	}
	
//	@Deprecated
//	public static void testFetchTimeCompareWithSingleManager() {
//		StopWatchUtil sw = new StopWatchUtil();
//		sw.start();
//		NamespaceManager.set(null);
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			for (int i=0; i < 100; i++) {
//				Domains domain = doFind(mgr, Domains.class, KeyUtil.createDomainKeyString("MyDomain"));
//				LOG.warning(domain.getDomainName());
//			}
//		} finally {
//			finalizeTransaction(mgr);
//			sw.stop();
//		}
//	}
//	
//	@Deprecated
//	public static void testFetchTimeCompareWithMultiManager() {
//		StopWatchUtil sw = new StopWatchUtil();
//		sw.start();
//		for (int i=0; i < 100; i++) {
//			Domains domain = getDomainFromDefaultNamespace("MyDomain");
//			LOG.warning(domain.getDomainName());
//		}
//		sw.stop();
//	}
	
//	@Deprecated
//	private Users updateUserPicture(String domainName, String userId, String pictureUrl) {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Users user = userService.getSimpleUsers(mgr, userId);
//			//user.setPictureUrl(pictureUrl);
//			doMergeTransaction(mgr, user);
//			
//			return user;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	
//	@Deprecated
//	private byte[] getUserImageToBytes(String domainName, String userId) throws Exception {
//		String prevNamespace = NamespaceManager.get();
//		try {
//			byte[] imageBytes = null;
//			if (StringUtils.isBlank(domainName) || StringUtils.isBlank(userId)) {
//				throw new Exception(ErrorCode.ILLEGAL_PARAMETER.getMessage("DomainName and userId are required."));
//			}
//			
//			NamespaceManager.set(domainName);
//			
//			Text userPicture = userService.getPicture(userId);
//			
//			if (userPicture != null && StringUtils.isNotBlank(userPicture.getValue())) {
//				byte[] bytes = Base64.decodeBase64(userPicture.getValue().split("^data:image/.+;base64,")[1]);
//				  
//				InputStream inStream = new ByteArrayInputStream(bytes);
//				imageBytes = IOUtils.toByteArray(inStream);
//				
//		        inStream.close();
//			}
//			return imageBytes;
//		} catch (Exception ex) {
//			LOG.warning("[User Picture Get Error] "+ex.getMessage());
//			throw ex;
//			//throw new IOException(ex.getMessage());
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
//	
//	@Deprecated
//	private GcsFilename uploadImageToGCS(String bucketName, byte[] images, String fileName) throws Exception {
//		try {
//			GcsFilename gcsFilename = new GcsFilename(bucketName, fileName);
//
//			//GcsFileOptions gcsFileOption = new GcsFileOptions.Builder().mimeType("image/jpeg").build();
//			GcsFileOptions gcsFileOption = GcsFileOptions.getDefaultInstance();
//
//			GcsOutputChannel outputChannel = gcsService.createOrReplace(
//					gcsFilename, gcsFileOption);
//	
//			copyToGCS(images, Channels.newOutputStream(outputChannel));
//			
//			return gcsFilename;
//		} catch (Exception ex) {
//			LOG.warning("uploadImageToGCS exception:" + ex.getMessage());
//			throw ex;
//		}
//	}
//	
//	@Deprecated
//	private void copyToGCS(byte[] b, OutputStream output) throws IOException {
//		try {
//			output.write(b);
//		} finally {
//			output.close();
//		}
//	}
//	
//	@Deprecated
//	@SuppressWarnings("unused")
//	private void copyToGCS(InputStream input, OutputStream output)
//			throws IOException {
//		try {
//			byte[] buffer = new byte[4096];
//			int bytesRead = input.read(buffer);
//			while (bytesRead != -1) {
//				output.write(buffer, 0, bytesRead);
//				
//				bytesRead = input.read(buffer);
//			}
//		} finally {
//			input.close();
//			output.close();
//		}
//	}
	
//	@Deprecated
//	public List<Users> relocationDomainUsersImageToGCS(String bucket, String domainName, int imageSize) throws Exception {
//		String prevNamespace = NamespaceManager.get();
//		NamespaceManager.set(domainName);
//		
//		try {
//			QueryResult<Users> users = userService.listUsers(null, null, null);
//			List<Users> results = users.getResultList();
//			List<Users> userList = new ArrayList<Users>();
//			
//			for (Users user : results) {
//				user = relocationUserImageToGCS(bucket, domainName, user.getUserId(), imageSize);
//				if (user != null) { userList.add(user); }
//			}
//			
//			return userList;
//		} finally {
//			NamespaceManager.set(prevNamespace);
//		}
//	}
//	
//	@Deprecated
//	@Override
//	public Users relocationUserImageToGCS(String bucket, String domainName, String userId, int imageSize) {
//		try {
//			if (StringUtils.isEmpty(bucket)) { bucket = GcsSignedUrlUtil.DEV_BUCKET_NAME; }
//			byte[] imageBytes = getUserImageToBytes(domainName, userId);
//			if (imageBytes == null) { return null; }
//			
//			GcsFilename gcsFilename = uploadImageToGCS(bucket, imageBytes, userId);
//			
//			String pictureUrl = imageService.getServingUrl(gcsFilename.getBucketName(), gcsFilename.getObjectName(), imageSize);
//			Users user = updateUserPicture(domainName, userId, pictureUrl);
//			return user;
//		} catch (Exception ex) {
//			LOG.warning(ex.getMessage());
//			return null;
//		}
//	}
//
	
//	@Deprecated
//	@SuppressWarnings("unused")
//	private void testURLFileRead(String urlStr) throws Exception {
//		try {
//		    URL url = new URL(urlStr);
//		   		    
//		    BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
//		    String line;
//
//		    
//		    LOG.warning(urlStr);
//		    
//		    while ((line = reader.readLine()) != null) {
//		        // ...
//		    	LOG.warning(line);
//		    }
//		    reader.close();
//
//		} catch (MalformedURLException e) {
//		    throw e;
//		} catch (IOException e) {
//		     throw e;
//		}
//	}
	 
}