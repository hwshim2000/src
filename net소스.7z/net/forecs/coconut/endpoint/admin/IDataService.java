package net.forecs.coconut.endpoint.admin;

import java.util.List;
import java.util.Map;

import net.forecs.coconut.common.code.IndexKind;
import net.forecs.coconut.common.code.Kind;
import net.forecs.coconut.endpoint.common.ICommonService;

import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;

public interface IDataService extends ICommonService {
	public abstract void removeKindData(String namespace, String kind);
	public abstract void removeNamespace(String namespace);
	public abstract void removeAllNamespace(boolean includeDefault);
	
	public abstract void removeIndex(String namespace, String indexName);
	public abstract void removeNamespaceIndex(String namespace);
	
	public abstract void removeAllIndex();
	public abstract void recreateAllIndex() throws Exception;
	
	public abstract void removeIndexSchema(String namespace, String indexName);
	public abstract void removeNamespaceIndexSchema(String namespace);
	
	public abstract void recreateNamespaceIndex(String namespace) throws Exception;
	
	public abstract void recreateTaskIndex(String namespace);
	
	//public abstract void recreateUserIndex(String namespace);
	public abstract void recreateCommentIndex(String namespace);
	public abstract void recreateTimelineIndex(String namespace);
	public abstract void recreateNoticeIndex(String namespace);
	public abstract void recreateEventIndex(String namespace);
	
	//public abstract void recreateChecklistHistoryIndex(String namespace);
	//public abstract void recreateChecklistIndex(String namespace);
	public abstract void recreateAttachmentIndex(String namespace);
	
	public abstract Map<String, List<String>> findUnavailableAllNamespaceData(String namespace, boolean remove) throws Exception;
	public abstract List<String> findUnavailableNamspaceData(String namespace, Kind kind, boolean remove) throws Exception;
	public abstract Map<String, String> removeUnavailableNamspaceData(String namespace, List<String> keys) throws Exception;
	
	public abstract List<Entity> getEntity(String namespace, List<String> keys) throws EntityNotFoundException;
	
	
	public abstract void invokeRecreateAllIndex(IndexKind indexKind);
	public abstract void invokeRecreateNamespaceIndex(String namespace);
	public abstract void invokeRecreateIndex(String namespace, IndexKind indexKind);
}
