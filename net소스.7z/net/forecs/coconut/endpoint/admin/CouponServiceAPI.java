package net.forecs.coconut.endpoint.admin;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.TermType;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.billing.Coupons;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;

@Api(name = API.ADMIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ADMIN_SERVICE_PACKAGE), description = "admin", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class CouponServiceAPI {
	private final ICouponService couponService;
	
	@Inject
	public CouponServiceAPI(ICouponService couponService) {
		this.couponService = couponService;
	}
	
	@ApiMethod(name = "listCoupons", path = "coupons", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public CollectionResponse<Coupons> listCoupons(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.domainName) String domainName,
			@Nullable @Named(FLD.useYN) String useYN,
			@Nullable @Named(FLD.issueYN) String issueYN,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		QueryResult<Coupons> result = couponService.listCoupons(cursorString, limit, domainName, useYN, issueYN);
		return CollectionResponse.<Coupons>builder().setItems(result.getResultList()).setNextPageToken(result.getNextPageToken()).build();
	}
	
	@ApiMethod(name = "createCoupons",  path = "coupons", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<Coupons> createCoupons(
			@Named(FLD.serviceType) ServiceType serviceType,
			@Nullable @Named(FLD.userQuota) Long userQuota,
			@Nullable @Named(FLD.storageQuota) Long storageQuota,
			@Nullable @Named(FLD.boardQuota) Long boardQuota,
			@Named(FLD.validDate) Date validDate,
			@Nullable @Named(FLD.termType) TermType termType,
			@Nullable @Named(FLD.term) Integer term,
			@Nullable @Named(FLD.expirationDate) Date expirationDate,
			@Named(FLD.couponCount) int couponCount,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return couponService.createCoupons(serviceType, userQuota, storageQuota, boardQuota, validDate, termType, term, expirationDate, couponCount);
	}
	
	@ApiMethod(name = "validCoupon",  path = "coupons/valid/{couponCode}", httpMethod = HttpMethod.GET)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Result isValidCoupon(@Named(FLD.couponCode) String couponCode,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return new Result(couponService.isValidCoupon(couponCode));
	}
	
	@ApiMethod(name = "registCoupon",  path = "coupons/regist/{couponCode}", httpMethod = HttpMethod.POST)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Coupons registCoupon(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.couponCode) String couponCode,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return couponService.registCoupon(domainName, couponCode);
	}
	
	@ApiMethod(name = "revokeCoupon",  path = "coupons/revoke/{couponCode}", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Coupons revokeCoupon(
			@Named(FLD.domainName) String domainName,
			@Named(FLD.couponCode) String couponCode,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return couponService.revokeCoupon(domainName, couponCode);
	}
	
	@ApiMethod(name = "issueCoupons",  path = "coupons/issue", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public List<Coupons> issueCoupons(
			@Named(FLD.couponCode) List<String> couponCodes,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return couponService.issueCoupons(couponCodes);
	}
	
	@ApiMethod(name = "issueCoupon",  path = "coupons/issue/{couponCode}", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Coupons issueCoupon(
			@Named(FLD.couponCode) String couponCode,
			@Named(FLD.issuer) String issuer,
			@Named(FLD.issueTarget) String issueTarget,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return couponService.issueCoupon(couponCode, issuer, issueTarget);
	}
	
	@ApiMethod(name = "updateIssuer",  path = "coupons/issuer", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Coupons updateIssuer(
			@Named(FLD.couponCode) String couponCode,
			@Named(FLD.issuer) String issuer,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return couponService.updateIssuer(couponCode, issuer);
	}
	
	@ApiMethod(name = "updateIssueTarget",  path = "coupons/issueTarget", httpMethod = HttpMethod.PUT)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public Coupons updateIssueTarget(
			@Named(FLD.couponCode) String couponCode,
			@Named(FLD.issueTarget) String issueTarget,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		return couponService.updateIssueTarget(couponCode, issueTarget);
	}
	
	@ApiMethod(name = "permanentRemoveCoupon",  path = "coupons/{couponCode}", httpMethod = HttpMethod.DELETE)
	@RequiresToken( scope = Scope.ADMIN, accessToken = "{accessToken}" )
	public void permanentRemoveCoupon(
			@Named(FLD.couponCode) String couponCode,
			@Named(FLD.accessToken) String accessToken) throws Exception {
		couponService.permanentRemoveCoupons(couponCode);
	}
}
