package net.forecs.coconut.endpoint.admin;

import java.util.List;

import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;

public interface IEmoticonService extends IAdminCommonService {
	public abstract String getEmoticonUploadUrl(String filePath, String contentType, Integer expiresIn) throws Exception;
	
	public abstract QueryResult<Emoticons> queryEmoticons(
			String cursorString,
			Integer limit,
			String domainName,
			SortType sortType,
			SortDirection sortDirection
			) throws Exception;
	public abstract Emoticons getEmoticons(String emoticonId) throws Exception;
	public abstract List<Emoticons> listEmoticons(List<String> emoticonIds) throws Exception;
	public abstract Emoticons insertEmoticons(Emoticons emoticons) throws Exception;
	public abstract Emoticons updateEmoticons(Emoticons emoticons) throws Exception;
	public abstract void removeEmoticons(String emoticonId) throws Exception;
	@Deprecated
	public abstract List<Images> insertEmoticonImagesFromGCS(
			Emoticons emoticons, String serviceHost, String bucket, String filePath,
			List<String> fileNames, int imageSize) throws Exception;
	@Deprecated
	public abstract List<Images> appendEmoticonImagesFromGCS(String emoticonId,
			String serviceHost, String bucket, String filePath,
			List<String> fileNames, int imageSize) throws Exception;
}
