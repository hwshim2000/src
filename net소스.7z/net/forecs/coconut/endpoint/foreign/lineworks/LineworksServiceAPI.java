package net.forecs.coconut.endpoint.foreign.lineworks;

import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.common.util.rest.JerseyLineClient;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;

@Api(name = API.FOREIGN_SERVICE, version = API.VERSION, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.FOREIGN_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class LineworksServiceAPI {
	
	@ApiMethod(name = "lineworksServiceLoginCheck", path = "foreign/service/lineworks/login", httpMethod = HttpMethod.POST)
	public Result lineworksServiceLogin(HttpServletRequest request, @Named(FLD.email) String email) throws Exception {
		Users user = CommonService.getCurrentUser();
		if (user == null) { return new Result(false); }
		if (StringUtils.equals(user.getId(), email)) { return new Result(true); }
		return new Result(false);
	}
	
	@ApiMethod(name = "getLineworksAccessToken", path = "foreign/service/lineworks/accessToken/{code}", httpMethod = HttpMethod.GET)
	public Result getLineworksAccessToken(HttpServletRequest request, @Named(FLD.code) String code) throws Exception {
		String accessToken = JerseyLineClient.getAccessToken(code);
		return new Result(accessToken);
	}

	@ApiMethod(name = "getLineworksUserInfo", path = "foreign/service/lineworks/userInfo", httpMethod = HttpMethod.GET)
	public Result getLineworksUserInfo(HttpServletRequest request, @Named(FLD.accessToken) String accessToken) throws Exception {
		String userInfo = JerseyLineClient.getUserInfo(accessToken);
		return new Result(userInfo);
	}

}
