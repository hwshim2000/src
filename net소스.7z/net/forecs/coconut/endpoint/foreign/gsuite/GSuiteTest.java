package net.forecs.coconut.endpoint.foreign.gsuite;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.List;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.appengine.datastore.AppEngineDataStoreFactory;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.admin.directory.Directory;
import com.google.api.services.admin.directory.DirectoryScopes;
import com.google.api.services.admin.directory.model.Group;
import com.google.api.services.admin.directory.model.Groups;
import com.google.api.services.admin.directory.model.Member;
import com.google.api.services.admin.directory.model.Members;
import com.google.api.services.admin.directory.model.User;
import com.google.api.services.admin.directory.model.Users;
import com.google.api.services.groupssettings.Groupssettings;
import com.google.api.services.groupssettings.GroupssettingsScopes;


@Deprecated
public class GSuiteTest {
    /** Application name. */
    private static final String APPLICATION_NAME =
        "Directory API Java Quickstart";

    /** Directory to store user credentials for this application. */
    private static final java.io.File DATA_STORE_DIR = new java.io.File(
        System.getProperty("user.home"), ".credentials/admin-directory_v1-java-quickstart");
    
    private static final AppEngineDataStoreFactory DATA_STORE_FACTORY = AppEngineDataStoreFactory
			.getDefaultInstance();

    /** Global instance of the {@link FileDataStoreFactory}. */
    //private static FileDataStoreFactory DATA_STORE_FACTORY;

    /** Global instance of the JSON factory. */
    private static final JsonFactory JSON_FACTORY =
        JacksonFactory.getDefaultInstance();

    /** Global instance of the HTTP transport. */
    private static HttpTransport HTTP_TRANSPORT;

    /** Global instance of the scopes required by this quickstart.
     *
     * If modifying these scopes, delete your previously saved credentials
     * at ~/.credentials/admin-directory_v1-java-quickstart
     */
    private static final List<String> SCOPES =
        Arrays.asList(DirectoryScopes.ADMIN_DIRECTORY_USER
        		, DirectoryScopes.ADMIN_DIRECTORY_GROUP
        		, GroupssettingsScopes.APPS_GROUPS_SETTINGS);

    static {
        try {
            HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
           // DATA_STORE_FACTORY = new FileDataStoreFactory(DATA_STORE_DIR);
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * Creates an authorized Credential object.
     * @return an authorized Credential object.
     * @throws IOException
     */
    public static Credential authorizeByInstalledApp() throws IOException {
        // Load client secrets.
        InputStream in =
        		GSuiteTest.class.getResourceAsStream("/client_secrets.json");
        GoogleClientSecrets clientSecrets =
            GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

        // Build flow and trigger user authorization request.
        GoogleAuthorizationCodeFlow flow =
                new GoogleAuthorizationCodeFlow.Builder(
                        HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
                .setDataStoreFactory(DATA_STORE_FACTORY)
                .setAccessType("offline")
                .build();
      //  GoogleAuthorizationCodeRequestUrl uri = flow.newAuthorizationUrl().setRedirectUri("http://localhost:8888/oauth2callback");
        LocalServerReceiver localReceiver = new LocalServerReceiver.Builder().setPort(8888).build();
       // LocalServerReceiver localReceiver = new LocalServerReceiver();
      //  System.out.println("Receiver uri:"+receiver.getRedirectUri());
        Credential credential = new AuthorizationCodeInstalledApp(
            flow, localReceiver).authorize("user");
        System.out.println(
                "Credentials saved to " + DATA_STORE_DIR.getAbsolutePath());
        return credential;
    }
    
    public static Credential authorizeByAccessToken(String accessToken) throws IOException {
		Credential credential = null;
		try { 
			credential = new GoogleCredential().setAccessToken(accessToken);
			
			System.out.println(credential.getAccessToken());
			credential.refreshToken();
			System.out.println(credential.getAccessToken());
		} catch (Exception ex) {
			ex.printStackTrace();
		};
		
		return credential;
	}

    // 참조 : https://developers.google.com/admin-sdk/directory/v1/guides/delegation
    // 참조 : https://developers.google.com/api-client-library/java/google-api-java-client/oauth2
    // 이함수를 실행하기 위해서는 credential을 먼저 만들고, sevice account key (p12)파일을 만들고
    // Oauth client를 만든뒤에 해당 계정에서 p12파일을 내려 받은뒤 등록
    // 단, 이 서비스를 이용하기 위해서는 해당 domain의 security 옵션에 해당 client id와 접근할 수 있는 서비스 경로를 등록해 주어야 하며,(https://admin.google.com/AdminHome?chromeless=1#OGX:ManageOauthClients)
    // accountUser도 해당 서비스 경로에 접근할 수 있는 권한을 가지고 있어야 한다.
    // 활용할 수 있는 곳은.. 사용자의 현재 로그인 세션과 무관하게, 해당 유저로 서비스에 접근하여 작업을 할 필요성이 있을 때, 유용하다.
    // 예로, 해당 도메인의 최상의 관리자로, 특정 사용자의 owner변경이라든가 리소스 접근 및 사용자 콘트롤등이 필요한 action이 있을 때, 등등
    public static GoogleCredential authorizeByServiceAccounts() throws IOException, GeneralSecurityException {
    	HttpTransport httpTransport = new NetHttpTransport();
    	  JacksonFactory jsonFactory = new JacksonFactory();
    	  GoogleCredential credential = new GoogleCredential.Builder()
    	      .setTransport(httpTransport)
    	      .setJsonFactory(jsonFactory)
    	      .setServiceAccountId("g-suite-admin@cocoworks-for-ecs.iam.gserviceaccount.com")
    	      .setServiceAccountScopes(SCOPES)
    	      .setServiceAccountUser("hyeunwoo.shim@forecs.net")
    	      .setServiceAccountPrivateKeyFromP12File(
    	          new java.io.File(GSuiteAuth.PRIVATE_KEY_FILE))
    	      .build();
    	 
    	System.out.println(credential.getAccessToken());
    	return credential;
    }
    /**
     * Build and return an authorized Admin SDK Directory client service.
     * @return an authorized Directory client service
     * @throws IOException
     */
    public static Directory getDirectoryServiceByInstalledApp() throws IOException {
        Credential credential = authorizeByInstalledApp();
        return new Directory.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }
    
    public static Directory getDirectoryServiceByAccessToken() throws IOException {
        Credential credential = authorizeByAccessToken("ya29.GlsmBMIH8tt4qESMdRIUhHcw-EQ5uCVXZPffo9VbZaf75wB19fRPVBxEVfdYtImXx26OVgmjhhZQfM5r11XwbWGxx9Ljhcna8nQ9EYoi4RP55XYK61esa5frKTv4");
       // Credential credential = authorizeByAccessToken("ya29.GlsmBOcDQmUshHTVepzyYa10Eb-j2QFcqtSK1tvhxiQRx8glF4v-rxD0Q1MbSmxrA94irJKCRv2GNYlE0OhIyWI-pQVW9-qEoHt77KeKC_FWw269V_UuVywbFVqH");
        return new Directory.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }

    public static Directory getDirectoryServiceByServiceAccounts() throws IOException, GeneralSecurityException {
        GoogleCredential credential = authorizeByServiceAccounts();
        
        System.out.println("ACCESS-TOKEN : " + credential.getAccessToken());
        
        return new Directory.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, null)
        		.setHttpRequestInitializer(credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }
   
    public static Groupssettings getGroupssettingServiceByServiceAccounts() throws IOException, GeneralSecurityException {
        GoogleCredential credential = authorizeByServiceAccounts();

        System.out.println("ACCESS-TOKEN : " + credential.getAccessToken());
        
        return new Groupssettings.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, null)
        		//.setGroupssettingsRequestInitializer(credential)
        		.setHttpRequestInitializer(credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }

    
    public static List<User> listUsersByInstalledApp() throws IOException {
    	// Build a new authorized API client service.
        Directory service = getDirectoryServiceByInstalledApp();

        
        // TODO : 이부분에서 에러 발생하는듯... 도메인의 delegation을 체크해봐야할듯
        // Print the first 10 users in the domain.
        Users result = service.users().list()
             //.setCustomer("forecs.net")
             .setDomain("forecs.net")
             .setMaxResults(10)
             .setOrderBy("email")
             .execute();
        List<User> users = result.getUsers();
        if (users == null || users.size() == 0) {
            System.out.println("No users found.");
        } else {
            System.out.println("Users:");
            for (User user : users) {
                System.out.println(user.getName().getFullName());
            }
        }
        return users;
    }
    
    public static void listUsersByAccessToken() throws IOException {
    	// Build a new authorized API client service.
        Directory service = getDirectoryServiceByAccessToken();

        
        // TODO : 이부분에서 에러 발생하는듯... 도메인의 delegation을 체크해봐야할듯
        // Print the first 10 users in the domain.
        try {
	        Users result = service.users().list()
	             //.setCustomer("forecs.net")
	             .setDomain("forecs.net")
	             .setMaxResults(10)
	             .setOrderBy("email")
	             .execute();
	        
	        List<User> users = result.getUsers();
	        if (users == null || users.size() == 0) {
	            System.out.println("No users found.");
	        } else {
	            System.out.println("Users:");
	            for (User user : users) {
	                System.out.println(user.getName().getFullName());
	            }
	        }
	        //return users;
        } catch (Exception ex) {
        	System.out.println("Users access exception : " + ex.getMessage());
        }
        
        try {
	        
	        Groups groupResult = service.groups().list().setDomain("forecs.net").setMaxResults(10).execute();
	        List<Group> groups = groupResult.getGroups();
	        
	        if (groups == null || groups.size() == 0) {
	            System.out.println("No group found.");
	        } else {
	            System.out.println("Group:");
	            for (Group group : groups) {
	            	System.out.println(group.getName());
	            }
	        }
	        
	        System.out.println(service.groups().get("all@forecs.net")==null?"NULL":"OK");
        } catch (Exception ex) {
        	System.out.println("Users access exception : " + ex.getMessage());
        }
        
    }
    
    public static List<User> listUsersByServiceAccounts() throws IOException, GeneralSecurityException {
    	// Build a new authorized API client service.
        Directory service = getDirectoryServiceByServiceAccounts();

        
        // TODO : 이부분에서 에러 발생하는듯... 도메인의 delegation을 체크해봐야할듯
        // Print the first 10 users in the domain.
        Users result = service.users().list()
             //.setCustomer("forecs.net")
             .setDomain("forecs.net")
             .setMaxResults(10)
             .setOrderBy("email")
             .execute();
        List<User> users = result.getUsers();
        if (users == null || users.size() == 0) {
            System.out.println("No users found.");
        } else {
            System.out.println("Users:");
            for (User user : users) {
                System.out.println(user.getName().getFullName());
            }
        }
        return users;
    }
    
    public static void listGroupByServiceAccounts() throws IOException, GeneralSecurityException {
    	// Build a new authorized API client service.
        Directory service = getDirectoryServiceByServiceAccounts();
        
        Groups groups = service.groups().list().setDomain("forecs.net").execute();
     
        for (Group group : groups.getGroups()) {
        	System.out.println("==================================");
        	System.out.println(group.toPrettyString());
        	 Members members = service.members().list(group.getId()).execute();
        	 if (members.getMembers() == null) continue;
             for (Member member : members.getMembers()) {
             	System.out.println("\t-------------------------");
             	System.out.println("\t"+member.toPrettyString());
             }
        }
    }
    public static void createGroupByServiceAccounts() throws IOException, GeneralSecurityException {
    	// Build a new authorized API client service.
        Directory service = getDirectoryServiceByServiceAccounts();
        
        // TODO : 이부분에서 에러 발생하는듯... 도메인의 delegation을 체크해봐야할듯
        // Print the first 10 users in the domain.
        Group group = new Group();
        group.setEmail("BoardGroupTest1@forecs.net");
        group.setName("Board Group Test1");
        group.setDescription("Test creation group");
        
        group = service.groups().insert(group).execute();
     
        
        System.out.println(group);
        System.out.println(group.getId());
        System.out.println(group.getKind());
        System.out.println(group.getName());
        System.out.println(group.getAliases());
        System.out.println(group.getEtag());
        System.out.println(group.getDirectMembersCount());
        System.out.println(group.toPrettyString());
        
        Members members = service.members().list(group.getId()).execute();
        if (members.getMembers() != null) {
	        for (Member member : members.getMembers()) {
	        	System.out.println("-------------------------");
	        	System.out.println(member.getEmail() + "/" + member.getId() + "/" + member.getRole());
	        }
        }
    }
    
    public static void getGroupssettingByServiceAccounts(String groupEmailAddress) throws IOException, GeneralSecurityException {
    	// Build a new authorized API client service.
        Groupssettings service = getGroupssettingServiceByServiceAccounts();
        
        com.google.api.services.groupssettings.model.Groups settingGroup = service.groups().get(groupEmailAddress).execute();
     
        System.out.println(settingGroup.toPrettyString());
    }
    
    public static void deleteGroupByServiceAccounts() throws IOException, GeneralSecurityException {
    	Directory service = getDirectoryServiceByServiceAccounts();
    	service.groups().delete("00lnxbz94hbi4qd").execute();
    }
    
    public static void main(String[] args) throws IOException, GeneralSecurityException {
    	listGroupByServiceAccounts();
    	//createGroupByServiceAccounts();
    	//deleteGroupByServiceAccounts();
    	//getGroupssettingByServiceAccounts("test2@forecs.net");
    	
    	//listUsersByInstalledApp();
    	//listUsersByAccessToken();
    	//listUsersByServiceAccounts();
    }

}