package net.forecs.coconut.endpoint.foreign.gsuite;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import net.forecs.coconut.common.code.UserType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.user.Role;

import com.google.api.services.admin.directory.model.User;
import com.google.api.services.admin.directory.model.Users;

@Deprecated
public class GSuiteService extends CommonService implements IGSuiteService {
	//private static final Logger LOG = Logger.getLogger(GSuiteService.class.getName());
	
	private final IDomainService domainService;
	
	@Inject
	public GSuiteService(IDomainService domainService) {
		this.domainService = domainService;
	}
	private static GSuiteDirectory getDirectory() throws Exception {
	//	return new GSuiteDirectory(getCurrentDomain());
		return new GSuiteDirectory("forecs.net", "hyeunwoo.shim@forecs.net", "C00xz7pch");
	}
	
	@Override
	public Users queryUsers(String nextPageToken, Integer limit) throws Exception {
		GSuiteDirectory directory = getDirectory();
		Users users = directory.queryUsers(nextPageToken, limit, "false");
		return users;
	}
	@Override
	public Users queryDeletedUsers(String nextPageToken, Integer limit) throws Exception {
		GSuiteDirectory directory = getDirectory();
		Users users = directory.queryUsers(nextPageToken, limit, "true");
		return users;
	}
	@Override
	public User getUser(String userKey) throws Exception {
		return getUser(getDirectory(), userKey);
	}
	private User getUser(GSuiteDirectory directory, String userKey) throws Exception {
		return directory.getUser(userKey);
	}
	@Override
	public Users listUsers(List<String> userKeys) throws Exception {
		GSuiteDirectory directory = getDirectory();
		List<User> userList = new ArrayList<User>();
		for (String userKey : userKeys) {
			User user = getUser(directory, userKey);
			//if (user != null && user.getSuspended()) {
				userList.add(user);
			//}
		}
		Users users = new Users();
		users.setUsers(userList);
		return users;
	}
	@Override
	public void syncAllGSuiteUsers() throws Exception {
		syncAvailableUsers();
		syncUnavailableUsers();
	}
	@Override
	public List<net.forecs.coconut.entity.user.Users> syncAvailableUsers(List<String> userKeys) throws Exception {
		Users users = new Users();
		List<User> userList = new ArrayList<User>();
		for (String userKey : userKeys) {
			User gsUser = getUser(userKey);
			if (gsUser != null) { userList.add(gsUser); }
		}
		users.setUsers(userList);
		return syncAvailableUsers(users);
	}
	@Override
	public List<net.forecs.coconut.entity.user.Users> syncAvailableUsers() throws Exception {
		Users users = queryUsers(null, null);
		return syncAvailableUsers(users);
	}
	
	private List<net.forecs.coconut.entity.user.Users> syncAvailableUsers(Users users) throws Exception {
		List<net.forecs.coconut.entity.user.Users> userList = new ArrayList<net.forecs.coconut.entity.user.Users>();
		Domains domain = getCurrentDomain();
		net.forecs.coconut.entity.user.Users loginUser = (net.forecs.coconut.entity.user.Users)ShiroUtils.getCurrentUser();

		for (User gsUser : users.getUsers()) {
			net.forecs.coconut.entity.user.Users coUser = assignDomainUser(domain, gsUser, loginUser.getUserId());
			if (coUser != null) { userList.add(coUser); }
		}
		return userList;
	}
	@Override
	public void syncUnavailableUsers() throws Exception {
		Users users = queryDeletedUsers(null, null);
		for (User gsUser : users.getUsers()) {
			domainService.unassignMember(KeyUtil.createUserKeyString(gsUser.getPrimaryEmail()));
		}
	}
	
	@SuppressWarnings("unused")
	private net.forecs.coconut.entity.user.Users assignDomainUser(String userKey) throws Exception {
		User gsUser = getUser(userKey);
		
		if (gsUser == null) {
			throw new Exception(ErrorCode.ENTITY_NOT_FOUND.getMessage(userKey));
		}
		
		Domains domain = getCurrentDomain();
		net.forecs.coconut.entity.user.Users loginUser = (net.forecs.coconut.entity.user.Users)ShiroUtils.getCurrentUser();
		
		return assignDomainUser(domain, gsUser, loginUser.getUserId());
	}
	
	private net.forecs.coconut.entity.user.Users assignDomainUser(Domains domain, User gsUser, String loginUserId) throws Exception {
		net.forecs.coconut.entity.user.Users coUser = new net.forecs.coconut.entity.user.Users();
		coUser.setId(gsUser.getPrimaryEmail());
		coUser.setUserName(gsUser.getName().getFullName());
		coUser.setEmail(gsUser.getPrimaryEmail());
		coUser.setDomainName(domain.getDomainName());
		if (gsUser.getIsAdmin() && gsUser.getPrimaryEmail().equalsIgnoreCase(domain.getGsuiteServiceAccount())) {
			coUser.setRole(Role.ADMIN);
		} else {
			coUser.setRole(Role.MEMBER);
		}
		
		coUser.setUserType(UserType.DOMAIN);
		coUser.setForcePasswordChangeYN(N);
		coUser.setConfirmYN(Y);
		coUser.setCreator(loginUserId);
		coUser.setActive(!gsUser.getSuspended());
		coUser.setPassword(KeyUtil.generateRandomPassword());
		coUser.setPictureURL(gsUser.getThumbnailPhotoUrl());
		
		return domainService.assignOrOverwriteMember(domain, coUser, true, loginUserId);
	}
	@Override
	public boolean verifiedDomain() {
		Domains domain = getCurrentDomain();
		return verifiedDomain(domain.getDomainName(), domain.getGsuiteServiceAccount(), domain.getGsuiteCustomerID());
	}
	@Override
	public boolean verifiedDomain(String domainName, String gsuiteServiceAccount, String gsuiteCustomerId) {
		try {
			GSuiteDirectory gsDirectory = new GSuiteDirectory(domainName, gsuiteServiceAccount, gsuiteCustomerId);
			return gsDirectory.verifiedCustomer() && gsDirectory.verifiedDomain();
		} catch (Exception ex) {
			return false;
		}
	}
	

//	public static void main(String[] args) throws Exception {
//		GSuiteService gsService = new GSuiteService();
//		
//		Users result = gsService.queryUsers(null, null);
//		System.out.println(result.toPrettyString());
//
//		List<User> users = result.getUsers();
//		
//		if (users == null || users.size() == 0) {
//			System.out.println("No users found.");
//		} else {
//			System.out.println("Users:");
//			for (User user : users) {
//				System.out.println(user.getName().getFullName() + ":" + (user.getIsAdmin()?"admin":"member"));
//			}
//		}
//	}
	
//	public static void main(String[] args) throws Exception {
//		String domainName = "forecs.net";
//		//String accountUser = "hyeunwoo.shim@forecs.net";
//		String accountUser = "jisu.shim@forecs.net";
////		String calendarId = "forecs.net_v8gfugl92e54op7ejbp44aeib0@group.calendar.google.com";
//		String calendarId = "jisu.shim@forecs.net";
//		String eventId = "tdfkcmi1gifbltmmvdtgijo5ek";
//		
//		GSuiteService service = new GSuiteService(domainName, accountUser);
////		service.calendarService.calendarList();
//		service.listEvent(calendarId);
//		service.getEvent(calendarId, "6moc2n393n69ng4bj85rdjfin8");
//		
//		
////		Calendar calendar = new Calendar();
////		calendar.setDescription("Test calendar for test 01");
////		calendar.setSummary("Test Group Calendar 01");
////		calendar.setTimeZone("Asia/Seoul");
////		service.insertCalendar(calendar);
//		
//		service.listCalendars();
//	}
	
	// search key test
//	public static void main(String[] args) throws Exception {
//		
//		String domainName = "forecs.net";
//		String accountUser = "gcp-admin@forecs.net";
//		String calendarId = "forecs.net_v8gfugl92e54op7ejbp44aeib0@group.calendar.google.com";
//		String eventId = "tdfkcmi1gifbltmmvdtgijo5ek";
//		
//		GSuiteService service = new GSuiteService(domainName, accountUser);
//		
//		long times = System.currentTimeMillis();
//		Date startDate = new Date(times+1800000);
//		Date endDate = new Date(times+3600000);
//		Map<String, String> privateExtendedSearchProperties = new HashMap<String, String>();
//		privateExtendedSearchProperties.put("taskId", "1234567890");
//		
//		service.insertEvent(calendarId, "KeyPairTest", startDate, endDate, privateExtendedSearchProperties);
//		Event searchEvent = service.searchEvent(calendarId, "taskId=1234567890");
//		System.out.println(searchEvent.toPrettyString());
//	}
	

//	public static void main(String[] args) throws Exception {
//		String domainName = "forecs.net";
//		String accountUser = "hyeunwoo.shim@forecs.net";
//		
//		GSuiteService service = new GSuiteService(domainName, accountUser);
//		service.getUsersByServiceAccounts("hyeunwoo.shim@forecs.net");
////		service.undeleteUsersByServiceAccounts("100021615103707733358");
////		service.listUsersByServiceAccounts(null, 10);
//		//service.insertUsersByServiceAccounts("심", "지수", "jisu.shim@forecs.net", "nasgood77");
//		//service.deleteUsersByServiceAccounts("jisu.shim@forecs.net");
//	}

/*	public static void main(String[] args) throws Exception {
		addCalendarAndEventTest();
	}
	public static void addCalendarAndEventTest() throws Exception {
		String domainName = "forecs.net";
		String accountUser = "hyeunwoo.shim@forecs.net";
		
		GSuiteService service = new GSuiteService(domainName, accountUser);
//		Calendar calendar = new Calendar();
//		calendar.setSummary("boardCalendar Test 01");
//		calendar.setDescription("boardCalendar description");
//
//		calendar = service.insertCalendar(calendar);
//		String calendarId = calendar.getId();
		String calendarId = "forecs.net_b1pm2e1aslf8gv7urh901es57c@group.calendar.google.com";
//		AclRule arOwner = new AclRule();
//		arOwner.setRole("owner");
//		Scope scopeOwner = new Scope();
//		scopeOwner.setType("user");
//		scopeOwner.setValue("hyeunwoo.shim@forecs.net");
//		arOwner.setScope(scopeOwner);
//		
//		service.calendarService.acl().insert(calendar.getId(), arOwner).execute();

		AclRule arReader = new AclRule();
		arReader.setRole("reader");
		Scope scopeReaderUser = new Scope();
		scopeReaderUser.setType("user");
		scopeReaderUser.setValue("jisu.shim@forecs.net");
		arReader.setScope(scopeReaderUser);

		service.calendarService.acl().insert(calendarId, arReader).execute();

		
		AclRule arWriter = new AclRule();
		arWriter.setRole("writer");
		Scope scopeWriterUser = new Scope();
		scopeWriterUser.setType("user");
		scopeWriterUser.setValue("gcp-admin@forecs.net");
		arWriter.setScope(scopeWriterUser);
		
		service.calendarService.acl().insert(calendarId, arWriter).execute();
		
		
		Event event = new Event();
		//event.setId("11111111111111111111111111111111111");
		event.setVisibility("private");
		event.setTransparency("transparent");	// opaque or transparent
		
		event.setSummary("일정 서버 입력 테스트4");
		event.setDescription("어쩌구저쩌구44");
		
		long times = System.currentTimeMillis();
		Date startDate = new Date(times+1800000);
		Date endDate = new Date(times+3600000);
		
		DateTime start = new DateTime(startDate, TimeZone.getTimeZone("UTC"));
		event.setStart(new EventDateTime().setDateTime(start));
		DateTime end = new DateTime(endDate, TimeZone.getTimeZone("UTC"));
		event.setEnd(new EventDateTime().setDateTime(end));
		service.insertEvent(calendarId, event);
		
		
//		service.insertEvent(calendar.getId(), "test group3 event 0001");
		


		//service.insertGroupMembersByServiceAccounts(group.getId(), "gcp-admin@forecs.net");
		
		//GSuiteService service = new GSuiteService("cocoworks.net", "admin@cocoworks.net");
		
		//service.listUsersByServiceAccounts(null, 5);
		//service.listGroupByServiceAccounts(null, 5);
		
//		String groupKey = "039kk8xu21zilrr";
//		
//		Group group = service.getGroupByServiceAccounts(groupKey);
//		Member member = service.insertGroupMembersByServiceAccounts(groupKey, groupUser);
//		member.setRole("OWNER");
//		member = service.updateGroupMembersByServiceAccounts(groupKey, member.getId(), member);
//		//service.removeGroupMembersByServiceAccounts("039kk8xu21zilrr", "hyeunwoo.shim@forecs.net");
//		Members members = service.listGroupMembersByServiceAccounts(groupKey, null, 10);	
	}*/
/*	public static void groupCreateTest(String[] args) throws Exception {
		String domainName = "forecs.net";
		String accountUser = "hyeunwoo.shim@forecs.net";
		
		String groupKeyId = "testgroup3@forecs.net";
		String groupName = "테스트그룹3";
		String description = "테스트입니다.";
		
		String groupUser = "jisu.shim@forecs.net";
		
		GSuiteService service = new GSuiteService(domainName, accountUser);
//		Group group = service.insertGroupByServiceAccounts(groupKeyId, groupName, description);
//		System.out.println("GroupID: "+group.getId());
//		
//		service.insertGroupMembersByServiceAccounts(group.getId(), groupUser);
//		
//		Calendar calendar = new Calendar();
//		calendar.setSummary("test group3 calendar");
//		calendar.setDescription("testgroup3 calendar description");
//
//		calendar = service.insertCalendar(calendar);
//		AclRule arOwner = new AclRule();
//		arOwner.setRole("owner");
//		Scope scopeOwner = new Scope();
//		scopeOwner.setType("user");
//		scopeOwner.setValue("hyeunwoo.shim@forecs.net");
//		arOwner.setScope(scopeOwner);
//		
//		service.calendarService.acl().insert(calendar.getId(), arOwner).execute();

		AclRule arGroup = new AclRule();
		arGroup.setRole("writer");
		Scope scopeGroup = new Scope();
		scopeGroup.setType("group");
		scopeGroup.setValue("testgroup3@forecs.net");
		arGroup.setScope(scopeGroup);

		service.calendarService.acl().insert("forecs.net_l9jaocrk96s9gtdqugc7crulsc@group.calendar.google.com", arGroup).execute();

		
//		service.insertEvent(calendar.getId(), "test group3 event 0001");
		


		//service.insertGroupMembersByServiceAccounts(group.getId(), "gcp-admin@forecs.net");
		
		//GSuiteService service = new GSuiteService("cocoworks.net", "admin@cocoworks.net");
		
		//service.listUsersByServiceAccounts(null, 5);
		//service.listGroupByServiceAccounts(null, 5);
		
//		String groupKey = "039kk8xu21zilrr";
//		
//		Group group = service.getGroupByServiceAccounts(groupKey);
//		Member member = service.insertGroupMembersByServiceAccounts(groupKey, groupUser);
//		member.setRole("OWNER");
//		member = service.updateGroupMembersByServiceAccounts(groupKey, member.getId(), member);
//		//service.removeGroupMembersByServiceAccounts("039kk8xu21zilrr", "hyeunwoo.shim@forecs.net");
//		Members members = service.listGroupMembersByServiceAccounts(groupKey, null, 10);
	}*/
}
