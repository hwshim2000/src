package net.forecs.coconut.endpoint.foreign.gsuite;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.List;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.admin.directory.Directory;
import com.google.api.services.admin.directory.DirectoryScopes;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.groupssettings.Groupssettings;
import com.google.api.services.groupssettings.GroupssettingsScopes;

@Deprecated
public class GSuiteAuth {
	/** Application name. */
	private static final String APPLICATION_NAME = "cocoworks";
	private static final String SERVICE_ACCOUNT_ID = "g-suite-admin@cocoworks-for-ecs.iam.gserviceaccount.com";
	public static final String PRIVATE_KEY_FILE = "war/WEB-INF/cocoworks-gsuite-390218e781d1.p12";

	/** Global instance of the JSON factory. */
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

	/** Global instance of the HTTP transport. */
	private static HttpTransport HTTP_TRANSPORT;

	/**
	 * Global instance of the scopes required by this quickstart.
	 *
	 * If modifying these scopes, delete your previously saved credentials at
	 * ~/.credentials/admin-directory_v1-java-quickstart
	 */
    private static final List<String> ADMIN_SCOPES =
        Arrays.asList(DirectoryScopes.ADMIN_DIRECTORY_USER
        		, DirectoryScopes.ADMIN_DIRECTORY_GROUP
        		, GroupssettingsScopes.APPS_GROUPS_SETTINGS
        		, CalendarScopes.CALENDAR);

    static {
        try {
            HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
        }
    }
    
    public static Credential authorizeByAccessToken(String accessToken) throws IOException {
		Credential credential = null;
		try { 
			credential = new GoogleCredential().setAccessToken(accessToken);
			
			System.out.println(credential.getAccessToken());
			credential.refreshToken();
			System.out.println(credential.getAccessToken());
		} catch (Exception ex) {
			ex.printStackTrace();
		};
		
		return credential;
	}
    
    // 참조 : https://developers.google.com/admin-sdk/directory/v1/guides/delegation
    // 참조 : https://developers.google.com/api-client-library/java/google-api-java-client/oauth2
    // 이함수를 실행하기 위해서는 credential을 먼저 만들고, sevice account key (p12)파일을 만들고
    // Oauth client를 만든뒤에 해당 계정에서 p12파일을 내려 받은뒤 등록
    // 단, 이 서비스를 이용하기 위해서는 해당 domain의 security 옵션에 해당 client id와 접근할 수 있는 서비스 경로를 등록해 주어야 하며,(https://admin.google.com/AdminHome?chromeless=1#OGX:ManageOauthClients)
    // accountUser도 해당 서비스 경로에 접근할 수 있는 권한을 가지고 있어야 한다.
    // 활용할 수 있는 곳은.. 사용자의 현재 로그인 세션과 무관하게, 해당 유저로 서비스에 접근하여 작업을 할 필요성이 있을 때, 유용하다.
    // 예로, 해당 도메인의 최상의 관리자로, 특정 사용자의 owner변경이라든가 리소스 접근 및 사용자 콘트롤등이 필요한 action이 있을 때, 등등
	public static GoogleCredential authorizeByServiceAccounts(String accountUser) throws IOException, GeneralSecurityException {
		HttpTransport httpTransport = new NetHttpTransport();
		JacksonFactory jsonFactory = new JacksonFactory();
		GoogleCredential credential = new GoogleCredential.Builder()
				.setTransport(httpTransport)
				.setJsonFactory(jsonFactory)
				.setServiceAccountId(SERVICE_ACCOUNT_ID)
				.setServiceAccountScopes(ADMIN_SCOPES)
				.setServiceAccountUser(accountUser)
				.setServiceAccountPrivateKeyFromP12File(
						new java.io.File(PRIVATE_KEY_FILE)).build();

		// System.out.println(credential.getAccessToken());
		return credential;
	}
    
    public static Directory getDirectoryServiceByAccessToken(String accessToken) throws IOException {
        Credential credential = authorizeByAccessToken(accessToken);
       // Credential credential = authorizeByAccessToken("ya29.GlsmBOcDQmUshHTVepzyYa10Eb-j2QFcqtSK1tvhxiQRx8glF4v-rxD0Q1MbSmxrA94irJKCRv2GNYlE0OhIyWI-pQVW9-qEoHt77KeKC_FWw269V_UuVywbFVqH");
        return new Directory.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }

    public static Directory getDirectoryServiceByServiceAccounts(String accountUser) throws IOException, GeneralSecurityException {
        GoogleCredential credential = authorizeByServiceAccounts(accountUser);
        
        return new Directory.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, null)
        		.setHttpRequestInitializer(credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }
   
    public static Groupssettings getGroupssettingServiceByServiceAccounts(String accountUser) throws IOException, GeneralSecurityException {
        GoogleCredential credential = authorizeByServiceAccounts(accountUser);

        System.out.println("ACCESS-TOKEN : " + credential.getAccessToken());
        
        return new Groupssettings.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, null)
        		//.setGroupssettingsRequestInitializer(credential)
        		.setHttpRequestInitializer(credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }
    public static Calendar getCalendarServiceByServiceAccounts(String accountUser) throws IOException, GeneralSecurityException {
        GoogleCredential credential = authorizeByServiceAccounts(accountUser);

        System.out.println("ACCESS-TOKEN : " + credential.getAccessToken());
        
        return new Calendar.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, null)
        		//.setGroupssettingsRequestInitializer(credential)
        		.setHttpRequestInitializer(credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
    }
    
    public static void getGroupssettingByServiceAccounts(String accountUser, String groupEmailAddress) throws IOException, GeneralSecurityException {
    	// Build a new authorized API client service.
        Groupssettings service = getGroupssettingServiceByServiceAccounts(accountUser);
        
        
        com.google.api.services.groupssettings.model.Groups settingGroup = service.groups().get(groupEmailAddress).execute();
     
        System.out.println(settingGroup.toPrettyString());
    }
    
//    public static void main(String[] args) throws IOException, GeneralSecurityException {
//    	//listGroupByServiceAccounts("hyeunwoo.shim@forecs.net");
//    	//createGroupByServiceAccounts();
//    	//deleteGroupByServiceAccounts();
//    	//getGroupssettingByServiceAccounts("test2@forecs.net");
//    	
//    	//listUsersByInstalledApp();
//    	//listUsersByAccessToken();
//    	//listUsersByServiceAccounts();
//    }

}
