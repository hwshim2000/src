package net.forecs.coconut.endpoint.foreign.gsuite;

import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Result;
import net.forecs.coconut.endpoint.API;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.services.admin.directory.model.User;
import com.google.api.services.admin.directory.model.Users;


@Api(name = API.DOMAIN_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.DOMAIN_SERVICE_PACKAGE), description = "CoCoNut 최상위 Domain API 목록", auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class GSuiteServiceAPI {
	private final IGSuiteService gsuiteService;
	
	@Inject
	public GSuiteServiceAPI(IGSuiteService gsuiteService) {
		this.gsuiteService = gsuiteService;
	}
	
	@ApiMethod(name = "queryUsers", path = "gsuite/users/query", httpMethod = HttpMethod.GET
			//, scopes = {CommonProperty.EMAIL_SCOPE, CommonProperty.SCOPE_ADMIN_DIRECTORY_GROUP, CommonProperty.SCOPE_ADMIN_DIRECTORY_USER}
			//, clientIds = {CommonProperty.WEB_CLIENT_ID,
			//com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID}
			)
	//@RequiresUser
	public Users queryUsers(@Nullable @Named(FLD.nextPageToken) String nextPageToken, @Nullable @Named(FLD.limit) Integer limit, com.google.appengine.api.users.User user) throws Exception {
		System.out.println("============"+user.getUserId() + "/"+user.getAuthDomain());
		return gsuiteService.queryUsers(nextPageToken, limit);
	}

	@ApiMethod(name = "queryDeletedUsers", path = "gsuite/users/deleted/query", httpMethod = HttpMethod.GET)
	public Users queryDeletedUsers(@Nullable @Named(FLD.nextPageToken) String nextPageToken, @Nullable @Named(FLD.limit) Integer limit, com.google.appengine.api.users.User user) throws Exception {
		return gsuiteService.queryDeletedUsers(nextPageToken, limit);
	}
	
	@ApiMethod(name = "getUser", path = "gsuite/users/{userKey}", httpMethod = HttpMethod.GET)
	public User getUser(@Named(FLD.userKey) String userKey) throws Exception {
		return gsuiteService.getUser(userKey);
	}
	
	@ApiMethod(name = "listUsers", path = "gsuite/users", httpMethod = HttpMethod.GET)
	public Users listUsers(@Named(FLD.userKeys) List<String> userKeys) throws Exception {
		return gsuiteService.listUsers(userKeys);
	}
	
	@ApiMethod(name = "syncAllGSuiteUsers", path = "gsuite/users/sync/all", httpMethod = HttpMethod.POST)
	public void syncAllGSuiteUsers() throws Exception {
		gsuiteService.syncAllGSuiteUsers();
	}
	
//	@ApiMethod(name = "syncAvailableUsers", path = "gsuite/users/sync/avaliable", httpMethod = HttpMethod.POST)
//	public List<net.forecs.coconut.entity.user.Users> syncAvailableUsers(@Named(FLD.userKeys) List<String> userKeys) throws Exception {
//		return gsuiteService.syncAvailableUsers(userKeys);
//	}
	
	@ApiMethod(name = "syncAvailableUsers", path = "gsuite/users/sync/available", httpMethod = HttpMethod.POST)
	public void syncAvailableUsers() throws Exception {
		gsuiteService.syncAvailableUsers();
	}
	
	@ApiMethod(name = "syncUnavailableUsers", path = "gsuite/users/sync/unavailable", httpMethod = HttpMethod.POST)
	public void syncUnavailableUsers() throws Exception{
		gsuiteService.syncUnavailableUsers();
	}
	
//	@ApiMethod(name = "verifiedDomain", path = "gsuite/domain/verfied", httpMethod = HttpMethod.POST)
//	public boolean verifiedDomain() {
//		return gsuiteService.verifiedDomain();
//	}
	
	@ApiMethod(name = "verifiedDomain", path = "gsuite/domain/verfied/{domainName}", httpMethod = HttpMethod.POST)
	public Result verifiedDomain(@Named(FLD.domainName) String domainName
			, @Named(FLD.gsuiteServiceAccount) String gsuiteServiceAccount
			, @Named(FLD.gsuiteCustomerId) String gsuiteCustomerId) {
		return new Result(gsuiteService.verifiedDomain(domainName, gsuiteServiceAccount, gsuiteCustomerId));
	}
}
