package net.forecs.coconut.endpoint.foreign.gsuite;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import net.forecs.coconut.common.Logger;

import com.google.api.client.googleapis.batch.BatchRequest;
import com.google.api.client.googleapis.batch.json.JsonBatchCallback;
import com.google.api.client.googleapis.json.GoogleJsonError;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.Lists;
import com.google.api.services.calendar.model.Calendar;
import com.google.api.services.calendar.model.CalendarList;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Event.ExtendedProperties;
import com.google.api.services.calendar.model.EventDateTime;
import com.google.api.services.calendar.model.Events;

@Deprecated
public class GSuiteCalendar {
	private static final Logger LOG = Logger.getLogger(GSuiteCalendar.class.getName());
	private static final java.util.List<Calendar> calendarsForUsingBatch = Lists.newArrayList();
	
	@SuppressWarnings("unused")
	private final String domainName;
	private final com.google.api.services.calendar.Calendar gsCalendar;
	
	public GSuiteCalendar(String domainName, String accountUser) throws IOException, GeneralSecurityException {
		this.domainName = domainName;
		this.gsCalendar = GSuiteAuth.getCalendarServiceByServiceAccounts(accountUser);
	}
	
	public CalendarList listCalendars() throws IOException, GeneralSecurityException {
		CalendarList calendarList = gsCalendar.calendarList().list().execute();
		System.out.println(calendarList.toPrettyString());
		return calendarList;
	}
	public Calendar getCalendar(String calendarId) throws IOException, GeneralSecurityException {
		return gsCalendar.calendars().get(calendarId).execute();
	}
	public Calendar insertCalendar(Calendar calendar) throws IOException, GeneralSecurityException {
		return gsCalendar.calendars().insert(calendar).execute();
	}
	public Calendar updateCalendar(Calendar calendar) throws IOException, GeneralSecurityException {
		return gsCalendar.calendars().update(calendar.getId(), calendar).execute();
	}
	public Calendar patchCalendar(Calendar calendar) throws IOException, GeneralSecurityException {
		return gsCalendar.calendars().patch(calendar.getId(), calendar).execute();
	}
	public void deleteCalendar(String calendarId) throws IOException, GeneralSecurityException {
		gsCalendar.calendars().delete(calendarId).execute();
	}
	public void insertCalendarsUsingBatch(List<Calendar> calendars) throws IOException, GeneralSecurityException {
		BatchRequest batch = gsCalendar.batch();

		// Create the callback.
		for (Calendar calendar : calendars) {
			JsonBatchCallback<Calendar> callback = new JsonBatchCallback<Calendar>() {
				@Override
				public void onSuccess(Calendar calendar, HttpHeaders responseHeaders) {
					calendarsForUsingBatch.add(calendar);
				}
	
				@Override
				public void onFailure(GoogleJsonError e, HttpHeaders responseHeaders) {
					LOG.warning("Error Message: " + e.getMessage());
				}
			};
			gsCalendar.calendars().insert(calendar).queue(batch, callback);
		}
		batch.execute();
	}
	public void deleteCalendarsUsingBatch(List<Calendar> calendarList) throws IOException, GeneralSecurityException {
		BatchRequest batch = gsCalendar.batch();
		//for (Calendar calendar : addedCalendarsUsingBatch) {
		for (Calendar calendar : calendarList) {
			gsCalendar.calendars().delete(calendar.getId()).queue(batch, new JsonBatchCallback<Void>() {
				@Override
				public void onSuccess(Void content,	HttpHeaders responseHeaders) {
					LOG.warning("Delete is successful!");
				}

				@Override
				public void onFailure(GoogleJsonError e, HttpHeaders responseHeaders) {
					LOG.warning("Error Message: "+ e.getMessage());
				}
			});
		}

		batch.execute();
	}

	public Events listEvent(String calendarId) throws IOException, GeneralSecurityException {
		// 만일, 이벤트의 일정을 반복된 내용을 포함시키려면, SingleEvents의 값을 true로 설정하면 된다.
		// SingleEvents의 값이 false이면, 반복일정을 하지 않고 한가지 event로 계산된다.
		Events events = gsCalendar.events().list(calendarId).execute();
		System.out.println(events.toPrettyString());
		return events;
	}
	public Events listInstances(String calendarId, String eventId) throws IOException, GeneralSecurityException {
		Events events = gsCalendar.events().instances(calendarId, eventId).execute();
		System.out.println(events.toPrettyString());
		return events;
	}

	public Event getEvent(String calendarId, String eventId) throws IOException, GeneralSecurityException {
		Event event = gsCalendar.events().get(calendarId, eventId).execute();
		System.out.println("==========================================");
		System.out.println(event.toPrettyString());
		return event;
	}
	
	public Event insertEvent(String calendarId, Event event) throws IOException, GeneralSecurityException {
		Event result = gsCalendar.events().insert(calendarId, event).execute();
		return result;
	}
	
	public Event insertEvent(String calendarId, String summary) throws IOException, GeneralSecurityException {
		long times = System.currentTimeMillis();
		Date startDate = new Date(times+1800000);
		Date endDate = new Date(times+3600000);
		Event event = insertEvent(calendarId, summary, startDate, endDate, null);
		return event;
	}
	
	public Event insertEvent(String calendarId, String summary, Date startDate, Date endDate, Map<String, String> privateExtendedSearchProperties) throws IOException, GeneralSecurityException {
		Event event = new Event();
		event.setSummary(summary);
		DateTime start = new DateTime(startDate, TimeZone.getTimeZone("UTC"));
		event.setStart(new EventDateTime().setDateTime(start));
		DateTime end = new DateTime(endDate, TimeZone.getTimeZone("UTC"));
		event.setEnd(new EventDateTime().setDateTime(end));
		
		if (privateExtendedSearchProperties != null) {
			ExtendedProperties extendedProperties = new ExtendedProperties();
			extendedProperties.setPrivate(privateExtendedSearchProperties);
			event.setExtendedProperties(extendedProperties);
		}
		return insertEvent(calendarId, event);
	}
	public Event quickAdd(String calendarId, String text, boolean sendNotifications) throws IOException, GeneralSecurityException {
		return gsCalendar.events().quickAdd(calendarId, text).setSendNotifications(sendNotifications).execute();
	}
	public Event moveEvent(String calendarId, String eventId, String targetCalendarId, boolean sendNotifications) throws IOException, GeneralSecurityException {
		return gsCalendar.events().move(calendarId, eventId, targetCalendarId).setSendNotifications(sendNotifications).execute();
	}

	public void deleteEvent(String calendarId, String eventId) throws IOException, GeneralSecurityException {
		gsCalendar.events().delete(calendarId, eventId).execute();
	}
	public Event updateEvent(String calendarId, String eventId, Event event) throws IOException, GeneralSecurityException {
		return gsCalendar.events().update(calendarId, eventId, event).execute();
	}
	public Event patchEvent(String calendarId, String eventId, Event event) throws IOException, GeneralSecurityException {
		return gsCalendar.events().patch(calendarId, eventId, event).execute();
	}
	public Event importEvent(String calendarId, String eventId, Event event) throws IOException, GeneralSecurityException {
		return gsCalendar.events().calendarImport(calendarId, event).execute();
	}
	public Event searchEvent(String calendarId, String searchKeyPair) throws IOException, GeneralSecurityException {
		List<String> privateExtendedProperties = new ArrayList<String>();
		privateExtendedProperties.add(searchKeyPair);
		Events events = gsCalendar.events().list(calendarId).setPrivateExtendedProperty(privateExtendedProperties).execute();
		if (events.getItems() == null || events.getItems().size() == 0) { return null; }
		else { return events.getItems().get(0); }
	}
}
