package net.forecs.coconut.endpoint.foreign.gsuite;

import java.util.List;

import net.forecs.coconut.endpoint.common.ICommonService;

import com.google.api.services.admin.directory.model.User;
import com.google.api.services.admin.directory.model.Users;

public interface IGSuiteService extends ICommonService {
	public abstract Users queryUsers(String nextPageToken, Integer limit) throws Exception;
	public abstract Users queryDeletedUsers(String nextPageToken, Integer limit) throws Exception;
	public abstract User getUser(String userKey) throws Exception;
	public abstract Users listUsers(List<String> userKeys) throws Exception;
	public abstract void syncAllGSuiteUsers() throws Exception;
	public abstract List<net.forecs.coconut.entity.user.Users> syncAvailableUsers(List<String> userKeys) throws Exception;
	public abstract List<net.forecs.coconut.entity.user.Users> syncAvailableUsers() throws Exception;
	public abstract void syncUnavailableUsers() throws Exception;
	public abstract boolean verifiedDomain();
	public abstract boolean verifiedDomain(String domainName, String gsuiteServiceAccount, String gsuiteCustomerId);
}
