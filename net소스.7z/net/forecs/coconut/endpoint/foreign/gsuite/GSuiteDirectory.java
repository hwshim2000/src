package net.forecs.coconut.endpoint.foreign.gsuite;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.google.api.services.admin.directory.Directory;
import com.google.api.services.admin.directory.Directory.Users.Watch;
import com.google.api.services.admin.directory.model.Channel;
import com.google.api.services.admin.directory.model.Domains;
import com.google.api.services.admin.directory.model.Group;
import com.google.api.services.admin.directory.model.Groups;
import com.google.api.services.admin.directory.model.Member;
import com.google.api.services.admin.directory.model.Members;
import com.google.api.services.admin.directory.model.User;
import com.google.api.services.admin.directory.model.UserMakeAdmin;
import com.google.api.services.admin.directory.model.UserName;
import com.google.api.services.admin.directory.model.UserUndelete;
import com.google.api.services.admin.directory.model.Users;

@Deprecated
public class GSuiteDirectory {
	//private static final Logger LOG = Logger.getLogger(GSuiteDirectory.class.getName());
	
	private final String domainName;
	private final Directory gsDirectory;
	private final String customerId;
	
	public GSuiteDirectory(String domainName, String accountUser, String customerId) throws IOException, GeneralSecurityException {
		this.domainName = domainName;
		this.gsDirectory = GSuiteAuth.getDirectoryServiceByServiceAccounts(accountUser);
		this.customerId = customerId;
	}
	
	public GSuiteDirectory(net.forecs.coconut.entity.domain.Domains domain) throws IOException, GeneralSecurityException {
		this.domainName = domain.getDomainName();
		this.gsDirectory = GSuiteAuth.getDirectoryServiceByServiceAccounts(domain.getGsuiteServiceAccount());
		this.customerId = domain.getGsuiteCustomerID();
	}

	
	public Users queryUsers(String nextPageToken, Integer limit, String showDeleted) throws IOException, GeneralSecurityException {
		Users result = gsDirectory.users().list()
				// .setCustomer("forecs.net")
				.setDomain(domainName)
				.setMaxResults(limit)
				.setPageToken(nextPageToken)
				.setOrderBy("email")
				.setShowDeleted(showDeleted)	// 삭제된 사용자만 볼경우 : true
				.execute();

		return result;
	}
	
	public boolean verifiedCustomer() throws IOException, GeneralSecurityException {
		return null != gsDirectory.customers().get(customerId).execute();
	}
	
	public boolean verifiedDomain() throws IOException, GeneralSecurityException {
		Domains domains = gsDirectory.domains().get(customerId, domainName).execute();
		return domains != null && domains.getVerified();
	}
	
	/* userKey : user's primary email address, alias email address, or unique user ID. */
	public User getUser(String userKey) throws IOException, GeneralSecurityException {
		// see more info : https://developers.google.com/admin-sdk/directory/v1/reference/users/get?hl=ko
		User user = gsDirectory.users().get(userKey)
				//.setCustomFieldMask("custom filelds,...")
				.setProjection("basic")		// basic, custom or full
				.setViewType("domain_public")	// domain_public or admin_view
				.execute();
		
		System.out.println(user.toPrettyString());
		return user;
	}
	
	public User insertUsers(String familyName, String givenName, String primaryEmail, String password) throws IOException, GeneralSecurityException {
		User user = new User();
		UserName userName = new UserName();
		userName.setFamilyName(familyName);
		userName.setGivenName(givenName);
		user.setName(userName);
		user.setPrimaryEmail(primaryEmail);
		user.setPassword(password);
		user.setChangePasswordAtNextLogin(false);
		
		user = gsDirectory.users().insert(user).execute();

		System.out.println(user.toPrettyString());
		return user;
	}
	/* userKey :  primary email address, alias email address, or unique user ID. */
	public void deleteUsers(String userKey) throws IOException, GeneralSecurityException {
		gsDirectory.users().delete(userKey).execute();
	}
	/* userKey : only unique ID */
	public void undeleteUsers(String userKey) throws IOException, GeneralSecurityException {
		UserUndelete uu = new UserUndelete();
		uu.setOrgUnitPath("/");
		
		gsDirectory.users().undelete(userKey, null).execute();
	}
	/*  primary email address, alias email address, or unique user ID. */
	public void makeAdminUsers(String userKey) throws IOException, GeneralSecurityException {
		UserMakeAdmin uma = new UserMakeAdmin();
		uma.setStatus(true);
		gsDirectory.users().makeAdmin(userKey, uma).execute();
	}
	
	public User updateUsers(String userKey, User user) throws IOException, GeneralSecurityException {
		return gsDirectory.users().update(userKey, user).execute();
	}
	
	public User patchUsers(String userKey, User user) throws IOException, GeneralSecurityException {
		return gsDirectory.users().patch(userKey, user).execute();
	}
	
	public Groups listGroup(String nextPageToken, Integer limit) throws IOException, GeneralSecurityException {
		Groups result = gsDirectory.groups().list()
				.setDomain(domainName)
				.setPageToken(nextPageToken)
				.setMaxResults(limit)
				.execute();

		System.out.println(result.toPrettyString());

		if (result.getGroups() != null) {
			for (Group group : result.getGroups()) {
				//System.out.println(group.toPrettyString());
				System.out.println(group.getName() + ":" + group.getId());
			}
		}
		return result;
	}
	
	public Group insertGroup(String groupEmail, String groupName, String description) throws IOException, GeneralSecurityException {
		Group group = new Group();
		
		group.setEmail(groupEmail);
		group.setName(groupName);
		group.setDescription(description);

		group = gsDirectory.groups().insert(group).execute();

		System.out.println(group.toPrettyString());

		return group;
	}
	/* groupKey : group's email address, group alias, or the unique group ID. */
	public Group getGroup(String groupKey) throws IOException, GeneralSecurityException {
		Group group = gsDirectory.groups().get(groupKey).execute();
		System.out.println(group.toPrettyString());
		return group;
	}
	public Group updateGroup(String groupKey, Group group) throws IOException, GeneralSecurityException {
		return gsDirectory.groups().update(groupKey, group).execute();
	}
	public Group patchGroup(String groupKey, Group group) throws IOException, GeneralSecurityException {
		return gsDirectory.groups().patch(groupKey, group).execute();
	}
	public void deleteGroup(String groupKey) throws IOException, GeneralSecurityException {
		gsDirectory.groups().delete(groupKey).execute();
	}
	
	
	public Members listGroupMembers(String groupKey, String nextPageToken, Integer limit) throws IOException, GeneralSecurityException {
		Members result = gsDirectory.members().list(groupKey)
				.setPageToken(nextPageToken)
				.setMaxResults(limit)
				.execute();

		System.out.println(result.toPrettyString());

		if (result.getMembers() != null) {
			for (Member member : result.getMembers()) {
				//System.out.println(member.toPrettyString());
				System.out.println(member.getEmail()+ ":" + member.getId());
			}
		}
		return result;
	}
	
	/**
	 * "MANAGER": This role is only available if the Google Groups for Business is enabled using the Admin console. A MANAGER role can do everything done by an OWNER role except make a member an OWNER or delete the group. A group can have multiple MANAGER members.
	 * "MEMBER": This role can subscribe to a group, view discussion archives, and view the group's membership list. For more information about member roles, see the administration help center.
	 * "OWNER": This role can send messages to the group, add or remove members, change member roles, change group's settings, and delete the group. An OWNER must be a member of the group. A group can have more than one OWNER.
	 */
	/**
	 * SCOPES
	 * https://www.googleapis.com/auth/admin.directory.group.member
	 * https://www.googleapis.com/auth/admin.directory.group 
	 */
	public Member insertGroupMembers(String groupKey, String email) throws IOException, GeneralSecurityException {
		Member member = new Member();
		member.setEmail(email);
		member.setRole("MEMBER");	// MANAGER or OWNER or MEMBER
		member.setType("USER");
		member = gsDirectory.members().insert(groupKey, member).execute();
		
		System.out.println(member.toPrettyString());

		return member;
	}
	
	public Member updateGroupMembers(String groupKey, String memberKey, Member member) throws IOException, GeneralSecurityException {
		// memberKey : primary email address, alias, or unique ID
		return gsDirectory.members().update(groupKey, memberKey, member).execute();
	}
	public Member patchGroupMembers(String groupKey, String memberKey, Member member) throws IOException, GeneralSecurityException {
		// memberKey : primary email address, alias, or unique ID
		return gsDirectory.members().patch(groupKey, memberKey, member).execute();
	}
	
	public void removeGroupMembers(String groupKey, String memberKey) throws IOException, GeneralSecurityException {
		// memberKey : primary email address, alias, or unique ID
		gsDirectory.members().delete(groupKey, memberKey).execute();
	}
	
	
	
	public void watch() throws IOException, GeneralSecurityException {
		Channel ch = new Channel();
		
		ch.setId("forecs-net-user-deleted");
		ch.setType("web_hook");
		ch.setAddress("https://performance-dot-cocoworks-for-ecs.appspot.com/notifications?domainName=forecs.net");
		Watch watch = gsDirectory.users().watch(ch);
		watch.setDomain("forecs.net");
		watch.setEvent("delete");
		ch = watch.execute();
		
		System.out.println(new Date(ch.getExpiration()));
		System.out.println(ch.toPrettyString());
	}
	
	private static String formattedDomainName(String domainName) {
		return domainName.replaceAll("\\.", "-");
	}
	public void watch2(String domainName) throws IOException, GeneralSecurityException {
		Channel ch = new Channel();
		
		ch.setId(formattedDomainName(domainName)+"-user-all");
		ch.setType("web_hook");
		
		ch.setAddress("https://performance-dot-cocoworks-for-ecs.appspot.com/notifications?domainName="+domainName);
		
		long expire = 1*24*3600;
		long cur = System.currentTimeMillis() + expire*1000;
		Date d = new Date(cur);
		ch.setExpiration(d.getTime());
		
		Map<String, String> m = new HashMap<String, String>();
		m.put("ttl", String.valueOf(expire));
		ch.setParams(m);
		Watch watch = gsDirectory.users().watch(ch);
		watch.setDomain(domainName);
//		watch.setEvent("delete");	// 지정안할경우 모든 이벤트
		ch = watch.execute();
		
		/*
		 *  "expiration" : "1493373928000",
  "id" : "forecs-net-user-all",
  "kind" : "api#channel",
  "resourceId" : "sDu98FUIf4pq3YXvbJ92bcGhIS8",
  "resourceUri" : "https://www.googleapis.com/admin/directory/v1/users?domain=forecs.net&projection=basic&viewType=admin_view&alt=json"
}
		 */
		System.out.println(new Date(ch.getExpiration()));
		System.out.println(ch.toPrettyString());
	}
	public void stop() throws IOException, GeneralSecurityException {
		Channel ch = new Channel();
		ch.setId("forecs-net-user-deleted");
		ch.setResourceId("a88bmmI51ELcb9KXBdUBbJ_eHIk");
		gsDirectory.channels().stop(ch).execute();
	}
	public void stop2(String domainName) throws IOException, GeneralSecurityException {
		Channel ch = new Channel();
		ch.setId(formattedDomainName(domainName)+"-user-all");
		ch.setResourceId("sDu98FUIf4pq3YXvbJ92bcGhIS8");
		//ch.setResourceId("vv0TG-2A33OaHqwONuAEsxOQebo");
		gsDirectory.channels().stop(ch).execute();
	}
	public static void main(String[] args) throws Exception {
		//String domainName = "cocoworks.net";
		String domainName = "forecs.net";
		GSuiteDirectory dir = new GSuiteDirectory(domainName, "hyeunwoo.shim@"+domainName, "C00xz7pch");
		//GSuiteDirectory dir = new GSuiteDirectory(domainName, "admin@"+domainName, "C01wivu9j");
		
		//dir.watch2(domainName);
		dir.stop2(domainName);
		
		////// TODO : 채널 지우기 전에 해당 채널이 살아 있는지 추후확인 
	}
}
