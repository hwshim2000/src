package net.forecs.coconut.endpoint.setting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.UserSettings;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.shiro.ShiroUtils;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


public class UserSettingService extends CommonService implements IUserSettingService {
	private List<UserSetting> listUserSettings(String userId) {
		EntityManager mgr = getEntityManager();
		try {
			return listUserSettings(mgr, userId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<UserSetting> listUserSettings(EntityManager mgr, String userId) {
		try {
			DsQuery<UserSetting> dsQuery = new DsQuery<>(UserSetting.class)
					.eq(FLD.creator, userId);
			return dsQuery.execute(mgr);
		} catch (Exception ex) {
			return new ArrayList<UserSetting>();
		} finally {
		}
	}

	@Override
	public List<UserSetting> listMySettings() {
		String userId = ShiroUtils.getCurrentUser().getObjectId();
		return listUserSettings(userId);
	}
	
	public static UserSetting getUserLocaleSetting(String userId) {
		if (StringUtils.isBlank(userId)) { return null; }
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(KeyFactory.stringToKey(userId).getNamespace());
		
		EntityManager mgr = getEntityManager();
		try {
			Key key = KeyUtil.createUserSettingKey(userId, CommonProperty.USER_UI_SETTING_NAME);
			
			return doFind(mgr, UserSetting.class, key);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	private UserSetting putUserSetting(String userId, UserSetting setting)
			throws Exception {
		String settingName = setting.getName();
		//Text settingValue = setting.getValue();
		if (setting.getKey() != null) {
			//setting.setValue(settingValue);
			return updateUserSetting(setting);
		} else {
			//setting = new UserSetting();
			Key key = KeyUtil.createUserSettingKey(userId, settingName);
			setting.setKey(key);
			setting.setCreator(userId);
			//setting.setName(settingName);
			//setting.setValue(settingValue);
			return insertSettings(setting);
		}
	}
	private UserSettings putUserSettings(String userId, UserSettings settings)
			throws Exception {
		List<UserSetting> updateSettings = new ArrayList<UserSetting>();
		List<UserSetting> insertSettings = new ArrayList<UserSetting>();
		List<UserSetting> resultSettings = new ArrayList<UserSetting>();
		
		for(UserSetting setting : settings.getSettings()) {
			String settingName = setting.getName();
			if (setting.getKey() != null) {
				updateSettings.add(setting);
			} else {
				Key key = KeyUtil.createUserSettingKey(userId, settingName);
				setting.setKey(key);
				setting.setCreator(userId);
				insertSettings.add(setting);
			}
		}
		
		if (updateSettings.size() > 0) {
			updateSettings = updateUserSettingList(updateSettings);
			resultSettings.addAll(updateSettings);
		}
		if (insertSettings.size() > 0) {
			insertSettings = insertSettingList(insertSettings);
			resultSettings.addAll(insertSettings);
		}
		
		return new UserSettings(resultSettings);
	}
	@Override
	public UserSettings putMySettings(UserSettings settings) throws Exception {
		String userId = ShiroUtils.getCurrentUser().getObjectId();
		return putUserSettings(userId, settings);
	}
	
	@Override
	public UserSetting putMySetting(UserSetting setting) throws Exception {
		String userId = ShiroUtils.getCurrentUser().getObjectId();
		return putUserSetting(userId, setting);
	}
	
	private UserSetting insertSettings(UserSetting settings) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			doPersistTransaction(mgr, settings);
			return settings;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<UserSetting> insertSettingList(List<UserSetting> settingList) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			doPersistTransaction(mgr, settingList);
			return settingList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	private UserSetting updateUserSetting(UserSetting settings) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			doMergeTransaction(mgr, settings);
			return settings;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private List<UserSetting> updateUserSettingList(List<UserSetting> settingList) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			doMergeTransaction(mgr, settingList);
			return settingList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public Map<String, UserSetting> batchMapUserSettings(Collection<String> userIds, String settingName) {
		// batch로 데이터를 가져올때, settting키가 아닌 userId를 키로 변환해서 가져오도록 구현
		try {
			Map<String, String> userKeyMap = new HashMap<String, String>(); // <SettingKey, UserId>
			for (String userId : userIds) {
				userKeyMap.put(KeyUtil.createUserSettingKeyString(userId, settingName), userId);
			}
			// settingKey로 Setting정보를 가져온다.
			Map<String, UserSetting> tempMap = batchMapByKey(UserSetting.class, userKeyMap.keySet());
			Map<String, UserSetting> settingMap = new HashMap<String, UserSetting>();
			
			// SettingKey에 해당하는  UserID를 SettingMap의 Key로 변환한
			for (Entry<String, UserSetting> entry : tempMap.entrySet()) {
				settingMap.put(userKeyMap.get(entry.getKey()), entry.getValue());
			}
			
			return settingMap;
		} catch (Exception ex) {
			return new HashMap<String, UserSetting>();
		}
	}
	
	public static String getPreparedDefaultBoard(String domainName, String userId) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		EntityManager mgr = getEntityManager();
		
		try {
			return getPreparedDefaultBoard(mgr, userId);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	public static String getPreparedDefaultBoard(EntityManager mgr, String userId) {
		try {
			Key uiKey = KeyUtil.createUserSettingKey(userId, "uisettings");
			UserSetting uiSetting = doFind(mgr, UserSetting.class, uiKey);
			if (uiSetting == null || uiSetting.getValue() == null || uiSetting.getValue().getValue() == null) { return null; }
			
			JsonFactory factory = new JsonFactory();
			ObjectMapper om = new ObjectMapper(factory);
			
			JsonNode jn = om.readTree(uiSetting.getValue().getValue());
			
			String type = jn.get("general").get("defaultBoard").get("type").textValue();
			if (StringUtils.equals("lastBoard", type)) {
				Key boardKey = KeyUtil.createUserSettingKey(userId, "mostRecentlyUsedBoardId");
				UserSetting boardSetting = doFind(mgr, UserSetting.class, boardKey);
				if (boardSetting == null || boardSetting.getValue() == null || boardSetting.getValue().getValue() == null) { return null; }
				String mostRecentlyBoardId = boardSetting.getValue().getValue();
				return StringUtils.equals("dashboard", mostRecentlyBoardId) ? null:mostRecentlyBoardId;
			} else if (StringUtils.equals("selectedBoard", type)){
				return jn.get("general").get("defaultBoard").get("boardId").textValue();
			} else {
				return null;
			}
		} catch (Exception ex) {
			return null;
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public List<UserSetting> listMySettings(EntityManager mgr) {
//		String userId = ShiroUtils.getCurrentUser().getObjectId();
//		return listUserSettings(mgr, userId);
//	}
//	private UserSetting getUserSetting(String userId, String settingName) {
//		Key key = KeyUtil.createUserSettingKey(userId, settingName);
//		return getUserSetting(key);
//	}
//	@Override
//	public UserSetting getMySetting(String settingName) {
//		String userId = ShiroUtils.getCurrentUser().getObjectId();
//		return getUserSetting(userId, settingName);
//	}
//
//	private UserSetting getUserSetting(Key key) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, UserSetting.class, key);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}