package net.forecs.coconut.endpoint.setting;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.NotificationType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.util.CopyUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;
import com.ibm.icu.util.Calendar;


public class NotificationSettingService extends CommonService implements INotificationSettingService {
	private static final Logger LOG = Logger.getLogger(NotificationSettingService.class.getName());
	
	private NotificationSettings getOrInsertNotificationSettings(EntityManager mgr, String notificationSettingId) throws Exception {
		try {
			Key notificationSettingKey = KeyFactory.stringToKey(notificationSettingId);
			NotificationSettings notificationsettings = doFindNoCache(mgr, NotificationSettings.class, notificationSettingKey);
			if (notificationsettings == null) {
				String userId = notificationSettingKey.getName();
				beginTransaction(mgr);
				notificationsettings = insertNotificationSettings(mgr, new NotificationSettings(userId, userId));
				commitTransaction(mgr);
			}
			return notificationsettings;
		} catch (Exception ex) {
			LOG.severe("[GetOrInsert NotificationSetting Error] : " + ex.getMessage());
			throw ex;
		}
	}
	
	@Override
	public NotificationSettings getUserNotificationSettings(String userId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getUserNotificationSettings(mgr, userId);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public NotificationSettings getUserNotificationSettings(EntityManager mgr, String userId) throws Exception {
		try {
			NotificationSettings notificationsettings = doFind(mgr, NotificationSettings.class, KeyUtil.createNotificationSettingKey(userId));
			
			if (notificationsettings == null) {
				notificationsettings = insertNotificationSettings(mgr, new NotificationSettings(userId, userId));
			}
			return notificationsettings;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public NotificationSettings insertNotificationSettings(
			EntityManager mgr,
			NotificationSettings notificationsettings) throws Exception {
		try {
			notificationsettings.setKey(KeyUtil.createNotificationSettingKey(notificationsettings));
			
			if (contains(mgr, NotificationSettings.class, notificationsettings.getKey())) {
				throw new ConflictException(ErrorCode.ENTITY_ALREADY_EXISTS.getMessage(notificationsettings.getNotificationSettingId()));
			}
			doPersist(mgr, notificationsettings);
			
			return notificationsettings;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public void resetNotificationActivities(EntityManager mgr, NotificationSettings notificationSetting) throws Exception {
		try {
			NotificationSettings setting = (NotificationSettings)CopyUtil.copyDeeply(notificationSetting);
			setting.setActivities(null);
			
			updateNotificationSettings(mgr, setting);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public NotificationSettings updateNotificationSettings(NotificationSettings notificationSetting) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return updateNotificationSettings(mgr, notificationSetting);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public NotificationSettings updateNotificationSettings(
			EntityManager mgr,
			NotificationSettings notificationSetting) throws Exception {
		try {
			NotificationSettings originNotificationSettings = getOrInsertNotificationSettings(mgr, notificationSetting.getNotificationSettingId());
			
			// Remove notification targets(Activities) that already include.
			if (N.equals(notificationSetting.getEmailPushYN())
					|| NotificationType.INSTANT.equals(notificationSetting.getNotificationType())) {
				// 다음부터 발생하는 activity때부터 이전에 있던것이 있다면 다함께 보낸다.
				//notificationSetting.setActivities(new ArrayList<String>());
				deleteNotificationTaskQueue(notificationSetting);
			} else if (!notificationSetting.getNotificationType().equals(originNotificationSettings.getNotificationType())
					|| !notificationSetting.getPeriod().equals(originNotificationSettings.getPeriod())) {
				//deleteNotificationTaskQueue(notificationSetting);
				resetNotificationTaskQueue(notificationSetting);
			}
			List<String> activities = new ArrayList<String>(notificationSetting.getActivities());
			beginTransaction(mgr);
			notificationSetting = doMerge(mgr, notificationSetting);
			notificationSetting.setActivities(activities);
			commitTransaction(mgr);
			
			return notificationSetting;
		} catch (Exception ex) {
			LOG.severe(String.format("[Update NotificationSetting Error] %s : domainName[%s] userId[%s]", ex.getMessage(), notificationSetting.getKey().getNamespace(), notificationSetting.getKey().getName()));
			throw ex;
		}
	}
	

	private void permanentRemoveNotificationSettings(EntityManager mgr, String notificationSettingId) throws Exception {
		try {
			NotificationSettings notificationSetting = doFind(mgr, NotificationSettings.class, notificationSettingId);
			doRemoveTransaction(mgr, notificationSetting);
			deleteNotificationTaskQueue(notificationSetting);
		} catch (Exception ex) {
			throw ex;
		}
	}
	@Override
	public void permanentRemoveUserNotificationSettings(String userId) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			permanentRemoveNotificationSettings(mgr, KeyUtil.createNotificationSettingKeyString(userId));
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@SuppressWarnings("unused")
	private int bulkRemoveNotificationSettings(
			String domainId,
			String boardId,
			String userId) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			Query query = new DsQuery<>(NotificationSettings.class)
					.eq(FLD.deleteYN, null)
//					.eq(FLD.domainId, domainId)	// unnecessary condition
					.eq(FLD.boardId, boardId)
					.eq(FLD.userId, userId)
					.keysOnly();
					
			List<Key> keys = listAllKeysForLimitedChunkSize(query);
			
			for (Key key : keys) {
				permanentRemoveNotificationSettings(mgr, KeyFactory.keyToString(key));
			}
			return keys.size();			
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private void deleteNotificationTaskQueue(NotificationSettings notificationSetting) {
		try {
			// 이전에 Queue에 Notification이 있었다면 지운다. 없을때 발생하는 에러는 무시한다.
			String taskName = notificationSetting.getTaskName();
			if (StringUtils.isNotEmpty(taskName)) {
				Queue queue = QueueFactory.getQueue(CommonProperty.NOTIFICATION_QUEUE_NAME);
				queue.deleteTask(taskName);
				//deleteNotificationQueueTaskName(notificationSetting);
			}
		} catch (Exception ex) {
			LOG.warning("[DELETE Notification Queue Exception] : " + ex.getMessage());
		}
	}
	
	private void resetNotificationTaskQueue(NotificationSettings notificationSetting) {
		try {
			deleteNotificationTaskQueue(notificationSetting);
			
			if (Y.equals(notificationSetting.getEmailPushYN()) &&
					N.equals(notificationSetting.getDeleteYN()) &&
					notificationSetting.getActivities() != null &&
					notificationSetting.getActivities().size() > 0) {
					//notificationSetting.getNotificationList() != null &&
					//notificationSetting.getNotificationList().size() > 0) {
				
				notificationSetting = updateNotificationQueueTaskName(notificationSetting);
				String taskName = notificationSetting.getTaskName();
				
				if (StringUtils.isNotBlank(taskName)) {
					Queue queue = QueueFactory.getQueue(CommonProperty.NOTIFICATION_QUEUE_NAME);
					TaskOptions taskOption = TaskOptions.Builder
				            .withUrl(CommonProperty.NOTIFICATION_EXECUTE_URL)
				            //.param(FLD.domainId, notificationSetting.getDomainId())
				            //.param(FLD.boardId, notificationSetting.getBoardId())
				            .param(FLD.userId, notificationSetting.getUserId())
				            .param(FLD.notificationSettingId, notificationSetting.getNotificationSettingId())
				            .method(Method.POST)
				            .taskName(taskName);
			
					long excuteMills = calculateNotificationTimeInMillis(notificationSetting);
					// Noti가 발생해야할 시점을 계산하여 Queue에 넣는다.
					try { queue.add(taskOption.etaMillis(excuteMills)); } catch (Exception ex) { LOG.warning(ex.getMessage()); }
				}
			}
		} catch (Exception ex) {
			LOG.warning("[RESET Notification Queue Exception] : " + ex.getMessage());
		}
	}
	
	/**
	 * Notification을 보낼 시간 단위를 계산하여 리턴한다.
	 * @param notificationSetting
	 * @return
	 */
	public static long calculateNotificationTimeInMillis(NotificationSettings notificationSetting) {
		Calendar cal = Calendar.getInstance();
		int period = 1;
		if (notificationSetting.getPeriod() != null) { period = notificationSetting.getPeriod(); }
		
		if (NotificationType.HOUR.equals(notificationSetting.getNotificationType())) {
			if (period<=0) period = 1;
			cal.add(Calendar.HOUR_OF_DAY, period);
			int hour = cal.get(Calendar.HOUR_OF_DAY);
			int nextHour = (hour/period)*period;
			
			cal.set(Calendar.HOUR_OF_DAY, nextHour);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
		} else if (NotificationType.MINUTE.equals(notificationSetting.getNotificationType())) {
			if (period<=0) period = 30;
			
			cal.add(Calendar.MINUTE, period);
			
			int minute = cal.get(Calendar.MINUTE);
			int nextMinute = (minute/period)*period;
			
			cal.set(Calendar.MINUTE, nextMinute);
			cal.set(Calendar.SECOND, 0);
		} else if (NotificationType.DAY.equals(notificationSetting.getNotificationType())) {
			if (period<=0) period = 1;
			
			cal.add(Calendar.DATE, period);
			cal.set(Calendar.HOUR_OF_DAY, 8);
			cal.set(Calendar.MINUTE, 30);
			cal.set(Calendar.SECOND, 0);
		}
		return cal.getTimeInMillis();
	}
	
	@Override
	public NotificationSettings updateNotificationQueueTaskName(NotificationSettings notificationSetting) {
		EntityManager mgr = getEntityManager();
		
		try {
			String taskName = String.format("%s-%d", notificationSetting.getUserId(), new Date().getTime());	
			notificationSetting.setTaskName(taskName);
			
			return doMergeTransaction(mgr, notificationSetting);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return null;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Map<String, NotificationSettings> batchMapUserNotificationSetting(EntityManager mgr, List<Users> userList) throws Exception {
		try {
			Set<String> userNotificationIds = new HashSet<String>();
			for (Users user : userList) {
				userNotificationIds.add(KeyUtil.createNotificationSettingKeyString(user.getUserId()));
			}
			Map<String, NotificationSettings> notificationMap = batchMapByKey(mgr, NotificationSettings.class, userNotificationIds);
			
			List<NotificationSettings> batchTxInsertTargets = new ArrayList<NotificationSettings>();

			for (Users user : userList) {
				if (!notificationMap.containsKey(KeyUtil.createNotificationSettingKeyString(user.getUserId()))) {
					NotificationSettings notificationSetting = new NotificationSettings(user.getUserId(), user.getUserId());
					notificationSetting.setKey(KeyUtil.createNotificationSettingKey(user.getUserId()));
					batchTxInsertTargets.add(new NotificationSettings(user.getUserId(), user.getUserId()));
				}
			}
			
			doPersistTransaction(mgr, batchTxInsertTargets);
			
			for (NotificationSettings notificationSetting : batchTxInsertTargets) {
				notificationMap.put(notificationSetting.getNotificationSettingId(), notificationSetting);
			}
			return notificationMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public NotificationSettings updateNotificationSettingsEmailPush(
//			String notificationSettingId, String emailPushYN) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			NotificationSettings notificationSetting = getOrInsertNotificationSettings(mgr, notificationSettingId);
//			notificationSetting.setEmailPushYN(emailPushYN);
//
//			return updateNotificationSettings(mgr, notificationSetting);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public NotificationSettings updateNotificationSettingsMobilePush(
//			String notificationSettingId, String mobilePushYN) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			NotificationSettings notificationSetting = getOrInsertNotificationSettings(mgr, notificationSettingId);
//			notificationSetting.setMobilePushYN(mobilePushYN);
//			
//			return updateNotificationSettings(mgr, notificationSetting);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public NotificationSettings updateNotificationSettingsType(
//			String notificationSettingId, NotificationType notificationType,
//			Integer period) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			NotificationSettings notificationSetting = getOrInsertNotificationSettings(mgr, notificationSettingId);
//			notificationSetting.setNotificationType(notificationType);
//			notificationSetting.setPeriod(period);
//			
//			return updateNotificationSettings(mgr, notificationSetting);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public void resetNotificationActivities(NotificationSettings notificationSetting) throws Exception {
//		try {
//			NotificationSettings setting = (NotificationSettings)CopyUtil.copyDeeply(notificationSetting);
//			setting.setActivities(null);
//			
//			updateNotificationSettings(setting);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	@Override
//	public void permanentRemoveNotificationSettings(String notificationSettingId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			permanentRemoveNotificationSettings(mgr, notificationSettingId);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
	
//	@SuppressWarnings("unused")
//	private int bulkRemoveNotificationSettings(
//			String domainId,
//			String boardId,
//			String userId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			TypedQuery<Key> query = new QueryBuilder<>(NotificationSettings.class)
//					.addClause(FLD.deleteYN, null)
////					.addClause(FLD.domainId, domainId)	// unnecessary condition
//					.addClause(FLD.boardId, boardId)
//					.addClause(FLD.userId, userId)
//					.buildKeyOnlyRead(mgr);
//					
//			List<Key> keys = listAllKeysForLimitedChunkSize(query);
//			
//			for (Key key : keys) {
//				permanentRemoveNotificationSettings(mgr, KeyFactory.keyToString(key));
//			}
//			return keys.size();			
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}

}
