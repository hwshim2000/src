package net.forecs.coconut.endpoint.setting;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.UserSettings;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.setting.UserSetting;


public interface IUserSettingService extends ICommonService {
	public abstract List<UserSetting> listMySettings();
	public abstract List<UserSetting> listUserSettings(EntityManager mgr, String userId);
	public abstract UserSetting putMySetting(UserSetting setting) throws Exception;
	@Deprecated
	public abstract UserSettings putMySettings(UserSettings settings) throws Exception;
	public abstract Map<String, UserSetting> batchMapUserSettings(Collection<String> userIds, String settingName);
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract List<UserSetting> listMySettings(EntityManager mgr);
//	public abstract List<UserSetting> listUserSettings(String userId);
//	public abstract UserSetting getUserSetting(String userId, String settingName);
//	public abstract UserSetting getMySetting(String settingName);
//	public abstract UserSetting putUserSetting(String userId, UserSetting setting) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
