package net.forecs.coconut.endpoint.setting;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.user.Users;


public interface INotificationSettingService extends ICommonService {
	public abstract NotificationSettings getUserNotificationSettings(String userId) throws Exception;
	public abstract NotificationSettings getUserNotificationSettings(EntityManager mgr, String userId) throws Exception;
	public abstract NotificationSettings insertNotificationSettings(EntityManager mgr, NotificationSettings notificationsettings) throws Exception;
	public abstract NotificationSettings updateNotificationSettings(NotificationSettings notificationsettings) throws Exception;
	public abstract NotificationSettings updateNotificationSettings(EntityManager mgr, NotificationSettings notificationsettings) throws Exception;
	public abstract void resetNotificationActivities(EntityManager mgr, NotificationSettings notificationSetting) throws Exception;
	public abstract NotificationSettings updateNotificationQueueTaskName(NotificationSettings notificationSetting);
	public abstract void permanentRemoveUserNotificationSettings(String userId) throws Exception;
	public abstract Map<String, NotificationSettings> batchMapUserNotificationSetting(EntityManager mgr, List<Users> userList) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract NotificationSettings updateNotificationSettingsEmailPush(String notificationSettingId, String emailPushYN) throws Exception;
//	public abstract NotificationSettings updateNotificationSettingsMobilePush(String notificationSettingId, String mobilePushYN) throws Exception;
//	public abstract NotificationSettings updateNotificationSettingsType(String notificationSettingId, NotificationType notificationType, Integer period) throws Exception;
//	public abstract void resetNotificationActivities(NotificationSettings notificationSetting) throws Exception;
//	public abstract void permanentRemoveNotificationSettings(String notificationSettingId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
