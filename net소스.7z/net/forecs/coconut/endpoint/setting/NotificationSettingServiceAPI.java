package net.forecs.coconut.endpoint.setting;

import javax.inject.Inject;

import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.user.Users;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;


@Api(name = API.SETTING_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.SETTING_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class NotificationSettingServiceAPI {

	private final INotificationSettingService notificationSettingService;
	
	@Inject
	public NotificationSettingServiceAPI(INotificationSettingService notificationSettingService) {
		this.notificationSettingService = notificationSettingService;
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "getMyNotificationSettings", path = "settings/notification/my", httpMethod = HttpMethod.GET)
	@RequiresUser
	public NotificationSettings getMyNotificationSettings() throws Exception {
		Users user = CommonService.getCurrentUser();
		return notificationSettingService.getUserNotificationSettings(user.getUserId());
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "getUserNotificationSettings", path = "notificationSettings/{userId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public NotificationSettings getUserNotificationSettings(@Named(FLD.userId) String userId) throws Exception {
//		CommonService.validNamespace(userId);
//		return notificationSettingService.getUserNotificationSettings(userId);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateNotificationSettings", path = "settings/notification", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public NotificationSettings updateNotificationSettings(
			NotificationSettings notificationsetting) throws Exception {
		CommonService.validNamespace(notificationsetting);
		return notificationSettingService.updateNotificationSettings(notificationsetting);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "updateNotificationSettingsEmailPush", path = "settings/notification/emailPush", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public NotificationSettings updateNotificationSettingsEmailPush(
//			@Named(FLD.notificationSettingId) String notificationSettingId,
//			@Named(FLD.emailPushYN) String emailPushYN) throws Exception {
//		CommonService.validNamespace(notificationSettingId);
//		return notificationSettingService.updateNotificationSettingsEmailPush(notificationSettingId, emailPushYN);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "updateNotificationSettingsMobilePush", path = "settings/notification/mobilePush", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public NotificationSettings updateNotificationSettingsMobilePush(
//			@Named(FLD.notificationSettingId) String notificationSettingId,
//			@Named(FLD.mobilePushYN) String mobilePushYN) throws Exception {
//		CommonService.validNamespace(notificationSettingId);
//		return notificationSettingService.updateNotificationSettingsMobilePush(notificationSettingId, mobilePushYN);
//	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "updateNotificationSettingsType", path = "settings/notification/type", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public NotificationSettings updateNotificationSettingsType(
//			@Named(FLD.notificationSettingId) String notificationSettingId,
//			@Named(FLD.notificationType) NotificationType notificationType,
//			@Named(FLD.period) Integer period) throws Exception {
//		CommonService.validNamespace(notificationSettingId);
//		return notificationSettingService.updateNotificationSettingsType(notificationSettingId, notificationType, period);
//	}
}