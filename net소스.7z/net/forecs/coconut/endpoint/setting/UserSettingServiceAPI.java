package net.forecs.coconut.endpoint.setting;

import java.util.List;

import javax.inject.Inject;

import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.entity.setting.UserSetting;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;


@Api(name = API.SETTING_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.SETTING_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class UserSettingServiceAPI {
	private final IUserSettingService settingService;

	@Inject
	UserSettingServiceAPI(IUserSettingService settingService) {
		this.settingService = settingService;
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "listUserSettings", path = "settings/user/{userId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public List<UserSetting> listUserSettings(@Named(FLD.userId) String userId) throws UnavailableException {
//		CommonService.validNamespace(userId);
//		return settingService.listUserSettings(userId);
//	}

	// ------------- Current service(Mobile) ----------------
	@ApiMethod(name = "listMySettings", path = "mySettings")
	@RequiresUser
	public List<UserSetting> listMySettings() {
		return settingService.listMySettings();
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getUserSetting", path = "settings/user/{userId}/{settingName}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public UserSetting getUserSetting(@Named(FLD.userId) String userId,
//			@Named(FLD.settingName) String settingName) throws UnavailableException {
//		CommonService.validNamespace(userId);
//		return settingService.getUserSetting(userId, settingName);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "getMySetting", path = "settings/user/my/{settingName}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public UserSetting getMySetting(@Named(FLD.settingName) String settingName) {
//		return settingService.getMySetting(settingName);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "putUserSetting", path = "settings/user/{userId}/{settingName}", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public UserSetting putUserSetting(@Named(FLD.userId) String userId,
//			UserSetting setting) throws Exception {
//		CommonService.validNamespace(userId);
//		return settingService.putUserSetting(userId, setting);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "putMySetting", path = "settings/user/my/{settingName}", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public UserSetting putMySetting(UserSetting setting) throws Exception {
		return settingService.putMySetting(setting);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "putMySettings", path = "settings/user/my", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public UserSettings putMySettings(UserSettings settings) throws Exception {
//		return settingService.putMySettings(settings);
//	}
}
