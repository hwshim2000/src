package net.forecs.coconut.endpoint;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Named;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.Result;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;

import com.google.api.client.http.HttpStatusCodes;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.common.base.Preconditions;
import com.google.common.collect.ArrayListMultimap;


// jongwook.yi@forecs.net 2015-05-26 : Workaround to apply session to non-endpoint servlets on dev server
@Api(name = API.COMMON_SERVICE, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.COMMON_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class ServletServiceAPI {
	private static final Logger LOG = Logger.getLogger(ServletServiceAPI.class.getName());

	public static final String KEY_CONTENT_TYPE = "contentType";
	public static final String KEY_REQUEST_BODY = "requestBody";
	public static final String KEY_SERVLET_RESPONSE = "servletResponse";
	public static final String KEY_STATUS = "status";
	public static final String KEY_RESPONSE_BODY = "responseBody";

	private static final Set<String> serlvletUriSet = new HashSet<String>();
	static {
//		serlvletUriSet.add(CommonProperty.CHANNEL_CONNETED_URL);
//		serlvletUriSet.add(CommonProperty.CHANNEL_DISCONNECTED_URL);

		serlvletUriSet.add(CommonProperty.MY_GOOGLE_CALENDAR_URL);

		// Test servlets
//		serlvletUriSet.add("/login");
//		serlvletUriSet.add("/ajaxLogin");
//		serlvletUriSet.add("/socialLogin");
//		serlvletUriSet.add("/googleLogin");
//		serlvletUriSet.add("/register");
//		serlvletUriSet.add("/tasks/sendRegCode");
//		serlvletUriSet.add("/status");
//		serlvletUriSet.add("/list");
//		serlvletUriSet.add("/suspend");
//		serlvletUriSet.add("/delete");
//		serlvletUriSet.add("/settings");
	}

	@ApiMethod(name = "serviceGet", path = "service/get/{serviceUri}", httpMethod = HttpMethod.GET)
	public Result doGet(HttpServletRequest request, @Named(FLD.serviceUri) String serviceUri)
			throws IOException, ServletException {
		return service(new RequestWrapper(request, HttpMethod.GET, serviceUri));
	}

	@ApiMethod(name = "servicePost", path = "service/post/{serviceUri}", httpMethod = HttpMethod.POST)
	public Result doPost(HttpServletRequest request, @Named(FLD.serviceUri) String serviceUri,
			@Named(KEY_REQUEST_BODY) String requestBody) throws IOException, ServletException {
		return service(new RequestWrapper(request, HttpMethod.POST, serviceUri, requestBody));
	}

	private Result service(HttpServletRequest request)
			throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse)request.getAttribute(KEY_SERVLET_RESPONSE);
		ResponseWrapper wrappedResponse = new ResponseWrapper(response);

		String requestUri = request.getRequestURI();
		LOG.info("Forwarding request : requestUri=" + requestUri);
		RequestDispatcher dispatcher = request.getRequestDispatcher(requestUri);
		dispatcher.forward(request, wrappedResponse);
		return wrappedResponse.getResult();
	}

	public static boolean dispatch(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String requestUri = request.getRequestURI();

		// Endpoint API
		if (requestUri.startsWith(API.SPI_ROOT) || requestUri.startsWith(API.API_ROOT)) {
			return false;
		}
		
		if (requestUri.startsWith("/myCalendar")) {
			return false;
		}

		// Google Admin Console
		//if (requestUri.startsWith("/_ah/admin") || requestUri.equals("/_ah/resources")) {
		//	return false;
		//}

		boolean isFreemarkerTemplate = requestUri.endsWith(".ftl");
		if (!isFreemarkerTemplate && !serlvletUriSet.contains(requestUri)) {
			return false;
		}

		String queryString = request.getQueryString();
		if (!StringUtils.isEmpty(queryString)) {
			requestUri = requestUri + "?" + queryString;
		}
		String forwardUri = String.format("/_ah/api/commonService/v1/service/%s/%s",
				request.getMethod().toLowerCase(),
				URLEncoder.encode(requestUri, StandardCharsets.UTF_8.name()).replace(".", "%2E"));
		LOG.info("Forwarding servlet request : requestUri=" + requestUri + ", forwardUri=" + forwardUri);
		RequestDispatcher dispatcher = request.getRequestDispatcher(forwardUri);
		dispatcher.forward(wrap(request), wrap(response));
		return true;
	}

	private class RequestWrapper extends HttpServletRequestWrapper {
		private final String method;

		private final URL requestUrl;
		private String requestBody;		// For POST request
		private final ArrayListMultimap<String, String> parameterMap = ArrayListMultimap.create();

		private ServletInputStream wrappedInputStream;

		private ServletInputStream inputStream;
		private BufferedReader reader;

		public RequestWrapper(HttpServletRequest request, String method, String requestUri)
				throws MalformedURLException {
			super(request);
			this.method = method;
			this.requestUrl = new URL(getScheme(), getServerName(), getServerPort(), requestUri);

			extractParameters();
		}
		public RequestWrapper(HttpServletRequest request, String method, String requestUri,
				String requestBody) throws MalformedURLException {
			this(request, method, requestUri);
			this.requestBody = requestBody;
		}

		private void extractParameters() {
			String queryString = getQueryString();
			if (StringUtils.isEmpty(queryString)) {
				return;
			}

			String[] queries = queryString.split("&");
			for (String query : queries) {
				String[] parameter = query.split("=");
				String name = parameter[0];
				String value = (1 < parameter.length) ? parameter[1] : "";
				parameterMap.put(name, value);
			}
		}

		@Override
		public String getMethod() {
			return method;
		}

		@Override
		public StringBuffer getRequestURL() {
			StringBuffer buffer = new StringBuffer();

			final String scheme = getScheme();
			buffer.append(scheme);
			buffer.append("://");
			buffer.append(getServerName());

			final int port = getServerPort();
			final int defaultPort = requestUrl.getDefaultPort();
			if ((0 < port) && (port != defaultPort)) {
				buffer.append(":");
				buffer.append(port);
			}

			buffer.append(getRequestURI());

			return buffer;
		}

		@Override
		public String getServletPath() {
			return requestUrl.getPath();
		}

		@Override
		public String getRequestURI() {
			return requestUrl.getPath();
		}

		@Override
		public String getQueryString() {
			return requestUrl.getQuery();
		}

		@Override
		public String getParameter(String name) {
			List<String> values = parameterMap.get(name);
			if ((values != null) && (0 < values.size())) {
				return values.get(0);
			} else {
				return null;
			}
		}

		@Override
		public Map<String, String[]> getParameterMap() {
			Map<String, String[]> map = new HashMap<String, String[]>();
			for (String key : parameterMap.keySet()) {
				map.put(key, parameterMap.get(key).toArray(new String[0]));
			}
			return Collections.unmodifiableMap(map);
		}

		@Override
		public Enumeration<String> getParameterNames() {
			return Collections.enumeration(parameterMap.keySet());
		}

		@Override
		public String[] getParameterValues(String name) {
			List<String> values = parameterMap.get(name);
			if (values != null) {
				return values.toArray(new String[0]);
			} else {
				return null;
			}
		}

		private ServletInputStream _getInputStream() throws IOException {
			if (wrappedInputStream == null) {
				if (StringUtils.isEmpty(requestBody)) {
					wrappedInputStream = super.getInputStream();
				} else {
					wrappedInputStream = new ServletInputStreamWrapper(requestBody.getBytes(StandardCharsets.UTF_8));
				}
			}
			return wrappedInputStream;
		}

		@Override
		public ServletInputStream getInputStream() throws IOException {
			Preconditions.checkState(reader == null, "getReader has already been called.");
			if (inputStream == null) {
				inputStream = _getInputStream();
			}
			return inputStream;
		}

		@Override
		public BufferedReader getReader() throws IOException {
			Preconditions.checkState(inputStream == null, "getInputStream has already been called.");
			if (reader == null) {
				reader = new BufferedReader(new InputStreamReader(_getInputStream(), StandardCharsets.UTF_8));
			}
			return reader;
		}
	}

	private static class ResponseWrapper extends HttpServletResponseWrapper {
		private ServletOutputStream outputStreamBuffer;

		private ServletOutputStream outputStream;
		private PrintWriter writer;

		private int status = HttpStatusCodes.STATUS_CODE_OK;

		public ResponseWrapper(HttpServletResponse response) {
			super(response);
		}

		public Result getResult() {
			JSONObject jsonObject = new JSONObject();
			String contentType = (getContentType() != null) ? getContentType() : "";
			jsonObject.put(KEY_CONTENT_TYPE, contentType);
			jsonObject.put(KEY_STATUS, status);
			String responseBody = (outputStreamBuffer != null) ? outputStreamBuffer.toString() : "";
			jsonObject.put(KEY_RESPONSE_BODY, responseBody);
			LOG.info("result=" + jsonObject.toString());
			return new Result(jsonObject.toString());
		}

		@Override
		public void setStatus(int sc, String sm) {
			status = sc;
			super.setStatus(sc, sm);
		}

		@Override
		public void setStatus(int sc) {
			status = sc;
			super.setStatus(sc);
		}

		@Override
		public void sendError(int sc, String msg) throws IOException {
			status = sc;
			super.sendError(sc, msg);
		}

		@Override
		public void sendError(int sc) throws IOException {
			status = sc;
			super.sendError(sc);
		}

		@Override
		public void sendRedirect(String location) throws IOException {
			status = HttpStatusCodes.STATUS_CODE_FOUND;
			super.sendRedirect(location);
		}

		private ServletOutputStream _getOutputStream() throws IOException {
			if (outputStreamBuffer == null) {
				outputStreamBuffer = new ServletOutputStreamBuffer();
			}
			return outputStreamBuffer;
		}

		@Override
		public ServletOutputStream getOutputStream() throws IOException {
			Preconditions.checkState(writer == null, "getWriter has already been called.");
			if (outputStream == null) {
				outputStream = _getOutputStream();
			}
			return outputStream;
		}

		@Override
		public PrintWriter getWriter() throws IOException {
			Preconditions.checkState(outputStream == null, "getOutputStream has already been called.");
			if (writer == null) {
				writer = new PrintWriter(_getOutputStream(), true);
			}
			return writer;
		}
	}

	private static HttpServletRequest wrap(HttpServletRequest request) {
		if (request.getMethod().toUpperCase().equals(HttpMethod.POST)) {
			return new PostApiRequestWrapper(request);
		} else {
			return request;
		}
	}
	private static class PostApiRequestWrapper extends HttpServletRequestWrapper {
		private ServletInputStream wrappedInputStream;

		private ServletInputStream inputStream;
		private BufferedReader reader;

		public PostApiRequestWrapper(HttpServletRequest request) {
			super(request);
		}

		private ServletInputStream _getInputStream() throws IOException {
			if (wrappedInputStream == null) {
				wrappedInputStream = new InputStreamWrapper(super.getInputStream());
			}
			return wrappedInputStream;
		}

		@Override
		public ServletInputStream getInputStream() throws IOException {
			Preconditions.checkState(reader == null, "getReader has already been called.");
			if (inputStream == null) {
				inputStream = _getInputStream();
			}
			return inputStream;
		}

		@Override
		public BufferedReader getReader() throws IOException {
			Preconditions.checkState(inputStream == null, "getInputStream has already been called.");
			if (reader == null) {
				reader = new BufferedReader(new InputStreamReader(_getInputStream(), StandardCharsets.UTF_8));
			}
			return reader;
		}

		private class InputStreamWrapper extends ServletInputStreamWrapper {
			public InputStreamWrapper(ServletInputStream inputStream) throws IOException {
				super(inputStream);
			}

			@Override
			protected String readData(ServletInputStream inputStream) throws IOException {
				String data = super.readData(inputStream);

				JSONObject jsonObject = new JSONObject();
				jsonObject.put(KEY_REQUEST_BODY, data);
				return jsonObject.toString();
			}
		}
	}

	private static HttpServletResponse wrap(HttpServletResponse response) {
		return new ApiResponseWrapper(response);
	}
	private static class ApiResponseWrapper extends HttpServletResponseWrapper {
		private ServletOutputStream outputStreamBuffer;

		private ServletOutputStream outputStream;
		private PrintWriter writer;

		public ApiResponseWrapper(HttpServletResponse response) {
			super(response);
		}

		private void processApiResponse() throws IOException {
			String data = outputStreamBuffer.toString();
			if (StringUtils.isEmpty(data)) {
				return;
			}

			JSONObject jsonObject = new JSONObject(data);
			String responseBody;
			if (jsonObject.has("error")) {
				responseBody = data;
			} else {
				JSONObject result = new JSONObject(jsonObject.getString("result"));
	
				String contentType = result.getString(KEY_CONTENT_TYPE);
				setContentType(contentType);
	
				int status = result.getInt(KEY_STATUS);
				setStatus(status);
	
				responseBody = result.getString(KEY_RESPONSE_BODY);
			}

			ServletOutputStream os = super.getOutputStream();
			os.print(responseBody);
			os.close();
		}

		private ServletOutputStream _getOutputStream() throws IOException {
			if (outputStreamBuffer == null) {
				outputStreamBuffer = new OutputStreamBuffer();
			}
			return outputStreamBuffer;
		}

		@Override
		public ServletOutputStream getOutputStream() throws IOException {
			Preconditions.checkState(writer == null, "getWriter has already been called.");
			if (outputStream == null) {
				outputStream = _getOutputStream();
			}
			return outputStream;
		}

		@Override
		public PrintWriter getWriter() throws IOException {
			Preconditions.checkState(outputStream == null, "getOutputStream has already been called.");
			if (writer == null) {
				writer = new PrintWriter(_getOutputStream(), true);
			}
			return writer;
		}

		private class OutputStreamBuffer extends ServletOutputStreamBuffer {
			@Override
			public void close() throws IOException {
				processApiResponse();
			}
		}
	}

	private static class ServletInputStreamWrapper extends ServletInputStream {
		private final byte[] data;
	    private int index = 0;

	    public ServletInputStreamWrapper(byte[] data) {
			this.data = data;
		}
	    public ServletInputStreamWrapper(ServletInputStream inputStream) throws IOException {
			data = readData(inputStream).getBytes(StandardCharsets.UTF_8);
		}

		protected String readData(ServletInputStream inputStream) throws IOException {
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));

				StringBuilder sb = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					sb.append(line);
					sb.append("\r\n");
				}

				return sb.toString();
			} catch (IOException e) {
				throw e;
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
					}
				}
			}
		}

	    @Override
		public int read() throws IOException {
			if (data.length <= index) {
				return -1;
			} else {
				int read = data[index];
				++index;
				return read;
			}
		}
	}

	private static class ServletOutputStreamBuffer extends ServletOutputStream {
		private final ByteArrayOutputStream streamBuffer = new ByteArrayOutputStream();

		@Override
		public void write(int b) throws IOException {
			streamBuffer.write(b);
		}

		@Override
		public String toString() {
			return new String(streamBuffer.toByteArray(), StandardCharsets.UTF_8);
		}
	}
}