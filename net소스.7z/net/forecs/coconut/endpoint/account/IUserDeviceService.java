package net.forecs.coconut.endpoint.account;

import java.io.IOException;

import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.user.UserDevices;

import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.NotFoundException;


public interface IUserDeviceService extends ICommonService {
	public abstract QueryResult<UserDevices> listUserDevices(String cursorString, Integer limit) throws IOException;
	public abstract UserDevices insertUserDevices(UserDevices device) throws ConflictException;
	public abstract UserDevices insertOrUpdateUserDevices(UserDevices device);
	public abstract void removeUserDevices(String userDeviceId) throws NotFoundException;
	public abstract void removeUserDevices(String userId, String gcmId);
	public abstract void bulkRemoveUserDevices(String userId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract UserDevices getUserDevices(String userDeviceId);
//	public abstract UserDevices updateUserDevices(UserDevices device) throws NotFoundException;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}