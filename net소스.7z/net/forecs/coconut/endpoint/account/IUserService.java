package net.forecs.coconut.endpoint.account;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.user.UserStatus;

import com.google.api.server.spi.response.BadRequestException;
import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.InternalServerErrorException;
import com.google.api.server.spi.response.UnauthorizedException;


public interface IUserService extends ICommonService {
	public abstract String requestRegCode(String domainName, String id, String userName, String email, boolean resetPassword)
			throws ConflictException, BadRequestException, InternalServerErrorException;
	public abstract IUser confirmRegCode(String regCode, String password, String role) throws BadRequestException;
	public abstract Users login(String domainName, String id, String password, boolean rememberMe, String host)	throws UnauthorizedException;
	@Deprecated
	public abstract void logout(@Deprecated String userId, String gcmId) throws Exception;
	public abstract void logout(String gcmId) throws Exception;
	public abstract UserStatus getStatus() throws Exception;
	public abstract void prepareUserStatus(String domainName, String userId) throws Exception;

	public abstract QueryResult<Users> queryUsers(String cursorString, Integer limit, Boolean active, boolean includeProfile, String deleteYN) throws Exception;
	public abstract List<Users> listUsers(Boolean active, boolean includeProfile) throws Exception;
	public abstract List<Users> listUsers(EntityManager mgr, Boolean active, boolean includeProfile) throws Exception;

	public abstract Users getUsers(String userId, boolean includeProfile);
	public abstract Users getUsers(EntityManager mgr, String userId, boolean includeProfile);
	public abstract Users getUsers(String domainName, String id);
	public abstract String getUserEmail(String userId);
	public abstract Users findUsers(Users user) throws Exception;
	public abstract Users findByEmail(String domainName, String email);
	public abstract Users updateUsers(Users user) throws Exception;
	public abstract Users assignUsers(EntityManager mgr, Users user, boolean validCheck) throws Exception;
	public abstract Users reassignUsers(EntityManager mgr, Users user) throws Exception;
	public abstract Users unassignUsers(EntityManager mgr, Users user) throws Exception;
	public abstract Users updateUserProfile(String userId, String userName, String nickName, Date birthday, SolarType solarType) throws Exception;
	public abstract void removeUsers(String userId);
	public abstract void permanentRemoveUsers(String userId);
	public abstract Users setRole(String userId, String role) throws Exception;
	public abstract void sendLostIdEmail(String domainName, String email) throws Exception;
	public abstract void sendRandomPassword(Users user, String randomPassword);
	public abstract void sendRandomPassword(Users user, String email, String randomPassword);
	public abstract Users updatePassword(String currentPassword, String newPassword) throws Exception;
	public abstract Users updateUserEmail(String userId, String newEmail, String passsword) throws Exception;
	public abstract Users findByLowerId(String domainName, String id);
	
	public abstract Map<String, Users> batchMapUsers(EntityManager mgr, Collection<String> userIds, boolean includeProfile) throws Exception;
	public abstract Users updateImage(String userId, Images image) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract Users getUsers(String userId);
//	public abstract Users getUsers(EntityManager mgr, String userId);
//	public abstract Users getSimpleUsers(String userId);
//	public abstract Users getSimpleUsers(EntityManager mgr, String userId);
//	public abstract List<Users> listUsers(Boolean active) throws Exception;
//	public abstract List<Users> listSimpleUsers(Boolean active) throws Exception;
//	public abstract List<Users> listSimpleUsers(EntityManager mgr, Boolean active) throws Exception;
//	public abstract boolean checkDuplicationNickName(String nickName);
//	public abstract Users updateUserName(String userId, String userName) throws Exception;
//	public abstract Users updateUserNickName(String userId, String nickName) throws Exception;
//	public abstract Users updateUserBirthday(String userId, Date birthday, SolarType solarType) throws Exception;
//	public abstract Users addPermissions(String userId, Set<String> permissions) throws Exception;
//	public abstract Users removePermissions(String userId, Set<String> permissions) throws Exception;
//	public abstract UserIndex createOrUpdateUserIndex(Users user);
//	public abstract Images getImage(String userId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
	