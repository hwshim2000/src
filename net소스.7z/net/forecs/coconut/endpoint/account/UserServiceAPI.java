package net.forecs.coconut.endpoint.account;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.UnavailableException;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.user.UserDevices;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.user.Role;

import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.CollectionResponse;
import com.google.api.server.spi.response.ConflictException;


@Api(name = API.ACCOUNT_SERVICE, version = API.VERSION, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ACCOUNT_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
@RequiresUser
public class UserServiceAPI {
	private final IUserService userService;
	private final IUserDeviceService userDeviceService;

	@Inject
	public UserServiceAPI(IUserService userService, IUserDeviceService userDeviceService) {
		this.userService = userService;
		this.userDeviceService = userDeviceService;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "listUsers", path = "users", httpMethod = HttpMethod.GET)
	@RequiresUser
	public CollectionResponse<Users> listUsers(
			@Nullable @Named(FLD.cursor) String cursorString,
			@Nullable @Named(FLD.limit) Integer limit,
			@Nullable @Named(FLD.active) Boolean active) throws Exception {
		QueryResult<Users> queryResult = userService.queryUsers(cursorString, limit, active, true, CommonService.N);
		List<Users> list = queryResult.getResultList();
		String nextPageToken = queryResult.getNextPageToken();
		return CollectionResponse.<Users>builder().setItems(list).setNextPageToken(nextPageToken).build();
	}

	// ------------- Current service(Mobile) ----------------
	@ApiMethod(name = "getUsers", path = "users/{userId}", httpMethod = HttpMethod.GET)
	@RequiresUser
	public Users getUsers(@Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(userId);
		return userService.getUsers(userId, true);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateUsers", path = "users", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Users updateUsers(Users user) throws Exception {
		CommonService.validNamespace(user.getUserId());
		return userService.updateUsers(user);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "updateUserName", path = "users/{userId}/userName", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Users updateUserName(@Named(FLD.userId) String userId, @Named(FLD.userName) String userName) throws Exception {
//		CommonService.validNamespace(userId);
//		return userService.updateUserName(userId, userName);
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "updateUserNickName", path = "users/{userId}/nickName", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Users updateUserNickName(@Named(FLD.userId) String userId, @Named(FLD.nickName) String nickName) throws Exception {
//		CommonService.validNamespace(userId);
//		return userService.updateUserNickName(userId, nickName);
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "updateUserBirthday", path = "users/{userId}/birthday", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public Users updateUserBirthday(@Named(FLD.userId) String userId, @Named(FLD.birthDay) Date birthday, @Named(FLD.solarType) SolarType solarType) throws Exception {
//		CommonService.validNamespace(userId);
//		return userService.updateUserBirthday(userId, birthday, solarType);
//	}

	// ------------- Current service ----------------
	@ApiMethod(name = "updateUserProfile", path = "users/{userId}/profile", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Users updateUserProfile(
			@Named(FLD.userId) String userId, 
			@Nullable @Named(FLD.userName) String userName, 
			@Nullable @Named(FLD.nickName) String nickName, 
			@Nullable @Named(FLD.birthDay) Date birthday, 
			@Nullable @Named(FLD.solarType) SolarType solarType) throws Exception {
		CommonService.validNamespace(userId);
		return userService.updateUserProfile(userId, userName, nickName, birthday, solarType);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "findByEmail", path = "users/findUserByEmail", httpMethod = HttpMethod.GET)
//	public Users findByEmail(@Named(FLD.domainName) String domainName, @Named(FLD.email) String email) {
//		return userService.findByEmail(domainName, email);
//	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "sendLostIdEmail", path = "users/sendLostIdEmail", httpMethod = HttpMethod.POST)
	public void sendLostIdEmail(@Named(FLD.domainName) String domainName, @Named(FLD.email) String email) throws Exception{
		userService.sendLostIdEmail(domainName, email);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updatePassword", path = "users/password", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Users updatePassword(@Named(FLD.currentPassword) String currentPassword, @Named(FLD.newPassword) String newPassword) throws Exception {
		return userService.updatePassword(currentPassword, newPassword);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateUserEmail", path = "users/{userId}/email", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Users updateUserEmail(@Named(FLD.userId) String userId, @Named(FLD.newEmail) String newEmail, @Named(FLD.password) String password) throws Exception {
		CommonService.validNamespace(userId);
		return userService.updateUserEmail(userId, newEmail, password);
	}
	
	// ------------- Current service ----------------
	@ApiMethod(name = "updateImage", path = "users/{userId}/image", httpMethod = HttpMethod.PUT)
	@RequiresUser
	public Users updateImage(@Named(FLD.userId) String userId, Images image) throws Exception {
		CommonService.validNamespace(userId);
		return userService.updateImage(userId, image);
	}
	
	// ************* Unused service ******************
//	@ApiMethod(name = "getImage", path = "users/{userId}/image", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public Images getImage(@Named(FLD.userId) String userId) throws Exception {
//		CommonService.validNamespace(userId);
//		return userService.getImage(userId);
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "setRole", path = "users/{userId}/role", httpMethod = HttpMethod.PUT)
//	@RequiresRoles(Role.SUPER)
//	public Users setRole(@Named(FLD.userId) String userId, @Named(FLD.role) String role) throws Exception {
//		CommonService.validNamespace(userId);
//		return userService.setRole(userId, role);
//	}
	// 
	// ------------- Current service(Mobile) ----------------
	// -=-=-=-=-= Moved(userDeviceServiceAPI에서 이동함.) -=-=-=-=-=
	@ApiMethod(name = "insertUserDevices", path = "devices", httpMethod = HttpMethod.POST)
	@RequiresUser
	public UserDevices insertUserDevices(UserDevices device) throws ConflictException, UnavailableException {
		CommonService.validNamespace(device.getOwner());
		return userDeviceService.insertOrUpdateUserDevices(device);
	}
	
	@ApiMethod(name = "removeUserDevices", path = "devices/{userId}/{gcmId}", httpMethod = HttpMethod.DELETE)
	@RequiresUser
	public void removeUserDevices(@Named(FLD.userId) String userId, @Named(FLD.gcmId) String gcmId) throws  UnavailableException {
		CommonService.validNamespace(userId);
		userDeviceService.removeUserDevices(userId, gcmId);
	}
	
	@ApiMethod(name = "removeUsers", path = "Users", httpMethod = HttpMethod.DELETE)
	@RequiresRoles(value = { Role.ADMIN, Role.SUPER }, logical = Logical.OR)
	public void removeUsers(@Named(FLD.userId) String userId) throws Exception {
		CommonService.validNamespace(userId);
		userService.removeUsers(userId);
	}
}