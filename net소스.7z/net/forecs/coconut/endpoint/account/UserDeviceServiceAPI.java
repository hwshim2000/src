package net.forecs.coconut.endpoint.account;


@Deprecated
//@Api(name = API.ACCOUNT_SERVICE, version = API.VERSION, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ACCOUNT_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
//@RequiresUser
public class UserDeviceServiceAPI {
//	private final IUserDeviceService userDeviceService;

//	@Inject
//	public UserDeviceServiceAPI(IUserDeviceService userDeviceService) {
//		this.userDeviceService = userDeviceService;
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "listUserDevices", path = "devices", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public CollectionResponse<UserDevices> listUserDevices(
//			@Nullable @Named(FLD.cursor) String cursorString,
//			@Nullable @Named(FLD.limit) Integer limit) {
//		QueryResult<UserDevices> queryResult = userDeviceService.listUserDevices(cursorString, limit);
//		List<UserDevices> list = queryResult.getResultList();
//		String nextPageToken = queryResult.getNextPageToken();
//		return CollectionResponse.<UserDevices>builder().setItems(list).setNextPageToken(nextPageToken).build();
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "getUserDevices", path = "devices/{userDeviceId}", httpMethod = HttpMethod.GET)
//	@RequiresUser
//	public UserDevices getUserDevices(@Named(FLD.userDeviceId) String userDeviceId) throws Exception {
//		CommonService.validNamespace(userDeviceId);
//		return userDeviceService.getUserDevices(userDeviceId);
//	}

	// ------------- Current service(Mobile) ----------------
	// -=-=-=-=-= Moved(UserServiceAPI 로 이동함.) -=-=-=-=-=
//	@ApiMethod(name = "insertUserDevices", path = "devices", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	public UserDevices insertUserDevices(UserDevices device) throws ConflictException, UnavailableException {
//		CommonService.validNamespace(device.getOwner());
//		return userDeviceService.insertUserDevices(device);
//	}

	// ************* Unused service ******************
//	@ApiMethod(name = "updateUserDevices", path = "devices", httpMethod = HttpMethod.PUT)
//	@RequiresUser
//	public UserDevices updateUserDevices(UserDevices device) throws NotFoundException, UnavailableException {
//		CommonService.validNamespace(device);
//		return userDeviceService.updateUserDevices(device);
//	}
	// ************* Unused service ******************
//	@ApiMethod(name = "removeUserDevices", path = "devices/{userDeviceId}", httpMethod = HttpMethod.DELETE)
//	@RequiresUser
//	public void removeUserDevices(@Named(FLD.userDeviceId) String userDeviceId) throws NotFoundException, UnavailableException {
//		CommonService.validNamespace(userDeviceId);
//		userDeviceService.removeUserDevices(userDeviceId);
//	}
}