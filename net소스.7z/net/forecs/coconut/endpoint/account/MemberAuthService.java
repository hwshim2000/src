package net.forecs.coconut.endpoint.account;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.MemcacheManager;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.AuthKind;
import net.forecs.coconut.common.code.AuthStatus;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.user.Users;

import com.google.api.server.spi.response.ConflictException;


public class MemberAuthService extends CommonService implements IMemberAuthService {
	private static final Logger LOG = Logger.getLogger(MemberAuthService.class.getName());
	private final IUserService userService;
	
	@Inject
	public MemberAuthService(IUserService userService) {
		this.userService = userService;
	}

	@Override
	public void permanentRemoveMemberAuths(EntityManager mgr, String memberAuthId) {
		try {
			doRemoveTransaction(mgr, MemberAuths.class, memberAuthId);
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public int bulkRemoveMemberAuths (
			String boardId,
			Auth auth,
			AuthKind authKind,
			String kindId,
			AuthStatus authStatus,
			String userId) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			TypedQuery<MemberAuths> query = new QueryBuilder<>(MemberAuths.class)
								.addClause(FLD.boardId, boardId)
								.addClause(FLD.auth, auth)
								.addClause(FLD.authKind, authKind)
								.addClause(FLD.kindId, kindId)
								.addClause(FLD.authStatus, authStatus)
								.addClause(FLD.userId, userId)
								.build(mgr);
			List<MemberAuths> results = query.getResultList();
			doRemoveTransaction(mgr, results);
			return results.size();
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public MemberAuths getMemberAuths(String kindId, String userId) {
		return getMemberAuths(KeyUtil.createMemberAuthKeyString(kindId, userId));
	}
	@Override
	public MemberAuths getMemberAuths(EntityManager mgr, String kindId, String userId) {
		return getMemberAuths(mgr, KeyUtil.createMemberAuthKeyString(kindId, userId));
	}
	private MemberAuths getMemberAuths(String memberAuthId) {
		EntityManager mgr = getEntityManager();
		try {
			return getMemberAuths(mgr, memberAuthId);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private MemberAuths getMemberAuths(EntityManager mgr, String memberAuthId) {
		MemberAuths memberAuth = doFind(mgr, MemberAuths.class, memberAuthId);
		if (memberAuth != null) {
			Users user = userService.getUsers(mgr, memberAuth.getUserId(), false);
			memberAuth.setUser(user);
		}
		return memberAuth;
	}

	@Override
	public List<MemberAuths> listMemberAuths(
			EntityManager mgr, Collection<String> boardIdList, Auth auth,
			AuthKind authKind, String kindId, AuthStatus authStatus,
			String userId, boolean includeUser) throws Exception {
		try {
			MemcacheManager<MemberAuths, List<MemberAuths>> mm = new MemcacheManager<>(MemberAuths.class, MemcacheManager.keySet(boardIdList));
			String memberMemcacheKey = mm.createMemcacheKey(boardIdList, auth, authKind, kindId, authStatus, userId);
			List<MemberAuths> memberAuthList = mm.getMemcache(memberMemcacheKey);
			
			if (memberAuthList == null) {
				DsQuery<MemberAuths> dsQuery = new DsQuery<>(MemberAuths.class)
						.in(FLD.boardId, boardIdList)
						.eq(FLD.auth, auth)
						.eq(FLD.authKind, authKind)
						.eq(FLD.kindId, kindId)
						.eq(FLD.authStatus, authStatus)
						.eq(FLD.userId, userId);
	
				List<MemberAuths> results = dsQuery.execute(mgr);
				memberAuthList = new ArrayList<MemberAuths>();
				
				for (MemberAuths memberAuth : results) {
					memberAuthList.add(memberAuth);
				}
				
				mm.setMemcache(memberMemcacheKey, memberAuthList);
			}
				
			if (includeUser) {
				Map<String, Users> userMap = batchMapMemberAuthUsers(mgr, memberAuthList, true);
				for (MemberAuths memberAuth : memberAuthList) {
					Users user = userMap.get(memberAuth.getUserId());
					if (user != null) {
						memberAuth.setUser(user);
					}
				}
			}

			return memberAuthList;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private Map<String, Users> batchMapMemberAuthUsers(EntityManager mgr, List<MemberAuths> memberAuthList, boolean includeProfile) throws Exception {
		Set<String> userIds = new HashSet<String>();
		for (MemberAuths memberAuth : memberAuthList) {
			userIds.add(memberAuth.getUserId());
		}
		return userService.batchMapUsers(mgr, userIds, includeProfile);
	}
	
	@Override
	public Map<String, List<Users>> batchMapTaskMembers(EntityManager mgr, Collection<String> taskIds) throws Exception {
		try {
			MemcacheManager<MemberAuths, List<MemberAuths>> mm = new MemcacheManager<>(MemberAuths.class, MemcacheManager.keySet(taskIds));
			String memberMemcacheKey = mm.createMemcacheKey(taskIds);
			List<MemberAuths> memberAuthList = mm.getMemcache(memberMemcacheKey);

			if (memberAuthList == null) {
				memberAuthList = new ArrayList<MemberAuths>();
				DsQuery<MemberAuths> dsQuery = new DsQuery<>(MemberAuths.class)
						.in(FLD.kindId, taskIds)
						.eq(FLD.authKind, AuthKind.TASKS)
						.eq(FLD.authStatus, AuthStatus.ACTIVE);
				
				List<MemberAuths> members = dsQuery.execute(mgr);
				memberAuthList.addAll(members);
				mm.setMemcache(memberMemcacheKey, memberAuthList);
			}
			
			Map<String, List<Users>> taskUsersMap = new HashMap<String, List<Users>>();
			Map<String, Users> userMap = batchMapMemberAuthUsers(mgr, memberAuthList, true);
			
			for (MemberAuths memberAuth : memberAuthList) {
				Users user = userMap.get(memberAuth.getUserId());
				if (user != null) {
					memberAuth.setUser(user);
				}
				String taskId = memberAuth.getKindId();
				if (!taskUsersMap.containsKey(taskId)) { taskUsersMap.put(taskId, new ArrayList<Users>()); }
				taskUsersMap.get(taskId).add(memberAuth.getUser());
			}
			
			return taskUsersMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Map<String, List<Users>> batchMapTaskMembers(EntityManager mgr, Collection<String> boardIds, Collection<String> taskIds) throws Exception {
		try {
			List<MemberAuths> memberAuthList = listTaskMembers(mgr, boardIds, taskIds);
			
			Map<String, List<Users>> taskUsersMap = new HashMap<String, List<Users>>();
			Map<String, Users> userMap = batchMapMemberAuthUsers(mgr, memberAuthList, true);
			
			for (MemberAuths memberAuth : memberAuthList) {
				if (!taskIds.contains(memberAuth.getKindId())) { continue; }
				
				Users user = userMap.get(memberAuth.getUserId());
				if (user != null) {
					memberAuth.setUser(user);
				}
				String taskId = memberAuth.getKindId();
				if (!taskUsersMap.containsKey(taskId)) { taskUsersMap.put(taskId, new ArrayList<Users>()); }
				taskUsersMap.get(taskId).add(memberAuth.getUser());
			}
			
			return taskUsersMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public Map<String, List<String>> batchMapTaskMemberIds(EntityManager mgr, Collection<String> boardIds, Collection<String> taskIds) throws Exception {
		try {
			List<MemberAuths> memberAuthList = listTaskMembers(mgr, boardIds, taskIds);
			Map<String, List<String>> taskUsersIdMap = new HashMap<String, List<String>>();
			
			for (MemberAuths memberAuth : memberAuthList) {
				String taskId = memberAuth.getKindId();
				if (!taskIds.contains(taskId)) { continue; }
			
				if (!taskUsersIdMap.containsKey(taskId)) { taskUsersIdMap.put(taskId, new ArrayList<String>()); }
				taskUsersIdMap.get(taskId).add(memberAuth.getUserId());
			}
			
			return taskUsersIdMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<MemberAuths> listTaskMembers(EntityManager mgr, Collection<String> boardIds, Collection<String> taskIds) throws Exception {
		try {
			List<String> boardIdList = new ArrayList<String>(boardIds);
			java.util.Collections.sort(boardIdList);
			MemcacheManager<MemberAuths, List<MemberAuths>> mm = new MemcacheManager<>(MemberAuths.class, MemcacheManager.keySet(boardIdList));
			String memberMemcacheKey = mm.createMemcacheKey(boardIdList);
			List<MemberAuths> memberAuthList = mm.getMemcache(memberMemcacheKey);

			Set<String> boardIdSet = null;
			
			if (boardIdList != null && boardIdList.size() > CommonProperty.SUBQUERY_PARAM_COUNT) {
				boardIdSet = new HashSet<String>(boardIdList);
				boardIdList = null;
			}
			
			if (memberAuthList == null) {
				memberAuthList = new ArrayList<MemberAuths>();
				DsQuery<MemberAuths> dsQuery = new DsQuery<>(MemberAuths.class)
						.in(FLD.boardId, boardIdList)
						.eq(FLD.authKind, AuthKind.TASKS)
						.eq(FLD.authStatus, AuthStatus.ACTIVE);
				
				List<MemberAuths> members = dsQuery.execute(mgr);
				for (MemberAuths memberAuth : members) {
					if (boardIdSet != null && !boardIdSet.contains(memberAuth.getBoardId())) { continue; }
					memberAuthList.add(memberAuth);
				}
				
				mm.setMemcache(memberMemcacheKey, memberAuthList);
			}
			return memberAuthList;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public List<String> batchMapUserTaskIds(EntityManager mgr, Collection<String> boardIds, Collection<String> userIds) throws Exception {
		try {
			List<String> boardIdList = new ArrayList<String>(boardIds);
			java.util.Collections.sort(boardIdList);
			MemcacheManager<MemberAuths, List<MemberAuths>> mm = new MemcacheManager<>(MemberAuths.class, MemcacheManager.keySet(boardIdList));
			String memberMemcacheKey = mm.createMemcacheKey(boardIdList, userIds);
			List<MemberAuths> memberAuthList = mm.getMemcache(memberMemcacheKey);

			Set<String> boardIdSet = null;
			
			if (boardIdList != null && boardIdList.size() > CommonProperty.SUBQUERY_PARAM_COUNT) {
				boardIdSet = new HashSet<String>(boardIdList);
				boardIdList = null;
			}
			
			if (memberAuthList == null) {
				memberAuthList = new ArrayList<MemberAuths>();
				DsQuery<MemberAuths> dsQuery = new DsQuery<>(MemberAuths.class)
						.in(FLD.boardId, boardIdList)
						.eq(FLD.authKind, AuthKind.TASKS)
						.eq(FLD.authStatus, AuthStatus.ACTIVE);
				
				List<MemberAuths> members = dsQuery.execute(mgr);
				for (MemberAuths memberAuth : members) {
					if (boardIdSet != null && !boardIdSet.contains(memberAuth.getBoardId())) { continue; }
					memberAuthList.add(memberAuth);
				}
				
				mm.setMemcache(memberMemcacheKey, memberAuthList);
			}
			
			List<String> taskIds = new ArrayList<String>();
			
			for (MemberAuths memberAuth : memberAuthList) {
				if (!userIds.contains(memberAuth.getUserId())) { continue; }
				taskIds.add(memberAuth.getKindId());
			}
			
			return taskIds;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public Map<String, List<Boards>> batchMapUserBoards(EntityManager mgr, Collection<String> userIdList) throws Exception {
		try {
			List<MemberAuths> memberAuthList = batchListMemberAuth(mgr, userIdList, AuthKind.BOARDS, AuthStatus.ACTIVE);
			Set<String> boardIds = new HashSet<String>();
			
			for (MemberAuths memberAuth : memberAuthList) {
				boardIds.add(memberAuth.getBoardId());
			}
			Map<String, Boards> boardsMap = batchMapByKey(mgr, Boards.class, boardIds);
					
			Map<String, List<Boards>> userBoardsMap = new HashMap<String, List<Boards>>();
			for (MemberAuths memberAuth : memberAuthList) {
				Boards board = boardsMap.get(memberAuth.getBoardId());
				if (board != null) {
					String userId = memberAuth.getUserId();
					//boolean userIsOwner = board.isOwner(userId);
					//if (isValid(board) || user.isSuper() || userIsOwner) {
					if (isValid(board)) {
						if (!userBoardsMap.containsKey(userId)) { userBoardsMap.put(userId, new ArrayList<Boards>()); }
						userBoardsMap.get(userId).add(board);
					}
				} else {
					LOG.warning("[FIXME] Invalid MemberAuths : boardId=" + memberAuth.getBoardId());
				}
			}
			
			return userBoardsMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public List<MemberAuths> batchListMemberAuthsOfTask(EntityManager mgr, String taskId, Collection<String> userIds) throws Exception {
		try {
			Set<String> memberAuthIds = new HashSet<String>();
			for (String userId : userIds) {
				memberAuthIds.add(KeyUtil.createMemberAuthKeyString(taskId, userId));
			}
			
			return batchListByKey(mgr, MemberAuths.class, memberAuthIds);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	private List<MemberAuths> batchListMemberAuth(EntityManager mgr, Collection<String> userIdList, AuthKind authKind, AuthStatus authStatus) throws Exception {
		try {
			MemcacheManager<MemberAuths, List<MemberAuths>> mm = new MemcacheManager<>(MemberAuths.class, MemcacheManager.keySet(userIdList));
			String memberMemcacheKey = mm.createMemcacheKey(userIdList, authKind, authStatus);
			List<MemberAuths> memberAuthList = mm.getMemcache(memberMemcacheKey);
			
			if (memberAuthList == null) {
				memberAuthList = new ArrayList<MemberAuths>();
				List<String> idList = new ArrayList<String>(userIdList);
					
				DsQuery<MemberAuths> dsQuery = new DsQuery<>(MemberAuths.class)
							.in(FLD.userId, idList)
							.eq(FLD.authKind, authKind)
							.eq(FLD.authStatus, authStatus);
				List<MemberAuths> members = dsQuery.execute(mgr);
				memberAuthList.addAll(members);
				mm.setMemcache(memberMemcacheKey, memberAuthList);
			}
			
			return memberAuthList;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public MemberAuths updateMemberAuths(EntityManager mgr, MemberAuths memberAuth) throws Exception {
		try {
			doMerge(mgr, memberAuth);
			
			if (memberAuth.getUser() == null) {
				memberAuth.setUser(userService.getUsers(memberAuth.getUserId(), true));
			}
			
			return memberAuth;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public MemberAuths reassignMemberAuths(EntityManager mgr, MemberAuths memberAuth) throws Exception {
		try {
			memberAuth.setDeleted(null);
			memberAuth.setDeleteYN(N);
			memberAuth.setAuthStatus(AuthStatus.ACTIVE);
			
			doMerge(mgr, memberAuth);

			if (memberAuth.getUser() == null) {
				memberAuth.setUser(userService.getUsers(memberAuth.getUserId(), true));
			}

			return memberAuth;
		} catch (Exception ex) {
			throw ex;
		}
	}

	@Override
	public MemberAuths insertMemberAuths(EntityManager mgr, MemberAuths memberAuth) throws Exception {
		try {
			if (contains(mgr, MemberAuths.class, memberAuth.getKey())) {
				throw new ConflictException(ErrorCode.MEMBER_ASSIGN_FAIL.getMessage(MemberAuths.class, memberAuth.getUserId()));
			}
			
			doPersist(mgr, memberAuth);
			
			if (memberAuth.getUser() == null) {
				memberAuth.setUser(userService.getUsers(mgr, memberAuth.getUserId(), true));
			}
			
			return memberAuth;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public void reassignAllMemberAuth(List<String> userIdList, AuthKind authKind) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<MemberAuths> memberAuthList = batchListMemberAuth(mgr, userIdList, authKind, AuthStatus.INACTIVE);

			for (MemberAuths memberAuth : memberAuthList) {
				memberAuth.setAuthStatus(AuthStatus.ACTIVE);
			}
			
			doMergeTransaction(mgr, memberAuthList);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public void unassignAllMemberAuth(List<String> userIdList, AuthKind authKind) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<MemberAuths> memberAuthList = batchListMemberAuth(mgr, userIdList, authKind, AuthStatus.ACTIVE);

			for (MemberAuths memberAuth : memberAuthList) {
				memberAuth.setAuthStatus(AuthStatus.INACTIVE);
			}
			
			doMergeTransaction(mgr, memberAuthList);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void reassignAllMemberAuth(String userId, AuthKind authKind) throws Exception {
		updateAllMemberAuth(userId, authKind, AuthStatus.ACTIVE);
	}
	@Override
	public void unassignAllMemberAuth(String userId, AuthKind authKind) throws Exception {
		updateAllMemberAuth(userId, authKind, AuthStatus.INACTIVE);
	}
	
	private void updateAllMemberAuth(String userId, AuthKind authKind, AuthStatus authStatus) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			List<MemberAuths> authList = listMemberAuths(mgr, null, null, authKind, null, null, userId, true);
			
			for (MemberAuths memberAuth : authList) {
				memberAuth.setAuthStatus(authStatus);
			}
			
			doMergeTransaction(mgr, authList);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public QueryResult<MemberAuths> queryMemberAuths(
//			String cursorString,
//			Integer limit,
//			Collection<String> boardIdList,
//			Auth auth,
//			AuthKind authKind,
//			String kindId,
//			AuthStatus authStatus,
//			String userId,
//			boolean simpleMode
//			/*, AuthQueryOption authQueryOption */) throws Exception {
//		
//		EntityManager mgr = getEntityManager();
//		try {
//			MemcacheManager<MemberAuths, List<MemberAuths>> mm = new MemcacheManager<>(MemberAuths.class, MemcacheManager.keySet(boardIdList));
//			
//			String memberMemcacheKey = mm.createMemcacheKey(cursorString, limit, boardIdList, auth, authKind, kindId, authStatus, userId /*, authQueryOption*/);
//			List<MemberAuths> memberAuthList = mm.getMemcache(memberMemcacheKey);
//			
//			if (memberAuthList == null ) {
//				Set<String> boardIdSet = null;
//				if (boardIdList != null && boardIdList.size() > CommonProperty.SUBQUERY_PARAM_COUNT) {
//					boardIdSet = new HashSet<String>();
//					for (String boardId : boardIdList) { boardIdSet.add(boardId); }
//					boardIdList = null;
//				}
//				
//				memberAuthList = new ArrayList<MemberAuths>();
//				TypedQuery<Key> query = new QueryBuilder<>(MemberAuths.class)
//									.addFilter(FLD.boardId, boardIdList)
//									.addClause(FLD.auth, auth)
//									.addClause(FLD.authKind, authKind)
//									.addClause(FLD.kindId, kindId)
//									.addClause(FLD.authStatus, authStatus)
//									.addClause(FLD.userId, userId)
//									//.addQueryOption(authQueryOption)
//									.buildKeyOnlyRead(mgr);
//	
//				int cursorPosition = QueryBuilder.getCursorPosition(cursorString);
//				
//				do {
//					query.setFirstResult(cursorPosition);
//					if (limit != null) {
//						query.setMaxResults(limit);
//					}
//				
//					List<MemberAuths> results = queryResults(mgr, MemberAuths.class, query);
//					
//					for (MemberAuths timeline : results) {
//						cursorPosition++;
//						if (boardIdSet != null && !boardIdSet.contains(timeline.getBoardId())) { continue; }
//						
//						memberAuthList.add(timeline);
//						if (limit != null && memberAuthList.size() == limit) {
//							break;
//						}
//					}
//					if (limit != null && (results.size() != limit || memberAuthList.size() == limit)) { break; }
//				} while (limit != null);
//				
//				cursorString = QueryBuilder.getCursorString(cursorPosition);
//				mm.setMemcache(memberMemcacheKey, memberAuthList, cursorString);
//			} else {
//				cursorString = mm.getCursorString(memberMemcacheKey);
//			}
//
//			if (!simpleMode) {
//				Map<String, Users> userMap = batchMapMemberAuthUsers(mgr, memberAuthList, true);
//				for (MemberAuths memberAuth : memberAuthList) {
//					Users user = userMap.get(memberAuth.getUserId());
//					if (user != null) {
//						memberAuth.setUser(user);
//					}
//				}
//			}
//			
//			return new QueryResult<MemberAuths>(memberAuthList, cursorString);
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public long countMemberAuths(AuthKind authKind,	String userId) throws Exception {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			SimpleQuery<MemberAuths> sq = new SimpleQuery<>(mgr, MemberAuths.class);
//			sq.where(sq.and(
//					sq.equal(FLD.authKind, authKind),
//					sq.equal(FLD.userId, userId)
//			));
//			TypedQuery<Long> query = sq.count();
//			return query.getSingleResult();
//		} catch (Exception ex) {
//			throw ex;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	//(성능을 고려하여, 단일 쿼리로 태스크의 모든 멤버롤 검색 후 분리함.
//	@Override
//	public Map<String, List<Users>> batchMapTaskAllMembers(EntityManager mgr, String taskId) throws Exception {
//		try {
//			MemcacheManager<MemberAuths, List<MemberAuths>> mm = new MemcacheManager<>(MemberAuths.class, taskId+"_ALL");
//			String memberMemcacheKey = mm.createMemcacheKey(taskId+"_ALL");
//			List<MemberAuths> memberAuthList = mm.getMemcache(memberMemcacheKey);
//
//			if (memberAuthList == null) {
//				memberAuthList = new ArrayList<MemberAuths>();
//				Query query = new DsQuery(MemberAuths.class)
//						.eq(FLD.kindId, taskId)
//						.eq(FLD.authKind, AuthKind.TASKS)
//						.setKeysOnly();
//				
//				List<MemberAuths> members = queryResults(mgr, MemberAuths.class, query);
//				memberAuthList.addAll(members);
//				mm.setMemcache(memberMemcacheKey, memberAuthList);
//			}
//			
//			Map<String, List<Users>> taskUsersMap = new HashMap<String, List<Users>>();
//			List<Users> assignedMembers = new ArrayList<Users>();
//			List<Users> unassignedMembers = new ArrayList<Users>();
//			
//			Map<String, Users> userMap = batchMapMemberAuthUsers(mgr, memberAuthList, true);
//			
//			for (MemberAuths memberAuth : memberAuthList) {
//				Users user = userMap.get(memberAuth.getUserId());
//				if (user == null) { continue; }
//				if (AuthStatus.ACTIVE.equals(memberAuth.getAuthStatus()) && isValid(user)) {
//					assignedMembers.add(user);
//				} else {
//					unassignedMembers.add(user);
//				}
//			}
//			
//			taskUsersMap.put(TaskService.ITEM_ASSIGNED_MEMBERS, assignedMembers);
//			taskUsersMap.put(TaskService.ITEM_UNASSIGNED_MEMBERS, unassignedMembers);
//			
//			return taskUsersMap;
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
