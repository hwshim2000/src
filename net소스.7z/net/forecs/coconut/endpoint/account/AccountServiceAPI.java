package net.forecs.coconut.endpoint.account;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.METHOD;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.security.SsoServiceManager;
import net.forecs.coconut.user.Role;
import net.forecs.coconut.user.UserStatus;

import org.apache.shiro.authz.annotation.RequiresUser;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiAuth;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiMethod.HttpMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.server.spi.response.BadRequestException;
import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.InternalServerErrorException;


@Api(name = API.ACCOUNT_SERVICE, version = API.VERSION, namespace = @ApiNamespace(ownerDomain = API.OWNER_DOMAIN, ownerName = API.OWNER_NAME, packagePath = API.ACCOUNT_SERVICE_PACKAGE), auth = @ApiAuth(allowCookieAuth = AnnotationBoolean.TRUE))
public class AccountServiceAPI {
	//private static final Logger LOG = Logger.getLogger(AccountServiceAPI.class.getName());
	private final IDomainService domainService;
	private final IUserService userService;
	
	@Inject
	public AccountServiceAPI(
			IDomainService domainService,
			IUserService userService) {
		this.domainService = domainService;
		this.userService = userService;
	}

	// ------------- Current service(Mobile) ----------------
	@Deprecated
	@ApiMethod(name = "signup", path = "account/signup", httpMethod = HttpMethod.POST)
	public Users signup(@Nullable @Named(FLD.domainName) String domainName, @Named(FLD.id) String id,
			@Nullable @Named(FLD.userName) String userName, @Named(FLD.email) String email,
			@Named(FLD.password) String password) throws Exception {
		String regCode = userService.requestRegCode(domainName, id, userName, email, false);
		requestSignup(id, userName, email);
		return confirmSignup(regCode, password);
	}

	// ============= Reference service =================
	// 위 signup 함수에서 참조하고 있다.
	@ApiMethod(name = "requestSignup", path = "account/requestSignup", httpMethod = HttpMethod.POST)
	public void requestSignup(@Named(FLD.id) String id,
			@Nullable @Named(FLD.userName) String userName, @Named(FLD.email) String email)
			throws ConflictException, BadRequestException, InternalServerErrorException {
		userService.requestRegCode(null, id, userName, email, false);
	}

	// ============= Reference service =================
	// 등록 이메일등에서 사용하고 있다.
	@ApiMethod(name = "confirmSignup", path = "account/confirmSignup", httpMethod = HttpMethod.POST)
	public Users confirmSignup(@Named(FLD.regCode) String regCode, @Named(FLD.password) String password)
			throws BadRequestException {
		IUser user = userService.confirmRegCode(regCode, password, Role.ADMIN);
		return (Users)user;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "resetPassword", path = "account/resetPassword", httpMethod = HttpMethod.PUT)
	public void resetPassword(@Named(FLD.domainName) String domainName,
			@Named(FLD.id) String id, @Nullable @Named(FLD.userName) String userName, @Named(FLD.email) String email)
			throws ConflictException, BadRequestException, InternalServerErrorException {
		userService.requestRegCode(domainName, id, userName, email, true);
	}

	// ------------- Current service & Reference service ----------------
	@ApiMethod(name = "confirmPassword", path = "account/confirmPassword", httpMethod = HttpMethod.POST)
	public Users confirmPassword(@Named(FLD.regCode) String regCode, @Named(FLD.password) String password)
			throws BadRequestException {
		IUser user = userService.confirmRegCode(regCode, password, null);
		return (Users)user;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = METHOD.login, path = "account/login", httpMethod = HttpMethod.POST)
	public Users login(HttpServletRequest request,
			@Nullable @Named(FLD.domainName) String domainName,
			@Named(FLD.id) String id, @Named(FLD.password) String password,
			@Nullable @Named(FLD.rememberMe) String rememberMe) throws Exception {
		String host = request.getRemoteHost();
		return userService.login(domainName, id, password,
				Boolean.parseBoolean(rememberMe), host);
	}
	
	@ApiMethod(name = METHOD.serviceLogin, path = "account/service/login", httpMethod = HttpMethod.POST
			,scopes = {CommonProperty.EMAIL_SCOPE, CommonProperty.PROFILE_SCOPE }
		    ,clientIds = {CommonProperty.DONGBU_SERVICE_WEB_CLIENT_ID,
			com.google.api.server.spi.Constant.API_EXPLORER_CLIENT_ID})
	public Users serviceLogin(HttpServletRequest request,
			@Named(FLD.domainName) String domainName,
			@Named(FLD.email) String email,
			@Nullable @Named(FLD.rememberMe) String rememberMe,
			@Named(FLD.serviceHost) String serviceHost,
			@Named(FLD.googleAccessToken) String googleAccessToken,
			@Named(FLD.expiresIn) long expiresIn) throws Exception {
		Domains fDomain = domainService.findByDomainName(domainName);
		if (fDomain == null) {
			//LOG.warning("Can't find domain:"+domainName);
			// TODO : 도메인을 조회하여 없으면 도메인을 생성한다.
			//createDomain
			return null;
		}
		
		Users fUser = userService.findByEmail(domainName, email);
		if (fUser == null) {
			//LOG.warning("Can't find user:"+email);
			// TODO : 사용자를 조회하여 없으면, 사용자를 등록한다.
			// insertUser
			return null;
		}
		
		String id = fUser.getId();
		String password = SsoServiceManager.createServicePassword();
		String host = request.getRemoteHost();

		Users user = userService.login(domainName, id, password, true /*Boolean.parseBoolean(rememberMe)*/, host);
		user.setForcePasswordChangeYN("N");
		
		return user;
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "logout", path = "account/logout", httpMethod = HttpMethod.POST)
	@RequiresUser
	public void logout(@Nullable @Named(FLD.userId) String userId, @Nullable @Named(FLD.gcmId) String gcmId) throws Exception {
		userService.logout(gcmId);
	}

	// ------------- Current service ----------------
	@ApiMethod(name = "getStatus", path = "account/status", httpMethod = HttpMethod.GET)
	public UserStatus getStatus(HttpServletRequest request) throws Exception {
		return userService.getStatus();
	}

	// ************* Unused service ******************
//	@ApiMethod(name = "withdraw", path = "account/withdraw", httpMethod = HttpMethod.POST)
//	@RequiresUser
//	@RequiresPermissions(Permission.DOMAIN_DELETE)
//	public void withdraw(Users user) throws Exception {
//		/*Users*/ user = getCurrentUser();
//		String userId = user.getUserId();
//
//		try {
//			// TODO
//			// 사용자가 가진 모든거 삭제 또는 삭제 Flag
//			//Domains domain = domainService.getOwnerDomain(userId);
//			Domains domain = domainService.findByDomainName(user.getDomainName());
//			if (domain != null) {
//				domainService.removeDomains(domain.getDomainId());
//			}
//
//			userService.permanentRemoveUsers(userId);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
}