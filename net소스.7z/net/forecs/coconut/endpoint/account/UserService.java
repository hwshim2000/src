package net.forecs.coconut.endpoint.account;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.PARAM;
import net.forecs.coconut.common.PrepareManager;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.exception.ErrorCode;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.Messages;
import net.forecs.coconut.common.util.Messages.WRAPPED_CHAR_TYPE;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.email.SendEmail;
import net.forecs.coconut.endpoint.admin.UsageService;
import net.forecs.coconut.endpoint.board.IAlarmService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.channel.ISubscriptionService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.common.IImageService;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.endpoint.domain.IStageService;
import net.forecs.coconut.endpoint.domain.StageService;
import net.forecs.coconut.endpoint.security.TokenService;
import net.forecs.coconut.endpoint.setting.INotificationSettingService;
import net.forecs.coconut.endpoint.setting.IUserSettingService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.freemarker.DocBuilder;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.user.UserStatus;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.BadRequestException;
import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.InternalServerErrorException;
import com.google.api.server.spi.response.UnauthorizedException;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;
import com.google.common.base.Preconditions;
import com.ibm.icu.text.MessageFormat;

import edu.emory.mathcs.backport.java.util.Arrays;


public class UserService extends CommonService implements IUserService {
	private static final Logger LOG = Logger.getLogger(UserService.class.getName());

	private final IUserDao<? extends IUser> dao;
	private final IDomainService domainService;
	private final IActivityService activityService;
	private final IMemberAuthService memberAuthService;
	private final ISubscriptionService subscriptionService;
	private final IAlarmService alarmService;
	private final INotificationSettingService notificationSettingService;
	private final IImageService imageService;
	private final IUserSettingService userSettingService;
	private final IBoardService boardService;
	private final IStageService stageService;
	private final IUserDeviceService userDeviceService;
	
	private final DocBuilder docBuilder;
	private final String userBaseUrl;
	
	@Inject
	public UserService(IUserDao<? extends IUser> dao, IDomainService domainService,
			IActivityService activityService, IMemberAuthService memberAuthService,
			ISubscriptionService subscriptionService,
			IAlarmService alarmService, INotificationSettingService notificationSettingService,
			IImageService imageService,
			IUserSettingService userSettingService,
			IBoardService boardService,
			IStageService stageService,
			IUserDeviceService userDeviceService,
			DocBuilder docBuilder,
			@Named(FLD.userBaseUrl) String userBaseUrl) {
		this.dao = dao;
		this.domainService = domainService;
		this.activityService = activityService;
		this.memberAuthService = memberAuthService;
		this.subscriptionService = subscriptionService;
		this.userBaseUrl = userBaseUrl;
		this.notificationSettingService = notificationSettingService;
		this.alarmService = alarmService;
		this.imageService = imageService;
		this.userSettingService = userSettingService;
		this.boardService = boardService;
		this.stageService = stageService;
		this.userDeviceService = userDeviceService;
		this.docBuilder = docBuilder;
	}

	//--> AccountServiceAPI : Domain filter not applied.
	@Override
	public String requestRegCode(String domainName, String id,
			String userName, String email, boolean resetPassword)
			throws ConflictException, BadRequestException, InternalServerErrorException {
		
		if (resetPassword) {
			if (StringUtils.isEmpty(id) || StringUtils.isEmpty(email)) {
				throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage(
		    			"User ID and Email should not be empty."));
			}
		} else {
			if (StringUtils.isEmpty(id) || StringUtils.isEmpty(userName) || StringUtils.isEmpty(email)) {
				throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage(
		    			"User ID, Name and Email should not be empty."));
			}
		}

		String prevNamespace = NamespaceManager.get();
		if (resetPassword) {
			NamespaceManager.set(domainName);		// Access domain's private namespace to find user
		}

		IUser user = dao.findUser(id, false);
		if (user != null && !resetPassword) {
			NamespaceManager.set(prevNamespace);	// Restore namespace
    		throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(
    				id + " is already registered."));
		}

		if (resetPassword && !email.equals(user.getEmail())) {
			NamespaceManager.set(prevNamespace);	// Restore namespace
    		throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage(
    				"Email is not a registered one with the User ID."));
    	}

		NamespaceManager.set(null);					// Access public namespace to register code

		String regCode = ShiroUtils.generateRegCode(id);
		LOG.info("Registration code is " + regCode);

		if (user != null && resetPassword) { userName = user.getUserName(); }
		
		if (dao.saveRegCode(regCode, domainName, id, userName, email) == null) {
			LOG.severe("Failed to save registration code.");
			NamespaceManager.set(prevNamespace);	// Restore namespace
			throw new InternalServerErrorException( // TODO Define ErrorCode
					"Failed to issue a registration code.");
		}

		//-->
		// hyeunwoo.shim 2015-07-13 : temp
		if (resetPassword) {
		//<--
			TaskOptions taskOptions = TaskOptions.Builder.withUrl(userBaseUrl + CommonProperty.SEND_REG_CODE_URL);
			//TaskOptions taskOptions = TaskOptions.Builder.withUrl(userBaseUrl + "/tasks/sendRegCode");
			if (!StringUtils.isEmpty(domainName)) {
				taskOptions = taskOptions.param(PARAM.DOMAINNAME, domainName);
			}
			taskOptions.param(PARAM.ID, id)
					.param(PARAM.DOMAINNAME, domainName)
					.param(PARAM.USERID, user.getObjectId())
					.param(PARAM.EMAIL, email)
					.param(PARAM.USERNAME, user.getUserName())
					.param(PARAM.REGCODE, regCode)
					.param(PARAM.FORGOT, Boolean.toString(resetPassword));
			Queue queue = QueueFactory.getDefaultQueue();
			queue.add(taskOptions);
		//-->
		// hyeunwoo.shim 2015-07-13 : temp
		}
		//<--

		NamespaceManager.set(prevNamespace);		// Restore namespace
		return regCode;
	}

	@Override
    public IUser confirmRegCode(String regCode, String password, String role)
			throws BadRequestException {
		if (dao.findUserIdFromRegCode(regCode) == null) {
			throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Invalid reg code : " + regCode));
		}

    	IUser user = dao.registerUserFromCode(regCode, password, role);
		return user;
	}

	@Override
	public Users login(String domainName, String id, String password,
			boolean rememberMe, String host) throws UnauthorizedException {
		try {
			if (ShiroUtils.getCurrentUser() != null) { ShiroUtils.logout(); }
		} catch (Exception ex) {}
		
		Domains domain = null;
		if (!StringUtils.isEmpty(domainName) && (domain = domainService.findByDomainName(domainName)) == null) {
			throw new UnauthorizedException(ErrorCode.LOGIN_FAIL.getMessage(
					"Invalid domain."));
		}

		if (StringUtils.isEmpty(id) || StringUtils.isEmpty(password)) {
			throw new UnauthorizedException(ErrorCode.LOGIN_FAIL.getMessage(
					"User ID or password is empty."));
		}
		
		if (domain != null && domain.isCaseInsensitive()) {
			Users lowerUser = findByLowerId(domainName, id);
			if (lowerUser != null) {
				id = lowerUser.getId();
			}
		}
		
		ShiroUtils.loginWithNewSession(domainName, id, password, rememberMe, host);
		Users user = getCurrentUser();
		
		updateLoginDate(user);
//		user.setOnline(true);

		try {
			if (StringUtils.isNotBlank(domainName)) {
				String prevNamespace = NamespaceManager.get();
				NamespaceManager.set(user.getDomainName());
				activityService.insertActivities(activityService.createUserActivity(user, null, ActivityType.LOGIN, user));
				NamespaceManager.set(prevNamespace);
			}
		} catch (Exception ex) {
			LOG.warning("Can't insert login activity : " + ex.getMessage());
		}

		return user;
	}

	@Deprecated
	public void logout(@Deprecated String userId, String gcmId) throws Exception {
		Users user = getCurrentUser();
		if (user == null) { 
			LOG.warning("[LOGOUT] User session was already terminated or  can't found.");
			return;
		}
		
		String prevNamespace = NamespaceManager.get();
		String domainName = user.getDomainName();
		NamespaceManager.set(domainName);		// Access domain's private namespace to update user
		
		try {
			user.setLogoutDate(new Date());
//			user.setOnline(false);

			updateUsers(user, false, false, false);

			try {
				if (StringUtils.isNotBlank(gcmId)) {
					userDeviceService.removeUserDevices(user.getUserId(), gcmId);
				}
				activityService.insertActivities(activityService.createUserActivity(user, null, ActivityType.LOGOUT, user));
			} catch (Exception ex) {
				LOG.warning("Can't insert logout activity : " + ex.getMessage());
			}
		} finally {
			NamespaceManager.set(null);				// Access public namespace to update session
			ShiroUtils.logout();
			TokenService.removeCurrentAccessToken();
			NamespaceManager.set(prevNamespace);	// Restore namespace
		}
	}
	
	@Override
	public void logout(String gcmId) throws Exception {
		Users user = getCurrentUser();
		if (user == null) { 
			LOG.warning("[LOGOUT] User session was already terminated or  can't found.");
			return;
		}
		
		String prevNamespace = NamespaceManager.get();
		String domainName = user.getDomainName();
		NamespaceManager.set(domainName);		// Access domain's private namespace to update user
		
		EntityManager mgr = getEntityManager();
		try {
			user.setLogoutDate(new Date());
//			user.setOnline(false);
			
			user = doMergeTransaction(mgr, user);
			
			try {
				if (StringUtils.isNotBlank(gcmId)) {
					userDeviceService.removeUserDevices(user.getUserId(), gcmId);
				}
				activityService.insertActivities(activityService.createUserActivity(user, null, ActivityType.LOGOUT, user));
			} catch (Exception ex) {
				LOG.warning("[LOGOUT] Can't insert logout activity : " + ex.getMessage());
			}
		} finally {
			finalizeTransaction(mgr, prevNamespace);
			NamespaceManager.set(null);				// Access public namespace to update session
			ShiroUtils.logout();
			TokenService.removeCurrentAccessToken();
		}
	}

	@Override
	public UserStatus getStatus() throws Exception {
		Users user = getCurrentUser();
		UserStatus status = new UserStatus();
		if (user != null) {
			PrepareManager pm = new PrepareManager(user.getDomainName());
			status = pm.getUserStatusFromPreparedMemcache(user.getUserId());
			
			if (status == null) {
				status = getStatus(user);
				LOG.warning("[PREPARE-USERSTATUS] Data initialization did not become. " + user.getId());
			} else {
				user.setUserProfiles(status.getUser().getUserProfiles());
				status.setUser(user);
				LOG.warning("[PREPARE-USERSTATUS] get data from memcache. " + user.getId());
			}
		}
		return status;
	}
	
	@Override
	public void prepareUserStatus(String domainName, String userId) throws Exception {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);			// Access domain's private namespace to get domain
		EntityManager mgr = getEntityManager();
		try {
			Users user = getUsers(mgr, userId, false);
			UserStatus status = getStatus(mgr, user);
			PrepareManager pm = new PrepareManager(domainName);
			pm.prepareUserStatus(status);
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}

	private UserStatus getStatus(Users user) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return getStatus(mgr, user);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private UserStatus getStatus(EntityManager mgr, Users user) throws Exception {
		String prevNamespace = NamespaceManager.get();
		String domainName = user.getDomainName();
		NamespaceManager.set(domainName);			// Access domain's private namespace to get domain
		try {
			UserStatus status = new UserStatus();
			Domains domain = doFindNoCache(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
			UserProfiles userProfile = doFindNoCache(mgr, UserProfiles.class, KeyUtil.createUserProfileKey(user));
			@SuppressWarnings("unchecked")
			List<Stages> stages = stageService.listStages(Arrays.asList(new String[] { StageService.COMMON_TASK_STAGE }));
			
			user.setUserProfiles(userProfile);
			status.setUser(user);
			status.setDomain(domain);
			
			status.setUserSettings(userSettingService.listUserSettings(mgr, user.getUserId()));
			status.setUsers(listUsers(mgr, null, true));
			status.setBoards(boardService.getUserBoards(mgr, user));
			
			//<!-- 2017-03-27 hyeunwoo.shim
			status.setStages(stages);
			//-->
			
			return status;
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public List<Users> listUsers(Boolean active, boolean includeProfile) throws Exception {
		EntityManager mgr = getEntityManager();
		try {
			return listUsers(mgr, active, includeProfile);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public List<Users> listUsers(EntityManager mgr, Boolean active, boolean includeProfile)	throws Exception {
		return queryUsers(mgr, null, null, active, includeProfile, N).getResultList();
	}

	@Override
	public QueryResult<Users> queryUsers(String cursorString, Integer limit, Boolean active, boolean includeProfile, String deleteYN) throws Exception {
		EntityManager mgr = getEntityManager();
		
		try {
			return queryUsers(mgr, cursorString, limit, active, includeProfile, deleteYN);
		} finally {
			finalizeTransaction(mgr);
		}

	}
	private QueryResult<Users> queryUsers(EntityManager mgr, String cursorString, Integer limit, Boolean active, boolean includeProfile, String deleteYN) throws Exception {
		DsQuery<Users> dsQuery = new DsQuery<>(Users.class)
				.eq(FLD.deleteYN, deleteYN)
				.eq(FLD.active, active)
				.cursor(cursorString)
				.limit(limit);
		
		List<Users> userList = dsQuery.execute(mgr);
		
		if (includeProfile) {
			Set<String> profileIds = new HashSet<String>();
			for (Users user : userList) {
				profileIds.add(KeyUtil.createUserProfileKeyString(user.getUserId()));
			}
			Map<String, UserProfiles> profileMap = batchMapByKey(mgr, UserProfiles.class, profileIds);
			for (Users user : userList) {
				user.setUserProfiles(profileMap.get(KeyUtil.createUserProfileKeyString(user.getUserId())));
			}
		}
		
		return new QueryResult<Users>(userList, dsQuery.getCursor());
	}

	@Override
	public Users getUsers(String userId, boolean includeProfile){
		EntityManager mgr = getEntityManager();
		try {
			return getUsers(mgr, userId, includeProfile);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@Override
	public Users getUsers(String domainName, String id){
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);
		try {
			return doFind(Users.class, KeyUtil.createUserKey(id));
		} finally {
			NamespaceManager.set(prevNamespace);
		}
	}
	
	@Override
	public Users getUsers(EntityManager mgr, String userId, boolean includeProfile){
		Users user = doFind(mgr, Users.class, userId);
		if (user != null && includeProfile) {
			UserProfiles userProfile = doFind(mgr, UserProfiles.class, KeyUtil.createUserProfileKey(user));
			user.setUserProfiles(userProfile);
		}
		
		return user;
	}
	
	@Override
	public String getUserEmail(String userId) {
		if (StringUtils.isBlank(userId)) { return null; }
		Users user = getUsers(userId, false);
		if (user == null) { return null; }
		return user.getEmail();
	}
	
	@Override
	public Users findUsers(Users user) throws Exception {
		if (user == null || StringUtils.isEmpty(user.getId())) {
			return null;
		}

		return getUsers(KeyUtil.createUserKeyString(user.getId()), true);
	}
	
	@Override
	public Users findByEmail(String domainName, String email) {
		if (StringUtils.isEmpty(domainName) || StringUtils.isEmpty(email)) {
			return null;
		}

		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);			// Access domain's private namespace to get domain
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Users> dsQuery = new DsQuery<>(Users.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.email, email);
			
			List<Users> results = dsQuery.execute(mgr);
			Users user = null;
			if (results.size() == 1) {
				user = results.get(0);
			} else {
				for (Users u : results) {
					//--> hyeunwoo.shim 2016-01-28 : Later, schedule to apply(ver 1.3)
					if (u.isAdmin()) { continue; }
					user = u;
				}
			}
			if (user != null) {
				UserProfiles userProfile = doFind(mgr, UserProfiles.class, KeyUtil.createUserProfileKey(user));
				user.setUserProfiles(userProfile);
			}
			return user;
		} catch (Exception e) {
			return null;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Users findByLowerId(String domainName, String id) {
		String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);			// Access domain's private namespace to get domain

		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<Users> dsQuery = new DsQuery<>(Users.class)
					.eq(FLD.deleteYN, N)
					.eq(FLD.lowerId, id.toLowerCase());
					
			Users user = dsQuery.single(mgr);
			if (user != null) {
				UserProfiles userProfile = doFind(mgr, UserProfiles.class, KeyUtil.createUserProfileKey(user));
				user.setUserProfiles(userProfile);
			}
			return user;
		} catch (Exception e) {
			return null;
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Users updatePassword(String currentPassword, String newPassword) throws Exception {
		if (StringUtils.isBlank(currentPassword) || StringUtils.isBlank(newPassword)) {
			throw new UnauthorizedException(ErrorCode.USER_INCORRECT_PASSWORD.getMessage("Required Password"));
		}
			
		EntityManager mgr = getEntityManager();
		
		try {		
			Users loginUser = getCurrentUser();
			
			Users user = doFindNoCache(mgr, Users.class, loginUser.getUserId());
			if (user != null) {
				UserProfiles userProfile = doFind(mgr, UserProfiles.class, KeyUtil.createUserProfileKey(user));
				user.setUserProfiles(userProfile);
			}
			valid(user);
			
			if (getPasswordHash(currentPassword, user.getSalt()).equals(user.getPassword())) {
				user.setPasswordHash(newPassword);
				user.setForcePasswordChangeYN(N);
			} else { throw new UnauthorizedException(ErrorCode.USER_INCORRECT_PASSWORD.getMessage("Incorrect Password")); }
		
			doMergeTransaction(mgr, user);
			
			return user;
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Users updateUserEmail(String userId, String newEmail, String passsword) throws Exception {
		Users user = null;
		
		if (StringUtils.isBlank(newEmail)) {
			return null;
		}

		EntityManager mgr = getEntityManager();
		try {
			user = doFindNoCache(mgr, Users.class, userId);
			
			valid(user);
			
			if (getPasswordHash(passsword, user.getSalt()).equals(user.getPassword())) {
				Users findUser = findByEmail(user.getDomainName(), newEmail); 
				if (findUser != null && !findUser.isAdmin()) {
					throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(Users.class, user.getEmail()));
				}				
				user.setEmail(newEmail);
			} else {
				throw new UnauthorizedException(ErrorCode.USER_INCORRECT_PASSWORD.getMessage("Incorrect Password"));
			}
			
			return updateUsers(mgr, user, false, true, false);
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	private String getPasswordHash(String password, byte[] salt) {
		Preconditions.checkNotNull(password);
		return ShiroUtils.hash(password, salt);
	}
	
	@Override
	public void sendLostIdEmail(String domainName, String email) throws Exception {
		Users user = findByEmail(domainName, email);
		
		String userId = user.getUserId();
		String userName = getDisplayUserName(user);
		String id = user.getId();
		
		Messages message = Messages.localeMessages(userId, WRAPPED_CHAR_TYPE.EMAIL);
		String subject = message.getMessage(Messages.SENDLOSTIDEMAIL_SUBJECT, userName);
		String templateName = MessageFormat.format(CommonProperty.SENDLOSTID_EMAIL_TEMPLATE, message.getLocale());
	
		if (StringUtils.isNotBlank(email) 
				&& StringUtils.isNotBlank(userName)
				&& StringUtils.isNotBlank(id)
				&& StringUtils.isNotBlank(domainName)) {
			HashMap<String, Object> messageMap = new HashMap<String, Object>();
			
			messageMap.put(PARAM.ID, id);
			messageMap.put(PARAM.USERNAME, userName);
			messageMap.put(PARAM.DOMAINNAME, domainName);
			messageMap.put(PARAM.WEBBASEURL, CommonProperty.WEB_BASE_URL);
			messageMap.put(PARAM.LOCALE, message.getLocale().toString());
					
			String htmlBody = docBuilder.createDocumentString(templateName, messageMap);
			
			SendEmail.sendEmailQueue(email, subject, htmlBody, CommonProperty.SENDLOSTID_EMAIL_QUEUE_NAME);
		}
	}
//	@Deprecated
//	public void sendLostIdEmailQueue(String domainName, String email) throws Exception {
//		try {
//			Users user = findByEmail(domainName, email);
//			
//			if (user != null) {
//				Queue queue =  QueueFactory.getQueue(CommonProperty.SENDLOSTID_EMAIL_QUEUE_NAME);
//				TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.SENDLOSTID_EMAIL_SEND_URL);
//			
//				taskOptions = taskOptions
//						.param(PARAM.ID, user.getId())
//						.param(PARAM.USERID, user.getUserId())
//						.param(PARAM.EMAIL, user.getEmail())
//						.param(PARAM.DOMAINNAME, domainName)
//						.param(PARAM.USERNAME, user.getUserName());
//				
//				taskOptions = taskOptions.method(Method.POST);
//		
//				queue.add(taskOptions);
//			} else {
//				throw new BadRequestException(ErrorCode.USER_NOT_FOUND.getMessage("ID can't find."));
//			}
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
	
	@Override
	public void sendRandomPassword(Users user, String randomPassword) {
		sendRandomPassword(user, user.getEmail(), randomPassword);
	}
	@Override
	public void sendRandomPassword(Users user, String email, String randomPassword) {
		TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.DOMAIN_USER_RANDOM_PASSWORD_URL);
		taskOptions.param(PARAM.ID, user.getId())
				.param(PARAM.USERID, user.getUserId())
				.param(PARAM.DOMAINNAME, user.getKey().getNamespace())
				.param(PARAM.EMAIL, email)
				.param(PARAM.USERNAME, user.getUserName())
				.param(PARAM.NICKNAME, user.getNickName() == null ? "" : user.getNickName())
				.param(PARAM.RANDOMPASSWORD, randomPassword);
		
		taskOptions = taskOptions.method(Method.POST);
				
		Queue queue = QueueFactory.getDefaultQueue();
		queue.add(taskOptions);
	}

	private Users insertUsers(EntityManager mgr, Users user, boolean validCheck) throws Exception {
		if (validCheck) { UsageService.validUsage(user); }
		
		if (user == null
				|| StringUtils.isEmpty(user.getId())
				|| StringUtils.isEmpty(user.getPassword())
				|| StringUtils.isEmpty(user.getEmail())) {
			throw new BadRequestException(ErrorCode.BAD_REQUEST.getMessage(Users.class));
		}

		try {
			Key key = KeyUtil.createUserKey(user.getId());
			user.setKey(key);
			user.setLowerId(user.getId().toLowerCase());
			//user.setCreator(user.getUserId());
			user.setOwner(user.getUserId());
			
			Domains domain = getDomain(user);
			
			if (contains(mgr, Users.class, key)) {
				throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(Users.class, user.getId()));
			}
			if (!user.isAdmin()) {
				Users findUser = findByEmail(user.getDomainName(), user.getEmail());
				if (findUser != null) {
					if (!findUser.isAdmin()) {
						throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(Users.class, user.getEmail()));
					}
					if (domain != null && ServiceType.GSUITE.equals(domain.getServiceType())) {
						throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(Users.class, user.getEmail()));
					}
				}
			}
			
			if (domain != null && domain.isCaseInsensitive()) {
				if (findByLowerId(domain.getDomainName(), user.getId().toLowerCase()) != null) {
					throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(Users.class, user.getId().toLowerCase()));
				}
			}
			
			if (user.getSalt() == null) {	// Not a password hash
				user.setPasswordHash(user.getPassword());
			}
			user.register();
			
			try {
				insertOrUpdateUserProfiles(mgr, user);
			} catch (Exception ex) {}

			doPersist(mgr, user);

			UsageService.increaseUsage(user);
			//createOrUpdateUserIndex(user);
			return user;
		} catch (Exception e) {
			throw e;
		}
	}
	
	@Override
	public Users updateUsers(Users user) throws Exception {
		return updateUsers(user, true, true, false);
	}
	
	private Users updateUsers(Users user, boolean updateProfile, boolean updateIndex, boolean updatePicture) throws Exception {
		EntityManager mgr = getEntityManager();

		try {
			return updateUsers(mgr, user, updateProfile, updateIndex, updatePicture);
		} catch (Exception e) {
			throw e;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	@SuppressWarnings("deprecation")
	private Users updateUsers(EntityManager mgr, Users user, boolean updateProfile, boolean updateIndex, boolean updatePicture) throws Exception {
		try {
			Users originUser = getUsers(user.getUserId(), true);
			UserProfiles userProfile = originUser.getUserProfiles();
			originUser.setRole(user.getRole());

			user.setPassword(originUser.getPassword());
			user.setSalt(originUser.getSalt());
			if (!updatePicture) {
				user.setPicture(originUser.getPicture());
			}
			if (!originUser.getEmail().equals(user.getEmail()) && !user.isAdmin()) {
				Users findUser = findByEmail(originUser.getDomainName(), user.getEmail());
				if (findUser != null && !findUser.isAdmin()) {
					throw new ConflictException(ErrorCode.USER_ALREADY_EXISTS.getMessage(Users.class, user.getEmail()));
				}
			}
			
			originUser = user;
			if (originUser.isActive()) {
				valid(originUser);
			}

			beginTransaction(mgr);
			if (updateProfile) {
				originUser = insertOrUpdateUserProfiles(mgr, originUser);
				userProfile = originUser.getUserProfiles();
			}
			
			originUser = doMerge(mgr, originUser);
			originUser.setUserProfiles(userProfile);
//			originUser.setOnline(syncService.isUserOnline(originUser));
			
			commitTransaction(mgr);
			
			ShiroUtils.clearCache(user.getDomainName(), user.getId());

			try {
				Users loginUser = getCurrentUser();
				if (loginUser != null) {
					Activities activity = activityService.createUserActivity(originUser, null,
							ActivityType.UPDATED, loginUser);
					activityService.insertActivities(activity);
				}
				if (updateProfile) { alarmService.updateAnniversaryAlarmQueue(user.getUserId()); }
			} catch (Exception e) {
				LOG.warning(e.getMessage());
				// Ignored. Activity is not a critical part of application.
			}
			
			return originUser;
		} catch (Exception e) {
			throw e;
		}
	}
	
	private void updateLoginDate(Users user){
		if (user == null) { return; }
		EntityManager mgr = getEntityManager();
		try {
			user.setLoginDate(new Date());
			doMergeTransaction(mgr, user);
		} catch (Exception ex) {
			LOG.warning("Update Login Date : " + ex.getMessage());
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public Users updateImage(String userId, Images image) throws Exception {
		try {
			Users user = getUsers(userId, true);
			valid(user);
			
			image = imageService.appendOrRemoveImages(userId, image);
			user.setPictureURL(image.getServingUrl());
			
			return updateUsers(user, false, false, true);
		} catch (Exception ex) {
			throw ex;
		} 
	}

	@Override
	public Users updateUserProfile(String userId, String userName, String nickName, Date birthday, SolarType solarType) throws Exception {
		try {
			Users user = getUsers(userId, true);
			valid(user);
			
			user.setUserName(userName);	
			user.setNickName(nickName);
			
			UserProfiles userProfile = user.getUserProfiles();
			if (userProfile == null) {userProfile = new UserProfiles(); }
			userProfile.setBirthday(birthday);
			userProfile.setSolarType(solarType);
			
			user.setUserProfiles(userProfile);
			
			return updateUsers(user);
		} catch (Exception ex) {
			throw ex;
		}
	}
	
	@Override
	public void removeUsers(String userId) {
		EntityManager mgr = getEntityManager();
		
		try {
			Users user = doFind(mgr, Users.class, userId);
			if (user == null) { return; }
			user.setDeleteYN(Y);
			user.setActive(false);
			
			doMergeTransaction(mgr, user);
			
			try {
//				memberAuthService.bulkRemoveMemberAuths(null, null, null, null, null, userId);
//				userDeviceService.bulkRemoveUserDevices(userId);
//				subscriptionService.bulkRemoveSubscriptions(null, null, userId);
//				notificationSettingService.permanentRemoveUserNotificationSettings(userId);
//				imageService.removeChildImages(userId);
//				//activityService.bulkRemoveActivities(null, null, null, null, null, userId);
			} catch (Exception ex) {}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	
	@Override
	public void permanentRemoveUsers(String userId) {
		EntityManager mgr = getEntityManager();
		
		try {
			permanentRemoveUsers(mgr, userId);
			
			try {
				memberAuthService.bulkRemoveMemberAuths(null, null, null, null, null, userId);
				userDeviceService.bulkRemoveUserDevices(userId);
				subscriptionService.bulkRemoveSubscriptions(null, null, userId);
				notificationSettingService.permanentRemoveUserNotificationSettings(userId);
				imageService.removeChildImages(userId);
				//activityService.bulkRemoveActivities(null, null, null, null, null, userId);
			} catch (Exception ex) {}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	private void permanentRemoveUsers(EntityManager mgr, String userId) {
		try {
			Users user = doFind(mgr, Users.class, userId);
			
			if (user != null) {
				beginTransaction(mgr);
				doRemove(mgr, UserProfiles.class, KeyUtil.createUserProfileKey(user));
//				doRemove(mgr, NotificationSettings.class, KeyUtil.createNotificationSettingKey(userId));
				doRemove(mgr, user);
				commitTransaction(mgr);
				try {
					UsageService.decreaseUsage(user);
				} catch (Exception ex) {}
			}
		} catch (Exception ex) {
			throw ex;
		}
	}

	private Users insertOrUpdateUserProfiles(EntityManager mgr, Users user) throws Exception {
		try {
			Key userProfileKey = KeyUtil.createUserProfileKey(user);
			UserProfiles userProfile = doFind(mgr, UserProfiles.class, userProfileKey);
			
			if (userProfile != null) {
				if (user.getUserProfiles() != null) {
					userProfile = user.getUserProfiles();
					userProfile.setKey(userProfileKey);
					doMerge(mgr, userProfile);
				}
			} else {
				userProfile = user.getUserProfiles();
				if (userProfile == null) {
					userProfile = new UserProfiles();
				}
				userProfile.setKey(userProfileKey);
				doPersist(mgr, userProfile);
			}
			
			user.setUserProfiles(userProfile);
			return user;	
		} catch (Exception e) {
			throw e;
		}
	}
	@Override
	public Users assignUsers(EntityManager mgr, Users user, boolean validCheck) throws Exception {
		user = insertUsers(mgr, user, validCheck);
		try {
			activityService.insertActivities(activityService.createUserActivity(user, null, ActivityType.ASSIGNED, getCurrentUser()));
		} catch (Exception ex) {
		}
		
		return user;
	}
	
	@Override
	public Users unassignUsers(EntityManager mgr, Users user) throws Exception {
		user = updateUsers(mgr, user, true, true, false);
		try {
			activityService.insertActivities(activityService.createUserActivity(user, null, ActivityType.UNASSIGNED, getCurrentUser()));
		} catch (Exception ex) {
		}
		UsageService.decreaseUsage(user);
		return user;
	}
	@Override
	public Users reassignUsers(EntityManager mgr, Users user) throws Exception {
		UsageService.validUsage(user);
		user = updateUsers(mgr, user, true, true, false);
		try {
			activityService.insertActivities(activityService.createUserActivity(user, null, ActivityType.ASSIGNED, getCurrentUser()));
		} catch (Exception ex) {
		}
		UsageService.increaseUsage(user);
		return user;
	}

	@Override
	public Users setRole(String userId, String role) throws Exception {
		Users user = getUsers(userId, true);
		if (user == null) {
			throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Invalid user key : " + userId));
		}

		return setRole(user, role);
	}

	private Users setRole(Users user, String role) throws Exception {
		user.setRole(role);
		user = updateUsers(user);
		//ShiroUtils.clearCache(user.getDomainName(), user.getId());
		return user;
	}

	private Domains getDomain(Users user) {
		String prevNamespace = NamespaceManager.get();
		String domainName = user.getDomainName();
		NamespaceManager.set(domainName);			// Access domain's private namespace to get domain
		EntityManager mgr = getEntityManager();
		try {
			return doFind(mgr, Domains.class, KeyUtil.createDomainKeyString(domainName));
		} finally {
			finalizeTransaction(mgr, prevNamespace);
		}
	}
	
	@Override
	public Map<String, Users> batchMapUsers(EntityManager mgr, Collection<String> userIds, boolean includeProfile) throws Exception {
		try {
			Map<String, Users> usersMap = batchMapByKey(mgr, Users.class, userIds);
			
			if (includeProfile) {
				Set<String> profileIds = new HashSet<String>();
				for (String userId : userIds) {
					profileIds.add(KeyUtil.createUserProfileKeyString(userId));
				}
				Map<String, UserProfiles> profilesMap = batchMapByKey(mgr, UserProfiles.class, profileIds);
				
				for(Map.Entry<String, Users> entry : usersMap.entrySet()) {
					entry.getValue().setUserProfiles(profilesMap.get(KeyUtil.createUserProfileKeyString(entry.getKey())));
				}
			}
			
			return usersMap;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public Users getUsers(String userId){
//		EntityManager mgr = getEntityManager();
//		try {
//			return getUsers(mgr, userId, true);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Users getUsers(EntityManager mgr, String userId){
//		return getUsers(mgr, userId, true);
//	}
//	@Override
//	public Users getSimpleUsers(String userId){
//		EntityManager mgr = getEntityManager();
//		try {
//			return getUsers(mgr, userId, false);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Users getSimpleUsers(EntityManager mgr, String userId){
//		return getUsers(mgr, userId, false);
//	}
//	@Override
//	public List<Users> listUsers(Boolean active) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return listUsers(mgr, active, true);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Users> listSimpleUsers(Boolean active) throws Exception {
//		EntityManager mgr = getEntityManager();
//		try {
//			return listUsers(mgr, active, false);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public List<Users> listSimpleUsers(EntityManager mgr, Boolean active) throws Exception {
//		return listUsers(mgr, active, false);
//	}
//	@Override
//	public boolean checkDuplicationNickName(String nickName) {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Query query = new DsQuery(Users.class)
//					.eq(FLD.nickName, nickName)
//					.eq(FLD.deleteYN, null)
//					.setKeysOnly();
//			return queryCount(query) == 0 ? true : false;
//		} catch (Exception e) {
//			return false;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public Users updateUserName(String userId, String userName) throws Exception {
//		try {
//			Users user = getUsers(userId);
//			valid(user);
//			user.setUserName(userName);
//			
//			return updateUsers(user);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	@Override
//	public Users updateUserNickName(String userId, String nickName) throws Exception {
//		try {
//			Users user = getUsers(userId);
//			valid(user);
//			user.setNickName(nickName);
//			
//			return updateUsers(user);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	}
//	@Override
//	public Users updateUserBirthday(String userId, Date birthday, SolarType solarType) throws Exception {
//		try {
//			Users user = getUsers(userId);
//			valid(user);
//			user.getUserProfiles().setBirthday(birthday);
//			user.getUserProfiles().setSolarType(solarType);
//			
//			return updateUsers(user);
//		} catch (Exception ex) {
//			throw ex;
//		}
//	
//	}
//	@Override
//	public Users addPermissions(String userId, Set<String> permissions) throws Exception {
//		Users user = getUsers(userId);
//		if (user == null) {
//			throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Invalid user key : " + userId));
//		}
//
//		return addPermissions(user, permissions);
//	}
//	// NOTICE : Has side effect that other properties than permissions might be updated
//	//@Override
//	private Users addPermissions(Users user, Set<String> permissions) throws Exception {
//		user.addPermissions(permissions);
//		user = updateUsers(user);
//		//ShiroUtils.clearCache(user.getDomainName(), user.getId());
//		return user;
//	}
//	@Override
//	public Users removePermissions(String userId, Set<String> permissions) throws Exception {
//		Users user = getUsers(userId);
//		if (user == null) {
//			throw new BadRequestException(ErrorCode.ILLEGAL_PARAMETER.getMessage("Invalid user key : " + userId));
//		}
//
//		return removePermissions(user, permissions);
//	}
//	// NOTICE : Has side effect that other properties than permissions might be updated
//	//@Override
//	private Users removePermissions(Users user, Set<String> permissions) throws Exception {
//		user.removePermissions(permissions);
//		user = updateUsers(user);
//		//ShiroUtils.clearCache(user.getDomainName(), user.getId());
//		return user;
//	}
//	@Override
//	public Images getImage(String userId) throws Exception {
//		return imageService.getUserImage(userId);
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}