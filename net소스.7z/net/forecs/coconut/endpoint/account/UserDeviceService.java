package net.forecs.coconut.endpoint.account;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.query.DsQuery;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.user.UserDevices;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.response.ConflictException;
import com.google.api.server.spi.response.NotFoundException;
import com.google.appengine.api.datastore.Key;


public class UserDeviceService extends CommonService implements IUserDeviceService {
	
	@Override
	public QueryResult<UserDevices> listUserDevices(String cursorString, Integer limit) throws IOException {
		EntityManager mgr = getEntityManager();
		
		try {
			DsQuery<UserDevices> dsQuery = new DsQuery<>(UserDevices.class)
					.cursor(cursorString)
					.limit(limit);
			List<UserDevices> results = dsQuery.execute(mgr);
			return new QueryResult<UserDevices>(results, dsQuery.getCursor());
		} catch (Exception ex) {
			throw new IOException(ex);
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public UserDevices insertUserDevices(UserDevices device) throws ConflictException {
		EntityManager mgr = getEntityManager();
		
		try {
			Key key = KeyUtil.createUserDeviceKey(device);
			if (contains(mgr,UserDevices.class, key)) {
				//throw new ConflictException("Object already exists.");
			}
			device.setKey(key);
			
			doPersistTransaction(mgr, device);
			
			return device;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public UserDevices insertOrUpdateUserDevices(UserDevices device) {
		EntityManager mgr = getEntityManager();
		
		try {
			Key key = KeyUtil.createUserDeviceKey(device);
			device.setKey(key);
			if (contains(mgr,UserDevices.class, key)) {
				device = doMergeTransaction(mgr, device);
			} else {
				doPersistTransaction(mgr, device);	
			}
			
			return device;
		} finally {
			finalizeTransaction(mgr);
		}
	}

	@Override
	public void removeUserDevices(String userDeviceId) throws NotFoundException {
		EntityManager mgr = getEntityManager();
		
		try {
			UserDevices device = doFind(mgr, UserDevices.class, userDeviceId);
			if (device == null) {
				throw new NotFoundException("Object does not exist.");
			}
			
			doRemoveTransaction(mgr, device);
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void removeUserDevices(String userId, String gcmId) {
		EntityManager mgr = getEntityManager();
		
		try {
			String userDeviceId = KeyUtil.createUserDeviceKeyString(gcmId);
			UserDevices device = doFind(mgr, UserDevices.class, userDeviceId);
			if (device != null && StringUtils.equals(userId, device.getOwner())) {
				doRemoveTransaction(mgr, device);
			}
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
	@Override
	public void bulkRemoveUserDevices(String userId) throws Exception {
		EntityManager mgr = getEntityManager();
			
		try {
			DsQuery<UserDevices> dsQuery = new DsQuery<>(UserDevices.class)
					.eq(FLD.owner, userId);
			
			List<UserDevices> results = dsQuery.execute(mgr);
			for (UserDevices device : results) {
				doRemoveTransaction(mgr, device);
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			finalizeTransaction(mgr);
		}
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@Override
//	public UserDevices getUserDevices(String userDeviceId) {
//		EntityManager mgr = getEntityManager();
//		try {
//			return doFind(mgr, UserDevices.class, userDeviceId);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	@Override
//	public UserDevices updateUserDevices(UserDevices device) throws NotFoundException {
//		EntityManager mgr = getEntityManager();
//		try {
//			Key key = device.getKey();
//			if (!contains(mgr, UserDevices.class, key)) {
//				throw new NotFoundException("Object does not exist.");
//			}
//			
//			doMergeTransaction(mgr, device);
//
//			return device;
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
	
//	public QueryResult<UserDevices> listUserDevices(String cursorString, Integer limit) {
//		EntityManager mgr = getEntityManager();
//		
//		try {
//			Cursor cursor = null;
//			
//			TypedQuery<UserDevices> query = mgr.createQuery("select from UserDevices as UserDevices", UserDevices.class);
//			if (!StringUtils.isEmpty(cursorString)) {
//				cursor = Cursor.fromWebSafeString(cursorString);
//				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
//			}
//
//			if (limit != null) {
//				query.setFirstResult(0);
//				query.setMaxResults(limit);
//			}
//
//			List<UserDevices> execute = query.getResultList();
//			cursor = JPACursorHelper.getCursor(execute);
//			
//			return new QueryResult<UserDevices>(execute, cursor);
//		} finally {
//			finalizeTransaction(mgr);
//		}
//	}
}