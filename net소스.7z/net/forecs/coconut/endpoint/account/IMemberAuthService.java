package net.forecs.coconut.endpoint.account;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.AuthKind;
import net.forecs.coconut.common.code.AuthStatus;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.user.Users;


public interface IMemberAuthService extends ICommonService {
	public abstract MemberAuths getMemberAuths(String kindId, String userId);
	public abstract MemberAuths getMemberAuths(EntityManager mgr, String kindId, String userId);
	public abstract List<MemberAuths> listMemberAuths(
			EntityManager mgr,
			Collection<String> boardIdList,
			Auth auth,
			AuthKind authKind,
			String kindId,
			AuthStatus authStatus,
			String userId,
			boolean includeUser
			/*, AuthQueryOption authQueryOption*/) throws Exception;

	public abstract MemberAuths updateMemberAuths(EntityManager mgr, MemberAuths memberAuth) throws Exception;
	public abstract MemberAuths reassignMemberAuths(EntityManager mgr, MemberAuths memberAuth) throws Exception;
	public abstract MemberAuths insertMemberAuths(EntityManager mgr, MemberAuths memberAuth) throws Exception;
	
	public abstract void unassignAllMemberAuth(List<String> userIdList, AuthKind authKind) throws Exception;
	public abstract void reassignAllMemberAuth(List<String> userIdList, AuthKind authKind) throws Exception;
	public abstract void unassignAllMemberAuth(String userId, AuthKind authKind) throws Exception;
	public abstract void reassignAllMemberAuth(String userId, AuthKind authKind) throws Exception;
	
	public abstract Map<String, List<Users>> batchMapTaskMembers(EntityManager mgr, Collection<String> taskIdList) throws Exception;
	public abstract Map<String, List<Users>> batchMapTaskMembers(EntityManager mgr, Collection<String> boardIdList, Collection<String> taskIdList) throws Exception;
	public abstract Map<String, List<Boards>> batchMapUserBoards(EntityManager mgr, Collection<String> userIdList) throws Exception;
	public abstract List<String> batchMapUserTaskIds(EntityManager mgr, Collection<String> boardIds, Collection<String> userIds) throws Exception;
	public abstract List<MemberAuths> batchListMemberAuthsOfTask(EntityManager mgr, String taskId, Collection<String> userIds) throws Exception;
	public abstract Map<String, List<String>> batchMapTaskMemberIds(EntityManager mgr, Collection<String> boardIds, Collection<String> taskIds) throws Exception;

	public abstract void permanentRemoveMemberAuths(EntityManager mgr, String memberAuthId);
	public abstract int bulkRemoveMemberAuths (
			String boardId,
			Auth auth,
			AuthKind authKind,
			String kindId,
			AuthStatus authStatus,
			String userId) throws Exception;
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	public abstract QueryResult<MemberAuths> queryMemberAuths(
//			String cursorString,
//			Integer limit,
//			Collection<String> boardIdList,
//			Auth auth,
//			AuthKind authKind,
//			String kindId,
//			AuthStatus authStatus,
//			String userId,
//			boolean simpleMode
//			/*, AuthQueryOption authQueryOption */) throws Exception;
//	public abstract long countMemberAuths(AuthKind authKind, String userId) throws Exception;
//	public abstract Map<String, List<Users>> batchMapTaskAllMembers(EntityManager mgr, String taskId) throws Exception;
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}