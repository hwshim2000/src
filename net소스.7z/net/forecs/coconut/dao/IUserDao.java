package net.forecs.coconut.dao;

import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.entity.user.RegCode;


public interface IUserDao<T extends IUser> extends IDao<T> {
    public abstract T savePassword(String id, String password);

    public abstract void deleteUser(final String userId);

    public abstract RegCode saveRegCode(String code, String domainName, String id, String userName, String email);
    public abstract String findUserIdFromRegCode(String code);

    public abstract T findUser(String id);
    public abstract T findUser(String id, boolean validate);

    public abstract T registerUserFromCode(final String code, final String password,
    		//-->
    		//final Set<String> roles, final Set<String> permissions);
			//--
			// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
    		final String role);
			//<--

    //public abstract T registerUser(T user);
    public abstract T registerUser(final String id, final String password,
    		final String userName, final String email,
    	    //-->
    		//final Set<String> roles, final Set<String> permissions);
			//--
			// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
    		final String role);
			//<--

	public abstract T suspendUser(String userId, boolean suspend);

	public abstract long getCount();
}