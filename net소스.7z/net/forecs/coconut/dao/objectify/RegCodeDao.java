package net.forecs.coconut.dao.objectify;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.entity.user.RegCode;


public class RegCodeDao extends BaseDao<RegCode> {
    static final Logger LOG = Logger.getLogger(RegCodeDao.class.getName());

    public RegCodeDao() {
        super(RegCode.class);
    }
}