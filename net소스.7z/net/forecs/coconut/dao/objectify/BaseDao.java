package net.forecs.coconut.dao.objectify;

import static com.googlecode.objectify.ObjectifyService.ofy;

import java.util.List;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.dao.IDao;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.QueryResultIterator;
import com.google.common.collect.Lists;
import com.googlecode.objectify.cmd.Query;


public class BaseDao<T> implements IDao<T> {
    static final Logger LOG = Logger.getLogger(BaseDao.class.getName());

    private final Class<T> clazz;

    public BaseDao(Class<T> clazz) {
        this.clazz = clazz;
    }

    public final String getObjectId(String id) {
		Key key = KeyFactory.createKey(clazz.getSimpleName(), id);
		return KeyFactory.keyToString(key);
    }

	public final T get(String objectId) {
		if (StringUtils.isEmpty(objectId)) {
			return null;
		}

		com.googlecode.objectify.Key<T> key = com.googlecode.objectify.Key.create(objectId);
		T object = (T)ofy().load().key(key).now();
		return object;
	}

	public final Key put(T object) {
		return ofy().save().entity(object).now().getRaw();
	}

	public final void delete(String objectId) {
		com.googlecode.objectify.Key<T> key = com.googlecode.objectify.Key.create(objectId);
		ofy().delete().key(key);
	}

	public final QueryResult<T> query(Cursor cursor, int limit, String order) {
		Query<T> query = ofy().load().type(clazz).limit(limit).order(order);
		if (cursor != null) {
			query.startAt(cursor);
		}

		List<T> list = Lists.newArrayList();
		QueryResultIterator<T> it = query.iterator();
		while (it.hasNext()) {
			list.add(it.next());
		}

		return new QueryResult<T>(list, it.getCursor());
	}
}