package net.forecs.coconut.dao.objectify;

import net.forecs.coconut.common.Logger;

import net.forecs.coconut.entity.user.UserCounter;


public class UserCounterDao extends BaseDao<UserCounter> {
    static final Logger LOG = Logger.getLogger(UserCounterDao.class.getName());

    public UserCounterDao() {
        super(UserCounter.class);
    }
}
