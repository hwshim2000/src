package net.forecs.coconut.dao.jpa;

import java.util.concurrent.TimeUnit;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.dao.objectify.RegCodeDao;
import net.forecs.coconut.dao.objectify.UserCounterDao;
import net.forecs.coconut.entity.user.RegCode;
import net.forecs.coconut.entity.user.UserCounter;
import net.forecs.coconut.entity.user.Users;

import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Key;
import com.googlecode.objectify.ObjectifyService;


public class UsersDao extends BaseDao<Users> implements IUserDao<Users> {
    static final Logger LOG = Logger.getLogger(UsersDao.class.getName());

	private static final long REGISTRATION_VALID_DAYS = 1;

	static {
		ObjectifyService.register(UserCounter.class);
		ObjectifyService.register(RegCode.class);
	}

    public UsersDao() {
    	super(Users.class);
    }

    /**
     * Save user with authorization information
     * @param user  User
     * @param changeCount should the user count be incremented
     * @return the user, after changes
     */
	private Users saveUser(final Users user, final boolean changeCount) {
		beginTransaction();
		try {
			put(user);
			if (changeCount) {
				changeCount(1L);
			}
			commit();

			return user;
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			endTransaction();
		}
	}

//	public Users savePassword(IUser user, String password) {
//		if (user instanceof Users) {
//			return savePassword((Users)user, password);
//		} else {
//			return null;
//		}
//	}

	private Users savePassword(Users user, String password) {
		if (user != null) {
			user.setPasswordHash(password);
			user = saveUser(user, false);
		}
		return user;
	}

	public Users savePassword(String id, String password) {
		Users user = findUser(id, false);
		return savePassword(user, password);
	}

//	public void deleteUser(IUser user) {
//		if (user instanceof Users) {
//			deleteUser((Users)user);
//		}
//	}

//	public void deleteUser(Users user) {
//		if (user != null) {
//			deleteUser(user.getId());
//		}
//	}

	public void deleteUser(final String userId) {
		beginTransaction();
		try {
			delete(userId);
			changeCount(-1L);

			commit();
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			endTransaction();
		}
	}

    public RegCode saveRegCode(String code, String domainName, String id, String userName, String email) {
		final String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);				// Access public namespace to save RegCode

		RegCodeDao dao = new RegCodeDao();
		RegCode regCode = new RegCode(code, domainName, id, userName, email,
				REGISTRATION_VALID_DAYS, TimeUnit.DAYS);

		Key key = dao.put(regCode);

		NamespaceManager.set(prevNamespace);	// Restore namespace
		if (key != null) {
			return regCode;
		} else {
			return null;
		}
	}

    private RegCode findRegCode(String code) {
		final String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(null);				// Access public namespace to find RegCode

		RegCodeDao dao = new RegCodeDao();
		String regCodeId = dao.getObjectId(code);
		RegCode regCode = dao.get(regCodeId);

		NamespaceManager.set(prevNamespace);	// Restore namespace
		return (regCode == null) ?  null : (regCode.isValid() ? regCode : null);
	}

	public String findUserIdFromRegCode(String code) {
		RegCode regCode = findRegCode(code);
		return (regCode == null) ?  null : regCode.getId();
	}

	public Users findUser(String id) {
		return findUser(id, true);
	}

	public Users findUser(String id, boolean validate) {
		String userId = getObjectId(id);
		Users user = get(userId);
		if (validate && (user != null) && !user.isValid()) {
			user = null;
		}
		return user;
	}

	private Users register(final String id, final String password,
			final String userName, final String email,
			//-->
			//final Set<String> roles, final Set<String> permissions,
			//--
			// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
			final String role,
			//<--
			final RegCode regCode) {
		beginTransaction();
		try {
			Users user = findUser(id, false);
			boolean changeCount;
			if (user == null) {
				changeCount = true;
				//-->
				//user = new Users(id, password, userName, email, roles, permissions);
				//--
				// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
				user = new Users(id, password, userName, email, role);
				//<--
				user.setUserId(getObjectId(id));
				user.register();

				if (regCode != null) {
					final String prevNamespace = NamespaceManager.get();
					NamespaceManager.set(null);				// Access public namespace to delete RegCode

					RegCodeDao dao = new RegCodeDao();
					dao.delete(regCode.getObjectId());

					NamespaceManager.set(prevNamespace);	// Restore namespace
				}
			} else {
				changeCount = false;
				user.setPasswordHash(password);
			}

			user = saveUser(user, changeCount);
			commit();
			return user;
		} catch (Exception e) {
			rollback();
			throw e;
		} finally {
			endTransaction();
		}
	}

	public Users registerUserFromCode(final String code, final String password,
			//-->
			//final Set<String> roles, final Set<String> permissions) {
			//--
			// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
			final String role) {
			//<--
		final RegCode regCode = findRegCode(code);
		if (regCode == null) {
			return null;
		}

		final String domainName = regCode.getDomainName();
		final String id = regCode.getId();
		final String userName = regCode.getUserName();
		final String email = regCode.getEmail();

		final String prevNamespace = NamespaceManager.get();
		NamespaceManager.set(domainName);			// Access domain's private namespace to find user

		Users user = null;
		try {
			//-->
			//user = register(id, password, userName, email, roles, permissions, regCode);
			//--
			// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
			user = register(id, password, userName, email, role, regCode);
			//<--
		} finally {
			NamespaceManager.set(prevNamespace);	// Restore namespace
		}

		return user;
	}

//	public Users registerUser(Users user) {
//		if (user != null) {
//			user.register();
//			user = saveUser(user, true);
//		}
//		return user;
//	}

	public Users registerUser(final String id, final String password,
			final String userName, final String email,
		//-->
		//	final Set<String> roles, final Set<String> permissions) {
		//return register(id, password, userName, email, roles, permissions, null);
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
			final String role) {
		return register(id, password, userName, email, role, null);
		//<--
	}

	private Users suspendUser(Users user, boolean suspend) {
		if (user != null) {
			user.setActive(!suspend);
			user = saveUser(user, false);
		}
		return user;
	}

	public Users suspendUser(String userId, boolean suspend) {
		Users user = get(userId);
		if (user != null) {
			user = suspendUser(user, suspend);
		}
		return user;
	}

	public long getCount() {
		UserCounterDao dao = new UserCounterDao();
		String counterId = dao.getObjectId(UserCounter.COUNTER_ID);
		UserCounter counter = dao.get(counterId);
		return (counter == null) ? 0 : counter.getCount();
	}

	private void changeCount(final long delta) {
		UserCounterDao dao = new UserCounterDao();
		String counterId = dao.getObjectId(UserCounter.COUNTER_ID);
		UserCounter counter = dao.get(counterId);
		if (counter == null) {
			counter = new UserCounter(UserCounter.COUNTER_ID);
		}
		counter.delta(delta);
		dao.put(counter);
	}
}