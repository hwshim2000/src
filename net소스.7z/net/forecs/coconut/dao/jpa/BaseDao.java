package net.forecs.coconut.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.query.QueryBuilder;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.dao.IDao;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.common.Base;

import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.datanucleus.query.JPACursorHelper;


public class BaseDao<T extends Base> extends CommonService implements IDao<T> {
    static final Logger LOG = Logger.getLogger(BaseDao.class.getName());

    private final Class<T> clazz;

    private EntityManager em;
    private EntityTransaction tr;
    private int trRefCount;

	public BaseDao(Class<T> clazz) {
		this.clazz = clazz;
		em = null;
	}

	public final void beginTransaction() {
		if (em == null) {
			em = CommonService.getEntityManager();
			tr = em.getTransaction();
			trRefCount = 0;
		}

		++trRefCount;
		if (!tr.isActive()) {
			tr.begin();
		}
	}
	public final void commit() {
		if (1 == trRefCount) {
			tr.commit();
		}
	}
	public final void rollback() {
		if (1 == trRefCount) {
			tr.rollback();
		}
	}
	public final void endTransaction() {
		if (em != null) {
			--trRefCount;
			if (0 == trRefCount) {
				tr = null;
				em.close();
				em = null;
			}
		}
	}

	public final String getObjectId(String id) {
		Key key = KeyFactory.createKey(clazz.getSimpleName(), id);
		return KeyFactory.keyToString(key);
    }

    protected final Key objectIdToKey(String objectId) {
    	return KeyFactory.stringToKey(objectId);
    }

    public final T get(String objectId) {
    	EntityManager em = CommonService.getEntityManager();
		//Key key = objectIdToKey(objectId);
		try {
			return doFind(em, clazz, objectId);
//			return em.find(clazz, key);
		} finally {
			em.close();
		}
	}

    public final Key put(T object) {
    	if (object == null) {
    		return null;
    	}

    	beginTransaction();
    	try {
    		Key key = objectIdToKey(object.getObjectId());
	    	//if (em.contains(object)) {
    		
    		if (doFind(em, clazz, key) != null) {
    			doMerge(em, object);
    		} else {
    			doPersist(em, object);
    		}
//    		if (em.find(clazz, key) != null) {
//	    		em.merge(object);
//	    	} else {
//	    		em.persist(object);
//			}
//    		//-->
//    		// hyeunwoo.shim 2016-02-20 : applied memcache
//    		MemcacheManager.put(object.getObjectId(), object);
//    		//<--
    		
	    	commit();

	    	return object.getKey();
    	} catch (Exception e) {
    		rollback();
    		throw e;
    	} finally {
    		endTransaction();
		}
    }

    public final void delete(String objectId) {
    	beginTransaction();
    	try {
    		Key key = objectIdToKey(objectId);
    		T object = doFind(em, clazz, key);
    		doRemove(em, object);
//    		T object = em.find(clazz, key);
//			em.remove(object);
	    	commit();
    	} catch (Exception e) {
    		rollback();
    		throw e;
    	} finally {
    		endTransaction();
		}
    }

    public final QueryResult<T> query(Cursor cursor, int limit, String order) {
    	EntityManager em = CommonService.getEntityManager();

		try {
			TypedQuery<T> query = new QueryBuilder<>(clazz).build(em);

			if (cursor != null) {
				query.setHint(JPACursorHelper.CURSOR_HINT, cursor);
			}

			query.setFirstResult(0);
			query.setMaxResults(limit);

			List<T> list = query.getResultList();
			cursor = JPACursorHelper.getCursor(list);
			return new QueryResult<T>(list, cursor);
		} catch (Exception e) {
			return null;
		} finally {
			em.close();
		}
    }
}