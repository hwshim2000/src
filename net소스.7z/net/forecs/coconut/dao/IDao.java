package net.forecs.coconut.dao;

import net.forecs.coconut.common.query.QueryResult;

import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.Key;


public interface IDao<T> {
	public T get(String objectId);
	public Key put(T object);
	public void delete(String objectId);
	public QueryResult<T> query(Cursor cursor, int limit, String order);
}