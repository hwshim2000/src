package net.forecs.coconut.entity.email;

@Deprecated
//@Entity
public class UserSummaryMails {

//	private static final long serialVersionUID = -6928442285619603148L;
//	@Getter @Setter
//	private String userId;
//	@Getter @Setter
//	private String domainId;
//	@Getter @Setter
//	private String email;
//	
//	@Getter @Setter
//	private String hostAddress;
//	@Getter @Setter
//	private Integer hostPort;
//	@Getter @Setter
//	private String hostType; // POP3/IMAP/...
//	
//	/** encryption and decryption require.*/
//	@Getter @Setter
//	private String password;
//	
//	@Getter @Setter
//	private String summaryYN;
//	@Getter @Setter
//	private String summaryLevel;
//	@Getter @Setter
//	private Integer extractKeywordCount;
//
//	private List<String> concernKeywords;
//	public void setConcernKeywords(List<String> concernKeywords) {
//		if (concernKeywords == null) concernKeywords = new ArrayList<String>();
//		this.concernKeywords = concernKeywords;
//	}
//	public List<String> getConcernKeywords() {
//		if (concernKeywords == null) concernKeywords = new ArrayList<String>();
//		return concernKeywords;
//	}
//
//	private List<String> exceptKeywords;
//	public void setExceptKeywords(List<String> exceptKeywords) {
//		if (exceptKeywords == null) exceptKeywords = new ArrayList<String>();
//		this.exceptKeywords = exceptKeywords;
//	}
//	public List<String> getExceptKeywords() {
//		if (exceptKeywords == null) exceptKeywords = new ArrayList<String>();
//		return exceptKeywords;
//	}
}
