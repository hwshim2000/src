package net.forecs.coconut.entity.email;

import java.util.Date;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
//import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.google.appengine.api.datastore.Text;			// for suppoerting DB varchar type(unlimited String type) 

@Schema(name="AdminEMailNotice"
	, description="운용자메일공지"
    , pkConstraint="CONSTRAINT pk_adminMailId PRIMARY KEY (adminEMailNoticeId)"
    )
@Entity
public class AdminEMailNotice extends Common {
//	private static final Logger LOG = Logger.getLogger(AdminEMailNotice.class.getName());
	private static final long serialVersionUID = 550909478753433042L;
	
	@Column(description="전송날짜", type="datetime", length=32, index=true, notnull=true)
	@Getter @Setter
	private Date sendDate;
	
	// title을 사용, 상위 common 클래스에 있는 것
//	@Column(description="메일제목", type="varchar", length=128, index=true)
//	@Getter @Setter
//	private String mailTitle;
	
	// description 을 사용, 상위 common 클래스에 있는 것
//	@Column(description="메일내용", type="varchar", length=4096, index=true)
//	@Getter @Setter
//	private String mailMessage;
	
	@Column(description="도메인정보", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;
	
	@Column(description="전송결과", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean sendResult;
	

	public AdminEMailNotice() {
//		LOG.warning("AdminEMailNotice : empty" );	// for debug
	}

	public AdminEMailNotice(AdminEMailNotice adminEMailNotice) {
//		LOG.warning("AdminEMailNotice - 1 : " + adminEMailNotice );	// for debug
		setSendDate(adminEMailNotice.getSendDate());
		setTitle(adminEMailNotice.getTitle());
		setDescription(adminEMailNotice.getDescription());
		setSendResult(adminEMailNotice.isSendResult());
	}
	
	public AdminEMailNotice(String title, Text description, String domainName, boolean sendResult) {
//		LOG.warning("AdminEMailNotice - 2 : " + title +  description.toString());	// for debug
		setSendDate(new Date());
		setTitle(title);
		setDescription(description);
		setDomainName(domainName);
		setSendResult(sendResult);
	}
	
	@Column(description="이메일아이뒤", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getAdminEMailNoticeId() {
		return super.getKeyStr();
	}
	public void setAdminEMailNoticeId(String adminEMailNoticeId) {
		super.setKeyStr(adminEMailNoticeId);
	}
}