package net.forecs.coconut.entity.email;


@Deprecated
//@Entity
public class MailSummary {
//	private static final long serialVersionUID = -7697588197562141456L;
//
//	@Getter @Setter
//	private String userId;
//	@Getter @Setter
//	private String domainId;
//	@Getter @Setter
//	private String senderEmail;
//	@Getter @Setter
//	private String senderName;
//	@Getter @Setter
//	private Date sendDate;
//	@Getter @Setter
//	private String reciverEmail;
//	@Getter @Setter
//	private String receiverName;
//	@Getter @Setter
//	private Date receiveDate;
//	@Getter @Setter
//	private String readYN;
//
//	private Text summaryResult;
//	public void setSummaryResult(Text summaryResult) {
//		if ((summaryResult == null) || (summaryResult.getValue() == null)) summaryResult = new Text("");
//		this.summaryResult = summaryResult;
//	}
//	public Text getSummaryResult() {
//		if ((summaryResult == null) || (summaryResult.getValue() == null)) summaryResult = new Text("");
//		return summaryResult;
//	}
//
//	@Getter @Setter
//	private Date summaryDate;
//	
//	public String getMailSummaryId() {
//		return super.getKeyStr();
//	}
//
//	public void setMailSummaryId(String mailSummaryId) {
//		super.setKeyStr(mailSummaryId);
//	}
}
