package net.forecs.coconut.entity.notice;



@Deprecated
//@Entity
public class NoticeComments /*extends Common*/ {
//	private static final long serialVersionUID = -4195926551199566362L;
//
//	@Getter @Setter
//	private String domainId;
//	@Getter @Setter
//	private String noticeId;
//	@Getter @Setter
//	private String guestYN;
//	@Getter @Setter
//	private long familyId;
//	@Getter @Setter
//	private long parentId;
//	@Getter @Setter
//	private int depth;
//	@Getter @Setter
//	private int indent;
//
//	@Transient
//	@Getter @Setter
//	private Users user;
//	
//	public String getNoticeCommentId() {
//		return super.getKeyStr();
//	}
//	public void setNoticeCommentId(String noticeCommentId) {
//		super.setKeyStr(noticeCommentId);
//	}
}
