package net.forecs.coconut.entity.notice;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.NoticeKind;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.common.Common;

@Schema(name="Notice"
	, description="곻지사항"
	, pkConstraint="CONSTRAINT pk_noticeId PRIMARY KEY (noticeId)"
	, references="Domains, Boards")
@Entity
public class Notice extends Common {
	private static final long serialVersionUID = 1208192072332209757L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="공지 종류(SYSTEM/DOMAINS/BOARDS/TASKS)", type="varchar", length=8, index=true, defaultValue="BOARDS")
	@Getter @Setter
	private NoticeKind noticeKind = NoticeKind.BOARDS;
	
	@Column(description="해당 공지 종류의 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String kindId;
	
	@Column(description="공지 헤더 고정 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String headerFixYN = N;
	
	@Column(description="우선 순위", type="numeric", length=16, index=true)
	@Getter @Setter
	private Integer priority;
	
	@Column(description="공지 디스플레이 야부", type="varchar", length=1, index=true, defaultValue="Y")
	@Getter @Setter
	private String showYN = Y;

	public Notice(Notice systemNotice) {
//		notice.setKey(KeyUtil.createDomainSystemNoticeKey(systemNotice.getKey().getId()));
//		notice.setDomainId(KeyUtil.createDomainKeyString(NamespaceManager.get()));
		setNoticeKind(systemNotice.getNoticeKind());
		setKindId(systemNotice.getKindId());
		setHeaderFixYN(systemNotice.getHeaderFixYN());
		setPriority(systemNotice.getPriority());
		setShowYN(systemNotice.getShowYN());
		setTitle(systemNotice.getTitle());
		setDescription(systemNotice.getDescription());
		setCreated(systemNotice.getCreated());
		setCreator(systemNotice.getCreator());
		setDeleted(systemNotice.getDeleted());
		setDeleteYN(systemNotice.getDeleteYN());
	}
	@Transient
	private List<Attachments> attachments;
	public void setAttachments(List<Attachments> attachments) {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		this.attachments = attachments;
	}
	public List<Attachments> getAttachments() {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		return attachments;
	}
	
	@Column(description="공지 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getNoticeId() {
		return super.getKeyStr();
	}
	public void setNoticeId(String noticeId) {
		super.setKeyStr(noticeId);
	}
}
