package net.forecs.coconut.entity.manage;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.common.Common;

import com.google.appengine.api.datastore.Text;

@Schema(name="Feedbacks"
, description="피드백"
, pkConstraint="CONSTRAINT pk_feedbackId PRIMARY KEY (feedbackId)")
@Entity
public class Feedbacks extends Common {
	private static final long serialVersionUID = -6345532999072880490L;
	
	@Column(description="도메인명", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;
	
	@Column(description="분류", type="varchar", length=16, index=true)
	@Getter @Setter
	private String category;
	
	@Column(description="질문자 고유 아이디(로그인)", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private String id;
	
	@Column(description="질문자 이메일", type="varchar", length=32, index=true, notnull=true)
	@Getter @Setter
	private String email;
	
	@Column(description="답변내용", type="clob", index=true )
	@Getter @Setter
	private Text answer;
	
	@Column(description="답변자", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private String answerer;
	
	@Column(description="답변일시", type="datetime", length=16, index=true )
	@Getter @Setter
	private Date answerDate;
	
	@Column(description="답변 만족도", type="numeric", length=16, index=true)
	@Getter @Setter
	private Integer satisfaction;
	
	@Transient
	private List<Attachments> attachments;
	public void setAttachments(List<Attachments> attachments) {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		this.attachments = attachments;
	}
	public List<Attachments> getAttachments() {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		return attachments;
	}
	
	@Transient
	private List<Images> images;
	public void setImages(List<Images> images) {
		if (images == null) images = new ArrayList<Images>();
		this.images = images;
	}
	public List<Images> getImages() {
		if (images == null) images = new ArrayList<Images>();
		return images;
	}
	
	@Column(description="피드백 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getFeedbackId() {
		return super.getKeyStr();
	}
	public void setFeedbackId(String feedbackId) {
		super.setKeyStr(feedbackId);
	}
}
