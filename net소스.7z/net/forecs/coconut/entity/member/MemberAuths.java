package net.forecs.coconut.entity.member;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.AuthKind;
import net.forecs.coconut.common.code.AuthStatus;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.user.Users;

@Schema(name="MemberAuths"
	, description="멤버 권한"
	, pkConstraint="CONSTRAINT pk_memberAuthId PRIMARY KEY (memberAuthId)"
	, fkConstraints="CONSTRAINT fk_userId FOREIGN KEY (userId) REFERENCES Users(userId)"
	, references={"Domains", "Boards", "Users"})
@Entity
public class MemberAuths extends Base {
	private static final long serialVersionUID = -8731297324999072516L;

	@Column(description="도메인 아이디", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="권한 타입(DOMAINS/GROUPS/BOARDS/TASKLISTS/TASKS/TASK_COMMENTS/NOTICE/NOTICE_COMMENTS/ATTACHEMENTS/SCHEDULE)", type="varchar", length=16, index=true)
	@Getter @Setter
	private AuthKind authKind;
	
	@Column(description="해당 객체의 아이디", type="varchar", length=32, index=true, notnull=true)
	@Getter @Setter
	private String kindId;
	
	@Column(description="사용자 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String userId;
	
	@Column(description="멤버 권한(ADMIN/SUPER/OWNER/MANAGER/MEMBER/VIEWER/GUEST)", type="varchar", length=8, index=true, defaultValue="MEMBER")
	@Getter @Setter
	private Auth auth = Auth.MEMBER;
	
	@Column(description="멤버 상태(ACTIVE/INACTIVE/WAITING/TEMPLATE)", type="varchar", length=8, index=true, defaultValue="ACTIVE")
	@Getter @Setter
	private AuthStatus authStatus = AuthStatus.ACTIVE;
	
	@Transient
	@Getter @Setter
	private Users user;
	
	@Deprecated
	@Transient
	@Getter @Setter
	private boolean isOnline;

	public MemberAuths() {}
	public MemberAuths(String domainId, String boardId, AuthKind authKind, String kindId, String userId, String creator, Auth auth, AuthStatus authStatus){
		this.domainId = domainId;
		this.boardId = boardId;
		this.authKind = authKind;
		this.kindId = kindId;
		this.userId = userId;
		this.setCreator(creator);
		this.auth = auth;
		this.authStatus = authStatus;
	}

	@Column(description="멤버 권한 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getMemberAuthId() {
		return super.getKeyStr();
	}

	public void setMemberAuthId(String memberAuthId) {
		super.setKeyStr(memberAuthId);
	}
}
