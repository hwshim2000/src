package net.forecs.coconut.entity.setting;

import javax.persistence.Entity;

import com.google.appengine.api.datastore.Text;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="UserSetting"
	, description="사용자 환경 설정"
	, pkConstraint="CONSTRAINT pk_userSettingId PRIMARY KEY (userSettingId)")
@Entity
public class UserSetting extends Base {
	private static final long serialVersionUID = 6542964604116683561L;

	@Column(description="셋팅명", type="varchar", length=32, index=true, notnull=true, unique=true)
	@Getter @Setter
	private String name;

	@Column(description="셋팅값", type="varchar", length=1024, index=true)
	private Text value;
	public void setValue(Text value) {
		if ((value == null) || (value.getValue() == null)) value = new Text("");
		this.value = value;
	}
	public Text getValue() {
		if ((value == null) || (value.getValue() == null)) value = new Text("");
		return value;
	}
}