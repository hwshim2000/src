package net.forecs.coconut.entity.setting;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.NotificationType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="NotificationSettings"
	, description="알림 셋팅"
	, pkConstraint="CONSTRAINT pk_notificationSettingId PRIMARY KEY (notificationSettingId)"
	, fkConstraints="CONSTRAINT fk_userId FOREIGN KEY (userId) REFERENCES Users(userId)"
	, references="Users")
@Entity
public class NotificationSettings extends Base {
	private static final long serialVersionUID = -2401959791753201565L;

	@Column(description="사용자 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String userId;
	
//	@Getter @Setter
//	//private SettingType type;
//	private SettingType type = SettingType.DASHBOARD; // Update시 이값이 Null인 상태로 올 경우 default 값으로 셋팅되어서 문제가 발생
	@Column(description="웹 알림 여부", type="varchar", length=1, index=true, defaultValue="Y")
	@Getter @Setter
	private String webPushYN = Y;
	
	@Column(description="이메일 알림 여부", type="varchar", length=1, index=true, defaultValue="Y")
	@Getter @Setter
	private String emailPushYN = Y;
	
	@Column(description="모바일 알림 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String mobilePushYN = N;
	
	@Column(description="알림 타입(INSTANT, MINUTE, HOUR,DAY)", type="varchar", length=8, index=true, defaultValue="HOUR")
	@Getter @Setter
	private NotificationType notificationType = NotificationType.HOUR;
	
	@Column(description="알림 주기(알림타입과 연관)", type="numeric", length=16, index=true, defaultValue="1")
	@Getter @Setter
	private Integer period = 1;
	
	@Column(description="알림 실행 일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date excutionDate;
	
	@Column(description="알람 설정값", type="varchar", length=4096, index=true)
	@Getter @Setter
	private String settings;
	
	@Column(description="태스크 큐 이름(이벤트 발생을 위한 등록 이름)", type="varchar", length=32, index=true, unique=true)
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private String taskName;

	private List<String> activities = new ArrayList<String>();
	public void setActivities(List<String> activities) {
		if (activities == null) activities = new ArrayList<String>();
		this.activities = activities;
	}
	public List<String> getActivities() {
		if (activities == null) activities = new ArrayList<String>();
		return activities;
	}
	
	public NotificationSettings() {	}
	public NotificationSettings(String userId, String creator) {
		this.userId = userId;
		this.setCreator(creator);
//		this.type = type;
	}

	@Column(description="알림 셋팅 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getNotificationSettingId() {
		return super.getKeyStr();
	}

	public void setNotificationSettingId(String notificationSettingId) {
		super.setKeyStr(notificationSettingId);
	}
	
//	private Text activities;
//	public void setActivities(List<String> activities) {
//		if ((this.activities == null) || (this.activities.getValue() == null)) this.activities = new Text("");
//		if (activities == null) activities = new ArrayList<String>();
//		
//		this.activities = new Text(StringUtils.join(activities, ","));
//	}
//	@SuppressWarnings("unchecked")
//	public List<String> getActivities() {
//		if ((activities == null) || (activities.getValue() == null)) activities = new Text("");
//		return Arrays.asList(activities.getValue().split(","));
//	}
}
