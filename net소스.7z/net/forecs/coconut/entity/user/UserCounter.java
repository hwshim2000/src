package net.forecs.coconut.entity.user;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.googlecode.objectify.annotation.Cache;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;

import java.util.Date;
import net.forecs.coconut.common.Logger;


/**
 * This is a singleton, just holding a count of the number
 * of User objects we have.
 * <p> The reason for using this is that counting the number of items
 * dynamically is very inefficient, and costly.
 * <p> This counter should be changed relatively rarely (less than once a second)
 * so doesn't need to be sharded.
 */
@Cache
@Entity
public class UserCounter {
    @SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(UserCounter.class.getName());

    public static final String COUNTER_ID = "counterID";

    @Id
    private String id;
    private int count;
    private Date lastModified;

	@SuppressWarnings("unused")
	private UserCounter() {
		this(COUNTER_ID);
	}

	public UserCounter(String id) {
		this.id = id;
		lastModified = new Date(0L);
	}

	public int getCount() {
		return count;
	}

	public void delta(long delta) {
		count += delta;
		lastModified = new Date();
	}

	public Date getLastModified() {
		return lastModified;
	}

	public String getObjectId() {
		Key key = KeyFactory.createKey(UserCounter.class.getSimpleName(), id);
		return KeyFactory.keyToString(key);
	}
}