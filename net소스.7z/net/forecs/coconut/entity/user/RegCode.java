package net.forecs.coconut.entity.user;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.googlecode.objectify.annotation.Cache;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;

import lombok.Getter;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import net.forecs.coconut.common.Logger;


@Cache
@Entity
public class RegCode {
    @SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(RegCode.class.getName());

	@Id
	@Getter
	private String code;

	@Getter
	private String domainName;

	@Getter
	private String id;		// Login User ID

	@Getter
	private String userName;

	@Getter
	private String email;

    private Date dateCreated;
    private long expiresIn;	// milliseconds

    // for objectify
    @SuppressWarnings("unused")
	private RegCode() {}

    public RegCode(String code, String domainName, String id, String userName, String email,
    		long expiresIn, TimeUnit unit) {
        this.code = code;
        this.domainName = domainName;
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.dateCreated = new Date();
        this.expiresIn = unit.toMillis(expiresIn);
    }

    public boolean isValid() {
        return dateCreated.getTime() + expiresIn > new Date().getTime();
    }

    public String getObjectId() {
		Key key = KeyFactory.createKey(RegCode.class.getSimpleName(), code);
		return KeyFactory.keyToString(key);
	}
}