package net.forecs.coconut.entity.user;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="UserDevices"
	, description="사용자 모바일 기기 정보"
	, pkConstraint="CONSTRAINT pk_userDeviceId PRIMARY KEY (userDeviceId)")
@Entity
public class UserDevices extends Base {
	private static final long serialVersionUID = 905120842307772276L;

	@Column(description="GCM 아이디", type="varchar", length=32, index=true, notnull=true, unique=true)
	@Getter @Setter
	private String gcmId;	// Used as device ID

	@Column(description="디바이스 OS", type="varchar", length=32, index=true)
	@Getter @Setter
	private String os;
	
	@Column(description="디바이스 OS 버전", type="varchar", length=32, index=true)
	@Getter @Setter
	private String osVersion;
	
	@Column(description="디바이스 모델명", type="varchar", length=32, index=true)
	@Getter @Setter
	private String model;

	@Column(description="사용자 디바이스 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getUserDeviceId() {
		return super.getKeyStr();
	}

	public void setUserDeviceId(String userDeviceId) {
		super.setKeyStr(userDeviceId);
	}
}
