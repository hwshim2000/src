package net.forecs.coconut.entity.user;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import net.forecs.coconut.common.Logger;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.user.Permission;
import net.forecs.coconut.user.Role;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.ShortBlob;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;
import com.googlecode.objectify.annotation.Cache;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;


@Cache
@Entity(name = "Users")
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class GaeUser implements Serializable, IUser {
	private static final long serialVersionUID = -8243376715829508328L;
	static final Logger LOG = Logger.getLogger(GaeUser.class.getName());

	@Getter @Setter
	private String domainName;

	@Id
	private String key;

	//@Id
	@Getter
	private String id;
	@Setter
	private String password;

    /** The salt, used to make sure that a dictionary attack is harder given a list of all the
     *  hashed passwords, as each salt will be different.
     */
	//private byte[] salt;
	private ShortBlob salt;

	@Getter @Setter
	private String userName;
    @Getter @Setter
    private String email;

    //-->
	//private Set<String> roles;
	//public void setRoles(Set<String> roles) {
	//	if (roles == null) roles = new HashSet<String>();
	//	this.roles = roles;
	//}
	//public Set<String> getRoles() {
	//	if (roles == null) roles = new HashSet<String>();
	//	return roles;
	//}
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Set<String> getRoles() {
		return Role.toRoleSet(role);
	}
	//<--

	//--> jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	private String role;
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		if (!Role.isValid(role)) {
			LOG.severe("Rejected the invalid role : " + role);
			return;
		}
		this.role = role;
	}
	//<--

	//-->
	//private Set<String> permissions;
	//public void setPermissions(Set<String> permissions) {
	//	if (permissions == null) permissions = new HashSet<String>();
	//	this.permissions = permissions;
	//}
	//public Set<String> getPermissions() {
	//	if (permissions == null) permissions = new HashSet<String>();
	//	return permissions;
	//}
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Set<String> getPermissions() {
		return Permission.fromRole(role);
	}
	//<--

    @Index
    private Date dateRegistered;

    @Getter @Setter
    private boolean active = true;

    // For objectify to create instances on retrieval
	@SuppressWarnings("unused")
	private GaeUser() {
		active = true;
	}

	//-->
	/*
	public GaeUser(String id, String password, String userName, String email,
			Set<String> roles, Set<String> permissions) {
		Preconditions.checkNotNull(id, "User ID can't be null");
		Preconditions.checkNotNull(roles, "User roles can't be null");
		Preconditions.checkNotNull(permissions, "User permissions can't be null");

		this.id = id;
		setPasswordHash(password);
		this.userName = userName;
		this.email = email;

		this.roles = new HashSet<String>(roles);
		this.permissions = new HashSet<String>(permissions);

		active = true;
	}
	*/
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	public GaeUser(String id, String password, String userName, String email, String role) {
		Preconditions.checkNotNull(id, "User ID can't be null");
		Preconditions.checkNotNull(role, "User role can't be null");
		Preconditions.checkArgument(Role.isValid(role), "Invalid user role : " + role);

		this.id = id;
		//this.lowerId = id.toLowerCase();
		setPasswordHash(password);
		this.userName = userName;
		this.email = email;

		setRole(role);

		active = true;
	}
	//<--

    public void setPasswordHash(String password) {
        Preconditions.checkNotNull(password);
        //salt = ShiroUtils.salt().getBytes();
        //this.password = ShiroUtils.hash(password, salt);
        salt = new ShortBlob(ShiroUtils.salt().getBytes());
        this.password = ShiroUtils.hash(password, salt.getBytes());
    }

    public Date getDateRegistered() {
        return dateRegistered == null ? null : new Date(dateRegistered.getTime());
    }

    @JsonIgnore
    public boolean isRegistered() {
        return getDateRegistered() != null;
    }

    public void register() {
        dateRegistered = new Date();
    }

    public boolean isValid() {
    	return isRegistered() && isActive();
    }

    @JsonIgnore
    public String getPassword() {
        return password;
    }

    @JsonIgnore
    public byte[] getSalt() {
        //return salt;
    	return salt.getBytes();
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof GaeUser) {
            GaeUser u = (GaeUser)o;
            return Objects.equal(getId(), u.getId()) &&
                   Objects.equal(getPassword(), u.getPassword());
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, password);
    }

    public String toJSONString() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            String out = mapper.writeValueAsString(this);
            return out;
        } catch (JsonProcessingException e) {
            LOG.severe("Can't convert GaeUser " + this + " to JSON string");
            return "";
        }
    }

    public String getObjectId() {
		Key key = KeyFactory.createKey(GaeUser.class.getSimpleName(), id);
		return KeyFactory.keyToString(key);
	}
}