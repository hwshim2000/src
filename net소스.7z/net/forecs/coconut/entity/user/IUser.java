package net.forecs.coconut.entity.user;

import java.util.Date;
import java.util.Set;


public interface IUser {
	public abstract String getObjectId();

	public abstract boolean isActive();
    public abstract void setActive(boolean suspended);

    public abstract boolean isRegistered();
    public abstract Date getDateRegistered();
    public abstract void register();

    public abstract boolean isValid();

    public abstract String getId();

	public abstract String getPassword();
    public abstract void setPassword(String password);
	public abstract byte[] getSalt();

	public abstract String getEmail();

	public abstract Set<String> getRoles();
	//-->
	//@Deprecated
	//public abstract void setRoles(Set<String> roles);
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	public abstract String getRole();
	public abstract void setRole(String role);
	//<--

    public abstract Set<String> getPermissions();
    //-->
	//@Deprecated
    //public abstract void setPermissions(Set<String> permissions);
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	//<--

    @Deprecated
    public abstract String getDomainName();
    
    public abstract String getUserName();
}