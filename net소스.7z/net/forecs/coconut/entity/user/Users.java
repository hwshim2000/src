package net.forecs.coconut.entity.user;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.UserType;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.user.Permission;
import net.forecs.coconut.user.Role;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Text;
import com.google.common.base.Objects;
import com.google.common.base.Preconditions;

@Schema(name="Users"
	, description="사용자"
	, pkConstraint="CONSTRAINT pk_userId PRIMARY KEY (userId)")
@Entity
public class Users extends Base implements IUser {
	private static final long serialVersionUID = 3623909402742095110L;
	private static final Logger LOG = Logger.getLogger(Users.class.getName());

	@Column(description="도메인명", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;

	@Column(description="사용자 고유 아이디(로그인)", type="varchar", length=16, index=true, notnull=true, unique=true)
	@Getter
	private String id;			// Login ID
	public void setId(String id) {
		this.id = id;
		this.lowerId = id.toLowerCase();
	}
	
	@Column(description="*사용자 고유 아이디(로그인) - 대소문자를 구분하지 않는 특정 도메인을 위해", type="varchar", length=16, index=true, notnull=true, unique=true)
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private String lowerId;

	@Column(description="사용자 로그인 암호", type="varchar", length=16, index=true, notnull=true)
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private String password;
	/**
	 * The salt, used to make sure that a dictionary attack is harder given a
	 * list of all the hashed passwords, as each salt will be different.
	 */
	
	@Column(description="암호 추가 내부 코드", type="char", length=16, index=true, notnull=true)
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private byte[] salt;

	@Column(description="사용자 이메일", type="varchar", length=32, index=true, notnull=true)
	@Getter @Setter
	private String email;

	//-->
	@Deprecated	// TODO : Remove this after data migration
	private Set<String> roles;
	//public void setRoles(Set<String> roles) {
	//	if (roles == null) roles = new HashSet<String>();
	//	this.roles = roles;
	//}
	//public Set<String> getRoles() {
	//	if (roles == null) roles = new HashSet<String>();
	//	return roles;
	//}
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Set<String> getRoles() {
		// TODO : Remove this after data migration
		if (StringUtils.isEmpty(role)) {
			if (roles == null) roles = new HashSet<String>();
			return roles;
		}
		return Role.toRoleSet(role);
	}
	//<--

	//--> jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	@Column(description="사용자 역할", type="varchar", length=16, index=true)
	private String role;
	@SuppressWarnings("deprecation")
	public String getRole() {
		// TODO : Remove this after data migration
		if (StringUtils.isEmpty(role)) {
			role = Role.fromRoleSet(roles);
		}
		return role;
	}
	public void setRole(String role) {
		if (!Role.isValid(role)) {
			LOG.warning("Rejected the invalid role : " + role);
			return;
		}
		this.role = role;
	}
	//<--

    //-->
    //private Set<String> permissions;
	//public void setPermissions(Set<String> permissions) {
	//	if (permissions == null) permissions = new HashSet<String>();
	//	this.permissions = permissions;
	//}
	//public Set<String> getPermissions() {
	//	if (permissions == null) permissions = new HashSet<String>();
	//	return permissions;
	//}
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	@Column(description="사용자 권한", type="varchar", length=16, index=true)
	@SuppressWarnings("deprecation")
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
    public Set<String> getPermissions() {
    	// TODO : Remove this after data migration
    	if (StringUtils.isEmpty(role)) {
			role = Role.fromRoleSet(roles);
		}
    	return Permission.fromRole(role);
    }
	//<--

	@Column(description="사용자 등록일", type="datetime", length=32, index=true, notnull=true)
    private Date dateRegistered;

	@Column(description="사용자 활성 여부", type="bool", length=1, index=true, defaultValue="true")
    @Getter @Setter
    private boolean active = true;

	@Column(description="강제 비밀 번호 변경 여부", type="varchar", length=16, index=true, notnull=true, unique=true)
	@Getter @Setter
    private String forcePasswordChangeYN = N;
	
	@Column(description="사용자 타입(SITE/DOMAIN/GUEST)", type="varchar", length=8, index=true, defaultValue="DOMAIN")
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private UserType userType = UserType.DOMAIN;

	@Column(description="사용자명", type="varchar", length=32, index=true, notnull=true)
	@Getter @Setter
	private String userName;
	
	@Column(description="사용자 닉네임", type="varchar", length=32, index=true)
	@Getter @Setter
	private String nickName;

	@Column(description="사용자 등록 확인 유무", type="varchar", length=1, index=true, defaultValue="Y")
	@Getter @Setter
	private String confirmYN = Y;
	
	@Deprecated
	@Transient
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private String confirmToken;

	@Deprecated
	@Transient
	@Getter @Setter
	private boolean online;

	@Column(description="사용자 사진 링크 URL", type="varchar", length=256, index=true)
	@Setter
	private String pictureURL;
	
	/** binary data(512kb limits) */
	@Deprecated
	private Text picture;
	public void setPicture(Text picture) {
		if ((picture == null) || (picture.getValue() == null)) picture = new Text("");
		this.picture = picture;
	}
	
	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getPicture() {
		if ((picture == null) || (picture.getValue() == null)) picture = new Text("");
		return picture;
	}
	
	public String getPictureURL() {
		if (StringUtils.isNotBlank(this.pictureURL)) {
			return this.pictureURL;
		}
	
		if (picture != null && StringUtils.isNotBlank(picture.getValue())) {
			String modifiedStr = "";
			try {
				if (getModified() != null) { modifiedStr = CalendarUtil.toString(getModified(), "yyyyMMddHHmmss"); }
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
			return String.format("%s?domainName=%s&userId=%s&modified=%s",
					CommonProperty.USER_PICTURE_URL,
					domainName,
					getUserId(),
					modifiedStr
					);
		} else {
			return null;
			//return "https://storage.googleapis.com/cocoworks-for-ecs.appspot.com/imgaes/users/img_member34.png";
		}
	}
	
	@Column(description="로그인 일시", type="datetime", length=32, index=true, notnull=true)
	@Getter @Setter
	private Date loginDate;
	
	@Column(description="로그아웃 일시", type="datetime", length=32, index=true, notnull=true)
	@Getter @Setter
	private Date logoutDate;

	@Transient
	@Getter @Setter
	private UserProfiles userProfiles;
	
//	public UserProfiles getUserProfiles() {
//		if (userProfiles == null) userProfiles = new UserProfiles();
//		
//		return userProfiles;
//	}	
//	public void setUserProfiles(UserProfiles userProfiles) {
//		if (userProfiles == null) userProfiles = new UserProfiles();
//		
//		this.userProfiles = userProfiles;
//	}
	
	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private int nuts = 50;

	public Users() {
        active = true;
	}

	public Users(Users user) {
		domainName = user.getDomainName();

		id = user.getId();
		password = user.getPassword();
		salt = user.getSalt();
		userName = user.getUserName();
		email = user.getEmail();

		//-->
		//roles = user.getRoles();
		//permissions = user.getPermissions();
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		role = user.getRole();
		//<--

		active = user.isActive();
	}

	//-->
	/*
	@Deprecated
	public Users(String id, String password, String userName, String email,
			Set<String> roles, Set<String> permissions) {
		Preconditions.checkNotNull(id, "User ID can't be null");
		Preconditions.checkNotNull(roles, "User roles can't be null");
		Preconditions.checkNotNull(permissions, "User permissions can't be null");

		this.id = id;
		this.lowerId = id.toLowerCase();
		setPasswordHash(password);
		this.userName = userName;
		this.email = email;

		this.roles = new HashSet<String>(roles);
		this.permissions = new HashSet<String>(permissions);

		active = true;
	}
	*/
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	public Users(String id, String password, String userName, String email, String role) {
		Preconditions.checkNotNull(id, "User ID can't be null");
		Preconditions.checkNotNull(role, "User role can't be null");
		Preconditions.checkArgument(Role.isValid(role), "Invalid user role : " + role);

		this.id = id;
		this.lowerId = id.toLowerCase();
		setPasswordHash(password);
		this.userName = userName;
		this.email = email;

		setRole(role);

		active = true;
	}
	//<--

	// Get database entity ID
	@Column(description="사용자 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getUserId() {
		return super.getKeyStr();
	}

	// Set database entity ID
	public void setUserId(String userId) {
		super.setKeyStr(userId);
	}

	public void setPasswordHash(String password) {
		Preconditions.checkNotNull(password);
        salt = ShiroUtils.salt().getBytes();
        this.password = ShiroUtils.hash(password, salt);
	}

	@Override
	public Date getDateRegistered() {
		return dateRegistered == null ? null : new Date(dateRegistered.getTime());
	}

	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Override
	public boolean isRegistered() {
		return getDateRegistered() != null;
	}

	@Override
	public void register() {
		dateRegistered = new Date();
	}

	@Override
	public boolean isValid() {
		return isRegistered() && isActive();
	}

    @Override
    public int hashCode() {
        return Objects.hashCode(id, password);
    }

	public String toJSONString() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            String out = mapper.writeValueAsString(this);
            return out;
        } catch (JsonProcessingException e) {
            LOG.severe("Can't convert Users " + this + " to JSON string");
            return "";
        }
	}

	//-->
	/*
	@Deprecated
	public boolean addRoles(Set<String> roles) {
		return this.roles.addAll(roles);
	}

	@Deprecated
	public boolean removeRoles(Set<String> roles) {
		return this.roles.removeAll(roles);
	}
	*/
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	//<--

	public boolean addPermissions(Set<String> permissions) {
		return permissions.addAll(permissions);
	}

	public boolean removePermissions(Set<String> permissions) {
		return permissions.removeAll(permissions);
	}

	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public boolean isGuest() {
		//-->
		//return roles.contains(Role.GUEST);
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		return Role.GUEST.equals(getRole());
		//<--
	}

	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public boolean isAdmin() {
		//-->
		//return roles.contains(Role.ADMIN);
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		return Role.ADMIN.equals(getRole());
		//<--
	}

	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public boolean isSuper() {
		//-->
		//return roles.contains(Role.SUPER);
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		final String role = getRole();
		return Role.SUPER.equals(role) || Role.ADMIN.equals(role);
		//<--
	}
	
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public boolean isManager() {
		final String role = getRole();
		return Role.MANAGER.equals(role) || Role.SUPER.equals(role) || Role.ADMIN.equals(role);
	}
}