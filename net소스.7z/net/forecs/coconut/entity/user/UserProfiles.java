package net.forecs.coconut.entity.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Email;
import com.google.appengine.api.datastore.Link;
import com.google.appengine.api.datastore.PhoneNumber;
import com.google.appengine.api.datastore.PostalAddress;

@Schema(name="UserProfiles"
	, description="사용자 프로필"
	, pkConstraint="CONSTRAINT pk_userProfileId PRIMARY KEY (userProfileId)"
	, fkConstraints="CONSTRAINT fk_userId FOREIGN KEY (userId) REFERENCES Users(userId)"
	, references="Users")
@Entity
public class UserProfiles extends Base {
	private static final long serialVersionUID = 8457810937672431306L;

	@Column(description="사용자 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String userId;

	@Column(description="성별", type="varchar", length=8, index=true)
	@Getter @Setter
	private String gender;
	
	@Column(description="전화번호 국가 코드", type="varchar", length=4, index=true)
	@Getter @Setter
	private String phoneNationCode;
	
	@Column(description="전화 번호", type="varchar", length=16, index=true)
	@Getter @Setter
	private PhoneNumber phone;
	
	@Column(description="팩스 국가 코드", type="varchar", length=4, index=true)
	@Getter @Setter
	private String faxNationCode;
	
	@Column(description="팩스 번호", type="varchar", length=16, index=true)
	@Getter @Setter
	private PhoneNumber fax;
	
	@Column(description="양력/음력", type="varchar", length=8, index=true)
	@Getter @Setter
	private SolarType solarType;
	
	@Column(description="생년일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date birthday;
	
	@Column(description="윤달코드", type="numeric", length=16, index=true)
	@Getter @Setter
	private int birthdayLeap;
	
	@Column(description="결혼기념일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date weddingday;
	
	@Column(description="결혼유무", type="varchar", length=1, index=true)
	@Getter @Setter
	private String marriedYN;
	
	@Column(description="우편번호", type="varchar", length=8, index=true)
	@Getter @Setter
	private String post;
	
	@Column(description="국가코드", type="varchar", length=8, index=true)
	@Getter @Setter
	private String nationCode;
	
	@Column(description="국가", type="varchar", length=32, index=true)
	@Getter @Setter
	private String nation;
	
	@Column(description="시/군/구", type="varchar", length=32, index=true)
	@Getter @Setter
	private String area;
	
	@Column(description="도시", type="varchar", length=32, index=true)
	@Getter @Setter
	private String city;
	
	@Column(description="주소", type="varchar", length=256, index=true)
	@Getter @Setter
	private PostalAddress address;
	
	@Column(description="직업", type="varchar", length=32, index=true)
	@Getter @Setter
	private String jobTitle;
	
	@Column(description="부서", type="varchar", length=32, index=true)
	@Getter @Setter
	private String department;
	
	@Column(description="조직/단체", type="varchar", length=32, index=true)
	@Getter @Setter
	private String organization;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private String taskNames; // for alarm taskName

	@Column(description="전화 목록", type="varchar", length=1024)
	private List<PhoneNumber> tels;
	public void setTels(List<PhoneNumber> tels) {
		if (tels == null) tels = new ArrayList<PhoneNumber>();
		this.tels = tels;
	}
	public List<PhoneNumber> getTels() {
		if (tels == null) tels = new ArrayList<PhoneNumber>();
		return tels;
	}

	@Column(description="이메일 목록", type="varchar", length=1024)
	private List<Email> emails;
	public void setEmails(List<Email> emails) {
		if (emails == null) emails = new ArrayList<Email>();
		this.emails = emails;
	}
	public List<Email> getEmails() {
		if (emails == null) emails = new ArrayList<Email>();
		return emails;
	}

	@Column(description="주소 목록", type="varchar", length=1024, index=true)
	private List<PostalAddress> addresses;
	public void setAddresses(List<PostalAddress> addresses) {
		if (addresses == null) addresses = new ArrayList<PostalAddress>();
		this.addresses = addresses;
	}
	public List<PostalAddress> getAddresses() {
		if (addresses == null) addresses = new ArrayList<PostalAddress>();
		return addresses;
	}

	@Column(description="웹주소 목록", type="varchar", length=1024, index=true)
	private List<Link> urls;
	public void setUrls(List<Link> urls) {
		if (urls == null) urls = new ArrayList<Link>();
		this.urls = urls;
	}
	public List<Link> getUrls() {
		if (urls == null) urls = new ArrayList<Link>();
		return urls;
	}

	@Column(description="기념일 목록", type="varchar", length=1024, index=true)
	private List<Date> memorials;
	public void setMemorials(List<Date> memorials) {
		if (memorials == null) memorials = new ArrayList<Date>();
		this.memorials = memorials;
	}
	public List<Date> getMemorials() {
		if (memorials == null) memorials = new ArrayList<Date>();
		return memorials;
	}
	@Column(description="관련정보 목록", type="varchar", length=1024, index=true)
	private List<String> relations;
	public void setRelations(List<String> relations) {
		if (relations == null) relations = new ArrayList<String>();
		this.relations = relations;
	}
	public List<String> getRelations() {
		if (relations == null) relations = new ArrayList<String>();
		return relations;
	}

	@Column(description="소셜정보 목록", type="varchar", length=1024, index=true)
	private List<String> socialProfiles;
	public void setSocialProfiles(List<String> socialProfiles) {
		if (socialProfiles == null) socialProfiles = new ArrayList<String>();
		this.socialProfiles = socialProfiles;
	}
	public List<String> getSocialProfiles() {
		if (socialProfiles == null) socialProfiles = new ArrayList<String>();
		return socialProfiles;
	}

	@Column(description="메신저 목록", type="varchar", length=1024, index=true)
	private List<String> messengers;
	public void setMessengers(List<String> messengers) {
		if (messengers == null) messengers = new ArrayList<String>();
		this.messengers = messengers;
	}
	public List<String> getMessengers() {
		if (messengers == null) messengers = new ArrayList<String>();
		return messengers;
	}

	@Column(description="사용자 프로필 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getUserProfileId() {
		return super.getKeyStr();
	}

	public void setUserProfileId(String userProfileId) {
		super.setKeyStr(userProfileId);
	} 
}