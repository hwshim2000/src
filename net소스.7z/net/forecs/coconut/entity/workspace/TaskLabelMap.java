package net.forecs.coconut.entity.workspace;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;


@Schema(name="TaskLabelMap"
	, description="태스크 레이블"
	, pkConstraint="CONSTRAINT pk_taskLabelId PRIMARY KEY (taskLabelId)"
	, fkConstraints={"CONSTRAINT fk_taskId FOREIGN KEY (taskId) REFERENCES Tasks(taskId)",
		"CONSTRAINT fk_taskLabelId FOREIGN KEY (taskLabelId) REFERENCES Tasks(taskId)"}
	, references={"Tasks", "TaskLabels"})
@Entity
public class TaskLabelMap extends Base {
	private static final long serialVersionUID = -5567843073893245546L;

	@Column(description="태스크 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="태스크 레이블 아이디", type="varchar", length=32, foreign=true, index=true, notnull=true)
	@Getter @Setter
	private String taskLabelId;

	public TaskLabelMap(String taskId, String taskLabelId) {
		this.taskId = taskId;
		this.taskLabelId = taskLabelId;
	}
	
	@Column(description="레이블 맵 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskLabelMapId() {
		return super.getKeyStr();
	}
	public void setTaskLabelMapId(String taskLabelMapId) {
		super.setKeyStr(taskLabelMapId);
	}
}
