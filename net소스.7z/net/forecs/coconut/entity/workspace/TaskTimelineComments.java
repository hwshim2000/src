package net.forecs.coconut.entity.workspace;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.KeyFactory;

@Schema(name="TaskTimelineComments"
	, description="태스크 타임라인 코멘트"
	, pkConstraint="CONSTRAINT pk_taskTimelineCommentId PRIMARY KEY (taskTimelineCommentId)"
	, fkConstraints="CONSTRAINT fk_taskTimelineId FOREIGN KEY (taskTimelineId) REFERENCES TaskTimelines(taskTimelineId)"
	, references="TaskTimelines")
@Entity
public class TaskTimelineComments extends Common {
	private static final long serialVersionUID = 4855824447391436452L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="태스크 타임라인 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String taskTimelineId;
	
	@Column(description="맨션 대상 유저 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private List<String> mentionIds;

	@Column(description="부모 아이디", type="varchar", length=32, index=true)
	private long parentId;
	public String getParentId() {
		if (parentId != 0) {
			return KeyFactory.keyToString(KeyFactory.createKey(KeyFactory.stringToKey(taskId),
					TaskTimelineComments.class.getSimpleName(), parentId));
		} else {
			return "0";
		}
	}
	public void setParentId(String parentId) {
		if (StringUtils.isBlank(parentId) || "0".equals(parentId)) {
			this.parentId = 0;
		} else {
			this.parentId = KeyFactory.stringToKey(parentId).getId();
		}
	}

	@Transient
	@Getter @Setter
	private Users user;
	
	@Column(description="이모티콘", type="varchar", length=256, index=true)
	@Getter @Setter
	private String emoticon;
	
//	@Transient
//	private List<String> emoticons;
//	public void setEmoticons(List<String> emoticons) {
//		if (emoticons == null) emoticons = new ArrayList<String>();
//		this.emoticons = emoticons;
//	}
//	public List<String> getEmoticons() {
//		if (emoticons == null) emoticons = new ArrayList<String>();
//		return emoticons;
//	}

	@Column(description="태스크 타임라인 댓글 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskTimelineCommentId() {
		return super.getKeyStr();
	}
	public void setTaskTimelineCommentId(String taskTimelineCommentId) {
		super.setKeyStr(taskTimelineCommentId);
	}
}
