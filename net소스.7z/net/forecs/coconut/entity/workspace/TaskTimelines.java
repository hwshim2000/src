package net.forecs.coconut.entity.workspace;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.user.Users;

import com.google.appengine.api.datastore.Text;

@Schema(name="TaskTimelines"
, description="태스크 타임라인"
, pkConstraint="CONSTRAINT pk_taskTimelineId PRIMARY KEY (taskTimelineId)"
, fkConstraints="CONSTRAINT fk_taskId FOREIGN KEY (taskId) REFERENCES Tasks(taskId)"
, references="Tasks")
@Entity
public class TaskTimelines extends Common {
	private static final long serialVersionUID = -6955832086299912653L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="포스트 평가수(Excellent)", type="numeric", length=16, index=true)
	@Getter @Setter
	private int evalExcellents;
	
	@Column(description="포스트 평가수(Good)", type="numeric", length=16, index=true)
	@Getter @Setter
	private int evalGoods;
	
	@Column(description="포스트 평가수(Effort)", type="numeric", length=16, index=true)
	@Getter @Setter
	private int evalEfforts;
	
	@Column(description="마지막 코멘트 작성 일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date lastCommented;	
	@Transient
	@Getter @Setter
	private Users user;
	@Transient
	private List<Attachments> attachments;
	@Transient
	private List<Images> images;
	@Transient
	private List<TaskTimelineComments> comments;
	
	@Column(description="맨션 대상 유저 아이디 목록", type="varchar", length=4096, index=true)
	@Getter @Setter
	private List<String> mentionIds;
	
	@Transient
	@Getter @Setter
	private String taskTitle;
	@Transient
	@Getter @Setter
	private String boardTitle;

	@Column(description="외부 포스트 링크 정보", type="clob", index=true)
	@Getter @Setter
	private Text links;
	
	@Column(description="이모티콘", type="varchar", length=256, index=true)
	@Getter @Setter
	private String emoticon;
//	public Map<String, Object> getLinkSources() {
//		if (linkSources != null && StringUtils.isNotBlank(linkSources.getValue())) {
//			try {
//				ObjectMapper om = new ObjectMapper();
//				return om.readValue(linkSources.getValue(), new TypeReference<HashMap<String, Object>>() {});
//			} catch (Exception ex) {
//			}
//		}
//		return null;
//	}
//	public void setLinkSources(Map<String, Object> linkSources) {
//		if (linkSources != null) {
//			ObjectMapper om = new ObjectMapper();
//			try {
//				String str = om.writeValueAsString(linkSources);
//				this.linkSources = new Text(str);
//			} catch (Exception ex) {
//				this.linkSources = null;
//			}
//		}
//	}
	
	public void setAttachments(List<Attachments> attachments) {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		this.attachments = attachments;
	}
	
	public List<Attachments> getAttachments() {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		return attachments;
	}
	
	public void setImages(List<Images> images) {
		if (images == null) images = new ArrayList<Images>();
		this.images = images;
	}
	
	public List<Images> getImages() {
		if (images == null) images = new ArrayList<Images>();
		return images;
	}
	
	public void setComments(List<TaskTimelineComments> comments) {
		if (comments == null) comments = new ArrayList<TaskTimelineComments>();
		this.comments = comments;
	}
	
	public List<TaskTimelineComments> getComments() {
		if (comments == null) comments = new ArrayList<TaskTimelineComments>();
		return comments;
	}

	@Column(description="태스크 타임라인 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskTimelineId() {
		return super.getKeyStr();
	}
	
	public void setTaskTimelineId(String taskTimelineId) {
		super.setKeyStr(taskTimelineId);
	}
}
