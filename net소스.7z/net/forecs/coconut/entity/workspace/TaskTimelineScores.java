package net.forecs.coconut.entity.workspace;



@Deprecated
//@Entity
public class TaskTimelineScores /*extends Base*/ {
//	private static final long serialVersionUID = 5071196167508739559L;
//
//	public TaskTimelineScores(String taskId, String taskTimelineId, String loginUserId, EvaluateType evaluateType) {
//		this.setTaskId(taskId);
//		this.setTaskTimelineId(taskTimelineId);
//		this.setCreator(loginUserId);
//		this.setEvaluateType(evaluateType);
//	}
//	
//	@Getter @Setter
//	private String taskId;
//	@Getter @Setter
//	private String taskTimelineId;
//	@Getter @Setter
//	private EvaluateType evaluateType;
//	
//	public String getTaskTimelineScoreId() {
//		return super.getKeyStr();
//	}
//	public void setTaskTimelineScoreId(String taskTimelineScoreId) {
//		super.setKeyStr(taskTimelineScoreId);
//	}
}
