package net.forecs.coconut.entity.workspace;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.EditPermission;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;

@Schema(name="Tasks"
	, description="태스크"
	, pkConstraint="CONSTRAINT pk_taskId PRIMARY KEY (taskId)"
	, fkConstraints="CONSTRAINT fk_boardId FOREIGN KEY (boardId) REFERENCES Boards(boardId)"
	, references="Boards")
@Entity
public class Tasks extends Common {
	private static final long serialVersionUID = -4068794218703867052L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String boardId;
	
	@Getter
	@Deprecated
	private String tasklistId;
	@Deprecated
	public void setTasklistId(String tasklistId) {
		if (StringUtils.isNotBlank(tasklistId)) {
			taskStage = KeyFactory.stringToKey(tasklistId).getName();
		}
		this.tasklistId = tasklistId;
	}

	@Column(description="위키", type="clob", index=true)
	private Text wiki;
	public void setWiki(Text wiki) {
		if ((wiki == null) || (wiki.getValue() == null)) wiki = new Text("");
		this.wiki = wiki;
	}
	public Text getWiki() {
		if ((wiki == null) || (wiki.getValue() == null)) wiki = new Text("");
		return wiki;
	}

	@Column(description="시작일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date startDate;
	
	@Column(description="완료일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date completeDate;
	
	@Column(description="목표일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date dueDate;
	
	@Column(description="우선순위", type="numeric", length=16, index=true)
	@Getter @Setter
	private int priority;
	
	@Column(description="중요도", type="varchar", length=8, index=true)
	@Getter @Setter
	private String importance;
	
	@Column(description="캘린더 표시 여부", type="varchar", length=1, index=true)
	@Getter @Setter
	private String displayInCalendarYN;
	
	@Column(description="위키잠금유저아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String wikiLockUserId;
	
	@Column(description="위키잠금일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date wikiLockDate;
	
	@Transient
	private List<TaskChecklists> checklists;
	public void setChecklists(List<TaskChecklists> checklists) {
		if (checklists == null) checklists = new ArrayList<TaskChecklists>();
		this.checklists = checklists;
	}
	public List<TaskChecklists> getChecklists() {
		if (checklists == null) checklists = new ArrayList<TaskChecklists>();
		return checklists;
	}

	@Deprecated
	@Transient
	private List<TaskComments> comments;
	@Deprecated
	public void setComments(List<TaskComments> comments) {
		if (comments == null) comments = new ArrayList<TaskComments>();
		this.comments = comments;
	}
	@Deprecated
	public List<TaskComments> getComments() {
		if (comments == null) comments = new ArrayList<TaskComments>();
		return comments;
	}

	@Transient
	private List<TaskLabels> labels;
	public void setLabels(List<TaskLabels> labels) {
		if (labels == null) labels = new ArrayList<TaskLabels>();
		this.labels = labels;
	}
	public List<TaskLabels> getLabels() {
		if (labels == null) labels = new ArrayList<TaskLabels>();
		return labels;
	}

	@Transient
	private List<Users> members;
	public void setMembers(List<Users> members) {
		if (members == null) members = new ArrayList<Users>();
		this.members = members;
	}
	public List<Users> getMembers() {
		if (members == null) members = new ArrayList<Users>();
		return members;
	}

	@Transient
	private List<Attachments> attachments;
	public void setAttachments(List<Attachments> attachments) {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		this.attachments = attachments;
	}
	public List<Attachments> getAttachments() {
		if (attachments == null) attachments = new ArrayList<Attachments>();
		return attachments;
	}
	
	@Transient
	private List<String> memberIds;
	public void setMemberIds(List<String> memberIds) {
		if (memberIds == null) memberIds = new ArrayList<String>();
		this.memberIds = memberIds;
	}
	public List<String> getMemberIds() {
		if (memberIds == null) memberIds = new ArrayList<String>();
		return memberIds;
	}

	@Transient
	@Getter @Setter
	private Events event;
	
	@Column(description="상세내용편집권한(OWNER/MEMBER)", type="varchar", length=8, index=true, defaultValue="OWNER")
	@Getter @Setter
	private EditPermission editDetailPermission = EditPermission.OWNER;
	
	@Column(description="체크리스트편집권한(OWNER/MEMBER)", type="varchar", length=8, index=true, defaultValue="OWNER")
	@Getter @Setter
	private EditPermission editChecklistPermission = EditPermission.OWNER;
	
	@Column(description="태스크 공개 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Setter
	private String closeYN = N;
	
	public String getCloseYN() {
		if (StringUtils.isBlank(closeYN)) { return N; }
		return closeYN;
	}
	
	@Column(description="태스크 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskId() {
		return super.getKeyStr();
	}

	public void setTaskId(String taskId) {
		super.setKeyStr(taskId);
	}
	
	@Column(description="태스크 진행 단계", type="varchar", length=16, index=true)
	@Setter
	private String taskStage;
	public String getTaskStage() {
		if (taskStage == null && StringUtils.isNotEmpty(tasklistId)) {
			taskStage = KeyFactory.stringToKey(tasklistId).getName();
		}
		return taskStage;
	}
	
	@Transient
	@Getter @Setter
	private Stages stage;
	
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private List<String> memberRequests;
	public void setMemberRequests(List<String> memberRequests) {
		if (memberRequests == null) memberRequests = new ArrayList<String>();
		this.memberRequests = memberRequests;
	}
	public List<String> getMemberRequests() {
		if (memberRequests == null) memberRequests = new ArrayList<String>();
		return memberRequests;
	}
	
	@Transient
	private List<Users> requestMembers;
	public void setRequestMembers(List<Users> requestMembers) {
		if (requestMembers == null) requestMembers = new ArrayList<Users>();
		this.requestMembers = requestMembers;
	}
	public List<Users> getRequestMembers() {
		if (requestMembers == null) requestMembers = new ArrayList<Users>();
		return requestMembers;
	}
}
