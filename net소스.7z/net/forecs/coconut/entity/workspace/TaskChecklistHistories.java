package net.forecs.coconut.entity.workspace;

import java.util.ArrayList;
import java.util.List;

import net.forecs.coconut.common.Logger;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.datastore.Text;

@Schema(name="TaskChecklistHistories"
	, description="체크리스트 히스토리"
	, pkConstraint="CONSTRAINT pk_taskChecklistHistoryId PRIMARY KEY (taskChecklistHistoryId)"
	, fkConstraints="CONSTRAINT fk_taskChecklistId FOREIGN KEY (taskChecklistId) REFERENCES TaskChecklists(taskChecklistId)"
	, references="TaskChecklists")
@Entity
public class TaskChecklistHistories extends Common {
	private static final Logger LOG = Logger.getLogger(TaskChecklistHistories.class.getName());
	private static final long serialVersionUID = 3768473984745896474L;
	
	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="체크리스트 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String checklistId;
	@Getter @Setter
	private ActivityType activityType;
	
	public TaskChecklistHistories(ActivityType activityType, TaskChecklists taskChecklist, List<TaskChecklists> checklists, String title, String loginUserId) {
		//this.version = version;
		this.activityType = activityType;
		this.domainId = taskChecklist.getDomainId();
		this.boardId = taskChecklist.getBoardId();
		this.taskId = taskChecklist.getTaskId();
		this.checklistId = taskChecklist.getTaskChecklistId();
		this.setTaskChecklists(checklists);
		this.setTitle(title);
		this.setCreator(loginUserId);
	}

	@Column(description="체크리스트 히스토리 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskChecklistHistoryId() {
		return super.getKeyStr();
	}

	public void setTaskChecklistHistoryId(String taskChecklistHitoryId) {
		super.setKeyStr(taskChecklistHitoryId);
	}
	
	public void setTaskChecklists(List<TaskChecklists> checklists) {
		if (checklists == null || checklists.size() == 0) {
			return;
		}
		
		try {
			ObjectMapper om = new ObjectMapper();
			Text description = new Text(om.writeValueAsString(checklists));
			
			this.setDescription(description);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}
	
	public List<TaskChecklists> getTaskChecklists() {
		List<TaskChecklists> checklists = null;
		
		try {
			if (this.getDescription() != null && this.getDescription().getValue() != null) {
				
				ObjectMapper om = new ObjectMapper();
				checklists = om.readValue(this.getDescription().getValue(), new TypeReference<ArrayList<TaskChecklists>>(){});
				for (TaskChecklists checklist : checklists) {
					checklist.setBoardId(this.boardId);		// Task보드를 이동시 대비하기 위해
				}
			}
		} catch (Exception  ex) {}
		return checklists;
	}
}
