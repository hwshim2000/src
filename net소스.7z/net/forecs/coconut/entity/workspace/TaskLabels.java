package net.forecs.coconut.entity.workspace;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="TaskLabels"
	, description="태스크 레이블"
	, pkConstraint="CONSTRAINT pk_taskLabelId PRIMARY KEY (taskLabelId)"
	, fkConstraints="CONSTRAINT fk_boardId FOREIGN KEY (boardId) REFERENCES Boards(boardId)"
	, references="Boards")
@Entity
public class TaskLabels extends Base {
	private static final long serialVersionUID = 8086645714189840782L;

	@Column(description="보드 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="레이블 색상", type="varchar", length=8, index=true)
	@Getter @Setter
	private String color;
	
	@Column(description="레이블 이름", type="varchar", length=32, index=true)
	@Getter @Setter
	private String label;

	@Column(description="레이블 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskLabelId() {
		return super.getKeyStr();
	}
	
	public void setTaskLabelId(String taskLabelId) {
		super.setKeyStr(taskLabelId);
	}
}
