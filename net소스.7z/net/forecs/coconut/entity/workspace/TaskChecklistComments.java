package net.forecs.coconut.entity.workspace;



@Deprecated
//@Entity
public class TaskChecklistComments /*extends Common*/ {
//	private static final long serialVersionUID = 3350941692067204960L;
//
//	@Getter @Setter
//	private String domainId;
//	@Getter @Setter
//	private String boardId;
//	@Getter @Setter
//	private String taskId;
//	@Getter @Setter
//	private long familyId;
//	@Getter @Setter
//	private long parentId;
//	@Getter @Setter
//	private int depth;
//	@Getter @Setter
//	private int indent;
//	
//	@Transient
//	@Getter @Setter
//	private Users user;
//	
//	
//	public String getTaskChecklistCommentId() {
//		return super.getKeyStr();
//	}
//	public void setTaskChecklistCommentId(String taskChecklistCommentId) {
//		super.setKeyStr(taskChecklistCommentId);
//	}
}
