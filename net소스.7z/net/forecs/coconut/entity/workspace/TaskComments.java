package net.forecs.coconut.entity.workspace;



@Deprecated
//@Entity
public class TaskComments /*extends Common*/ {
//	private static final long serialVersionUID = -5366142536615819412L;
//
//	@Getter @Setter
//	private String domainId;
//	@Getter @Setter
//	private String boardId;
//	@Getter @Setter
//	private String taskId;
//	@Getter @Setter
//	private String guestYN;
//	@Getter @Setter
//	private long familyId = 0;
//	@Getter @Setter
//	private long parentId = 0;
//	@Getter @Setter
//	private int depth = 0;
//	@Getter @Setter
//	private int indent = 0;
//	@Transient
//	@Getter @Setter
//	private Users user;
//	
//	public String getTaskCommentId() {
//		return super.getKeyStr();
//	}
//	public void setTaskCommentId(String taskCommentId) {
//		super.setKeyStr(taskCommentId);
//	}
}
