package net.forecs.coconut.entity.workspace;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.google.appengine.api.datastore.Text;

@Schema(name="TaskHistories"
, description="태스크 이력"
, pkConstraint="CONSTRAINT pk_taskHistoryId PRIMARY KEY (taskHistoryId)"
, fkConstraints="CONSTRAINT fk_taskId FOREIGN KEY (taskId) REFERENCES Tasks(taskId)"
, references="Tasks")
@Entity
public class TaskHistories extends Common {
	private static final long serialVersionUID = -8366795218589768351L;

	@Column(description="태스크 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="태스크 위키", type="clob", index=true)
	private Text wiki;
	public void setWiki(Text wiki) {
		if ((wiki == null) || (wiki.getValue() == null)) wiki = new Text("");
		this.wiki = wiki;
	}
	public Text getWiki() {
		if ((wiki == null) || (wiki.getValue() == null)) wiki = new Text("");
		return wiki;
	}

	public TaskHistories(String taskId, String title, String loginUserId, Text description) {
		this.taskId = taskId;
		super.setTitle(title);
		super.setCreator(loginUserId);
		super.setDescription(description);
	}
	
	@Column(description="태스크 이력 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskHistoryId() {
		return super.getKeyStr();
	}
	public void setTaskHistoryId(String taskHistoryId) {
		super.setKeyStr(taskHistoryId);
	}
}
