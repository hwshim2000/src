package net.forecs.coconut.entity.workspace;

import java.util.Date;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="TaskChecklists"
, description="태스크 체크리스트"
	, pkConstraint="CONSTRAINT pk_taskChecklistId PRIMARY KEY (taskChecklistId)"
	, fkConstraints="CONSTRAINT fk_taskId FOREIGN KEY (taskId) REFERENCES Tasks(taskId)"
	, references="Tasks")
@Entity
public class TaskChecklists extends Common {
	private static final long serialVersionUID = -615394688007374805L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="체크여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String checkYN = N;
	
	@Column(description="체크리스트 순서", type="numeric", length=16, index=true)
	@Getter @Setter
	private Integer ordernum;
	
	@Column(description="체크리스트 담당자", type="varchar", length=32, index=true)
	@Getter @Setter
	private String assignee;
	
	@Column(description="체크리스트 목표일", type="datetime", length=32, index=true, notnull=true)
	@Getter @Setter
	private Date dueDate;
	
	@Column(description="체크리스트 진행률", type="numeric", length=16, index=true)
	@Getter @Setter
	private int progress;
	
	@Column(description="체크리스트 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTaskChecklistId() {
		return super.getKeyStr();
	}
	public void setTaskChecklistId(String taskChecklistId) {
		super.setKeyStr(taskChecklistId);
	}
}
