/**
 * @desc FREQUENCY VS INTERVAL<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |          |SECONDLY|MINUTELY|HOURLY |DAILY  |WEEKLY|MONTHLY|YEARLY|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYMONTH   |Limit   |Limit   |Limit  |Limit  |Limit |Limit  |Expand|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYWEEKNO  |N/A     |N/A     |N/A    |N/A    |N/A   |N/A    |Expand|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYYEARDAY |Limit   |Limit   |Limit  |N/A    |N/A   |N/A    |Expand|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYMONTHDAY|Limit   |Limit   |Limit  |Limit  |N/A   |Expand |Expand|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYDAY     |Limit   |Limit   |Limit  |Limit  |Expand|Note 1 |Note 2|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYHOUR    |Limit   |Limit   |Limit  |Expand |Expand|Expand |Expand|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYMINUTE  |Limit   |Limit   |Expand |Expand |Expand|Expand |Expand|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYSECOND  |Limit   |Expand  |Expand |Expand |Expand|Expand |Expand|<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
   |BYSETPOS  |Limit   |Limit   |Limit  |Limit  |Limit |Limit  |Limit |<br>
   +----------+--------+--------+-------+-------+------+-------+------+<br>
 * @author hwshim
 *
 */

package net.forecs.coconut.entity.calendar;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.code.StartDayOfWeek;
import net.forecs.coconut.common.code.WeekDayType;


@Embeddable
public class Recurrence implements Serializable {
	private static final long serialVersionUID = -1052015202268303760L;

	/**
	 * @desc 반복 주기. writable<br>
	 * @values [DAILY|WEEKLY|MONTHLY|YEARLY]
	 */
	@Getter @Setter
	private Frequency frequency = Frequency.DAILY;
	
	/**
	 * @desc 마지막 반복 instance의 일시. Optional. writable<br>
	 * @values yyyyMMdd'T'HHmmss
	 */
	@Getter @Setter
	private Date until;
	
	/**
	 * count값이 0이면 Unlimite와 동일하다.
	 * @desc 반복 횟수. Optional. writable<br>
	 * @values INTEGER
	 */
	@Getter @Setter
	private Integer count;
	
	/**
	 * @desc 반복 간격. Optional. (RFC5545의 “INTERVAL”) writable<br>
	 * @values INTEGER값<br>
	 *  frequency에 종속적임<br>
	 * @ex interval = 1일경우, frequency가 DAILY면 매일, WEEKLY면 매주라는 의미
     */
	@Getter @Setter
	private Integer interval;

	/** 반복 제외 일자 목록. Optional. writable */
	private List<Date> exceptionDates;
	public void setExceptionDates(List<Date> exceptionDates) {
		if (exceptionDates == null) exceptionDates = new ArrayList<Date>();
		this.exceptionDates = exceptionDates;
	}
	public List<Date> getExceptionDates() {
		if (exceptionDates == null) exceptionDates = new ArrayList<Date>();
		return exceptionDates;
	}

	private List<Integer> bySeconds;
	public void setBySeconds(List<Integer> bySeconds) {
		if (bySeconds == null) bySeconds = new ArrayList<Integer>();
		this.bySeconds = bySeconds;
	}
	public List<Integer> getBySeconds() {
		if (bySeconds == null) bySeconds = new ArrayList<Integer>();
		return bySeconds;
	}

	private List<Integer> byMinutes;
	public void setByMinutes(List<Integer> byMinutes) {
		if (byMinutes == null) byMinutes = new ArrayList<Integer>();
		this.byMinutes = byMinutes;
	}
	public List<Integer> getByMinutes() {
		if (byMinutes == null) byMinutes = new ArrayList<Integer>();
		return byMinutes;
	}

	private List<Integer> byHours;
	public void setByHours(List<Integer> byHours) {
		if (byHours == null) byHours = new ArrayList<Integer>();
		this.byHours = byHours;
	}
	public List<Integer> getByHours() {
		if (byHours == null) byHours = new ArrayList<Integer>();
		return byHours;
	}

	/** 
	 * @desc 반복 대상 주중 요일 목록. Optional. writable<br>
	 * @values [+/-][1-53][SU|MO|TU|WE|TH|FR|SA]
	 */
	private List<WeekDayType> byDays;
	public void setByDays(List<WeekDayType> byDays) {
		if (byDays == null) byDays = new ArrayList<WeekDayType>();
		this.byDays = byDays;
	}
	public List<WeekDayType> getByDays() {
		if (byDays == null) byDays = new ArrayList<WeekDayType>();
		return byDays;
	}

	/**
	 * @desc 반복 대상 월중 일 목록. Optional. writable<br>
	 * @values [+|-][1-31]
	 */
	private List<Integer> byMonthDays;
	public void setByMonthDays(List<Integer> byMonthDays) {
		if (byMonthDays == null) byMonthDays = new ArrayList<Integer>();
		this.byMonthDays = byMonthDays;
	}
	public List<Integer> getByMonthDays() {
		if (byMonthDays == null) byMonthDays = new ArrayList<Integer>();
		return byMonthDays;
	}

	/**
	 * @desc 반복 대상 연중 주 목록. Optional. writable<br>
	 * @values [+|-][1-53]
	 */
	private List<Integer> byWeekNumbers;
	public void setByWeekNumbers(List<Integer> byWeekNumbers) {
		if (byWeekNumbers == null) byWeekNumbers = new ArrayList<Integer>();
		this.byWeekNumbers = byWeekNumbers;
	}
	public List<Integer> getByWeekNumbers() {
		if (byWeekNumbers == null) byWeekNumbers = new ArrayList<Integer>();
		return byWeekNumbers;
	}

	/**
	 * @desc 반복 대상 연중 월 목록. Optional. writable<br>
	 * @values [1-12]  
	 */
	private List<Integer> byMonths;
	public void setByMonths(List<Integer> byMonths) {
		if (byMonths == null) byMonths = new ArrayList<Integer>();
		this.byMonths = byMonths;
	}
	public List<Integer> getByMonths() {
		if (byMonths == null) byMonths = new ArrayList<Integer>();
		return byMonths;
	}

	/**
	 * @desc 반복 대상 연중 일 목록. Optional. writable<br>
	 * @values [+|-][1-366]
	 */
	private List<Integer> byYearDays;
	public void setByYearDays(List<Integer> byYearDays) {
		if (byYearDays == null) byYearDays = new ArrayList<Integer>();
		this.byYearDays = byYearDays;
	}
	public List<Integer> getByYearDays() {
		if (byYearDays == null) byYearDays = new ArrayList<Integer>();
		return byYearDays;
	}

	/**
	 * @desc 반복 단위 내의 대상 위치 목록. Optional. writable<br>
	 * @values [+|-][1-31]
	 */
	private List<Integer> bySetPositions;
	public void setBySetPositions(List<Integer> bySetPositions) {
		if (bySetPositions == null) bySetPositions = new ArrayList<Integer>();
		this.bySetPositions = bySetPositions;
	}
	public List<Integer> getBySetPositions() {
		if (bySetPositions == null) bySetPositions = new ArrayList<Integer>();
		return bySetPositions;
	}

	/**
	 * @desc 주중 근무 시작요일. Optional. default=”MO”. writable<br>
	 * @values [SU|MO|TU|WE|TH|FR|SA]
	 */
	@Getter @Setter
	private StartDayOfWeek startDayOfWeek = StartDayOfWeek.MO;
}
