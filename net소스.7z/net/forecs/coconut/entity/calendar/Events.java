package net.forecs.coconut.entity.calendar;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.AlarmTriggerType;
import net.forecs.coconut.common.code.AnniversaryType;
import net.forecs.coconut.common.code.CalendarVisibility;
import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.code.SolarType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="Events"
	, description="이벤트"
	, pkConstraint="CONSTRAINT pk_eventId PRIMARY KEY (eventId)"
	, references={"Domains","Boards","Tasks"})
@Entity
public class Events extends Common {
	private static final long serialVersionUID = 7070630585908238754L;
	
	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="이벤트 반복 아이디", type="varchar", length=32, index=true)
	@Transient
	@Getter @Setter
	private Long recurrenceId;
	
	@Column(description="이벤트 반복 일시", type="datetime", length=32, index=true)
	@Transient
	@Getter @Setter
	private Date recurrenceDate;
	
	@Column(description="이벤트 그룹 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String eventGroupId;
	
	@Column(description="이벤트 타입(TASK/APPOINTMENT/ANNIVERSARY/PRIVATE_ANNIVERSARY/SYSTEM_HOLIDAY/HOLIDAY/PRIVATE)", type="varchar", length=16, index=true, defaultValue="APPOINTMENT")
	@Getter @Setter
	private EventType eventType = EventType.APPOINTMENT;
	
	@Column(description="기념일 타입(BIRTH, WEDDING)", type="varchar", length=16, index=true)
	@Getter @Setter
	private AnniversaryType anniversaryType;
	
	@Column(description="이벤트 시작일", type="datetime", length=32, index=true, notnull=true)
	@Getter @Setter
	private Date startDate;
	
	@Column(description="이벤트 종료일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date endDate;
	
	@Column(description="양력/음력(SOLAR/LUNAR)", type="varchar", length=16, index=true, defaultValue="SOLAR")
	@Getter @Setter
	private SolarType solarType = SolarType.SOLAR;
	
	@Column(description="이벤트 하루 종일 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String dayOffYN = N;
	
	@Column(description="이벤트 수정 여부", type="varchar", length=1, index=true, defaultValue="Y")
	@Getter @Setter
	private String editableYN = Y;
	
	@Column(description="이벤트 음력 시작일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date lunarStartDate;
	
	@Column(description="이벤트 음력 종료일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date lunarEndDate;
	
	@Column(description="이벤트 기준 시작 오프셋", type="numeric", length=16, index=true)
	@Getter @Setter
	private int startDateOffset;
	
	@Column(description="이벤트 기준 종료 오프셋", type="numeric", length=16, index=true)
	@Getter @Setter
	private int endDateOffset;
	
	@Column(description="윤달 관련 설정 값", type="numeric", length=16, index=true)
	@Getter @Setter
	private int leap;
	
	@Transient
	@Getter @Setter
	private Date lunarRecurrenceDate;
	@Embedded
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private Recurrence recurrence;
	
	@Column(description="알람 트리거 단위 타입(MINUTE, HOUR, DAY, WEEK)", type="varchar", length=8, index=true, defaultValue="MINUTE")
	@Getter @Setter
	private AlarmTriggerType alarmTriggerType = AlarmTriggerType.MINUTE;
	
	@Column(description="알람 트리거 값", type="numeric", length=16, index=true, defaultValue="10")
	@Getter @Setter
	private Integer alarmTriggerValue = 10;
	@Transient
	@Getter @Setter
	private Date alarmDateTime;
	
	@Column(description="이벤트 발생 장소", type="varchar", length=1024, index=true)
	@Getter @Setter
	private String location;
	
	@Column(description="종일 이벤트 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String allDayYN = N;
	
	@Column(description="반복여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String recurrenceYN = N;
	
	@Column(description="알람 발생 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String alarmYN = N;
	
	@Column(description="이벤트 활성 여부", type="varchar", length=1, index=true, defaultValue="Y")
	@Getter @Setter
	private String activeYN = Y;
	
	/** ICalendar(iCal4j) or GoogleCalendar ICalUid 를 위한 값 */
	@Column(description="캘린더 고유값(ICalendar(iCal4j) or GoogleCalendar ICalUid 를 위한 값)", type="varchar", length=32, index=true)
	@Getter @Setter
	private String uid;
	
	/** ICalendar(iCal4j) or GoogleCalendar SEQUENCE 를 위한 값 */
	@Column(description="ICalendar(iCal4j) or GoogleCalendar SEQUENCE 를 위한 값", type="numeric", length=16, index=true)
	@Getter @Setter
	private Integer sequence = 0;
	
	@Column(description="Google Calendar의  htmlLink 값을 위함", type="varchar", length=1024, index=true)
	/** Google Calendar의  htmlLink 값을 위함 */
	@Getter @Setter
	private String htmlLink;
	
	/** Google의 Visibility 값은 공개/비공개 설정이며, iCal에서는 CLASS Property 값의 형태로 나타난다. */ 
	@Column(description="공개범위(default/private/public/confidential):Google의 Visibility 값은 공개/비공개 설정이며, iCal에서는 CLASS Property 값의 형태로 나타난다.", type="varchar", length=16, index=true, defaultValue="default")
	@Getter @Setter
	private String visibility = CalendarVisibility.DEFAULT;
	
	@Column(description="태스크 큐 이름(이벤트 발생을 위한 등록 이름)", type="varchar", length=32, index=true, unique=true)
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private String taskName;
	
	@Column(description="이벤트 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getEventId() {
		return super.getKeyStr();
	}

	public void setEventId(String eventId) {
		super.setKeyStr(eventId);
	}
}
