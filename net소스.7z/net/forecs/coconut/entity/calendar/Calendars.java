package net.forecs.coconut.entity.calendar;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.CalendarAccessRole;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.google.appengine.api.datastore.Text;

@Schema(name="Calendars"
	, description="캘린더"
	, pkConstraint="CONSTRAINT pk_calendarId PRIMARY KEY (calendarId)"
	, fkConstraints="CONSTRAINT fk_userId FOREIGN KEY (userId) REFERENCES Users(userId)"
	, references = "Users" )
@Entity
public class Calendars extends Common {

	private static final long serialVersionUID = 6109806568298850710L;
	
	/** 실질적인 calendarId */
	@Column(description="캘린더 고유 아이디", type="varchar", length=32, index=true, unique=true)
	@Getter @Setter
	private String id;
	
	@Column(description="캘린더 소유자 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String userId;
	
	@Column(description="사용자의 타임존", type="varchar", length=8, index=true)
	@Getter @Setter
	private String timeZone;
	
	@Column(description="캘린더 접근 권한(owner/reader/freeBusyReader/writer)", type="varchar", length=16, index=true)
	@Getter @Setter
	private CalendarAccessRole accessRole;
	
	@Column(description="사용자의 기본 캘린더 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private Boolean primary;
	
	@Column(description="캘린더의 이벤트가 적용된 호스트 도메인(예:google)", type="varchar", length=32, index=true)
	@Getter @Setter
	private String hostDomain;

	@Column(description="캘린더 이벤트", type="clob")
	private Text events;
	public void setEvents(Text events) {
		if ((events == null) || (events.getValue() == null)) events = new Text("");
		this.events = events;
	}
	public Text getEvents() {
		if ((events == null) || (events.getValue() == null)) events = new Text("");
		return events;
	}

	@Column(description="이벤트 장소", type="varchar", length=128, index=true)
	@Getter @Setter
	private String location;
	
	@Column(description="캘린더 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getCalendarId() {
		return super.getKeyStr();
	}

	public void setCalendarId(String calendarId) {
		super.setKeyStr(calendarId);
	}
}
