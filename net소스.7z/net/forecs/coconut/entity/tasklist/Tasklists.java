package net.forecs.coconut.entity.tasklist;

import java.util.Date;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.TaskStage;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="Tasklists"
	, description="태스크 스테이지 목록"
	, pkConstraint="CONSTRAINT pk_tasklistId PRIMARY KEY (tasklistId)"
	, fkConstraints="CONSTRAINT fk_boardId FOREIGN KEY (boardId) REFERENCES Boards(boardId)"
	, references="Boards")
@Entity
public class Tasklists extends Base {
	private static final long serialVersionUID = 2517762220138721883L;
	
	public Tasklists(String boardId, TaskStage stage, String userId) {
		this.boardId = boardId;
		this.stage = stage;
		this.setCreator(userId);
		super.setKey(KeyUtil.createTasklistKey(boardId, stage.toString()));
	}

	@Override
	public Date getCreated() { return null; }
	@Override
	public String getDeleteYN() { return null; }
	@Override
	public String getObjectId() { return null; }
	@Override
	public String getCreator() { return null; }
	@Override
	public String getOwner() { return null; }
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="단계(Ideation/Incubation/Reference/Preparation/OnGoing/Pending/Drop/Complete/Trash)", type="varchar", length=16, index=true)
	@Getter @Setter
	private TaskStage stage;
		
	@Column(description="태스크 단계 목록 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTasklistId() {
		return super.getKeyStr();
	}

	public void setTasklistId(String tasklistId) {
		super.setKeyStr(tasklistId);
	}
}
