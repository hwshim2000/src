package net.forecs.coconut.entity.domain;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.DomainsLogType;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

@Schema(name="DomainsLog"
	, description="도메인 로그"
	, pkConstraint="CONSTRAINT pk_domainLogId PRIMARY KEY (domainLogId)"
	, fkConstraints="CONSTRAINT fk_domainId FOREIGN KEY (domainId) REFERENCES Domains(domainId)"
	, references="Domains")
@Entity
public class DomainsLog extends Common {
	private static final long serialVersionUID = 3376411376073006045L;

	public DomainsLog(Domains domain, DomainsLogType domainsLogType) {
		this(domain, domainsLogType, null);
	}
	
	public DomainsLog(Domains domain, DomainsLogType domainsLogType, String couponCode) {
//		setKey(KeyUtil.createDomainsLogKey());
		setDomainId(domain.getDomainId());
		setDomainName(domain.getDomainName());
		setBlockReason(domain.getBlockReason());
		setBlockType(domain.getBlockType());
		setCaseInsensitive(domain.isCaseInsensitive());
		setExpirationDate(domain.getExpirationDate());
		setOwner(domain.getOwner());
		setStorageQuota(domain.getStorageQuota());
		setUserQuota(domain.getUserQuota());
		
		setServiceType(domain.getServiceType());
		setCouponCode(couponCode);
		setLogType(domainsLogType);
		setBoardQuota(domain.getBoardQuota());
		setCreator(CommonProperty.SYSTEM_USER_ID);	// admin
//		setPaymentStart(domain.getPaymentStart());
		setPaymentEnd(domain.getPaymentEnd());
		setLabel(domain.getLabel());
		setNote(domain.getNote());
		setCreateBoardAuth(domain.getCreateBoardAuth());
//		setTerm(domain.getTerm());
//		setPeriod(domain.getPeriod());
		//setGroupQuota(domain.getGroupQuota());
		
		//setTaskQuota(domain.getTaskQuota());
		//setSummary(domain.getSummary());
		//setTitle(domain.getTitle());
		//setDescription(domain.getDescription());
	}
	
	@Column(description="도메인 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="쿠폰 코드", type="varchar", length=16)
	@Getter @Setter
	private String couponCode;
	
	@Column(description="도메인 로그 형식(UPDATE_BLOCK/UPDATE_EXPIRATION/UPDATE_QUOTA/UPDATE_CASE/REGIST_COUPON/REVOKE_COUPON/UPDATE_SERVICE_TYPE/APPLY_BILL/CANCEL_BILL/SUBSCRIBE_BILL/UNSUBSCRIBE_BILL)", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private DomainsLogType logType;
	
	@Column(description="도메인명", type="varchar", length=16, index=true, notnull=true, unique=true)
	@Getter @Setter
	private String domainName;
	
	@Column(description="도메인 계약 사용자 수", type="numeric", length=32, index=true)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private Long userQuota;
	
	@Column(description="스토리지 계약 할당량", type="numeric", length=32, index=true)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private Long storageQuota;
	
	@Column(description="보드 계약 생성 수", type="numeric", length=32, index=true)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private Long boardQuota;

	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	@Getter @Setter
	private Long groupQuota;
	@Getter @Setter
	private Long taskQuota;
	*/
	//<-- ===== DOMAIN STATISTICS =====

	@Column(description="계약 서비스 타입(TRIAL/STANDARD)", type="varchar", length=8, defaultValue="STANDARD")
	@Getter @Setter
	private ServiceType serviceType;
	
	@Column(description="도메인 블럭 타입(PASS/BLOCK/AUTO)", type="varchar", length=8, index=true)
	@Getter @Setter
	private BlockType blockType;
	
	@Column(description="블럭 사유", type="varchar", length=4096, index=true)
	@Getter @Setter
	private String blockReason;
	
	@Column(description="만료일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date expirationDate;
	
	@Column(description="도메인 사용자 대소문자 구분 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean caseInsensitive; // user's id case sensitivity
	
//	@Deprecated
//	@Column(description="정기 결재 시작 일시", type="datetime", length=32, index=true)
//	@Getter @Setter
//	private Date paymentStart;
	
	@Column(description="정기 결재 종료 일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date paymentEnd;
	
//	@Deprecated
//	@Column(description="계약 기간", type="numeric", length=8, index=true)
//	@Getter @Setter
//	private Integer term;
	
//	@Deprecated
//	@Column(description="결재 간격", type="numeric", length=8, index=true)
//	@Getter @Setter
//	private Integer period;

	@Column(description="레이블", type="varchar", length=128, index=true)
	@Getter @Setter
	private String label;
	
	@Column(description="노트", type="varchar", length=128, index=true)
	@Getter @Setter
	private String note;
	
//	@Transient
//	@Getter @Setter
//	private Integer ordernum;
	
	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Column(description="GSuite API 서비스 계정", type="varchar", length=128, index=true)
	@Getter @Setter
	private String gsuiteServiceAccount;

	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Column(description="GSuite Customer ID", type="varchar", length=32, index=true)
	@Getter @Setter
	private String gsuiteCustomerID;

	@Column(description="보드 생성 권한", type="varchar", length=16, index=true)
	private Auth createBoardAuth = Auth.MEMBER;
	public Auth getCreateBoardAuth() {
		if (createBoardAuth == null) { createBoardAuth = Auth.MEMBER; }
		return createBoardAuth;
	}
	public void setCreateBoardAuth(Auth createBoardAuth) {
		if (createBoardAuth == null) { createBoardAuth = Auth.MEMBER; }
		this.createBoardAuth = createBoardAuth;
	}
	
	@Column(description="도메인 로그 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	@Transient
	public String getDomainsLogId() {
		return super.getKeyStr();
	}
	public void setDomainsLogId(String logId) {
		super.setKeyStr(logId);
	}
}
