package net.forecs.coconut.entity.domain;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="Stages"
, description="테스크 단계"
, pkConstraint="CONSTRAINT pk_stageId PRIMARY KEY (stageId)")
@Entity
public class Stages extends Common {
	private static final long serialVersionUID = 550662350451259238L;

	@Column(description="보드아이디", type="varchar", length=32, index=true, defaultValue="COMMON")
	@Getter @Setter
	private String boardId = "COMMON";
	
	@Column(description="단계명(변경불가)", type="varchar", length=16, index=true, notnull=true, unique=true)
	@Getter @Setter
	private String taskStage;
	
	@Column(description="단계고유값(변경불가)", type="numeric", length=16, index=true, notnull=true, unique=true)
	@Getter @Setter
	private Integer stageOrdinal;

	@Column(description="정렬순서", type="numeric", length=16, index=true, notnull=true, defaultValue="0")
	@Getter @Setter
	private int ordernum;
	
	@Column(description="색상", type="varchar", length=16, index=true)
	@Getter @Setter
	private String color;
	
	@Column(description="아이콘", type="varchar", length=256, index=true)
	@Getter @Setter
	private String icon;
	
	@Column(description="단계 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getStageId() {
		return super.getKeyStr();
	}
	
	public void setStageId(String stageId) {
		super.setKeyStr(stageId);
	}
	
	public Stages() {}
	public Stages(String title, String taskStage, int stageOrdinal) {
		setKey(KeyUtil.createStageKey(taskStage));
		setTitle(title);
		setTaskStage(taskStage);
		setStageOrdinal(stageOrdinal);
		setOrdernum(stageOrdinal);
	}
}
