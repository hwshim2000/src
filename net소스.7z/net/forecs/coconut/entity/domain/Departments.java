package net.forecs.coconut.entity.domain;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.Dept;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Text;

@Schema(name="Departments"
	, description="조직도"
	, pkConstraint="CONSTRAINT pk_departmentId PRIMARY KEY (departmentId)"
	, fkConstraints="CONSTRAINT fk_memberId FOREIGN KEY (memberId) REFERENCES Users(userId)"
	, references="Users")
//@JsonFilter("departmentFilter")
@Entity
public class Departments extends Common {
	private static final long serialVersionUID = 4344626960665009129L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="상위 조직도 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String parentId;
	
	@Column(description="상위 조직 코드", type="varchar", length=16, index=true)
	@Getter @Setter
	private String parentDeptCode;
	
	@Column(description="조직 코드", type="varchar", length=16, index=true)
	@Getter @Setter
	private String deptCode;
	
	@Column(description="최상위 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private Boolean rootNode;
	
	@Column(description="연락처", type="varchar", length=256, index=true)
	@Getter @Setter
	private String contact;
	
	@Column(description="해당 조직 멤버 아이디", type="varchar", length=32, index=true, foreign=true)
	@Getter @Setter
	private String memberId;
	
	@Transient
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private Users member;
	
	@Column(description="정렬 순서", type="numeric", length=8, index=true)
	@Getter @Setter
	private int ordernum;
	
	@Transient
	@Getter @Setter
	private int depth;
	
	@Getter @Setter
	private String color;
	
	@Getter @Setter
	private String theme;
	
	@Transient
	List<Departments> children;
	public List<Departments> getChildren() {
		if (children == null) { children = new LinkedList<Departments>(); }
		return children;
	}
	public void setChildren(List<Departments> children) {
		if (children == null) { children = new LinkedList<Departments>(); }
		this.children = children;
	}
	
	public void appendChildren(Departments child) {
		if (children == null) { children = new LinkedList<Departments>(); }
		children.add(child);
	}
	

	// ----------------------------------- IGNORE FIELDS
	public Date getCreated() { return super.getCreated(); }
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Date getModified() { return super.getModified(); }
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)	
	public String getDeleteYN() { return super.getDeleteYN(); }
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public String getArchiveYN() { return super.getArchiveYN(); }
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public String getPermanentDeleteYN() { return super.getPermanentDeleteYN(); }
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public String getOwner() { return super.getOwner(); }
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public String getCreator() { return super.getCreator(); }
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public String getObjectId() { return super.getObjectId(); }
	
	//------------------------------------ Organizaation Tree Chart(getOrgChart.js)
	public String getName() {
		return CommonService.getDisplayUserName(member, null);
	}
	public String getMail() {
		return member != null ? member.getEmail() : null;
	}
	public String getPhone() {
		if (member == null) { return null; }
		if (member.getUserProfiles() == null) { return null; }
		if (member.getUserProfiles().getPhone() == null) { return null; }
		return member.getUserProfiles().getPhone().getNumber(); 
	}
	public String getAddress() {
		if (member == null) { return null; }
		if (member.getUserProfiles() == null) { return null; }
		if (member.getUserProfiles().getAddress() == null) { return null; }
		return member.getUserProfiles().getAddress().getAddress();
	}
	
	//------------------------------------ Organizaation Tree Chart(Treant.js)
	public String getId() {
		return getDepartmentId();
	}
	public String getParent() {
		return getParentId();
	}
	
	public boolean isStackChildren() {
		if (!Boolean.TRUE.equals(getRootNode()) && getChildren().size() > 1) { return true; }
		return false;
	}
	
	public String getImage() {
		if (member == null) { return null; }
		return member.getPictureURL();
	}
	
	@ApiResourceProperty(name = "text")
	public Map<String, Object> getContactMap() {
		Map<String, Object> contactsMap = new HashMap<String, Object>();
		
    	if (member != null) {
    		contactsMap.put("name", CommonService.getDisplayUserName(member));
    		if (member.getUserProfiles().getPhone() != null) {
    			contactsMap.put("contact", member.getUserProfiles().getPhone().getNumber());
    		} else {
    			Map<String, String> contactMap = new HashMap<String, String>();
    			contactMap.put("val",  member.getEmail());
    			contactMap.put("href",  "mailto:"+member.getEmail());
    			contactsMap.put("contact", contactMap);
    		}
    	} else if (StringUtils.isNotBlank(contact)) {
    		contactsMap.put("contact", contact);
    	}
    	if (StringUtils.isNotBlank(getTitle())) { contactsMap.put("title", getTitle()); }
    	if (getDescription() != null && StringUtils.isNotBlank(getDescription().getValue())) {
    		contactsMap.put("desc", getDescription().getValue());
    	}
    	return contactsMap;
	}
	
//	@Transient
//	@Getter @Setter
//	private List<Users> members;
	
	public Departments() {}
	public Departments(Dept dept) {
		this(dept.getTitle(), dept.getDescription(), dept.getContact(), dept.getParentDeptCode(), dept.getDeptCode(), dept.getId());
	}
	public Departments(String title, String description, String contact, String parentDeptCode, String deptCode, String id) {
		setTitle(title);
		if (StringUtils.isNotBlank(description)) { setDescription(new Text(description)); }
		setContact(contact);
		setParentDeptCode(parentDeptCode);
		setDeptCode(deptCode);
		if (StringUtils.isNotBlank(id)) {
			Users user = new Users();
			user.setId(id);
			setMember(user);
		}
	}
	
	@Column(description="조직 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getDepartmentId() {
		return super.getKeyStr();
	}
	public void setDepartmentId(String departmentId) {
		super.setKeyStr(departmentId);
	}
}
