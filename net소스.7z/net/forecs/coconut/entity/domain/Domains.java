package net.forecs.coconut.entity.domain;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.Auth;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.billing.BlockType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.endpoint.billing.BillingService;
import net.forecs.coconut.entity.common.Common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

@Schema(name="Domains"
	, description="도메인"
	, pkConstraint="CONSTRAINT pk_domainId PRIMARY KEY (domainId)")
@Entity
public class Domains extends Common {
	private static final long serialVersionUID = 8677998213105604020L;

	public Domains() { }
	public Domains(Domains domain) {
		setTitle(domain.getTitle());
		domainName = domain.getDomainName();
		blockType = domain.getBlockType();
		caseInsensitive = domain.isCaseInsensitive();
		serviceType = domain.getServiceType();
		userQuota = domain.getUserQuota();
		storageQuota = domain.getStorageQuota();
		boardQuota = domain.getBoardQuota();
		expirationDate = domain.getExpirationDate();
	}
	
	@Column(description="도메인명", type="varchar", length=16, index=true, notnull=true, unique=true)
	@Getter @Setter
	private String domainName;
	
	@Column(description="도메인 계약 사용자 수", type="numeric", length=32, index=true)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private Long userQuota;
	
	@Column(description="스토리지 계약 할당량", type="numeric", length=32, index=true)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private Long storageQuota;
	
	@Column(description="보드 계약 생성 수", type="numeric", length=32, index=true)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	private Long boardQuota;

	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	@Getter @Setter
	private Long groupQuota;
	@Getter @Setter
	private Long taskQuota;
	*/
	//<-- ===== DOMAIN STATISTICS =====

	@Column(description="도메인 블럭 타입(PASS/BLOCK/AUTO)", type="varchar", length=8, index=true)
	@Getter @Setter
	private BlockType blockType;
	
	@Column(description="블럭 사유", type="varchar", length=4096, index=true)
	@Getter @Setter
	private String blockReason;
	
	@Column(description="만료일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date expirationDate;
	
	@Column(description="도메인 사용자 대소문자 구분 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean caseInsensitive; // user's id case sensitivity
	
	
	@Column(description="계약 서비스 타입(TRIAL/STANDARD/DEFERRED)", type="varchar", length=8, defaultValue="STANDARD")
	@Setter
	private ServiceType serviceType = ServiceType.TRIAL;
	public ServiceType getServiceType() {
		if (serviceType == null) { return ServiceType.STANDARD; }
		return serviceType;
	}
	
	@Column(description="계약 서비스 등급", type="varchar", length=8)
	@Getter @Setter
	private String serviceGrade = BillingService.DEFAULT_SERVICE_GRADE;
	
//	@JsonIgnore
//	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
//	public ServiceType getStoredServiceType() {
//		return serviceType;
//	}
	
	@Column(description="스토리지 사용 유무", type="bool", length=1, index=true, defaultValue="true")
	@Setter
	private Boolean useStorage = true;
	public Boolean getUseStorage() {
		if (useStorage == null) { return true; }
		return useStorage;
	}

//	@Deprecated
//	@Column(description="결재 시작 일시", type="datetime", length=32, index=true)
//	@Getter @Setter
//	private Date paymentStart;
//	
	// Bills의 PaymentDate가 아닌 ServiceEnd값
	@Column(description="마지막 결재(서비스) 일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date paymentEnd;

//	@Deprecated
//	@Column(description="계약 기간", type="numeric", length=16, index=true)
//	@Getter @Setter
//	private Integer term;
//	
//	@Deprecated
//	@Column(description="결재 간격", type="numeric", length=16, index=true)
//	private Integer period;
//	public Integer getPeriod() {
//		if (period == null || period == 0) { period = 1; }
//		return period;
//	}
//	public void setPeriod(Integer period) {
//		if (period == null || period == 0) { period = 1; }
//		this.period = period;
//	}

	@Column(description="레이블", type="varchar", length=128, index=true)
	@Getter @Setter
	private String label;
	
	@Column(description="노트", type="varchar", length=128, index=true)
	@Getter @Setter
	private String note;
	
//	@Transient
//	@Getter @Setter
//	private Integer ordernum;
	
	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Column(description="GSuite API 서비스 계정", type="varchar", length=128, index=true)
	@Getter @Setter
	private String gsuiteServiceAccount;

	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Column(description="GSuite Customer ID", type="varchar", length=32, index=true)
	@Getter @Setter
	private String gsuiteCustomerID;

	@Column(description="보드 생성 권한", type="varchar", length=16, index=true)
	private Auth createBoardAuth = Auth.MEMBER;
	public Auth getCreateBoardAuth() {
		if (createBoardAuth == null) { createBoardAuth = Auth.MEMBER; }
		return createBoardAuth;
	}
	public void setCreateBoardAuth(Auth createBoardAuth) {
		if (createBoardAuth == null) { createBoardAuth = Auth.MEMBER; }
		this.createBoardAuth = createBoardAuth;
	}
	
	@Column(description="도메인 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getDomainId() {
		return super.getKeyStr();
	}
	public void setDomainId(String domainId) {
		super.setKeyStr(domainId);
	}
	
	/*
	@SuppressWarnings("unused")
	private static void sort(List<Domains> list) {
		Collections.sort(list, new Comparator<Domains>() {
	        @Override
	        public int compare(Domains first, Domains second) {
				if (first.getOrdernum() == null && second.getOrdernum() == null) {
	        		return 0;
	        	} else if (first.getOrdernum()==null ) {
	        		return 1;
	        	} else if (second.getOrdernum()==null) {
	        		return -1;
	        	}
	        	
	        	if (first.getOrdernum() > second.getOrdernum()) {
	        		return 1;
	        	} else if (first.getOrdernum() < second.getOrdernum()) {
	        		return -1;
	        	} else {
	        		return 0;
	        	}
	        }
	    });
	}
	*/
}
