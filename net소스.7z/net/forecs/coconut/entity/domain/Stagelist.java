package net.forecs.coconut.entity.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class Stagelist {

	@Getter @Setter
	List<Stages> stages;
}
