package net.forecs.coconut.entity.billing;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

import com.googlecode.objectify.annotation.Cache;

@Schema(name="Usage"
	, description="도메인 사용량 정보"
	, pkConstraint="CONSTRAINT pk_usageId PRIMARY KEY (usageId)"
	, fkConstraints="CONSTRAINT fk_domainId FOREIGN KEY (domainId) REFERENCES Domains(domainId)"
	, references="Domains")
@Cache
@Entity
public class Usage extends Base {
	private static final long serialVersionUID = 4462789682876366534L;

	public Usage() {
	}
	public Usage(String domainName, com.google.appengine.api.datastore.Entity entity) {
		this.domainId = KeyUtil.createDomainKeyString(domainName);
		this.domainName = domainName;
		if (entity != null) {
			this.timestamp = (Date)entity.getProperty("timestamp");
			this.bytes = (Long)entity.getProperty("bytes");
			this.count = (Long)entity.getProperty("count");
			this.entityBytes = (Long)entity.getProperty("entity_bytes");
			this.compositeIndexBytes = (Long)entity.getProperty("composite_index_bytes");
			this.compositeIndexCount = (Long)entity.getProperty("composite_index_count");
			this.bulitinIndexBytes = (Long)entity.getProperty("builtin_index_bytes");
			this.bulitinIndexCount = (Long)entity.getProperty("builtin_index_count");
		}
	}
	
	public Usage(Usage usage) {
		setKey(usage.getKey());
		setDomainName(usage.getDomainName());
		setAttachmentBytes(usage.getAttachmentBytes());
		setAttachmentCount(usage.getAttachmentCount());
		setBoardCount(usage.getBoardCount());
		setBulitinIndexBytes(usage.getBulitinIndexBytes());
		setBulitinIndexCount(usage.getBulitinIndexCount());
		setBytes(usage.getBytes());
		setCompositeIndexBytes(usage.getCompositeIndexBytes());
		setCompositeIndexCount(usage.getCompositeIndexCount());
		setCount(usage.getCount());
		setCreated(usage.getCreated());
		setCreator(usage.getCreator());
		setDeleteYN(usage.getDeleteYN());
		setDeleted(usage.getDeleted());
		setDomainId(usage.getDomainId());
		setEntityBytes(usage.getEntityBytes());
		setExpirationDate(usage.getExpirationDate());
		setExpirationCheckDays(usage.getExpirationCheckDays());
		setImageBytes(usage.getImageBytes());
		setImageCount(usage.getImageCount());
		setModified(new Date());
		setOwner(usage.getOwner());
		setSearchIndexBytes(usage.getSearchIndexBytes());
		setSearchIndexCount(usage.getSearchIndexCount());
		setTimestamp(usage.getTimestamp());
		setUsageCheckPointsOfBoard(usage.getUsageCheckPointsOfBoard());
		setUsageCheckPointsOfStorage(usage.getUsageCheckPointsOfStorage());
		setUsageCheckPointsOfUser(usage.getUsageCheckPointsOfUser());
		setUserCount(usage.getUserCount());
		setChargeable(usage.isChargeable());
	}
	
	@Column(description="도메인명", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private String domainName;
	
	/**
	 * domainName -> namespace가 적용된 domainId
	 */
	@Column(description="도메인 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="사용량 체크일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date timestamp;
	
	@Column(description="사용량(총 바이트)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long bytes;
	
	@Column(description="총 엔티티수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long count;
	
	@Column(description="엔티티 사용량(총 바이트)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long entityBytes;
	
	@Column(description="복합 인덱스 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long compositeIndexBytes;
	
	@Column(description="복합 인덱스 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long compositeIndexCount;
	
	@Column(description="내부 인덱스 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long bulitinIndexBytes;
	
	@Column(description="내부 인덱스 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long bulitinIndexCount;
	
	@Column(description="사용자 수", type="numeric", length=32, index=true)
	@Getter @Setter	
	private Long userCount;
	
	@Column(description="첨부파일 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long attachmentCount;
	
	@Column(description="첨부파일 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long attachmentBytes;
	
	@Column(description="이미지 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long imageCount;
	
	@Column(description="이미지 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long imageBytes;
	
	@Column(description="서비스 만료일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date expirationDate;
	
	@Column(description="검색 인덱스 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long searchIndexBytes;
	
	@Column(description="검색 인덱스 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long searchIndexCount;
	
	@Column(description="보드 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long boardCount;
	
	@Column(description="과금 대상 여부", type="bool", length=1, index=true)
	@Getter @Setter
	private boolean chargeable;
	
	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	@Getter @Setter
	private Long groupCount;
	@Getter @Setter
	private Long taskCount;
	*/
	//<-- ===== DOMAIN STATISTICS =====
	
	@Transient
	public Long getTotalBytes() {
		long totBytes = 0L;
		if (bytes != null) { totBytes += bytes; }
		if (attachmentBytes != null) { totBytes += attachmentBytes; }
		if (imageBytes != null) { totBytes += imageBytes; }
		if (searchIndexBytes != null) { totBytes += searchIndexBytes; }
		
		return totBytes;
	}

	private List<Integer> expirationCheckDays = new ArrayList<Integer>();
	public void setExpirationCheckDays(List<Integer> expirationCheckDays) {
		if (expirationCheckDays == null) expirationCheckDays = new ArrayList<Integer>();
		this.expirationCheckDays = expirationCheckDays;
	}
	public List<Integer> getExpirationCheckDays() {
		if (expirationCheckDays == null) expirationCheckDays = new ArrayList<Integer>();
		return expirationCheckDays;
	}

	/** 사용자 초과 %목록을 넣어둔다. 단위 80%... 90%..95% */
	private List<Integer> usageCheckPointsOfUser = new ArrayList<Integer>();
	public void setUsageCheckPointsOfUser(List<Integer> usageCheckPointsOfUser) {
		if (usageCheckPointsOfUser == null) usageCheckPointsOfUser = new ArrayList<Integer>();
		this.usageCheckPointsOfUser = usageCheckPointsOfUser;
	}
	public List<Integer> getUsageCheckPointsOfUser() {
		if (usageCheckPointsOfUser == null) usageCheckPointsOfUser = new ArrayList<Integer>();
		return usageCheckPointsOfUser;
	}
	// Board 초과 % 목록을 넣어둔다. 단위 80%... 90%..95%
	private List<Integer> usageCheckPointsOfBoard = new ArrayList<Integer>();
	public void setUsageCheckPointsOfBoard(List<Integer> usageCheckPointsOfBoard) {
		if (usageCheckPointsOfBoard == null) usageCheckPointsOfBoard = new ArrayList<Integer>();
		this.usageCheckPointsOfBoard = usageCheckPointsOfBoard;
	}
	public List<Integer> getUsageCheckPointsOfBoard() {
		if (usageCheckPointsOfBoard == null) usageCheckPointsOfBoard = new ArrayList<Integer>();
		return usageCheckPointsOfBoard;
	}

	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	// Group 초과 % 목록을 넣어둔다. 단위 80%... 90%..95%
	private List<Integer> usageCheckPointsOfGroup = new ArrayList<Integer>();
	public void setUsageCheckPointsOfGroup(List<Integer> usageCheckPointsOfGroup) {
		if (usageCheckPointsOfGroup == null) usageCheckPointsOfGroup = new ArrayList<Integer>();
		this.usageCheckPointsOfGroup = usageCheckPointsOfGroup;
	}
	public List<Integer> getUsageCheckPointsOfGroup() {
		if (usageCheckPointsOfGroup == null) usageCheckPointsOfGroup = new ArrayList<Integer>();
		return usageCheckPointsOfGroup;
	}
	// Task 초과 % 목록을 넣어둔다. 단위 80%... 90%..95%
	private List<Integer> usageCheckPointsOfTask = new ArrayList<Integer>();
	public void setUsageCheckPointsOfTask(List<Integer> usageCheckPointsOfTask) {
		if (usageCheckPointsOfTask == null) usageCheckPointsOfTask = new ArrayList<Integer>();
		this.usageCheckPointsOfTask = usageCheckPointsOfTask;
	}
	public List<Integer> getUsageCheckPointsOfTask() {
		if (usageCheckPointsOfTask == null) usageCheckPointsOfTask = new ArrayList<Integer>();
		return usageCheckPointsOfTask;
	}
	*/
	//<-- ===== DOMAIN STATISTICS =====

	/** Storage 초과 % 목록을 넣어둔다. 단위 80%... 90%..95% */
	private List<Integer> usageCheckPointsOfStorage = new ArrayList<Integer>();
	public void setUsageCheckPointsOfStorage(List<Integer> usageCheckPointsOfStorage) {
		if (usageCheckPointsOfStorage == null) usageCheckPointsOfStorage = new ArrayList<Integer>();
		this.usageCheckPointsOfStorage = usageCheckPointsOfStorage;
	}
	public List<Integer> getUsageCheckPointsOfStorage() {
		if (usageCheckPointsOfStorage == null) usageCheckPointsOfStorage = new ArrayList<Integer>();
		return usageCheckPointsOfStorage;
	}

	@Column(description="사용량 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	@Transient
	public String getUsageId() {
		return super.getKeyStr();
	}
	public void setUsageId(String usageId) {
		super.setKeyStr(usageId);
	}
}
