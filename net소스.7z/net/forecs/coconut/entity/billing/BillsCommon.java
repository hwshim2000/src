package net.forecs.coconut.entity.billing;

import javax.persistence.Entity;
import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.billing.PaidType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.entity.common.Base;

@Deprecated
@Entity
@MappedSuperclass
public class BillsCommon extends Base {
	private static final long serialVersionUID = -5868384291665364138L;
	
	//==========================================================
	/* 도메인 설정 정보  */
	
	@Column(description="도메인명", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;		// 도메인명(customer_uid에 사용됨)
	
	@Column(description="결재 사이트", type="varchar", length=32, index=true)
	@Getter @Setter
	private String site;			// 결제 site
	
	@Column(description="결재 타입(AUTH, NOAUTH)", type="varchar", length=8, index=true)
	@Getter @Setter
	private PaidType paidType;		// 결제 타입(AUTH, NOAUTH)
	
	@Column(description="상품명", type="varchar", length=64, index=true)
	@Getter @Setter
	private String name;			// 상품명
	
	@Column(description="사용자 로그인 아이디(결재 아이디)", type="varchar", length=32, index=true)
	@Getter @Setter
	private String id;				// 사용자 ID(결제ID)
	
	@Column(description="서비스 타입(STANDARD, TRIAL, PREMIUM)", type="varchar", length=8, index=true, defaultValue="STANDARD")
	@Getter @Setter
	private ServiceType serviceType = ServiceType.STANDARD;// 서비스 타입
	
	@Column(description="서비스 사용 유저수", type="numeric", length=16)
	@Getter @Setter
	private Long userQuota;			// 사용 유저수
	
	@Column(description="추가 스토리지", type="numeric", length=32)
	@Getter @Setter
	private Long addedStorage;		// 추가 스토리지
	
	@Column(description="계약(연장)월 수, null이면 unlimit 또는 카드 유효기간", type="numeric", length=8, index=true)
	@Getter @Setter
	private Integer term;			// 계약월 or 연장 월수(null 이면 unlimit or 카드 유효기간)
	
	@Column(description="결재주기, 월(1)/분기(3)/반기(6)/년(12)", type="numeric", length=8, index=true, defaultValue="1")
	@Getter @Setter
	private Integer period = 1;		// 계약주기 : 월(1), 분기(3), 반기(6), 년(12) 
	
	@Column(description="정기 예약 결제 여부", type="boolean", length=1, index=true, defaultValue="true")
	@Getter @Setter
	private boolean subscription = true;// 정기 예약 결제 여부
	
	@Column(description="총 결제금액(일시불일경우 totalAmount = amount)", type="numeric", length=16, index=true, notnull=true)
	@Getter @Setter
	private Integer amount;			// 총 결제금액(일시불일경우 totalAmount = amount);
//	@Getter @Setter
//	private Date expirationDate;	// 계약 종료일
	
	@Column(description="부가세", type="numeric", length=16)
	@Getter @Setter
	private Integer vat;			// 부가세
}
