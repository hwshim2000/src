package net.forecs.coconut.entity.billing;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="ServiceGrades"
, description="서비스 등급"
, pkConstraint="CONSTRAINT pk_serviceGradeId PRIMARY KEY (serviceGradeId)"
, references="Coupons")
@Entity
public class ServiceGrades extends Common {
	private static final long serialVersionUID = -6237656071073898722L;

	@Column(description="서비스 등급", type="varchar", unique=true, length=16, index=true, notnull=true)
	@Getter @Setter
	private String serviceGrade;
	
	@Column(description="사용자별단가(월)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Integer pricePerUser;
	
	@Column(description="스토리지별단가(월)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Integer pricePerGiga;
	
	@Column(description="사용자별기본제공스토리지(월)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Integer gigaPerUser;
	
	@Column(description="서비스 등급 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getServiceGradeId() {
		return super.getKeyStr();
	}
	public void setServiceGradeId(String serviceGradeId) {
		super.setKeyStr(serviceGradeId);
	}
}
