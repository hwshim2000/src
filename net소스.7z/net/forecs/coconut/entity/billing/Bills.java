package net.forecs.coconut.entity.billing;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.billing.IamportBill;
import net.forecs.coconut.common.code.billing.PaidStatus;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Text;

@Schema(name="Bills"
	, description="계산서"
	, pkConstraint="CONSTRAINT pk_billId PRIMARY KEY (billId)"
	, references="Coupons")
@Entity
public class Bills extends Base {
	private static final long serialVersionUID = 1753351430511314434L;
	
	@Column(description="도메인명", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;		// 도메인명(customer_uid에 사용됨)
	
	@Column(description="결재 사이트", type="varchar", length=32, index=true)
	@Getter @Setter
	private String site;			// 결제 site
	
	@Column(description="상품명(결재명)", type="varchar", length=64, index=true)
	@Getter @Setter
	private String name;			// 상품명
	
	@Column(description="총 결제금액", type="numeric", length=32, index=true, notnull=true)
	@Getter @Setter
	private Integer amount;			// 총 결제금액(일시불일경우 totalAmount = amount);
//	@Getter @Setter
//	private Date expirationDate;	// 계약 종료일
	
	@Column(description="부가세", type="numeric", length=16)
	@Getter @Setter
	private Integer vat;			// 부가세
	
	@Column(description="고객 UID(domainName + '_' + dateTime)", type="varchar", length=32, index=true, notnull=true)
	@Getter @Setter
	private String merchant_uid;	// 고객 UID(domainName + "_" + datetime)
	
	@Column(description="결재 결과(ready/paid/failed/cancelled)", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private PaidStatus paidStatus;	// 서버 도메인 적용 여부(ready, paid, failed, cancelled)
	
	@Getter @Setter
	private Date paymentDate;		// 결제일시
	
	@Column(description="사용량(총)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long totBytes;
	
	@Column(description="사용량(평균)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Double avgBytes;
	
	@Column(description="사용자 수(총)", type="numeric", length=32, index=true)
	@Getter @Setter	
	private Long totUsers;
	
	@Column(description="사용자 수(평균)", type="numeric", length=32, index=true)
	@Getter @Setter	
	private Double avgUsers;
	
	@Column(description="해당월서비스시작일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date serviceStart;		// 서비스시작일시

	@Column(description="해당월서비스마지막일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date serviceEnd;		// 서비스 마감일시
	
	@Column(description="실제서비스이용일", type="numeric", length=16, index=true)
	@Getter @Setter
	private int serviceDays;
	
	@Column(description="결재 시도 횟수", type="numeric", length=16, index=true)
	@Getter @Setter
	private int tryCount;
	
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Text customerObj;
	@Transient
	private Customers customer;		// 고객정보
	public Customers getCustomer() {
		if (customer != null) { return customer; }
		if (customerObj != null && StringUtils.isNotBlank(customerObj.getValue())) {
			ObjectMapper om = new ObjectMapper();
			om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	//		om.setVisibilityChecker(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
			try {
				customer = om.readValue(customerObj.getValue(), new TypeReference<Customers>() {});
			} catch (Exception ex) { return null; }
		}
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
		if (customer != null) {
			ObjectMapper om = new ObjectMapper();
			om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
//			om.setVisibilityChecker(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
			try {
				customerObj = new Text(om.writeValueAsString(customer));
			} catch (Exception ex) {}
		}
	}

	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@JsonIgnore
	private Text iamportBillObj;
	@Transient
	private IamportBill iamportBill;// IamPort Bill
	public IamportBill getIamportBill() {
		if (iamportBill!= null) { return iamportBill; }
		if (iamportBillObj != null && StringUtils.isNotBlank(iamportBillObj.getValue())) {
			ObjectMapper om = new ObjectMapper();
			om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	//		om.setVisibilityChecker(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
			try {
				iamportBill = om.readValue(iamportBillObj.getValue(), new TypeReference<IamportBill>() {});
			} catch (Exception ex) { return null; }
		}
		return iamportBill;
	}
	public void setIamportBill(IamportBill iamportBill) {
		this.iamportBill = iamportBill;
		if (iamportBill != null) {
			ObjectMapper om = new ObjectMapper();
			om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
//			om.setVisibilityChecker(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
			try {
				iamportBillObj = new Text(om.writeValueAsString(iamportBill));
			} catch (Exception ex) {}
		}
	}
	
	@Column(description="빌링 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getBillId() {
		return super.getKeyStr();
	}
	public void setBilld(String billId) {
		super.setKeyStr(billId);
	}
	
	public Map<String, Object> toIamportEntities(boolean isAgain) {
		customer = getCustomer();
		
		Map<String, Object> entities = new HashMap<String, Object>();
		entities.put(FLD.merchant_uid, merchant_uid);	// 가맹점에서 전달한 거래 고유번호. imp_uid, merchant_uid 중 하나는 필수이어야 합니다. 두 값이 모두 넘어오면 imp_uid를 우선 적용합니다.
		entities.put(FLD.amount, amount);				// 결재 금액
		entities.put(FLD.vat, vat);						// 결제금액 중 부가세 금액(파라메터가 누락되면 10%로 자동 계산됨)
//		entityMap.put("remember_me", null);				// 다음번에도 결제사용여부. 기존에 customer_uid로 등록된 적이 있으면 overwrite됩니다.
		entities.put(FLD.customer_uid, domainName);		// string 타입의 고객 고유번호 (이 정보는 유지할 필요가 없을듯)
		entities.put(FLD.name, name);
		if (customer != null) {
			if (!isAgain) {
				entities.put(FLD.card_number, customer.getCard_number());// 카드번호(dddd-dddd-dddd-dddd)
				entities.put(FLD.expiry, customer.getExpiry());			// 환카드 유효기간(YYYY-MM)
				entities.put(FLD.birth, customer.getBirth());			// 생년월일6자리
				entities.put(FLD.pwd_2digit, customer.getPwd_2digit());	// 카드비밀번호 앞 2자리
			}
			entities.put(FLD.buyer_name, customer.getBuyer_name());
			entities.put(FLD.buyer_email, customer.getBuyer_email());
			entities.put(FLD.buyer_tel, customer.getBuyer_tel());
			entities.put(FLD.buyer_addr, customer.getBuyer_addr());
			entities.put(FLD.buyer_postcode, customer.getBuyer_postcode());
		}
		return entities;
	}
	
//	public Bills() { }
//	public Bills(Bills bill) {
//		setSite(bill.getSite());
//		setAmount(bill.getAmount());
//		setCustomer(bill.getCustomer());
//		setDomainName(bill.getDomainName());
//		setMerchant_uid(bill.getMerchant_uid());
//		setName(bill.getName());
//		setOwner(bill.getOwner());
//		setPaidStatus(bill.getPaidStatus());
////		setPaymentStart(bill.getPaymentStart());
//		setVat(bill.getVat());
//	}
}
