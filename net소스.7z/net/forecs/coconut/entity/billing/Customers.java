package net.forecs.coconut.entity.billing;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.security.AESCipher;
import net.forecs.coconut.entity.common.Base;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

@Entity
public class Customers extends Base {
	private static final long serialVersionUID = -8606547489769179492L;
	// ----- 요청 시 필요 -----
	@Getter @Setter
	private String customer_uid;	// 고객 고유 번호(도메인네임)
	@Getter @Setter
	private String card_number;		// 카드 번호 (ddddd-ddddd-ddddd-ddddd)
	@Getter @Setter
	private String expiry;			// 카드 유효기간(yyyy-MM)
	@Getter @Setter
	private String birth;			// 생년월일(yyyyMMdd)
	private String pwd_2digit;		// 비밀번호 앞 두자리(**XX)/법인카드는 없어도 무방
	public String getPwd_2digit() {
		try {
			if (StringUtils.isBlank(pwd_2digit)) { return null; }
			return AESCipher.decode(pwd_2digit, card_number.replaceAll("-", ""));
		} catch (Exception ex) { return null; }
	}
	public void setPwd_2digit(String pwd_2digit) {
		try {
			this.pwd_2digit = AESCipher.encode(pwd_2digit, card_number.replaceAll("-", ""));
		} catch (Exception ex) {} 
	}
	
	
	@Getter @Setter
	private String buyer_name;		// 구매자명
	@Getter @Setter
	private String buyer_email;		// 구매자 이메일 주소
	@Getter @Setter
	private String buyer_tel;		// 구매자 전화번호
	@Getter @Setter
	private String buyer_addr;		// 구매자 배송 주소
	@Getter @Setter
	private String buyer_postcode;	// 구매자 배송주소 우편 번호
//	
	// ----- 요청 결과 -----
	@Getter @Setter
	private String inserted;		// 카드 정보 입력일자
	@Getter @Setter
	private String updated;			// 카드 정보 갱신일자
	@Getter @Setter
	private String card_name;		// 카드명(고객 등록후 등록된 카드의 명을 반환)
	
	public Date getInsertedDate() {
		if (StringUtils.isNotBlank(inserted) && NumberUtils.isNumber(inserted)) {
			return new Date(Long.parseLong(inserted)*1000);
		}
		return null;
	}
	public Date getUpdatedDate() {
		if (StringUtils.isNotBlank(updated) && NumberUtils.isNumber(updated)) {
			return new Date(Long.parseLong(updated)*1000);
		}
		return null;
	}
	
	@Column(description="고객아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getCustomerId() {
		return super.getKeyStr();
	}
	public void setCustomerId(String customerId) {
		super.setKeyStr(customerId);
	}
	
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Map<String, Object> toIamportEntities() {
		Map<String, Object> entityMap = new HashMap<String, Object>();
		entityMap.put(FLD.customer_uid, customer_uid);	// String 타입의 고객 고유 번호 (도메인명)
		entityMap.put(FLD.card_number, card_number);	// 카드번호
		entityMap.put(FLD.expiry, expiry);				// 유효기간
		entityMap.put(FLD.birth, birth);				// 생년월일
		entityMap.put(FLD.pwd_2digit, pwd_2digit);		// 카드번호
		return entityMap;
	}
}
