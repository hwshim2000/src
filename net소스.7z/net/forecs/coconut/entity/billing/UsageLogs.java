package net.forecs.coconut.entity.billing;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="UsageLogs"
, description="도메인 사용량 정보 이력"
	, pkConstraint="CONSTRAINT pk_usageLogId PRIMARY KEY (usageLogId)"
	, fkConstraints="CONSTRAINT fk_domainId FOREIGN KEY (domainId) REFERENCES Domains(domainId)"
	, references="Domains")
@Entity
public class UsageLogs extends Base {
	private static final long serialVersionUID = -4064422397497167238L;

	@Column(description="도메인명", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private String domainName;
	/**
	 * domainName -> namespace가 적용된 domainId
	 */
	
	@Column(description="도메인 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="사용량 기록 주기(HOURLY/DAILY/MONTHLY/YEARLY), ", type="varchar", length=8, index=true, defaultValue="DAILY")
	@Getter @Setter
	private Frequency frequency = Frequency.DAILY;
	
	@Column(description="사용량 체크일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date timestamp;
	
	@Column(description="사용량(총 바이트)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long bytes;
	
	@Column(description="총 엔티티수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long count;
	
	@Column(description="엔티티 사용량(총 바이트)", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long entityBytes;
	
	@Column(description="복합 인덱스 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long compositeIndexBytes;
	
	@Column(description="복합 인덱스 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long compositeIndexCount;
	
	@Column(description="내부 인덱스 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long bulitinIndexBytes;
	
	@Column(description="내부 인덱스 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long bulitinIndexCount;
	
	@Column(description="사용자 수", type="numeric", length=32, index=true)
	@Getter @Setter	
	private Long userCount;
	
	@Column(description="첨부파일 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long attachmentCount;
	
	@Column(description="첨부파일 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long attachmentBytes;
	
	@Column(description="이미지 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long imageCount;
	
	@Column(description="이미지 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long imageBytes;
	
	@Column(description="서비스 만료일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date expirationDate;
	
	@Column(description="검색 인덱스 사용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long searchIndexBytes;
	
	@Column(description="검색 인덱스 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long searchIndexCount;
	
	@Column(description="보드 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long boardCount;
	
	@Column(description="과금 대상 여부", type="bool", length=1, index=true)
	@Getter @Setter
	private boolean chargeable;

	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	@Getter @Setter
	private Long groupCount;
	@Getter @Setter
	private Long taskCount;
	*/
	//<-- ===== DOMAIN STATISTICS =====

	@Transient
	public Long getTotalBytes() {
		long totBytes = 0L;
		if (bytes != null) { totBytes += bytes; }
		if (attachmentBytes != null) { totBytes += attachmentBytes; }
		if (imageBytes != null) { totBytes += imageBytes; }
		if (searchIndexBytes != null) { totBytes += searchIndexBytes; }
		
		return totBytes;
	}

	private List<Integer> expirationCheckDays = new ArrayList<Integer>();
	public void setExpirationCheckDays(List<Integer> expirationCheckDays) {
		if (expirationCheckDays == null) expirationCheckDays = new ArrayList<Integer>();
		this.expirationCheckDays = expirationCheckDays;
	}
	public List<Integer> getExpirationCheckDays() {
		if (expirationCheckDays == null) expirationCheckDays = new ArrayList<Integer>();
		return expirationCheckDays;
	}

	/** 
	 * 사용자 초과 %목록을 넣어둔다. 단위 80%... 90%..95%
	 */
	private List<Integer> usageCheckPointsOfUser = new ArrayList<Integer>();
	public void setUsageCheckPointsOfUser(List<Integer> usageCheckPointsOfUser) {
		if (usageCheckPointsOfUser == null) usageCheckPointsOfUser = new ArrayList<Integer>();
		this.usageCheckPointsOfUser = usageCheckPointsOfUser;
	}
	public List<Integer> getUsageCheckPointsOfUser() {
		if (usageCheckPointsOfUser == null) usageCheckPointsOfUser = new ArrayList<Integer>();
		return usageCheckPointsOfUser;
	}
	// Board 초과 % 목록을 넣어둔다. 단위 80%... 90%..95%
	private List<Integer> usageCheckPointsOfBoard = new ArrayList<Integer>();
	public void setUsageCheckPointsOfBoard(List<Integer> usageCheckPointsOfBoard) {
		if (usageCheckPointsOfBoard == null) usageCheckPointsOfBoard = new ArrayList<Integer>();
		this.usageCheckPointsOfBoard = usageCheckPointsOfBoard;
	}
	public List<Integer> getUsageCheckPointsOfBoard() {
		if (usageCheckPointsOfBoard == null) usageCheckPointsOfBoard = new ArrayList<Integer>();
		return usageCheckPointsOfBoard;
	}

	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	// Group 초과 % 목록을 넣어둔다. 단위 80%... 90%..95%
	private List<Integer> usageCheckPointsOfGroup = new ArrayList<Integer>();
	public void setUsageCheckPointsOfGroup(List<Integer> usageCheckPointsOfGroup) {
		if (usageCheckPointsOfGroup == null) usageCheckPointsOfGroup = new ArrayList<Integer>();
		this.usageCheckPointsOfGroup = usageCheckPointsOfGroup;
	}
	public List<Integer> getUsageCheckPointsOfGroup() {
		if (usageCheckPointsOfGroup == null) usageCheckPointsOfGroup = new ArrayList<Integer>();
		return usageCheckPointsOfGroup;
	}
	// Task 초과 % 목록을 넣어둔다. 단위 80%... 90%..95%
	private List<Integer> usageCheckPointsOfTask = new ArrayList<Integer>();
	public void setUsageCheckPointsOfTask(List<Integer> usageCheckPointsOfTask) {
		if (usageCheckPointsOfTask == null) usageCheckPointsOfTask = new ArrayList<Integer>();
		this.usageCheckPointsOfTask = usageCheckPointsOfTask;
	}
	public List<Integer> getUsageCheckPointsOfTask() {
		if (usageCheckPointsOfTask == null) usageCheckPointsOfTask = new ArrayList<Integer>();
		return usageCheckPointsOfTask;
	}
	*/
	//<-- ===== DOMAIN STATISTICS =====

	/** Storage 초과 % 목록을 넣어둔다. 단위 80%... 90%..95% */
	private List<Integer> usageCheckPointsOfStorage = new ArrayList<Integer>();
	public void setUsageCheckPointsOfStorage(List<Integer> usageCheckPointsOfStorage) {
		if (usageCheckPointsOfStorage == null) usageCheckPointsOfStorage = new ArrayList<Integer>();
		this.usageCheckPointsOfStorage = usageCheckPointsOfStorage;
	}
	public List<Integer> getUsageCheckPointsOfStorage() {
		if (usageCheckPointsOfStorage == null) usageCheckPointsOfStorage = new ArrayList<Integer>();
		return usageCheckPointsOfStorage;
	}

	public UsageLogs(Usage usage, Frequency frequency) {
		this.setKey(KeyUtil.createUsageLogKey(frequency));
		this.frequency = frequency;
		this.domainName = usage.getDomainName();
		this.bytes = usage.getBytes();
		this.count = usage.getCount();
		this.entityBytes = usage.getEntityBytes();
		this.compositeIndexBytes = usage.getCompositeIndexBytes();
		this.compositeIndexCount = usage.getCompositeIndexCount();
		this.bulitinIndexBytes = usage.getBulitinIndexBytes();
		this.bulitinIndexCount = usage.getBulitinIndexCount();

		this.userCount = usage.getUserCount();
		this.boardCount = usage.getBoardCount();
		this.attachmentCount = usage.getAttachmentCount();
		this.attachmentBytes = usage.getAttachmentBytes();
		this.imageCount = usage.getImageCount();
		this.imageBytes = usage.getImageBytes();
		this.expirationDate = usage.getExpirationDate();
		this.searchIndexBytes = usage.getSearchIndexBytes();
		this.searchIndexCount = usage.getSearchIndexCount();
		
		this.expirationCheckDays = usage.getExpirationCheckDays();
		this.usageCheckPointsOfUser = usage.getUsageCheckPointsOfUser();
		this.usageCheckPointsOfStorage = usage.getUsageCheckPointsOfStorage();
		this.usageCheckPointsOfBoard = usage.getUsageCheckPointsOfBoard();
		
		this.timestamp = usage.getTimestamp();
		this.chargeable = usage.isChargeable();
		//--> ===== DOMAIN STATISTICS =====
		/* Later, I may use this code.
		// region
		this.usageCheckPointsOfGroup = usage.getUsageCheckPointsOfGroup();
		this.usageCheckPointsOfTask = usage.getUsageCheckPointsOfTask();
		
		this.groupCount = usage.getGroupCount();
		this.taskCount = usage.getTaskCount();
		// endregion
		*/
		//<-- ===== DOMAIN STATISTICS =====
	}
	
	@Column(description="사용량 이력 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	@Transient
	public String getUsageLogId() {
		return super.getKeyStr();
	}
	public void setUsageLogId(String usageLogId) {
		super.setKeyStr(usageLogId);
	}
}
