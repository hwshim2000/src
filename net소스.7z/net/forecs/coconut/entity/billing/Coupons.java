package net.forecs.coconut.entity.billing;

import java.util.Date;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.TermType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

import com.google.appengine.api.datastore.Key;

@Schema(name="Coupons"
	, description="서비스 이용 쿠폰"
	, pkConstraint="CONSTRAINT pk_couponId PRIMARY KEY (couponId)"
	, references={"Domains", "Bills"})
@Entity
public class Coupons extends Base {
	private static final long serialVersionUID = -6268780104825968735L;

	@Column(description="사용자 이용 가능 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long userQuota;
	
	@Column(description="스토리지 허용량", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long storageQuota;
	
	@Column(description="보드 생성 허용 수", type="numeric", length=32, index=true)
	@Getter @Setter
	private Long boardQuota;

	//--> ===== DOMAIN STATISTICS =====
	/* Later, I may use this code.
	@Getter @Setter
	private Long groupQuota;
	@Getter @Setter
	private Long taskQuota;
	*/
	//<-- ===== DOMAIN STATISTICS =====
	
	@Column(description="기간 연장 타입(FIXED/APPEND)", type="varchar", length=8, index=true, defaultValue="APPEND")
	@Getter @Setter
	private TermType termType = TermType.APPEND;	// termType 이 APPEND 이면 도메인의 expirationDate + term(days)
	
	@Column(description="기간 연장(days)", type="numeric", length=16, index=true)
	@Getter @Setter
	private Integer term;	// days
	
	@Column(description="사용 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String useYN;
	
	@Column(description="발행 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String issueYN;
	
	@Column(description="도메인명", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;
	
	@Column(description="사용일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date usedDate;
	
	@Column(description="발행일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date issueDate;
	
	@Column(description="발행인", type="varchar", length=16, index=true)
	@Getter @Setter
	private String issuer;
	
	@Column(description="밸행대상", type="varchar", length=16, index=true)
	@Getter @Setter
	private String issueTarget;
	
	@Column(description="유효일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date validDate;
	
	@Column(description="만료일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date expirationDate;	// termType이 FIXED 일 경우, 이 값을 도메인의 expirationDate에 적용
	
	@Column(description="서비스 타입(TRIAL/STANDARD)", type="varchar", length=8, index=true, defaultValue="TRIAL")
	@Getter @Setter
	private ServiceType serviceType = ServiceType.TRIAL;
	
	@Column(description="쿠폰 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getCouponId() {
		return super.getKeyStr();
	}

	public void setCouponId(String couponId) {
		super.setKeyStr(couponId);
	}
	
	public String getCouponCode() {
		final Key key = getKey();
		return key != null ? key.getName() : null;
	}
}
