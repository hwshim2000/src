package net.forecs.coconut.entity.subscription;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.user.Users;

@Schema(name="Subscriptions"
	, description="구독"
	, pkConstraint="CONSTRAINT pk_subscriptionId PRIMARY KEY (subscriptionId)"
	, fkConstraints={"CONSTRAINT fk_taskId FOREIGN KEY (taskId) REFERENCES Tasks(taskId)",
		"CONSTRAINT fk_userId FOREIGN KEY (userId) REFERENCES Users(userId)"}
	, references={"Users", "Tasks"})
@Entity
public class Subscriptions extends Base {
	private static final long serialVersionUID = 2397149551858926962L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="사용자 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String userId;
	
	@Transient
	@Getter @Setter
	private Users user;
	
	public Subscriptions(String domainId, String boardId, String taskId, String userId, String creator) {
		this.domainId = domainId;
		this.boardId = boardId;
		this.taskId = taskId;
		this.userId = userId;
		this.setCreator(creator);
	}
	@Column(description="구독 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getSubscriptionId() {
		return super.getKeyStr();
	}
	public void setSubscriptionId(String subsriptionId) {
		super.setKeyStr(subsriptionId);
	}
}
