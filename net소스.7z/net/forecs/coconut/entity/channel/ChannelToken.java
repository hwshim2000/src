package net.forecs.coconut.entity.channel;

import java.util.Date;
import java.util.Map;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.KeyFactory;
import com.googlecode.objectify.annotation.Cache;

@Schema(name="ChannelToken"
	, description="싱크를 위한 채널 토근"
	, pkConstraint="CONSTRAINT pk_channelTokenId PRIMARY KEY (channelTokenId)"
	, fkConstraints="CONSTRAINT fk_userId FOREIGN KEY (userId) REFERENCES Users(userId)"
	, references = "Users" )
@Cache
@Entity
public class ChannelToken extends Base {
	private static final long serialVersionUID = -143653218133286497L;

	public ChannelToken(String domainId, String userId) {
		this.domainId = domainId;
		this.userId = userId;
	}

	@Column(description="채널 토큰 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getChannelTokenId(){
		return super.getKeyStr();
	}
	public void setChannelTokenId(String channelToken) {
		super.setKeyStr(channelToken);
	}

	@Column(description="채널 토큰", type="varchar", length=16, index=true, notnull=true)
	@Getter @Setter
	private String token;
	
	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="사용자 아이디", type="varchar", length=32, index=true, foreign=true, notnull=true)
	@Getter @Setter
	private String userId;
	
	@Column(description="토큰 만료일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date expirationDate;
	
	@Column(description="연결일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date connectedDate;
	
	public boolean isValid() {
		if (expirationDate==null) { return true; }
		return 0 < expirationDate.compareTo(new Date());
	}

	public boolean isConnected() {
		return isValid() && (connectedDate != null);
	}
	
	@Column(description="도메인명", type="varchar", length=16, index=true)
	public String getDomainName() {
		try {
			if (StringUtils.isBlank(domainId)) { return null; }
			return KeyFactory.stringToKey(domainId).getName();
		} catch (Exception ex) { return null; }
	}
	
	public String getId() {
		try {
			if (StringUtils.isBlank(userId)) { return null; }
			return KeyFactory.stringToKey(userId).getName();
		} catch (Exception ex) { return null; }
	}
	
	public String getChannelKey() {
		return String.valueOf(getCreated().getTime());
	}
	
	public ChannelToken(String channelKey, Map<String, Object> channel) {
		Date date = new Date(Long.valueOf(channelKey));
		setCreated(date);
		setConnectedDate(date);
		setDomainId((String)channel.get(FLD.domainId));
		setDeleteYN((String)channel.get(FLD.deleteYN));
		setUserId((String)channel.get(FLD.userId));
		setToken((String)channel.get(FLD.token));
	}
}
