package net.forecs.coconut.entity.channel;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="WebHook"
	, description="웹훅"
	, pkConstraint="CONSTRAINT pk_webHookId PRIMARY KEY (webHookId)"
	, references="Activities")
@Entity
public class WebHook extends Base {
	private static final long serialVersionUID = -6309677489011377518L;

	@Column(description="엑티비티 종류(Domains, Boards, Tasks, ...)", type="varchar", length=16, index=true)
	@Getter @Setter
	private ActivityKind activityKind;
	
	@Column(description="엑티비티 타입(ADDED, UPDATED, DELETED, ...)", type="varchar", length=32, index=true)
	@Getter @Setter
	private ActivityType activityType;
	
	@Column(description="엑티비티 발생 아이디", type="varchar", length=16, index=true)
	@Getter @Setter
	private String kindId;			// 해당 object의 고유 id
	
	@Column(description="웹훅 메쏘드(POST/GET/DELETE/PATCH/....)", type="varchar", length=8, index=true)
	@Getter @Setter
	private String method;			// POST/GET/DELETE/PATCH/....
	
	@Column(description="웹훅 대상 URL", type="varchar", length=512, index=true)
	@Getter @Setter
	private String url;				// hook url
	
	@Column(description="웹훅 대상 콘텐츠 타입(json/xml/text/....)", type="varchar", length=16, index=true)
	@Getter @Setter
	private String contentType;		//json/xml/text/....
	
	@Column(description="헤더에 사용할 key:value 멥", type="varchar", length=4096, index=true)
	@Getter @Setter
	private String headerMap;		// 헤더에 사용할 (key : value) json String. 예를 들어, access token등 로그인을 위해 사용한다던가...
	
	@Column(description="파라미터에 사용할 key:value 멥", type="clob", index=true)
	@Getter @Setter
	private String paramMap;		// parameter (key : value) json String
	
	@Column(description="제외시킬 항목 목록", type="varchar", length=4096, index=true)
	@Setter
	private List<String> excepts;	// Object attribute중에서 제외시킬 항목들
	public List<String> getExcepts() {
		if (excepts == null) { return new ArrayList<String>(); }
		return excepts;
	}
	
	@Column(description="전송 측과 수신측에서의 parameter를 mapping", type="varchar", length=4096, index=true)
	@Getter @Setter
	private String convertMap;		// 전송 측과 수신측에서의 parameter를 mapping하기 위해 (key : value) json String
	
	@Column(description="훅 실행 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean disable;		// hook 실행 여부
	
	@Column(description="해당 object에서만 발생한 activity만 보낼지 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean local;			// 해당 object에서만 발생한 activity만 보낼지 여부(true이면, 해당 오브젝트 및 global한 설정이 있을 경우 모두 보낸다)
	
	@Column(description="Object에 null을 포함 시킬지 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean includeNull;	// Object에 null을 포함 시킬지 여부
	
	@Column(description="Object에 empty을 포함 시킬지 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean includeEmpty;	// Object에 empty를 포함 시킬지 여부
	
	@Column(description="해당 Activity에 대해 로그로 남길지 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean saveLog;		// 해당 Activity에 대해 로그로 남길지 여부
	
	@Column(description="hook 실패시 재 시도 횟수, 0이면 더이상 시도하지 않는다.", type="numeric", length=16, index=true)
	@Getter @Setter
	private int retryCount;			// hook 실패시 재 시도 횟수, 0이면 더이상 시도하지 않는다.
	
	@Column(description="재시도시 간격(단위:초), 0이면 즉시 시도한다.", type="numeric", length=16, index=true)
	@Getter @Setter
	private int retryTerm;			// 재시도시 간격(단위:초), 0이면 즉시 시도한다.
	
	@Column(description="웹훅 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getWebHookId() {
		return super.getKeyStr();
	}
	public void setWebHookId(String webHookId) {
		super.setKeyStr(webHookId);
	}
}
