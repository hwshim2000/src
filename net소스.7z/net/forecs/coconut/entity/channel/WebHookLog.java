package net.forecs.coconut.entity.channel;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="WebHookLog"
, description="웹훅 이력"
, pkConstraint="CONSTRAINT pk_webHookLogId PRIMARY KEY (webHookLogId)"
, fkConstraints="CONSTRAINT fk_webHookId FOREIGN KEY (webHookId) REFERENCES WebHook(webHookId)"
, references="WebHook, Activities")
@Entity
public class WebHookLog extends Base {
	private static final long serialVersionUID = -5150901354585860472L;

	@Column(description="웹훅 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String webHookId;

	@Column(description="엑티비티 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String activityId;
	
	@Column(description="엑티비티 발생 아이디", type="varchar", length=16, index=true)
	@Getter @Setter
	private String kindId;
	
	@Column(description="엑티비티 종류(Domains, Boards, Tasks, ...)", type="varchar", length=16, index=true)
	@Getter @Setter
	private ActivityKind activityKind;
	
	@Column(description="엑티비티 타입(ADDED, UPDATED, DELETED, ...)", type="varchar", length=32, index=true)
	@Getter @Setter
	private ActivityType activityType;
	
	@Column(description="hook 실패시 재 시도 횟수, 0이면 더이상 시도하지 않는다.", type="numeric", length=16, index=true)
	@Getter @Setter
	private int retryCount;
	
	@Column(description="웹훅 실행 상태", type="numeric", length=8, index=true)
	@Getter @Setter
	private int status;
	
	@Column(description="웹훅 이력 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getWebHookLogId() {
		return super.getKeyStr();
	}
	public void setWebHookLogId(String webHookLogId) {
		super.setKeyStr(webHookLogId);
	}
}
