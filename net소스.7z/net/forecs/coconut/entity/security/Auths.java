package net.forecs.coconut.entity.security;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.security.AccessType;
import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="Auths"
	, description="사용자(OpenAPI or Admin) 인증 정보"
	, pkConstraint="CONSTRAINT pk_AuthId PRIMARY KEY (authId)"
	, references="Users")
@Entity
public class Auths extends Base {
	private static final long serialVersionUID = 7907646766640873595L;

	@Column(description="클라이언트 아이디", type="varchar", notnull=true, length=32)
	@Getter
	private String clientId;
	public void setClientId(String clientId) {
		this.clientId = clientId;
		setKey(KeyUtil.createAuthsKey(clientId));
	}
	
	@Getter @Setter
	@Column(description="클라이언트 인증 키", type="varchar", notnull=true, length=32)
	private String secretKey;
	
	@Getter @Setter
	@Column(description="접근타입(online/offline)", type="varchar", length=8)
	private AccessType accessType;
	
	@Column(description="접근 영역 목록(null(all)/ADMIN/PROFILE/DOMAIN/DASHBOARD/BOARD/TASK)", type="varchar", length=256)
	@Basic(fetch = FetchType.EAGER)
	private List<Scope> scopes;
	public void setScopes(List<Scope> scopes) {
		if (scopes==null) { scopes = new ArrayList<Scope>(); }
		this.scopes = scopes;
	}
	public List<Scope> getScopes() {
		if (scopes==null) { scopes = new ArrayList<Scope>(); }
		return scopes;
	}
	
	@Column(description="접근 주소 목록", type="varchar", length=1024)
	@Basic(fetch = FetchType.EAGER)
	private List<String> addresses;	// allowed ip addresses.
	public void setAddresses(List<String> addresses) {
		if (addresses==null) { addresses = new ArrayList<String>(); }
		this.addresses = addresses;
	}
	public List<String> getAddresses() {
		if (addresses==null) { addresses = new ArrayList<String>(); }
		return addresses;
	}
	
	@Column(description="도메인명", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;		// null(all), domain name.
	
	@Column(description="사용자 아이디 또는 이메일(로그인 아이디)", type="varchar", length=32, foreign=true)
	@Getter @Setter
	private String id;				// null(SYSTEM), login ID or email
	
	@Column(description="웹브라우저 정보 체크 여부", defaultValue="FALSE", type="bool")
	@Getter @Setter
	private boolean agentCheck;		// 사용자 brower agent 체크여부
	
	@Column(description="인증 아이디", type="varchar", primary=true, notnull=true, length=32)
	public String getAuthId(){
		return super.getKeyStr();
	}
	public void setAuthId(String authId) {
		super.setKeyStr(authId);
	}
}
