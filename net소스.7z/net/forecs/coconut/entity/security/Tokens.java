package net.forecs.coconut.entity.security;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

@Schema(name="Tokens"
	, description="엑세스 토큰(Session로그인과는 별도로 관리자 로그인을 위한 토큰 목록)"
	, pkConstraint="CONSTRAINT pk_tokenId PRIMARY KEY (tokenId)"
	, fkConstraints="CONSTRAINT fk_clientId FOREIGN KEY (clientId) REFERENCES Auths(clientId)"
	, references="Auths")
@Entity
public class Tokens extends Base {
	private static final long serialVersionUID = -4250763435734359453L;

	@Column(description="엑세스 토큰", type="varchar", notnull=true, length=64)
	@Getter @Setter
	private String accessToken;	// access token
	
	@Column(description="엑세스 갱신 토큰", type="varchar", notnull=true, length=64)
	@Getter @Setter
	private String refreshToken;// refresh token
	
	@Column(description="토큰 타입(barerer, etc, ..)", type="varchar", notnull=true, length=64)
	@Getter @Setter
	private String tokenType;	// token type. barerer, etc
	
	@Column(description="갱신 토큰 만료일시", type="datetime", length=32)
	@JsonIgnore
	@Getter @Setter
	private Date refreshExpire;	// refresh token expiration date.
	
	@Column(description="토큰 만료일시", type="datetime", length=32, notnull=true)
	@Getter @Setter
	private Date expire;		// onetime refresh tokenType is 7 days.	refresh tokenType is 1 months.
	
	@Column(description="클라이언트 아이디", type="varchar", notnull=true, length=16, foreign=true, index=true)
	@JsonIgnore
	@Getter @Setter
	private String clientId;	// request client id;
//	@JsonIgnore
//	@Getter @Setter
//	private String secretKey;	// secret key.
	
	@Column(description="토큰 허용 브라우저 Agent값", type="varchar", length=256)
	@JsonIgnore
	@Getter @Setter
	private String agent;		// browser information.
	
	@Column(description="토큰 허용 주소", type="varchar", length=64)
	@JsonIgnore
	@Getter @Setter
	private String address;		// access address.
	
	@Column(description="토큰 자동 갱신 여부", type="bool", length=1, defaultValue="FALSE")
	@Getter @Setter
	private boolean refresh;	// auto refresh
	
	public Integer getExpireIn() {
		if (expire != null) {
			Long expireIn =  (expire.getTime() - new Date().getTime())/1000;
			return expireIn.intValue();
		}
		return null;
	}
	
	@JsonIgnore
	@Transient
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private Auths auth;
	
	@Transient
	@Getter @Setter
	private String jwsAccessToken;
	
	@Column(description="토큰 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getTokenId(){
		return super.getKeyStr();
	}
	public void setTokenId(String tokenId) {
		super.setKeyStr(tokenId);
	}
}
