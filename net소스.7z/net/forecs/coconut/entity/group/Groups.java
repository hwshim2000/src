package net.forecs.coconut.entity.group;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="Groups"
	, description="그룹"
	, pkConstraint="CONSTRAINT pk_groupId PRIMARY KEY (groupId)"
	, fkConstraints="CONSTRAINT fk_domainId FOREIGN KEY (attachmentId) REFERENCES Domains(domainId)"
	, references="Domains")
@Entity
public class Groups extends Common {
	private static final long serialVersionUID = -4103394848896958845L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true, notnull=true)
	@Getter @Setter
	private String domainId;

	@Column(description="정렬 순서", type="numeric", length=16, index=true)
	@Getter @Setter
	private Integer ordernum;

	@Column(description="기본 그룹 여부", type="varchar", length=1, index=true, defaultValue="N")
	@Getter @Setter
	private String defaultYN = N;
	
	@Column(description="그룹 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getGroupId() {
		return super.getKeyStr();
	}

	public void setGroupId(String groupId) {
		super.setKeyStr(groupId);
	}

	public static void sort(List<Groups> list) {
		Collections.sort(list, new Comparator<Groups>() {
	        @Override
	        public int compare(Groups first, Groups second) {
	        	if (first.getOrdernum()==null && second.getOrdernum()==null) {
	        		return 0;
	        	} else if (first.getOrdernum()==null ) {
	        		return 1;
	        	} else if (second.getOrdernum()==null) {
	        		return -1;
	        	}
	        	
	        	if (first.getOrdernum() > second.getOrdernum()) {
	        		return 1;
	        	} else if (first.getOrdernum() < second.getOrdernum()) {
	        		return -1;
	        	} else {
	        		return 0;
	        	}
	        }
	    });
	}
}
