package net.forecs.coconut.entity.backup;

import java.util.Date;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="Backups"
	, description="백업 정도"
	, pkConstraint="CONSTRAINT pk_backupId PRIMARY KEY (backupId)")
@Entity
public class Backups extends Base {
	private static final long serialVersionUID = 4996614493326436445L;
	
	@Column(description="파일 저장 기본 경로(구글의 bucket)", type="varchar", length=32, index=true)
	@Getter @Setter
	private String bucket;
	
	@Column(description="백업명", type="varchar", length=128, index=true)
	@Getter @Setter
	private String backupName;
	
	@Column(description="도메인명", type="varchar", length=16, index=true)
	@Getter @Setter
	private String domainName;
	
	@Column(description="파일 백업 경로", type="varchar", length=512, index=true)
	@Getter @Setter
	private String backupPath;
//	@Getter @Setter
//	private String backupResult;
	
	@Column(description="백업 저장 요청 여부", defaultValue="FALSE", type="bool")
	@Getter @Setter
	private boolean isRestoreRequest;
	
	@Column(description="백업 저장 요청 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String restoreRequestUserId;
	
	@Column(description="백업 저장 요청 일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date restoreRequesetDate;
	
	@Column(description="백업저장결과", type="varchar", length=128, index=true)
	@Getter @Setter
	private String restoreResult;
	
	@Column(description="백업 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getBackupId() {
		return super.getKeyStr();
	}
	public void setBackupId(String backupId) {
		super.setKeyStr(backupId);
	}
	
	public Backups() { }
	public Backups(String bucket, String backupName, String domainName, String backupPath, Date backupDate) {
		this.bucket = bucket;
		this.backupName = backupName;
		this.domainName = domainName;
		this.backupPath = backupPath;
		this.setCreated(backupDate);
	}
}
