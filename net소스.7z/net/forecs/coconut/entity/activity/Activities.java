package net.forecs.coconut.entity.activity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.NoticeKind;
import net.forecs.coconut.common.util.HtmlUtil;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.endpoint.common.ActivityService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Text;

@Schema(name="Activities"
	, description="엑티비티 목록"
	, pkConstraint="CONSTRAINT pk_activityId PRIMARY KEY (activityId)"
	, references={"Domains","Boards","Tasks"})
@Entity
public class Activities extends Common {
	private static final long serialVersionUID = -4952152890418253534L;
	//-----------------------------------------------------------
	//<!-- version histories
	// 메시지의 parameters가 변하는 등등의 이유로 메시지가 변할때만 주로 사용
//	private static final String VERSION_DEFAULT = "default";// application version : default(null) or ~ 1.5
//	private static final String VERSION_1_5 = "1.5";		// application version : 1.5
//	@SuppressWarnings("unused")
//	private static final String VERSION_2_0 = "2.0";		// 향후 사용될 버전
	//-->
	//-----------------------------------------------------------
	
	//private static final String CURRENT_ACTIVITY_VERSION = VERSION_1_5;	
	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="엑티비티 종류(Domains/Boards/Tasks/...)", type="varchar", length=16, index=true)
	@Getter @Setter
	private ActivityKind activityKind;
	
	@Column(description="엑티비티 타입(ADDED/UPDATED/DELETED/...)", type="varchar", length=32, index=true)
	@Getter @Setter
	private ActivityType activityType;
	
	@Column(description="엑티비티 발생 아이디", type="varchar", length=32, index=true, notnull=true)
	@Getter @Setter
	private String kindId;
	
	@Column(description="태스크 타임라인 아이디", type="varchar", length=32, index=true)
	@Setter
	private String taskTimelineId;
	public String getTaskTimelineId() {
		if (StringUtils.isBlank(taskTimelineId)) {
			if (ActivityKind.TASK_TIMELINES.equals(activityKind)) {
				return kindId;
			} else if (ActivityKind.TASK_TIMELINE_COMMENTS.equals(activityKind)) {
				TaskTimelineComments comment = CommonService.doFind(TaskTimelineComments.class, kindId);
				if (comment != null) { return comment.getTaskTimelineId(); }
			}
		}
		return taskTimelineId;
	}
	
	@Column(description="태스크 타임라인 코멘트 아이디", type="varchar", length=16, index=true)
	@Setter
	private String taskTimelineCommentId;
	public String getTaskTimelineCommentId() {
		if (ActivityKind.TASK_TIMELINE_COMMENTS.equals(activityKind) && StringUtils.isBlank(taskTimelineCommentId)) {
			return kindId;
		}
		return taskTimelineCommentId;
	}
	
	@Column(description="관련 객체", type="varchar", length=512, index=true)
	@Getter @Setter
	private String refObj;

	@Column(description="알림 대상 여부", type="varchar", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean notification;
	
	@Column(description="노출 여부", type="varchar", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean show;
	
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Transient
	@Getter @Setter
	private Object obj;
	
	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Transient
	@Getter @Setter
	private boolean subscribedTaskNotification;
	
	@Column(description="엑티비티 메시지", type="varchar", length=512, index=true)
	@Getter @Setter
	private String message;
	
	@Column(description="해당 엑티비티 링크 주소", type="varchar", length=256, index=true)
	@Getter @Setter
	private String linkURL;

	@Transient
	@Getter @Setter
	private Object syncEntity;
	
	@Column(description="메시지 구성 파라미터", type="varchar", length=8192)
	private String[] msgParams;
	public void setMsgParams(String... msgParams) {
		this.msgParams = msgParams;
	}
	public String[] getMsgParams() {
		if (msgParams != null) {
			List<String> params = new ArrayList<String>();
			if ((ActivityKind.TASK_TIMELINES.equals(activityKind) || ActivityKind.TASK_TIMELINE_COMMENTS.equals(activityKind))) {
				if (msgParams.length == 4) { 
					params.add(msgParams[0]);								// user
					params.add(msgParams[1]);								// description
					params.add(msgParams[2]);								// task
					params.add(msgParams[3]);								// board
					params.add(ActivityService.getTaskStage(getTaskId()));	// task stage
					return params.toArray(new String[0]);
				}
			}
			if (ActivityKind.TASKS.equals(activityKind) && ActivityType.UPDATE_WIKI.equals(activityType)) {
				if (msgParams.length == 3) {
					params.add(msgParams[0]);								// user
					params.add(msgParams[1]); 								// task
					params.add(msgParams[2]);								// board
					params.add(ActivityService.getTaskStage(getTaskId()));	// task stage
					return params.toArray(new String[0]);
				}
			}
			if (ActivityKind.TASK_CHECKLISTS.equals(activityKind)) {
				if (msgParams.length == 4) {
					params.add(msgParams[0]);								// user
					params.add(msgParams[1]); 								// checklist
					params.add(msgParams[2]); 								// task
					params.add(msgParams[3]);								// board
					params.add(ActivityService.getTaskStage(getTaskId()));	// task stage
					return params.toArray(new String[0]);
				}
			}
		}
		
		// current version
		return msgParams;
	}
	
	@Override
	public Text getDescription() {
		Text desc = super.getDescription();
		if ((desc == null || StringUtils.isBlank(desc.getValue()))
				&& ActivityKind.TASK_TIMELINES.equals(activityKind) || ActivityKind.TASK_TIMELINE_COMMENTS.equals(activityKind)) {
			if (msgParams != null && msgParams.length == 4 && StringUtils.isNotBlank(msgParams[1])) {
				desc = new Text(msgParams[1]);
			}
		}
		return new Text(HtmlUtil.ellipsis(desc));
	}
	
	@Transient
	@Getter @Setter
	private List<String> notificationUserIds;
	
	@Column(description="맨션 대상 사용자 아이디 목록", type="varchar", length=512)
	@Setter
	private List<String> mentionIds;
	public List<String> getMentionIds() {
		if (mentionIds == null) { return new ArrayList<String>(); }
		return mentionIds;
	}
	
	@Column(description="맨션 대상 사용자 이름", type="varchar", length=256, index=true)
	public String getMentionedUserNames() {
		return ActivityService.getMentionedUserNames(getMentionIds());
	}
	
	@Transient
	@Getter @Setter
	private Boolean read;
	
	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private Text content;
	
	@Column(description="엑티비티 아이디", type="varchar", length=16, primary=true, index=true, notnull=true)
	public String getActivityId() {
		return super.getKeyStr();
	}
	public void setActivityId(String activityId) {
		super.setKeyStr(activityId);
	}
	
	public Activities() {}

	public Activities(ActivityKind activityKind, ActivityType activityType, String kindId, String creator) {
		this.activityKind = activityKind;
		this.activityType = activityType;
		this.kindId = kindId;
		this.setCreator(creator);
	}
	public Activities(Groups group, ActivityType activityType, Users loginUser) {
		this.setCreated(new Date());
		this.domainId = group.getDomainId();
		this.kindId = group.getGroupId();
		this.setTitle(group.getTitle());
		//this.setDescription(board.getDescription());
		this.activityKind = ActivityKind.GROUPS;
		this.activityType = activityType;
		this.setCreator(loginUser==null?group.getCreator():loginUser.getUserId());
	}
	public Activities(Boards board, ActivityType activityType, Users loginUser) {
		this.obj = board;
		this.setCreated(new Date());
		this.domainId = board.getDomainId();
		this.boardId = board.getBoardId();
		this.kindId = board.getBoardId();
		this.setTitle(board.getTitle());
		//this.setDescription(board.getDescription());
		this.activityKind = ActivityKind.BOARDS;
		this.activityType = activityType;
		this.setCreator(loginUser==null?board.getCreator():loginUser.getUserId());
	}
	public Activities(Events event, ActivityType activityType, Users loginUser) {
		this.setCreated(new Date());
		this.domainId = event.getDomainId();
		this.boardId = event.getBoardId();
		this.taskId = event.getTaskId();
		this.kindId = event.getEventId();
		this.setTitle(event.getTitle());
		this.setDescription(event.getDescription());
		this.activityKind = ActivityKind.SCHEDULE;
		this.activityType = activityType;
		this.setCreator(loginUser==null?event.getCreator():loginUser.getUserId());
	}
	public Activities(Tasks task, ActivityType activityType, Users loginUser) {
		this.obj = task;
		this.setCreated(new Date());
		this.domainId = task.getDomainId();
		this.boardId = task.getBoardId();
		this.taskId = task.getTaskId();
		this.kindId = task.getTaskId();
		this.setTitle(task.getTitle());
		this.setDescription(task.getDescription());
		this.activityKind = ActivityKind.TASKS;
		this.activityType = activityType;
		this.setCreator(loginUser==null?task.getCreator():loginUser.getUserId());
	}
//	@Deprecated
//	public Activities(TaskComments taskComment, ActivityType activityType, Users loginUser) {
//		this.setCreated(new Date());
//		this.domainId = taskComment.getDomainId();
//		this.boardId = taskComment.getBoardId();
//		this.taskId = taskComment.getTaskId();
//		this.kindId = taskComment.getTaskCommentId();
//		this.setTitle(taskComment.getTitle());
//		this.setDescription(taskComment.getDescription());
//		this.activityKind = ActivityKind.TASK_COMMENTS;
//		this.activityType = activityType;
//		this.setCreator(loginUser==null?taskComment.getCreator():loginUser.getUserId());
//	}
	public Activities(Users user, ActivityType activityType) {
		this.setCreated(new Date());
		this.domainId = KeyUtil.createDomainKeyString(user.getDomainName());
		this.boardId = null;
		this.kindId = user.getUserId();
		this.activityKind = ActivityKind.USERS;
		this.activityType = activityType;
		this.setCreator(user.getUserId());
	}
	public Activities(Notice notice, ActivityType activityType, Users loginUser) {
		this.setCreated(new Date());
		this.domainId = notice.getDomainId();
		this.boardId = notice.getNoticeKind().equals(NoticeKind.BOARDS)?notice.getKindId():null;
		this.kindId = notice.getObjectId();
		this.setTitle(notice.getTitle());
		this.setDescription(notice.getDescription());
		this.activityKind = ActivityKind.NOTICE;
		this.activityType = activityType;
		this.setCreator(loginUser==null?notice.getCreator():loginUser.getUserId());
	}
	public Activities(TaskChecklists taskChecklist, ActivityType activityType, Users loginUser) {
		this.setCreated(new Date());
		this.domainId = taskChecklist.getDomainId();
		this.boardId = taskChecklist.getBoardId();
		this.taskId = taskChecklist.getTaskId();
		this.kindId = taskChecklist.getTaskChecklistId();
		this.setTitle(taskChecklist.getTitle());
		this.activityKind = ActivityKind.TASK_CHECKLISTS;
		this.activityType = activityType;
		this.setCreator(loginUser==null?taskChecklist.getCreator():loginUser.getUserId());
	}
//	@Deprecated
//	public Activities(TaskChecklistComments taskChecklistComment, ActivityType activityType, Users loginUser) {
//		this.setCreated(new Date());
//		this.domainId = taskChecklistComment.getDomainId();
//		this.boardId = taskChecklistComment.getBoardId();
//		this.taskId = taskChecklistComment.getTaskId();
//		this.kindId = taskChecklistComment.getTaskChecklistCommentId();
//		this.setTitle(taskChecklistComment.getTitle());
//		this.setDescription(taskChecklistComment.getDescription());
//		this.activityKind = ActivityKind.TASK_CHECKLIST_COMMENTS;
//		this.activityType = activityType;
//		this.setCreator(loginUser==null?taskChecklistComment.getCreator():loginUser.getUserId());
//	}
	public Activities(TaskTimelines taskTimelines, ActivityType activityType, Users loginUser) {
		this.setCreated(new Date());
		this.domainId = taskTimelines.getDomainId();
		this.boardId = taskTimelines.getBoardId();
		this.taskId = taskTimelines.getTaskId();
		this.kindId = taskTimelines.getTaskTimelineId();
		this.taskTimelineId = taskTimelines.getTaskTimelineId();
		this.setTitle(taskTimelines.getTitle());
		this.setDescription(taskTimelines.getDescription());
		this.activityKind = ActivityKind.TASK_TIMELINES;
		this.activityType = activityType;
		this.setCreator(loginUser==null?taskTimelines.getCreator():loginUser.getUserId());
		this.mentionIds = taskTimelines.getMentionIds();
	}
	public Activities(TaskTimelineComments taskTimelineComment, ActivityType activityType, Users loginUser) {
		this.setCreated(new Date());
		this.domainId = taskTimelineComment.getDomainId();
		this.boardId = taskTimelineComment.getBoardId();
		this.taskId = taskTimelineComment.getTaskId();
		this.kindId = taskTimelineComment.getTaskTimelineCommentId();
		this.taskTimelineId = taskTimelineComment.getTaskTimelineId();
		this.taskTimelineCommentId = taskTimelineComment.getTaskTimelineCommentId();
		this.setTitle(taskTimelineComment.getTitle());
		this.setDescription(taskTimelineComment.getDescription());
		this.activityKind = ActivityKind.TASK_TIMELINE_COMMENTS;
		this.activityType = activityType;
		this.setCreator(loginUser==null?taskTimelineComment.getCreator():loginUser.getUserId());
		this.mentionIds = taskTimelineComment.getMentionIds();
	}
	public Activities(Usage usage, ActivityType activityType) {
		this.setCreated(new Date());
		this.domainId = usage.getDomainId();
		this.kindId = usage.getUsageId();
		this.activityKind = ActivityKind.USAGE;
		this.activityType = activityType;
	}

	public static class ActivityData {
		@Getter @Setter
		private Object oldEntity;
		@Getter @Setter
		private Object newEntity;

		public ActivityData(Object oldEntity, Object newEntity) {
			this.oldEntity = oldEntity;
			this.newEntity = newEntity;
		}
	}
}
