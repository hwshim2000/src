package net.forecs.coconut.entity.activity;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="Notifications"
	, description="알림"
	, pkConstraint="CONSTRAINT pk_notificationId PRIMARY KEY (notificationId)"
	, fkConstraints={"CONSTRAINT fk_activityId FOREIGN KEY (activityId) REFERENCES Activities(activityId)"
		, "CONSTRAINT fk_userId FOREIGN KEY (userId) REFERENCES Users(userId)"}
	, references={"Users", "Activities"})
@Entity
public class Notifications extends Common {
	private static final long serialVersionUID = 550909478753433042L;
	
	@Column(description="알림 대상 액티비티 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String activityId;
	
	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="보드 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String boardId;
	
	@Column(description="태스크 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String taskId;
	
	@Column(description="사용자 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String userId;
	
	@Column(description="액티비티 종류(Domains/Groups/Boards/...)", type="varchar", length=16, index=true)
	@Getter @Setter
	private ActivityKind activityKind;
	
	@Column(description="액티비티 타입(ADDED/DELETED/UPDATED/...)", type="varchar", length=16, index=true)
	@Getter @Setter
	private ActivityType activityType;
	
	@Column(description="액티비티 해당 객체 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String kindId;
	
	@Column(description="타임라인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String taskTimelineId;
	
	@Column(description="타임라인 코멘트 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String taskTimelineCommentId;
//	@Getter @Setter
//	private String refObj;
	
	@Column(description="읽음 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private boolean read;
	
	@Column(description="맨션 여부", type="bool", length=1, index=true, defaultValue="FALSE")
	@Getter @Setter
	private Boolean mention;
	
//	@JsonIgnore
//	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
//	@Getter @Setter
//	private String message;
//	@Getter @Setter
//	private String linkURL;

//	@Transient
//	@Getter @Setter
//	private Object syncEntity;
	
//	@Getter
//	private String[] msgParams;
//	public void setMsgParams(String... msgParams) {
//		this.msgParams = msgParams;
//	}
	
	public Notifications() {}

	public Notifications(Activities activity, String notificationUserId) {
		this.setKey(KeyUtil.createNotificationKey(notificationUserId));
		this.activityId = activity.getActivityId();
		this.domainId = activity.getDomainId();
		this.boardId = activity.getBoardId();
		this.taskId = activity.getTaskId();
		this.userId = notificationUserId;
		this.activityKind = activity.getActivityKind();
		this.activityType = activity.getActivityType();
//		this.refObj = activity.getRefObj();
		this.setCreated(activity.getCreated());
//		this.setModified(activity.getModified());
//		this.setCreator(activity.getCreator());
		this.kindId = activity.getKindId();
		this.taskTimelineId = activity.getTaskTimelineId();
		this.taskTimelineCommentId = activity.getTaskTimelineCommentId();
//		this.setTitle(activity.getTitle());
//		this.setDescription(activity.getDescription());
//		this.message = activity.getMessage();
//		this.linkURL = activity.getLinkURL();
//		this.msgParams = activity.getMsgParams();
		this.mention = activity.getMentionIds().contains(notificationUserId);
	}
	
	@Column(description="알림 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getNotificationId() {
		return super.getKeyStr();
	}
	public void setNotificationId(String notificationId) {
		super.setKeyStr(notificationId);
	}
}