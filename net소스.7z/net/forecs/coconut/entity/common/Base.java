package net.forecs.coconut.entity.common;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.schema.Column;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


@Entity
@MappedSuperclass
public abstract class Base implements Serializable {
	private static final long serialVersionUID = -4253684456885178147L;
	protected static final String Y = "Y";
	protected static final String N = "N";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(fetch = FetchType.EAGER)
	@Getter @Setter
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Key key;

	@Column(description="생성일", type="datetime", length=16, index=true, notnull=true, defaultValue="GETDATE()" )
	@Getter @Setter
	private Date created = new Date();
	
	@Column(description="생성자", type="varchar", length=32, index=true, notnull=true )
	@Getter
	private String creator;
	public void setCreator(String creator) {
		this.creator = creator;
		owner = creator;	// Creator is owner.
	}

	@Column(description="소유자", type="varchar", length=32, index=true)
	@Getter @Setter
	private String owner;
	
	@Column(description="수정일", type="datetime", length=16, index=true)
	@Setter
	private Date modified;
	
	public Date getModified() {
		if (CalendarUtil.equals(created, modified)) {
			return null;
		}
		return modified;
	}
	
	@Column(description="삭제여부", type="varchar", length=1, index=true, notnull=true, defaultValue="N" )
	@Getter @Setter
	private String deleteYN = N;
	
	@Column(description="삭제일", type="datetime", length=16, index=true)
	@Getter @Setter
	private Date deleted;

	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	protected String getKeyStr() {
		return key != null ? KeyFactory.keyToString(key) : null;
	}
	
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	protected void setKeyStr(String str) {
		if (StringUtils.isNotEmpty(str)) {
			key = KeyFactory.stringToKey(str);
		}
	}
	
	@Column(description="객체아이디(해당 Schema의 ID)", type="varchar", length=32 )
	public String getObjectId() {
		return getKeyStr();
	}
	public void setObjectId(String objectId) {
		setKeyStr(objectId);
	}

	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public boolean isOwner(String userId) {
		if (StringUtils.isEmpty(owner)) {
			return !StringUtils.isEmpty(creator) && creator.equals(userId);
		} else {
			return owner.equals(userId);
		}
	}
}
