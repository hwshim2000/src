package net.forecs.coconut.entity.common;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public final class EMF {
	private static final EntityManagerFactory emfInstance = Persistence
			.createEntityManagerFactory("default");
//	private static final EntityManagerFactory emfInstanceEventualReads = Persistence
//			.createEntityManagerFactory("eventual-reads-short-deadlines");
//	private static final EntityManagerFactory emfInstanceTransactionsOptional = Persistence
//			.createEntityManagerFactory("transactions-optional");

	private EMF() {
	}

	public static EntityManagerFactory get() {
		return emfInstance;
	}
//	public static EntityManagerFactory getEventualReads() {
//		return emfInstanceEventualReads;
//	}
//	public static EntityManagerFactory getTransactionsOptional() {
//		return emfInstanceTransactionsOptional;
//	}
}