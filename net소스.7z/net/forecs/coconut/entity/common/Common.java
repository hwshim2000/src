package net.forecs.coconut.entity.common;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;

import com.google.appengine.api.datastore.Text;


@Entity
@MappedSuperclass
public class Common extends Base {
	private static final long serialVersionUID = -2064252665235312486L;

	@Column(description="제목", type="varchar", length=512, index=true )
	@Getter @Setter
	private String title;
	
	@Column(description="요약", type="varchar", length=1024 )
	@Getter @Setter
	private String summary;

	@Column(description="내용", type="clob", index=true )
	private Text description;
	public void setDescription(Text description) {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		this.description = description;
	}
	public Text getDescription() {
		if ((description == null) || (description.getValue() == null)) description = new Text("");
		return description;
	}

	@Column(description="보관여부", type="varchar", length=1, defaultValue="N", index=true )
	@Getter @Setter
	private String archiveYN = N;
	
	@Column(description="보관일시", type="datetime", length=16, index=true )
	@Getter @Setter
	private Date archived;
	
	@Column(description="영구삭제 여부", type="varchar", length=1, defaultValue="N" )
	@Getter @Setter
	private String permanentDeleteYN = N;
}