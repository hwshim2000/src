package net.forecs.coconut.entity.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import lombok.Getter;

public class SearchResponse<T> implements Serializable {

	private static final long serialVersionUID = -7908736171907022300L;

	@Getter
	private Collection<T> items = new ArrayList<T>();
	
	@Getter
	private String nextPageToken = null;;
	
	@Getter 
	Long totalCount = 0L;
	
	public static <T> Builder<T>  builder() {
		return new Builder<T>();
	}
	
	public static class Builder<T> {
		private List<T> items;
		private String nextPageToken;
		Long totalCount;
		
		public Builder<T> setItems(List<T> items) {
			this.items = items;
			return this;
		}
		public Builder<T> setNextPageToken(String nextPageToken) {
			this.nextPageToken = nextPageToken;
			return this;
		}
		public Builder<T> setTotalCount(Long totalCount) {
			this.totalCount = totalCount;
			return this;
		}
		
		public SearchResponse<T> build() {
			SearchResponse<T> sr = new SearchResponse<T>();
			sr.items = this.items;
			sr.nextPageToken = this.nextPageToken;
			sr.totalCount = this.totalCount;
			return sr;
		}
	}
}

