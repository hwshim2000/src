package net.forecs.coconut.entity.search;

import java.io.Serializable;
import java.util.Date;

import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.search.index.AttachmentIndex;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;

public class Attachment implements Serializable {
	private static final long serialVersionUID = -4596947144190806178L;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private AttachmentIndex index;
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	private Attachments attachment;
	
	public String getAttachmentId() {
		return index.getAttachmentId();
	}
	public String getBoardId() {
		return index.getBoardId();
	}
	public String getTaskId() {
		return index.getTaskId();
	}
	public String getKindId() {
		return index.getKindId();
	}
	public String getKind() {
		return index.getKind();
	}
	public String getCreator() {
		return attachment.getCreator();
	}
	public String getOwner() {
		return attachment.getOwner();
	}
	public Date getCreated() {
		return attachment.getCreated();
	}
	public Date getModified() {
		return attachment.getModified();
	}
	public long getFileSize() {
		return attachment.getFileSize();
	}
	public String getFilePath() {
		return attachment.getFilePath();
	}
	public String getFileName() {
		return attachment.getFileName();
	}
	public String getMimeType() {
		return attachment.getMimeType();
	}
	
	public Attachment(AttachmentIndex index, Attachments attachment) {
		this.index = index;
		this.attachment = attachment;
	}
}
