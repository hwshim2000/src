package net.forecs.coconut.entity.survey;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.QuestionItemType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.google.appengine.api.datastore.Text;

@Schema(name="SurveyAnswers"
, description="설문조사답변"
, pkConstraint="CONSTRAINT pk_surveyAnswerId PRIMARY KEY (surveyAnswerId)"
, fkConstraints={"CONSTRAINT fk_surveyQuestionId FOREIGN KEY (surveyQuestionId) REFERENCES SurveyQuestions(surveyQuestionId)"
		, "CONSTRAINT fk_surveyItemId FOREIGN KEY (surveyItemId) REFERENCES SurveyItems(surveyItemId)" }
, references={"SurveyQuestions", "SurveyItems"})
@Entity
public class SurveyAnswers extends Common {
	private static final long serialVersionUID = 4299515325150818820L;

	@Column(description="부모 설문항목 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String parentId;
	
	@Column(description="설문항목 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String surveyItemId;
	
	@Column(description="설문조사 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String surveyQuestionId;
	
	@Column(description="설문항목타입", type="varchar", length=8, index=true)
	@Getter @Setter
	private QuestionItemType type;
	
	@Column(description="설문답변자이메일", type="varchar", length=32, index=true)
	@Getter @Setter
	private String email;
	
	@Column(description="설문조사 답변 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getSurveyAnswerId() {
		return super.getKeyStr();
	}

	public void setSurveyAnswerId(String surveyAnswerId) {
		super.setKeyStr(surveyAnswerId);
	}
	
	public SurveyAnswers() { }
	public SurveyAnswers(String surveyAnswerId, Text description, SurveyItems item, String email, String userId) {
		setSurveyQuestionId(item.getSurveyQuestionId());
		setParentId(item.getParentId());
		setSurveyItemId(item.getSurveyItemId());
		setSurveyAnswerId(surveyAnswerId);
		setDescription(description);
		setEmail(email);
		setCreator(userId);
		setType(item.getType());
	}
}
