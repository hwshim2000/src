package net.forecs.coconut.entity.survey;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="SurveyQuestions"
, description="설문조사"
, pkConstraint="CONSTRAINT pk_surveyQuestionId PRIMARY KEY (surveyQuestionId)")
@Entity
public class SurveyQuestions extends Common {
	private static final long serialVersionUID = 6442010387574677863L;

	/**
	 * @Description : 사이트 전체의 설문조사는 AdminAPI를 통해서만 생성하도록 하고, default namespace에 저장되도록 한다.
	 * 이외의, 설문조사는 해당 도메인의 영역에서 관리, kindId를 분석하여 해당 도메인의 kind 값을 넣는다.
	 * Domains/Groups/Boards/Tasks/TaskTimelines/... 
	 */
	@Column(description="설문영역(null or site는 사이트 전체에 설문조사, 이외의 영역은 해당 도메인에서의 설문조사)", type="varchar", length=16, index=true)
	@Getter @Setter
	private String surveyKind;
	
	@Column(description="설문영역  아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String kindId;
	
	@Column(description="시작일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date startDate;
	
	@Column(description="종료일", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date endDate;
	
	@Column(description="노출여부", type="varchar", length=1, index=true)
	@Getter @Setter
	private String displayYN = Y;
	
	@Column(description="수정가능여부", type="bool", length=1, index=true, defaultValue="true")
    @Getter @Setter
    private boolean changePermit;
	
	@Transient
	@Getter @Setter
	private List<SurveyItems> surveyItems;
	
	@Column(description="설문조사 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getSurveyQuestionId() {
		return super.getKeyStr();
	}

	public void setSurveyQuestionId(String surveyQuestionId) {
		super.setKeyStr(surveyQuestionId);
	}
}
