package net.forecs.coconut.entity.survey;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.QuestionItemType;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="SurveyItems"
, description="설문조사항목"
, pkConstraint="CONSTRAINT pk_surveyItemId PRIMARY KEY (surveyItemId)"
, fkConstraints="CONSTRAINT fk_surveyQuestionId FOREIGN KEY (surveyQuestionId) REFERENCES SurveyQuestions(surveyQuestionId)"
, references="SurveyQuestions")
@Entity
public class SurveyItems extends Common {
	private static final long serialVersionUID = -1231874577546361156L;

	@Column(description="부모 설문항목 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String parentId;
	
	@Column(description="설문조사 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String surveyQuestionId;
	
	@Column(description="정렬 순서", type="numeric", length=8, index=true)
	@Getter @Setter
	private Integer ordernum;
	
	@Transient
	@Column(description="참여수", type="numeric", length=16, index=true)
	@Getter @Setter
	private Integer count;
	
	@Column(description="설문항목타입", type="varchar", length=8, index=true)
	@Getter @Setter
	private QuestionItemType type = QuestionItemType.RADIO;
	
	@Column(description="필수여부", type="bool", length=1, index=true, defaultValue="true")
    @Getter @Setter
    private boolean require;
	
	@Transient
	@Getter @Setter
	private List<SurveyAnswers> answers;
	
	@Transient
	@Getter @Setter
	private List<SurveyItems> childs;
	
	public void appendChild(SurveyItems item) {
		if (childs == null) { childs = new ArrayList<SurveyItems>(); }
		childs.add(item);
	}
	@Column(description="설문조사 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getSurveyItemId() {
		return super.getKeyStr();
	}

	public void setSurveyItemId(String surveyItemId) {
		super.setKeyStr(surveyItemId);
	}
}
