package net.forecs.coconut.entity.board;

//import javax.persistence.Entity;

@Deprecated
//@Entity
public class BoardInvites /*extends Base*/ {
//	private static final long serialVersionUID = -9219948591570519726L;
//
//	@Getter @Setter
//	private String domainId;
//	@Getter @Setter
//	private String boardId;
//	@Getter @Setter
//	private String userId;
//	@Getter @Setter
//	private Date expirationStartDate;
//	@Getter @Setter
//	private Date expirationEndDate;
//	@Getter @Setter
//	private String inviteEmail;
//	@Getter @Setter
//	private String inviteName;
//	@Getter @Setter
//	private String confirmYN = N;
//	@Getter @Setter
//	private Date confirmed;
//	
//	public String getBoardInviteId() {
//		return super.getKeyStr();
//	}
//
//	public void setBoardInviteId(String boardInviteId) {
//		super.setKeyStr(boardInviteId);
//	}
}
