package net.forecs.coconut.entity.board;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.CreateNoticeAuth;
import net.forecs.coconut.common.code.CreateScheduleAuth;
import net.forecs.coconut.common.code.CreateTaskAuth;
import net.forecs.coconut.common.code.PublicSearchRange;
import net.forecs.coconut.common.code.TaskStage;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.tasklist.Tasklists;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Text;

@Schema(name="Boards"
	, description="보드"
	, pkConstraint="CONSTRAINT pk_boardId PRIMARY KEY (boardId)"
	, fkConstraints={"CONSTRAINT fk_domainId FOREIGN KEY (domainId) REFERENCES Domains(domainId)",
		"CONSTRAINT fk_groupId FOREIGN KEY (groupId) REFERENCES Groups(groupId)"}
	, references = {"Domains", "Groups"} )
@Entity
public class Boards extends Common {
	private static final long serialVersionUID = -9193523149326849070L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="그룹 아이디", type="varchar", length=32, index=true, notnull=true, foreign=true)
	@Getter @Setter
	private String groupId;

	@Column(description="정렬 순서", type="numeric", length=8, index=true)
	@Getter @Setter
	private Integer ordernum;
	
	/** size limit : 512kb */
	@Deprecated
	private Text boardLogo;
	@Deprecated
	public void setBoardLogo(Text boardLogo) {
		if ((boardLogo == null) || (boardLogo.getValue() == null)) boardLogo = new Text("");
		this.boardLogo = boardLogo;
	}
	@Deprecated
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	public Text getBoardLogo() {
		if ((boardLogo == null) || (boardLogo.getValue() == null)) boardLogo = new Text("");
		return boardLogo;
	}
	
//	public String getBoardLogoURL() {
//		if (boardLogo != null && StringUtils.isNotBlank(boardLogo.getValue())) {
//			return String.format("%s?domainName=%s&boardId=%s", CommonProperty.USER_PICTURE_URL, this.getKey().getNamespace(), getBoardId());
//		} else {
//			return null;
//		}
//	}

	@Column(description="기본 보드 여부", type="varchar", length=1, index=true, defaultValue="N" )
	@Getter @Setter
	private String defaultYN = N;
	
	@Column(description="보드 공개 여부", type="varchar", length=1, index=true, defaultValue="N" )
	@Getter @Setter
	private String closeYN = N;
	
	@Column(description="보드 검색 공개 범위(BOARD/DOMAIN)", type="varchar", length=8, index=true, defaultValue="BOARD" )
	@Getter @Setter
	private PublicSearchRange publicSearchRange = PublicSearchRange.BOARD;
	
	@Column(description="공지 생성 권한(OWNER/MEMBER)", type="varchar", length=8, index=true, defaultValue="OWNER" )
	@Getter @Setter
	private CreateNoticeAuth createNoticeAuth = CreateNoticeAuth.OWNER;
	
	@Column(description="태스크 생성 권한(OWNER/MEMBER)", type="varchar", length=8, index=true, defaultValue="OWNER" )
	@Getter @Setter
	private CreateTaskAuth createTaskAuth = CreateTaskAuth.OWNER;
	
	@Column(description="일정 생성 권한(OWNER/MEMBER)", type="varchar", length=8, index=true, defaultValue="OWNER" )
	@Getter @Setter
	private CreateScheduleAuth createScheduleAuth = CreateScheduleAuth.OWNER;

	@Column(description="보드 테그 목록", type="varchar", length=4096 )
	private List<String> tags;
	public void setTags(List<String> tags) {
		if (tags == null) tags = new ArrayList<String>();
		this.tags = tags;
	}
	public List<String> getTags() {
		if (tags == null) tags = new ArrayList<String>();
		return tags;
	}

	@Transient
	@Deprecated
	private List<Tasklists> tasklists;
//	public void setTasklists(List<Tasklists> tasklists) {
//		if (tasklists == null) tasklists = new ArrayList<Tasklists>();
//		this.tasklists = tasklists;
//	}
	@Deprecated
	public List<Tasklists> getTasklists() {
		if (tasklists == null) tasklists = new ArrayList<Tasklists>();
		for (TaskStage taskStage : TaskStage.values()) {
			Tasklists tasklist = new Tasklists(getBoardId(), taskStage, getCreator());
			tasklists.add(tasklist);
		}
		
		return tasklists;
	}
	
	private Text stageOrder;
	public void setStageOrder(Text stageOrder) {
		if ((stageOrder == null) || (stageOrder.getValue() == null)) stageOrder = new Text("");
		this.stageOrder = stageOrder;
	}
	public Text getStageOrder() {
		if ((stageOrder == null) || (stageOrder.getValue() == null)) stageOrder = new Text("");
		return stageOrder;
	}
	
	@Column(description="보드 아이디", type="varchar", primary=true, length=32, index=true, notnull=true)
	public String getBoardId() {
		return super.getKeyStr();
	}

	public void setBoardId(String boardId) {
		super.setKeyStr(boardId);
	}
	
	public static void sort(List<Boards> list) {
		Collections.sort(list, new Comparator<Boards>() {
	        @Override
	        public int compare(Boards first, Boards second) {
	        	if (first.getOrdernum()==null && second.getOrdernum()==null) {
	        		return 0;
	        	} else if (first.getOrdernum()==null ) {
	        		return 1;
	        	} else if (second.getOrdernum()==null) {
	        		return -1;
	        	}
	        	
	        	if (first.getOrdernum() > second.getOrdernum()) {
	        		return 1;
	        	} else if (first.getOrdernum() < second.getOrdernum()) {
	        		return -1;
	        	} else {
	        		return 0;
	        	}
	        }
	    });
	}
}
