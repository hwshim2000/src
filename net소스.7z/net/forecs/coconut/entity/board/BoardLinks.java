package net.forecs.coconut.entity.board;


@Deprecated
//@Entity
public class BoardLinks /*extends Base*/ {
//	private static final long serialVersionUID = 2172643915006866569L;
//
//	@Getter @Setter
//	private String domainId;
//	private String boardId;
//	
//	private String guestId;
//	private Email guestEmail;
//	private String getName;
//	
//	private String linkUrl;
//	private String linkToken;
//	private String confirmYN;
//	private Date confirmed;
//	
//	
//	public String getBoardLinkId() {
//		return super.getKeyStr();
//	}
//
//	public void setBoardLinkId(String boardLinkId) {
//		super.setKeyStr(boardLinkId);
//	}
//
//	public String getBoardId() {
//		return boardId;
//	}
//
//	public void setBoardId(String boardId) {
//		this.boardId = boardId;
//	}
//
//	public String getGuestId() {
//		return guestId;
//	}
//
//	public void setGuestId(String guestId) {
//		this.guestId = guestId;
//	}
//
//	public Email getGuestEmail() {
//		return guestEmail;
//	}
//
//	public void setGuestEmail(Email guestEmail) {
//		this.guestEmail = guestEmail;
//	}
//
//	public String getGetName() {
//		return getName;
//	}
//
//	public void setGetName(String getName) {
//		this.getName = getName;
//	}
//
//	public String getLinkUrl() {
//		return linkUrl;
//	}
//
//	public void setLinkUrl(String linkUrl) {
//		this.linkUrl = linkUrl;
//	}
//
//	public String getLinkToken() {
//		return linkToken;
//	}
//
//	public void setLinkToken(String linkToken) {
//		this.linkToken = linkToken;
//	}
//
//	public String getConfirmYN() {
//		return confirmYN;
//	}
//
//	public void setConfirmYN(String confirmYN) {
//		this.confirmYN = confirmYN;
//	}
//
//	public Date getConfirmed() {
//		return confirmed;
//	}
//
//	public void setConfirmed(Date confirmed) {
//		this.confirmed = confirmed;
//	}
}
