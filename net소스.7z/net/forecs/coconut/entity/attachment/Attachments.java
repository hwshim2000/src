package net.forecs.coconut.entity.attachment;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.google.appengine.api.datastore.Link;

@Schema(name="Attachments"
	, description="첨부 파일 목록"
	, pkConstraint="CONSTRAINT pk_attachmentId PRIMARY KEY (attachmentId)"
	, references="AttachmentsMap")
@Entity
public class Attachments extends Common {
	private static final long serialVersionUID = 2771693627898104753L;

	@Column(description="도메인 아이디", type="varchar", length=32, index=true)
	@Getter @Setter
	private String domainId;
	
	@Column(description="파일 저장 기본 경로(위치) 구글의 bucket", type="varchar", length=32, index=true)
	@Getter @Setter
	private String bucket;
	
	@Column(description="파일 경로", type="varchar", length=512, index=true)
	@Getter @Setter
	private String filePath;
	
	@Column(description="파일명", type="varchar", length=256, index=true)
	@Getter @Setter
	private String fileName;
	
	@Column(description="파일 사이즈", type="numeric", length=16, index=true)
	@Getter @Setter
	private long fileSize;
	
	@Column(description="파일 타입", type="varchar", length=16, index=true)
	@Getter @Setter
	private String mimeType;
	
	@Column(description="파일 접근 경로", type="varchar", length=512, index=true)
	@Getter @Setter
	private Link fileUrl;
	
	@Column(description="다운로드 수", type="numeric", length=16, index=true)
	@Getter @Setter
	private int downloads;
	
	@Column(description="업로드 형태", type="varchar", length=8, index=true)
	@Getter @Setter
	private String uploadType;

	@Column(description="파일 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getAttachmentId() {
		return super.getKeyStr();
	}
	public void setAttachmentId(String attachmentId) {
		super.setKeyStr(attachmentId);
	}
}
