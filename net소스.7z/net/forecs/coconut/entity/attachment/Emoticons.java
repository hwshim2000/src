package net.forecs.coconut.entity.attachment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.server.spi.config.AnnotationBoolean;
import com.google.api.server.spi.config.ApiResourceProperty;
import com.google.appengine.api.datastore.Text;

@Schema(name="Emoticons"
	, description="이모티콘"
	, pkConstraint="CONSTRAINT pk_emoticonId PRIMARY KEY (emoticonId)"
	, references="Images")
@Entity
public class Emoticons extends Common {
	private static final Logger LOG = Logger.getLogger(Emoticons.class);
	private static final long serialVersionUID = -4440642932310726173L;
	
	@Column(description="서비스 등급", type="varchar", length=8, index=true)
	@Getter @Setter
	private String serviceLevel;
	
	@Column(description="만료일시", type="datetime", length=32, index=true)
	@Getter @Setter
	private Date expirationDate;	// 유효 기간
//	@Getter @Setter
//	private Integer price;	// 가격
	
	@Column(description="도메인명", type="varchar", length=16, index=true, defaultValue="COMMON")
	@Getter @Setter
	private String domainName = "COMMON";	// 사용가능 도메인
	
	@JsonIgnore
	@ApiResourceProperty(ignored = AnnotationBoolean.TRUE)
	@Getter @Setter
	private Text emoticonImages;
	
	public void setImages(List<Images> images) {
		if (images == null || images.size() == 0) {
			return;
		}
		
		try {
			ObjectMapper om = new ObjectMapper();
			Text emoticonImages = new Text(om.writeValueAsString(images));
			this.setEmoticonImages(emoticonImages);
		} catch (Exception ex) { LOG.warning(ex.getMessage()); }
	}
	
	public List<Images> getImages() {
		List<Images> images = new ArrayList<Images>();
		
		try {
			if (emoticonImages != null && emoticonImages.getValue() != null) {
				ObjectMapper om = new ObjectMapper();
				images = om.readValue(emoticonImages.getValue(), new TypeReference<ArrayList<Images>>(){});
			}
		} catch (Exception  ex) { LOG.warning(ex.getMessage()); }
		return images;
	}
	
//	@Transient
//	private List<Images> images;
//	public List<Images> getImages() {
//		if (images == null) images = new ArrayList<Images>();
//		return images;
//	}
//	public void setImages(List<Images> images) {
//		if (images == null) images = new ArrayList<Images>();
//		this.images = images;
//	}
	
	public Emoticons() {}
	public Emoticons(String title) {
		setTitle(title);
	}
	public Emoticons(String title, String serviceLevel, Date expirationDate) {
		setTitle(title);
		setServiceLevel(serviceLevel);
		setExpirationDate(expirationDate);
	}
	
	@Column(description="이모티콘 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getEmoticonId() {
		return super.getKeyStr();
	}
	
	public void setEmoticonId(String emoticonId) {
		super.setKeyStr(emoticonId);
	}
}
