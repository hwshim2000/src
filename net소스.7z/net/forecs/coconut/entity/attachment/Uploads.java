package net.forecs.coconut.entity.attachment;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Base;

@Schema(name="Uploads"
	, description="업로드 대상 목록(특정 시간이후 남아있는 파일 삭제하기 위해)"
	, pkConstraint="CONSTRAINT pk_uploadId PRIMARY KEY (uploadId)"
	, references="Attachments, Images")
@Entity
public class Uploads extends Base {
	private static final long serialVersionUID = 2145001929282184711L;
	
	@Column(description="도메인명", type="varchar", length=16, index=true, notnull=true, unique=true)
	@Getter @Setter
	private String domainName;
	
	@Column(description="파일 경로", type="varchar", length=512, index=true)
	@Getter @Setter
	private String filePath;
	
	@Column(description="업로드 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getUploadId() {
		return super.getKeyStr();
	}
	public void setUploadId(String uploadId) {
		super.setKeyStr(uploadId);
	}
}
