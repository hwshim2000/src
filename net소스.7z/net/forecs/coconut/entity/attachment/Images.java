package net.forecs.coconut.entity.attachment;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

import com.google.appengine.api.datastore.Link;

@Schema(name="Images"
	, description="이미지"
	, pkConstraint="CONSTRAINT pk_imageId PRIMARY KEY (imageId)"
	, references={"Users","TaskTimelines","TaskTimelineComments"})
@Entity
public class Images extends Common {
	private static final long serialVersionUID = -1839032558970623809L;
	
	@Column(description="부모 아이디(TaskTimelines/TaskTimelineComments/Users)", type="varchar", length=32, index=true)
	@Getter @Setter
	private String parentId;
	
	@Column(description="파일 저장 기본 경로(구글)", type="varchar", length=32, index=true)
	@Getter @Setter
	private String bucket;
	
	@Column(description="이미지 저장 경로", type="varchar", length=512, index=true)
	@Getter @Setter
	private String filePath;
	
	@Column(description="이미지명", type="varchar", length=256, index=true)
	@Getter @Setter
	private String fileName;
	
	@Column(description="이미지 사이즈", type="numeric", length=32, index=true)
	@Getter @Setter
	private long fileSize;
	
	@Column(description="이미지 타입", type="varchar", length=16, index=true)
	@Getter @Setter
	private String mimeType;
	
	@Column(description="이미지 접근 경로", type="varchar", length=512, index=true)
	@Getter @Setter
	private Link fileUrl;
	
	@Column(description="이미지 웹 경로", type="varchar", length=512, index=true)
	@Getter @Setter
	private String servingUrl;
	
	@Column(description="이미지 크기(가로세로중큰값)", type="varchar", length=16, index=true)
	@Getter @Setter
	private int imageSize; // 해상도
//	@Getter @Setter
//	private int downloads;
//	@Getter @Setter
//	private String uploadType;

	@Column(description="이미지 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	public String getImageId() {
		return super.getKeyStr();
	}
	public void setImageId(String imageId) {
		super.setKeyStr(imageId);
	}
}
