package net.forecs.coconut.entity.attachment;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.schema.Column;
import net.forecs.coconut.common.util.schema.Schema;
import net.forecs.coconut.entity.common.Common;

@Schema(name="AttachmentsMap"
		, description="첨부파일 매핑"
		, pkConstraint="CONSTRAINT pk_attachmentMapId PRIMARY KEY (attachmentMapId)"
		, fkConstraints="CONSTRAINT fk_attachmentId FOREIGN KEY (attachmentId) REFERENCES Attachments(attachmentId)"
		, references={"Attachments", "Tasks", "TaskTimelines", "Notice"})
@Entity
public class AttachmentsMap extends Common{
	private static final long serialVersionUID = -8042814567338696754L;

	@Column(description="파일 등록 객체 아이디(Tasks/TaskTimelines/Notice)", type="varchar", length=32, index=true)
	@Getter @Setter
	private String kindId;
	
	@Column(description="파일 아이디", type="varchar", length=32, primary=true, index=true, notnull=true)
	@Getter @Setter
	private String attachmentId;

	public AttachmentsMap() {}

	public AttachmentsMap(String parentId, String attachmentId) {
		this.kindId = parentId;
		this.attachmentId = attachmentId;
	}
}
