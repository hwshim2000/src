package net.forecs.coconut.common.sync;

import java.util.HashMap;
import java.util.Map;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.rest.JerseyRabbitMQClient;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Rbmq {
	private static final Logger LOG = Logger.getLogger(Rbmq.class.getName());
	/*
	 * 중요!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	 * 1. Erlang 설치
	 * *Erlang : 분산/병렬/동시성 프로그래밍을 지원하는 언어로 Concurrency Oriented Programming이라고도 함.
	 * > wget http://packages.erlang-solutions.com/erlang-solutions-1.0-1.noarch.rpm
	 * > rpm -Uvh erlang-solutions-1.0-1.noarch.rpm
	 * > yum install erlang -y
	 * 
	 * 2. RabbitMQ-Server 설치
	 * > wget https://www.rabbitmq.com/releases/rabbitmq-server/v3.6.1/rabbitmq-server-3.6.0-1.noarch.rpm
	 * > rpm --import https://www.rabbitmq.com/rabbitmq-signing-key-public.asc
	 * > yum install rabbitmq-server-3.6.1-1.noarch.rpm -y
	 * 
	 * 3. 서비스 등록
	 * > chkconfig rabbitmq-server on
	 * 
	 * 4. 방화벽 설정 혹은 제거
	 * 필요한 port [5672:server, 15672:management, 15674:ws/stomp, 15670:ws/stomp]
	 * > service iptables stop
	 * > service ip6tables stop
	 * 
	 * 5. 서비스 시작
	 * > service rabbitmq-server [start/stop/restart]
	 * 
	 * 6. 사용자 등록(guest/guest)는 localhost만 허용되므로...[rabbitmqctl 실행 명령 참조]
	 * > rabbitmqctl [command] [userid] [password]
	 * > rabbitmqctl add_user admin admin
	 * > rabbitmqctl add_user rabbitmq rabbitmq
	 * > rabbitmqctl set_user_tags admin administrator
	 * > rabbitmqctl set_user_tags rabbitmq administrator
	 * serverip:15672 로 접속
	 * admin에서  can access virtual hosts 항목을 enable 해주어야 한다.
	 * 
	 * 7. plugin enable 설정
	 * [Management]
	 * > rabbitmq-plugins enable rabbitmq_management
	 * [WebStomp]
	 * > rabbitmq-plugins enable web_stomp
	 * [WebStom_examples]
	 * > rabbitmq-plugins enable web_stomp_examples
	 * > http://host:15670/ 으로 접속하면 테스트할 수 있음
	 * > 참고로 CentOS에서 설치를 하면 아래의 경로에 소스가 있음
	 * /var/lib/rabbitmq/mnesia/rabbit@localhost-plugins-expand/rabbitmq_web_stomp_examples-3.6.1/priv
	 * 위경로에서 테스트를 할려면 외부에서 접속할 경우 신규 유저를 등록한후 변경하여 사용하면 됨
	 * > vi echo.html
	 * client.connect('guest', 'guest', on_connect, on_error, '/'); -> client.connect('rabbitmq', 'rabbitmq', on_connect, on_error, '/');
	 * 
	 * 8. 서비스 재시작(필요하면)
	 * 에를 들어, rabbitMQ의 exchange type이 첫번째 정해지면, 서버 재 기동전까지 같은 타입을 유지한다.
	 * 즉, 새로운 타입으로 변경하려면, 설정 변경 후에 재 시작해야 한다.
	 * > service rabbitmq-server restart
	 * 
	 * 8-1. Java Client Library를 사용할 수 있다. 하지만 Appengine에서는 newConnection() 생성시 thread 생성을 막아놨기에 사용 불가
	 * ************************************************************************************************
	 * 8-2. Appengine을 활용할 경우엔, Http API를 활용하여 메시지 전송하는 방법을 이용한다. 
	 * --> RabbitMQ Management HTTP API
	 * --> 참조 URL : http://hg.rabbitmq.com/rabbitmq-management/raw-file/rabbitmq_v3_1_1/priv/www/api/index.html
	 * ************************************************************************************************
	 * 8-3. command line interface 참조
	 * --> rabbitmqctl
	 * --> rabbitmqadmin
	 * --> rabbitmq-server
	 * --> rabbitmq-plugins
	 * 
	 * 9. /rabbitmq/echo.html 참조
	 * 10. test
	 * 10-1. 결정해야 할 사항들
	 * --> 도메인 별로 exchange명을 사용할 것인지( 이경우엔, exchange type을 direct 혹은 fanout로 사용 검토)
	 * --> exchange명은 고정 시키고, routing key를 도메인별로 할당하여 사용(이 경우에도, exchange type을 direct 혹은 fanout로 사용 검토)
	 * --> exchange명은 고정 시키고, routing key를 도메인과 activity type별로 할당 하여 사용. (이 경우엔, exchange type을 topic 또는 direct 사용 검토)
	 * 
	 */
	
	private final static String USERNAME = "rabbitmq";
	private final static String PASSWORD = "rabbitmq";
//	private final static String RABBITMQ_SERVER_ADDR = "192.168.187.135";	// Cluster Server
//	private final static String RABBITMQ_SERVER_ADDR = "104.199.153.202";	// COMPUTE Engine
	//private final static String RABBITMQ_SERVER_ADDR = "192.168.187.139";	// HAProxy Server
	private final static String RABBITMQ_SERVER_ADDR = "192.168.100.3";	// Private Development Server
	private final static int RABBITMQ_SERVER_PORT = 15672;
	
	public static String get(String urlStr) throws Exception {
		return JerseyRabbitMQClient.get(urlStr, USERNAME, PASSWORD);
//		return ApacheRabbitMQClient.get(urlStr, USERNAME, PASSWORD);
//		return NetRabbitMQClient.get(urlStr, USERNAME, PASSWORD);
	}
	
//	public static void publish(String exchangeName, String routingKey, Map<String, Object> entityMap) throws Exception {
//		String message = null;
//		if (entityMap != null) {
//			ObjectMapper om = new ObjectMapper();
//			message = om.writeValueAsString(entityMap);
//		}
//		publish(exchangeName, routingKey, message);
//	}
	
	public static void publish(String routingKey, Object obj) {
		try {
			publish("amq.direct", routingKey, obj);
		} catch (Exception ex) {
			LOG.warning("[rabbitMQ publish] : " + ex.getMessage());
		}
	}
	
	public static void publish(String routingKey, String message) {
		try {
			publish("amq.direct", routingKey, message);
		} catch (Exception ex) {
			LOG.warning("[rabbitMQ publish] : " + ex.getMessage());
		}
	}
	
	public static void publish(String exchangeName, String routingKey, Object obj) {
		try {
			String message = null;
			if (obj != null) {
				ObjectMapper om = new ObjectMapper();
				message = om.writeValueAsString(obj);
			}
			publish(exchangeName, routingKey, message);
		} catch (Exception ex) {
			LOG.warning("[rabbitMQ publish] : " + ex.getMessage());
		}
	}
	
	public static void publish(String exchangeName, String routingKey, String message) throws Exception {
		
		Map<String, Object> propertiesMap = new HashMap<String, Object>();
		
		propertiesMap.put("properties", new HashMap<String, String>());
		propertiesMap.put("routing_key",routingKey);
		propertiesMap.put("payload", message);
		propertiesMap.put("payload_encoding", "string");
		
		String urlStr = String.format("http://%s:%d/api/exchanges/%s/%s/publish", RABBITMQ_SERVER_ADDR, RABBITMQ_SERVER_PORT, "%2f", exchangeName);
		JerseyRabbitMQClient.post(urlStr, USERNAME, PASSWORD, propertiesMap);
//		ApacheRabbitMQClient.post(urlStr, USERNAME, PASSWORD, propertiesMap);
//		NetRabbitMQClient.post(urlStr, USERNAME, PASSWORD, propertiesMap);
	}
	
	public static void createExchange(String exchangeName) throws Exception {
		Map<String, Object> propertiesMap = new HashMap<String, Object>();
		
		propertiesMap.put("type", "fanout");
		propertiesMap.put("auto_delete", false);
		propertiesMap.put("durable", false);
		propertiesMap.put("internal", false);
		
		String urlStr = String.format("http://%s:%d/api/exchanges/%s/%s", RABBITMQ_SERVER_ADDR, RABBITMQ_SERVER_PORT, "%2f", exchangeName);
		JerseyRabbitMQClient.put(urlStr, USERNAME, PASSWORD, propertiesMap);
//		ApacheRabbitMQClient.put(urlStr, USERNAME, PASSWORD, propertiesMap);
//		NetRabbitMQClient.put(urlStr, USERNAME, PASSWORD, propertiesMap);
	}
	
	public static void removeExchange(String exchangeName) throws Exception {
		String urlStr = String.format("http://%s:%d/api/exchanges/%s/%s", RABBITMQ_SERVER_ADDR, RABBITMQ_SERVER_PORT, "%2f", exchangeName);
		JerseyRabbitMQClient.delete(urlStr, USERNAME, PASSWORD);
//		ApacheRabbitMQClient.delete(urlStr, USERNAME, PASSWORD);
//		NetRabbitMQClient.delete(urlStr, USERNAME, PASSWORD);
	}
	
/*	public static void main(String[] args) throws Exception {
		try {
			Map<String, Object> entityMap = new HashMap<String, Object>();
			entityMap.put("domainName", "MyDomain");
			entityMap.put("userId", "me");
			
			publish("MyDomain", entityMap);
			
			//createExchange("DomainName");
			//removeExchange("DomainName");
			
			//createExchange("WebStompTestFanout");
		} catch (Exception ex) {
			throw ex;
		}
	}*/
}
