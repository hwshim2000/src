package net.forecs.coconut.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.entity.domain.Departments;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.KeyFactory;

public class Dept implements Serializable {
	private static final long serialVersionUID = 8590259604479179502L;

	@Getter @Setter
	private String title;
	@Getter @Setter
	private String description;
	@Getter @Setter
	private String contact;
	@Getter @Setter
	private String parentDeptCode;
	@Getter @Setter
	private String deptCode;
	@Getter @Setter
	private String id;
	
	public Dept() {}
	public Dept(String title, String description, String contact, String parentDeptCode, String deptCode, String id) {
		this.title = title;
		this.description = description;
		this.contact = contact;
		this.parentDeptCode = parentDeptCode;
		this.deptCode = deptCode;
		this.id = id;
	}
	public Dept(String[] args) {
		int index = 0;
		this.title = args[index++];
		this.description = args[index++];
		this.contact = args[index++];
		this.parentDeptCode = args[index++];
		this.deptCode = args[index++];
		this.id = args[index++];
	}
	public Dept(Departments dept) {
		title = dept.getTitle();
		contact = dept.getContact();
		parentDeptCode = dept.getParentDeptCode();
		deptCode = dept.getDeptCode();
		if (dept.getDescription() != null) { description = dept.getDescription().getValue(); }
		if (StringUtils.isBlank(parentDeptCode) && StringUtils.isNotBlank(dept.getParentId())) {
			parentDeptCode = KeyFactory.stringToKey(dept.getParentId()).getName();
		}
		if (StringUtils.isBlank(deptCode) && StringUtils.isNotBlank(dept.getDepartmentId())) {
			deptCode = KeyFactory.stringToKey(dept.getDepartmentId()).getName();
		}
		if (StringUtils.isNotBlank(dept.getMemberId())) { id = KeyFactory.stringToKey(dept.getMemberId()).getName(); }
	}
	public String[] toArray() {
		return new String[] { title, description, contact, parentDeptCode, deptCode, id };
	}
	public static List<Dept> convertToDept(List<Departments> departments) {
		List<Dept> depts = new ArrayList<Dept>();
		for (Departments dept : departments) {
			depts.add(new Dept(dept));
		}
		return depts;
	}
	public static List<Departments> convertToDepartments(List<Dept> depts) {
		List<Departments> departments = new ArrayList<Departments>();
		for (Dept dept : depts) {
			departments.add(new Departments(dept));
		}
		return departments;
	}
//	
//	public static void main(String[] args) throws Exception {
//		Set<String> deptFilterPropes = new HashSet<String>();
//		
//		deptFilterPropes.add("domainId");
//		deptFilterPropes.add("deptCode");
//		
//		deptFilterPropes.add("title");
//		deptFilterPropes.add("description");
//		deptFilterPropes.add("creator");
//		deptFilterPropes.add("created");
//		deptFilterPropes.add("modified");
//		deptFilterPropes.add("deleteYN");
//		deptFilterPropes.add("archiveYN");
//		
//		SimpleBeanPropertyFilter deptFilter = SimpleBeanPropertyFilter.serializeAllExcept(deptFilterPropes);
//		
//		FilterProvider filters = new SimpleFilterProvider().addFilter("departmentFilter", deptFilter);
//				
//		ObjectMapper om = new ObjectMapper();
//		om.setSerializationInclusion(Include.NON_NULL);
//				
//		Departments dept = new Departments();
//		dept.setTitle("afafafaf");
//		dept.setCreator("afafafafafaf");
//		dept.setModified(new Date());
//		
//		System.out.println(om.writer(filters).writeValueAsString(dept));
//				
//	}
}
