package net.forecs.coconut.common;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class CountNotifications {
	@Getter @Setter
	List<CountInfo> CountInfos;
}
