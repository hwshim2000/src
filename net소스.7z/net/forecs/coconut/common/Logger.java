package net.forecs.coconut.common;

import java.util.logging.Level;

public final class Logger {

	/**
	 * Instance of the real logger object.
	 */
	private final java.util.logging.Logger realLogger;

	/**
	 * Obtain a new or existing Logger instance.
	 * 
	 * @param name
	 *            Name of the logger, package names are recommended
	 */
	public static Logger getLogger(String name) {
		return new Logger(name);
	}
	public static Logger getLogger(Class<?> clazz) {
		return new Logger(clazz.getName());
	}

	// public static void configure(String filename) {
	// FileInputStream is = null;
	// try {
	// is = new FileInputStream(filename);
	// LogManager.getLogManager().readConfiguration(is);
	// }
	// catch (Exception e) {
	// System.err.println("SIMPLEDBM-ERROR: Failed to initialize logging system due to following error: "
	// + e.getMessage());
	// e.printStackTrace();
	// }
	// finally {
	// try {
	// is.close();
	// } catch (IOException e) {}
	// }
	// }

	public Logger(String name) {
		realLogger = java.util.logging.Logger.getLogger(name);
	}

	public void info(String sourceClass, String sourceMethod, String message) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.INFO, sourceClass, sourceMethod, message);
		}
	}

	public void info(String sourceClass, String sourceMethod, String message,
			Throwable thrown) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.INFO, sourceClass, sourceMethod, message, thrown);
		}
	}

	public void debug(String sourceClass, String sourceMethod, String message) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.FINE, sourceClass, sourceMethod, message);
		}
	}

	public void debug(String sourceClass, String sourceMethod, String message,
			Throwable thrown) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.FINE, sourceClass, sourceMethod, message, thrown);
		}
	}

	public void trace(String sourceClass, String sourceMethod, String message) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.FINER, sourceClass, sourceMethod, message);
		}
	}

	public void trace(String sourceClass, String sourceMethod, String message,
			Throwable thrown) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.FINER, sourceClass, sourceMethod, message, thrown);
		}
	}

	public void warn(String sourceClass, String sourceMethod, String message) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.WARNING, sourceClass, sourceMethod, message);
		}
	}

	public void warn(String sourceClass, String sourceMethod, String message,
			Throwable thrown) {
		if (CommonProperty.DEBUG) {
			realLogger.logp(Level.WARNING, sourceClass, sourceMethod, message,
				thrown);
		}
	}

	public void error(String sourceClass, String sourceMethod, String message) {
		realLogger.logp(Level.SEVERE, sourceClass, sourceMethod, message);
	}

	public void log(Level level, String message) {
		if (CommonProperty.DEBUG) {
			realLogger.log(level, message);
		}
	}
	
	public void log(Level level, String message, Throwable e) {
		if (CommonProperty.DEBUG) {
			realLogger.log(level, message, e);
		}
	}
	
	public void info(String message) {
		if (CommonProperty.DEBUG) {
			realLogger.info(message);
		}
	}

	public void warning(String message) {
		if (CommonProperty.DEBUG) {
			realLogger.warning(message);
		}
	}

	public void severe(String message) {
		realLogger.severe(message);
	}

	public void fine(String message) {
		realLogger.fine(message);
	}
	
	public void error(String sourceClass, String sourceMethod, String message,
			Throwable thrown) {
		realLogger.logp(Level.SEVERE, sourceClass, sourceMethod, message,
				thrown);
	}

	public boolean isTraceEnabled() {
		return realLogger.isLoggable(Level.FINER);
	}

	public boolean isDebugEnabled() {
		return realLogger.isLoggable(Level.FINE);
	}

	public void enableDebug() {
		realLogger.setLevel(Level.FINE);
	}

	public void disableDebug() {
		realLogger.setLevel(Level.INFO);
	}
}
