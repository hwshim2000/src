package net.forecs.coconut.common;

import lombok.Getter;
import lombok.Setter;

public class Result {

	@Getter @Setter
	private Object result;

	public Result() {
	}
	
	public Result(Object result) {
		this.result = result;
	}
}
