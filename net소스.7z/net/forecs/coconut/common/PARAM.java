package net.forecs.coconut.common;

public final class PARAM {
	public static final String BOARDID = "boardId";
	public static final String EMAIL = "email";
	public static final String HREF = "href";
	public static final String SUBJECT = "subject";
	public static final String MESSAGE = "message";
	public static final String MESSAGES = "messages";
	public static final String ACTIVITIES = "activities";
	public static final String ACTIVITYMAP = "activityMap";
	public static final String ACTIVITYMAPKEYS = "activityMapKeys";
	public static final String ACTIVITYID = "activityId";
	public static final String SECCODE = "secCode";
	
	public static final String NAME = "name";
	public static final String QUEUE = "queue";
	public static final String FILESYSTEM = "filesystem";
	public static final String GS_BUCKET_NAME = "gs_bucket_name";
	public static final String NAMESPACE = "namespace";
	public static final String KIND = "kind";
	public static final String DOMAINID = "domainId";
	public static final String DOMAINNAME = "domainName";
	public static final String EVENTID = "eventId";
	public static final String EVENTTYPE = "eventType";
	public static final String TASKID = "taskId";
	public static final String FORMAT = "format";
	public static final String ATTACHMENTID = "attachmentId";
	
	public static final String EVENTDATETIMEMILLS = "eventDateTimeMillis";
	public static final String ANNIVERSARYTYPE = "anniversaryType";
	public static final String ALARMDATETIMEMILLS = "alarmDateTimeMillis";
	public static final String NOTIFICATIONSETTINGID = "notificationSettingId";

	public static final String USERID = "userId";
	public static final String ID = "id";
	public static final String USERNAME = "userName";
	public static final String NICKNAME = "nickName";
	public static final String PASSWORD = "password";
	public static final String RANDOMPASSWORD = "randomPassword";
	public static final String REGCODE = "regCode";
	public static final String FORGOT = "forgot";
	public static final String REMEMBERME = "rememberMe";
	public static final String SUSPEND = "suspend";
	
	public static final String TEMPLATENAME = "templateName";
	public static final String TEMPLATENAME2 = "templateName2";				// add 20170808
	public static final String BODY = "body";
	public static final String FILENAME = "fileName";
	public static final String LOCALE = "locale";
	public static final String OVERWRITE = "overwrite";
	public static final String INVITETOKEN = "inviteToken";
	
	public static final String WEBBASEURL = "webBaseUrl";
	
	public static final String SYNCTIME = "syncTime";
	public static final String LONGPOLLINGTIME = "longPollingTime";
	
	public static final String WEBHOOKID = "webHookId";
	public static final String ISDEVMODE = "isDevMode";
	public static final String PREPARETYPE = "prepareType";
	
	public static final String KEY = "key";
	public static final String CHANNELKEY = "channelKey";
	
	public static final String MERCHANT_UID = "merchant_uid";
	public static final String AMOUNT = "amount";
	public static final String REASON = "reason";
	
	private PARAM() {}
}
