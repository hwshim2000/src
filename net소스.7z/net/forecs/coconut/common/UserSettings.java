package net.forecs.coconut.common;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.entity.setting.UserSetting;

public class UserSettings {
	@Getter @Setter
	private List<UserSetting> settings;
	
	public UserSettings() {}
	public UserSettings(List<UserSetting> settings) {
		this.settings = settings;
	}
}
