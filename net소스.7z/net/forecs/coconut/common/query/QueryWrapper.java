package net.forecs.coconut.common.query;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import javax.persistence.Parameter;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;


class QueryWrapper<X> implements TypedQuery<X> {
	private final Query query;

	QueryWrapper(Query query) {
		this.query = query;
	}

	@Override
	public int executeUpdate() {
		return query.executeUpdate();
	}

	@Override
	public int getFirstResult() {
		return query.getFirstResult();
	}

	@Override
	public FlushModeType getFlushMode() {
		return query.getFlushMode();
	}

	@Override
	public Map<String, Object> getHints() {
		return query.getHints();
	}

	@Override
	public LockModeType getLockMode() {
		return query.getLockMode();
	}

	@Override
	public int getMaxResults() {
		return query.getMaxResults();
	}

	@Override
	public Parameter<?> getParameter(String arg0) {
		return query.getParameter(arg0);
	}

	@Override
	public Parameter<?> getParameter(int arg0) {
		return query.getParameter(arg0);
	}

	@Override
	public <T> Parameter<T> getParameter(String arg0, Class<T> arg1) {
		return query.getParameter(arg0, arg1);
	}

	@Override
	public <T> Parameter<T> getParameter(int arg0, Class<T> arg1) {
		return query.getParameter(arg0, arg1);
	}

	@Override
	public <T> T getParameterValue(Parameter<T> arg0) {
		return query.getParameterValue(arg0);
	}

	@Override
	public Object getParameterValue(String arg0) {
		return query.getParameterValue(arg0);
	}

	@Override
	public Object getParameterValue(int arg0) {
		return query.getParameterValue(arg0);
	}

	@Override
	public Set<Parameter<?>> getParameters() {
		return query.getParameters();
	}

	@Override
	public boolean isBound(Parameter<?> arg0) {
		return query.isBound(arg0);
	}

	@Override
	public <T> T unwrap(Class<T> arg0) {
		return query.unwrap(arg0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<X> getResultList() {
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public X getSingleResult() {
		return (X)query.getSingleResult();
	}

	@Override
	public TypedQuery<X> setFirstResult(int arg0) {
		query.setFirstResult(arg0);
		return this;
	}

	@Override
	public TypedQuery<X> setFlushMode(FlushModeType arg0) {
		query.setFlushMode(arg0);
		return this;
	}

	@Override
	public TypedQuery<X> setHint(String arg0, Object arg1) {
		query.setHint(arg0, arg1);
		return this;
	}

	@Override
	public TypedQuery<X> setLockMode(LockModeType arg0) {
		query.setLockMode(arg0);
		return this;
	}

	@Override
	public TypedQuery<X> setMaxResults(int arg0) {
		query.setMaxResults(arg0);
		return this;
	}

	@Override
	public <T> TypedQuery<X> setParameter(Parameter<T> arg0, T arg1) {
		query.setParameter(arg0, arg1);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(String arg0, Object arg1) {
		query.setParameter(arg0, arg1);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(int arg0, Object arg1) {
		query.setParameter(arg0, arg1);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(Parameter<Calendar> arg0, Calendar arg1, TemporalType arg2) {
		query.setParameter(arg0, arg1, arg2);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(Parameter<Date> arg0, Date arg1, TemporalType arg2) {
		query.setParameter(arg0, arg1, arg2);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(String arg0, Calendar arg1, TemporalType arg2) {
		query.setParameter(arg0, arg1, arg2);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(String arg0, Date arg1, TemporalType arg2) {
		query.setParameter(arg0, arg1, arg2);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(int arg0, Calendar arg1, TemporalType arg2) {
		query.setParameter(arg0, arg1, arg2);
		return this;
	}

	@Override
	public TypedQuery<X> setParameter(int arg0, Date arg1, TemporalType arg2) {
		query.setParameter(arg0, arg1, arg2);
		return this;
	}
}