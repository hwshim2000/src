package net.forecs.coconut.common.query;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * @Description :
 * @Author      : hyeunwoo.shim@forecs.net 2015. 4. 30.
 */
public class SearchOption implements Serializable {
	private static final long serialVersionUID = 8788190124107220762L;

	public SearchOption() {
	}
	private List<SearchSortOption> sortOptions;
	public void setSortOptions(List<SearchSortOption> sortOptions) {
		if (sortOptions == null) sortOptions = new ArrayList<SearchSortOption>();
		this.sortOptions = sortOptions;
	}
	public List<SearchSortOption> getSortOptions() {
		if (sortOptions == null) sortOptions = new ArrayList<SearchSortOption>();
		return sortOptions;
	}
}
