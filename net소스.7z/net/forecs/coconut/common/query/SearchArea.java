package net.forecs.coconut.common.query;

public enum SearchArea {
	ALL,
	TASKS,
	EVENTS,
	ATTACHMENTS,
	TIMELINES,
	COMMENTS
}
