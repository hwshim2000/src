package net.forecs.coconut.common.query;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.FilterType;


/**
 * @Description :
 * @Author      : hyeunwoo.shim@forecs.net 2015. 4. 24.
 */
public class FilterOption implements Serializable {
	private static final long serialVersionUID = -9173029212339845988L;

	@Getter @Setter
	private FilterType filterType;

	private List<Object> filterValues;
	public void setFilterValues(List<Object> filterValues) {
		if (filterValues == null) filterValues = new ArrayList<Object>();
		this.filterValues = filterValues;
	}
	public List<Object> getFilterValues() {
		if (filterValues == null) filterValues = new ArrayList<Object>();
		return filterValues;
	}
}
