package net.forecs.coconut.common.query;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import lombok.Getter;

import org.apache.commons.lang.StringUtils;
import org.datanucleus.api.jpa.criteria.ExpressionImpl;
import org.datanucleus.api.jpa.criteria.JPQLHelper;
import org.datanucleus.query.expression.DyadicExpression;
import org.datanucleus.query.expression.Expression.DyadicOperator;
import org.datanucleus.query.expression.Literal;


public class SimpleQuery<T> {
	private final Class<T> clazz;

	private EntityManager em;
	private CriteriaBuilder cb;
	private CriteriaQuery<T> cq;

	private Root<T> from;
	private Condition where;
	private List<Order> orderBy = new ArrayList<Order>();
	private Map<String, Object> parameters = new HashMap<String, Object>();

	public SimpleQuery(EntityManager em, Class<T> clazz) {
		this.em = em;
		this.clazz = clazz;

		cb = em.getCriteriaBuilder();
		cq = cb.createQuery(clazz);

		from = cq.from(clazz);
	}

	public SimpleQuery<T> where(Condition condition) {
		where = condition;
		if (condition != null) {
			parameters.putAll(condition.getParameters());
		} else {
			parameters.clear();
		}
		return this;
	}

	public <V> Condition isNull(String fieldName) {
		if (StringUtils.isEmpty(fieldName)) {
			return null;
		}

		Predicate predicate = cb.isNull(from.get(fieldName));

		Condition condition = new Condition(predicate);
		return condition;
	}

	public <V> Condition isNotNull(String fieldName) {
		if (StringUtils.isEmpty(fieldName)) {
			return null;
		}

		Predicate predicate = cb.isNotNull(from.get(fieldName));

		Condition condition = new Condition(predicate);
		return condition;
	}

	public <V> Condition equal(String fieldName, V value) {
		if (StringUtils.isEmpty(fieldName) || (value == null)) {
			return null;
		}

		Predicate predicate = cb.equal(from.get(fieldName), cb.parameter(value.getClass(), fieldName));

		Condition condition = new Condition(predicate);
		condition.getParameters().put(fieldName, value);
		return condition;
	}

	public <V extends Comparable<?>> Condition greaterThan(String fieldName, V value) {
		if (StringUtils.isEmpty(fieldName) || (value == null)) {
			return null;
		}

		@SuppressWarnings("unchecked")
		Predicate predicate = cb.greaterThan(from.<V>get(fieldName), cb.parameter(value.getClass(), fieldName));

		Condition condition = new Condition(predicate);
		condition.getParameters().put(fieldName, value);
		return condition;
	}

	public <V extends Comparable<?>> Condition lessThan(String fieldName, V value) {
		if (StringUtils.isEmpty(fieldName) || (value == null)) {
			return null;
		}

		@SuppressWarnings("unchecked")
		Predicate predicate = cb.lessThan(from.<V>get(fieldName), cb.parameter(value.getClass(), fieldName));

		Condition condition = new Condition(predicate);
		condition.getParameters().put(fieldName, value);
		return condition;
	}

	public <V> Condition in(String fieldName, List<V> values) {
		if (StringUtils.isEmpty(fieldName) || (values == null) || values.isEmpty()) {
			return null;
		}

		//Predicate predicate = from.<V>get(fieldName).in(values);
		//In<V> predicate = CriteriaBuilder_in(from.<V>get(fieldName));
		//for (V value : values) {
		//	predicate.value(value);
		//}
		In<V> predicate = CriteriaBuilder_in(from.<V>get(fieldName), values);

		Condition condition = new Condition(predicate);
		return condition;
	}

	public <V> Condition and(Condition... conditions) {
		List<Predicate> predicates = new ArrayList<Predicate>();
		for (Condition c : conditions) {
			if (c == null) continue;
			predicates.add(c.getPredicate());
		}

		Predicate predicate = cb.and(predicates.toArray(new Predicate[0]));

		Condition condition = new Condition(predicate);
		for (Condition c : conditions) {
			if (c == null) continue;
			condition.getParameters().putAll(c.getParameters());
		}
		return condition;
	}

	public <V> Condition or(Condition... conditions) {
		List<Predicate> predicates = new ArrayList<Predicate>();
		for (Condition c : conditions) {
			if (c == null) continue;
			predicates.add(c.getPredicate());
		}

		Predicate predicate = cb.or(predicates.toArray(new Predicate[0]));

		Condition condition = new Condition(predicate);
		for (Condition c : conditions) {
			if (c == null) continue;
			condition.getParameters().putAll(c.getParameters());
		}
		return condition;
	}

	public SimpleQuery<T> orderBy(String fieldName, boolean asc) {
		Order order;
		if (asc) {
			order = cb.asc(from.get(fieldName));
		} else {
			order = cb.desc(from.get(fieldName));
		}

		orderBy.add(order);
		return this;
	}

	private <V> TypedQuery<V> createQuery(CriteriaQuery<V> cq, Selection<V> selection) {
		Predicate predicate = null;
		if (where != null) predicate = where.getPredicate();
		cq.select(selection).where(predicate).orderBy(orderBy);

		//-->
		//TypedQuery<V> query =  em.createQuery(cq);
		//--
		// jongwook.yi@forecs.net 2015-05-14 : Workaround to use TypedQuery.
		//		Seems to be a bug : GAE dose not support cursor for TypedQuery.
		TypedQuery<V> query = new QueryWrapper<V>(em.createQuery(cq.toString()));
		//<--

		for (Map.Entry<String, Object> entry : parameters.entrySet()) {
			query = query.setParameter(entry.getKey(), entry.getValue());
		}

		return query;
	}

	public TypedQuery<T> list() {
		return createQuery(cq, from);
	}

	public TypedQuery<Long> count() {
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.count(from));
	}

	public TypedQuery<Long> countDistinct(String field) {
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.countDistinct(from.<Double>get(field)).alias("CD"));
	}

	public TypedQuery<Number> sum(String field) {
		CriteriaQuery<Number> cq = cb.createQuery(Number.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.sum(from.<Number>get(field)).alias("S"));
	}

	public TypedQuery<Double> sumAsDouble(String field) {
		CriteriaQuery<Double> cq = cb.createQuery(Double.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.sum(from.<Double>get(field)).alias("S"));
	}

	public TypedQuery<Long> sumAsLong(String field) {
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.sum(from.<Long>get(field)).alias("S"));
	}

	public TypedQuery<Double> avg(String field) {
		CriteriaQuery<Double> cq = cb.createQuery(Double.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.avg(from.<Double>get(field)).alias("A"));
	}

	public TypedQuery<Number> max(String field) {
		CriteriaQuery<Number> cq = cb.createQuery(Number.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.max(from.<Number>get(field)).alias("M"));
	}

	public TypedQuery<Double> maxAsDouble(String field) {
		CriteriaQuery<Double> cq = cb.createQuery(Double.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.max(from.<Double>get(field)).alias("M"));
	}

	public TypedQuery<Long> maxAsLong(String field) {
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.max(from.<Long>get(field)).alias("M"));
	}

	public TypedQuery<Number> min(String field) {
		CriteriaQuery<Number> cq = cb.createQuery(Number.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.min(from.<Number>get(field)).alias("M"));
	}

	public TypedQuery<Double> minAsDouble(String field) {
		CriteriaQuery<Double> cq = cb.createQuery(Double.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.min(from.<Double>get(field)).alias("M"));
	}

	public TypedQuery<Long> minAsLong(String field) {
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<T> from = cq.from(clazz);
		return createQuery(cq, cb.min(from.<Long>get(field)).alias("M"));
	}

	public static class Condition {
		@Getter
		private final Predicate predicate;
		@Getter
		private Map<String, Object> parameters = new HashMap<String, Object>();

		Condition(Predicate predicate) {
			this.predicate = predicate;
		}
	}

	//--> jongwook.yi@forecs.net 2015-05-20 : GAE workaround to support in clause
	//	Code from https://github.com/datanucleus/datanucleus-api-jpa
	//	TODO Use library and remove this if official library is released
	public class GaeExpressionImpl<E> implements Selection<E>, Expression<E>, Serializable {
		static final long serialVersionUID = -9180595377551709140L;

		protected CriteriaBuilder cb;
		private final Class<E> cls;
		private String alias;

		/** The underlying (generic) query expression. */
		org.datanucleus.query.expression.Expression queryExpr;

		public GaeExpressionImpl(CriteriaBuilder cb, Class<E> cls) {
			this.cb = cb;
			this.cls = cls;
		}
		public <X> Expression<X> as(Class<X> cls) {
			GaeExpressionImpl<X> expr = new GaeExpressionImpl<X>(cb, cls);
			expr.queryExpr = queryExpr;
			return expr;
		}
		public Predicate in(Collection<?> values) {
			return CriteriaBuilder_in(this, values);
		}
		@SuppressWarnings("unchecked")
		public Predicate in(Expression<?>... values) {
			return CriteriaBuilder_in(this, (Expression[]) values);
		}
		@SuppressWarnings("unchecked")
		public Predicate in(Expression<Collection<?>> values) {
			return CriteriaBuilder_in(this, values);
		}
		public Predicate in(Object... values) {
			return CriteriaBuilder_in(this, values);
		}
		public Predicate isNotNull() {
			GaePredicateImpl pred = new GaePredicateImpl(cb);
			Literal lit = new Literal(null);
			org.datanucleus.query.expression.Expression queryExpr = new DyadicExpression(getQueryExpression(),
					org.datanucleus.query.expression.Expression.OP_NOTEQ, lit);
			pred.queryExpr = queryExpr;
			return pred;
		}
		public Predicate isNull() {
			GaePredicateImpl pred = new GaePredicateImpl(cb);
			Literal lit = new Literal(null);
			org.datanucleus.query.expression.Expression queryExpr = new DyadicExpression(getQueryExpression(),
					org.datanucleus.query.expression.Expression.OP_EQ, lit);
			pred.queryExpr = queryExpr;
			return pred;
		}
		public Selection<E> alias(String alias) {
			this.alias = alias;
			return this;
		}
		public List<Selection<?>> getCompoundSelectionItems() {
			return null;
		}
		public boolean isCompoundSelection() {
			return false;
		}
		public String getAlias() {
			return alias;
		}
		public Class<? extends E> getJavaType() {
			return cls;
		}
		public org.datanucleus.query.expression.Expression getQueryExpression() {
			return queryExpr;
		}
		public String toString() {
			return JPQLHelper.getJPQLForExpression(queryExpr);
		}
	}
	@SuppressWarnings("serial")
	class GaePredicateImpl extends GaeExpressionImpl<Boolean> implements Predicate {
		protected final List<Predicate> exprs = new ArrayList<Predicate>();

		boolean negated = false;

		BooleanOperator operator = null;

		public GaePredicateImpl(CriteriaBuilder cb) {
			super(cb, Boolean.class);
			this.operator = BooleanOperator.AND;
		}
		public GaePredicateImpl(CriteriaBuilder cb, BooleanOperator op) {
			super(cb, Boolean.class);
			this.operator = op;
		}
		public Predicate not() {
			negated = !negated;
			return this;
		}
		public List<Expression<Boolean>> getExpressions() {
			if (exprs == null) {
				return null;
			}
			return new ArrayList<Expression<Boolean>>(exprs);
		}
		public BooleanOperator getOperator() {
			return operator;
		}
		public boolean isNegated() {
			return negated;
		}
		public GaePredicateImpl append(Predicate pred) {
			exprs.add(pred);
			return this;
		}
		@SuppressWarnings("unchecked")
		public org.datanucleus.query.expression.Expression getQueryExpression() {
			if (exprs != null && !exprs.isEmpty()) {
	            // Generate series of nested DyadicExpressions all using the defined operator
				DyadicOperator op = (operator == BooleanOperator.AND ? org.datanucleus.query.expression.Expression.OP_AND
						: org.datanucleus.query.expression.Expression.OP_OR);
				Iterator<Predicate> iter = exprs.iterator();
				org.datanucleus.query.expression.Expression left = null;
				org.datanucleus.query.expression.Expression right = null;
				while (iter.hasNext()) {
					GaePredicateImpl pred = (GaePredicateImpl) iter.next();
					if (left == null) {
						left = pred.getQueryExpression();
						right = left;
					} else {
						left = right;
						right = new DyadicExpression(left, op, pred.getQueryExpression());
					}
				}

				if (negated) {
					return new DyadicExpression(org.datanucleus.query.expression.Expression.OP_NOT, right);
				}

				return right;
			}

			if (negated) {
				return new DyadicExpression(org.datanucleus.query.expression.Expression.OP_NOT, queryExpr);
			}
			return queryExpr;
		}
		public String toString() {
			StringBuffer str = new StringBuffer();
			if (negated) {
				str.append("!(");
			}

			if (exprs.isEmpty()) {
				// Base expression
				str.append(JPQLHelper.getJPQLForExpression(queryExpr));
			} else {
				// Sub-predicates, using the defined operator
				Iterator<Predicate> iter = exprs.iterator();
				while (iter.hasNext()) {
					Predicate pred = iter.next();
					str.append(pred);
					if (iter.hasNext()) {
						str.append(operator == BooleanOperator.AND ? " AND " : " OR ");
					}
				}
			}
			if (negated) {
				str.append(")");
			}

			return str.toString();
		}
	}

	public class GaeInPredicate<X> extends GaePredicateImpl implements In<X> {
		private static final long serialVersionUID = -831538482168317142L;

		ExpressionImpl<? extends X> expr;
		List<Expression<? extends X>> values;

		boolean negated = false;

		public GaeInPredicate(CriteriaBuilder cb, Expression<? extends X> expr) {
			super(cb);
			this.expr = (ExpressionImpl<? extends X>) expr;
		}
	    @SuppressWarnings("unchecked")
		public GaeInPredicate(CriteriaBuilder cb, Expression<? extends X> expr, X... values) {
			this(cb, expr);
			for (int i = 0; i < values.length; i++) {
				value(values[i]);
			}
		}
		public GaeInPredicate(CriteriaBuilder cb, Expression<? extends X> expr, List<Expression<? extends X>> values) {
			this(cb, expr);
			this.values = values;
		}
	    @SuppressWarnings("unchecked")
		public GaeInPredicate(CriteriaBuilder cb, Expression<? extends X> expr, Expression<? extends X>... values) {
			this(cb, expr, Arrays.asList(values));
		}
		public GaeInPredicate(CriteriaBuilder cb, Expression<? extends X> expr, Collection<X> values) {
			this(cb, expr);
			for (X val : values) {
				value(val);
			}
		}
		public BooleanOperator getOperator() {
			return BooleanOperator.AND;
		}
		public boolean isNegated() {
			return negated;
		}
		@SuppressWarnings("unchecked")
		public List<Expression<Boolean>> getExpressions() {
			return Collections.EMPTY_LIST;
		}
		public Predicate not() {
			negated = !negated;
			return this;
		}
		@SuppressWarnings("unchecked")
		public Expression<X> getExpression() {
			return (Expression<X>) expr;
		}
		public In<X> value(X value) {
			if (values == null) {
				values = new ArrayList<Expression<? extends X>>();
			}
			// ExpressionImpl<X> litExpr = new LiteralExpression<X>(cb, value);
			Expression<X> litExpr = cb.literal(value);
			values.add(litExpr);
			queryExpr = null; // Reset it for recalculation

			return this;
		}
		public In<X> value(Expression<? extends X> value) {
			if (values == null) {
				values = new ArrayList<Expression<? extends X>>();
			}
			values.add(value);
			queryExpr = null; // Reset it for recalculation

			return this;
		}
		@SuppressWarnings("rawtypes")
		@Override
		public org.datanucleus.query.expression.Expression getQueryExpression() {
			if (queryExpr == null) {
				if (values == null || values.isEmpty()) {
					return null;
				}

	            // Generate the query expression
				DyadicExpression dyExpr = null;
				if (values.size() == 1) {
	                // Single value, could be value of same type, or a Collection so treat as "IN"
					Expression valueExpr = values.get(0);
					dyExpr = new DyadicExpression(expr.getQueryExpression(),
							org.datanucleus.query.expression.Expression.OP_IN,
							((ExpressionImpl) valueExpr).getQueryExpression());
				} else {
					for (Expression valExpr : values) {
						DyadicExpression valDyExpr = new DyadicExpression(expr.getQueryExpression(),
								org.datanucleus.query.expression.Expression.OP_EQ,
								((ExpressionImpl) valExpr).getQueryExpression());
						if (dyExpr == null) {
							dyExpr = valDyExpr;
						} else {
							dyExpr = new DyadicExpression(dyExpr, org.datanucleus.query.expression.Expression.OP_OR, valDyExpr);
						}
					}
				}
				queryExpr = dyExpr;
			}
			return queryExpr;
		}
		@SuppressWarnings("rawtypes")
		public String toString() {
			StringBuilder str = new StringBuilder();
			if (negated) {
				str.append("!(");
			}

			str.append(JPQLHelper.getJPQLForExpression(expr.getQueryExpression())).append(" IN (");
			boolean firstValue = true;
			for (Expression valExpr : values) {
				if (!firstValue) {
					str.append(",");
				}
				str.append(valExpr.toString());
				firstValue = false;
			}
			str.append(")");

			if (negated) {
				str.append(")");
			}

			return str.toString();
		}
	}

	public <X> In<X> CriteriaBuilder_in(Expression<? extends X> expr) {
		return new GaeInPredicate<X>(cb, expr);
	}
	@SuppressWarnings("unchecked")
	public <X> In<X> CriteriaBuilder_in(Expression<? extends X> expr, Expression<? extends X>... values) {
		return new GaeInPredicate<X>(cb, expr, values);
	}
	@SuppressWarnings("unchecked")
	public <X> In<X> CriteriaBuilder_in(Expression<? extends X> expr, X... values) {
		return new GaeInPredicate<X>(cb, expr, values);
	}
	public <X> In<X> CriteriaBuilder_in(Expression<? extends X> expr, Collection<X> values) {
		return new GaeInPredicate<X>(cb, expr, values);
	}
	//<--
}