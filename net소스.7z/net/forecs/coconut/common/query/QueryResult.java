package net.forecs.coconut.common.query;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.Cursor;


public final class QueryResult<T> implements Serializable {
	/**
	 * @Description :
	 * @Author      : hyeunwoo.shim@forecs.net 2016. 9. 7.
	 */
	private static final long serialVersionUID = -1127996039794313451L;
	private List<T> resultList;
	@Getter
	private Cursor cursor;
	
	@Getter @Setter
	private String cursorString;

	public QueryResult() {
		this.resultList = new ArrayList<T>();
		this.cursor = null;
		this.cursorString = null;
	}
	public QueryResult(List<T> resultList) {
		if (resultList == null) resultList = new ArrayList<T>();
		this.resultList = resultList;
		this.cursor = null;
		this.cursorString = null;
	}
	
	public QueryResult(List<T> resultList, Cursor cursor) {
		if (resultList == null) resultList = new ArrayList<T>();
		this.resultList = resultList;
		this.cursor = cursor;
		this.cursorString = null;
	}
	
	public QueryResult(List<T> resultList, String cursorString) {
		if (resultList == null) resultList = new ArrayList<T>();
		this.resultList = resultList;
		this.cursor = null;
		this.cursorString = cursorString;
	}
	
	public List<T> getResultList() {
		return (resultList != null) ? resultList : new ArrayList<T>();
	}

	public String getNextPageToken() {
		if (cursor != null) {
			return cursor.toWebSafeString();
		} else if (StringUtils.isNotBlank(cursorString)) {
			return cursorString;
		} else {
			return null;
		}
	}
}