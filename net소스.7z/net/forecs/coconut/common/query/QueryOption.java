package net.forecs.coconut.common.query;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * @Description :
 * @Author      : hyeunwoo.shim@forecs.net 2015. 4. 24.
 */
public class QueryOption implements Serializable {
	private static final long serialVersionUID = -4492327128301506822L;

	private List<FilterOption> filterOptions;
	public void setFilterOptions(List<FilterOption> filterOptions) {
		if (filterOptions == null) filterOptions = new ArrayList<FilterOption>();
		this.filterOptions = filterOptions;
	}
	public List<FilterOption> getFilterOptions() {
		if (filterOptions == null) filterOptions = new ArrayList<FilterOption>();
		return filterOptions;
	}

	private List<SortOption> sortOptions;
	public void setSortOptions(List<SortOption> sortOptions) {
		if (sortOptions == null) sortOptions = new ArrayList<SortOption>();
		this.sortOptions = sortOptions;
	}
	public List<SortOption> getSortOptions() {
		if (sortOptions == null) sortOptions = new ArrayList<SortOption>();
		return sortOptions;
	}
}
