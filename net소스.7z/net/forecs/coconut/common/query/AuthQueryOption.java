package net.forecs.coconut.common.query;

import java.util.ArrayList;
import java.util.List;


public class AuthQueryOption {
	private List<AuthSortOption> authSortOptions;

	public List<AuthSortOption> getAuthSortOptions() {
		if (authSortOptions == null) authSortOptions = new ArrayList<AuthSortOption>();
		return authSortOptions;
	}

	public void setAuthSortOptions(List<AuthSortOption> authSortOptions) {
		if (authSortOptions == null) authSortOptions = new ArrayList<AuthSortOption>();
		this.authSortOptions = authSortOptions;
	}
}
