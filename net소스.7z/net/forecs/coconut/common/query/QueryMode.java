package net.forecs.coconut.common.query;

public enum QueryMode {
	SELECT,
	DELETE
	// UPDATE  // do not use, datastore is not allowed bulk updates
}
