package net.forecs.coconut.common.query;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

import com.google.appengine.api.search.SortExpression;

public class SearchSortOption implements Serializable{
	private static final long serialVersionUID = -4481064999591321837L;
	
	@Getter @Setter
	private String sortItem;
	@Getter @Setter
	private SortExpression.SortDirection sortDirection;
	@Getter @Setter
	private String defaultValue;
	
	public SearchSortOption() {}
	
	public SearchSortOption(String sortItem, SortExpression.SortDirection sortDirection, String defaultValue) {
		this.sortItem = sortItem;
		this.sortDirection = sortDirection;
		this.defaultValue = defaultValue;
	}
}
