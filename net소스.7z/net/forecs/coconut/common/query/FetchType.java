package net.forecs.coconut.common.query;

public enum FetchType {
	ALL,
	KEY,
	NAMESPACE,
	/** result variable type : Long */
	COUNT,
	/** result variable type : Integer */
	MAX,
	/** result variable type : Integer */
	MIN,
	/** result variable type : Long */
	SUM,
	/** result variable type : Double */
	AVG;
}
