package net.forecs.coconut.common.query;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;

import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.common.Base;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.CompositeFilterOperator;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.google.appengine.api.datastore.Query.SortDirection;

public class DsQuery<T extends Base> {
//	private static final Logger LOG = Logger.getLogger(DsQuery.class.getName());
	
	private final Class<T> clazz;
	
	private Query q;
	private List<Filter> filters;
	private FetchOptions fetchOptions;
	private Integer limit;
	private boolean complete;
	private int cursorPosition;
	private int fetchSize;
	private boolean endOfFetch;
	
	private int currentEntityFetchIndex = 0;
	private List<T> nextFetchs;
	private List<T> results;
	
	public DsQuery(Class<T> clazz) {
		this.clazz = clazz;
		q = new Query(clazz.getSimpleName());
		filters = new ArrayList<Filter>();
		fetchOptions = null;
		cursorPosition = 0;
		fetchSize = -1;
		complete = false;
		results = new ArrayList<T>();
	}
//	public DsQuery(String kind) {
//		q = new Query(kind);
//		filters = new ArrayList<Filter>();
//		fetchOptions = null;
//		cursorPosition = 0;
//		fetchSize = -1;
//	}
	
	public DsQuery<T> eq(String field, Object value) {
		Filter f = null;
		if (StringUtils.isNotBlank(field) && value != null) {
			if (value.getClass().isEnum()) { value = value.toString(); }
			f = new FilterPredicate(field, FilterOperator.EQUAL, value);
//			q = q.setFilter(f);
			filters.add(f);
		}
		return this;
	}
	public DsQuery<T> ge(String field, Object value) {
		Filter f = null;
		if (StringUtils.isNotBlank(field) && value != null) {
			f = new FilterPredicate(field, FilterOperator.GREATER_THAN_OR_EQUAL, value);
//			q = q.setFilter(f);
			filters.add(f);
		}
		return this;
	}
	public DsQuery<T> gt(String field, Object value) {
		Filter f = null;
		if (StringUtils.isNotBlank(field) && value != null) {
			f = new FilterPredicate(field, FilterOperator.GREATER_THAN, value);
//			q = q.setFilter(f);
			filters.add(f);
		}
		return this;
	}
	public DsQuery<T> le(String field, Object value) {
		Filter f = null;
		if (StringUtils.isNotBlank(field) && value != null) {
			f = new FilterPredicate(field, FilterOperator.LESS_THAN_OR_EQUAL, value);
//			q = q.setFilter(f);
			filters.add(f);
		}
		return this;
	}
	public DsQuery<T> lt(String field, Object value) {
		Filter f = null;
		if (StringUtils.isNotBlank(field) && value != null) {
			f = new FilterPredicate(field, FilterOperator.LESS_THAN, value);
//			q = q.setFilter(f);
			filters.add(f);
		}
		return this;
	}
	@SuppressWarnings("rawtypes")
	public DsQuery<T> in(String field, Object value) {
		Filter f = null;
		if (StringUtils.isNotBlank(field) && value != null) {
			if (isCollection(value)) {
				Collection<Object> values = new ArrayList<Object>();
				Iterator iter = ((Collection)value).iterator();
				while(iter.hasNext()) {
					Object obj = iter.next();
					if (obj.getClass().isEnum()) { obj = obj.toString(); }
					values.add(obj);
				}
				if (((Collection)value).size() > 0) {
					f = new FilterPredicate(field, FilterOperator.IN, values);
					filters.add(f);
				}
			}
		}
		return this;
	}
	public DsQuery<T> ne(String field, Object value) {
		Filter f = null;
		if (StringUtils.isNotBlank(field) && value != null) {
			f = new FilterPredicate(field, FilterOperator.NOT_EQUAL, value);
			filters.add(f);
		}
		return this;
	}
	public DsQuery<T> sort(String field, SortDirection direction) {
		if (StringUtils.isNotBlank(field) && direction != null) {
			q = q.addSort(field, direction);
		}
		return this;
	}
	public DsQuery<T> sort(String field, net.forecs.coconut.common.code.SortDirection direction) {
		if (StringUtils.isNotBlank(field) && direction != null) {
			if (net.forecs.coconut.common.code.SortDirection.ASC.equals(direction)) {
				q = q.addSort(field, SortDirection.ASCENDING);
			} else {
				q = q.addSort(field, SortDirection.DESCENDING);
			}
		}
		return this;
	}
	public DsQuery<T> fetchOptions(FetchOptions fetchOptions) {
		this.fetchOptions = fetchOptions;
		return this;
	}
	public DsQuery<T> limit(Integer limit) {
		this.limit = limit;
		return this;
	}
	public DsQuery<T> cursor(String cursorString) {
		try {
			if (StringUtils.isNotBlank(cursorString) && StringUtils.isNumeric(cursorString)) {
				cursorPosition = Integer.parseInt(cursorString);
			}
		} catch (NumberFormatException ex) {}
		return this;
	}
	
	public Query keysOnly() {
		if (filters.size() > 0) {
			if (filters.size() == 1) { q = q.setFilter(filters.get(0)); }
			else { q = q.setFilter(CompositeFilterOperator.and(filters)); }
		}
		return q.setKeysOnly();
	}
//	public List<T> query(EntityManager mgr) throws Exception {
//		List<T> fetchs = CommonService.queryResults(mgr, clazz, this.setKeysOnly(), this.fetchOptions);
//		return fetchs;
//	}
	private boolean isCollection(Object ob) {
		return ob instanceof Collection/* || ob instanceof Map*/;
	}
	
	public FetchOptions getFetchOptions() {
		return fetchOptions;
	}
	
	public List<T> execute(EntityManager mgr) throws Exception {
		nextFetch(mgr);
		results = nextFetchs;
		cursorPosition += results.size();
		complete = true;
		return results;
	}
	public void nextFetch(EntityManager mgr) throws Exception {
		nextFetch(mgr, 1);
	}
	public void nextFetch(EntityManager mgr, int bulkFetchAmount) throws Exception{
		if (limit != null && limit > 0) {
			if (fetchOptions == null) { fetchOptions = FetchOptions.Builder.withDefaults(); }
			fetchSize = limit * bulkFetchAmount;
			if (fetchSize < limit) { fetchSize = limit; }
			if (fetchSize > 1000) { fetchSize = 1000; }
			fetchOptions = fetchOptions.offset(cursorPosition).limit(fetchSize);
		}
		nextFetchs = CommonService.queryResults(mgr, clazz, keysOnly(), fetchOptions);
		currentEntityFetchIndex = 0;
		if (nextFetchs.size() != fetchSize) { endOfFetch = true; }
		else { endOfFetch = false; }
	}
	public boolean hasNextFetch() {
		if (complete) { return false; }
		if (endOfFetch) { return false; }
		
		return true;
	}
	
	public T single(EntityManager mgr) throws Exception {
		return CommonService.querySingleResults(mgr, clazz, keysOnly());
	}
	public Long count() {
		return CommonService.queryCount(keysOnly());
	}
	
	public String getCursor() {
		if (limit != null && limit != results.size()) {
			return null;
		}
		return String.valueOf(cursorPosition);
	}
	public boolean hasEntity() {
		if (complete) { return false; }
		if (currentEntityFetchIndex >= nextFetchs.size()) { return false; }
		return true;
	}
	public T nextEntity() {
		cursorPosition++;
		if (currentEntityFetchIndex >= nextFetchs.size()) { return null; }
		return nextFetchs.get(currentEntityFetchIndex++);			
	}
	
//	public boolean isComplete(List<T> results ) {
//		complete = false;
//		if (limit != null && results.size() == limit) { complete = true; }
//		return complete;
//	}
	public List<T> getResults() {
		if (results.size() == 0 && hasEntity()) {
			results = nextFetchs;
			cursorPosition = cursorPosition + results.size();
			complete = true;
		}
		return results;
	}
	public void addResult(T t) {
		results.add(t);
		if (limit != null && results.size() == limit) {
			complete = true;
		}
	}
}
