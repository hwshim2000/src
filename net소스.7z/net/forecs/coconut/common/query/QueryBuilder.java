package net.forecs.coconut.common.query;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.util.CalendarUtil;
import net.forecs.coconut.common.util.ClassUtil;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.common.Common;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.Key;


public class QueryBuilder<T> {
	private static final Logger LOG = Logger.getLogger(QueryBuilder.class.getName());
	private final Class<T> clazz;

	private final String aliasName = "m";
	
	private QueryMode queryMode;
	private FetchType fetchType;
	private String aggregationField;
	
	private String kind;
	private String superKind;
	private String fetchStr;
	private StringBuilder queryStr = new StringBuilder();
	private StringBuilder conditionStr = null;
	private StringBuilder orderStr = null;
	private StringBuilder filterQuery = null;
	private StringBuilder niFilterQuery = null;
	
	private boolean deleteCondition = true;
	private boolean archiveCondition = false;
	private boolean permanentDeleteCondition = false;
	
	private Map<String, Object> paramMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> neParamMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> gtParamMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> ltParamMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> geParamMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> leParamMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> filterMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> niFilterMap = new LinkedHashMap<String, Object>();
	private Map<String, Object> orderMap = new LinkedHashMap<String, Object>();
	
	private List<String> nullParamList = new ArrayList<String>();
	private List<String> notnullParamList = new ArrayList<String>();
	
	public QueryBuilder(Class<T> clazz) throws Exception {
		this.clazz = clazz;
		this.queryMode = QueryMode.SELECT;
		this.fetchType = FetchType.ALL;
		this.aggregationField = null;
	}
	public QueryBuilder(Class<T> clazz, QueryMode queryMode) throws Exception {
		this.clazz = clazz;
		this.queryMode = queryMode;
		this.fetchType = null;
		this.aggregationField = null;
	}
	public QueryBuilder(Class<T> clazz, FetchType fetchType) throws Exception {
		this.clazz = clazz;
		this.queryMode = QueryMode.SELECT;
		this.fetchType = fetchType;
		this.aggregationField = null;
	}
	public QueryBuilder(Class<T> clazz, FetchType fetchType, String aggregationField) throws Exception {
		this.clazz = clazz;
		this.queryMode = QueryMode.SELECT;
		this.fetchType = fetchType;
		this.aggregationField = aggregationField;
	}
	public QueryBuilder(Class<T> clazz, FetchType fetchType, QueryMode queryMode) throws Exception {
		this.clazz = clazz;
		this.queryMode = queryMode;
		this.fetchType = fetchType;
		this.aggregationField = null;
	}
	
	public QueryBuilder<T> addClause(String param, Object value) {
		if (param != null) { paramMap.put(param, value); }
		return this;
	}
	public QueryBuilder<T> addNEClause(String param, Object value) {
		if (param != null) { neParamMap.put(param, value); }
		return this;
	}
	public QueryBuilder<T> addNullClause(String param) {
		if (param != null) { nullParamList.add(param); }
		return this;
	}
	public QueryBuilder<T> addNotNullClause(String param) {
		if (param != null) { notnullParamList.add(param); }
		return this;
	}
	
	public boolean isDeleteCondition() {
		return deleteCondition;
	}
	public void setDeleteCondition(boolean deleteCondition) {
		this.deleteCondition = deleteCondition;
	}
	public boolean isArchiveCondition() {
		return archiveCondition;
	}
	public void setArchiveCondition(boolean archiveCondition) {
		this.archiveCondition = archiveCondition;
	}
	public boolean isPermanentDeleteCondition() {
		return permanentDeleteCondition;
	}
	public void setPermanentDeleteCondition(boolean permanentDeleteCondition) {
		this.permanentDeleteCondition = permanentDeleteCondition;
	}
	
	public String getQueryString() {
		String fullQueryStr = queryStr.toString();
		
		for(Map.Entry<String, Object> entry : paramMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				Object obj = entry.getValue();
				
				if (obj.getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+entry.getValue().toString()+"'");
				} else if (obj.getClass().equals(java.util.Date.class)) {
					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
				} else {
					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), entry.getValue().toString());
				}
			}
		}
		for(Map.Entry<String, Object> entry : neParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				Object obj = entry.getValue();
				
				if (obj.getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+entry.getValue().toString()+"'");
				} else if (obj.getClass().equals(java.util.Date.class)) {
					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
				} else {
					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), entry.getValue().toString());
				}
			}
		}
		for(Map.Entry<String, Object> entry : gtParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				Object obj = entry.getValue();
				
				if (obj.getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
					fullQueryStr = fullQueryStr.replace(":GT"+entry.getKey(), "'"+entry.getValue().toString()+"'");	
				} else if (obj.getClass().equals(java.util.Date.class)) {
					fullQueryStr = fullQueryStr.replace(":GT"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
				} else {
					fullQueryStr = fullQueryStr.replace(":GT"+entry.getKey(), entry.getValue().toString());
				}
			}
		}
		for(Map.Entry<String, Object> entry : ltParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				Object obj = entry.getValue();
				
				if (obj.getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
					fullQueryStr = fullQueryStr.replace(":LT"+entry.getKey(), "'"+entry.getValue().toString()+"'");
				} else if (obj.getClass().equals(java.util.Date.class)) {
					fullQueryStr = fullQueryStr.replace(":LT"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
				} else {
					fullQueryStr = fullQueryStr.replace(":LT"+entry.getKey(), entry.getValue().toString());
				}
			}
		}
		for(Map.Entry<String, Object> entry : geParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				Object obj = entry.getValue();
				
				if (obj.getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
					fullQueryStr = fullQueryStr.replace(":GE"+entry.getKey(), "'"+entry.getValue().toString()+"'");
				} else if (obj.getClass().equals(java.util.Date.class)) {
					fullQueryStr = fullQueryStr.replace(":GE"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
				} else {
					fullQueryStr = fullQueryStr.replace(":GE"+entry.getKey(), entry.getValue().toString());
				}
			}
		}
		for(Map.Entry<String, Object> entry : leParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				Object obj = entry.getValue();
				
				if (obj.getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
					fullQueryStr = fullQueryStr.replace(":LE"+entry.getKey(), "'"+entry.getValue().toString()+"'");	
				} else if (obj.getClass().equals(java.util.Date.class)) {
					fullQueryStr = fullQueryStr.replace(":LE"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
				} else {
					fullQueryStr = fullQueryStr.replace(":LE"+entry.getKey(), entry.getValue().toString());
				}
			}
		}
		for(Map.Entry<String, Object> entry : filterMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
			Object obj = entry.getValue();
				
			if (obj.getClass().equals(java.util.Date.class)) {
				fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
			} else {
				fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+entry.getValue().toString()+"'");
			}
//				} else {
//					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), entry.getValue().toString());
//				}
			}
		}
		for(Map.Entry<String, Object> entry : niFilterMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				Object obj = entry.getValue();
				
			if (obj.getClass().equals(java.util.Date.class)) {
				fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+toDateString((Date)entry.getValue())+"'");
			} else {
				fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), "'"+entry.getValue().toString()+"'");
			}
//				} else {
//					fullQueryStr = fullQueryStr.replace(":"+entry.getKey(), entry.getValue().toString());
//				}
			}
		}
		
		return fullQueryStr;
	}
	public Map<String, Object> getParameterMap() { return paramMap; }
	public Map<String, Object> getFilterMap() { return filterMap; }
	public Map<String, Object> getNIFilterMap() { return niFilterMap; }
	
	
	/**
	 * Equal 비교값을 제외한 나머지 비교 형태는 해당 비교 항목에 대한 Sort가 존재해야한다.
	 * @param param
	 * @param value
	 * @param sortDirection
	 * @return
	 */
	public QueryBuilder<T> addGTClause(String param, Object value, SortDirection sortDirection) {
		if (param != null) { gtParamMap.put(param, value); addOrder(param, sortDirection); }
		return this;
	}
	/**
	 * Equal 비교값을 제외한 나머지 비교 형태는 해당 비교 항목에 대한 Sort가 존재해야한다.
	 * @param param
	 * @param value
	 * @param sortDirection
	 * @return
	 */
	public QueryBuilder<T> addLTClause(String param, Object value, SortDirection sortDirection) {
		if (param != null) { ltParamMap.put(param, value); addOrder(param, sortDirection); }
		return this;
	}
	/**
	 * Equal 비교값을 제외한 나머지 비교 형태는 해당 비교 항목에 대한 Sort가 존재해야한다.
	 * @param param
	 * @param value
	 * @param sortDirection
	 * @return
	 */
	public QueryBuilder<T> addGEClause(String param, Object value, SortDirection sortDirection) {
		if (param != null) { geParamMap.put(param, value); addOrder(param, sortDirection); }
		return this;
	}
	/**
	 * Equal 비교값을 제외한 나머지 비교 형태는 해당 비교 항목에 대한 Sort가 존재해야한다.
	 * @param param
	 * @param value
	 * @param sortDirection
	 * @return
	 */
	public QueryBuilder<T> addLEClause(String param, Object value, SortDirection sortDirection) {
		if (param != null) { leParamMap.put(param, value); addOrder(param, sortDirection); }
		return this;
	}
	
	@SuppressWarnings("rawtypes")
	public QueryBuilder<T> addFilter(String param, Object value) {
		if (param != null) {
//			if (value != null && (value.getClass().getCanonicalName().equals(ArrayList.class.getCanonicalName())
//					|| value.getClass().getCanonicalName().equals(LinkedList.class.getCanonicalName()))) {
			if (isCollection(value)) {
				if (((Collection)value).size() > 0) {
					if (filterQuery == null) {
						filterQuery = new StringBuilder();
					} else {
						filterQuery.append(" AND");
					}

					String joinValue = StringUtils.join((Collection)value, "','");
				
					filterQuery.append(String.format(" %s.%s IN ('%s')", aliasName, param, joinValue)); 
				}
			} else {
				filterMap.put(param, value);
			}
		}
		return this;
	}
	@SuppressWarnings("rawtypes")
	public QueryBuilder<T> addNIFilter(String param, Object value, boolean isStringValue) {
		if (param != null) {
//			if (value != null && (value.getClass().getCanonicalName().equals(ArrayList.class.getCanonicalName())
//					|| value.getClass().getCanonicalName().equals(LinkedList.class.getCanonicalName()))) {
				
			if (value != null & isCollection(value)) {
				if (((Collection)value).size() > 0) {
					if (niFilterQuery==null) {
						niFilterQuery = new StringBuilder();
					} else {
						niFilterQuery.append(" AND");
					}
					if (isStringValue) {
						String joinValue = StringUtils.join((Collection)value, "','");
						niFilterQuery.append(String.format(" %s.%s NOT IN ('%s')", aliasName, param, joinValue));
					} else {
						String joinValue = StringUtils.join((Collection)value, ",");
						niFilterQuery.append(String.format(" %s.%s NOT IN (%s)", aliasName, param, joinValue));
					}
				}
			} else {
				niFilterMap.put(param, value);
			}
		}
		return this;
	}
	
	public QueryBuilder<T> addOrder(String param, Object value) {
		if (param != null) { orderMap.put(param, value); }
		return this;
	}

	public QueryBuilder<T> addQueryOption(Object obj) {
		if (obj==null) { return this; }
		
		if (obj.getClass().getCanonicalName().equals(QueryOption.class.getCanonicalName())) { 
			addCommonQueryOption((QueryOption)obj);
		} else if (obj.getClass().getCanonicalName().equals(AuthQueryOption.class.getCanonicalName())) {
			addAuthQueryOption((AuthQueryOption)obj);
		}
		
		return this;
	}
	private void addCommonQueryOption(QueryOption queryOption) {
		if (queryOption != null){
			if (queryOption.getFilterOptions() != null) {
				for (FilterOption filterOption : queryOption.getFilterOptions()) {
					//queryStr.append(String.format(" AND %s IN (:%s)", filterOption.getFilterType(), filterOption.getFilterType()));
					filterMap.put(filterOption.getFilterType().toString(), filterOption.getFilterValues());
					//paramMap.put(filterOption.getFilterType().toString(), filterOption.getFilterValues());
				}
			}
			if (queryOption.getSortOptions() != null) {
				for (SortOption sortOption : queryOption.getSortOptions()) {
					orderMap.put(sortOption.getSortType().toString(), sortOption.getSortDirection());
					
//					if (orderStr == null) {
//						orderStr = new StringBuilder();
//						orderStr.append(" ORDER BY");
//						orderStr.append(String.format(" %s %s", sortOption.getSortType(), sortOption.getSortDirection()));
//					} else {
//						orderStr.append(String.format(", %s %s", sortOption.getSortType(), sortOption.getSortDirection()));
//					}
				}
			}
		}
	}
	private void addAuthQueryOption(AuthQueryOption authQueryOption) {
		if (authQueryOption != null){
			if (authQueryOption.getAuthSortOptions() != null) {
				for (AuthSortOption authSortOption : authQueryOption.getAuthSortOptions()) {
					orderMap.put(authSortOption.getAuthSortType().toString(), authSortOption.getSortDirection());
					
//					if (orderStr == null) {
//						orderStr = new StringBuilder();
//						orderStr.append(" ORDER BY");
//						orderStr.append(String.format(" %s %s", authSortOption.getAuthSortType(), authSortOption.getSortDirection()));
//					} else {
//						orderStr.append(String.format(", %s %s", authSortOption.getAuthSortType(), authSortOption.getSortDirection()));
//					}
				}
			}
		}
	}

	
	public TypedQuery<T> build(EntityManager mgr) throws Exception {
		try {
			init();
			TypedQuery<T> query = new QueryWrapper<T>(mgr.createQuery(makeQueryString()));
			setParameter(query);
//			logger.info("===JPQL(ORIGIN)===>"+query.toString());
//			logger.info("===JPQL(PARAMS)===>"+getQueryString());
			return query;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		}
	}
	public TypedQuery<Key> buildKeyOnlyRead(EntityManager mgr) throws Exception {
		try {
			this.fetchType = FetchType.KEY;
			init();
			TypedQuery<Key> query = new QueryWrapper<Key>(mgr.createQuery(makeQueryString()));
			setParameter(query);
//			logger.info("===JPQL(ORIGIN)===>"+query.toString());
//			logger.info("===JPQL(PARAMS)===>"+getQueryString());
			return query;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		}
	}
	private String makeQueryString() {
		for(Map.Entry<String, Object> entry : neParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" (m.%s <> :%s)", entry.getKey(), entry.getKey()));
			}
		}
		
		for(Map.Entry<String, Object> entry : paramMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" (m.%s = :%s)", entry.getKey(), entry.getKey()));
			}
		}
		
		for(Map.Entry<String, Object> entry : gtParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" (m.%s > :GT%s)", entry.getKey(), entry.getKey()));
			}
		}
		
		for(Map.Entry<String, Object> entry : ltParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" (m.%s < :LT%s)", entry.getKey(), entry.getKey()));
			}
		}
		
		for(Map.Entry<String, Object> entry : geParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" (m.%s >= :GE%s)", entry.getKey(), entry.getKey()));
			}
		}
		
		for(Map.Entry<String, Object> entry : leParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" (m.%s <= :LE%s)", entry.getKey(), entry.getKey()));
			}
		}
		
		for(String param : nullParamList) {
			if (conditionStr==null) {
				conditionStr = new StringBuilder();
				conditionStr.append(" WHERE");
			} else {
				conditionStr.append(" AND");
			}
			conditionStr.append(String.format(" (m.%s IS NULL)", param));
		}
		
		for(String param : notnullParamList) {
			if (conditionStr==null) {
				conditionStr = new StringBuilder();
				conditionStr.append(" WHERE");
			} else {
				conditionStr.append(" AND");
			}
			conditionStr.append(String.format(" (m.%s IS NOT NULL)", param));
		}
		
		for(Map.Entry<String, Object> entry : filterMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" %s.%s IN (:%s)", aliasName, entry.getKey(), entry.getKey()));
			}
		}
		
		for(Map.Entry<String, Object> entry : niFilterMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (conditionStr==null) {
					conditionStr = new StringBuilder();
					conditionStr.append(" WHERE");
				} else {
					conditionStr.append(" AND");
				}
				conditionStr.append(String.format(" %s.%s NOT IN (:%s)", aliasName, entry.getKey(), entry.getKey()));
			}
		}
		
		for(Map.Entry<String, Object> entry : orderMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				if (orderStr==null) {
					orderStr = new StringBuilder();
					orderStr.append(" ORDER BY");
				} else {
					orderStr.append(",");
				}
				
				String order = entry.getValue().toString();
				if (StringUtils.isEmpty(order)) { order = "ASC"; }
				orderStr.append(String.format(" m.%s %s", entry.getKey(), order));
			}
		}
		
		if (conditionStr != null) { queryStr.append(conditionStr); }
		if (filterQuery != null) {
			if (conditionStr != null) { queryStr.append(" AND");
			} else { queryStr.append(" WHERE"); }
			queryStr.append(filterQuery);
		}
		if (niFilterQuery != null) {
			if (conditionStr != null) { queryStr.append(" AND");
			} else { queryStr.append(" WHERE"); }
			queryStr.append(niFilterQuery);
		}
		// Order by 는 Update/Delete 시 허용되지 않는다. 사용하면 에러 발생
		if (orderStr != null && queryMode.equals(QueryMode.SELECT)) {
			queryStr.append(orderStr);
		}
		return queryStr.toString();
	}
	
	private void setParameter(TypedQuery<?> query) {
		for(Map.Entry<String, Object> entry : paramMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter(entry.getKey(), entry.getValue());
			}
		}
		for(Map.Entry<String, Object> entry : neParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter(entry.getKey(), entry.getValue());
			}
		}
		for(Map.Entry<String, Object> entry : gtParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter("GT"+entry.getKey(), entry.getValue());
			}
		}
		for(Map.Entry<String, Object> entry : ltParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter("LT"+entry.getKey(), entry.getValue());
			}
		}
		for(Map.Entry<String, Object> entry : geParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter("GE"+entry.getKey(), entry.getValue());
			}
		}
		for(Map.Entry<String, Object> entry : leParamMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter("LE"+entry.getKey(), entry.getValue());
			}
		}
		for(Map.Entry<String, Object> entry : filterMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter(entry.getKey(), entry.getValue());
			}
		}
		for(Map.Entry<String, Object> entry : niFilterMap.entrySet()) {
			if (entry.getKey() != null && entry.getValue() != null) {
				query = query.setParameter(entry.getKey(), entry.getValue());
			}
		}
	}
	
	/**
	 * QueryMode : SELECT, DELETE, (Do not support to bulk update)
	 */
	private void init() throws Exception {
		if (queryMode == null) { queryMode = QueryMode.SELECT; }
		if (fetchType == null) { fetchType = FetchType.ALL; }
		
		kind = ClassUtil.getSimpleClassName(clazz);
		superKind = ClassUtil.getSimpleSuperClassName(clazz);
		
		switch(fetchType) {
			case KEY : fetchStr = "key";
				break;
			case NAMESPACE : fetchStr = "__NAMESPACE__";
				break;
			case COUNT : fetchStr = String.format("COUNT(%s)", aliasName);
				break;
			case MAX :
			case MIN :
			case SUM :
			case AVG :
				if (StringUtils.isNotEmpty(aggregationField)) {
					fetchStr = String.format("%s(%s.%s)", fetchType.toString(), aliasName, aggregationField);
				} else {
					throw new Exception("Aggregation field name is required.");
				}
				break;	
			case ALL :
			default : 
				fetchStr = aliasName;
				break; 
		}
//		if (fetchType == null || fetchType.equals(FetchType.ALL)) { fetchStr = aliasName; }
//		else if (fetchType.equals(FetchType.KEY)) { fetchStr = "__KEY__"; }
//		else if (fetchType.equals(FetchType.NAMESPACE)) { fetchStr = "__NAMESPACE__"; }
//		else if (fetchType.equals(FetchType.COUNT)) { fetchStr = String.format("MAX(%s.priority)", aliasName); }

		if (Common.class.getSimpleName().equals(superKind)) {
			if (deleteCondition && !paramMap.containsKey(FLD.deleteYN)) { paramMap.put(FLD.deleteYN, "N"); }
			if (archiveCondition && !paramMap.containsKey(FLD.archiveYN)) { paramMap.put(FLD.archiveYN, "N"); }
			if (permanentDeleteCondition && !paramMap.containsKey(FLD.permanentDeleteYN)) { paramMap.put(FLD.permanentDeleteYN, "N"); }
		} else if (Base.class.getSimpleName().equals(superKind)) {
			if (deleteCondition && !paramMap.containsKey(FLD.deleteYN)) { paramMap.put(FLD.deleteYN, "N"); }
		}
		
		
		if (QueryMode.SELECT.equals(queryMode)) {
			queryStr.append(String.format("SELECT %s FROM %s AS %s", fetchStr, kind, aliasName));
		} else if (QueryMode.DELETE.equals(queryMode)) {
			queryStr.append(String.format("DELETE FROM %s AS %s", kind, aliasName));
			if (!paramMap.containsKey(FLD.deleteYN)) { paramMap.put(FLD.deleteYN, null); }
			if (!paramMap.containsKey(FLD.archiveYN)) { paramMap.put(FLD.archiveYN, null); }
			if (!paramMap.containsKey(FLD.permanentDeleteYN)) { paramMap.put(FLD.permanentDeleteYN, null); }
		} 
	}
	private String toDateString(Date date) {
		String dateString = null;
		try {
			dateString = CalendarUtil.toString(date, "yyyy-MM-dd HH:mm:ss");
		} catch (Exception ex) {
			dateString = date.toString();
		}
		return dateString;
	}
	
	private boolean isCollection(Object ob) {
		return ob instanceof Collection/* || ob instanceof Map*/;
	}
	
	public static int getCursorPosition(String cursorString) {
		if (StringUtils.isBlank(cursorString)) { return 0; }
		try {
			return Integer.parseInt(cursorString);
		} catch (NumberFormatException ex) {
			LOG.warning("[Query position invalid] " + ex.getMessage());
			return 0;
		}
	}
	
	public static String getCursorString(int cursorPosition) {
		return String.valueOf(cursorPosition);
	}

//	public QueryBuilder<T> addQueryOption(QueryOption queryOption) {
//	if (queryOption != null){
//		if (queryOption.getFilterType() != null) {
//			queryStr.append(String.format(" AND %s IN (:%s) ", queryOption.getFilterType(), queryOption.getFilterType()));
//			paramMap.put(queryOption.getFilterType().toString(), queryOption.getFilterValues());
//		}
//		if (queryOption.getSortType() != null) {
//			if (orderStr==null) { orderStr = new StringBuilder(); orderStr.append(" ORDER BY "); }
//			orderStr.append(String.format(" %s %s ", queryOption.getSortType(), queryOption.getSortDirection().toString()));
//		}
//	}
//	return this;
//}
//	public QueryBuilder<T> addFilter(FilterType filterType, List<Object> filerValues) {
//		queryStr.append(String.format(" AND %s IN (:%s) ", filterType.toString().toLowerCase(), filterType.toString().toLowerCase()));
//		paramMap.put(filterType.toString().toLowerCase(), filerValues);
//		return this;
//	}
//	public QueryBuilder<T> addSorter(SortType sortType, SortDirection sortDirection) {
//		if (orderStr == null) {
//			orderStr = new StringBuilder();
//			orderStr.append(" ORDER BY ");
//			orderStr.append(String.format(" %s %s ", sortType.toString().toLowerCase(), sortDirection.toString()));
//		} else {
//			orderStr.append(String.format(", %s %s ", sortType.toString().toLowerCase(), sortDirection.toString()));
//		}
//		
//		return this;
//	}
	
	
//	/**
//	 * Common Class를 상속 받은 Entity들을 조회하는 기본 쿼리
//	 * @param kind
//	 * @return
//	 */
//	private void commonQueryStr() {
//		setArchiveCondition(true);
//		setPermanentDeleteCondition(true);
//		simpleQueryStr();
//	}
//	
//	/**
//	 * BASE Class만 상속 받은 Entity를 조회하는 기본 쿼리
//	 * @param kind
//	 * @return
//	 */
//	private void baseQueryStr() {
//		setArchiveCondition(false);
//		setPermanentDeleteCondition(false);
//		
//		simpleQueryStr();
//	}
//	
//	private void simpleQueryStr() {
//		queryStr.append(String.format("SELECT %s From %s AS %s ", fetchStr, kind, aliasName));
//		if (deleteCondition) { queryStr.append(" deleteYN = 'N' "); }
//		if (archiveCondition) { queryStr.append(" AND archiveYN = 'N' "); }
//		if (permanentDeleteCondition) { queryStr.append(" AND permanentDeleteYN = 'N' "); }
//	}
}

