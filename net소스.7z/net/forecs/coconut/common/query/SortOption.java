package net.forecs.coconut.common.query;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.code.SortDirection;
import net.forecs.coconut.common.code.SortType;

public class SortOption implements Serializable {
	/**
	 * @Description :
	 * @Author      : hyeunwoo.shim@forecs.net 2015. 4. 24.
	 */
	private static final long serialVersionUID = 2171667711017031150L;
	@Getter @Setter
	private SortType sortType;
	@Getter @Setter
	private SortDirection sortDirection;
}
