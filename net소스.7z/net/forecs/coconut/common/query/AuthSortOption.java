package net.forecs.coconut.common.query;

import net.forecs.coconut.common.code.AuthSortType;
import net.forecs.coconut.common.code.SortDirection;

class AuthSortOption {
	private AuthSortType authSortType;
	private SortDirection sortDirection;
	
	
	public AuthSortType getAuthSortType() {
		return authSortType;
	}

	public void setAuthSortType(AuthSortType authSortType) {
		this.authSortType = authSortType;
	}

	public SortDirection getSortDirection() {
		return sortDirection;
	}
	public void setSortDirection(SortDirection sortDirection) {
		this.sortDirection = sortDirection;
	}
}
