package net.forecs.coconut.common.code;

public enum StartDayOfWeek {
	SU,
	MO
}
