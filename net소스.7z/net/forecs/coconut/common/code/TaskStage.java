package net.forecs.coconut.common.code;


public enum TaskStage {
	Ideation(0),
	Incubation(1),
	Reference(2),
	Preparation(3),
	OnGoing(4),
	Pending(5),
	Drop(6),
	Complete(7),
	Trash(8),
	None(9);
	 
	private int value;

	private TaskStage(int value) {
		this.value = value;
	}
	
	public int getOrdinal() {
		return value;
	}
}

