package net.forecs.coconut.common.code;

public enum SortDirection {
	DESC,
	ASC
}
