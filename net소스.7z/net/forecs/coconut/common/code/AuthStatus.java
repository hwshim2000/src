package net.forecs.coconut.common.code;

public enum AuthStatus {
	ACTIVE,
	INACTIVE,
	WAITING,
	TEMPLATE
}
