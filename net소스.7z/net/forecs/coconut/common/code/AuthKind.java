package net.forecs.coconut.common.code;

/**
 * 사용자 권한 대상 KIND
 * @author 현우
 *
 */
public enum AuthKind {
	@Deprecated
	DOMAINS,
	GROUPS,
	BOARDS,
	TASKLISTS,
	TASKS,
	@Deprecated
	TASK_COMMENTS,
	NOTICE,
	@Deprecated
	NOTICE_COMMENTS,
	ATTACHEMENTS,
	SCHEDULE
}
