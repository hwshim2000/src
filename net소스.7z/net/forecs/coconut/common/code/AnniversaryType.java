package net.forecs.coconut.common.code;

public enum AnniversaryType {
	BIRTH,
	WEDDING
}
