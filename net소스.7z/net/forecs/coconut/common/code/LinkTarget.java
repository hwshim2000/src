package net.forecs.coconut.common.code;

public enum LinkTarget {
	WEB,
	POPUP,
	EMAIL,
	MOBILE
}
