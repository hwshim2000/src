package net.forecs.coconut.common.code;

/**
 * Task 타입
 * TASK : 일반 타입
 * APPOINTMENT : Calendar에서만 표시되는 타입
 * ANNIVERSARY : Calendar에서만 표시되는 타입
 * HOLIDAY : Calendar에서만 표시되는 타입
 * PRIVATE : 개인 Calendar로서 현재 Google 메일만 해당.(개인 Calendar중에서도 Role이 owner이고 primary가 true인것만 가져오는것이 합당하나 현재는 모든 Calendar를 저장해 놓는다.)
 * Task의 키값은 DomainId가 부모키값이고, TaskType+User Key의 name값을 Key Name으로 하여 유일한값 보장 (또는 DomainKey, UserKey 가 부모키이고 TaskType을 Task의 Key name으로 한다.)
 * BIRTH,		// DOMAIN에 유일한값 (Tasks에 이 타입을 넣을땐 boardId는 무시하거나 Null값이다.(보드에 상관없이 개인 기념일이고 유일한 값이므로) 사용자 도메인 등록시 값이 있으면 자동으로 도메인값을 이용하여 태스크 생성하고 기념일 등록
 * WEDDING,	// DOMAIN에 유일한값 (Tasks에 이 타입을 넣을땐 boardId는 무시하거나 Null값이다.(보드에 상관없이 개인 기념일이고 유일한 값이므로) 사용자 도메인 등록시 값이 있으면 자동으로 도메인값을 이용하여 태스크 생성하고 기념일 등록
 * @author 현우
 *
 */
public enum EventType {
	TASK,
	APPOINTMENT,
	ANNIVERSARY,
	PRIVATE_ANNIVERSARY,
	SYSTEM_HOLIDAY,
	HOLIDAY,
	PRIVATE
	//	사용자 Profile 변경시 체크하여 업데이트 필요
	// Task의 키값은 DomainId가 부모키값이고, TaskType+User Key의 name값을 Key Name으로 하여 유일한값 보장 (또는 DomainKey, UserKey 가 부모키이고 TaskType을 Task의 Key name으로 한다.)
//	BIRTH,		// DOMAIN에 유일한값 (Tasks에 이 타입을 넣을땐 boardId는 무시하거나 Null값이다.(보드에 상관없이 개인 기념일이고 유일한 값이므로) 사용자 도메인 등록시 값이 있으면 자동으로 도메인값을 이용하여 태스크 생성하고 기념일 등록
//	WEDDING,	// DOMAIN에 유일한값 (Tasks에 이 타입을 넣을땐 boardId는 무시하거나 Null값이다.(보드에 상관없이 개인 기념일이고 유일한 값이므로) 사용자 도메인 등록시 값이 있으면 자동으로 도메인값을 이용하여 태스크 생성하고 기념일 등록
}
