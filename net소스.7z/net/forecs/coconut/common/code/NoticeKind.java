package net.forecs.coconut.common.code;

public enum NoticeKind {
	SYSTEM,
	DOMAINS,
	BOARDS,
	TASKS
}
