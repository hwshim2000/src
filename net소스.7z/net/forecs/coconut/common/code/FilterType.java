package net.forecs.coconut.common.code;

public enum FilterType {
	//labelIds,			// use task datastore & index search
	assignMembers,		// use task index search
	subscriptionMembers,// use task index search
	dueDate				// use only task search (현재 시점 이후 가장 임박한(ASCENDING) completeDate가 없는 task가 대상)
}
