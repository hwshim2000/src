package net.forecs.coconut.common.code;

/**
 * 사용자 Action이 일어나는 Object 종류
 * @author 현우
 *
 */

public enum ActivityKind {
	DOMAINS,
	GROUPS,
	BOARDS,
	TASKLISTS,
	TASKS,
	@Deprecated
	TASK_COMMENTS,
	TASK_CHECKLISTS,
	@Deprecated
	TASK_CHECKLIST_COMMENTS,
	TASK_TIMELINES,
	TASK_TIMELINE_COMMENTS,
	EVENTS,
	NOTICE,
	@Deprecated
	NOTICE_COMMENTS,
	ATTACHEMENTS,
	SCHEDULE,
	USERS,
	USAGE
}
