package net.forecs.coconut.common.code;


public enum CreateNoticeAuth {
	OWNER(Auth.OWNER),
	MEMBER(Auth.MEMBER);

	@SuppressWarnings("unused")
	private Auth auth;

	private CreateNoticeAuth(Auth auth) {
		this.auth = auth;
	}
}
