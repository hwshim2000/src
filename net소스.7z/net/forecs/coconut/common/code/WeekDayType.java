package net.forecs.coconut.common.code;

public enum WeekDayType {
	SU,
	MO,
	TU,
	WE,
	TH,
	FR,
	SA
}
