package net.forecs.coconut.common.code.security;

public enum Scope {
	ADMIN,
	DOMAIN,
	BOARD,
	DASHBOARD,
	TASK,
	EVENT,
	NOTICE,
	BILL,
	COUPON,
	USAGE,
	DATA,
	PROFILE,
	NONE
}
