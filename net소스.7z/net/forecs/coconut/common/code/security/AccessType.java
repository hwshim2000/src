package net.forecs.coconut.common.code.security;

public enum AccessType {
	online,
	offline
}
