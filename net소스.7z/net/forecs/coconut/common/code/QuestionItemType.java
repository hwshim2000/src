package net.forecs.coconut.common.code;

public enum QuestionItemType {
	FLAT,
	RADIO,
	CHECKBOX,
	SHORT,
	LONG
}
