package net.forecs.coconut.common.code;


public enum CreateTaskAuth {
	OWNER(Auth.OWNER),
	MEMBER(Auth.MEMBER);

	@SuppressWarnings("unused")
	private Auth auth;

	private CreateTaskAuth(Auth auth) {
		this.auth = auth;
	}
}
