package net.forecs.coconut.common.code;

public enum NotificationType {
	INSTANT,
	MINUTE,
	HOUR,
	DAY
}
