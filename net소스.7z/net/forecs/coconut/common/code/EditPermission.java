package net.forecs.coconut.common.code;


public enum EditPermission {
	OWNER(Auth.OWNER),
	MEMBER(Auth.MEMBER);

	@SuppressWarnings("unused")
	private Auth auth;

	private EditPermission(Auth auth) {
		this.auth = auth;
	}
}
