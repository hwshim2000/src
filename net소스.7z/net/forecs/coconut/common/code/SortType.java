package net.forecs.coconut.common.code;

/**
 * @Project    : coconut
 * @Package    : net.forecs.coconut.common.code
 * @FileName   : SortType.java
 * @Date       : 2015. 3. 30.
 * @Author     : hyeunwoo.shim@forecs.net
 * @Version    :
 * @Histories  :
 * @Description:
 */
public enum SortType {
	created,
	creator,
	title,
	modified,
	priority,
	ordernum,
	lastCommented,	// use only taskTimeline search
	stageOrdinal,	// use only task search
	boardTitle,		// use only task search
	boardCreated	// use only task search
}
