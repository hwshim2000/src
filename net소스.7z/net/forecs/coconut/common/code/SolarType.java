package net.forecs.coconut.common.code;

public enum SolarType {
	SOLAR,
	LUNAR
}
