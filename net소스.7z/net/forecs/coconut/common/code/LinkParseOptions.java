package net.forecs.coconut.common.code;

import lombok.Getter;
import lombok.Setter;

public class LinkParseOptions {
	final static int DEF_TITLE_ELLIPSIS_LENGTH = 50;
	final static int DEF_DESCRIPTION_ELLIPSIS_LENGTH = 512;
	final static int DEF_IMAGES_COUNT = 30;
	final static int DEF_HREFS_COUNT = 10;
	final static int DEF_TEXTS_COUNT = 20;
	final static int DEF_IGNORE_TEXT_LENGTH = 50;
	final static int LIMIT_IMAGE_WIDTH = 100;
	final static int LIMIT_IMAGE_HEIGHT = 100;
	final static int LIMIT_IMAGE_SIZE = 10000;
	
	@Getter @Setter
	private String encoding;
	@Getter @Setter
	private boolean detail = false;
	@Getter @Setter
	private boolean useUserAgent = false;
	@Getter @Setter
	private String userAgent = "Apache-HttpClient/release (java 1.5)";
	@Getter @Setter
	private boolean filterImage = false;
	
	private Integer imageSize;
	public Integer getImageSize() {
		if (imageSize==null || imageSize<=0) { imageSize = LIMIT_IMAGE_SIZE; }
		return imageSize;
	}
	public void setImageSize(Integer imageSize) {
		if (imageSize==null || imageSize<=0) { imageSize = LIMIT_IMAGE_SIZE; }
		this.imageSize = imageSize;
	}
	private Integer imageWidth;
	public Integer getImageWidth() {
		if (imageWidth==null || imageWidth<=0) { imageWidth = LIMIT_IMAGE_WIDTH; }
		return imageWidth;
	}
	public void setImageWidth(Integer imageWidth) {
		if (imageWidth==null || imageWidth<=0) { imageWidth = LIMIT_IMAGE_WIDTH; }
		this.imageWidth = imageWidth;
	}
	private Integer imageHeight;
	public Integer getImageHeight() {
		if (imageHeight==null || imageHeight<=0) { imageHeight = LIMIT_IMAGE_HEIGHT; }
		return imageHeight;
	}
	public void setImageHeight(Integer imageHeight) {
		if (imageHeight==null || imageHeight<=0) { imageHeight = LIMIT_IMAGE_HEIGHT; }
		this.imageHeight = imageHeight;
	}
	
	private Integer titleEllipsisLength;
	public Integer getTitleEllipsisLength() {
		if (titleEllipsisLength==null || titleEllipsisLength<=0) { titleEllipsisLength = DEF_TITLE_ELLIPSIS_LENGTH; }
		return titleEllipsisLength;
	}
	public void setTitleEllipsisLength(Integer titleEllipsisLength) {
		if (titleEllipsisLength==null || titleEllipsisLength<=0) { titleEllipsisLength = DEF_TITLE_ELLIPSIS_LENGTH; }
		this.titleEllipsisLength = titleEllipsisLength;
	}
	
	private Integer descriptionEllipsisLength;
	public Integer getDescriptionEllipsisLength() {
		if (descriptionEllipsisLength==null || descriptionEllipsisLength<=0) { descriptionEllipsisLength = DEF_DESCRIPTION_ELLIPSIS_LENGTH; }
		return descriptionEllipsisLength;
	}
	public void setDescriptionEllipsisLength(Integer descriptionEllipsisLength) {
		if (descriptionEllipsisLength==null || descriptionEllipsisLength<=0) { descriptionEllipsisLength = DEF_DESCRIPTION_ELLIPSIS_LENGTH; }
		this.descriptionEllipsisLength = descriptionEllipsisLength;
	}
	private Integer imagesCount;
	public Integer getImagesCount() {
		if (imagesCount==null || imagesCount<=0) { imagesCount = DEF_IMAGES_COUNT; }
		return imagesCount;
	}
	public void setImagesCount(Integer imagesCount) {
		if (imagesCount==null || imagesCount<=0) { imagesCount = DEF_IMAGES_COUNT; }
		this.imagesCount = imagesCount;
	}
	
	private Integer hrefsCount;
	public Integer getHrefsCount() {
		if (hrefsCount==null || hrefsCount<=0) { hrefsCount = DEF_HREFS_COUNT; }
		return hrefsCount;
	}
	public void setHrefsCount(Integer hrefsCount) {
		if (hrefsCount==null || hrefsCount<=0) { hrefsCount = DEF_HREFS_COUNT; }
		this.hrefsCount = hrefsCount;
	}
	private Integer textsCount;
	public Integer getTextsCount() {
		if (textsCount==null || textsCount<=0) { textsCount = DEF_TEXTS_COUNT; }
		return textsCount;
	}
	public void setTextsCount(Integer textsCount) {
		if (textsCount==null || textsCount<=0) { textsCount = DEF_TEXTS_COUNT; }
		this.textsCount = textsCount;
	}
	private Integer ignoreTextLength;
	public Integer getIgnoreTextLength() {
		if (ignoreTextLength==null || ignoreTextLength<=0) { ignoreTextLength = DEF_IGNORE_TEXT_LENGTH; }
		return ignoreTextLength;
	}
	public void setIgnoreTextLength(Integer ignoreTextLength) {
		if (ignoreTextLength==null || ignoreTextLength<=0) { ignoreTextLength = DEF_IGNORE_TEXT_LENGTH; }
		this.ignoreTextLength = ignoreTextLength;
	}
}