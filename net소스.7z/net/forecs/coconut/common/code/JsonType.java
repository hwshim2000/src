package net.forecs.coconut.common.code;

public enum JsonType {
	NONE,
	OBJECT,
	ARRAY
}
