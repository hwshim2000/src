package net.forecs.coconut.common.code;

import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Notifications;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.attachment.Uploads;
import net.forecs.coconut.entity.backup.Backups;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Coupons;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Calendars;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.channel.WebHook;
import net.forecs.coconut.entity.channel.WebHookLog;
import net.forecs.coconut.entity.domain.Departments;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.DomainsLog;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.tasklist.Tasklists;
import net.forecs.coconut.entity.user.UserDevices;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskHistories;
import net.forecs.coconut.entity.workspace.TaskLabelMap;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;

public enum Kind {
	Activities,
	Attachments,
	AttachmentsMap,
	Images,
	Backups,
	Bills,
	Boards,
	Calendars,
	ChannelToken,
	Coupons,
	Domains,
	DomainsLog,
	Events,
	Groups,
	MemberAuths,
	Notice,
	NotificationSettings,
	Notifications,
	Subscriptions,
	Tasks,
	Tasklists,
	TaskChecklistHistories,
	TaskChecklists,
	TaskHistories,
	TaskLabelMap,
	TaskLabels,
	TaskTimelineComments,
	TaskTimelines,
	Users,
	UserProfiles,
	UserSetting,
	Usage,
	UsageLogs,
	UserDevices,
	WebHook,
	WebHookLog,
	Departments,
	Emoticons,
	Uploads,
	Auths,
	Tokens,
;

	public static void main(String[] args) {
		System.out.println(Activities.class.getSimpleName()+",");
		System.out.println(Attachments.class.getSimpleName()+",");
		System.out.println(AttachmentsMap.class.getSimpleName()+",");
		System.out.println(Images.class.getSimpleName()+",");
		System.out.println(Backups.class.getSimpleName()+",");
		System.out.println(Bills.class.getSimpleName()+",");
		System.out.println(Boards.class.getSimpleName()+",");
//		System.out.println(BoardInvites.class.getSimpleName()+",");	// deprecated
//		System.out.println(BoardLinks.class.getSimpleName()+",");	// deprecated
		System.out.println(Calendars.class.getSimpleName()+",");
		System.out.println(ChannelToken.class.getSimpleName()+",");
		System.out.println(Coupons.class.getSimpleName()+",");
		System.out.println(Domains.class.getSimpleName()+",");
		System.out.println(DomainsLog.class.getSimpleName()+",");
		System.out.println(Events.class.getSimpleName()+",");
		System.out.println(Groups.class.getSimpleName()+",");
		System.out.println(MemberAuths.class.getSimpleName()+",");
		System.out.println(Notice.class.getSimpleName()+",");
//		System.out.println(NoticeComments.class.getSimpleName()+",");	// deprecated
		System.out.println(NotificationSettings.class.getSimpleName()+",");
		System.out.println(Notifications.class.getSimpleName()+",");
		System.out.println(Subscriptions.class.getSimpleName()+",");
		System.out.println(Tasks.class.getSimpleName()+",");
		System.out.println(Tasklists.class.getSimpleName()+",");
//		System.out.println(TaskChecklistComments.class.getSimpleName()+",");
		System.out.println(TaskChecklistHistories.class.getSimpleName()+",");
		System.out.println(TaskChecklists.class.getSimpleName()+",");
//		System.out.println(TaskComments.class.getSimpleName()+",");		// deprecated
		System.out.println(TaskHistories.class.getSimpleName()+",");
		System.out.println(TaskLabelMap.class.getSimpleName()+",");
		System.out.println(TaskLabels.class.getSimpleName()+",");
		System.out.println(TaskTimelineComments.class.getSimpleName()+",");
		System.out.println(TaskTimelines.class.getSimpleName()+",");
//		System.out.println(TaskTimelineScores.class.getSimpleName()+",");	// deprecated
		System.out.println(Users.class.getSimpleName()+",");
		System.out.println(UserProfiles.class.getSimpleName()+",");
		System.out.println(UserSetting.class.getSimpleName()+",");
		System.out.println(Usage.class.getSimpleName()+",");
		System.out.println(UsageLogs.class.getSimpleName()+",");
		System.out.println(UserDevices.class.getSimpleName()+",");
		System.out.println(WebHook.class.getSimpleName()+",");
		System.out.println(WebHookLog.class.getSimpleName()+",");
		System.out.println(Departments.class.getSimpleName()+",");
		System.out.println(Emoticons.class.getSimpleName()+",");
		System.out.println(Uploads.class.getSimpleName()+",");
		
		System.out.println(Auths.class.getSimpleName()+",");
		System.out.println(Tokens.class.getSimpleName()+",");
	}
}