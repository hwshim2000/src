package net.forecs.coconut.common.code;

public enum UserType {
	SITE,
	DOMAIN,
	@Deprecated
	MEMEBER, 
	GUEST
}
