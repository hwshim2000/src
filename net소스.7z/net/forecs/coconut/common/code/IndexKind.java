package net.forecs.coconut.common.code;

public enum IndexKind {
	AttachmentIndex,
	TaskIndex,
	ChecklistHistoryIndex,
	ChecklistIndex,
	CommentIndex,
	EventIndex,
	NoticeIndex,
	TimelineIndex,
	UserIndex
}
