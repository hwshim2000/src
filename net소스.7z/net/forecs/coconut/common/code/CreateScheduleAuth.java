package net.forecs.coconut.common.code;


public enum CreateScheduleAuth {
	OWNER(Auth.OWNER),
	MEMBER(Auth.MEMBER);

	@SuppressWarnings("unused")
	private Auth auth;

	private CreateScheduleAuth(Auth auth) {
		this.auth = auth;
	}
}
