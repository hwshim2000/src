package net.forecs.coconut.common.code;

public enum AlarmTriggerType {
	MINUTE,
	HOUR,
	DAY,
	WEEK
}
