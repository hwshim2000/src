package net.forecs.coconut.common.code;

@Deprecated
public enum EvaluateType {
	Excellent,
	Good,
	Effort
}
