package net.forecs.coconut.common.code;

public enum ServiceType {
	TRIAL,
	STANDARD,
	DEFERRED,
//	@Deprecated
//	GOLD,
//	@Deprecated
//	PREMIUM,
	GSUITE //@Deprecated or not used
}
