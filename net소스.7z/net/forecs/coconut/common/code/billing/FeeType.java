package net.forecs.coconut.common.code.billing;

@Deprecated
public enum FeeType {
	FlatRate,	// 정액제
	MeterRate	// 종량제
}
