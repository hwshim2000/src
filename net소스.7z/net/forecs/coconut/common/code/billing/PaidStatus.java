package net.forecs.coconut.common.code.billing;

public enum PaidStatus {
	all,
	paid,
	ready,
	cancelled,
	failed,
	subscribed
}
