package net.forecs.coconut.common.code.billing;

@Deprecated
public enum PaidType {
	AUTH,
	NOAUTH
}
