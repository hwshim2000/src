package net.forecs.coconut.common.code.billing;

public enum BlockType {
	/**
	 * @Description : 서비스 허용량을 초과하더라도 서비스 사용 가능
	 */
	PASS,
	/**
	 * @Description : 서비스 사용량에 상관없이 서비스 차단.
	 */
	BLOCK,
	/**
	 * @Description : 서비스 사용량을 파악하여 자동으로 차단 혹은 통과
	 */
	AUTO
}
