package net.forecs.coconut.common.code.billing;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

public class IamportBill implements Serializable {
	private static final long serialVersionUID = -3190441600776175265L;
	
	@Getter @Setter
	private String imp_uid;			// 아임포트 거래 고유 번호
	@Getter @Setter
	private String pay_method;		// PG사가 제공하는 결제수단('card' : 신용카드, 'trans' : 실시간계좌이체, 'vbank' : 가상계좌, 'phone' : 휴대폰소액결제)
	@Getter @Setter
	private String merchant_uid;	// 상점에서 전달한 고유번호. 전달하지 않았을 때에는 임의 생성됨
	@Getter @Setter
	private String name;			// 주문명
	@Getter @Setter
	private Integer amount;			// 결제된 금액
	@Getter @Setter
	private Integer cancel_amount;	// 취소된 금액
	@Getter @Setter
	private String pg_provider;		// PG사 이름. inicis 등
	@Getter @Setter
	private String pg_tid;			// PG사 승인번호
	@Getter @Setter
	private String apply_num;		// 카드사 승인번호(신용카드 결제일 때만 있음)
	@Getter @Setter
	private String vbank_num;		// 가상계좌 입금계좌번호(가상계좌 결제일 때만 있음)
	@Getter @Setter
	private String vbank_date;		// 가상계좌 입금기한(가상계좌 결제일 때만 있음)
	@Getter @Setter
	private String vbank_holder;	// 가상계좌 예금주(가상계좌 결제일 때만 있음)
	@Getter @Setter
	private String vbank_name;		// 가상계좌 은행명(가상계좌 결제일 때만 있음)
	@Getter @Setter
	private String buyer_name;		// 구매자명
	@Getter @Setter
	private String buyer_email;		// 구매자 이메일 주소
	@Getter @Setter
	private String buyer_tel;		// 구매자 전화번호
	@Getter @Setter
	private String buyer_addr;		// 구매자 배송 주소
	@Getter @Setter
	private String buyer_postcode;	// 구매자 배송주소 우편 번호
	@Getter @Setter
	private String custom_data;		// 결제요청시 전달한 custom_data. javascript object로 그대로 반환	--> 여기에 domainName, ID, serviceType, 사용자 수등의 정보를 넣으면 될듯.
	@Getter @Setter
	private String status;			// 결제 상태(결제성공 직후 상태이므로 paid). ready:미결제 / paid:결제완료 / cancelled:결제취소 / failed:결제실패 중 하나의 값을 가진다.
	@Getter @Setter
	private Long paid_at;			// 결제성공 시점의 UNIX timestamp	--> Date 타입으로 변경
	@Getter @Setter
	private String receipt_url;		// 결제건의 매출전표 URL
	@Getter @Setter
	private String cancel_reason;	// 취소 사유
	@Getter @Setter
	private Long cancelled_at;		// 취소 일시
	@Getter @Setter
	private String card_name;		// 카드명
	@Getter @Setter
	private Integer card_quota;		// 
	@Getter @Setter
	private String fail_reason;		// 실패 사유
	@Getter @Setter
	private Long failed_at;			// 취소 일시
	@Getter @Setter
	private String user_agent;		// 사용자 agent 정보
	
	@Getter @Setter
	private String bank_code;		// 실시간계좌이체 졀제가 아닌경우 null로 전달
	@Getter @Setter
	private String card_code;		// 신용카드 결제가 아닌경우 null로 전달
	@Getter @Setter
	private String vbank_code;		// 가상계좌 결제가 아니거나 발급되지 않은 경우 null로 전달
	
	public Date getFaildDate() {
		if (failed_at != null && failed_at != 0) {
			return new Date(failed_at*1000);
		}
		return null;
	}
	public Date getCancelledDate() {
		if (cancelled_at != null && cancelled_at != 0) {
			return new Date(cancelled_at*1000);
		}
		return null;
	}
	public Date getPaidDate() {
		if (paid_at != null && paid_at != 0) {
			return new Date(paid_at*1000);
		}
		return null;
	}
}
