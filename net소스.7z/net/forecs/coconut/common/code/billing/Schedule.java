package net.forecs.coconut.common.code.billing;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Schedule {

	@Getter @Setter
	private String merchant_uid;
	@Getter @Setter
	private Long schedule_at;
	@Getter @Setter
	private Integer amount;
	
	@JsonIgnore
	public Date getScheduleDate() {
		if (schedule_at != null && schedule_at != 0) {
			return new Date(schedule_at*1000);
		}
		return null;
	}
}
