package net.forecs.coconut.common.code.billing;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.entity.billing.Bills;


public class CancelInfo implements Serializable {
	private static final long serialVersionUID = -4188753242498440351L;
	@Getter @Setter
	private String imp_uid;
	@Getter @Setter
	private String merchant_uid;
	@Getter @Setter
	private Integer amount;
	@Getter @Setter
	private String reason;
	@Getter @Setter
	private String refund_holder;
	@Getter @Setter
	private String refund_bank;
	@Getter @Setter
	private String refund_account;
	
	public CancelInfo() {}
	public CancelInfo(Bills bill, String reason) {
		this.merchant_uid = bill.getMerchant_uid();
		this.amount = bill.getAmount();
		this.reason = reason;
	}
	public CancelInfo(String merchant_uid, Integer amount, String reason) {
		this.merchant_uid = merchant_uid;
		this.amount = amount;
		this.reason = reason;
	}
/*	
	public Map<String, Object> toIamportEntities() {
		Map<String, Object> entityMap = new HashMap<String, Object>();
		
		if (StringUtils.isNotBlank(imp_uid)) {
			entityMap.put(FLD.imp_uid, imp_uid);				// 취소할 거래의 아임포트 고유번호
		}
		if (StringUtils.isNotBlank(merchant_uid)) {
			entityMap.put(FLD.merchant_uid, merchant_uid);		// 가맹점에서 전달한 거래 고유번호. imp_uid, merchant_uid 중 하나는 필수이어야 합니다.	두 값이 모두 넘어오면 imp_uid를 우선 적용합니다.
		}
		if (amount != null) {
			entityMap.put(FLD.amount, amount);					// 부분취소요청금액(누락이면 전액취소)
		}
		if (StringUtils.isNotBlank(reason)) {
			entityMap.put(FLD.reason, reason);					// 취소 사유
		}
		if (StringUtils.isNotBlank(refund_holder)) {
			entityMap.put(FLD.refund_holder, refund_holder);	// 환불계좌 예금주(가상계좌취소시 필수)
		}
		if (StringUtils.isNotBlank(refund_bank)) {
			entityMap.put(FLD.refund_bank, refund_bank);		// 환불계좌 은행코드(하단 은행코드표 참조, 가상계좌취소시 필수)
		}
		if (StringUtils.isNotBlank(refund_account)) {
			entityMap.put(FLD.refund_account, refund_account);	// 환불계좌 계좌번호(가상계좌취소시 필수)
		}
		
		return entityMap;
	}
*/	
}
