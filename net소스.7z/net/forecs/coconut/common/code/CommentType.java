package net.forecs.coconut.common.code;

public enum CommentType {
	@Deprecated
	WIKI,
	@Deprecated
	CHECKLIST,
	TIMELINE
}
