package net.forecs.coconut.common.code;

public enum CalendarAccessRole {
	owner,
	reader,
	freeBusyReader,
	writer
}
