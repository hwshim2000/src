package net.forecs.coconut.common.code;

public final class PrepareType {
	public final static String USERSTATUS = "USERSTATUS";
	public final static String BOARDS = "BOARDS";
	public final static String TASKTIMELINES = "TASKTIMELINES";
}
