package net.forecs.coconut.common.code;

public enum DomainsLogType {
	UPDATE_BLOCK,
	UPDATE_EXPIRATION,
	UPDATE_QUOTA,
	UPDATE_CASE,
	REGIST_COUPON,
	REVOKE_COUPON,
	UPDATE_SERVICE_TYPE,
	APPLY_BILL,
	CANCEL_BILL,
	@Deprecated
	SUBSCRIBE_BILL,
	@Deprecated
	UNSUBSCRIBE_BILL,
	CREATE_BOARD_AUTH
}
