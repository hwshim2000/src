package net.forecs.coconut.common.code;

import org.apache.commons.lang.StringUtils;

import net.fortuna.ical4j.model.property.Clazz;

public final class CalendarVisibility {
	public final static String DEFAULT = "default";
	public final static String PRIVATE = "private";
	public final static String PUBLIC = "public";
	public final static String CONFIDENTIAL = "confidential";
	
	public static Clazz visibilityToICalClazz(String value) {
		if (StringUtils.isNotBlank(value)) {
			if (PUBLIC.equals(value)) {
				return Clazz.PUBLIC;
			} else if (CONFIDENTIAL.equals(value)) {
				return Clazz.CONFIDENTIAL;
			} else {
				return Clazz.PRIVATE;
			}
		} else {
			return Clazz.PRIVATE;
		}
	}
	
	public static String iCalClazzToVisibility(Clazz clazz) {
		if (clazz != null) {
			if (Clazz.CONFIDENTIAL.equals(clazz)) {
				return CONFIDENTIAL;
			} else if (Clazz.PUBLIC.equals(clazz)) {
				return PUBLIC;
			} else {
				return PRIVATE;
			}
		} else {
			return PRIVATE;
		}
	}
}
