package net.forecs.coconut.common.code;

public enum Auth {
	ROOT(99),
	// jongwook.yi@forecs.net 2015-01-30 : Changed to use Users.isGuest(), Users.isAdmin(), Users.isSuper() and Base.isOwner()
	@Deprecated
	ADMIN(77),
	@Deprecated
	SUPER(66),
	OWNER(55),
	@Deprecated
	MANAGER(44),
	MEMBER(33),
	@Deprecated
	VIEWER(22),
	@Deprecated
	GUEST(11);

	@SuppressWarnings("unused")
	private int value;

	private Auth(int value) {
		this.value = value;
	}
}
