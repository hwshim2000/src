package net.forecs.coconut.common.code;

public enum AuthSortType {
	auth,
	authKind,
	authStatus,
	creator,
	created,
	modifier,
	modified,
	kindId
}
