package net.forecs.coconut.common.code;

public enum RecurrenceChangeType {
	/**
	 * @Description : 해당 일정만 변경(Recurrence의 ExceptionDates 참조)
	 * @Author      : hyeunwoo.shim@forecs.net 2015. 3. 25.
	 */
	ONLY,
	
	/**
	 * @Description : 모든 일정 변경
	 * @Author      : hyeunwoo.shim@forecs.net 2015. 3. 25.
	 */
	ALL,
	
	/**
	 * @Description : 이후 일정 모두 변경
	 * @Author      : hyeunwoo.shim@forecs.net 2015. 3. 25.
	 */
	AFTER
}
