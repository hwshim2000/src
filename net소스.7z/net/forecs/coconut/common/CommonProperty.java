package net.forecs.coconut.common;

import net.forecs.coconut.common.code.ServiceType;
import net.forecs.coconut.common.code.billing.BlockType;

public final class CommonProperty {
	//----------------------------------------------------------
	// COMMON
	//----------------------------------------------------------
	public static final boolean DEBUG = true;
	public static final String UTF_8 = "UTF-8";
	public static final String MS949 = "MS949";
	public static final String EUC_KR = "EUC-KR";
	
	public static final String DEFAULT_QUEUE_NAME = "default";
	public static final String DEFAULT_EMAIL_QUEUE_NAME = "DefaultEmailQueue";
	public static final String DEFAULT_EMAIL_SEND_URL = "/_ah/admin/queue/sendEmail";
	//public static final String ANDROID_CLIENT_ID = "";
	//public static final String ANDROID_AUDIENCE = WEB_CLIENT_ID;
	public static final String EMAIL_SCOPE = "https://www.googleapis.com/auth/userinfo.email";
	public static final String PROFILE_SCOPE = "https://www.googleapis.com/auth/userinfo.profile";
	public static final String CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar";
	public static final String WEB_BASE_URL = "https://www.cocoworks.net";
	public static final String BOARD_LINK_URL = WEB_BASE_URL + "/#/boards/board/";
	public static final String WORKSPACE_LINK_URL = WEB_BASE_URL + "/#/workspace/";
	public static final String DOMAIN_INFO_LINK_URL = WEB_BASE_URL + "#/domain/information/";
	public static final String INSTANCE_INIT_SERVLET_URL = "/_ah/admin/instance/init";
	
	public static final String SCOPE_ADMIN_DIRECTORY_USER_READONLY = "https://www.googleapis.com/auth/admin.directory.user.readonly";
	public static final String SCOPE_ADMIN_DIRECTORY_USER = "https://www.googleapis.com/auth/admin.directory.user";
	public static final String SCOPE_ADMIN_DIRECTORY_GROUP = "https://www.googleapis.com/auth/admin.directory.group";
	
	public static final String SYSTEM_USER_ID = "__SYSTEM__";
	public static final String SYSTEM_USER_NAME = "SYSTEM";
	public static final int SUBQUERY_PARAM_COUNT = 30;
	
	public static final long KB = 1024;
	public static final long MB = KB * KB;
	public static final long GB = MB * KB;
	public static final long TB = GB * KB;
	
	//----------------------------------------------------------
	// INIT DATA PREPARE
	//----------------------------------------------------------
	public static final String PREPARE_INIT_DATA_QUEUE = "PrepareQueue";
	public static final String PREPARE_INIT_DATA_URL = "/_ah/admin/queue/prepareInitData";
	
	//----------------------------------------------------------
	// USER
	//----------------------------------------------------------
	public static final String USER_PICTURE_URL = "/_ah/domain/user/picture";
	public static final String SEND_REG_CODE_URL = "/tasks/sendRegCode";
	public static final String ADMINID_FORMAT = "%sadmin";
	public static final String ADMIN_USERNAME = "admin";
	public static final String ADMIN_NICKNAME = "admin";
	
	//----------------------------------------------------------
	// USER_SETTING
	//----------------------------------------------------------
	public static final String USER_UI_SETTING_NAME = "uisettings";
	
	/** coconut project web client id & secrets */
	public static final String WEB_CLIENT_ID = "1042066804754-hd6nhgmg0pcfnjp0q76fe6mbg57u94rt.apps.googleusercontent.com";
	public static final String CLIENT_SECRETS_FILEPATH = "/client_secrets.json";
	public static final String SERVICE_ACCOUNT_EMAIL = "1042066804754-fqhu6keiaa9m6hh5iu429cqd04f57u13@developer.gserviceaccount.com";
	//public static final String SERVICE_ACCOUNT_EMAIL = "1042066804754-hd6nhgmg0pcfnjp0q76fe6mbg57u94rt.apps.googleusercontent.com";//같은용도의 또다른 계정
	public static final String SERVICE_ACCOUNT_PKCS12_FILE_PATH = "WEB-INF/CoCoWorks_Service_Account_Key.p12";
	//public static final String SERVICE_ACCOUNT_PKCS12_FILE_PATH = "war/WEB-INF/CoCoWorks_Service_Account_Key.p12";	// local java application 테스트시
	
	/** private development project web client id & secrets */
	//public static final String WEB_CLIENT_ID = "1073273458742-5mddepucma4lcu4n6kav62jjkg6g7fr7.apps.googleusercontent.com";
	//public static final String CLIENT_SECRETS_FILEPATH = "/client_secrets_dev.json";
	//public static final String SERVICE_ACCOUNT_EMAIL = "679798256317-3i9bupu89tjr4a710kkmmd0dn1r2vq9v@developer.gserviceaccount.com";
	//public static final String SERVICE_ACCOUNT_PKCS12_FILE_PATH = "WEB-INF/CoCoNut_Service_Account_Key.p12";
		
	
	
	//----------------------------------------------------------
	// SENDER EMAIL INFO
	//----------------------------------------------------------
	public final static String SENDER_NOREPLY_EMAIL = "noreply@cocoworks.net";
	public final static String SENDER_NOREPLY_NAME = "";
	public final static String SENDER_NOREPLY_PSWD = "20141010forecs";
	
	public final static String SENDER_MANAGER_EMAIL = "wiki-admin@forecs.net";
	public final static String SENDER_MANAGER_NAME = "Manager";
	public final static String SENDER_MANAGER_PSWD = "20141010forecs.net";
	
	//----------------------------------------------------------
	// DOMAIN SERVICE
	//----------------------------------------------------------
	public final static String DOMAIN_USER_EXCEL_UPLOAD_URL = "/_ah/domain/user/excelUpload";
	public final static String DOMAIN_USER_EXCEL_DOWNLOAD_URL = "/_ah/domain/user/excelDownload";	
	public final static String DOMAIN_USER_RANDOM_PASSWORD_URL = "/_ah/admin/user/sendRandomPassword";
	public final static String DOMAIN_USER_RANDOM_PASSWORD_TEMPLATE = "sendRandomPasswordEmail_{0}.ftl";
	public final static String DOMAIN_DEPARTMENTS_UPLOAD_URL = "/_ah/domain/departments/upload";
	public final static String DOMAIN_DEPARTMENTS_DOWNLOAD_URL = "/_ah/domain/departments/download";
	
	//----------------------------------------------------------
	// TASK SERVICE
	//----------------------------------------------------------
	public final static String TASK_DOWNLOAD_URL = "/_ah/task/download";
	
	//----------------------------------------------------------
	// ATTACHMENT SERVICE
	//----------------------------------------------------------
	public final static String ATTACHMENT_DOWNLOAD_URL = "/_ah/attachment/download";
	
	//----------------------------------------------------------
	// BOARD SERVICE
	//----------------------------------------------------------
	/** board invite url */
////	public final static String BOARD_INVITATION_URL = "_ah/api/boardService/v1/invite/confirm";
//	@Deprecated
//	public final static String BOARD_INVITATION_URL = "/_ah/admin/invite/guest";
//	/** UNIT(day) */
//	@Deprecated
//	public final static int DEFAULT_BOARD_INVITE_EXPIRATION_DAY = 30;
//	/** 초대가 빈번하지 않으면 default queue를 사용하는것으로.... */
//	@Deprecated
//	public final static String INVITATION_EMAIL_QUEUE_NAME = DEFAULT_EMAIL_QUEUE_NAME;
//	@Deprecated
//	public final static String INVITATION_EMAIL_TEMPLATE = "invitationEmail_{0}.ftl";
//	@Deprecated
//	//public final static String INVITATION_EMAIL_QUEUE_NAME = "InviationEmailQueue";
//	public final static String INVITATION_EMAIL_SEND_URL = "/_ah/admin/queue/sendInviteEmail";
//	@Deprecated
//	public final static String BOARD_LOGO_URL = "/_ah/domain/board/logo";
	
// <!-- hyeunwoo.shim 2017-03-09 deprecated appengine channel token service.
//	//----------------------------------------------------------
//	// CHANNEL
//	//----------------------------------------------------------
//	/** UNIT(minutes, default:120 (2 hours)) range : 0 ~ 24*60 */
//	@Deprecated
//	public final static int CHANNEL_CONNECT_EXPIRATION_TIME = 24*60;
//	@Deprecated
//	public final static String CHANNEL_CONNETED_URL = "/_ah/channel/connected/";
//	@Deprecated
//	public final static String CHANNEL_DISCONNECTED_URL = "/_ah/channel/disconnected/";
// -->
	//----------------------------------------------------------
	// DATASTORE QUERY & TRANSACTION 
	//----------------------------------------------------------
	/** UNIT(seconds): search result keep memcache. */
//	public final static int QUERY_RESULT_KEEP_TIME = 3600 * 24; //hours
	public final static int DEFAULT_TRANSACTION_COUNT = 5;
	
	//----------------------------------------------------------
	// NOTIFICATION
	//----------------------------------------------------------
	public final static String NOTIFICATION_EMAIL_QUEUE_NAME = "NotificationEmailQueue";
//	@Deprecated
//	public final static String NOTIFICATION_EMAIL_SEND_URL = "/_ah/admin/queue/sendNotificationEmail";
	public final static String NOTIFICATION_EMAIL_TEMPLATE = "notificationEmail_{0}.ftl";
	public final static String NOTIFICATION_QUEUE_NAME = "NotificationQueue";
	public final static String NOTIFICATION_EXECUTE_URL = "/_ah/admin/queue/executeNotification";
	public final static String PREPARE_NOTIFICATION_QUEUE_NAME = "PrepareNotificationQueue";
	public final static String PREPARE_NOTIFICATION_URL = "/_ah/admin/queue/prepareNotification";
	
	//----------------------------------------------------------
	// ALARM
	//----------------------------------------------------------
	public final static String ALARM_QUEUE_NAME = "AlarmQueue";
	public final static String ALARM_INVOKE_QUEUE_NAME = "AlarmInvokeQueue";
	public final static String ALARM_EXECUTE_URL = "/_ah/admin/queue/executeAlarm";
	public final static String ALARM_PUSH_URL = "/_ah/admin/queue/pushAlarm";
	
	//----------------------------------------------------------
	// ADMIN - DATA BACKUP
	//----------------------------------------------------------
	public final static String BACKUP_QUEUE_NAME = "BackupQueue";
	public final static String BACKUP_URL = "/_ah/admin/backup";
	/** UNIT(milliseconds) */
	public final static Long BACKUP_INTERVAL_PER_DOMAIN = 60000L;
	
	//----------------------------------------------------------
	// USAGE
	//----------------------------------------------------------
	public final static String SURVEY_DOMAIN_USAGE_QUEUE_NAME = "SurveyDomainUsageQueue";
	public final static String SURVEY_DOMAIN_USAGE_URL = "/_ah/admin/queue/surveyDomainUsage";
	
	public final static ServiceType DEFAULT_SERVICE_TYPE = ServiceType.TRIAL;
	public final static BlockType DEFAULT_BLOCK_TYPE = BlockType.AUTO;
	public final static long DEFAULT_USER_QUOTA = 5;
	public final static long DEFAULT_BOARD_QUOTA = 2;	// don't delete
	//public final static long DEFAULT_GROUP_QUOTA = 10;	// don't delete
	//public final static long DEFAULT_TASK_QUOTA = 100;	// don't delete
	public final static long UNIT_STORAGE_PER_USER = 5 * GB;// 5 GB
	public final static long DEFAULT_STORAGE_QUOTA = DEFAULT_USER_QUOTA * UNIT_STORAGE_PER_USER;
	public final static long TRIAL_STORAGE_QUOTA = 5 * GB;	// 5 GB
	
	public final static int DEFAULT_EXPIRATION_MONTH = 1;
	
	//----------------------------------------------------------
	// BILL
	//----------------------------------------------------------
	public final static String SUMARRIZE_DOMAIN_BILLS_QUEUE_NAME = "SummarizeDomainBillsQueue";
	public final static String SUMARRIZE_DOMAIN_BILLS_URL = "/_ah/admin/queue/summarizeDomainBills";
	public final static String PAYMENT_DOMAIN_QUEUE_NAME = SUMARRIZE_DOMAIN_BILLS_QUEUE_NAME;
	public final static String PAYMENT_DOMAIN_URL = "/_ah/admin/queue/payment";
	public final static String PAYMENT_CANCEL_DOMAIN_URL = "/_ah/admin/queue/payment/cancel";
	
	//----------------------------------------------------------
	// CRON(Schedule)
	//----------------------------------------------------------
	/** survey usage info all domain */
	public final static String CRON_SURVEY_USAGE_URL = "/_ah/admin/usage/surveyUsage";
//	/** unavailable channel token remove all */
//	@Deprecated
	public final static String CRON_REMOVE_ALL_UNAVAILABLE_CHANNEL_URL = "/_ah/admin/channel/removeAllUnavailableChannel";
	/** unavailable channel token remove all */
	public final static String CRON_REMOVE_UNAVAILABLE_ACCESS_TOKEN_URL = "/_ah/admin/token/removeUnavailableAccessToken";
	/** next alarm invoke executor */
	public final static String CRON_INVOKE_ALARM_EXECUTOR_URL = "/_ah/admin/alarm/invokeAlarmExecutor";
	/** summarize bill */
	public final static String CRON_SUMARRIZE_BILLS_URL = "/_ah/admin/billing/summarizeBills";
	public final static String CRON_SCHEDULED_PAYMENT_URL = "/_ah/admin/billing/scheduledPayments";
	
	//@Deprecated
	//public final static String CRON_CHECK_SUBSCRIBED_BILLS_URL = "/_ah/admin/billing/checkSubscribedBills";
	/** remove all trash uploaded gcs files */
	public final static String CRON_REMOVE_UPLOADED_TRASH_FILES_URL = "/_ah/admin/attachment/removeUploadedTrashFiles";
	public final static String REMOVE_NOTIFICATION_URL = "/_ah/admin/notification/removeNotification";
	public final static int REMOVE_NOTIFICATION_DAYS = -7;
	
	/** remove all unavailabe notifications */
	//-->
	//public final static String CRON_REMOVE_ALL_UNAVAILABEL_Activities = "/_ah/admin/activity/removeAllUnavailableActivities";
	// hyeunwoo.shim 2015-05-23 : Has 0 references. 
	//<--
	
	//----------------------------------------------------------
	// GOOGLE Calendar
	//----------------------------------------------------------
	/** 구굴 계정에 있는 일정 정보를 가져오기 위한 url */
	public final static String MY_GOOGLE_CALENDAR_URL = "/myCalendar";
	
	//----------------------------------------------------------
	// SEND EMIAL LOST ID AND PASSWORD
	//----------------------------------------------------------
//	public final static String SENDLOSTID_EMAIL_QUEUE_NAME = "SendLostIdEmailQueue";
	public final static String SENDLOSTID_EMAIL_QUEUE_NAME = DEFAULT_EMAIL_QUEUE_NAME;
//	@Deprecated
//	public final static String SENDLOSTID_EMAIL_SEND_URL = "/_ah/admin/queue/sendLostIdEmail";
	public final static String SENDLOSTID_EMAIL_TEMPLATE = "sendLostIdEmail_{0}.ftl";
	
	//----------------------------------------------------------
	// SEND EMAIL RESET PASSWORD && REGISTRATION TEMPLATE
	//----------------------------------------------------------
	public final static String SEND_REGIST_EMAIL_TEMPLATE = "registerEmail_{0}.ftl";
	public final static String SEND_RESET_PASSWORD_EMAIL_TEMPLATE = "resetPasswordEmail_{0}.ftl";

	//----------------------------------------------------------
	// SEND EMAIL ADMIN NOTICE TEMPLATE 20170808
	// admin사용자의 공지 메일의 template
	//----------------------------------------------------------
	public final static String SEND_ADMIN_NOTICE_EMAIL_TEMPLATE = "adminNoticeEmail.ftl";
	
	//----------------------------------------------------------
	// SYNC MESSAGE
	//----------------------------------------------------------
	public final static String ASYNC_FIREBASE_MESSAGE_QUEUE_NAME = "AsyncFirebaseMessageQueue";
	public final static String ASYNC_FIREBASE_MESSAGE_SEND_URL = "/_ah/admin/queue/firebaseAsyncMessage";
//	@Deprecated
//	public final static String ASYNC_MESSAGE_QUEUE_NAME = "AsyncMessageQueue";
//	@Deprecated
//	public final static String ASYNC_MESSAGE_SEND_URL = "/_ah/admin/queue/asyncMessage";
	
	//----------------------------------------------------------
	// NOTICE EMAIL
	//----------------------------------------------------------
//	public final static String NOTICE_EMAIL_QUEUE_NAME = "NoticeEmailQueue";
//	@Deprecated
//	public final static String NOTICE_EMAIL_QUEUE_NAME = DEFAULT_EMAIL_QUEUE_NAME;
//	@Deprecated
//	public final static String NOTICE_EMAIL_SEND_URL = "/_ah/admin/queue/sendNoticeEmail";
	public final static String NOTICE_EMAIL_TEMPLATE = "noticeEmail.ftl";
	
	//----------------------------------------------------------
	// INDEX
	//----------------------------------------------------------
	public final static String RECREATE_INDEX_QUEUE_NAME = DEFAULT_QUEUE_NAME;
//	public final static String RECREATE_INDEX_QUEUE_NAME = "RecreateIndexQueue";
	public final static String RECREATE_INDEX_URL = "/_ah/admin/queue/recreateindex";
	
	//----------------------------------------------------------
	// WEB HOOK
	//----------------------------------------------------------
	public final static boolean WEB_HOOK_ENABLE = true;
	public final static String WEB_HOOK_QUEUE_NAME = "WebHookQueue";
	public final static String WEB_HOOK_URL = "/_ah/admin/queue/webHook";
	
	//----------------------------------------------------------
	// DONGBU SERVICE
	//----------------------------------------------------------
	public final static String DONGBU_SERVICE_SSO_LOGIN_URL = "/_ah/sso/login/dongbu";
	public final static String DONGBU_SERVICE_WEB_CLIENT_ID = "1073273458742-5mddepucma4lcu4n6kav62jjkg6g7fr7.apps.googleusercontent.com";
	
	//----------------------------------------------------------
	// IMAGE SERVICE
	//----------------------------------------------------------
	public final static String IMAGE_INFO_URL = "/_ah/image/info";
	
	//----------------------------------------------------------
	// GCS(Google Cloud Storage) SERVICE
	//----------------------------------------------------------
	public final static String GCS_DOWNLOAD_SERVLET_URL = "/_ah/admin/gcs/objects/dowonload";
}
