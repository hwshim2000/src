package net.forecs.coconut.common.util;

import java.util.Date;
import java.util.HashSet;
import java.util.logging.Level;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.endpoint.API;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;

import com.ibm.icu.text.SimpleDateFormat;

public class StopWatchUtil extends StopWatch {
	private static final Logger LOG = Logger.getLogger(StopWatchUtil.class.getName());
	
	private final static boolean STOP_WATCH_ENABLE = true;
	private final static Level STOP_WATCH_LOG_LEVEL = Level.INFO;
	private final static boolean ENABLE_START_LOG = false;
	private final static boolean ENABLE_SPLIT_LOG = false;
	private final static boolean ENABLE_STOP_LOG = true;
	
	private final String target;
	private final boolean isWatchTarget;
	private final boolean isMethod;	// Method or URI
	
	private final static HashSet<String> targets = new HashSet<String>();
	static {
		targets.add(API.API_ROOT);
	}
	public StopWatchUtil(String target) {
		this.target = target;
		isWatchTarget = isWatchTarget() && STOP_WATCH_ENABLE;
		isMethod = false;
	}
	public StopWatchUtil() {
		target = null;
		isWatchTarget = true && STOP_WATCH_ENABLE;
		isMethod = true;
	}
	
	private boolean isWatchTarget() {
		for (String t : targets) {
			if (StringUtils.startsWith(target, t)) { return true; }
		}
		
		return false;
	}
	
	@Override
	public void start() {
		if (!isWatchTarget) return;
		super.reset();
		super.start();
		
		if (ENABLE_START_LOG) {
			if (isMethod) {
				String classMethod = getClassMethod();
				logWrite("START", classMethod);
			} else {
				logWrite("START", target);
			}
		}
	}
	
	@Override
	public void stop() {
		if (!isWatchTarget) return;
		try {
			super.stop();
			
			if (ENABLE_STOP_LOG) {
				if (isMethod) {
					String classMethod = getClassMethod();
					logWrite("STOP", classMethod);
				} else {
					logWrite("STOP", target);
				}
			}
		} catch (Exception ex) {}
	}
	
	@Override
	public void reset() {
		if (!isWatchTarget) return;
		super.reset();
	}
	
	@Override
	public void resume() {
		if (!isWatchTarget) return;
		super.resume();
	}

	@Override
	public void split() {
		if (!isWatchTarget) return;
		try {
			super.split();
			
			if (ENABLE_SPLIT_LOG) {
				if (isMethod) {
					String classMethod = getClassMethod();
					logWrite("SPLIT", classMethod);
				} else {
					logWrite("SPLIT", target);
				}
			}
		} catch (Exception ex) {}
	}

	@Override
	public void unsplit() {
		if (!isWatchTarget) return;
		super.unsplit();
	}
	
	@Override
	public void suspend() {
		if (!isWatchTarget) return;
		super.suspend();
	}
	
	@Override
	public long getStartTime() {
		if (!isWatchTarget) return 0;
		return super.getStartTime();
	}
	
	@Override
	public long getSplitTime() {
		if (!isWatchTarget) return 0;
		return super.getSplitTime();
	}
	
	@Override
	public long getTime() {
		if (!isWatchTarget) return 0;
		return super.getTime();
	}
	
	private void logWrite(String watchType, String watchTarget) {
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss.SSS");
		String startTime = formatter.format(new Date(super.getStartTime()));
		
		if (StringUtils.equals("START", watchType)) {
			LOG.log(STOP_WATCH_LOG_LEVEL, String.format("%s [%s] [%s ~] %s", watchType, super.toString(), startTime, watchTarget));
		} else if (StringUtils.equals("SPLIT", watchType)) {
			String splitTime = formatter.format(new Date(super.getStartTime() + super.getSplitTime()));
			LOG.log(STOP_WATCH_LOG_LEVEL, String.format("%s [%s] [%s ~ %s] %s", watchType, super.toSplitString(), startTime, splitTime, watchTarget));
		} else {
			String stopTime = formatter.format(new Date(super.getStartTime() + super.getTime()));
			LOG.log(STOP_WATCH_LOG_LEVEL, String.format("%s [%s] [%s ~ %s] %s", watchType, super.toString(), startTime, stopTime, watchTarget));
		}
	}
	
	private String getClassMethod() {
		StackTraceElement e[] = Thread.currentThread().getStackTrace();
//		boolean doNext = true;
		String methodName = "";
		String className = "";
		for (StackTraceElement s : e) {
			methodName = s.getMethodName();
			className = s.getClassName();
			
//			if (doNext) {
//				methodName = s.getMethodName();
//				className = s.getClassName();
////			} else {
////				break;
//			}
			//doNext = "getMethod".equals(s.getMethodName()) && s.getClassName().equals(this.getClass().getName());
			if (className.startsWith("net.forecs.coconut.endpoint")) {
				break;
			}
//			doNext = s.getClassName().equals(this.getClass().getName());
//			LOG.warning(doNext + ":" + className + "." + methodName);
		}
		
		return className + "." + methodName;
	}
}
