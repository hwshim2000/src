package net.forecs.coconut.common.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.Frequency;
import net.forecs.coconut.common.util.security.SecurityUtils;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Notifications;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.attachment.Uploads;
import net.forecs.coconut.entity.backup.Backups;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Coupons;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.entity.billing.ServiceGrades;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Calendars;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.channel.WebHook;
import net.forecs.coconut.entity.channel.WebHookLog;
import net.forecs.coconut.entity.domain.Departments;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.DomainsLog;
import net.forecs.coconut.entity.email.AdminEMailNotice;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.manage.Feedbacks;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.survey.SurveyAnswers;
import net.forecs.coconut.entity.survey.SurveyItems;
import net.forecs.coconut.entity.survey.SurveyQuestions;
import net.forecs.coconut.entity.tasklist.Tasklists;
import net.forecs.coconut.entity.user.UserDevices;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskHistories;
import net.forecs.coconut.entity.workspace.TaskLabelMap;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.fortuna.ical4j.model.property.Uid;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;


public class KeyUtil {
	public static String UUID() {
		return UUID.randomUUID().toString();
	}
	public static long TIMESTAMP() {
		return new Date().getTime();
	}

	public static String SHA1() {
		String shaString = null;
		try {
			// Initialize SecureRandom
			// This is a lengthy operation, to be done only upon
			// initialization of the application
			SecureRandom prng = SecureRandom.getInstance("SHA1PRNG");

			// generate a random number
			String randomNum = new Integer(prng.nextInt()).toString();

			// get its digest
			MessageDigest sha = MessageDigest.getInstance("SHA-1");
			byte[] result = sha.digest(randomNum.getBytes(StandardCharsets.UTF_8));
			shaString = hexEncode(result);
			//LOG.warning("Random number: " + randomNum);
			//LOG.warning("Message digest: " + hexEncode(result));
		} catch (NoSuchAlgorithmException ex) {
			//System.err.println(ex);
		}
		return shaString;
	}

	/**
	 * The byte[] returned by MessageDigest does not have a nice textual
	 * representation, so some form of encoding is usually performed.
	 *
	 * This implementation follows the example of David Flanagan's book
	 * "Java In A Nutshell", and converts a byte array into a String of hex
	 * characters.
	 *
	 * Another popular alternative is to use a "Base64" encoding.
	 */
	static private String hexEncode(byte[] aInput) {
		StringBuilder result = new StringBuilder();
		char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'a', 'b', 'c', 'd', 'e', 'f' };
		for (int idx = 0; idx < aInput.length; ++idx) {
			byte b = aInput[idx];
			result.append(digits[(b & 0xf0) >> 4]);
			result.append(digits[b & 0x0f]);
		}
		return result.toString();
	}
	
	public static String generateRandomPassword() {
		return generateCode(8);
	}
	public static String generateCoupon() {
		return generateCode(16);
	}
	public static String generateDownloadKey() throws Exception {
		return generateCode(64);
	}
	public static String generateCode(int length) {
		Random random = new Random();
		String characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		StringBuilder result = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			result.append(characters.charAt(random.nextInt(characters.length())));
		}
		return result.toString();
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// User Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createUserKey(String id) {
		return KeyFactory.createKey(Users.class.getSimpleName(), id);
	}
	public static String createUserKeyString(String id) {
		return KeyFactory.createKeyString(Users.class.getSimpleName(), id);
	}
	public static Key createUserDeviceKey(UserDevices device) {
		return KeyFactory.createKey(UserDevices.class.getSimpleName(), device.getGcmId());
	}
	public static String createUserDeviceKeyString(String gcmId) {
		return KeyFactory.createKeyString(UserDevices.class.getSimpleName(), gcmId);
	}

	public static Key createUserProfileKey(Users user) {
		return createUserProfileKey(user.getUserId());
	}
	public static Key createUserProfileKey(String userId) {
		Key userKey = KeyFactory.stringToKey(userId);
		return KeyFactory.createKey(UserProfiles.class.getSimpleName(), userKey.getName());
	}
	public static String createUserProfileKeyString(String userId) {
		Key userKey = KeyFactory.stringToKey(userId);
		return KeyFactory.createKeyString(UserProfiles.class.getSimpleName(), userKey.getName());
	}

	public static Key createMemberAuthKey(String kindId, String userId) {
		Key parentKey = KeyFactory.stringToKey(kindId);
		String name = KeyFactory.stringToKey(userId).getName();
		return KeyFactory.createKey(parentKey, MemberAuths.class.getSimpleName(), name);
	}
	
	public static String createMemberAuthKeyString(String kindId, String userId) {
		return KeyFactory.keyToString(createMemberAuthKey(kindId, userId));
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Domains Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createDomainKey(String domainName) {
		return KeyFactory.createKey(Domains.class.getSimpleName(), domainName);
	}
	public static String createDomainKeyString(String domainName) {
		return KeyFactory.createKeyString(Domains.class.getSimpleName(), domainName);
	}
	public static Key createDomainKey(Domains domain) {
		return KeyFactory.createKey(Domains.class.getSimpleName(), domain.getDomainName());
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Domains Usage Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createUsageKey(Usage usage) {
		return KeyFactory.createKey(Usage.class.getSimpleName(), usage.getDomainName());
	}
	public static Key createUsageKey(String domainName) {
		return KeyFactory.createKey(Usage.class.getSimpleName(), domainName);
	}
	public static String createUsageKeyString(String domainName) {
		return KeyFactory.createKeyString(Usage.class.getSimpleName(), domainName);
	}
	/// Domain UsageLogs Key ///
	public static Key createUsageLogKey(Frequency frequency) {
		String keyName = null;
		switch (frequency) {
			case YEARLY :
				keyName = CalendarUtil.toString(new Date(), "yyyy");
				break;
			case MONTHLY :
				keyName = CalendarUtil.toString(new Date(), "yyyyMM");
				break;
			case HOURLY :
				keyName = CalendarUtil.toString(new Date(), "yyyyMMddHH");
				break;
			case DAILY :
			default :
				 keyName = CalendarUtil.toString(new Date(), "yyyyMMdd");
		}
		return KeyFactory.createKey(UsageLogs.class.getSimpleName(), keyName);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Departments Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createDepartmentKey() {
		return KeyFactory.createKey(Departments.class.getSimpleName(), UUID());
	}
	public static Key createDepartmentKey(String code) {
		return KeyFactory.createKey(Departments.class.getSimpleName(), code);
	}
	public static String createDepartmentKeyString() {
		return KeyFactory.createKeyString(Departments.class.getSimpleName(), UUID());
	}
	public static String createDepartmentKeyString(String code) {
		return KeyFactory.createKeyString(Departments.class.getSimpleName(), code);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Domains Backup Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createDomainsLogKey() {
		return KeyFactory.createKey(DomainsLog.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Domains Log Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createBackupKey() {
		return KeyFactory.createKey(Backups.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}

	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Group Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createDefaultGroupKey(Domains domain) {
		return KeyFactory.createKey(domain.getKey(), Groups.class.getSimpleName(), "DEFAULT");
	}
	public static Key createDefaultGroupKey(String domainId) {
		return KeyFactory.createKey(KeyFactory.stringToKey(domainId), Groups.class.getSimpleName(), "DEFAULT");
	}
	public static Key createGroupKey(Groups group) {
		return KeyFactory.createKey(KeyFactory.stringToKey(group.getDomainId()), Groups.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Stage Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createStageKey(String stage) {
		return KeyFactory.createKey(Stages.class.getSimpleName(), stage);
	}
//	public static Key createStageKey(int stageOrdinal) {
//		return createStageKey(String.format("STAGE-%d", stageOrdinal));
//	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Board Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createDefaultBoardKey() {
		return KeyFactory.createKey(Boards.class.getSimpleName(), "DEFAULT" + "_" + KeyUtil.TIMESTAMP());
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Tasklist Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTasklistKey(String boardId, String stage) {
		return KeyFactory.createKey(KeyFactory.stringToKey(boardId), Tasklists.class.getSimpleName(), stage);	
	}
	public static String createTasklistKeyString(String boardId, String stage) {
		return KeyFactory.createKeyString(KeyFactory.stringToKey(boardId), Tasklists.class.getSimpleName(), stage);	
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// BoardInvite Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
//	@Deprecated
//	public static Key createBoardInviteKey(BoardInvites boardInvite) {
//		return KeyFactory.createKey(KeyFactory.stringToKey(boardInvite.getBoardId()), BoardInvites.class.getSimpleName(), boardInvite.getInviteEmail());	
//	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Calendar Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createCalendarKey(String userId) {
		Key userKey = KeyFactory.stringToKey(userId);
		return KeyFactory.createKey(userKey, Calendars.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	public static Key createCalendarKey(String userId, String value) {
		Key userKey = KeyFactory.stringToKey(userId);
		return KeyFactory.createKey(userKey, Calendars.class.getSimpleName(), value);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Event Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createEventKey() {
		//return KeyFactory.createKey(Events.class.getSimpleName(), KeyUtil.TIMESTAMP());
		return KeyFactory.createKey(Events.class.getSimpleName(), KeyUtil.UUID());
	}
	public static Key createEventKey(Uid uid, String sequence) {
		String keyStr = uid.getValue();
		
		if (StringUtils.isNotBlank(sequence) && !"0".equals(sequence)) {
			keyStr = keyStr + "-" + sequence;
		}
		return KeyFactory.createKey(Events.class.getSimpleName(), keyStr);
	}
	public static Key createEventKey(String value) {
		return KeyFactory.createKey(Events.class.getSimpleName(), value);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Channel Token Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	@Deprecated
	public static String createChannelTokenKeyString() {
		return createChannelTokenKeyString(KeyUtil.UUID());
	}
	@Deprecated
	public static String createChannelTokenKeyString(String channelId) {
		return KeyFactory.createKeyString(ChannelToken.class.getSimpleName(), channelId);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Activity Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createActivityKey() {
		return KeyFactory.createKey(Activities.class.getSimpleName(), KeyUtil.UUID());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// NoticeC Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createNoticeKey() {
		return KeyFactory.createKey(Notice.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	public static Key createRootSystemNoticeKey() {
		return createNoticeKey();
	}
	public static Key createDomainSystemNoticeKey(long parentKeyId) {
		return KeyFactory.createKey(Notice.class.getSimpleName(), parentKeyId);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// NoticeComment Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
//	@Deprecated
//	public static Key createNoticeCommentKey(String noticeId) {
//		return KeyFactory.createKey(KeyFactory.stringToKey(noticeId), NoticeComments.class.getSimpleName(), KeyUtil.TIMESTAMP());
//	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Task Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskKey() {
		return KeyFactory.createKey(Tasks.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskComment Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
//	@Deprecated
//	public static Key createTaskCommentKey(Key taskKey) {
//		return KeyFactory.createKey(taskKey, TaskComments.class.getSimpleName(), KeyUtil.TIMESTAMP());
//	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskTimeline Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskTimelineKey() {
		return KeyFactory.createKey(TaskTimelines.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskTimelineScore Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
//	@Deprecated
//	public static Key createTaskTimelineScoreKey(String taskTimelineId, Users loginUser) {
//		Key parentKey = KeyFactory.stringToKey(taskTimelineId);
//		return KeyFactory.createKey(parentKey, TaskTimelineScores.class.getSimpleName(), loginUser.getId());
//	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskTimelineComment Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskTimelineCommentKey(Key taskKey) {
		return KeyFactory.createKey(taskKey, TaskTimelineComments.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskHistory Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskHistoryKey() {
		return KeyFactory.createKey(TaskHistories.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskLabel Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskLabelKey(TaskLabels taskLabel) {
		return KeyFactory.createKey(KeyFactory.stringToKey(taskLabel.getBoardId()),
				TaskLabels.class.getSimpleName(),
				KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskLabelMap Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskLabelMapKey(TaskLabelMap taskLabelMap) {
		return createTaskLabelMapKey(taskLabelMap.getTaskId(), taskLabelMap.getTaskLabelId());
	}
	public static Key createTaskLabelMapKey(String taskId, String taskLabelId) {
		return KeyFactory.createKey(KeyFactory.stringToKey(taskId), TaskLabelMap.class.getSimpleName(),	taskLabelId);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskChecklistComment Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
//	@Deprecated
//	public static Key createTaskChecklistCommentKey(Key taskKey) {
//		return KeyFactory.createKey(taskKey, TaskChecklistComments.class.getSimpleName(), KeyUtil.TIMESTAMP());
//	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskChecklist Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskChecklistKey() {
		return KeyFactory.createKey(TaskChecklists.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// TaskChecklistHistory Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTaskChecklistHistoryKey() {
		return KeyFactory.createKey(TaskChecklistHistories.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Subscription Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createSubscriptionKey(Subscriptions subscription) {
		return KeyFactory.createKey(
				KeyFactory.stringToKey(subscription.getTaskId()),
				Subscriptions.class.getSimpleName(),
				KeyFactory.stringToKey(subscription.getUserId()).getName());
	}
	
	public static String createSubscriptionKeyString(Tasks task, Users user) {
		return KeyFactory.createKeyString(
				KeyFactory.stringToKey(task.getTaskId()),
				Subscriptions.class.getSimpleName(),
				user.getId());
	}
	
	public static String createSubscriptionKeyString(Tasks task, String userId) {
		return KeyFactory.createKeyString(
				KeyFactory.stringToKey(task.getTaskId()),
				Subscriptions.class.getSimpleName(),
				KeyFactory.stringToKey(userId).getName());
	}
	
	public static String createSubscriptionKeyString(String taskId, String userId) {
		return KeyFactory.createKeyString(
				KeyFactory.stringToKey(taskId),
				Subscriptions.class.getSimpleName(),
				KeyFactory.stringToKey(userId).getName());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Setting Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createUserSettingKey(String userId, String settingName) {
		Key parentKey = KeyFactory.stringToKey(userId);
		return KeyFactory.createKey(parentKey, UserSetting.class.getSimpleName(), settingName);
	}
	public static String createUserSettingKeyString(String userId, String settingName) {
		Key parentKey = KeyFactory.stringToKey(userId);
		return KeyFactory.createKeyString(parentKey, UserSetting.class.getSimpleName(), settingName);
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Attachment Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createAttachmentKey(Attachments attachment) {
		return KeyFactory.createKey(Attachments.class.getSimpleName(), SecurityUtils.getMD5(attachment.getFilePath()));
	}
	public static Key createAttachmentKey(String filePath) {
		return KeyFactory.createKey(Attachments.class.getSimpleName(), SecurityUtils.getMD5(filePath));
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Image Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createImageKey(Images image) {
		return KeyFactory.createKey(Images.class.getSimpleName(), SecurityUtils.getMD5(image.getFilePath()));
	}
	public static Key createImageKey(String filePath) {
		return KeyFactory.createKey(Images.class.getSimpleName(), SecurityUtils.getMD5(filePath));
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Uploads Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createUploadKey(String filePath) {
		return KeyFactory.createKey(Uploads.class.getSimpleName(), SecurityUtils.getMD5(filePath));
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// AttachmentMap Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createAttachmentMapKey(String parentId, String attachmentId) {
		return KeyFactory.createKey(KeyFactory.stringToKey(parentId), AttachmentsMap.class.getSimpleName(), attachmentId);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Notification Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createNotificationKey(String userId) {
		return KeyFactory.createKey(KeyFactory.stringToKey(userId), Notifications.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	/// NotificationSetting Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createNotificationSettingKey(NotificationSettings notificationSetting) {
		return KeyFactory.createKey(NotificationSettings.class.getSimpleName(),
				KeyFactory.stringToKey(notificationSetting.getUserId())
						.getName());
	}
	public static Key createNotificationSettingKey(String userId) {
		Key userKey = KeyFactory.stringToKey(userId);
		return KeyFactory.createKey(NotificationSettings.class.getSimpleName(), userKey.getName());
	}
	public static String createNotificationSettingKeyString(String userId) {
		return KeyFactory.keyToString(createNotificationSettingKey(userId));
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Coupons Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createCouponKey() {
		String couponKeyStr = generateCoupon();
		return KeyFactory.createKey(Coupons.class.getSimpleName(), couponKeyStr);
	}
	public static Key createCouponKey(String couponStr) {
		return KeyFactory.createKey(Coupons.class.getSimpleName(), couponStr);
	}
	public static String createCouponKeyString(String couponStr) {
		return KeyFactory.createKeyString(Coupons.class.getSimpleName(), couponStr);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Billing Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createBillKey(Date serviceEnd) {
		return KeyFactory.createKey(Bills.class.getSimpleName(), CalendarUtil.toString(serviceEnd, "yyyyMMdd"));
	}
	public static String createBillKeyString(Date serviceEnd) {
		return KeyFactory.createKeyString(Bills.class.getSimpleName(), CalendarUtil.toString(serviceEnd, "yyyyMMdd"));
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// ServiceGrade Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createServiceGradeKey(String serviceGrade) {
		return KeyFactory.createKey(ServiceGrades.class.getSimpleName(), serviceGrade);
	}
	public static String createServiceGradeKeyString(String serviceGrade) {
		return KeyFactory.createKeyString(ServiceGrades.class.getSimpleName(), serviceGrade);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Customer Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createCustomerKey(String key) {
		return KeyFactory.createKey(Customers.class.getSimpleName(), key);
	}
	public static String createCustomerKeyString(String key) {
		return KeyFactory.createKeyString(Customers.class.getSimpleName(), key);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Tokens Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createTokenKey(String token) {
		return KeyFactory.createKey(Tokens.class.getSimpleName(), token);
	}
	public static Key createAuthsKey(String clientId) {
		return KeyFactory.createKey(Auths.class.getSimpleName(), clientId);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// WebHook Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createWebHookKey(WebHook webHook) {
		return createWebHookKey(webHook.getActivityKind(), webHook.getActivityType(), webHook.getKindId());
	}
	public static Key createWebHookKey(ActivityKind activityKind, ActivityType activityType) {
		return createWebHookKey(activityKind, activityType, null);
	}
	public static Key createWebHookKey(ActivityKind activityKind, ActivityType activityType, String kindId) {
		StringBuilder sbKeyName = new StringBuilder(1500);
		sbKeyName.append(activityKind);
		sbKeyName.append('-');
		sbKeyName.append(activityType);
		
		if (StringUtils.isNotBlank(kindId)) {
			Key objKey = KeyFactory.stringToKey(kindId);
			Key parentKey = objKey.getParent();
			
			if (parentKey != null) {
				if (StringUtils.isNotBlank(parentKey.getName())) {
					sbKeyName.append('-');
					sbKeyName.append(parentKey.getName());
				} else {
					sbKeyName.append('-');
					sbKeyName.append(parentKey.getId());
				}
			}
			if (StringUtils.isNotBlank(objKey.getName())) {
				sbKeyName.append('-');
				sbKeyName.append(objKey.getName());
			} else {
				sbKeyName.append('-');
				sbKeyName.append(objKey.getId());
			}
		}
		return KeyFactory.createKey(WebHook.class.getSimpleName(), sbKeyName.toString());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// WebHookLog Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createWebHookLogKey(WebHook webHook, Activities activity) {
		String keyName = webHook.getKey().getName() + activity.getKey().getName();
		return KeyFactory.createKey(WebHookLog.class.getSimpleName(), keyName);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Emoticons Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createEmoticonKey() {
		return KeyFactory.createKey(Emoticons.class.getSimpleName(), TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// AdminMail Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createAdminEMailNoticeKey() {
		return KeyFactory.createKey(AdminEMailNotice.class.getSimpleName(), TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Feedbacks Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createFeedbackKey() {
		return KeyFactory.createKey(Feedbacks.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////
	/// Survey Key ///
	//////////////////////////////////////////////////////////////////////////////////////////////
	public static Key createSurveyQuestionKey() {
		return KeyFactory.createKey(SurveyQuestions.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	public static Key createSurveyItemKey() {
		return KeyFactory.createKey(SurveyItems.class.getSimpleName(), KeyUtil.TIMESTAMP());
	}
	
	public static Key createSurveyAnswerKey(String surveyItemId, String userId) {
		Key parentKey = KeyFactory.stringToKey(surveyItemId);
		String name = KeyFactory.stringToKey(userId).getName();
		return KeyFactory.createKey(parentKey, SurveyAnswers.class.getSimpleName(), name);
	}
	public static String createSurveyAnswerKeyString(String surveyItemId, String userKey) {
		if (StringUtils.isBlank(userKey)) { return null; }
		Key parentKey = KeyFactory.stringToKey(surveyItemId);
		return KeyFactory.createKeyString(parentKey, SurveyAnswers.class.getSimpleName(), userKey);
	}

}
