package net.forecs.coconut.common.util;

/* 
 * Copyright (C) 2006 Methodhead Software LLC.  All rights reserved.
 * 
 * This file is part of TransferCM.
 * 
 * TransferCM is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * TransferCM is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * TransferCM; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
 * Fifth Floor, Boston, MA  02110-1301  USA
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ServletUtil {
	//-----------------------------------------------------
	// access key valid check properties
	public final static String USER_AGENT = "User-Agent";
	public final static String REMOTE_ADDR = "RemoteAddr";
	public final static String JSESSIONID = "JSESSIONID";
	//-----------------------------------------------------
	
	/**
	 * NOT UNIT TESTED Returns the URL (including query parameters) minus the
	 * scheme, host, and context path. This method probably be moved to a more
	 * general purpose class.
	 */
	public static String getRelativeUrl(HttpServletRequest req) {
		String baseUrl = null;

		if ((req.getServerPort() == 80) || (req.getServerPort() == 443))
			baseUrl = req.getScheme() + "://" + req.getServerName()
					+ req.getContextPath();
		else
			baseUrl = req.getScheme() + "://" + req.getServerName()
					+ ":" + req.getServerPort() + req.getContextPath();

		StringBuffer buf = req.getRequestURL();

		if (req.getQueryString() != null) {
			buf.append("?");
			buf.append(req.getQueryString());
		}

		return buf.substring(baseUrl.length());
	}

  /**
   * NOT UNIT TESTED Returns the base url (e.g, <tt>http://myhost:8080/myapp</tt>) suitable for
   * using in a base tag or building reliable urls.
   */
	public static String getBaseUrl(HttpServletRequest req) {
		if ((req.getServerPort() == 80) || (req.getServerPort() == 443))
			return req.getScheme() + "://" + req.getServerName()
					+ req.getContextPath();
		else
			return req.getScheme() + "://" + req.getServerName() + ":"
					+ req.getServerPort() + req.getContextPath();
	}

  /**
   * Returns the file specified by <tt>path</tt> as returned by
   * <tt>ServletContext.getRealPath()</tt>.
   */
	public static File getRealFile(HttpServletRequest req, String path) {
		return new File(req.getSession().getServletContext().getRealPath(path));
	}
 	
	public static String getContents(HttpServletRequest req) {
		try {
			StringBuilder builder = new StringBuilder();
			BufferedReader br = req.getReader();
			String str;
			while ((str = br.readLine()) != null) {
				builder.append(str);
			}
			if (builder.toString().isEmpty()) {	return null; }
			return builder.toString();
		} catch (IOException e) {
			return null;
		}
	}
	
	public static Map<String, Object> getContentsMap(HttpServletRequest req) {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			StringBuilder builder = new StringBuilder();
			BufferedReader br = req.getReader();
			String str;
			while ((str = br.readLine()) != null) {
				builder.append(str);
			}
			if (builder.toString().isEmpty()) {	return map;	}
			
			try {
				ObjectMapper mapper = new ObjectMapper();
				String contents = builder.toString();
				map = mapper.readValue(contents, new TypeReference<Map<String, Object>>(){});
			} catch (JsonGenerationException e) {
				//e.printStackTrace();
			} catch (JsonMappingException e) {
				//e.printStackTrace();
			} catch (IOException e) {
				//e.printStackTrace();
			} 
		} catch (IOException e) {
			//e.printStackTrace();
		}
		return map;
	}
	
	public static List<Cookie> getCookies(HttpServletRequest req, String name) {
    	if (req.getCookies()==null) { return null; }
    	List<Cookie> cookies = new ArrayList<Cookie>();
    	for (Cookie cookie : req.getCookies()) {
    		if (StringUtils.equalsIgnoreCase(name, cookie.getName())) {
    			cookies.add(cookie);
    		}
    	}
    	return cookies;
    }
	   
	public static String getCookieValue(String name, HttpServletRequest req) {
		Cookie[] cookies = req.getCookies();
		if (cookies == null) { return null; }
		for (int i = 0; i < cookies.length; i++) {
			if (StringUtils.equalsIgnoreCase(name, cookies[i].getName())) {
				return  cookies[i].getValue();
			}
		}
		return null;
	}
	public static String getJsessionId(HttpServletRequest req) {
		return getCookieValue(JSESSIONID, req);
	}
	public static String getUserAgent(HttpServletRequest req) {
		return req.getHeader(USER_AGENT);
	}
	public static String getRemoteAddr(HttpServletRequest req) {
		return req.getRemoteHost();
	}
	public static void reloadCookie(String name, String value, int expires, HttpServletResponse res) {
		Cookie cookie = new Cookie(name, value);
		if (!MainModule.developmentServer) {
			cookie.setMaxAge(expires);
			cookie.setPath("/");
		}
		res.addCookie(cookie);
	}

	public static void reloadCookieByHeader(String name, String value, int expires, HttpServletResponse res) {
//		Date expdate = new Date();
//		if (expires > 0) { expdate.setTime(expdate.getTime() + (expires * 1000)); }
//		else { expdate.setTime(0); }
//		
//		DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
//		df.setTimeZone(TimeZone.getTimeZone("GMT"));
//		String cookieExpire = df.format(expdate);
//		String cookieString =  String.format("%s=%s", name, value==null?"":value);
//		String cookieString =  String.format("%s=%s; max-age:%d; path=/", name, value==null?"":value, expires);
//		String cookieString =  String.format("%s=%s; expires=%s; max-age:%d; Path=/", name, value, cookieExpire, expires);
		
		String cookieString = null;
		if (MainModule.developmentServer) {
			cookieString =  String.format("%s=%s", name, value==null?"":value);
		} else {
			cookieString =  String.format("%s=%s; max-age:%d; path=/", name, value==null?"":value, expires);
		}
		res.addHeader("Set-Cookie", cookieString);
	}
	
    public static void printHeader(HttpServletRequest req, HttpServletResponse res) {
		String headers = req.getHeader("Cookie");
		if (StringUtils.isNotBlank(headers)) {
			String[] cookieHeaders = headers.split(";");
			for (String str : cookieHeaders) {
				CommonService.printlnDev("Cookie From header", str);
			}
		}
    }
    public static void printCookie(HttpServletRequest req, HttpServletResponse res) {
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				CommonService.printlnDev("Cookie:"+cookie.getName(), cookie.getValue(), cookie.getMaxAge(), cookie.getPath(), cookie.getDomain());
			}
		}
    }
    public static void printContentsMap(HttpServletRequest req, HttpServletResponse res) {
    	Map<String, Object> contentsMap = ServletUtil.getContentsMap(req);
    	String contents = contentsMapToString(contentsMap);
    	CommonService.printlnDev("contents", contents);
    }
    public static String contentsMapToString(Map<String, Object> contentsMap) {
		if (contentsMap == null) { return null; }
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(contentsMap);
		} catch (JsonGenerationException e) {
			return null;
		} catch (JsonMappingException e) {
			return null;
		} catch (IOException e) {
			return null;
		} 
	}
    public static Map<String, String> stringToContentsMap(String contents) {
		if (StringUtils.isEmpty(contents)) { return null; }
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.readValue(contents, new TypeReference<Map<String, String>>(){});
		} catch (JsonGenerationException e) {
			return null;
		} catch (JsonMappingException e) {
			return null;
		} catch (IOException e) {
			return null;
		} 
	}
  // properties ///////////////////////////////////////////////////////////////
  // attributes ///////////////////////////////////////////////////////////////
}