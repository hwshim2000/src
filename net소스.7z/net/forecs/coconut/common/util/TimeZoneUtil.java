package net.forecs.coconut.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class TimeZoneUtil {

	/**
	 * Local Time -> UTC Time String
	 * @param pv_localDateTime
	 * @return
	 */
	public static String localTimeToUtcString(long pv_localDateTime) {
		return localTimeToUtcDate(pv_localDateTime).toString();
	}
	/**
	 * Local Time -> UTC Time Format String
	 * @param pv_localDateTime
	 * @param format
	 * @return
	 */
	public static String localTimeToUtcString(long pv_localDateTime, String format) {
		SimpleDateFormat f = new SimpleDateFormat(format);
		return f.format(localTimeToUtcDate(pv_localDateTime));
	}
	/**
	 * Local Time(TimeZone) -> UTC Time Format String
	 * @param pv_localDateTime
	 * @param z
	 * @param format
	 * @return
	 */
	public static String localTimeToUtcString(long pv_localDateTime, TimeZone z, String format) {
		SimpleDateFormat f = new SimpleDateFormat(format);
		return f.format(localTimeToUtcDate(pv_localDateTime, z));
	}
	
	/**
	 * UTC Time -> Local Time String
	 * @param pv_UTCDateTime
	 * @return
	 */
	public static String utcTimeToLocalString(long pv_UTCDateTime) {
		return utcTimeToLocalDate(pv_UTCDateTime).toString();
	}
	/**
	 * UTC Time -> Local Time Format String
	 * @param pv_UTCDateTime
	 * @param format
	 * @return
	 */
	public static String utcTimeToLocalString(long pv_UTCDateTime, String format) {
		SimpleDateFormat f = new SimpleDateFormat(format);
		return f.format(utcTimeToLocalDate(pv_UTCDateTime));
	}
	/**
	 * UTC Time(TimeZone) -> Local Time Format String
	 * @param pv_UTCDateTime
	 * @param z
	 * @param format
	 * @return
	 */
	public static String utcTimeToLocalString(long pv_UTCDateTime, TimeZone z, String format) {
		SimpleDateFormat f = new SimpleDateFormat(format);
		return f.format(utcTimeToLocalDate(pv_UTCDateTime, z));
	}
	
	/**
	 * Local Time -> UTC Date
	 * @param pv_localDateTime
	 * @return
	 */
	public static Date localTimeToUtcDate(long pv_localDateTime) {
		return new Date(localTimeToUtc(pv_localDateTime));
	}
	/**
	 *  Local Time(TimeZone)) -> UTC Date
	 * @param pv_localDateTime
	 * @param z
	 * @return
	 */
	public static Date localTimeToUtcDate(long pv_localDateTime, TimeZone z) {
//		java.util.Calendar calendar = java.util.Calendar.getInstance(z);
//		calendar.setTimeInMillis(localTimeToUtc(pv_localDateTime, z));
//		return calendar.getTime();
		return new Date(localTimeToUtc(pv_localDateTime, z));
	}

	/** UTC Time -> Local Date
	 * @param pv_UTCDateTime
	 * @return
	 */
	public static Date utcTimeToLocalDate(long pv_UTCDateTime) {
		return new Date(utcTimeToLocal(pv_UTCDateTime));
	}
	/**
	 * UTC Time(TimeZone) -> Local Date 
	 * @param pv_UTCDateTime
	 * @param z
	 * @return
	 */
	public static Date utcTimeToLocalDate(long pv_UTCDateTime, TimeZone z) {
		return new Date(utcTimeToLocal(pv_UTCDateTime, z));
	}

	/**
	 * Local Time -> UTC Time
	 * @param pv_localDateTime
	 * @return
	 */
	public static long localTimeToUtc(long pv_localDateTime) {
		return localTimeToUtc(pv_localDateTime, null);
	}

	/**
	 *  Local Time(TimeZone) -> UTC Time
	 * @param pv_localDateTime
	 * @param z
	 * @return
	 */
	public static long localTimeToUtc(long pv_localDateTime, TimeZone z) {
		long lv_UTCTime = pv_localDateTime;

		if (z == null) {
			z = TimeZone.getDefault();
		}
		// int offset = z.getRawOffset(); // The offset not includes daylight
		// savings time
		int offset = z.getOffset(pv_localDateTime); // The offset includes
													// daylight savings time
		lv_UTCTime = pv_localDateTime - offset;
		return lv_UTCTime;
	}

	/**
	 * UTC Time -> Local Time
	 * @param pv_UTCDateTime
	 * @return
	 */
	public static long utcTimeToLocal(long pv_UTCDateTime) {
		return utcTimeToLocal(pv_UTCDateTime, null);
	}

	/**
	 *  UTC Time(TimeZone) -> Local Time
	 * @param pv_UTCDateTime
	 * @param z
	 * @return
	 */
	public static long utcTimeToLocal(long pv_UTCDateTime, TimeZone z) {
		long lv_localDateTime = pv_UTCDateTime;

		if (z == null) {
			z = TimeZone.getDefault();
		}

		// int offset = z.getRawOffset(); // The offset not includes daylight
		// savings time
		int offset = z.getOffset(pv_UTCDateTime); // The offset includes
													// daylight savings time

		lv_localDateTime = pv_UTCDateTime + offset;

		return lv_localDateTime;
	}
}
