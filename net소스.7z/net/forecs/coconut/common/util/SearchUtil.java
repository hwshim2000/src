package net.forecs.coconut.common.util;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

public class SearchUtil {
	/**
	 * 인덱싱 작업을 위한 String값 쪼개기
	 * @param str
	 * @return
	 */
	public static String joinAndSplitForIndexing(String str) {
		return joinAndSplitForIndexing(str, 1);
	}
	public static String joinAndSplitForIndexing(String str, int minLength) {
		Set<String> list = split(str, minLength);
		
		return StringUtils.join(list, " ");
	}
	public static String joinAndSplitForIndexing(String str, String seperator) {
		return joinAndSplitForIndexing(str, seperator, 1);
	}
	public static String joinAndSplitForIndexing(String str, String seperator, int minLength) {
		Set<String> list = split(str, seperator, minLength);
		
		return StringUtils.join(list, " ");
	}
	
	public static Set<String> split(String str) {
		return split(str, "\\s+", 1);
	}
	public static Set<String> split(String str, String seperator) {
		return split(str, seperator, 1);
	}
	public static Set<String> split(String str, String seperator, int minLength) {
		if (StringUtils.isBlank(str)) { return new HashSet<String>(); }
		Set<String> list = new HashSet<String>();
		list.add(str);
		String[] arr = str.split(seperator);
		
		for (String s : arr) {
			if (StringUtils.isBlank(str)) { continue; }
			Set<String> splits = split(s, minLength);
			if (splits == null || splits.size() == 0) { continue; }
			
			//list.add(joinAndSplitForIndexing(s, minLength));
			list.addAll(splits);
		}
		return list;
	}
	
	public static Set<String> split(String str, int minLength) {
		if (StringUtils.isBlank(str)) { return new HashSet<String>(); }
		Set<String> list = new HashSet<String>();
		
		for (int a = 1; a <= str.length(); a++) {
			int i = 0;
			while (i <= str.length() - a) {
				String splitStr = str.substring(i, i + a).trim();
				if (splitStr.length() >= minLength) {
					list.add(splitStr);
				}
				i++;
			}
		}
		
		return list;
	}
}
