package net.forecs.coconut.common.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class FileTypes {
	public final static String CSV = "csv";
	public final static String TSV = "tsv";
	public final static String XLS = "xls";
	public final static String XLSX = "xlsx";
	public final static String JSON_ARR = "json_arr";
	public final static String JSON = "json";
	
	public final static Character DELIMITER_COMMA = ',';
	public final static Character DELIMITER_TAB = '\t';
	public final static String DEFAULT_EXT = XLSX;
	
	public final static List<String> AVAIL_TYPES;
	public final static List<String> EXCEL_TYPES;
	public final static List<String> JSON_TYPES;
	
	static {
		EXCEL_TYPES = Collections.unmodifiableList(Arrays
				.asList(new String[] { FileTypes.CSV, FileTypes.TSV,
						FileTypes.XLS, FileTypes.XLSX
						}));
		
		JSON_TYPES = Collections.unmodifiableList(Arrays
				.asList(new String[] { FileTypes.JSON_ARR, FileTypes.JSON
						}));
		
		AVAIL_TYPES = new ArrayList<String>();
		AVAIL_TYPES.addAll(EXCEL_TYPES);
		AVAIL_TYPES.addAll(JSON_TYPES);
	}
}
