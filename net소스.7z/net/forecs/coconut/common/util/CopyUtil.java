package net.forecs.coconut.common.util;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtilsBean;


public class CopyUtil {
	public static boolean copy(Object desc, Object orig) {
		try {
			ConvertUtilsBean convertUtilsBean = NullAwareBeanUtilsBean.getInstance()
					.getConvertUtils();
			convertUtilsBean.register(false, true, -1);
	
			BeanUtils.copyProperties(desc, orig);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	// jongwook.yi@forecs.net 2015-03-30 : Clone object
	@SuppressWarnings("unchecked")
	public static <T> T clone(T source) {
		try {
			return (T)BeanUtils.cloneBean(source);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * source의 Null이 아닌값들을 target에 Memrge
	 * @param target
	 * @param destination
	 */
	public static <M> boolean mergeForce(M target, M source, Set<String> exclude) {
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(source.getClass());
			// Iterate over all the attributes
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				// Only copy writable attributes
				Method readMethod = descriptor.getReadMethod();
				Method writeMethod = descriptor.getWriteMethod();
				if (readMethod != null && writeMethod != null && !exclude.contains(descriptor.getName())) {
					Object originalValue = readMethod.invoke(source);
					// Only copy values values where the destination values is null
					//if (originalValue != null) {
						writeMethod.invoke(target, originalValue);
					//}
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * source의 Null이 아닌값들을 target에 Memrge
	 * @param target
	 * @param destination
	 */
//	public static <M> boolean merge(M target, M source, Set<String> exclude) {
//		return merge(target, source, exclude, null, false);
//	}
	public static <M> boolean merge(M target, M source, Set<String> exclude, Set<String> include) {
		return merge(target, source, exclude, include, false);
	}
	public static <M> boolean merge(M target, M source, Set<String> exclude) {
		return merge(target, source, exclude, null, true);
	}
	private static <M> boolean merge(M target, M source, Set<String> exclude, Set<String> include, boolean isForce) {
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(source.getClass());
			// Iterate over all the attributes
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				// Only copy writable attributes
				Method readMethod = descriptor.getReadMethod();
				Method writeMethod = descriptor.getWriteMethod();
				if (readMethod != null && writeMethod != null && !exclude.contains(descriptor.getName())) {
					Object originalValue = readMethod.invoke(source);
					
					// Only copy values values where the destination values is null
					if (isForce ||
							originalValue != null ||
							(include != null && include.contains(descriptor.getName()))) {
						
						if (originalValue != null && descriptor.getPropertyType().equals(Date.class)) {
							writeMethod.invoke(target, new Date(((Date)originalValue).getTime()));
						} else {
							writeMethod.invoke(target, originalValue);
						}
					} 
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
//	public static <M> boolean merge(M target, M source) {
//		try {
//			BeanInfo beanInfo = Introspector.getBeanInfo(source.getClass());
//			// Iterate over all the attributes
//			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
//				// Only copy writable attributes
//				Method readMethod = descriptor.getReadMethod();
//				Method writeMethod = descriptor.getWriteMethod();
//				if (readMethod != null && writeMethod != null) {
//					Object originalValue = readMethod.invoke(source);
//					// Only copy values values where the destination values is null
//					if (originalValue != null) {
//						writeMethod.invoke(target, originalValue);
//					}
//				}
//			}
//			return true;
//		} catch (Exception e) {
//			e.printStackTrace();
//			return false;
//		}
//	}
	
	/**
	 * serializable인 object를 deep copy 한다.
	 * @param oldObj : serializable인 object
	 * @return deep copy된 new object
	 * @throws Exception 
	 */
	public static Object copyDeeply(Object oldObj) throws Exception {
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		Object result;
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(bos);
				
			oos.writeObject(oldObj);
			oos.flush();
				
			ByteArrayInputStream  bin = new ByteArrayInputStream(bos.toByteArray());
			ois = new ObjectInputStream(bin);
				
			result = ois.readObject();
		} finally {
			if(oos != null) oos.close();
			if(ois != null) ois.close();
		}
		return result;
	}
	
	public static <M> void init(M target, HashMap<String, Object> initMap) {
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(target.getClass());
			// Iterate over all the attributes
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				// Only copy writable attributes
				Method readMethod = descriptor.getReadMethod();
				Method writeMethod = descriptor.getWriteMethod();
				if (readMethod != null && writeMethod != null && initMap.containsKey(descriptor.getName())) {
					writeMethod.invoke(target, initMap.get(descriptor.getName()));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
//	public static <M> void merge(M target, M source) {
//		try {
//			BeanInfo beanInfo = Introspector.getBeanInfo(target.getClass());
//			// Iterate over all the attributes
//	
//			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
//				// Only copy writable attributes
//	
//				if (descriptor.getWriteMethod() != null) {
//					Object originalValue = descriptor.getReadMethod()
//							.invoke(target);
//					// Only copy values values where the destination values is null
//					if (originalValue == null) {
//						Object defaultValue = descriptor.getReadMethod().invoke(
//								source);
//						descriptor.getWriteMethod().invoke(target, defaultValue);
//					}
//				}
//			}
//		} catch (Exception ex) {
//			ex.getStackTrace();
//		}
//	}
//	public static void merge(Object dest, Object source) throws IntrospectionException, IllegalArgumentException, IllegalAccessException,
//    InvocationTargetException {
//BeanInfo beanInfo = Introspector.getBeanInfo(source.getClass());
//PropertyDescriptor[] pdList = beanInfo.getPropertyDescriptors();
//for (PropertyDescriptor pd : pdList) {
//    Method writeMethod = null;
//    Method readMethod = null;
//    try {
//        writeMethod = pd.getWriteMethod();
//        readMethod = pd.getReadMethod();
//    } catch (Exception e) {
//    }
//
//    if (readMethod == null || writeMethod == null) {
//        continue;
//    }
//
//    Object val = readMethod.invoke(source);
//    writeMethod.invoke(dest, val);
//}
//}
}
