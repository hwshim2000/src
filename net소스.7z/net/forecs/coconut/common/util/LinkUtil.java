package net.forecs.coconut.common.util;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.common.code.LinkTarget;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Notifications;

import org.apache.commons.lang.StringUtils;

public class LinkUtil {
	/*
	 * DOMAINS,
	GROUPS,
	BOARDS,
	TASKLISTS,
	TASKS,
	TASK_COMMENTS,
	TASK_CHECKLISTS,
	TASK_CHECKLIST_COMMENTS,
	TASK_TIMELINES,
	TASK_TIMELINE_COMMENTS,
	EVENTS,
	NOTICE,
	NOTICE_COMMENTS,
	ATTACHEMENTS,
	SCHEDULE,
	USERS,
	USAGE
	 */
	public static String getLinkUrl(Activities activity) {
		return getLinkUrl(LinkTarget.WEB, activity.getDomainId(),
				activity.getBoardId(),
				activity.getTaskId(),
				activity.getActivityKind(),
				activity.getActivityType(),
				activity.getKindId());
	}
	public static String getLinkUrl(Notifications notification) {
		return getLinkUrl(LinkTarget.WEB, notification.getDomainId(),
				notification.getBoardId(),
				notification.getTaskId(),
				notification.getActivityKind(),
				notification.getActivityType(),
				notification.getKindId());
	}

	private static String getLinkUrl(LinkTarget linkTarget, String domainId,
			String boardId,
			String taskId,
			ActivityKind activityKind,
			ActivityType activityType,
			String kindId) {
		String linkUrl = null;
		switch(activityKind) {
			case BOARDS : linkUrl = getBoardLinkUrl(domainId, boardId, activityType);
				break;
			case TASKS : linkUrl = getTaskLinkUrl(domainId, boardId, taskId, activityType);
				break;
//			case TASK_COMMENTS : linkUrl = getTaskCommentLinkUrl(domainId, boardId, taskId, activityType, kindId);
//				break;
			case TASK_CHECKLISTS : linkUrl = getTaskChecklistLinkUrl(domainId, boardId, taskId, activityType, kindId);
				break;
//			case TASK_CHECKLIST_COMMENTS : linkUrl = getTaskChecklistCommentLinkUrl(domainId, boardId, taskId, activityType, kindId);
//				break;
			case TASK_TIMELINES : linkUrl = getTaskTimelineLinkUrl(domainId, boardId, taskId, activityType, kindId);
				break;
			case TASK_TIMELINE_COMMENTS : linkUrl = getTaskTimelineCommentLinkUrl(domainId, boardId, taskId, activityType, kindId);
				break;
			case EVENTS : linkUrl = getEventLinkUrl(domainId, boardId, taskId, activityType, kindId);
				break;
			case NOTICE : linkUrl = getNoticeLinkUrl(domainId, boardId, taskId, activityType, kindId);
				break;
			case USAGE : linkUrl = getUsageLinkUrl(domainId, activityType);
				break;
			default :
				break;
		}
		return linkUrl;
	}
	public static String getBoardLinkUrl(String boardId) {
		return CommonProperty.BOARD_LINK_URL + boardId; 
	}
	private static String getBoardLinkUrl(String domainId, String boardId, ActivityType activityType) {
		String linkUrl = getBoardLinkUrl(boardId);
		switch(activityType) {
			default :
				break;
		}
		return linkUrl;
	}
	public static String getWorkspaceLinkUrl(String taskId) {
		return CommonProperty.WORKSPACE_LINK_URL + taskId;
	}
	private static String getTaskLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType) {
		String linkUrl = getBoardLinkUrl(boardId);
		
		switch(activityType) {
			case ASSIGNED : linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			case UNASSIGNED : linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			case ATTACHED : linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			case UPDATE_STARTDATE : linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			case UPDATE_DUEDATE : linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			default :
				break;
		}
		
		return linkUrl;
	}
	
	private static String getTaskChecklistLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType, String taskChecklistId) {
		String linkUrl = null;
		
		switch(activityType) {
			case ADDED :
			case UPDATED :
				linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			case DELETED :
			default :
				break;
		}
		
		return linkUrl;
	}
	
	private static String getTaskTimelineLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType, String taskTimelineId) {
		String linkUrl = null;
		
		switch(activityType) {
			case ADDED :
			case ADDED_WITH_MENTION :
			case COPIED :
			case UPDATED :
			case UPDATED_WITH_MENTION :
				linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			case DELETED :
			default :
				break;
		}
		
		return linkUrl;
	}
	private static String getTaskTimelineCommentLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType, String taskTimelineCommentId) {
		String linkUrl = null;
		
		switch(activityType) {
			case ADDED :
			case ADDED_WITH_MENTION :
			case UPDATED :
			case UPDATED_WITH_MENTION :
				linkUrl = getWorkspaceLinkUrl(taskId);
				break;
			case DELETED :
			default :
				break;
		}
		
		return linkUrl;
	}
	private static String getEventLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType, String eventId) {
		String linkUrl = null;
		
		switch(activityType) {
			case ADDED :
			case UPDATE_EVENT_DATE :
			case UPDATE_EVENT_STARTDATE :
			case UPDATE_EVENT_ENDDATE :
				if (StringUtils.isNotBlank(boardId)) {
					linkUrl = getBoardLinkUrl(boardId);
				}
				break;
			case DELETED :
			default :
				break;
		}
		
		return linkUrl;
	}
	private static String getNoticeLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType, String noticeId) {
		String linkUrl = null;
		
		switch(activityType) {
			case ADDED :
			case UPDATED :
				if (StringUtils.isNotBlank(boardId)) {
					linkUrl = getBoardLinkUrl(boardId);
				}
				break;
			case SYSTEM_NOTICE_ADDED :
			case SYSTEM_NOTICE_UPDATED :
//					linkUrl = CommonProperty.NOTICE_LINK_URL + noticeId;
				break;
			case DELETED :
			default :
				break;
		}
		
		return linkUrl;
	}
	private static String getUsageLinkUrl(String domainId, ActivityType activityType) {
		String linkUrl = CommonProperty.DOMAIN_INFO_LINK_URL;
		
		return linkUrl;
	}
	
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
//	@SuppressWarnings("unused")
//	@Deprecated
//	private static String getTaskChecklistCommentLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType, String taskChecklistCommentId) {
//		String linkUrl = null;
//		
//		switch(activityType) {
//			case ADDED :
//			case UPDATED :
//				linkUrl = getWorkspaceLinkUrl(taskId);
//				break;
//			case DELETED :
//			default :
//				break;
//		}
//		
//		return linkUrl;
//	}
//	@SuppressWarnings("unused")
//	@Deprecated
//	private static String getTaskCommentLinkUrl(String domainId, String boardId, String taskId, ActivityType activityType, String taskCommentId) {
//		String linkUrl = null;
//		
//		switch(activityType) {
//			case ADDED :
//			case UPDATED :
//				linkUrl = getWorkspaceLinkUrl(taskId);
//				break;
//			case DELETED :
//			default :
//				break;
//		}
//		
//		return linkUrl;
//	}
//	>>>>>>>>>>>>>>>>> Deprecated or Unused <<<<<<<<<<<<<<<<<<<<<
}
