package net.forecs.coconut.common.util.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;


public class SecurityUtils {
	public static String getMD5(String source) {
		return getSecure(source, "MD5");
    }
	
	public static String getSHA256(String source) {
		return getSecure(source, "SHA-256");
    }

	public static String getSHA1(String source) {
		return getSecure(source, "SHA-1");
    }

	public static String getSHA384(String source) {
		return getSecure(source, "SHA-384");
    }

	public static String getSHA512(String source) {
		return getSecure(source, "SHA-512");
    }

	public static String getSecure(String source, String algo) {
		// algo = SHA-1, SHA-256, SHA-384, SHA-512
		String sec = "";
		if (StringUtils.isBlank(algo)) { algo = "MD5"; }
		try {
			MessageDigest md = MessageDigest.getInstance(algo);
			md.update(source.getBytes(StandardCharsets.UTF_8));
			byte byteData[] = md.digest();
			sec = Hex.encodeHexString(byteData);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			sec = null;
		}
		return sec;
	}
}
