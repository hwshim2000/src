package net.forecs.coconut.common.util.security;

/*
 * Copyright (c) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.CommonProperty;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.appengine.datastore.AppEngineDataStoreFactory;
import com.google.api.client.extensions.appengine.http.UrlFetchTransport;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.store.DataStoreFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.storage.Storage;
import com.google.api.services.storage.StorageScopes;
import com.google.appengine.api.users.UserServiceFactory;

/**
 * Utility class for JDO persistence, OAuth flow helpers, and others.
 *
 * @author Yaniv Inbar
 */
public class OAuthUtils {
	//private static final Logger LOG = Logger.getLogger(OAuthUtils.class.getName());
	/**
	 * Global instance of the {@link DataStoreFactory}. The best practice is to
	 * make it a single globally shared instance across your application.
	 */
	private static final AppEngineDataStoreFactory DATA_STORE_FACTORY = AppEngineDataStoreFactory.getDefaultInstance();
	static List<String> GCS_SCOPES;
	static {
		GCS_SCOPES = new ArrayList<String>();
		GCS_SCOPES.add(StorageScopes.CLOUD_PLATFORM);
		GCS_SCOPES.add(StorageScopes.DEVSTORAGE_FULL_CONTROL);
	}
	

	/** Global instance of the HTTP transport. */
	static final HttpTransport HTTP_TRANSPORT = new UrlFetchTransport();

	/** Global instance of the JSON factory. */
	static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

	private static GoogleClientSecrets clientSecrets = null;

	public synchronized static GoogleClientSecrets getClientCredential() throws IOException {
		if (clientSecrets != null) { return clientSecrets; }
		
		clientSecrets = GoogleClientSecrets.load(
				JSON_FACTORY,
				new InputStreamReader(OAuthUtils.class
						.getResourceAsStream(CommonProperty.CLIENT_SECRETS_FILEPATH), StandardCharsets.UTF_8));
		Preconditions
				.checkArgument(
						!clientSecrets.getDetails().getClientId()
								.startsWith("Enter ")
								&& !clientSecrets.getDetails()
										.getClientSecret()
										.startsWith("Enter "),
						"Download client_secrets.json file from https://code.google.com/apis/console/"
								+ "?api=calendar into calendar-appengine-sample/src/main/resources/client_secrets.json");
		

		return clientSecrets;
	}

	public static String getRedirectUri(HttpServletRequest req) {
		GenericUrl url = new GenericUrl(req.getRequestURL().toString());
		url.setRawPath("/oauth2callback");
		return url.build();
	}

	public static GoogleAuthorizationCodeFlow newFlow() throws IOException {
		return new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT,
				JSON_FACTORY, getClientCredential(),
				Collections.singleton(CalendarScopes.CALENDAR))
				.setDataStoreFactory(DATA_STORE_FACTORY)
				.setAccessType("offline")
				.setApprovalPrompt("force")
				.build();
		
		// DATA_STORE_FACTORY).setAccessType("offline").build();
		// Refresh token을 얻기 위해선 ApprovalPrompt=force로
	}
	
	static final Collection<String> CALENDAR_SCOPES = Arrays.asList(
		//"https://www.googleapis.com/auth/userinfo.email",
		CalendarScopes.CALENDAR
			);

	public static Calendar loadCalendarClient() throws IOException {
		String userId = UserServiceFactory.getUserService().getCurrentUser().getUserId();

		// LOG.info(UserServiceFactory.getUserService().getCurrentUser().getEmail());
		// LOG.info(UserServiceFactory.getUserService().getCurrentUser().getNickname());
		// LOG.info(UserServiceFactory.getUserService().getCurrentUser().getFederatedIdentity());
		// LOG.info(UserServiceFactory.getUserService().getCurrentUser().getAuthDomain());
		
		Credential credential = newFlow().loadCredential(userId);
		return new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential).setApplicationName("My Google Calendar").build();
	}
	public static Calendar loadCalendarClientByEndpoints(String userEmail) throws IOException {
		Credential credential = null;
		try { 
			credential = new GoogleCredential.Builder()
				.setTransport(HTTP_TRANSPORT)
			    .setJsonFactory(JSON_FACTORY)
			    .setServiceAccountId(CommonProperty.SERVICE_ACCOUNT_EMAIL)
			    .setServiceAccountPrivateKeyFromP12File(new File("WEB-INF/CoCoWorks_Service_Account_Key.p12"))
			    .setServiceAccountScopes(Collections.singleton(CalendarScopes.CALENDAR))
			    .setServiceAccountUser(userEmail)
			    .build();
			System.out.println(credential.getAccessToken());
		} catch (Exception ex) {
			ex.printStackTrace();
		};
		
		return new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential).setApplicationName("cocoworks-myGoogleCalendar").build();
	}
//	public static Calendar loadCalendarApp() throws IOException {
//		AppIdentityCredential credential = new AppIdentityCredential(Arrays.asList(CalendarScopes.CALENDAR));
//
//		return new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential).setApplicationName("My Google Calendar").build();
//	}

	public static Storage loadGCS() throws IOException, GeneralSecurityException {
		try {
			HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
			JsonFactory jsonFactory = new JacksonFactory();
			GoogleCredential credential = null;
		
			credential = new GoogleCredential.Builder()
				.setTransport(httpTransport)
				.setJsonFactory(jsonFactory)
				.setServiceAccountId(CommonProperty.SERVICE_ACCOUNT_EMAIL)
				//.setServiceAccountPrivateKeyFromP12File(new File(CommonProperty.SERVICE_ACCOUNT_PKCS12_FILE_PATH))
				.setServiceAccountPrivateKeyFromP12File(new File(CommonProperty.SERVICE_ACCOUNT_PKCS12_FILE_PATH))
				.setServiceAccountScopes(GCS_SCOPES).build();
		
			return new Storage.Builder(httpTransport, jsonFactory, credential).setApplicationName("cocoworks-gcs").build();
		} catch (IOException ex) {
			throw ex;
		} catch (GeneralSecurityException ex) {
			throw ex;
		}
	}
	/**
	 * Returns an {@link IOException} (but not a subclass) in order to work
	 * around restrictive GWT serialization policy.
	 */
	public static IOException wrappedIOException(IOException e) {
		if (e.getClass() == IOException.class) {
			return e;
		}
		return new IOException(e.getMessage());
	}

	private OAuthUtils() {
	}
}
