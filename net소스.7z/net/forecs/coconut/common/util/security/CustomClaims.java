package net.forecs.coconut.common.util.security;

import java.io.Serializable;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.entity.security.Tokens;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomClaims implements Serializable {
	private static final long serialVersionUID = 3956342198265203276L;
	@Getter @Setter
	private String clientId;
	@Getter @Setter
	private String id;
//	@Getter @Setter
//	private String userName;
	@Getter @Setter
	private String domainName;
//	@Getter @Setter
//	private List<Scope> scopes;
	
	public CustomClaims() {
	}
	
	public CustomClaims(Tokens token) {
		this.clientId = token.getClientId();
		this.id = token.getAuth().getId();
		this.domainName = token.getAuth().getDomainName();
//		this.scopes = token.getAuth().getScopes();
	}
	
	public static CustomClaims convert(Map<String, Object> claimMap) {
		ObjectMapper om = new ObjectMapper();
		return om.convertValue(claimMap, CustomClaims.class);
	}
}
