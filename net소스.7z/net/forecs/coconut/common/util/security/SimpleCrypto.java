package net.forecs.coconut.common.util.security;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public final class SimpleCrypto {
	private final static String HEX = "0123456789ABCDEF";
//	private final static String CIPHER_KEY = "FNOeCRoCEtoNuCtS";
	
    public static String encrypt(String seed, String cleartext) throws Exception {
        byte[] rawKey = getRawKey(seed.getBytes(StandardCharsets.UTF_8));
        byte[] result = encrypt(rawKey, cleartext.getBytes(StandardCharsets.UTF_8));
        return toHex(result); 
    }

    public static String decrypt(String seed, String encrypted) throws Exception {
        byte[] rawKey = getRawKey(seed.getBytes(StandardCharsets.UTF_8));
        byte[] enc = toByte(encrypted);
        byte[] result = decrypt(rawKey, enc);
        return new String(result, StandardCharsets.UTF_8);
    }

    private static byte[] getRawKey(byte[] seed) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
        sr.setSeed(seed);
        kgen.init(128, sr); 
        SecretKey skey = kgen.generateKey();
        byte[] raw = skey.getEncoded();
        return raw;
    }


    private static byte[] encrypt(byte[] raw, byte[] clear) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encrypted = cipher.doFinal(clear);
        return encrypted;
    }

    private static byte[] decrypt(byte[] raw, byte[] encrypted) throws Exception {
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        byte[] decrypted = cipher.doFinal(encrypted);
        return decrypted;
    }

    public static String toHex(String txt) {
        return toHex(txt.getBytes(StandardCharsets.UTF_8));
    }
    public static String fromHex(String hex) {
        return new String(toByte(hex), StandardCharsets.UTF_8);
    }

    public static byte[] toByte(String hexString) {
        int len = hexString.length()/2;
        byte[] result = new byte[len];
        for (int i = 0; i < len; i++)
            result[i] = Integer.valueOf(hexString.substring(2*i, 2*i+2), 16).byteValue();
        return result;
    }

    public static String toHex(byte[] buf) {
        if (buf == null)
            return "";
        StringBuffer result = new StringBuffer(2*buf.length);
        for (int i = 0; i < buf.length; i++) {
            appendHex(result, buf[i]);
        }
        return result.toString();
    }
    
    private static void appendHex(StringBuffer sb, byte b) {
        sb.append(HEX.charAt((b>>4)&0x0f)).append(HEX.charAt(b&0x0f));
    }

    /*
    public static void main(String args[]) {
        // 암호화 Key 설정
        String key = CIPHER_KEY;
        
        try {
        	
        	String cr1 = SimpleCrypto.encrypt(key, "hyeunwoo.shim@forecs.net");
        	String cr2 = SimpleCrypto.encrypt(key, "coconutUserPassword!123!1");
        	String cr3 = SimpleCrypto.encrypt(key, "mailSummary@blabla.com");
        	String cr4 = SimpleCrypto.encrypt(key, "emailAccountPassword!!!21313");
        	
            LOG.warning("Encryped ID1 : " + cr1);
            LOG.warning("Encryped PW1 : " + cr2);
            LOG.warning("Encryped ID2 : " + cr3);
            LOG.warning("Encryped PW2 : " + cr4);
            
            LOG.warning("Decryped ID1 : " + SimpleCrypto.decrypt(key, cr1));
            LOG.warning("Decryped PW1 : " + SimpleCrypto.decrypt(key, cr2));
            LOG.warning("Decryped ID2 : " + SimpleCrypto.decrypt(key, cr3));
            LOG.warning("Decryped PW2 : " + SimpleCrypto.decrypt(key, cr4));

            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     */
}
