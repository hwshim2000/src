package net.forecs.coconut.common.util.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.util.JSONHelper;
import net.forecs.coconut.common.util.ServletUtil;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.security.TokenService;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.security.TokenContext;

import org.apache.commons.lang.StringUtils;

import com.google.api.server.spi.ServiceException;
import com.google.api.server.spi.response.UnauthorizedException;
import com.sun.jersey.core.util.Base64;

public class JwtManager {
	private final static String CUSTOM_CLAIM_NAME = "custom";
	private final static String HEADER_ALG_KEY = "alg"; 
	private final static String HEADER_TYP_KEY = "typ";
	private final static String DEFAULT_TYP_VAL = "JWT";
	private final static String DEFAULT_ISS_VAL = "cocoworks";
	
	private final static String SIGNATURE_ALGORITHM_PREFIX = "SHA1with";
	
	public final static String RSA = "RSA";
	public final static String DSA = "DSA";
	public final static String DH = "DH";
	//("DSA", 1024);
	//("DH", 576);
	//("RSA", 1024);
	 
	private String keyAlgorithm;
	private int keyInitNumBits;
	private String dataSignatureAlgorithm;
	private SignatureAlgorithm jwtSignatureAlgorithm; // RS256 or HS256
	
	private static JwtManager manager;
	
	public static JwtManager getManager() {
		if (manager == null) { manager = new JwtManager(); }
		return manager;
	}
	/** 
	 * @description : RS256을 사용하려면 형식에 맞는 키구조를 만들어서 사용해야 한다. 보통 키 생성시 사용자의 권한정보등에 privateKey 와 publickKey를 보관하였다가
	 * 키 생성시에 privateKey를 이용하고, public키를 이용하여 검증한다.
	 * 하지만, 여기서는 카종류중 한가지만을 사용하며, 성능향상을 위해 DB에서 키를 조회하는등의 단계등을 제거하기 위해
	 * customKey를 사용하기위해 주로 HS256을 사용할 것이다.
	 * jwt 토큰생성시 secretKey로 주로 사용자의 userAgent값과 remoteAddress를 키로 활용한다.
	 */
	private JwtManager() {
		this(RSA, SignatureAlgorithm.HS256);
		//this(RSA, SignatureAlgorithm.RS256);
	}
	private JwtManager(String keyAlgorithm) {
		this(keyAlgorithm, SignatureAlgorithm.HS256);
		//this(keyAlgorithm, SignatureAlgorithm.RS256);
	}
	private JwtManager(SignatureAlgorithm jwtSignatureAlgorithm) {
		this(RSA, jwtSignatureAlgorithm);
	}
	private JwtManager(String keyAlgorithm, SignatureAlgorithm jwtSignatureAlgorithm) {
		this.keyAlgorithm = keyAlgorithm;
		this.jwtSignatureAlgorithm = jwtSignatureAlgorithm;
		
		init();
	}
	private void init() {
		dataSignatureAlgorithm = SIGNATURE_ALGORITHM_PREFIX+keyAlgorithm;
		if (DH.equals(keyAlgorithm)) {
			keyInitNumBits = 574;
		} else {
			keyInitNumBits = 1024;
		}
	}
	private String generateKeyForHS256(HttpServletRequest request, Auths auth) {
		return generateKey(auth.isAgentCheck(), auth.getSecretKey(), ServletUtil.getRemoteAddr(request), ServletUtil.getUserAgent(request));
	}
	private String generateKeyForHS256(Tokens token) {
		return generateKey(token.getAuth().isAgentCheck(), token.getAuth().getSecretKey(), token.getAddress(), token.getAgent());
	}
	private String generateKey(boolean isAgentCheck, String secretKey, String address, String agent) {
		if (isAgentCheck) {
			return SecurityUtils.getMD5(String.format("%s%s%s", secretKey, address, agent));
		} else {
			return secretKey;
		}
	}
	
	/**
	 * TODO : Key를 생성해서 사용자 DB에 String 값으로 저장하는것에 대해 고려
	 * @description : private Key를 이용하여 data를 암호화 / public key를 이용하여 복호화 하는 등의 활용
	 *   : 또 다른 화룡 방법으로는 Jwt 인증 키로 활용하는 방안 검토
	 */
	public KeyPair generateKeyPair() throws NoSuchAlgorithmException, NoSuchProviderException{
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance(keyAlgorithm);
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
        keyGen.initialize(keyInitNumBits, random);
        //keyGen.initialize(numBits);
        return keyGen.genKeyPair();
	}
	
	/**
	 * @description : privateKey, publicKey를 Map 형태로 생성
	 */
	public Map<String, String> generateKeyPairStringMap() throws NoSuchAlgorithmException, NoSuchProviderException{
        return toKeyPairStringMap(generateKeyPair());
	}
	/**
	 * @description : privateKey, publicKey를 Map 형태로 생성
	 */
	public static Map<String, String> toKeyPairStringMap(KeyPair keyPair) throws NoSuchAlgorithmException, NoSuchProviderException{
		Map<String, String> keyPairMap = new HashMap<String, String>(2);
        keyPairMap.put("privateKey", toBase64String(keyPair.getPrivate()));
        keyPairMap.put("publicKey", toBase64String(keyPair.getPublic()));
        return keyPairMap;
	}

	/**
	 * @description : key를 base64 string으로 변환
	 */
	public static String toBase64String(Key key) {
		byte[] keyBytes = key.getEncoded();
        return DatatypeConverter.printBase64Binary(keyBytes);
	}
	
	/**
	 * @description : privateKey를 base64 string으로 변환
	 */
	public static String toPrivateKeyString(KeyPair keyPair) {
		 return toBase64String(keyPair.getPrivate());
	}
	/**
	 * @description : publicKey를 base64 string으로 변환
	 */
	public static String toPublicKeyString(KeyPair keyPair) {
		 return toBase64String(keyPair.getPublic());
	}
	/**
	 * @description : base64 string을 privateKey로 변환
	 */
	public PrivateKey toPrivateKey(String keyString) throws NoSuchAlgorithmException, InvalidKeySpecException{
		return toPrivateKey(toKeyBytes(keyString));
	}
	// key algorithm = RSA, DSA, ...
	/**
	 * @description : byte[]값을  privateKey로 변환
	 */
	public PrivateKey toPrivateKey(byte[] privateKeyBytes) throws NoSuchAlgorithmException, InvalidKeySpecException{
		KeyFactory keyFactory = KeyFactory.getInstance(keyAlgorithm);
        EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
        return keyFactory.generatePrivate(privateKeySpec);
	}
	/**
	 * @description : base64 string을 publicKey로 변환
	 */
	public PublicKey toPublicKey(String keyString) throws NoSuchAlgorithmException, InvalidKeySpecException{
		return toPublicKey(toKeyBytes(keyString));
	}
	/**
	 * @description : byte[]값을  publicKey로 변환
	 */
	public PublicKey toPublicKey(byte[] publicKeyBytes) throws NoSuchAlgorithmException, InvalidKeySpecException{
		KeyFactory keyFactory = KeyFactory.getInstance(keyAlgorithm);
        EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
        return keyFactory.generatePublic(publicKeySpec);
	}
	/**
	 * @description : base64 string을  byte[] 로 변환
	 */
	public static byte[] toKeyBytes(String keyString) {
		return DatatypeConverter.parseBase64Binary(keyString);
	}
	/**
	 * @description : 주어진 값을 이용하여 jwsToken(json web token)을 생성
	 * signatureAlgorithm에 따라 생성 방법이 다름
	 * HS256은 사용자 임의의 키를 활용하여 생성 가능하나(ex: userAgent, remoteAddr),
	 *  RS256은 key algorithm에 맞는 key값이어야 한다.(주로 privateKey 활용)
	 *
	 * TODO : 생성시에 TokenService의 token 생성시, jwt도 같이 생성하도록 검토
	 *      : 일회성 토큰이므로 DB에 저장할 필요는 없다. 단지, tokenSerice이 refresh 토큰을 이용하여 새로운 토큰을 만들어 낼때 같이 jwt도 만드는 방법 검토
	 *      : 토큰 만료 시간은, token의 만료시간을 활용
	 */
	public String generateJwsAccessToken(Tokens token)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		Date issueDate = new Date();
		
		CustomClaims cc = new CustomClaims(token);
		String keyString = generateKeyForHS256(token);
		JwtBuilder jb = Jwts.builder()
				.setHeaderParam(HEADER_ALG_KEY, jwtSignatureAlgorithm.toString())
				.setHeaderParam(HEADER_TYP_KEY, DEFAULT_TYP_VAL)
				.setIssuer(DEFAULT_ISS_VAL)
				.setId(UUID.randomUUID().toString())
				.setAudience(token.getClientId())
				.setIssuedAt(issueDate)
				.setExpiration(token.getExpire())
				.claim(CUSTOM_CLAIM_NAME, cc);
		
		PrivateKey pk = null;
		if (SignatureAlgorithm.RS256.equals(jwtSignatureAlgorithm)) {
			byte[] encoded = DatatypeConverter.parseBase64Binary(keyString);
			PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
	        
	        KeyFactory kf = KeyFactory.getInstance(RSA);
	        pk = kf.generatePrivate(keySpec);
	        jb.signWith(jwtSignatureAlgorithm, pk);
		} else if (SignatureAlgorithm.HS256.equals(jwtSignatureAlgorithm)) {
			jb.signWith(jwtSignatureAlgorithm, keyString);
		}
		
		return jb.compact();
	}
	
	/**
	 * @description : keyString(privateKey 또는 userAgent/remoteAddr)을 이용하여 jwt를 파싱
	 * TODO : 분석된 claims에서 필요한 데이터를 추출하여 Users 객체나, Tokens 객체에 담아서 리턴방법 검토
	 */
	private CustomClaims parseAndVerifyJwsAccessToken(String keyString, String jwsAccessToken) throws NoSuchAlgorithmException, InvalidKeySpecException {
		JwtParser jp = Jwts.parser();
		Date current = new Date();
		Date expiration = null;
		
		
		PrivateKey pk = null;
		if (SignatureAlgorithm.RS256.equals(jwtSignatureAlgorithm)) {
			byte[] encoded = DatatypeConverter.parseBase64Binary(keyString);
			PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
	        
	        KeyFactory kf = KeyFactory.getInstance(RSA);
	        pk = kf.generatePrivate(keySpec);
	        jp.setSigningKey(pk);
		} else if (SignatureAlgorithm.HS256.equals(jwtSignatureAlgorithm)) {
			jp.setSigningKey(keyString);
		} else {
			throw new NoSuchAlgorithmException("Avaialable algorithm is HS256 and RS256.");
		}
		
		Jws<Claims> jws = jp
				//.requireSubject("ME")
				//.require(CUSTOM_CLAIM_NAME, "myCustom")
				.requireIssuer(DEFAULT_ISS_VAL)
				.parseClaimsJws(jwsAccessToken);
		
		expiration = jws.getBody().getExpiration();
		if (expiration == null) {
			throw new InvalidKeySpecException("Require expiration date.");
		}
		if (expiration.compareTo(current) < 0) {
			throw new InvalidKeySpecException("Expired key.");
		}
		if (!StringUtils.equals(SignatureAlgorithm.HS256.toString(), (String)jws.getHeader().get(HEADER_ALG_KEY))
				&& !StringUtils.equals(SignatureAlgorithm.RS256.toString(), (String)jws.getHeader().get(HEADER_ALG_KEY))) {
			throw new NoSuchAlgorithmException("Avaialable signature algorithm is HS256 and RS256.");
		}
		
		@SuppressWarnings("unchecked")
		CustomClaims cc = CustomClaims.convert((Map<String, Object>)jws.getBody().get(CUSTOM_CLAIM_NAME));
		
		return cc;
		
		// -- verified values --
//		System.out.println("alg : " + jws.getHeader().get(HEADER_ALG_KEY));
//		System.out.println("typ : " + jws.getHeader().get(HEADER_TYP_KEY));
//		System.out.println("issuer : " + jws.getBody().get("iss"));
	}
	
	public CustomClaims validJwsAccessToken(HttpServletRequest request, String jwsAccessToken) throws InvalidKeySpecException, NoSuchAlgorithmException {
		try {
			String clientId = getClientId(jwsAccessToken.split("\\.")[1]);
			Auths auth = TokenService.getAuthById(clientId);
			CommonService.valid(auth);
			String keyString = generateKeyForHS256(request, auth);
			return parseAndVerifyJwsAccessToken(keyString, jwsAccessToken);
		} catch (InvalidKeySpecException ex) {
			throw ex;
		} catch (NoSuchAlgorithmException ex) {
			throw ex;
		} catch (ServiceException ex) {
			throw new InvalidKeySpecException(ex.getMessage());
		}
	}
	public CustomClaims validJwsAccessToken(String jwsAccessToken, Scope scope, TokenContext tokenContext) throws Exception {
		if (tokenContext != null && StringUtils.isBlank(jwsAccessToken)) { 
			//accessToken = retrieveAccessToken(context.getRequest());
			jwsAccessToken = tokenContext.getAccessToken();
			if (StringUtils.isBlank(jwsAccessToken)) { throw new UnauthorizedException("Invalid access token : " + jwsAccessToken); }
		}
		
		CustomClaims cc = validJwsAccessToken(tokenContext.getRequest(), jwsAccessToken);
		
		if (!CommonService.isValid(tokenContext.getAuth())) { throw new UnauthorizedException("Authority not found."); }
		if (!isValidScopes(tokenContext.getAuth().getScopes(), scope)) { throw new UnauthorizedException("Not access privilege area."); }
		return cc;
	}
	private static boolean isValidScopes(List<Scope> authScopes, Scope scope) {
		if (scope == null || Scope.NONE.equals(scope)) { return true; }	// 요청한 scope가 없으면 권한 체크를 하지 않음
		
		if (authScopes == null || authScopes.size() == 0) { return true; } // TODO : Scope가 없는 경우의 처리
		if (authScopes.contains(Scope.ADMIN)) { return true; } // 관리자 Scope를 가진 자격이면 true
		return authScopes.contains(scope);
	}
	// algorithm = DSA, RSA
	/**
	 * @description : privateKey를 활용하여 data를 암호화
	 */
	public String sign(String data, String privateKeyString) throws Exception {
		PrivateKey priKey = toPrivateKey(privateKeyString);
		return sign(data, priKey);
	}
	/**
	 * @description : privateKey를 활용하여 data를 암호화
	 */
	public String sign(String data, PrivateKey priKey) throws Exception {
		//String signatureAlgo = SIGNATURE_ALGORITHM_PREFIX+priKey.getAlgorithm();
		Signature dsaSign = Signature.getInstance(dataSignatureAlgorithm);
		
		dsaSign.initSign(priKey);
		
		//String data = "This is sample data.";
		dsaSign.update(data.getBytes());
		byte[] sig = dsaSign.sign();
		
		return DatatypeConverter.printBase64Binary(sig);
		//return sig;
	}
	/**
	 * @description : publicKey와 privateKey에 의해 생성된 signature를 활용하여 data가 변조되었는지 확인
	 */
	public boolean verify(String data, String signature, String publicKeyString) throws Exception {
		//-------------------------------------
		// data와 sigature를 전송했다 치고
		//-----------------------------------
		PublicKey pubKey = toPublicKey(publicKeyString);
		return verify(data, signature, pubKey);
	}
	/**
	 * @description : publicKey와 privateKey에 의해 생성된 signature를 활용하여 data가 변조되었는지 확인
	 */
	public boolean verify(String data, String signature, PublicKey pubKey) throws Exception {
		//-------------------------------------
		// data와 sigature를 전송했다 치고
		//-----------------------------------
		//String signatureAlgo = SIGNATURE_ALGORITHM_PREFIX+pubKey.getAlgorithm();
		Signature dsaVerify = Signature.getInstance(dataSignatureAlgorithm);
		
		dsaVerify.initVerify(pubKey);
		
		dsaVerify.update(data.getBytes());
		boolean verifies = dsaVerify.verify(DatatypeConverter.parseBase64Binary(signature));
		System.out.println("Signature verfies:" + verifies);
		
		return verifies;
	}
	
	public static boolean isJwsTokenType(String accessToken) {
		if (StringUtils.isBlank(accessToken)) { return false; }
		String jws[] = accessToken.split("\\.");
		if (jws.length != 3) { return false; }

		if (!Base64.isBase64(jws[0])) { return false; }
		
		try {
			String decodedHeader = Base64.base64Decode(jws[0]);
			String typ = JSONHelper.getStringValue(decodedHeader, HEADER_TYP_KEY);
			if (StringUtils.equals(typ, DEFAULT_TYP_VAL)) { return true; }
		} catch (Exception ex) { return false; }
		
		return false;
	}
	
	public static CustomClaims getNotVerifiedCustomClaims(String claimStr) {
		if (StringUtils.isBlank(claimStr)) { return null; }
		try {
			String decodedStr = Base64.base64Decode(claimStr);
			Map<String, Object> customMap = JSONHelper.getMap(decodedStr, CUSTOM_CLAIM_NAME);
			return CustomClaims.convert(customMap);
		} catch (Exception ex) { return null; }
	}
	
	public static String getClientId(String claimStr) {
		return getNotVerifiedCustomClaims(claimStr).getClientId();
	}
	
	
	/////////////////////////////////////
	
	/*private static void generateKeyTest(String keyAlgorithm, int numBits) throws Exception {
        try {
    		 // Get the public/private key pair
             KeyPairGenerator keyGen = KeyPairGenerator.getInstance(keyAlgorithm);
             SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
             keyGen.initialize(numBits, random);
             //keyGen.initialize(numBits);
             KeyPair keyPair = keyGen.genKeyPair();
             PrivateKey privateKey = keyPair.getPrivate();
             PublicKey publicKey = keyPair.getPublic();

             System.out.println("\n" + "Generating key/value pair using " + privateKey.getAlgorithm() + " algorithm");

             // Get the bytes of the public and private keys
             byte[] privateKeyBytes = privateKey.getEncoded();
             byte[] publicKeyBytes = publicKey.getEncoded();

             // Get the formats of the encoded bytes
             String formatPrivate = privateKey.getFormat(); // PKCS#8
             String formatPublic = publicKey.getFormat(); // X.509
            
             String base64PrivateKey = DatatypeConverter.printBase64Binary(privateKeyBytes);
             String base64PublicKey = DatatypeConverter.printBase64Binary(publicKeyBytes);
             
             System.out.println("base64 private key : " + base64PrivateKey);
             System.out.println("base64 public key : " + base64PublicKey);
             
             System.out.println("base64 private key 2: " + JwtManager.toPrivateKeyString(keyPair));
             System.out.println("base64 public key 2: " + JwtManager.toPublicKeyString(keyPair));
             
            
             System.out.println(Arrays.equals(privateKeyBytes, DatatypeConverter.parseBase64Binary(base64PrivateKey)));
             System.out.println(Arrays.equals(publicKeyBytes, DatatypeConverter.parseBase64Binary(base64PublicKey)));
             
             
             System.out.println("formatted binanry private Key : " + Base64.encode(String.valueOf(formatPrivate)));
             System.out.println("formatted binary public Key : " + Base64.encode(String.valueOf(formatPublic)));

             System.out.println("binary private Key : " + Base64.encode(String.valueOf(privateKeyBytes)));
             System.out.println("binary public Key : " + Base64.encode(String.valueOf(publicKeyBytes)));

             // The bytes can be converted back to public and private key objects
             KeyFactory keyFactory = KeyFactory.getInstance(keyAlgorithm);
             EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
             PrivateKey privateKey2 = keyFactory.generatePrivate(privateKeySpec);

             EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
             PublicKey publicKey2 = keyFactory.generatePublic(publicKeySpec);

             // The original and new keys are the same
             System.out.println("  Are both private keys equal? " + privateKey.equals(privateKey2));
             System.out.println("  Are both public keys equal? " + publicKey.equals(publicKey2));
        } catch (InvalidKeySpecException specException) {
             System.out.println("Exception");
             System.out.println("Invalid Key Spec Exception");
        } catch (NoSuchAlgorithmException e) {
             System.out.println("Exception");
             System.out.println("No such algorithm: " + keyAlgorithm);
        }
	}
	
	public static void signAndVerifyTest() throws Exception {
		String algo = "RSA"; // or DSA
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance(algo);
		
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
		keyGen.initialize(1024, random);
		
		KeyPair pair = keyGen.generateKeyPair();
		
		Signature dsaSign = Signature.getInstance(SIGNATURE_ALGORITHM_PREFIX+algo);
		
		PrivateKey priv = pair.getPrivate();
		dsaSign.initSign(priv);
		
		String data = "This is sample data.";
		dsaSign.update(data.getBytes());
		byte[] sig = dsaSign.sign();
		
		//-------------------------------------
		// data와 sigature를 전송했다 치고
		//-----------------------------------
		
		Signature dsaVerify = Signature.getInstance(SIGNATURE_ALGORITHM_PREFIX+algo);
		PublicKey pub = pair.getPublic();
		dsaVerify.initVerify(pub);
		
		dsaVerify.update(data.getBytes());
		boolean verfies = dsaVerify.verify(sig);
		System.out.println("Signature verfies:" + verfies);
	}
	
	
	public static void main(String[] args) throws Exception {
//		generateKeyTest("DSA", 1024);
//		generateKeyTest("DH", 576);
//		generateKeyTest("RSA", 1024);
//
//		signAndVerifyTest();
//		
//		JwtManager jm = new JwtManager(SignatureAlgorithm.HS256);
//		
//		Auths auth = new Auths();
//		auth.setId("IIIIIIII");
//		auth.setDomainName("DDDDDDDDDDD");
//		auth.setScopes(new ArrayList<Scope>());
//		
//		String keyString = "User-Agent:remoteAddr";	//webBrowser info + user ip address
//		Tokens token = new Tokens();
//		token.setExpire(new Date(Long.MAX_VALUE));
//		token.setClientId("CCCCCCCCCCCCCCCC");
//		token.setAuth(auth);
//		
//		String compactJws = jm.parseAndVerifyJwsToken(keyString, token);
		String claimStr = "eyJpc3MiOiJjb2Nvd29ya3MiLCJqdGkiOiIyOWI1NDQyOS0wOGZhLTQ3MjktODU5OS0zOTFhOWFlNDYwZDAiLCJhdWQiOiJNeURvbWFpbi1jb2NvbnV0IiwiaWF0IjoxNTAwODYwMjYzLCJleHAiOjE1MDE0NjUwNjMsImN1c3RvbSI6eyJjbGllbnRJZCI6Ik15RG9tYWluLWNvY29udXQiLCJpZCI6ImNvY29udXQiLCJ1c2VyTmFtZSI6bnVsbCwiZG9tYWluTmFtZSI6Ik15RG9tYWluIiwic2NvcGVzIjpbIkFETUlOIl19fQ";
		System.out.println(getClientId(claimStr));
		
//		System.out.println(compactJws);
//		CustomClaims cc = jm.parseAndVerifyJwsToken(keyString, compactJws);
//		System.out.println(cc.getId());
	}*/
}
