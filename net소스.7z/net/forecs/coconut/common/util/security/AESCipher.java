package net.forecs.coconut.common.util.security;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class AESCipher {
	private final static byte[] ivBytes = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
//	private final static String CIPHER_KEY = "FNOeCRoCEtoNuCtS";
	
	public static String encode(String str, String key)	throws java.io.UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException,	IllegalBlockSizeException, BadPaddingException {
		byte[] textBytes = str.getBytes(StandardCharsets.UTF_8);
		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		     SecretKeySpec newKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
		     Cipher cipher = null;
		cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
		
		// Base64로 인코딩한 후 GET 방식으로 보내면 안됨.. (POST 방식은 가능--why?? 인코딩된 값의 맨끝에 line feed 값이 넘어간다.)
		// 만일, GET 방식으로 보낸다면 HEX값으로 변경해서 보내면 되지만, Multi-language에서 사용하려면 제공된 모든 개발 언어에서도 toHex 함수를 만들어야 한다.
		return Base64.encodeBase64String(cipher.doFinal(textBytes));
		//return toHex(cipher.doFinal(textBytes));
	}

	public static String decode(String str, String key)	throws java.io.UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		// 인코딩 과정에서 Base64 encoding을 했는지 HEX string으로 encoding했는지에 따라 적용
		byte[] textBytes = Base64.decodeBase64(str);
		//byte[] textBytes = toByte(str);
		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec newKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
		return new String(cipher.doFinal(textBytes), StandardCharsets.UTF_8);
	}
    
//	public static void main(String[] args) throws InvalidKeyException, UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
//		String plainText;
//		String encodeText;
//		String decodeText;
//		/**
//		 * 주의할점. CIPHER_KEY의 값은 한글(3byte), 숫자/대문자/소문자 (1byte) 포함해서 16bytes(=128bit) 가 되어야 한다.
//		 * (Google AppEngine에서는 256bit가 지원 안되기 때문에 128bit 암호화만 허용됨. -
//		 */
//		// Encrypt
//		plainText  = "한글을 테스트 합니다.";
//		encodeText = AESCipher.encode(plainText, CIPHER_KEY);		
//		//LOG.warning("AES encode : "+encodeText + "(" + encodeText.length() + ")");
//		 
//		// Decrypt
//		decodeText = AESCipher.decode(encodeText, CIPHER_KEY);
//		//LOG.warning("AES decode : "+decodeText);
//	}
}