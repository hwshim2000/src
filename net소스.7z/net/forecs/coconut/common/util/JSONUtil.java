package net.forecs.coconut.common.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.code.JsonType;

import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.datastore.Text;

public class JSONUtil {
	public static boolean isJson(String jsonString) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			mapper.readTree(jsonString);
			return true;
		} catch (IOException e) {
			return false;
		}
	}
//	public static boolean isJson2(String jsonString) {
//		try {
//			final JSONObject mapper = new JSONObject(jsonString);
//			return true;
//		} catch (Exception e) {
//			return false;
//		}
//	}
    
//    private static Map<String, Object> parse(String key, Object obj , Map<String, Object> out) throws JSONException{
//    	if (obj instanceof JSONObject) {
//    		JSONObject json = (JSONObject)obj;
//	        Iterator<String> keys = json.keys();
//	        while(keys.hasNext()){
//	            key = keys.next();
//	            try{
//	            	parse(key, json.get(key), out);
//	            }catch(Exception e){
//	               // val = json.get(key);
//	            }
//	        }
//    	} else if (obj instanceof JSONArray) {
//    		JSONArray json = (JSONArray)obj;
//    		for (int i = 0; i < json.length(); i++) {
//    			parse(key+"-"+i, json.get(i), out);
//    		}
//    	} else {
//    		out.put(key, obj);
//    	}
//        return out;
//    }
    
	@SuppressWarnings("unchecked")
	private static void parse(Object obj, List<Object> out) {
		if (obj instanceof Map) {
			Map<Object, Object> mObj = (Map<Object, Object>)obj;
			for (Map.Entry<Object, Object> entry : mObj.entrySet()) {
				parse(entry.getValue(), out);
			}
		} else if (obj instanceof Collection) {
			List<Object> lObj = new ArrayList<Object>((Collection<Object>)obj);
			for (Object o : lObj) {
				parse(o, out);
			}
		} else {
			out.add(obj);
		}
	}

	public static Text toStringValues(Text jsonText, boolean removeHtmlTags) {
		if (jsonText == null || StringUtils.isBlank(jsonText.getValue())) { return new Text(""); }
		return new Text(toStringValues(jsonText.getValue(), removeHtmlTags));
	}
	public static String toStringValues(String jsonStr, boolean removeHtmlTags) {
		JSONObject json = null;
		String valueStr = jsonStr;
		try {
			json = new JSONObject(jsonStr);
			Map<String, Object> jMap = json.toMap();
			List<Object> out = new ArrayList<Object>();
			parse(jMap, out);
			
			StringBuilder sb = new StringBuilder();
			for (Object obj : out) {
				sb.append(obj);
				sb.append(" ");
			}
			valueStr = sb.toString();
		} catch (Exception ex) { } // 에러 발생시, jsonObject가 아니므로 일반적인 text로 판단 
		
		if (removeHtmlTags) {
			valueStr = HtmlUtil.removeHTMLTags(valueStr);
		}
		
		
		return valueStr;
	}
	public static Text toIndexingValues(Text jsonText, boolean removeHtmlTags) {
		if (jsonText == null || StringUtils.isBlank(jsonText.getValue())) { return new Text(""); }
		return new Text(toIndexingValues(jsonText.getValue(), removeHtmlTags));
	}
	public static String toIndexingValues(String jsonStr, boolean removeHtmlTags) {
		JSONObject json = null;
		String valueStr = jsonStr;
		try {
			json = new JSONObject(jsonStr);
			Map<String, Object> jMap = json.toMap();
			Object titleObj = jMap.get(FLD.title);
			Object descObj = jMap.get(FLD.description);
			
			StringBuilder sb = new StringBuilder();
			if (titleObj != null) { sb.append(titleObj); sb.append(" "); }
			if (descObj != null) { sb.append(descObj); }
			
			valueStr = sb.toString();
		} catch (Exception ex) { } // 에러 발생시, jsonObject가 아니므로 일반적인 text로 판단 
		
		if (removeHtmlTags) {
			valueStr = HtmlUtil.removeHTMLTags(valueStr);
		}
		
		return valueStr;
	}
	
	public static boolean isJsonValid(String str) {
		try {
	        new JSONObject(str);
	        return true;
	    } catch (JSONException ex) {
	        try {
	            new JSONArray(str);
	            return true;
	        } catch (JSONException ex1) {
	            return false;
	        }
	    }
	}
	
	public static JsonType getJsonType(String str) {
		try {
	        new JSONObject(str);
	        return JsonType.OBJECT;
	    } catch (JSONException ex) {
	        try {
	            new JSONArray(str);
	            return JsonType.ARRAY;
	        } catch (JSONException ex1) {
	            return JsonType.NONE;
	        }
	    }
	}
	
	public static boolean isJsonObject(String str) {
		try {
	        new JSONObject(str);
	        return true;
	    } catch (JSONException ex) {
	    	return false;
	    }
	}
	
	public static boolean isJsonArray(String str) {
		try {
	        new JSONArray(str);
	        return true;
	    } catch (JSONException ex) {
	    	return false;
	    }
	}

    
//    private static String toStringValues2(String jsonStr, boolean removeHtmlTags) {
//    	JSONObject json = new JSONObject(jsonStr);
//		Map<String, Object> out = new TreeMap<String, Object>();
//
//		parse("root", json, out);
//
//		StringBuilder sb = new StringBuilder();
//		for (Map.Entry<String, Object> entry : out.entrySet()) {
//			sb.append(entry.getValue());
//			sb.append(" ");
//		}
//		String result = sb.toString();
//		if (removeHtmlTags) {
//			result = HtmlUtil.removeHTMLTags(result);
//		}
//		
//		return result;
//    }
   
}
