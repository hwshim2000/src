package net.forecs.coconut.common.util.schema;

import lombok.Getter;
import lombok.Setter;

import org.apache.commons.lang.StringUtils;

public class Columns {
	@Getter @Setter
	private String name;
	@Getter @Setter
	private String description;
	@Getter @Setter
	private String type;
	@Getter @Setter
	private String defaultValue;
	@Getter @Setter
	private boolean primary;
	@Getter @Setter
	private boolean foreign;
	@Getter @Setter
	private boolean notnull;
	@Getter @Setter
	private boolean unique;
	@Getter @Setter
	private boolean index;
	@Getter @Setter
	private boolean autoIncrement;
	@Getter @Setter
	private int length;
	@Getter @Setter
	private boolean method;
	
	public Columns(Column column, String columnName, String columnType, boolean method) {
		if (StringUtils.isBlank(column.name())) {
			this.name = columnName;
		} else {
			this.name = column.name();	
		}
		if (StringUtils.isBlank(column.type())) {
			this.type = columnType;
		} else {
			this.type = column.type();
		}
		//this.name = StringUtils.upperCase(this.name);
		this.type = StringUtils.upperCase(this.type);
		
		this.defaultValue = column.defaultValue();	
		this.description = column.description();
		this.length = column.length();
		this.foreign = column.foreign();
		this.notnull = column.notnull();
		this.primary = column.primary();
		this.unique = column.unique();
		this.index = column.index();
		this.autoIncrement = column.autoIncrement();
		this.method = method;
	}
}
