package net.forecs.coconut.common.util.schema;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD}) //can use in method only.
public @interface Column {
	public String name() default "";		// Column name
	public String description() default "";	// Column description
	public String type() default "";		// Column type(String, Integer, Long, Date, ....)
	public String defaultValue() default "";// Default value
	public boolean primary() default false;	// is primary key
	public boolean foreign() default false;	// is foreign key
	public boolean unique() default false;	// is unique
	public boolean index() default false;
	public boolean notnull() default false;	// is notnull
	public boolean autoIncrement() default false;	// if only, primary is true
	public int length() default 0;			// Column length, if <=0 : unlimit
}
