package net.forecs.coconut.common.util.schema;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.attachment.Uploads;
import net.forecs.coconut.entity.backup.Backups;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Coupons;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Calendars;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.channel.WebHook;
import net.forecs.coconut.entity.channel.WebHookLog;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.domain.Departments;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.DomainsLog;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.tasklist.Tasklists;
import net.forecs.coconut.entity.user.UserDevices;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskHistories;
import net.forecs.coconut.entity.workspace.TaskLabelMap;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import edu.emory.mathcs.backport.java.util.Arrays;

public class DDLUtils {
	private final static boolean includeSuper = false;
	private final static String TAB = "        ";
	private final static Map<String, Class<? extends Base>> SCHEMAS = new HashMap<String, Class<? extends Base>>();
	static {
		SCHEMAS.put(Activities.class.getSimpleName(), Activities.class);
		SCHEMAS.put(Attachments.class.getSimpleName(), Attachments.class);
		SCHEMAS.put(AttachmentsMap.class.getSimpleName(), AttachmentsMap.class);
		SCHEMAS.put(Images.class.getSimpleName(), Images.class);
		SCHEMAS.put(Backups.class.getSimpleName(), Backups.class);
		SCHEMAS.put(Bills.class.getSimpleName(), Bills.class);
		SCHEMAS.put(Boards.class.getSimpleName(), Boards.class);
		SCHEMAS.put(Calendars.class.getSimpleName(), Calendars.class);
		SCHEMAS.put(ChannelToken.class.getSimpleName(), ChannelToken.class);
		SCHEMAS.put(Coupons.class.getSimpleName(), Coupons.class);
		SCHEMAS.put(Domains.class.getSimpleName(), Domains.class);
		SCHEMAS.put(DomainsLog.class.getSimpleName(), DomainsLog.class);
		SCHEMAS.put(Events.class.getSimpleName(), Events.class);
		SCHEMAS.put(Groups.class.getSimpleName(), Groups.class);
		SCHEMAS.put(MemberAuths.class.getSimpleName(), MemberAuths.class);
		SCHEMAS.put(Notice.class.getSimpleName(), Notice.class);
		SCHEMAS.put(NotificationSettings.class.getSimpleName(), NotificationSettings.class);
		SCHEMAS.put(Subscriptions.class.getSimpleName(), Subscriptions.class);
		SCHEMAS.put(Tasks.class.getSimpleName(), Tasks.class);
		SCHEMAS.put(Tasklists.class.getSimpleName(), Tasklists.class);
		SCHEMAS.put(TaskChecklistHistories.class.getSimpleName(), TaskChecklistHistories.class);
		SCHEMAS.put(TaskChecklists.class.getSimpleName(), TaskChecklists.class);
		SCHEMAS.put(TaskHistories.class.getSimpleName(), TaskHistories.class);
		SCHEMAS.put(TaskLabelMap.class.getSimpleName(), TaskLabelMap.class);
		SCHEMAS.put(TaskLabels.class.getSimpleName(), TaskLabels.class);
		SCHEMAS.put(TaskTimelineComments.class.getSimpleName(), TaskTimelineComments.class);
		SCHEMAS.put(TaskTimelines.class.getSimpleName(), TaskTimelines.class);
		SCHEMAS.put(Users.class.getSimpleName(), Users.class);
		SCHEMAS.put(UserProfiles.class.getSimpleName(), UserProfiles.class);
		SCHEMAS.put(UserSetting.class.getSimpleName(), UserSetting.class);
		SCHEMAS.put(Usage.class.getSimpleName(), Usage.class);
		SCHEMAS.put(UsageLogs.class.getSimpleName(), UsageLogs.class);
		SCHEMAS.put(UserDevices.class.getSimpleName(), UserDevices.class);
		SCHEMAS.put(WebHook.class.getSimpleName(), WebHook.class);
		SCHEMAS.put(WebHookLog.class.getSimpleName(), WebHookLog.class);
		SCHEMAS.put(Departments.class.getSimpleName(), Departments.class);
		SCHEMAS.put(Emoticons.class.getSimpleName(), Emoticons.class);
		SCHEMAS.put(Uploads.class.getSimpleName(), Uploads.class);
		SCHEMAS.put(Auths.class.getSimpleName(), Auths.class);
		SCHEMAS.put(Tokens.class.getSimpleName(), Tokens.class);
	}
	public static Schemas convertToSchemas(Class<? extends Base> clazz) throws Exception {
		if (!clazz.isAnnotationPresent(Schema.class)) { return null; }
		
		Annotation annotation = clazz.getAnnotation(Schema.class);
		Schema schema = (Schema) annotation;
		
		return new Schemas(schema, clazz.getSimpleName());
	}
	
	public static List<Columns> convertToColumns(Class<? extends Base> clazz) throws Exception {
		List<Method> methods = getAllMethods(clazz);
		List<Columns> columns = new ArrayList<Columns>();
		
		for (Method method : methods) {
			if (java.lang.reflect.Modifier.isStatic(method.getModifiers())) { continue; }
			if (!method.isAnnotationPresent(Column.class)) { continue; }
			
			String name = method.getName();
			//System.out.printf("Method : %s\n", name);
			if(!name.startsWith("get") && !name.startsWith("is")) { continue; }
		
			Annotation annotation = method.getAnnotation(Column.class);
			Column column = (Column) annotation;
			
			String methodName = name.substring(3);
			methodName = methodName.substring(0,1).toLowerCase() + methodName.substring(1);
			String returnType = method.getReturnType().getSimpleName();
		
			columns.add(new Columns(column, methodName, returnType, true));
		}
		
		List<Field> fields = getAllFields(clazz);
		for (Field field : fields) {
			if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) { continue; } 
			
			// if method is annotated with @Test
			if (!field.isAnnotationPresent(Column.class)) { continue; }

			Annotation annotation = field.getAnnotation(Column.class);
			Column column = (Column) annotation;
			
			columns.add(new Columns(column, field.getName(), field.getType().getSimpleName(), false));
//			System.out.println("- - - - - - - - - - -");
//			System.out.printf("Field property : %s %s\n", field.getName(), field.getType().getSimpleName() );
//			System.out.printf("Field desc : %s\n", column.desc());
//			System.out.printf("Field name : %s\n", column.name());
//			System.out.println("- - - - - - - - - - -");
		}
		sort(columns);
		return columns;
	}
	
	private static List<Field> getAllFields(Class<?> clazz) {
		List<Field> fields = new ArrayList<Field>();
		setAllFields(clazz, fields);
		
		return fields;
	}
	
	@SuppressWarnings("unchecked")
	private static void setAllFields(Class<?> clazz, List<Field> fields) {
		Field[] arr = clazz.getDeclaredFields();
		fields.addAll(Arrays.asList(arr));
		if (!includeSuper) { return; }
		if (clazz.getSuperclass() != null) {
			setAllFields(clazz.getSuperclass(), fields);
		}
	}
	
	private static List<Method> getAllMethods(Class<?> clazz) {
		List<Method> methods = new ArrayList<Method>();
		setAllMethods(clazz, methods);
		
		return methods;
	}
	
	@SuppressWarnings("unchecked")
	private static void setAllMethods(Class<?> clazz, List<Method> methods) {
		Method[] arr = clazz.getDeclaredMethods();
		methods.addAll(Arrays.asList(arr));
		if (!includeSuper) { return; }
		if (clazz.getSuperclass() != null) {
			setAllMethods(clazz.getSuperclass(), methods);
		}
	}
	public static List<Schemas> listAllSchemas() throws Exception {
		List<Schemas> schemas = new ArrayList<Schemas>();
		
		for (Map.Entry<String, Class<? extends Base>> obj : SCHEMAS.entrySet()) {
			Schemas schema = getSchemas(obj.getKey());
			if (schema != null) {
				schemas.add(schema);
			}
		}
		sortBySchemaName(schemas);
		return schemas;
	}
	public static List<Schemas> listSchemas(List<String> kinds) throws Exception {
		List<Schemas> schemas = new ArrayList<Schemas>();
		for (String kind : kinds) {
			Schemas schema = getSchemas(kind);
			if (schema != null) { schemas.add(schema); }
		}
		sortBySchemaName(schemas);
		return schemas;
	}
	public static Schemas getSchemas(String kind) throws Exception {
		Class<? extends Base> clazz = SCHEMAS.get(kind);
		return getSchemas(clazz);
	}
	private static Schemas getSchemas(Class<? extends Base> clazz) throws Exception {
		Schemas schema = convertToSchemas(clazz);
		if (schema == null) { return null; }
		
		List<Columns> columns = convertToColumns(clazz);
		schema.setColumns(columns);
		return schema; 
	}
	private static void sortBySchemaName(List<Schemas> list) {
		Collections.sort(list, new Comparator<Schemas>() {
	        @Override
	        public int compare(Schemas first, Schemas second) {
	        	return first.getName().compareTo(second.getName()); 
	        }
	    });
	}
	
	private static void sort(List<Columns> list) {
		sortByName(list);
		sortByNotNull(list);
		sortByFK(list);
		Collections.sort(list, new Comparator<Columns>() {
	        @Override
	        public int compare(Columns first, Columns second) {
	        	if (first.isPrimary() && !second.isPrimary()) {
	        		return -1;
	        	} else {
	        		return 0;
	        	}
//	        	} else if (first.isPrimary() == second.isPrimary()){
	        }
	    });
	}
	private static void sortByName(List<Columns> list) {
		Collections.sort(list, new Comparator<Columns>() {
	        @Override
	        public int compare(Columns first, Columns second) {
	        	return first.getName().compareTo(second.getName()); 
	        }
	    });
	}
	private static void sortByFK(List<Columns> list) {
		Collections.sort(list, new Comparator<Columns>() {
	        @Override
	        public int compare(Columns first, Columns second) {
	        	if (first.isForeign() && !second.isForeign()) {
	        		return -1;
	        	} else if (first.isForeign() == second.isForeign()){
	        		return 0;
	        	} else {
	        		return 1;
	        	}
	        }
	    });
	}
	private static void sortByNotNull(List<Columns> list) {
		Collections.sort(list, new Comparator<Columns>() {
	        @Override
	        public int compare(Columns first, Columns second) {
	        	if (first.isNotnull() && !second.isNotnull()) {
	        		return -1;
	        	} else if (first.isNotnull() == second.isNotnull()){
	        		return 0;
	        	} else {
	        		return 1;
	        	}
	        }
	    });
	}
	
	public static String createTableStatement(Schemas schema) {
		StringBuilder sb = new StringBuilder();
		sb.append("CREATE TABLE ");
		sb.append(schema.getName());
		sb.append("(\n");
		
		List<String> colDefs = new ArrayList<String>();
		
		for (Columns col : schema.getColumns()) {
			String colDef = TAB + col.getName() + " " + col.getType();
			if (col.getLength() > 0) { colDef += "("+col.getLength()+")"; }
			if (col.isNotnull()) { colDef += " NOT NULL"; }
			if (col.isUnique()) { colDef += " UNIQUE"; }
			if (col.isAutoIncrement()) { colDef +=" AUTO_INCREMENT"; }
			if (StringUtils.isNotBlank(col.getDefaultValue())) { colDef += " DEFAULT '"+col.getDefaultValue()+"'"; }
			
			colDefs.add(colDef);
			//sb.append(",\n");
		}
		
		if (StringUtils.isNotBlank(schema.getPkConstraint())) {
			colDefs.add(TAB + schema.getPkConstraint());
		}
		for (String fk : schema.getFkConstraints()) {
			if (StringUtils.isNotBlank(fk)) {
				colDefs.add(TAB+fk);
			}
		}
		sb.append(StringUtils.join(colDefs, ",\n"));
		sb.append("\n)");
		
		return sb.toString();
	}
	
	
	public static void main(String[] args) throws Exception {
		List<Schemas> schemas = listAllSchemas();
		
		ObjectMapper om = new ObjectMapper();
		om.enable(SerializationFeature.INDENT_OUTPUT);
		
		System.out.println(om.writeValueAsString(schemas));
		for (Schemas schema : schemas) {
			String ddl = createTableStatement(schema);
			
			System.out.println(ddl);
		}
	}
}
