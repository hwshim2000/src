package net.forecs.coconut.common.util.schema;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

import org.apache.commons.lang.StringUtils;

public class Schemas {
	@Getter @Setter
	private String name;
	@Getter @Setter
	private String description;
	@Getter @Setter
	private List<String> references;
	@Getter @Setter
	private String pkConstraint;
	@Getter @Setter
	private List<String> fkConstraints;
	@Getter @Setter
	private List<Columns> columns;
	
	public Schemas(Schema schema, String schemaName) {
		if (StringUtils.isBlank(schema.name())) {
			name = schemaName;
		} else {
			name = schema.name();	
		}
		description = schema.description();
		references = new ArrayList<String>();
		for (String ref : schema.references()) {
			if (StringUtils.isNotBlank(ref)) { references.add(ref); }
		}
		
		this.pkConstraint = schema.pkConstraint();
		this.fkConstraints = new ArrayList<String>();
		for (String fk : schema.fkConstraints()) {
			if (StringUtils.isNotBlank(fk)) { fkConstraints.add(fk); }
		}
	}
}
