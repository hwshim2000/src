package net.forecs.coconut.common.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.DatatypeConverter;

import com.ibm.icu.text.SimpleDateFormat;
import com.ibm.icu.util.Calendar;
import com.ibm.icu.util.ChineseCalendar;
import com.ibm.icu.util.TimeZone;


public class CalendarUtil {
	public static final String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS zzz";
//    public static final String LEGACY_FORMAT = "EEE MMM dd hh:mm:ss zzz yyyy";
    private static final TimeZone utc = TimeZone.getTimeZone("UTC");
//    private static final SimpleDateFormat legacyFormatter = new SimpleDateFormat(LEGACY_FORMAT);
    private static final SimpleDateFormat isoFormatter = new SimpleDateFormat(ISO_FORMAT);
    private static final List<String> formats = new ArrayList<String>();
	
    static {
//        legacyFormatter.setTimeZone(utc);
        isoFormatter.setTimeZone(utc);
        formats.add("yyyy-MM-dd'T'HH:mm:ss.SSS zzz");
    	formats.add("yyyy-MM-dd");
    	formats.add("yyyy/MM/dd");
    	formats.add("yyyy.MM.dd");
    	formats.add("yyyy-MM-dd HH:mm:ss");
    	formats.add("yyyyMMdd");
    	formats.add("yyyyMMddHHmmss");
    	formats.add("dd/MM/yyyy");
    	formats.add("dd/MM/yy");
    	formats.add("dd-MM-yyyy");
    	formats.add("dd-MM-yy");
    	formats.add("dd.MM.yyyy");
    	formats.add("dd.MM.yy");
    	formats.add("yy-MM-dd");
    	formats.add("yy/MM/dd");
    	formats.add("yy.MM.dd");
    	formats.add("yyMMdd");
    }

	
	public static int getCurrentDay() {
		return Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
	}
	public static int getCurrentMonth() {
		return Calendar.getInstance().get(Calendar.MONTH) + 1;
	}
	public static int getCurrentYear() {
		return Calendar.getInstance().get(Calendar.YEAR);
	}
	
	public static int getDay(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DAY_OF_MONTH);
	}
	public static int getMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.MONTH) + 1;
	}
	public static int getYear(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.YEAR);
	}
	
	public static Date setDate(int year, int month, int day) {
		Calendar cal = Calendar.getInstance();
		cal.set(year, month - 1, day);
		return cal.getTime();
	}
	public static Date setDate(Date date, int year, int month, int day) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(year, month - 1, day);
		return cal.getTime();
	}
	public static Date setYearMonth(Date date, int year, int month) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month-1);
		return cal.getTime();
	}
	public static Date setYear(Date date, int year) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.YEAR, year);
		return cal.getTime();
	}
	public static Date setMonth(Date date, int month) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.MONTH, month-1);
		return cal.getTime();
	}
	
	public static int getDayOfYear() {
		return Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
	}
	
	public static int diffDaysOfNextMonth(Integer day) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		if (day != null && day != 0) {
			cal.set(Calendar.DAY_OF_MONTH, day);
		}
		
		return cal.get(Calendar.DAY_OF_YEAR) - getDayOfYear();
	}
	public static int diffDaysOfMonth(Date fromDate, Date toDate) {
		if (fromDate == null || toDate == null) { return 0; }
		Calendar from = Calendar.getInstance();
		Calendar to = Calendar.getInstance();
		
		from.setTime(fromDate);
		to.setTime(toDate);
		
		return (to.get(Calendar.DAY_OF_MONTH) - from.get(Calendar.DAY_OF_MONTH)) + 1;
	}
	public static int diffDaysOfMonth(Integer day) {
		Calendar cal = Calendar.getInstance();
		if (day != null && day != 0) {
			cal.set(Calendar.DAY_OF_MONTH, day);
		}
		
		return cal.get(Calendar.DAY_OF_YEAR) - getDayOfYear();
	}
	public static Long diffDays(Date fromDate, Date toDate) {
		if (fromDate == null || toDate == null) { return null; }
		Long from = toLongDay_yyyyMMdd(fromDate);
		Long to = toLongDay_yyyyMMdd(toDate);
		
		return from - to;
	}

	public static Date parseDateFromUTC(String utcDateString) {
		java.util.Calendar cal = DatatypeConverter.parseDateTime(utcDateString);
		return cal.getTime();
	}
	public static String toISOString(final Date date) {
		return isoFormatter.format(date);
	}
	public static String toString(final Date date) {
		if (date == null) { return null; }
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.format(date);
	}
	public static String toString(final Date date, String format) {
		if (date == null) { return null; }
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(date);
	}
	public static Date toDate(String dateStr, String format) throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.parse(dateStr);
	}
	private static Long toLongDay_yyyyMMdd(Date date) {
		String dateStr = toString(date, "yyyyMMdd");
		return Long.valueOf(dateStr);
	}
	
	public static Date addSecond(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.SECOND, amount);
		return cal.getTime();
	}
	public static Date addMinute(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MINUTE, amount);
		return cal.getTime();
	}
	public static Date addHour(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR_OF_DAY, amount);
		return cal.getTime();
	}
	public static Date addDay(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, amount);
		return cal.getTime();
	}
	public static Date addWeek(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.WEEK_OF_MONTH, amount);
		return cal.getTime();
	}
	public static Date addMonth(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, amount);
		return cal.getTime();
	}
	public static Date addYear(Date date, int amount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.YEAR, amount);
		return cal.getTime();
	}
	
	public static Date getStartDateOfDay(Date date) {
		return getStartDateOfDay(date, null);
	}
	private static Date getStartDateOfDay(Date date, TimeZone tz) {
		if (date==null) { return null; }
		Calendar cal = Calendar.getInstance();
		
		if (tz == null) { tz = TimeZone.getDefault(); }
		cal.setTimeZone(tz);
		
		cal.setTime(date);
		
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		
		return cal.getTime();
	}
	
	public static Date getEndDateOfDay(Date date) {
		return getEndDateOfDay(date, null);
	}
	private static Date getEndDateOfDay(Date date, TimeZone tz) {
		if (date==null) { return null; }
		Calendar cal = Calendar.getInstance();
		
		if (tz == null) { tz = TimeZone.getDefault(); }
		cal.setTimeZone(tz);
		
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 999);
		
		return cal.getTime();
	}
	
	/**
	 * 양력(yyyyMMdd) -> 음력(yyyyMMdd)
	 * 윤달 제외
	 */
	public static Date toLunar(Date date) throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-HHmmss");
		String[] dateTime = formatter.format(date).split("-");
		
		String formattedDate = toLunar(dateTime[0]);
		return formatter.parse(formattedDate+"-"+dateTime[1]);
	}
	public static Date toLunarStartDateOfDay(Date date) throws Exception {
		return getStartDateOfDay(toLunar(date));
	}
	public static Date toLunarEndDateOfDay(Date date) throws Exception {
		return getEndDateOfDay(toLunar(date));
	}

	/**
	 * 양력(yyyyMMdd) -> 음력(yyyyMMdd)
	 * 윤달 제외
	 */
	private static String toLunar(String yyyymmdd) {
		Calendar cal = Calendar.getInstance();
		ChineseCalendar cc = new ChineseCalendar();
		
		if (yyyymmdd == null)
			return "";

		String date = yyyymmdd.trim();
		if (date.length() != 8) {
			if (date.length() == 4)
				date = date + "0101";
			else if (date.length() == 6)
				date = date + "01";
			else if (date.length() > 8)
				date = date.substring(0, 8);
			else
				return "";
		}

		cal.set(Calendar.YEAR, Integer.parseInt(date.substring(0, 4)));
		cal.set(Calendar.MONTH, Integer.parseInt(date.substring(4, 6)) - 1);
		cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(date.substring(6)));

		cc.setTimeInMillis(cal.getTimeInMillis());

		// ChinessCalendar.YEAR 는 1~60 까지의 값만 가지고 ,
		// ChinessCalendar.EXTENDED_YEAR 는 Calendar.YEAR 값과 2637 만큼의 차이를 가집니다.
		int y = cc.get(ChineseCalendar.EXTENDED_YEAR) - 2637;
		int m = cc.get(ChineseCalendar.MONTH) + 1;
		int d = cc.get(ChineseCalendar.DAY_OF_MONTH);

		StringBuffer ret = new StringBuffer();
		if (y >= 100 && y < 1000)
			ret.append("0");
		else if (y >= 10 && y < 100)
			ret.append("00");
		else if (y < 10)
			ret.append("000");
		ret.append(y);

		if (m < 10)
			ret.append("0");
		ret.append(m);

		if (d < 10)
			ret.append("0");
		ret.append(d);

		return ret.toString();
	}
	
	/**
	 * 음력(yyyyMMdd) -> 양력(yyyyMMdd)
	 * 윤달 포함
	 */
	public static Date toSolar(Date date) throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-HHmmss");
		String[] dateTime = formatter.format(date).split("-");
		String formattedDate = toSolar(dateTime[0]);
		return formatter.parse(formattedDate+"-"+dateTime[1]);
	}
	public static Date toSolarStartDateOfDay(Date date) throws Exception {
		return getStartDateOfDay(toSolar(date));
	}
	public static Date toSolarEndDateOfDay(Date date) throws Exception {
		return getEndDateOfDay(toSolar(date));
	}
	/**
	 * 음력(yyyyMMdd) -> 양력(yyyyMMdd)
	 * 윤달 포함
	 */
	private static String toSolar(String yyyymmdd) {
		Calendar cal = Calendar.getInstance();;
		ChineseCalendar cc = new ChineseCalendar();
		if (yyyymmdd == null)
			return "";

		String date = yyyymmdd.trim();
		if (date.length() != 8) {
			if (date.length() == 4)
				date = date + "0101";
			else if (date.length() == 6)
				date = date + "01";
			else if (date.length() > 8)
				date = date.substring(0, 8);
			else
				return "";
		}

		cc.set(ChineseCalendar.EXTENDED_YEAR,
				Integer.parseInt(date.substring(0, 4)) + 2637);
		cc.set(ChineseCalendar.MONTH,
				Integer.parseInt(date.substring(4, 6)) - 1);
		cc.set(ChineseCalendar.DAY_OF_MONTH,
				Integer.parseInt(date.substring(6)));

		cal.setTimeInMillis(cc.getTimeInMillis());

		int y = cal.get(Calendar.YEAR);
		int m = cal.get(Calendar.MONTH) + 1;
		int d = cal.get(Calendar.DAY_OF_MONTH);

		StringBuffer ret = new StringBuffer();
		if (y >= 100 && y < 1000)
			ret.append("0");
		else if (y >= 10 && y < 100)
			ret.append("00");
		else if (y < 10)
			ret.append("000");
		ret.append(y);

		if (m < 10)
			ret.append("0");
		ret.append(m);

		if (d < 10)
			ret.append("0");
		ret.append(d);

		return ret.toString();
	}

	/**
	* 입력받은 양력일자를 변환하여 음력일자로 반환
	* @param sDate 양력일자
	* @return 음력일자
	*/
	public static HashMap<String, Object> toLunarWithLeap(Date date) throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-HHmmss");
		String[] dateTime = formatter.format(date).split("-");
		HashMap<String, Object> lunarMap = toLunarWithLeap(dateTime[0]);
		Date lunarDate = formatter.parse((String)lunarMap.get("dayStr")+"-"+dateTime[1]);
		Date startDate = getStartDateOfDay(lunarDate);
		Date endDate = getEndDateOfDay(lunarDate);
		lunarMap.put("date", lunarDate);
		lunarMap.put("startDate", startDate);
		lunarMap.put("endDate", endDate);
		return lunarMap;
	}
	
	/**
	* 입력받은 양력일자를 변환하여 음력일자로 반환
	* @param sDate 양력일자
	* @return 음력일자
	*/
    private static HashMap<String, Object> toLunarWithLeap(String sDate) {
        String dateStr = validChkDate(sDate);

        HashMap<String, Object> hm = new HashMap<String, Object>();
        hm.put("dayStr", "");
        hm.put("leap", 0);

        if(dateStr.length() != 8) {
            return hm;
        }

        Calendar cal ;
        ChineseCalendar lcal ;

        cal = Calendar.getInstance() ;
        lcal = new ChineseCalendar();

        cal.set(Calendar.YEAR        , Integer.parseInt(dateStr.substring(0,4)));
        cal.set(Calendar.MONTH       , Integer.parseInt(dateStr.substring(4,6))-1 );
        cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateStr.substring(6,8)));

        lcal.setTimeInMillis(cal.getTimeInMillis());

        String year  = String.valueOf(lcal.get(ChineseCalendar.EXTENDED_YEAR) - 2637);
        String month = String.valueOf(lcal.get(ChineseCalendar.MONTH        ) + 1   );
        String day   = String.valueOf(lcal.get(ChineseCalendar.DAY_OF_MONTH )       );
        int leap  = lcal.get(ChineseCalendar.IS_LEAP_MONTH);

        String pad4Str = "0000";
        String pad2Str = "00";

        String retYear  = (pad4Str + year ) .substring(year .length());
        String retMonth = (pad2Str + month) .substring(month.length());
        String retDay   = (pad2Str + day  ) .substring(day  .length());

        String SDay = retYear+retMonth+retDay;

        hm.put("dayStr", SDay);
        hm.put("leap", leap);

        return hm;
    }

    /**
     * 입력받은 음력일자를 변환하여 양력일자로 반환
     * @param sDate 음력일자
     * @param iLeapMonth 음력윤달여부(IS_LEAP_MONTH)  윤달구분[0,1] (예, 1)
     * @return 양력일자
     */
    public static Date toSolarWithLeap(Date sDate, int iLeapMonth) throws Exception {
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd-HHmmss");
    	String[] dateTime = formatter.format(sDate).split("-");
		return formatter.parse(toSolarWithLeap(dateTime[0], iLeapMonth)+"-"+dateTime[1]);
    }
    public static Date toSolarStartDateOfDayWithLeap(Date sDate, int iLeapMonth) throws Exception {
    	return getStartDateOfDay(toSolarWithLeap(sDate, iLeapMonth));
    }
    public static Date toSolarEndDateOfDayWithLeap(Date sDate, int iLeapMonth) throws Exception {
    	return getEndDateOfDay(toSolarWithLeap(sDate, iLeapMonth));
    }
    /**
     * 입력받은 음력일자를 변환하여 양력일자로 반환
     * @param sDate 음력일자
     * @param iLeapMonth 음력윤달여부(IS_LEAP_MONTH)  윤달구분[0,1] (예, 1)
     * @return 양력일자
     */
    private static String toSolarWithLeap(String sDate, int iLeapMonth) {
        String dateStr = validChkDate(sDate);

        Calendar cal ;
        ChineseCalendar lcal ;

        cal = Calendar.getInstance() ;
        lcal = new ChineseCalendar();


        lcal.set(ChineseCalendar.EXTENDED_YEAR, Integer.parseInt(dateStr.substring(0,4)) + 2637);
        lcal.set(ChineseCalendar.MONTH        , Integer.parseInt(dateStr.substring(4,6)) - 1);
        lcal.set(ChineseCalendar.DAY_OF_MONTH , Integer.parseInt(dateStr.substring(6,8)));
        lcal.set(ChineseCalendar.IS_LEAP_MONTH, iLeapMonth);

        cal.setTimeInMillis(lcal.getTimeInMillis());

        String year  = String.valueOf(cal.get(Calendar.YEAR        )    );
        String month = String.valueOf(cal.get(Calendar.MONTH       ) + 1);
        String day   = String.valueOf(cal.get(Calendar.DAY_OF_MONTH)    );

        String pad4Str = "0000";
        String pad2Str = "00";

        String retYear  = (pad4Str + year ).substring(year .length());
        String retMonth = (pad2Str + month).substring(month.length());
        String retDay   = (pad2Str + day  ).substring(day  .length());

        return retYear+retMonth+retDay;
    }
    /** 입력한 양력날짜가 윤달을 포함한지 여부 */
    public static int getLeap(Date date) {
        Calendar cal;
        ChineseCalendar lcal ;

        cal = Calendar.getInstance();
        cal.setTime(date);
        lcal = new ChineseCalendar();

        lcal.setTimeInMillis(cal.getTimeInMillis());
        return lcal.get(ChineseCalendar.IS_LEAP_MONTH);
    }

    /**
     * 입력된 일자 문자열을 확인하고 8자리로 리턴
     * @param sDate
     * @return
     */
    private static String validChkDate(String dateStr) {
        String _dateStr = dateStr;

        if (dateStr == null || !(dateStr.trim().length() == 8 || dateStr.trim().length() == 10)) {
            throw new IllegalArgumentException("Invalid date format: " + dateStr);
        }
        if (dateStr.length() == 10) {
            _dateStr = dateStr.replace("-","");
        }
        return _dateStr;
    }
	
	public static void getFirstWeekDay() {
		Calendar calendar = Calendar.getInstance();
		int mm = calendar.get(Calendar.DAY_OF_WEEK) - 1;
		Calendar ddd = (Calendar) calendar.clone();
		ddd.add(Calendar.DAY_OF_MONTH, mm * -1); // 해당 주의 시작날짜
		Calendar create_day = (Calendar) ddd.clone();
		create_day.getTime();
	}
	
	/**
     * 음력 공휴일을 체크한다
     * @param dt : 체크할 날짜 ( 날짜포맷 : yyyy-MM-dd)
     * @return
     */
    @SuppressWarnings("unused")
	private static boolean isLunar(String dt) throws Exception{
       boolean result = false ;    
         
        // 음력 공휴일 목록
        String[] arrLunar = {
                 
                "01-01"     // 설날 2 
                , "01-02"   // 설날 3
                , "04-08"   // 부처님 오신날
                , "08-14"   // 추석 1
                , "08-15"   // 추석 2
                , "08-16"   // 추석 3
                , "12-31"   // 설날 1
        } ;
         
        ChineseCalendar chinaCal = new ChineseCalendar();
        Calendar cal = Calendar.getInstance() ;
         
        cal.set(Calendar.YEAR, Integer.parseInt(dt.substring(0, 4)));
        cal.set(Calendar.MONTH, Integer.parseInt(dt.substring(5, 7)) - 1);
        cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dt.substring(8,10)));
        chinaCal.setTimeInMillis(cal.getTimeInMillis());
 
        int chinaYY = chinaCal.get(ChineseCalendar.EXTENDED_YEAR) - 2637 ;
        int chinaMM = chinaCal.get(ChineseCalendar.MONTH) + 1;
        int chinaDD = chinaCal.get(ChineseCalendar.DAY_OF_MONTH);
         
        StringBuilder chinaDate = new StringBuilder(5); // 음력날짜
        chinaDate.append(String.format("%02d", chinaMM));
        chinaDate.append('-');
        chinaDate.append(String.format("%02d", chinaDD));
              
        // 음력 공휴일 목록과 변환한 음력날짜가 일치하는지 비교
        for(int i=0; i < arrLunar.length; i++){
            String tmpLunar = arrLunar[i] ;
             
            if(tmpLunar.equals(chinaDate.toString())){
                result = true ;                
            }
        }
         
        return result ;     
    }
    
    /**
     * 달의 시작일과 끝일을 되돌려 준다.
     * @param year
     * @param month
     * @return
     */
	
	private static Calendar getStartDateMonthOnly(int year, int month) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, cal.getActualMinimum(Calendar.HOUR_OF_DAY));
		cal.set(Calendar.MINUTE, cal.getActualMinimum(Calendar.MINUTE));
		cal.set(Calendar.SECOND, cal.getActualMinimum(Calendar.SECOND));
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
		
		return cal;
	}
	private static Calendar getEndDateMonthOnly(Calendar cal) {
		cal.set(Calendar.HOUR_OF_DAY, cal.getActualMaximum(Calendar.HOUR_OF_DAY));
		cal.set(Calendar.MINUTE, cal.getActualMaximum(Calendar.MINUTE));
		cal.set(Calendar.SECOND, cal.getActualMaximum(Calendar.SECOND));
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		
		return cal;
	}
	public static Date getStartDatePreviousMonth() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		return getStartDateMonthOnly(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)).getTime();
	}
	public static Date getStartDateCurrentMonth() {
		Calendar cal = Calendar.getInstance();
		return getStartDateMonthOnly(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)).getTime();
	}
	public static Date getStartDateNextMonth() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		return getStartDateMonthOnly(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)).getTime();
	}
	public static Date getEndDatePreviousMonth() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		return getEndDateMonthOnly(cal).getTime();
	}
	public static Date getEndDateCurrentMonth() {
		Calendar cal = Calendar.getInstance();
		return getEndDateMonthOnly(cal).getTime();
	}
	public static Date getEndDateNextMonth() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		return getEndDateMonthOnly(cal).getTime();
	}
	public static int getEndDaysOfMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	}
	
	public static boolean isCurrentEndDateOfMonth() {
		return isEndDateOfMonth(null);
	}
	public static boolean isEndDateOfMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		if (date != null) { cal.setTime(date); }
		
		Calendar endDate = getEndDateMonthOnly(cal);
		
		if (endDate.get(Calendar.DAY_OF_MONTH) == cal.get(Calendar.DAY_OF_MONTH)) {
			return true;
		} else {
			return false;
		}
	}

    /**
	 * 달의 시작주의 첫날짜와 달의 끝날이 포함된주의 끝날짜를 되돌려준다.
	 * @param year
	 * @param month
	 * @param dayOfWeek 1 ~ 7 (1 = Sunday, 7 = Saturday)
	 * @return startAndEndDayOfMonth - int[] ([0] = start, [1] = end)
	 */
    public static Date[] getStartAndEndOfMonthDynamic(int year, int month) {
    	return getStartAndEndOfMonthDynamic(year, month, Calendar.SUNDAY);
    }
	private static Date[] getStartAndEndOfMonthDynamic(int year, int month, int startDayOfWeek) {
		month--;// 자바에서는 0 부터 시작
		Calendar cal;
		
		cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(year, month - 1, cal.getActualMaximum(Calendar.DATE));
		cal.set(year, month - 1, cal.getActualMaximum(Calendar.DATE) - cal.get(Calendar.DAY_OF_WEEK) + startDayOfWeek);
		Date startDate = cal.getTime();
		
		cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(year, month + 1, 1);
		cal.set(year, month + 1, 7 - cal.get(Calendar.DAY_OF_WEEK) + startDayOfWeek);
		Date endDate = cal.getTime();
		
		return new Date[] {startDate, endDate};
	}
	
	/**
	 * 달의 시작주의 첫날짜와 달의 끝날이 포함된주의 끝날짜를 되돌려준다.(단 끝주는 6번째주를 무조건 되돌려준다. Windows의 시스템의 달력 참조)
	 * @param year
	 * @param month
	 * @param offset default is sunday. ex) if you want to set first-day-of-week, put 1.
	 * @return startAndEndDayOfMonth - int[] ([0] = start, [1] = end)
	 */
	public static Date[] getStartAndEndOfMonthStatic(int year, int month) {
		return getStartAndEndOfMonthStatic(year, month, Calendar.SUNDAY);
	}
	private static Date[] getStartAndEndOfMonthStatic(int year, int month, int startDayOfWeek) {
		month--;// 자바에서는 0 부터 시작
		Calendar cal;
		
		cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(year, month - 1, cal.getActualMaximum(Calendar.DATE));
		cal.set(year, month - 1, cal.getActualMaximum(Calendar.DATE) - cal.get(Calendar.DAY_OF_WEEK) + startDayOfWeek);
		Date startDate = cal.getTime();
		
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.add(Calendar.DATE, 41);
		
		Date endDate = cal.getTime();
		
		return new Date[] {startDate, endDate};
	}
	
	public static boolean equals(Date d1, Date d2) {
		if (d1 == null && d2 == null) { return true; }
		if (d1 == null || d2 == null) { return false; }
		if (d1.compareTo(d2) == 0) { return true; }
		return false;
	}
	
	private static Date parseDate(String dateString, String dateFromat){
		if(dateString == null){
			return null;
		}

		SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
		sdf.setLenient(false);

		try {
			//if not valid, it will throw ParseException
			Date date = sdf.parse(dateString);
//			System.out.println(date);
			return date;
		} catch (ParseException e) {
			//e.printStackTrace();
			return null;
		}
	}
	public static Date parseDate(String dateString) {
		for (String dateFormat : formats) {
			Date date = parseDate(dateString, dateFormat);
			if (date != null) { return date; }
		}
		return null;
	}
	
//	public static void main(String[] args) {
//	    StringBuilder chinaDate = new StringBuilder(16); // 음력날짜
//        chinaDate.append(String.format("%02d", 9));
//        chinaDate.append('-');
//        chinaDate.append(String.format("%02d", 22));
//        System.out.println(chinaDate.toString());
//		System.out.println(String.format("%02d", 0));
//		System.out.println(getEndDatePreviousMonth());
//		System.out.println(getEndDateCurrentMonth());
//		System.out.println(getEndDateNextMonth());
//	}
}
