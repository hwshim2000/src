package net.forecs.coconut.common.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.Text;

/**
 * @Project    : coconut_dev
 * @Package    : net.forecs.coconut.common.util
 * @FileName   : CreateLetterIndexUtil.java
 * @Date       : 2015. 5. 8.
 * @Author     : yonkyoung.park@forecs.net
 * @Version    :
 * @Histories  :
 * @Description: split words for indexing
 */
public class CreateLetterIndexUtil {

	private static final int TOKENIZE_LETTER_LENGTH = 10;
	private static final int MAX_INDEX_TEXT_LENGTH = 1000000; // 1024*1024 = 1048576
	/**
	 * 참고 : MAX_INDEX_TEXT_LENGTH를 1048576로 안하는 이유중의 하나는 Index document의 총 사이즈가 2M이다.
	 * description, wiki 외에도 기타 메타 정보를 위한 여유 공간이 필요하기 때문에 1000000으로 조정함.
	 */
	
	public static String createLetterIndex(String contents) {
		return createLetterIndex(contents, 1);
	}
	public static String createLetterIndex(String contents, int index) {
		if (StringUtils.isBlank(contents)) { return ""; }
		if (contents.length() > MAX_INDEX_TEXT_LENGTH) return contents.substring(0, MAX_INDEX_TEXT_LENGTH);
		
		List<String> splitWordList = new ArrayList<String>();
		List<String> lettersIndexList = new ArrayList<String>();
		
		contents = contents.trim();
		splitWordList = Arrays.asList(contents.split(" "));		
		int indexStringLength = 0;
		for(String word : splitWordList) {
			char[] letter = word.toCharArray();
			
			//-->
			// TODO : 나중에 실제 tokenize 방식에 대해서 더 고민이 필요하다.
			int maxLength = letter.length;
			if (maxLength > TOKENIZE_LETTER_LENGTH) {
				lettersIndexList.add(word);
				indexStringLength += (word.length()+1);
				maxLength = TOKENIZE_LETTER_LENGTH;
			}
			//<--
			
			for (int i = index; i <= maxLength; i++) {
				String letters = new String(letter, 0, i);
				if (!lettersIndexList.contains(letters)) {
					lettersIndexList.add(letters);
					indexStringLength += (letters.length()+1);
				}
			}
			
			if (indexStringLength > MAX_INDEX_TEXT_LENGTH) break;
		}
		
		String resultStr = StringUtils.join(lettersIndexList, " ");
		// 1024*1024(1048576) limit
		if (resultStr.length() > MAX_INDEX_TEXT_LENGTH) { resultStr = resultStr.substring(0, MAX_INDEX_TEXT_LENGTH); }
		return resultStr;
	}
	
	public static String createLetterIndex(Set<String> splitWordList) {
		return createLetterIndex(splitWordList, 2);
	}
	public static String createLetterIndex(Set<String> splitWordList, int index) {
		if (splitWordList == null || splitWordList.size() == 0) { return ""; }
		
		List<String> lettersIndexList = new ArrayList<String>();
		
		for(String word : splitWordList) {
			char[] letter = word.toCharArray();
			
			for (int i=index; i <= letter.length; i++) {
				String letters = new String(letter, 0, i);
				if (!lettersIndexList.contains(letters)) {
					lettersIndexList.add(letters);
				}
			}		
		}
		
		return StringUtils.join(lettersIndexList, " ");
	}
	public static Text createLetterIndex(Text text) {
		return createLetterIndex(text, 2);
	}
	public static Text createLetterIndex(Text text, int index) {
		Text newText = null;
		if (text == null || StringUtils.isBlank(text.getValue())) {
			newText = new Text("");
		} else {
			newText = new Text(createLetterIndex(HtmlUtil.removeHTMLTags(text.getValue()), index));
		}
		
		return newText;
	}
}
