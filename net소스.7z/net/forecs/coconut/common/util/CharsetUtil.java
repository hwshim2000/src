package net.forecs.coconut.common.util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.UnsupportedCharsetException;
import java.util.HashSet;
import java.util.Set;

import net.forecs.coconut.common.CommonProperty;

import org.apache.commons.lang.StringUtils;

import com.ibm.icu.text.CharsetDetector;
import com.ibm.icu.text.CharsetMatch;


public final class CharsetUtil {
	private static int MATCH_CONFIDENCE = 70;
	private static String DEFAULT_MATCH_CHARSET = CommonProperty.EUC_KR;
	private static Set<String> MATCH_CHARSETS = new HashSet<String>();
	static {
		MATCH_CHARSETS.add(CommonProperty.EUC_KR);
		MATCH_CHARSETS.add(CommonProperty.UTF_8);
	}
	
	public static String detectCharset(InputStream is) throws IOException, UnsupportedCharsetException {
		String charset = null;
		try {
			CharsetDetector detector = new CharsetDetector();
			detector.setText(is instanceof BufferedInputStream ? is	: new BufferedInputStream(is));
			detector.enableInputFilter(true);
			
			charset = detect(detector);
		} catch (IOException ex) {
			throw ex;
		} catch (UnsupportedCharsetException ex) {
			throw ex;
		}
		
		return charset;
	}
	public static String detectCharset(InputStream is, String defaulCharset) {
		String charset = defaulCharset;
		try {
			charset = detectCharset(is);
		} catch (Exception ex) {}
		
		return charset;
	}
	
	public static String detectCharsetFormHtml(InputStream is) throws IOException, UnsupportedCharsetException {
		String charset = null;
		try {
			CharsetDetector detector = new CharsetDetector();
			detector.setText(is instanceof BufferedInputStream ? is	: new BufferedInputStream(is));
			detector.enableInputFilter(true);
			
			charset = detectForHtml(detector);
		} catch (IOException ex) {
			throw ex;
		} catch (UnsupportedCharsetException ex) {
			throw ex;
		}
		
		return charset;
	}
	
	public static String detectCharset(byte[] buffer) throws UnsupportedCharsetException {
		String charset = null;
		try {
			CharsetDetector detector = new CharsetDetector();
			detector.setText(buffer);
			detector.enableInputFilter(true);

			charset = detect(detector);
		} catch (UnsupportedCharsetException ex) {
			throw ex;
		}
		
		return charset;
	}
	
	private static String detectForHtml(CharsetDetector detector) throws UnsupportedCharsetException {
		String charset = null;
		try {
			detector.enableInputFilter(true);
			CharsetMatch match = detector.detect();
			//LOG.warning("[MATCH CONFIDENCE] : " + match.getConfidence() + " : " + match.getName());
			if (match != null && match.getConfidence() > MATCH_CONFIDENCE) {
				try {
					charset = match.getName();
				} catch (UnsupportedCharsetException ex) {
					throw ex;
				}
			}
			
			if (StringUtils.isEmpty(charset)) {
				charset = DEFAULT_MATCH_CHARSET; 
				CharsetMatch[] matchs = detector.detectAll();
				for (CharsetMatch mch : matchs) {
					if (MATCH_CHARSETS.contains(mch.getName().toUpperCase())) {
//						System.out.println("[MATCHS CONFIDENCE] : " + mch.getConfidence() + " : " + mch.getName());
						charset = mch.getName().toUpperCase(); 
						break;
					}
				}
			}
		} catch (UnsupportedCharsetException ex) {
			throw ex;
		}
		
		return charset;
	}
	
	private static String detect(CharsetDetector detector) throws UnsupportedCharsetException {
		String charset = null;
		try {
			detector.enableInputFilter(true);
			CharsetMatch match = detector.detect();
			//LOG.warning("[MATCH CONFIDENCE] : " + match.getConfidence() + " : " + match.getName());
			if (match != null && match.getConfidence() > MATCH_CONFIDENCE) {
				try {
					charset = match.getName();
				} catch (UnsupportedCharsetException ex) {
					throw ex;
				}
			}
			
			if (StringUtils.isEmpty(charset)) {
				Set<String> charsetNames = new HashSet<String>();
				CharsetMatch[] matchs = detector.detectAll();
				for (CharsetMatch mch : matchs) {
					charsetNames.add(mch.getName().toUpperCase());
					//LOG.warning("[MATCHS CONFIDENCE] : " + mch.getConfidence() + " : " + mch.getName());
				}
				
				if (charsetNames.contains(DEFAULT_MATCH_CHARSET)) { charset = DEFAULT_MATCH_CHARSET; }
			}
		} catch (UnsupportedCharsetException ex) {
			throw ex;
		}
		
		return charset;
	}
	
	public static String detectCharsetMaxConfidence(InputStream is) throws IOException, UnsupportedCharsetException {
		try {
			CharsetDetector detector = new CharsetDetector();
			detector.setText(is instanceof BufferedInputStream ? is	: new BufferedInputStream(is));
			detector.enableInputFilter(true);
			CharsetMatch match = detector.detect();
			//LOG.warning("[MATCH CONFIDENCE] : " + match.getConfidence() + " : " + match.getName());
			return match.getName();
		} catch (IOException ex) {
			throw ex;
		} catch (UnsupportedCharsetException ex) {
			throw ex;
		}
	}
	
	public static String detectCharsetMaxConfidence(byte[] buffer) throws UnsupportedCharsetException {
		try {
			CharsetDetector detector = new CharsetDetector();
			detector.setText(buffer);
			detector.enableInputFilter(true);
			CharsetMatch match = detector.detect();
			//LOG.warning("[MATCH CONFIDENCE] : " + match.getConfidence() + " : " + match.getName());
			return match.getName();
		} catch (UnsupportedCharsetException ex) {
			throw ex;
		}
	}
	
	public static String getEncoding(String str) {
		try {
			if (StringUtils.isBlank(str)) { return CommonProperty.UTF_8; }
			if (str.matches(".*[ㄱ-ㅎㅏ-ㅣ가-힣]+.*")) {	return CommonProperty.MS949; }
			return CommonProperty.UTF_8;
		} catch (Exception ex) {
			return CommonProperty.UTF_8;
		}
	}
	
//	public static String detectCharset(String contents) throws UnsupportedCharsetException {
//		return detectCharset(contents.getBytes());
//	}
	
	public static String[] charsetNames() {
		String[] charsetNames = CharsetDetector.getAllDetectableCharsets();
		return charsetNames;
	}
}
