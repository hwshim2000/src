package net.forecs.coconut.common.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import net.forecs.coconut.common.CommonProperty;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.Text;

public class HtmlUtil {
	static final int ELLIPSIS_LENGTH = 120;
	
	public static String escape(String s) {
	    StringBuilder builder = new StringBuilder();
	    boolean previousWasASpace = false;
	    for( char c : s.toCharArray() ) {
	        if( c == ' ' ) {
	            if( previousWasASpace ) {
	                builder.append("&nbsp;");
	                previousWasASpace = false;
	                continue;
	            }
	            previousWasASpace = true;
	        } else {
	            previousWasASpace = false;
	        }
	        switch(c) {
	            case '<': builder.append("&lt;"); break;
	            case '>': builder.append("&gt;"); break;
	            case '&': builder.append("&amp;"); break;
	            case '"': builder.append("&quot;"); break;
	            case '\n': builder.append("<br>"); break;
	            // We need Tab support here, because we print StackTraces as HTML
	            case '\t': builder.append("&nbsp; &nbsp; &nbsp;"); break;  
	            default:
	                if( c < 128 ) {
	                    builder.append(c);
	                } else {
	                    builder.append("&#").append((int)c).append(";");
	                }    
	        }
	    }
	    return builder.toString();
	}
	
	public static String encodeURIComponent(String s) {
		String result = null;

		try {
			result = URLEncoder.encode(s, CommonProperty.UTF_8).replaceAll("\\+", "%20")
					.replaceAll("\\%21", "!").replaceAll("\\%27", "'")
					.replaceAll("\\%28", "(").replaceAll("\\%29", ")")
					.replaceAll("\\%7E", "~");
		}

		// This exception should never occur.
		catch (UnsupportedEncodingException e) {
			result = s;
		}

		return result;
	}
	
	public static String removeHTMLTags(String html) {
		if (StringUtils.isBlank(html)) { return ""; }
	    return html.replaceAll("\\<[^\\>]*\\>", "");
	}
	public static String removeHTMLTags(Text text) {
		if (text == null) { return ""; }
		return removeHTMLTags(text.getValue());
	}
	public static String removeHTMLTags(Text text, int trimLength) {
		String str = removeHTMLTags(text);
		if (str.length() <= trimLength) { return str; }
		
		return str.substring(0, trimLength)+"...";
	}
	
	public static String ellipsis(Text text) {
		return removeHTMLTags(text, ELLIPSIS_LENGTH);
	}
	public static String ellipsis(Text text, int ellipsisLength) {
		return removeHTMLTags(text, ellipsisLength);
	}
}
