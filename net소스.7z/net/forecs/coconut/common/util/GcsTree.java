package net.forecs.coconut.common.util;

import java.util.ArrayList;
import java.util.StringTokenizer;

import lombok.Getter;
import lombok.Setter;

import org.apache.commons.lang.StringUtils;

import com.google.api.services.storage.model.StorageObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GcsTree {
	private String bucket;
	private Node root;
	
	public class Node {
		@Getter @Setter
		private String fileName;	// name only
		@Getter @Setter
		private String filePath;	// path + name, obj의 name과 동일
		@Getter @Setter
		private ArrayList<Node> children;
		@Getter @Setter
		private StorageObject obj;
		@Getter @Setter
		private int depth;
		@Getter @Setter
		private String nextPageToken;

		public Node(String fileName, int depth, StorageObject obj) {
			this.fileName = fileName;
			this.depth = depth;
			this.obj = obj;
			if (obj != null) { this.filePath = obj.getName(); }
			children = new ArrayList<Node>();
		}

		public Node getChild(String data) {
			for (Node n : children) {
				if (n.fileName.equals(data)) { return n; }
			}
			return null;
		}
	}

	
	public Node getNode() {
		return this.root;
	}
	
	public Node findNodeByPath(String filePath) {
		return findNodeByPath(this.root, filePath);
	}
	
	private Node findNodeByPath(Node n, String filePath) {
		if (n==null) { return null; }
		if (StringUtils.equals(filePath, n.getFilePath())) { return n; }
		for (Node c : n.children) {
			Node r = findNodeByPath(c, filePath);
			if (r != null) { return r; }
		}
		return null;
	}
	public Node findNodeByName(String filePath) {
		return findNodeByName(this.root, filePath);
	}
	private Node findNodeByName(Node n, String fileName) {
		if (n==null) { return null; }
		if (StringUtils.equals(fileName, n.getFileName())) { return n; }
		for (Node c : n.children) {
			Node r = findNodeByName(c, fileName);
			if (r != null) { return r; }
		}
		return null;
	}
	
	public GcsTree(String bucket) {
		this(bucket, null);
	}
	public GcsTree(String bucket, Object obj) {
		if (StringUtils.isBlank(bucket)) {
			this.bucket = "";
		} else {
			this.bucket = bucket;
		}

		root = new Node(this.bucket, 0, null);
	}

	public boolean isEmpty() {
		return root == null;
	}

	public void add(String fileName, StorageObject obj) {
		Node current = root;
		StringTokenizer fileNames = new StringTokenizer(fileName, "/");
		while (fileNames.hasMoreElements()) {
			fileName = (String) fileNames.nextElement();
			Node child = current.getChild(fileName);
			if (child == null) {
				current.children.add(new Node(fileName, current.getDepth()+1, obj));
				child = current.getChild(fileName);
			}
			current = child;
		}
	}

	public void print() {
		print(this.root);
	}

	public static void print(Node n) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		System.out.println(gson.toJson(n));
	}
}