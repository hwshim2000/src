package net.forecs.coconut.common.util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.common.Base;

public class ClassUtil {
	private static final String TYPE_NAME_PREFIX = "class ";
	private static final String kindBasePackage = "net.forecs.coconut.entity";
	private static final String indexBasePackage = "net.forecs.coconut.search.index";
	
	public static String getSimpleClassName(Type type) throws Exception {
		return getClass(type).getSimpleName();
	}
	
	public static String getSimpleSuperClassName(Type type) throws Exception {
		return getClass(type).getSuperclass().getSimpleName();
	}
	
	public static String getClassName(Type type) {
	    if (type==null) {
	        return "";
	    }
	    String className = type.toString();
	    if (className.startsWith(TYPE_NAME_PREFIX)) {
	        className = className.substring(TYPE_NAME_PREFIX.length());
	    }
	    return className;
	}

	public static Class<?> getClass(Type type) 
	            throws ClassNotFoundException {
	    String className = getClassName(type);
	    if (className==null || className.isEmpty()) {
	        return null;
	    }
	    return Class.forName(className);
	}

	public static Object newInstance(Type type) 
	        throws ClassNotFoundException, InstantiationException, IllegalAccessException {
	    Class<?> clazz = getClass(type);
	    if (clazz==null) {
	        return null;
	    }
	    return clazz.newInstance();
	}
	
	public static <T extends Base> Class<T> findKIndClass(String kind) {
		return findClass(kind, kindBasePackage);
	}
	public static Class<?> findIndexClass(String kind) {
		return findClass(kind, indexBasePackage);
	}
	@SuppressWarnings("unchecked")
	public static <T extends Base> Class<T> findClass(String kind, String packageName) {
		final Package[] packages = Package.getPackages();
	    final String className = kind;
	    Class<T> c = null;
	    
	    for (final Package p : packages) {
	        final String pack = p.getName();
	        if (pack.indexOf(packageName) !=0 ) continue;
	        
	        final String tentative = pack + "." + className;
	        try {
	            c = (Class<T>)Class.forName(tentative);
	        } catch (final ClassNotFoundException e) {
	            continue;
	        }
//	        LOG.info("Find class : " + tentative);
	        break;
	    }
	    return c;
	}
	public static List<Class<?>> findKindClasses(String namespace) {
		List<Class<?>> classList = new ArrayList<Class<?>>();
		
		List<String> kindList = CommonService.listKinds(namespace);
		
		for (String kind : kindList) {
			Class<?> kindClass = findKIndClass(kind);
			if (kindClass != null) { classList.add(kindClass); }
		}
		
		return classList;
	}
	
	public static Class<?>[] getClasses(String packageName)
			throws ClassNotFoundException, IOException {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		assert classLoader != null;
		String path = packageName.replace('.', '/');
		Enumeration<URL> resources = classLoader.getResources(path);
		List<File> dirs = new ArrayList<File>();
		while (resources.hasMoreElements()) {
			URL resource = resources.nextElement();
			dirs.add(new File(resource.getFile()));
		}
		ArrayList<Class<?>> classes = new ArrayList<Class<?>>();
		for (File directory : dirs) {
			List<Class<?>> classList = findClasses(directory, packageName);
			if (classList != null) {
				for (Class<?> cls : classList) {
					if (cls.getSuperclass() == null
							|| (!"net.forecs.coconut.entity.common.Base".equals(cls.getSuperclass().getName())
									&& !"net.forecs.coconut.entity.common.Common".equals(cls.getSuperclass().getName()))) {
						continue;
					}
				}
			}
			classes.addAll(findClasses(directory, packageName));
		}
		return classes.toArray(new Class[classes.size()]);
	}

	private static List<Class<?>> findClasses(File directory, String packageName)
			throws ClassNotFoundException {
		List<Class<?>> classes = new ArrayList<Class<?>>();
		if (!directory.exists()) {
			return classes;
		}
		File[] files = directory.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				assert !file.getName().contains(".");
				classes.addAll(findClasses(file, packageName + "." + file.getName()));
			} else if (file.getName().endsWith(".class")) {
				classes.add(Class.forName(packageName + '.'	+ file.getName().substring(0, file.getName().length() - 6)));
			}
		}
		return classes;
	}
/*
	public static void main(String[] args) throws Exception {
		getClasses("net.forecs.coconut.entity");
	}*/
}
