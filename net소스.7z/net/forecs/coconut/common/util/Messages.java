package net.forecs.coconut.common.util;

import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;

import net.forecs.coconut.common.code.ActivityKind;
import net.forecs.coconut.common.code.ActivityType;
import net.forecs.coconut.endpoint.setting.UserSettingService;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.setting.UserSetting;

import org.apache.commons.lang.StringUtils;

public class Messages {
	public final static String NOTIFICATION_COMMON = "NOTIFICATION_COMMON";
	public final static String NOTIFICATION_SUBJECT = "NOTIFICATION_SUBJECT";
	public final static String SENDRANDOMPASSWORD_SUBJECT = "SENDRANDOMPASSWORD_SUBJECT";
	public final static String SENDLOSTIDEMAIL_SUBJECT = "SENDLOSTIDEMAIL_SUBJECT";
	public final static String RESETPASSWORD_SUBJECT = "RESETPASSWORD_SUBJECT";
	public final static String COMPLETEREGISTRATION_SUBJECT = "COMPLETEREGISTRATION_SUBJECT";
	
	private final static String DEFAULT_FILENAME_PREFIX = "message";
	
	private String START_WRAPPED_CHAR = "『";
	private String END_WRAPPED_CHAR = "』";
	
//	
//	private final static String START_WRAPPED_CHAR = "「";
//	private final static String END_WRAPPED_CHAR = "」";
//	private final static String START_WRAPPED_CHAR = "【";
//	private final static String END_WRAPPED_CHAR = "】";
//	private final static String START_WRAPPED_CHAR = "《";
//	private final static String END_WRAPPED_CHAR = "》";
//	private final static String START_WRAPPED_CHAR = "〃";
//	private final static String END_WRAPPED_CHAR = "〃";
			
	/** 메시지 프로퍼티 파일 명칭 : '.message' */
    //public static final String MESSAGE_FILENAME = "message";
	
    /** 번들명칭 */
    private final String name;
    /** 로케일 */
    private Locale locale;
    /** ResourceBundle */
    private transient ResourceBundle bundle;
    //private transient ResourceBundle namedBundle;

    
    private void setWrappedChar(WRAPPED_CHAR_TYPE type) {
    	switch(type) {
	    	case EMAIL :
	    		START_WRAPPED_CHAR = "『";
	    		END_WRAPPED_CHAR = "』";
	    		break;
	    	case MOBILE :
	    		START_WRAPPED_CHAR = "『";
	    		END_WRAPPED_CHAR = "』";
	    		break;
	    	case WEB :
	    		START_WRAPPED_CHAR = "<b>";
	    		END_WRAPPED_CHAR = "</b>";
	    		break;
	    	case DEFAULT :
    		default :
	    		START_WRAPPED_CHAR = "『";
	    		END_WRAPPED_CHAR = "』";
	    		break;
    	}
    }
    /**
     * Constructor.
     * 번들명칭은 이 클래스 또는 이를 상속한 객체의 패키지명.message 이 된다.
     * 해당 패키지내에 message.properties 및 Locale 별 메시지 파일이 있어야 한다.
     */
    @SuppressWarnings("unused")
    private Messages() {
        //name = this.getClass().getPackage().getName() + "." + MESSAGE_FILENAME;
    	name = DEFAULT_FILENAME_PREFIX;
        //locale = Locale.getDefault();
        locale = LocaleUtil.DEFAULT_LOCALE;
        initBundle();
        
        setWrappedChar(WRAPPED_CHAR_TYPE.DEFAULT);
    }

    /**
     * 이름 지정 Constructor.
     * @param name 이름.
     */
    @SuppressWarnings("unused")
	private Messages(String name) {
        this.name = name;
        //locale = Locale.getDefault();
        locale = LocaleUtil.DEFAULT_LOCALE;
        initBundle();
        
        setWrappedChar(WRAPPED_CHAR_TYPE.DEFAULT);
    }
    
    /**
     * Locale 지정 Constructor.
     * 번들명칭은 이 클래스 또는 이를 상속한 객체의 패키지명.message 에 해당한다.  
     * 해당 패키지내에 message.properties 및 Locale 별 메시지 파일이 있어야 한다.
     * @param locale Locale
     */
    @SuppressWarnings("unused")
	private Messages(Locale locale) {
    	if (locale == null) { locale = LocaleUtil.DEFAULT_LOCALE; }
        //name = this.getClass().getPackage().getName() + "." + MESSAGE_FILENAME;
    	name = DEFAULT_FILENAME_PREFIX;
        this.locale = locale;
        initBundle();
        
        setWrappedChar(WRAPPED_CHAR_TYPE.DEFAULT);
    }

    public Messages(String name, UserSetting userSetting, WRAPPED_CHAR_TYPE type) {
    	this.name = name;
    	locale = LocaleUtil.getUserLocale(userSetting);
    	initBundle();
    	
    	setWrappedChar(type);
    }
    /**
     * 이름, Locale 지정 Constructor.
     * @param name 이름
     * @param locale Locale
     */
    public Messages(String name, Locale locale) {
        this.name = name;
        this.locale = locale;
        initBundle();
        
        setWrappedChar(WRAPPED_CHAR_TYPE.DEFAULT);
    }
    
    /**
     * 초기화.
     */
    private synchronized void initBundle() {
        if ( bundle == null ) { 
            bundle = ResourceBundle.getBundle("META-INF/messages/"+name, locale);
        }
//        if (namedBundle == null) {
//        	namedBundle = ResourceBundle.getBundle("META-INF/messages/named_"+name, locale);
//        }
    }
    
    /**
     * 명칭 반환.
     * @return 명칭.
     */
    public String getName() {
        return name;
    }
    
    /**
     * Locale 설정
     * @param locale Locale
     */
    public void setLocale(Locale locale) {
        this.locale = locale;
        bundle = null;
        initBundle();
    }
    
    /**
     * Locale 반환.
     * @return Locale
     */
    public Locale getLocale() {
        return locale;
    }
    
    /**
     * ResourceBundle 반환.
     * @return 리소스번들
     */
    public ResourceBundle getResourceBundle() {
        initBundle();
        return bundle;
    }
//    public ResourceBundle getNamedResourceBundle() {
//        initBundle();
//        return namedBundle;
//    }
    
    private String getKey(ActivityKind activityKind, ActivityType activityType) {
    	if (activityType != null) {
    		return String.format("%s_%s", activityKind, activityType);
    	} else {
    		return String.format("%s_DEFAULT", activityKind);
    	}
    }
    
	@SuppressWarnings("unused")
	private static String getMessage(Activities activity, UserSetting userSetting) {
    	Messages msg = new Messages(DEFAULT_FILENAME_PREFIX, userSetting, WRAPPED_CHAR_TYPE.WEB);
    	return msg.getMessage(activity);
    }
   
    
    public String getMessage(Activities activity) {
    	if (activity.getMsgParams() != null && activity.getMsgParams().length > 0) {
    		return getMessage(getKey(activity.getActivityKind(), activity.getActivityType()), activity.getMsgParams());
    	} else {
    		return activity.getMessage();
    	}
    }
    /**
     * 메시지 반환.
     * @param key 키
     * @return 메시지
     */
    public String getSourceMessage(String key) {
        initBundle();
        return bundle.getString(key);
    }
//    public String getNamedSourceMessage(String key) {
//        initBundle();
//        return namedBundle.getString(key);
//    }
  
    /**
     * 메시지 반환.
     * @param key 키
     * @param arg 아규먼트
     * @return 메시지
     */
    public String getMessage(String key, Object arg) {
        return getMessage(key,new Object[]{arg});
    }

    /**
     * 메시지 반환.
     * @param key 키
     * @param arg1 아규먼트
     * @param arg2 아큐먼트
     * @return 메시지
     */
//    public String getMessage(String key, Object arg1, Object arg2) {
//        return getMessage(key,new Object[]{arg1,arg2});
//    }

    /**
     * 메시지 반환.
     * @param key 키
     * @param arg1 아규먼트
     * @param arg2 아규먼트
     * @param arg3 아규먼트
     * @return 메시지
     */
//    public String getMessage(String key, Object arg1, Object arg2, Object arg3) {
//        return getMessage(key,new Object[]{arg1,arg2,arg3});
//    }

    /**
     * 메시지 반환.
     * @param key 키
     * @param arg1 아규먼트
     * @param arg2 아규먼트
     * @param arg3 아규먼트
     * @param arg4 아규먼트
     * @return 메시지
     */
//    public String getMessage(String key, Object arg1, Object arg2, Object arg3, Object arg4) {
//        return getMessage(key,new Object[]{arg1,arg2,arg3,arg4});
//    }
    
    /**
     * 메시지 반환.
     * @param key 키
     * @param args 아규먼트
     * @return 메시지
     */
    public String getMessage(String key, Object[] args) {
    	Object[] wrappedArgs = new Object[args.length];
    	for (int i=0; i < args.length; i++) {
    		wrappedArgs[i] = START_WRAPPED_CHAR + args[i] + END_WRAPPED_CHAR;
    	}
        return MessageFormat.format(getSourceMessage(key), wrappedArgs);
    }
    public String getMessage(String key, Object[] args, Object defaultValue) {
    	return getMessage(key, args, 5, "");
    }
    public String getMessage(String key, Object[] args, int initArgsLength, Object defaultValue) {
    	if (initArgsLength <= args.length) {
    		return getMessage(key, args);
    	} else {
	    	Object[] newArgs = new Object[initArgsLength];
	    	for(int i=0; i < initArgsLength; i++) {
	    		if (i < args.length ) { newArgs[i] = args[i]; }
	    		else { newArgs[i] = defaultValue; }
	    	}
	        return getMessage(key, newArgs);
    	}
    }
    
    /**
     * 키목록 반환.
     * @return 키목록
     */
    public Enumeration<String> getKeys() {
        return bundle.getKeys();
    }
//    public Enumeration<String> getNamedKeys() {
//        return namedBundle.getKeys();
//    }
    
	public static Messages localeMessages(String userId, WRAPPED_CHAR_TYPE wcType) {
		UserSetting userSetting = null;
		if (StringUtils.isNotBlank(userId)) {
			userSetting = UserSettingService.getUserLocaleSetting(userId);
		}
		return localeMessages(userSetting, wcType);
	}
	public static Messages localeMessages(UserSetting userSetting, WRAPPED_CHAR_TYPE wcType) {
		return new Messages(DEFAULT_FILENAME_PREFIX, userSetting, wcType);
	}
/*	
	public static void main(String[] args) {
		try {
			String jsonStr = "{\"general\":{\"language\":{\"code\":\"zh-cn\",\"title\":\"Korean\"},\"defaultBoard\":{\"type\":\"lastBoard\",\"boardId\":\"\",\"title\":\"\"}},\"board\":{\"fixMember\":true,\"fixCalendar\":false,\"showMemberBirthday\":false,\"showKoreanHoliday\":false},\"calendar\":{\"showKoreanHoliday\":true,\"showMemberBirthday\":true},\"chatting\":{\"showBadge\":true,\"font\":{\"type\":\"Arial Black\",\"size\":10,\"color\":\"black\"}},\"notification\":{\"web\":{\"recieve\":\"Y\",\"schedule\":{\"type\":\"event\",\"title\":\"건별\"}},\"email\":{\"recieve\":\"Y\",\"schedule\":{\"type\":\"HOUR\",\"title\":\"시간별\"}}}}";
			
			Locale locale = LocaleUtil.parseLocale(jsonStr);
			//locale = Locale.TAIWAN;

//			LOG.warning(locale.getDisplayCountry());
//			LOG.warning(locale.getCountry());
//			LOG.warning(locale.getDisplayLanguage());
//			LOG.warning(locale.getDisplayName());
//			LOG.warning(locale.getDisplayScript());
//			LOG.warning(locale.getLanguage());
//			LOG.warning(locale.getScript());
//			LOG.warning(MessageFormat.format("LOCALE : {0}", locale));
//			LOG.warning(locale.toString());
			
			Messages message = new Messages(locale);
			Object[] msg = new Object[] { "a", 13245, new Date(), 123 };
//			LOG.warning(message.getMessage("TASKS_ADDED", msg));
			
//			JsonNode jn = om.readTree(jsonStr);
//			LOG.warning(jn.findValue("code").textValue());
//			LOG.warning(jn.findPath("code"));
//			LOG.warning(jn.get("general").get("language").get("code")
//					.textValue());
		} catch (Exception ex) {
		}
	}
	*/

	public enum WRAPPED_CHAR_TYPE {
		DEFAULT,
		WEB,
		MOBILE,
		EMAIL
	}
}
