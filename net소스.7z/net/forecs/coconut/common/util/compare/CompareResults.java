package net.forecs.coconut.common.util.compare;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.compare.DiffMatchPatch.Diff;
import net.forecs.coconut.entity.workspace.TaskHistories;

public class CompareResults {
	@Getter @Setter
	TaskHistories sourceHistory;
	
	@Getter @Setter
	TaskHistories targetHistory;
	
	@Getter @Setter
	String sourceText;
	@Getter @Setter
	String targetText;
	@Getter @Setter
	String bothText;
	
	@Getter @Setter
	String sourceHtml;
	@Getter @Setter
	String targetHtml;
	@Getter @Setter
	String bothHtml;
	
	@Getter @Setter
	List<Diff> bothDiffList;
	@Getter @Setter
	List<Diff> sourceDiffList;
	@Getter @Setter
	List<Diff> targetDiffList;
}
