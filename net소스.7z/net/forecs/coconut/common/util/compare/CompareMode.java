package net.forecs.coconut.common.util.compare;

public enum CompareMode {
	SEMANTIC,
	EFFICIENCY,
	NONE
}
