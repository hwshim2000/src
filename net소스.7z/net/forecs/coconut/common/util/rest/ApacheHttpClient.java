package net.forecs.coconut.common.util.rest;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.forecs.coconut.common.util.CharsetUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ApacheHttpClient {
	private final static String HEADER_AUTHORIZATION = "Authorization";
//	private final static String HEADER_AUTHORIZATION = "X-ImpTokenHeader";
	private final static int CONNECTION_TIMEOUT = 15*1000;
	
	public static String get(String urlStr, Charset charset, String userAgent) throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		
		try {
			RequestConfig requestConfig = RequestConfig.custom()
			    .setConnectionRequestTimeout(CONNECTION_TIMEOUT)
			    .setConnectTimeout(CONNECTION_TIMEOUT)
			    .setSocketTimeout(CONNECTION_TIMEOUT)
			    .build();
			
			HttpGet getRequest = new HttpGet(urlStr);
//			HttpPost getRequest = new HttpPost(urlStr);
			getRequest.setConfig(requestConfig);
			getRequest.addHeader("accept", "*/*");
			getRequest.addHeader("User-Agent", userAgent);
			
//			getRequest.addHeader("Content-Type", "text/html; charset=euc-kr");
//			getRequest.addHeader("Cache-control", "proxy-revalidate");
//			//getRequest.addHeader("Accept-Language", "ko_KR");
//			//getRequest.addHeader("Accept-Encoding", "gzip,deflate,x-compress,x-zip");
//			getRequest.addHeader("Pragma", "no-cache");
//			getRequest.addHeader("Connection", "Keep-Alive");
//			getRequest.addHeader("Keep-Alive", "timeout=5, max=1000");
//			getRequest.addHeader("Access-Control-Allow-Credentials", "true");
//			getRequest.addHeader("X-Content-Type-Options", "nosniff");
//			getRequest.addHeader("Referer", "http://news.mk.co.kr/");
			
			CloseableHttpResponse response = httpClient.execute(getRequest);
			try {
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}
				BufferedInputStream bis = new BufferedInputStream(response.getEntity().getContent());
				if (charset == null) {
					String enc = CharsetUtil.detectCharsetFormHtml(bis);
					if (StringUtils.isNotBlank(enc)) {
						charset = Charset.forName(enc);
					} else {
						charset = StandardCharsets.UTF_8;
					}
				}
				
				BufferedReader br = new BufferedReader(new InputStreamReader(bis, charset));
	
				String output;
				StringBuilder sb = new StringBuilder();	
				while ((output = br.readLine()) != null) {
					sb.append(output);
				}
				
				return sb.toString();
			} finally {
				response.close();
			}
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.close();
		}
	}
	
	public static String get(String urlStr, String token) throws ClientProtocolException, IOException {
		//DefaultHttpClient httpClient = new DefaultHttpClient();
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			HttpGet getRequest = new HttpGet(urlStr);
			getRequest.addHeader("accept", "application/json");
			if (StringUtils.isNotBlank(token)) {
				getRequest.addHeader(HEADER_AUTHORIZATION, token);
			}
			
			CloseableHttpResponse response = httpClient.execute(getRequest);
			try {
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}
	
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(response.getEntity().getContent()), StandardCharsets.UTF_8));
	
				String output;
				StringBuilder sb = new StringBuilder();
				while ((output = br.readLine()) != null) {
					sb.append(output);
				}
				
				return sb.toString();
			} finally {
				response.close();
			}
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.close();
//			httpClient.getConnectionManager().shutdown();
		}
	}

	public static String postToAppengine(String urlStr, String token, Map<String, String> entityMap) throws ClientProtocolException, IOException {
//		DefaultHttpClient httpClient = new DefaultHttpClient();
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			HttpPost postRequest = new HttpPost(urlStr);
			postRequest.addHeader("accept", "application/json");
			if (StringUtils.isNotBlank(token)) {
				postRequest.addHeader(HEADER_AUTHORIZATION, token);
			}

			if (entityMap != null) {
				List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
				for (Map.Entry<String, String> entry : entityMap.entrySet()) {
					urlParameters.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
				}
				postRequest.setEntity(new UrlEncodedFormEntity(urlParameters));
			}

			CloseableHttpResponse response = httpClient.execute(postRequest);
			
			try {
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}
	
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(response.getEntity().getContent()), StandardCharsets.UTF_8));
	
				StringBuilder sb = new StringBuilder();
				String output;
				while ((output = br.readLine()) != null) {
					sb.append(output);
				}
			
				return sb.toString();
			} finally {
				response.close();
			}
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.close();
//			httpClient.getConnectionManager().shutdown();
		}
	}
	
	public static String post(String urlStr, String token, Map<String, Object> entityMap) throws ClientProtocolException, IOException {
//		DefaultHttpClient httpClient = new DefaultHttpClient();
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			HttpPost postRequest = new HttpPost(urlStr);
			postRequest.addHeader("accept", "application/json");
			if (StringUtils.isNotBlank(token)) {
				postRequest.addHeader(HEADER_AUTHORIZATION, token);
			}

			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				String entityStr = om.writeValueAsString(entityMap);
				StringEntity input = new StringEntity(entityStr);
				input.setContentType("application/json");
				postRequest.setEntity(input);
			}

			CloseableHttpResponse response = httpClient.execute(postRequest);
			
			try {
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}
	
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(response.getEntity().getContent()), StandardCharsets.UTF_8));
	
				StringBuilder sb = new StringBuilder();
				String output;
				while ((output = br.readLine()) != null) {
					sb.append(output);
				}
			
				return sb.toString();
			} finally {
				response.close();
			}
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.close();
//			httpClient.getConnectionManager().shutdown();
		}
	}
	
	public static String delete(String urlStr, String token) throws ClientProtocolException, IOException {
		CloseableHttpClient httpClient = HttpClients.createDefault();
//		DefaultHttpClient httpClient = new DefaultHttpClient();
		try {
			HttpDelete deleteRequest = new HttpDelete(urlStr);
			deleteRequest.addHeader("accept", "application/json");
			if (StringUtils.isNotBlank(token)) {
				deleteRequest.addHeader(HEADER_AUTHORIZATION, token);
			}
			
			CloseableHttpResponse response = httpClient.execute(deleteRequest);

			try {
				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ response.getStatusLine().getStatusCode());
				}
	
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(response.getEntity().getContent()), StandardCharsets.UTF_8));
	
				String output;
				StringBuilder sb = new StringBuilder();
				while ((output = br.readLine()) != null) {
					sb.append(output);
				}
	
				return sb.toString();
			} finally {
				response.close();
			}
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.close();
//			httpClient.getConnectionManager().shutdown();
		}
	}
}
