package net.forecs.coconut.common.util.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.ClientProtocolException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class NetClient {
	private final static String HEADER_AUTHORIZATION = "Authorization";
//	private final static String HEADER_AUTHORIZATION = "X-ImpTokenHeader";
	
	public static String get(String path) throws ClientProtocolException, IOException {
	try {
		URL url = new URL(path);
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestMethod("GET");
		
		conn.setRequestProperty("Accept", "application/json");

		if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}

		BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream()), StandardCharsets.UTF_8));

		String output;
		StringBuilder sb = new StringBuilder();
		while ((output = br.readLine()) != null) {
			sb.append(output);
		}

		conn.disconnect();
		
		return sb.toString();
	} catch (MalformedURLException ex) {
		ex.printStackTrace();
		throw ex;
	} catch (IOException ex) {
		ex.printStackTrace();
		throw ex;
	}
}
	public static String get(String urlStr, String token) throws ClientProtocolException, IOException {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("GET");
			if (StringUtils.isNotBlank(token)) {
				conn.setRequestProperty(HEADER_AUTHORIZATION, token);
			}
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream()), StandardCharsets.UTF_8));

			String output;
			StringBuilder sb = new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			conn.disconnect();
			
			return sb.toString();
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

	public static String post(String urlStr, String token, Map<String, Object> entityMap) throws ClientProtocolException, IOException {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			if (StringUtils.isNotBlank(token)) {
				conn.setRequestProperty(HEADER_AUTHORIZATION, token);
			}
			conn.setRequestProperty("Content-Type", "application/json");

			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				String input = om.writeValueAsString(entityMap);
				
				OutputStream os = conn.getOutputStream();
				os.write(input.getBytes(StandardCharsets.UTF_8));
				os.flush();
			}

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream()), StandardCharsets.UTF_8));

			StringBuilder sb = new StringBuilder();
			String output;
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			conn.disconnect();
			
			return sb.toString();
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String delete(String urlStr, String token) throws ClientProtocolException, IOException {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("DELETE");
			if (StringUtils.isNotBlank(token)) {
				conn.setRequestProperty(HEADER_AUTHORIZATION, token);
			}
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream()), StandardCharsets.UTF_8));

			String output;
			StringBuilder sb = new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			conn.disconnect();
			
			return sb.toString();
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
}
