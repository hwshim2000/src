package net.forecs.coconut.common.util.rest;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class JerseyClient {
	private final static String HEADER_AUTHORIZATION = "Authorization";
//	private final static String HEADER_AUTHORIZATION = "X-ImpTokenHeader";
	
	public static String get(String path) throws Exception {
	try {
		Client client = Client.create();
		WebResource webResource = client.resource(path);
		
		ClientResponse response = webResource
				//.accept("application/json")
				.get(ClientResponse.class);

		if (response.getStatus() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
					+ response.getStatus());
		}

		return response.getEntity(String.class);
	} catch (Exception ex) {
		ex.printStackTrace();
		throw ex;
	}
}

	public static String get(String urlStr, String token) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);
			
			ClientResponse response = webResource
					.header(HEADER_AUTHORIZATION, token)
					.accept("application/json")
					.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);

			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

//	public static String post(String urlStr, String token, Map<String, Object> entityMap) throws Exception {
	public static String post(String urlStr, String token, Object entityObj) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);

			String input = null;
			if (entityObj != null) {
				ObjectMapper om = new ObjectMapper();
				om.setSerializationInclusion(Include.NON_NULL);
				input = om.writeValueAsString(entityObj);
			}
			
			ClientResponse response;
			if (input != null) {
				response = webResource
						.header(HEADER_AUTHORIZATION, token)
						.type("application/json")
						.post(ClientResponse.class, input);
			} else {
				response = webResource
						.header(HEADER_AUTHORIZATION, token)
						.type("application/json")
						.post(ClientResponse.class);
			}
			
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String delete(String urlStr, String token) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);
			ClientResponse response = webResource
					.header(HEADER_AUTHORIZATION, token)
					.accept("application/json")
					.delete(ClientResponse.class);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
}
