package net.forecs.coconut.common.util.rest;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import lombok.Getter;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.code.LinkParseOptions;
import net.forecs.coconut.common.util.PathUtils;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.routines.UrlValidator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;
import org.jsoup.select.Elements;

import com.google.appengine.api.images.Image;
import com.google.appengine.api.images.ImagesServiceFactory;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class HtmlParser {
	final static Set<String> URL_TAGS = new HashSet<String>();
	final static Set<String> URL_YOUTUBE_AVS = new HashSet<String>();
	final static List<String> CONTAIN_IMAGE_TYPES = new ArrayList<String>();
	final static Set<String> IGRNORE_IMAGE_CHARS = new HashSet<String>();
	
	static {
		URL_YOUTUBE_AVS.add("og:video");
		URL_YOUTUBE_AVS.add("og:video:url");
		URL_YOUTUBE_AVS.add("og:video:secure_url");
		URL_YOUTUBE_AVS.add("og:audio");
		URL_YOUTUBE_AVS.add("og:audio:url");
		URL_YOUTUBE_AVS.add("og:audio:secure_url");
		
		URL_TAGS.add("img");
		URL_TAGS.add("embed");
		URL_TAGS.add("iframe");
		URL_TAGS.add("a");
		
		CONTAIN_IMAGE_TYPES.add("jpg");
		CONTAIN_IMAGE_TYPES.add("jpeg");
		CONTAIN_IMAGE_TYPES.add("gif");
		CONTAIN_IMAGE_TYPES.add("bmp");
		CONTAIN_IMAGE_TYPES.add("tiff");
		CONTAIN_IMAGE_TYPES.add("png");
		CONTAIN_IMAGE_TYPES.add("webp");
		CONTAIN_IMAGE_TYPES.add("ico");
		CONTAIN_IMAGE_TYPES.add("aspx");
		CONTAIN_IMAGE_TYPES.add("asp");
		CONTAIN_IMAGE_TYPES.add("jsp");
		CONTAIN_IMAGE_TYPES.add("cgi");
		
		IGRNORE_IMAGE_CHARS.add("btn");
		IGRNORE_IMAGE_CHARS.add("button");
		IGRNORE_IMAGE_CHARS.add("ico");
		IGRNORE_IMAGE_CHARS.add("more");
		IGRNORE_IMAGE_CHARS.add("banner");
	}
	private LinkParseOptions options;
	
	@Getter
	private URL url;
	
	@Getter
	private String html = null;
	private Document doc = null;
	private Charset charset = null;;
	
	@Getter
	private Map<String, String> properties = new TreeMap<String, String>();
	private List<String> texts = new ArrayList<String>();
	
	private HtmlParser(URL url) throws Exception {
		this.url = url;
	}
	
	private HtmlParser(String html) throws Exception {
		this.html = html;
	}
	
	private void parse(LinkParseOptions options) throws Exception {
		try {
			this.options = options;
		    if (StringUtils.isNotBlank(options.getEncoding()) && !StringUtils.equalsIgnoreCase("auto", options.getEncoding())) {
		    	charset = Charset.forName(options.getEncoding());
		    }
		    
		    // URI 정보가 있는 경우는 해당 경로로부터 html 정보를 가져온다.
			if (url != null) {
				html = ApacheHttpClient.get(url.toString(), charset, options.getUserAgent());
			}
			
			if (StringUtils.isNotBlank(html)) {
				doc = Jsoup.parse(html);
			}
			if (url == null) { url =  findURIFromDocuments(); }
			
			if (doc == null || doc.getAllElements().size() == 0) {
				throw new Exception("This HTML is not a valid document.");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	private Map<String, List<String>> getMetaProperties(String prefix) {
		return getMetaContents("property", prefix);
	}
	private Map<String, List<String>> getMetaNames(String prefix) {
		return getMetaContents("name", prefix);
	}
	private Map<String, List<String>> getMetaContents(String item, String prefix) {
		Elements elements = doc.select("meta["+item+"^="+prefix+":]");
		Map<String, List<String>> properties = new LinkedHashMap<String, List<String>>();
		
		for (Element el : elements) {
			String attr = el.attr(item).toLowerCase();
			//String attr = el.attr("property").replace("og:", "");
			String val = el.attr("content");
			if (StringUtils.isNotBlank(val)) {
				val = val.trim();
				if (!properties.containsKey(attr)) { properties.put(attr, new ArrayList<String>()); }
				if (!properties.get(attr).contains(val)) {
					properties.get(attr).add(val);
				}
			}
		}
		return properties;
	}
	
	private Map<String, String> getFirstMetaContents() {
		Map<String, String> contents = new LinkedHashMap<String, String>();
		String metaDescription = getFirstMetaContent("name", "description");
		String metaTitle = getFirstMetaContent("name", "title");
		String metaImage = getFirstMetaContent("name", "image");
		
		if (StringUtils.isNotBlank(metaDescription)) { contents.put("description", metaDescription); }
		if (StringUtils.isNotBlank(metaTitle)) { contents.put("title", metaTitle); }
		if (StringUtils.isNotBlank(metaImage)) { contents.put("image", metaImage); }
		
		return contents;
	}
	private String getFirstMetaContent(String item, String value) {
		Elements elements = doc.select("meta["+item+"^="+value+"]");
		if (elements.first() != null) {
			return elements.first().attr("content").trim();
		} else { return null; }
	}
	private URL findURIFromDocuments() throws Exception {
		if (doc == null) { return null; }
		URL fUrl = null;
		String strUrl = getFirstMetaContent("property", "og:url");
		if (StringUtils.isBlank(strUrl)) {
			strUrl = getFirstMetaContent("property", "twitter:url");
		}
		if (StringUtils.isBlank(strUrl)) {
			strUrl = getFirstMetaContent("property", "url");
		}
		if (StringUtils.isBlank(strUrl)) {
			strUrl = getFirstMetaContent("name", "url");
		}
		if (StringUtils.isNotBlank(strUrl)) {
			fUrl = new URL(strUrl);
		}
		return fUrl;
	}
	
	private List<String> listTextValue(String tag) {
		Elements elements = doc.select(tag);
		for (Element el : elements) {
			for (Node node : el.childNodes()) {
				recursiveSearch(node);
			}
		}
		List<String> textList = new ArrayList<String>(texts);
		sortByLength(textList);
		List<String> subTexts = getSubList(textList, options.getTextsCount());
		
		// 원래 순서대로 변경
		TreeMap<Integer, String> sortMap = new TreeMap<Integer, String>();
		for (String text : subTexts) {
			sortMap.put(texts.indexOf(text), text);
		}
		return new ArrayList<String>(sortMap.values());
	}
//	private List<String> listPatternValues(String pattern, String attr) {
//		Elements elements = doc.select(pattern);
//		List<String> values = new ArrayList<String>();
//		for (Element el : elements) {
//			values.add(el.attr(attr));
//		}
//		System.out.println(values);
//		return values;
//	}
	private void recursiveSearch(Node node) {
		if (node == null) { return; }
		if (node instanceof TextNode) {
			String text = ((TextNode)node).text().trim();
			if (StringUtils.isNotBlank(text) && text.length() > options.getIgnoreTextLength()) {
				if (!texts.contains(text)) { texts.add(text); }
			}
		} else if (node.childNodeSize() > 0) {
			for (Node child : node.childNodes()) {
				recursiveSearch(child);
			}
		}
	}
	
	@SuppressWarnings("unused")
	private String getValue(String tag) {
		return getValue(tag, null);
	}
	private String getValue(String tag, String attr) {
		Element el = doc.select(tag).first();
		if (el == null) { return null; }
		String value = null;
		
		if (StringUtils.isBlank(attr)) { value = el.text(); }
		else { value = el.attr(attr); }
		if (StringUtils.isNotBlank(value) && URL_TAGS.contains(tag)) {
			value = value.trim();
			value = toAbsolutePath(value);
		}
		return value;
	}
	
	@SuppressWarnings("unused")
	private String getSource(String tag) {
		Element el = doc.select(tag).first();
		if (el == null) { return null; }
		return el.toString().trim();
	}
	private List<String> listValue(String tag) {
		return listValue(tag, null);
	}
	private List<String> listValue(String tag, String attr) {
		Elements elements = doc.select(tag);
		boolean isUriTag =  URL_TAGS.contains(tag);
		List<String> values = new ArrayList<String>();
		for (Element el : elements) {
			String value = null;
			if (StringUtils.isBlank(attr)) { value = el.text(); }
			else {
				value = el.attr(attr);
			}
			
			if (StringUtils.isNotBlank(value)) {
				value = value.trim();
				if(isUriTag) { value = toAbsolutePath(value); }
				if (!values.contains(value)) { values.add(value); }
			}
		}
		
		return values;
	}
	private Map<String, String> listHtml5MediaValue(String mediaType) {
		Elements elements = doc.select(mediaType+" source");
		Map<String, String> values = new LinkedHashMap<String, String>();
		for (Element el : elements) {
			String src = el.attr("src");
			String type = el.attr("type");
			
			if (StringUtils.isNotBlank(src) && StringUtils.isNotBlank(type)) {
				src = src.trim();
				src = toAbsolutePath(src);
			} else { continue; }
			
			values.put(src, type);
		}
		
		return values;
	}
	
	@SuppressWarnings("unused")
	private List<String> listSource(String tag) {
		Elements elements = doc.select(tag);
		List<String> values = new ArrayList<String>();
		for (Element el : elements) {
			String value = el.toString();
			if (!values.contains(value)) { values.add(value); }
		}
		return values;
	}

	private String toAbsolutePath(String path) {
		return PathUtils.makeAbsolutePath(url, path);
	}
	
	private static String ellipsis(String str, int length) {
		if (StringUtils.isEmpty(str)) { return str; }
		if (str.length() <= length) { return str; }
		return StringUtils.substring(str, 0, length) + "...";
	}
	
	private Map<String, List<String>> getTagProperties() throws Exception {
		Map<String, List<String>> tagProps = new LinkedHashMap<String, List<String>>();
		
		// Title
		List<String> titles = listValue("title");
		if (titles.size() > 0) { tagProps.put("title", titles); }
		
		// Image
	    List<String> images = listValue("img", "src");
	    images.addAll(listValue("img", "data-src"));
	//http://news.sbs.co.kr/news/endPage.do?news_id=N1003930299&plink=STAND&cooper=NAVER
	    if (options.isFilterImage()) {
	    	images = filterImages(images);
	    }
	    if (images.size() > 0) { tagProps.put("image", getSubList(images, options.getImagesCount())); }
	    
	    // Embed(Video or Audio)
	    List<String> embeds = listValue("embed", "src");
	    if (embeds.size() > 0) { tagProps.put("embed", embeds); }
	    
	    List<String> objs = listValue("object", "src");
	    if (objs.size() > 0) { tagProps.put("object", objs); }
	    
	    // Iframe
	    List<String> iframes = listValue("iframe", "src");
	    iframes.addAll(listValue("iframe", "_src"));
	    List<String> iframesVideo = new ArrayList<String>();
	    for (String src : iframes) {
	    	if (StringUtils.containsIgnoreCase(src, "www.youtube.com/embed")
	    			|| StringUtils.containsIgnoreCase(src, "www.youtube.com/v")) {
	    		iframesVideo.add(src);
	    	}
	    }
	    if (iframes.size() > 0) { iframes.removeAll(iframesVideo); tagProps.put("iframe", iframes); }
	    if (iframesVideo.size() > 0) { tagProps.put("iframe:video", iframesVideo); }
		
	    // Body
		List<String> bodies = listValue("body");
		if (bodies.size() > 0) { tagProps.put("body:fulltext", bodies); }
		
		// Href 
		List<String> hrefs = filterHref(listValue("a", "href"));
		if (hrefs.size() > 0) {	tagProps.put("href", getSubList(hrefs, options.getHrefsCount())); }
		
		// Text
		List<String> textList = listTextValue("body");
		if (textList.size() > 0) { tagProps.put("body:text", textList); }
		
		Map<String, String> videos = listHtml5MediaValue("video");
		if (videos.size() > 0) {
			List<String> srcs = new ArrayList<String>();
			List<String> types = new ArrayList<String>();
			
			for (Map.Entry<String, String> entry : videos.entrySet()) {
				srcs.add(entry.getKey());
				types.add(videos.get(entry.getValue()));
			}
			tagProps.put("video:html5:url", srcs);
			tagProps.put("video:html5:type", types);
		}
		Map<String, String> audios = listHtml5MediaValue("audio");
		if (audios.size() > 0) {
			List<String> srcs = new ArrayList<String>();
			List<String> types = new ArrayList<String>();
			for (Map.Entry<String, String> entry : audios.entrySet()) {
				srcs.add(entry.getKey());
				types.add(entry.getValue());
			}
			tagProps.put("audio:html5:url", srcs);
			tagProps.put("audio:html5:type", types);
		}
//		// TODO : 만일, 필요하면 넣을 예정
//		// HTML - Hrefs
//		Set<String> hrefHtmls = listSource("a");
//		if (hrefHtmls.size() > 0) { tagProps.put("href:html", hrefHtmls); }
//		// HTML - Images
//		Set<String> imagesHtml = listSource("img");
//		if (imagesHtml.size() > 0) { tagProps.put("image:html", imagesHtml); }
//		// HTML - Embed
//		Set<String> embedHtml = listSource("embed");
//		if (embedHtml.size() > 0) { tagProps.put("embed:html", embedHtml); }
//		// HTML - Iframe
//		Set<String> iframeHtml = listSource("iframe");
//		if (iframeHtml.size() > 0) { tagProps.put("iframe:html", iframeHtml); }
		
		return tagProps;
	}
	private List<String> getSubList(List<String> list, int size) {
		List<String> subList = new ArrayList<String>();
		if (list.size() > 0) {
	    	int subSize = list.size() > size ? size : list.size();
	    	subList = list.subList(0, subSize);
	    }
		return subList;
	}
	private void setMetaContents(Map<String, List<String>> props, String prefix) {
		//boolean isYoutube = StringUtils.isNotBlank(prefix) && StringUtils.equals("og", prefix);
		for (Map.Entry<String, List<String>> entry : props.entrySet()) {
			String key =  entry.getKey();
			String newKey = key;
			if (StringUtils.isNotBlank(prefix)) { newKey = key.replace(prefix+":", ""); }
			
			if (!properties.containsKey(newKey)) {
				Iterator<String> iter = entry.getValue().iterator();
				if (iter.hasNext()) {
					properties.put(newKey, iter.next());
				}
			}
		}
	}
	private void setMetaContents(Map<String, String> contents) {
		for (Map.Entry<String, String> entry : contents.entrySet()) {
			if (!properties.containsKey(entry.getKey())) { properties.put(entry.getKey(), entry.getValue()); }
		}
	}
//	private void setMetaContents(Map<String, List<String>> props, String prefix) {
//		boolean isYoutube = StringUtils.isNotBlank(prefix) && StringUtils.equals("og", prefix);
//		
//		for (Map.Entry<String, List<String>> entry : props.entrySet()) {
//			String key = entry.getKey();
//			String newKey = key;
//			if (StringUtils.isNotBlank(prefix)) { newKey = key.replace(prefix+":", ""); }
//			
//			if (!properties.containsKey(newKey)) {
//				Iterator<String> iter = entry.getValue().iterator();
//				while (iter.hasNext()) {
//					String value = iter.next();
//					if (isYoutube && URL_YOUTUBE_AVS.contains(key.toLowerCase())) {
//						if (StringUtils.containsIgnoreCase(value, "www.youtube.com/v")) {
//							properties.put(newKey+":embed", value);
//						} else if (StringUtils.containsIgnoreCase(value, "www.youtube.com/embed")) {
//							properties.put(newKey+":iframe", value);
//						} else {
//							properties.put(newKey, value);
//						}
//					} else {
//						properties.put(newKey, value);
//						break;
//					}
//				}
//			}
//		}
//	}
	private void setTagContents(Map<String, List<String>> tags) {
		setTagContents(tags, "title", "title");
		setTagContents(tags, "image", "image");
		setTagContents(tags, "description", "body:text");
		setTagContents(tags, "description", "body:fulltext");
		setTagContents(tags, "href", "href");
		setTagContents(tags, "embed", "embed");
		setTagContents(tags, "object", "object");
		setTagContents(tags, "iframe", "iframe");
		setTagContents(tags, "iframe:video", "iframe:video");
		setTagContents(tags, "video:html5:url", "video:html5:url");
		setTagContents(tags, "video:html5:type", "video:html5:type");
		setTagContents(tags, "audio:html5:url", "audio:html5:url");
		setTagContents(tags, "audio:html5:type", "audio:html5:type");
	}
	private void setTagContents(Map<String, List<String>> tags, String targetTag, String sourceTag) {
		if (!properties.containsKey(targetTag)) {
			if (tags.containsKey(sourceTag) && tags.get(sourceTag).size() > 0) {
				properties.put(targetTag, tags.get(sourceTag).get(0));
			}
		}
	}
	private void setCommonContents() throws Exception {
		String ellipsisTitle = ellipsis(properties.get("title"), options.getTitleEllipsisLength());
		String ellipsisDescription = ellipsis(properties.get("description"), options.getDescriptionEllipsisLength());
		
		if (StringUtils.isNotBlank(ellipsisTitle)) { properties.put("title:ellipsis", ellipsisTitle); }
		if (StringUtils.isNotBlank(ellipsisDescription)) { properties.put("description:ellipsis", ellipsisDescription); }
		
		if (url != null) { 
			if (!properties.containsKey("url")) { properties.put("url", url.toString()); }
			if (!properties.containsKey("host")) { properties.put("host", PathUtils.getFullHost(url)); }
			if (!properties.containsKey("domain")) { properties.put("domain", url.getHost()); }
		} else {
			String uriStr = properties.get("url");
			if (isValidUri(uriStr)) {
				url = new URL(uriStr);
				if (!properties.containsKey("url")) { properties.put("url", url.toString()); }
				if (!properties.containsKey("host")) { properties.put("host", PathUtils.getFullHost(url)); }
				if (!properties.containsKey("domain")) { properties.put("domain", url.getHost()); }
			}
		}
		//if (!properties.containsKey("html")) { properties.put("html", html); }
	}
	
	// 웹 페이지에 포함되어 있는 콘텐츠가 아닌 직접적인 파일이나 이미지, 동영상 등일 경우에는
	private static Map<String, Object> getDirectContents(String urlStr, URL url) {
		try {
			Map<String, Object> results = null;
			//URL url = new URL(uri);
			URLConnection urlConn = url.openConnection();
			long length = Long.parseLong(urlConn.getHeaderField("Content-Length"));
			String type = urlConn.getHeaderField("Content-Type");
			//String contentType = u.getContentType();
			
//			Gson gson = new GsonBuilder().setPrettyPrinting().create();
//			LinkParseOptions option = new LinkParseOptions();
//			option.setDetail(true);
//			option.setFilterImage(true);
//			
//			String jsonStr = gson.toJson(urlConn.getHeaderFields());
//			System.out.println("=======================================");
//			System.out.println(jsonStr);
//			System.out.println("=======================================");
		
			
			if (StringUtils.startsWithIgnoreCase(type, "text/html")/* && length < 1024*1024*/) {
				return null;
			} else {
				results = new LinkedHashMap<String, Object>();
				results.put("directContents", true);
				results.put("title", FilenameUtils.getName(urlStr));
				//results.put("description", urlStr);
				results.put("contentsType", type);
				results.put("contentsLength", length);
				
				if (StringUtils.startsWithIgnoreCase(type, "image/")) {
					results.put("image", urlStr);
				} else if (StringUtils.startsWithIgnoreCase(type, "audio/")) {
					results.put("audio", urlStr);
				} else if (StringUtils.startsWithIgnoreCase(type, "video/")) {
					results.put("video", urlStr);
				} else if (StringUtils.startsWithIgnoreCase(type, "application/")) {
					results.put("application", urlStr);
				} else {
					results.put("object", urlStr);
				}
				return results;
			}
		} catch (Exception ex) {
			return null;
		}
	}
	public static Map<String, Object> execute(String source, LinkParseOptions options) throws Exception {
		URL url = null;
		HtmlParser parser = null;
		Map<String, Object> results = null;
		
		if (StringUtils.isBlank(source)) {
			throw new Exception("Request source is null.");
		}
		
		if (isValidUri(source)) {
			String encodedSource = PathUtils.encodeQueryString(source);
			url = new URL(encodedSource);

			// 해당 URL의 contents가 직접적인 파일 이미지, 동영상등을 나타내는 경우에는 파싱을 하지 않고 곧바로 리턴
			results = getDirectContents(encodedSource, url);
			if (results != null) { return results; }
			
			parser = new HtmlParser(url);
		} else {
			String decodedSource = StringEscapeUtils.unescapeHtml(source);
			parser = new HtmlParser(decodedSource);
		}
		parser.parse(options);
		
		results = new LinkedHashMap<String, Object>();
		
		Map<String, List<String>> ogContents = parser.getMetaProperties("og");
		Map<String, List<String>> twContents = parser.getMetaNames("twitter");

		// meta 태그값중에 위 og나 twitter등이 설정되어 있지 않는 경우, meta tag의 attr속성중에 description,title등을 가지고 있는 사이트가 있다.
		Map<String, String> firstMetaContents = parser.getFirstMetaContents();
		
		Map<String, List<String>> ntContents = new LinkedHashMap<String, List<String>>();
		Map<String, List<String>> m2Contents = new LinkedHashMap<String, List<String>>();
		Map<String, List<String>> alContents = new LinkedHashMap<String, List<String>>();
		
		if (options.isDetail()) {
			ntContents = parser.getMetaNames("nate");
			m2Contents = parser.getMetaProperties("me2");
			alContents = parser.getMetaProperties("al");
		}
		Map<String, List<String>> tagProps = parser.getTagProperties();
		
		// 순서가 중요
		// 순서에 우선하여 값이 저장되며, 이미 설정된 값은 앞에 설정된 값이 우선한다.
		parser.setMetaContents(ogContents, "og");
		parser.setMetaContents(twContents, "twitter");
		parser.setTagContents(tagProps);
		parser.setMetaContents(firstMetaContents);
		parser.setCommonContents();
		
		results.putAll(parser.getProperties());
		
		if (options.isDetail()) {
			if (ogContents.size() > 0) { results.put("ogs", ogContents); }
			if (twContents.size() > 0) { results.put("twitters", twContents); }
			results.put("htmls", tagProps);
			if (alContents.size() > 0) { results.put("als", alContents); }
			if (ntContents.size() > 0) { results.put("nates", ntContents); }
			if (m2Contents.size() > 0) { results.put("me2s", m2Contents); }
		}
		
		return results;
	}

	private List<String> filterImages(List<String> images) throws Exception {
		List<String> filters = new ArrayList<String>();
		for (String image : images) {
			String ext = getExtension(image);
			if (isIgnoreImagesName(image)) { continue; }
			if (StringUtils.isBlank(ext) || CONTAIN_IMAGE_TYPES.contains(ext)) {
				filters.add(image);
			}
		}
		filters = getAvaliableImages(filters);
		//sortByExtension(filters);
		return filters;
	}
	private List<String> filterHref(List<String> hrefs) {
		List<String> filters = new ArrayList<String>();
		for (String href : hrefs) {
			if (href.startsWith("#")) { continue; }
			if (StringUtils.startsWithIgnoreCase(href,"javascript:")) { continue; }
			filters.add(href);
		}
		return filters;
	}
	private boolean isIgnoreImagesName(String image) {
		for (String ignoreChars : IGRNORE_IMAGE_CHARS) {
			//String name = FilenameUtils.getName(image);
			if (StringUtils.contains(image, ignoreChars)) { return true; }
		}
		return false;
	}
	
	public static void sortByLength(List<String> list) {
		Collections.sort(list, new Comparator<String>() {
	        @Override
	        public int compare(String first, String second) {
	        	if (first.length() < second.length()) {
	        		return 1;
	        	} else if (first.length() > second.length()) {
	        		return -1;
	        	} else {
	        		return 0;
	        	}
	        }
	    });
	}
	
	public static void sortByExtension(List<String> list) {
		Collections.sort(list, new Comparator<String>() {
	        @Override
	        public int compare(String first, String second) {
	        	String firstExt = getExtension(first);
	        	String secondExt = getExtension(second);
	        	
	        	int firstIndex = CONTAIN_IMAGE_TYPES.indexOf(firstExt);
	        	int secondIndex = CONTAIN_IMAGE_TYPES.indexOf(secondExt);
	        	return Integer.compare(firstIndex, secondIndex);
	        	
//	        	return secondExt.compareToIgnoreCase(firstExt);
	        }
	    });
	}
	private List<String> getAvaliableImages(List<String> images) {
		List<String> availImages = new ArrayList<String>();
		for (String image : images) {
			if (isAvailableImageSize(image)) {
				availImages.add(image);
			}
			if (availImages.size() == options.getImagesCount()) { break; }
		}
		return availImages;
	}
	private boolean isAvailableImageSize(String src) {
		boolean avail = false;
		try {
	    	URL url = new URL(src);  
			final ByteArrayOutputStream baos = new ByteArrayOutputStream();
			
	        final InputStream inputStream = url.openStream();
	        int read;
	        byte[] buffer = new byte[8192];
	        
	        while ((read = inputStream.read(buffer)) != -1) {
	            baos.write(buffer, 0, read);
	        }

	        final Image image = ImagesServiceFactory.makeImage(baos.toByteArray());
//	        System.out.println(String.format("%s : (%d X %d) : %d : %s ",
//	        		src, image.getWidth(), image.getHeight(), image.getImageData().length, image.getFormat()));
	        
			if (image.getImageData().length > options.getImageSize()
					&& image.getWidth() > options.getImageWidth()
					&& image.getHeight() > options.getImageHeight()) {
				avail = true;
			}
		} catch (final MalformedURLException e) {
//			System.out.println("malformed url error!");
	    } catch (final IOException e) {
//	    	System.out.println("image doesn't exists!");
	    } catch (final IllegalArgumentException e) {
//	    	System.out.println("invalid image!");
	    } catch (final Exception e) {
//	    	System.out.println(e.getMessage());
	    }
		
	    return avail;
	}
	
	private static boolean isValidUri(String uri) {
		try {
			if (StringUtils.isBlank(uri)) { return false; }
			if (StringUtils.startsWith(uri, "https://") || StringUtils.startsWith(uri, "http://")) { return true; }
			if (StringUtils.startsWith(uri, "//")) { return true; }
			
			if (new UrlValidator().isValid(uri.replaceAll(" ", ""))) {
				return true;
			}
		} catch (Exception ex) {}
		return false;
	}
	private static String getExtension(final String uri) {
		try {
			String path = uri.replaceAll(" ", "");
			path = new URI(path).getPath();
			String ext = FilenameUtils.getExtension(URLEncoder.encode(path, CommonProperty.UTF_8));
			return ext.toLowerCase();
		} catch (Exception ex) {
			return "";
		}
	}
	public static void main(String[] args) throws Exception {
		//http://imgnews.naver.net/image/079/2016/12/15/20161215003124338557_99_20161215060218.jpg
		//String path = "http://dev.epiloum.net/916";
//		String path = "https://www.youtube.com/watch?v=AMSvArIMPrc";
//		String path = "http://news.mk.co.kr/newsRead.php?sc=30000001&year=2016&no=848946";
//		String path = "http://news.naver.com/main/read.nhn?mode=LS2D&mid=shm&sid1=100&sid2=264&oid=448&aid=0000190442";
//		String path = "http://program.sbs.co.kr/builder/endPage.do?pgm_id=22000009540&pgm_mnu_id=43857&bbsCd=&contNo=22000207320";
//		String path = "http://news.naver.com/main/hotissue/read.nhn?mid=hot&sid1=100&cid=1053020&iid=24782531&oid=008&aid=0003782670&ptype=052";
//		String path = "http://imnews.imbc.com/replay/2016/nwtoday/article/4178852_19847.html";
//		String path = "http://news.kmib.co.kr/article/view.asp?arcid=0011124411&code=61122020&sid1=all&cp=nv2";
//		String path = "http://www.zdnet.co.kr/news/news_view.asp?artice_id=20161209160117";
//		String path = "http://post.naver.com/viewer/postView.nhn?memberNo=909494&volumeNo=5732042&navigationType=push";
		String path = "http://news.naver.com/main/read.nhn?mode=LSD&mid=shm&sid1=100&oid=003&aid=0007661164";
//		String path = "https://storage.googleapis.com/cocoworks-for-ecs.appspot.com/imgaes/mail/cocoworks_mail_btn_en_US.png";
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		LinkParseOptions option = new LinkParseOptions();
		option.setDetail(true);
		option.setFilterImage(true);
		
		String jsonStr = gson.toJson(HtmlParser.execute(path, option));
		System.out.println(jsonStr);
//		
//		Document doc = Jsoup
//				.connect("http://imnews.imbc.com/replay/2016/nwtoday/article/4178852_19847.html")
////				.followRedirects(true)
////				.maxBodySize(10000000)
////				.validateTLSCertificates(false)
////				.timeout(1000000)
//				.get();
//				
//				
//		System.out.println(doc.getAllElements().size());
//		Elements els = doc.select("meta[property^=og:");
//		for (Element el : doc.getAllElements()) {
//			System.out.println(el.toString());
//		}

		
	}
	
//	public static void main(String[] args) throws Exception {
//		LinkParseOptions option = new LinkParseOptions();
//		option.setDetail(true);
//		option.setFilterImage(true);
//		//
//		//String uri = URLDecoder.decode("https%3A%2F%2Fvt.tumblr.com%2Ftumblr_o4dcvk2KrY1v2u7xj.mp4", "utf-8");
//		String uri = URLDecoder.decode("http://khnews.kheraldm.com/view.php?ud=20170719000839&kr=1&nt=1&md=20170719163251_BL&kr=1", "utf-8");
//		System.out.println(uri);
//		Map<String, Object> map = execute(uri, option);
//		System.out.println(map);
//		//System.out.println(isValidUri(url));
//		
//		
//		URL url = new URL(uri);
//		URLConnection u = url.openConnection();
//		String contentLength = u.getHeaderField("Content-Length");
//		System.out.println("contentLength : " + contentLength);
//		long length = 0;
//		if (StringUtils.isNumeric(contentLength)) {
//			length = Long.parseLong(u.getHeaderField("Content-Length"));
//		}
//		String type = u.getHeaderField("Content-Type");
//
//		String contentType = u.getContentType();
//		
//		System.out.println("length:" + length);
//		System.out.println("type:" + type);
//		System.out.println("contentType" + contentType);
//	}
}
