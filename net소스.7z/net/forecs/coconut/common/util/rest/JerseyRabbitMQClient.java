package net.forecs.coconut.common.util.rest;

import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;

public class JerseyRabbitMQClient {
	public static String get(String urlStr, String userName, String password) throws Exception {
		try {
			Client client = Client.create();
			client.addFilter(new HTTPBasicAuthFilter(userName, userName));
			
			WebResource webResource = client.resource(urlStr);
			
			ClientResponse response = webResource
//					.header(HEADER_AUTHORIZATION, token)
					.accept("application/json")
					.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);

			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

	public static String post(String urlStr, String username, String password, Map<String, Object> entityMap) throws Exception {
		try {
			Client client = Client.create();
			client.addFilter(new HTTPBasicAuthFilter(username, username));
			
			WebResource webResource = client.resource(urlStr);

			String input = null;
			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				input = om.writeValueAsString(entityMap);
			}
			
			ClientResponse response;
			if (input != null) {
				response = webResource
						.type("application/json")
						.post(ClientResponse.class, input);
			} else {
				response = webResource
						.type("application/json")
						.post(ClientResponse.class);
			}
			
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = "";
			if (response.hasEntity()) {
				output = response.getEntity(String.class);
			}
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String put(String urlStr, String username, String password, Map<String, Object> entityMap) throws Exception {
		try {
			Client client = Client.create();
			client.addFilter(new HTTPBasicAuthFilter(username, password));
			
			WebResource webResource = client.resource(urlStr);

			String input = null;
			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				input = om.writeValueAsString(entityMap);
			}
			
			ClientResponse response;
			if (input != null) {
				response = webResource
						.type("application/json")
						.put(ClientResponse.class, input);
			} else {
				response = webResource
						.type("application/json")
						.put(ClientResponse.class);
			}
			
			if (response.getStatus() != 204) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = "";
			if (response.hasEntity()) {
				output = response.getEntity(String.class);
			}

			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String delete(String urlStr, String username, String password) throws Exception {
		try {
			Client client = Client.create();
			client.addFilter(new HTTPBasicAuthFilter(username, password));
			
			WebResource webResource = client.resource(urlStr);
			ClientResponse response = webResource
//					.header(HEADER_AUTHORIZATION, token)
					.accept("application/json")
					.delete(ClientResponse.class);

			if (response.getStatus() != 204) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = "";
			if (response.hasEntity()) {
				output = response.getEntity(String.class);
			}

			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
}
