package net.forecs.coconut.common.util.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.ClientProtocolException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class NetRabbitMQClient {
	public static String get(String urlStr, String username, String password) throws ClientProtocolException, IOException {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			
			String auth = username + ":" + password;
//			String encoded = new String(Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8)));
			String encoded = Base64.encodeBase64String(auth.getBytes(StandardCharsets.UTF_8));
			conn.setRequestProperty("Authorization", "Basic "+encoded);
			
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream()), StandardCharsets.UTF_8));

			String output;
			StringBuilder sb = new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			conn.disconnect();
			
			return sb.toString();
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

	public static String post(String urlStr, String username, String password, Map<String, Object> entityMap) throws ClientProtocolException, IOException {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			
			String auth = username + ":" + password;
//			String encoded = new String(Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8)));
			String encoded = Base64.encodeBase64String(auth.getBytes(StandardCharsets.UTF_8));
			conn.setRequestProperty("Authorization", "Basic "+encoded);
			
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");

			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				String input = om.writeValueAsString(entityMap);
				
				OutputStream os = conn.getOutputStream();
				os.write(input.getBytes(StandardCharsets.UTF_8));
				os.flush();
			}

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream()), StandardCharsets.UTF_8));

			StringBuilder sb = new StringBuilder();
			String output;
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			conn.disconnect();
			
			return sb.toString();
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String put(String urlStr, String username, String password, Map<String, Object> entityMap) throws ClientProtocolException, IOException {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			
			String auth = username + ":" + password;
//			String encoded = new String(Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8)));
			String encoded = Base64.encodeBase64String(auth.getBytes(StandardCharsets.UTF_8));
			conn.setRequestProperty("Authorization", "Basic "+encoded);
			
			conn.setDoOutput(true);
			conn.setRequestMethod("PUT");
			conn.setRequestProperty("Content-Type", "application/json");

			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				String input = om.writeValueAsString(entityMap);
				
				OutputStream os = conn.getOutputStream();
				os.write(input.getBytes(StandardCharsets.UTF_8));
				os.flush();
			}

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream()), StandardCharsets.UTF_8));

			StringBuilder sb = new StringBuilder();
			String output;
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			conn.disconnect();
			
			return sb.toString();
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String delete(String urlStr, String username, String password) throws ClientProtocolException, IOException {
		try {
			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			
			String auth = username + ":" + password;
			//String encoded = new String(Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8)));
			String encoded = Base64.encodeBase64String(auth.getBytes(StandardCharsets.UTF_8));
			conn.setRequestProperty("Authorization", "Basic "+encoded);
			
			conn.setRequestMethod("DELETE");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream()), StandardCharsets.UTF_8));

			String output;
			StringBuilder sb = new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			conn.disconnect();
			
			return sb.toString();
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
}
