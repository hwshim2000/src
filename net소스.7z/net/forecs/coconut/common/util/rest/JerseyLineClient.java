package net.forecs.coconut.common.util.rest;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.net.URLEncoder;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class JerseyLineClient {
	private final static String HEADER_AUTHORIZATION = "Authorization";
	//private static final String private_key = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCpCmeNCUpaZqDKcBYc/sssvgi2QI4fzwpk2JG5JSX7Ygkxaa9EcLGLv25pgpeYY827SUCXnfPljrzVyWIchhOj5V1rX6E/uHNpGWDr5nDRESzkD8Z/bCK48NhQj0dBBoiLKzEv5pAdlZFojioD0vepv6jRVyckQLwLpMapv540D+VM7WLWXA8/6feDz9De6lFTOy8j07mS50+3HTdR2tPKSDzFPwUY7oaEnLDLkY602AHwlcalW3Kuae4ZeDOqveAJJF3BwANBYYWjBm0qDHVjTXRlJu55ZQxIFi/NQ6lWPDFJ4N/P5ZrzWnkTvSVfYZ7fVC3hC+Y9l4KicpEFUVwDAgMBAAECggEBAKispCVcdt/79kfqTnaCXFR6D5FkmyzsWG/GlqpLgjn0Wj3/Og+t78wFqfQIhqJePGS8tIJV75BJvO4KtCbINwLdFTnWQ72knSzrUQYzfLFxVP0BLM3rJj6qvP6t6ajeDxPndn5Yr8eFfoH5Eb2dHto4UAkL0RfgrINl2YJ6nS9OaeKkAxCbyhqk4+NVvIqW/at5OuIsv623gdL5V5v1tZxfWypgoCToVJy9pAp3jx5p58k7nFYpCSg4BxEPODlJ9i/8SvvQBNX9mMIFesYQvAX3W0flBVoYhGqXMIZ6pgvZTDcnavT/K9NrDvlxaWeanrNkbjtzx255o1jkQkCWZrkCgYEA1pC5SYDfe1KhHXyX/stw5VbYTYABOVKqy3r53nvhcfHu2CaRIjqKVW1N9mtibbNymSa2HCd7U4vfN/CayTKx18ROM0hFAp8a/j0LHkCNKnCQuge23Jr4zz0t11LLvOjWocL2d5UNCoToxsJk5pvMR0UorOWsITE/U1rF4mJ25O0CgYEAya8d/nQPkCvIR65jRSGEn+WDYi83pRsR3DMbNMTOm7ckIr+qQ1n/zEa1lT6gC5yj5ACZaTooc6fW8dypKGcmimSPKGU62KY+SBuBDMeHEyVNMrB1fpwy5PJHLJegz2vsZ7uLwv1rmphz8yqPf1kjsLM7LP06x8qZ56ex9maIlq8CgYBz55XPmOggLBCQZx+MKcWAfZs2sjD3ECrm5DVZ871i2ffVl2/K96iGYRc+R9/Rtp/vDzRMnR9HkEUyaKyUhuf+0DIWDbIJqnzgXYVGAETBajEj7Mrg/G3vNPMwX69jCrv2geS10DRNPGKqC5SJ5htBXKCOVTrYa0vz8RL4KYxkOQKBgAFg8ROMN48EvZm/123hjMaLCxrgt8CpLrYSo1z4+3CVD+os5T0QoG8FDLi4dN+fcn9cga/2ddBUlWOR3pYoHltT1KayCnTwrfxQM9Gii4nV93EhQ6xZ5P8rqNDlOHQyiKss3Qe4M8QaxrAi2lhEg7nxf7YPBRfYirTKsKy+hrCBAoGBALHS2+0Ll8F1K+xZgKkwwjUTJJuVV5Myj7/vwfz6ji5GIPiO6fzA6yVyRJQJvWK5rRGHYpYDZ+HIW+BR9MIVsjWeUJvQQ1U0cLrPYqWCK9NwTItVKtIyr+tDeC6MdWKDSpORwPFRLs3yLxcN59Y4ilQV6kbVclxsZSTo5EO/AHrm";
	private static final String private_key = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCcqjZB5ilElJwcyJiGf+/y++qlCIO7KG/WMQFAcb43GRoR3zL64ufcgLHyQ+lLiqpQXhiuc6s5ClDBB/22jln0os5Y3+YHD2zerg+wFjBTiJwO/yKuW5Vb72CFNu96n5n5a4wQ4sLKMOR9vKiIL0KnKP+sgHYBvXCiOk0DQrEUZbeEXeg403QeUNlyIDnKboto0eTUPdc/vRaPhO9NIyTIw4lEDS9x+O5xPakBjcfwk/2RHMdE1OP7b/gmF+2hQCtQdC9Jh/nSLWhkTitu+u8WvtQRsLTFxLIwd78asi9lvD7y7iE+LRojJ+fG1QzAbfAq+uUzfs7YmVfklKeGugtNAgMBAAECggEBAJHje7UwRPvFO/8d2dNeLi9i4iYe4LUXudWHOvgtM4oRiRJdfBbf2DShb5QAI68iCOngRjGmKytp7Ltk2qH2u9QxC+D9VzL57VMMWjWK5CPV0iWw9zXQuSyspIBJIQdausLmoL9UuzoX/58LYRG4mOQbLMQRuFJ0e//GNNM1drtbalELJFMyeYxeM5o8IRG5CLz+za4q4DJ5rJ6euCJBkmoGhdC+X+qkzv8zkM38Di/Ase6qxTblAAZlUXLJFEHWxyzKVVQ0gyuN/FgMM2O4cj0utexrGtwd0NUOOInAvnM8w3gzpWUTIAIjEspaSsVFUUWk6TIvFxeywymgaxMByw0CgYEA3pZ1hesGZ+JAswZr4XUb3LbYsCJ2x26VOQ5jtH4ZsZApIYO7AiL8vpjcrVMYQiY7T2vcaFwggWGu8OeKMwwJWRjenvAU6ZiCrMjBQF19RNLPnSWijjX8EHijs7gOcDXdr2K1Ar1Ac5MmlP8nu9ilsuwx14yAbN5wWTm2q3JGYx8CgYEAtC5842yxGF7hX/MXJXkMjZLSNognuTpdPRJXaOvl2uIFIeQigV3ZIhDFOGXZU7kTxDMqpqPm3WZKqpUXw7k4toIxlyan+4P/MJ19hqSHgqKY2DvlyJpgc6GTNmTab9O3/dN8LpQ3zZKHsX/UUoFjdnyV5BLjpgiIKUE/9lGZUBMCgYAMyK9vRZRUmxYEMjY3+LXk80t2skQIKD3BzSXE1Ak9vX3fQuWWtdO2Tqk9+yvFgNSfNx6tj7z+MVIO2/1/+Q0AZQFEN5273NqEefM/cx8iuMjbybGQYWFcwNEGHWgW4cEdtZmX0q7E9IqevBjYHRVHNXGXY6ZsmknxlfL73dBVGQKBgExnQhH17wqUgSD8pZ4APHB0B6uUBLQoqYzSEDqvfSJZoS+D25Xbw80MK3UEyykTW+xgff93lNfhHlxDKHaYPhI2Fu0vOSAQEs/8mFPVxJiCdimLDJ8Jx0iBBTmVfoLY1jZNzWS6+Qa00dFUkSYDM7f0kGLMF7g5+fL0djju1QH9AoGAU9bswypyfogDeTVx1RWegdb3P9xD+m32Db7qt0EsEHKKO52Z6BtCTh1NuO+WW1zJ9eiGnmR1TW5C+qwAj/jnnUMzybOed/w+6/gyo3iUY4ljYHttm6DgNkYovd7nfk9VMQISV67M/C7WGEhl2LbBouig2y0jFclAQd5oqp4oONE=";
	private static final String issuer_server_id = "6ec7f8b790d64c97bfee300e176195a9";
	

	
	public static String get(String urlStr) throws Exception {
		return get(urlStr, null, null);
	}

	public static String get(String urlStr, Map<String, String> headerMap) throws Exception {
		return get(urlStr, headerMap, null);
	}
	
	public static String get(String urlStr, Map<String, String> headerMap, Map<String, Object> paramMap) throws Exception {
		try {
			Client client = Client.create();
			
			StringBuilder sb = new StringBuilder(urlStr);
			String queryStr = mapToQueryString(paramMap);
			if (StringUtils.isNotBlank(queryStr)) {
				sb.append("?").append(queryStr);
			}
			
			WebResource webResource = client.resource(sb.toString());
			com.sun.jersey.api.client.WebResource.Builder b = webResource.accept("application/json");
			
			if (headerMap != null) {
				for (String key : headerMap.keySet()) {
					b = b.header(key, headerMap.get(key));
				}
			}
			
			ClientResponse response = b.get(ClientResponse.class);
			
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);

			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

	public static String post(String urlStr, Map<String, String> headerMap, Map<String, Object> paramMap, boolean isFormData) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);
			com.sun.jersey.api.client.WebResource.Builder b = webResource.accept("application/json");
			
			MultivaluedMap<String, String> formData = null;
			String bodyData = null;
			if (paramMap != null) {
				if (isFormData) {
					formData = new MultivaluedMapImpl();
					for (String key : paramMap.keySet()) {
						formData.add(key, String.valueOf(paramMap.get(key)));
					}
				} else {
					ObjectMapper om = new ObjectMapper();
					bodyData = om.writeValueAsString(paramMap);
				}
			}
			
			for (String key : headerMap.keySet()) {
				b = b.header(key, headerMap.get(key));
			}
		
			ClientResponse response;
			if (formData != null && formData.size() > 0) {
				response = b.post(ClientResponse.class, formData);
			} else if (StringUtils.isNotBlank(bodyData)) {
				response = b.post(ClientResponse.class, bodyData);
			} else {
				response = b.post(ClientResponse.class);
			}
			
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String delete(String urlStr, String token) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);
			ClientResponse response = webResource
					.header(HEADER_AUTHORIZATION, token)
					.accept("application/json")
					.delete(ClientResponse.class);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	private static String mapToQueryString(Map<String, Object> paramMap) {
		try {
			StringBuilder sb = new StringBuilder();
			for (Map.Entry<String, Object> e : paramMap.entrySet()) {
				if (sb.length() > 0) { sb.append('&'); }
				sb.append(URLEncoder.encode(e.getKey(), "UTF-8"))
					.append('=')
					.append(URLEncoder.encode(String.valueOf(e.getValue()),"UTF-8"));
			}
			return sb.toString();
		} catch (Exception ex) {
			return "";
		}
	}
	
	//---------------------------------------------------------------------------------------------------------
	
	public static String getLineAuthorizationCode() throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("consumerKey", "X9AoVMjL1aTKCd0brWTy");
//		headerMap.put("User-Agent", "Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.13) Gecko/20101206 Ubuntu/10.10 (maverick) Firefox/3.6.13");
//		headerMap.put("Accept", "*/*");
//		headerMap.put("Referer", "https://auth.worksmobile.com/ba/kr1oQQGnGLKOf/service/authorize?isRefreshed=true&redirect_uri=https%3A%2F%2Fperformance-dot-cocoworks-for-ecs.appspot.com%2Fnotifications&domain=forecs.net&state=afafafafafafaf&client_id=X9AoVMjL1aTKCd0brWTy");
		
		//String redirect_uri = "https://performance-dot-cocoworks-for-ecs.appspot.com/notifications";
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("client_id", "X9AoVMjL1aTKCd0brWTy");
		paramMap.put("redirect_uri", "https://performance-dot-cocoworks-for-ecs.appspot.com/notifications");
		paramMap.put("state", "afafafafafafaf");
		paramMap.put("domain", "forecs.net");
		//paramMap.put("isRefreshed", true);
		
		String url = "https://auth.worksmobile.com/ba/kr1oQQGnGLKOf/service/authorize";
					//+ "?isRefreshed=false&redirect_uri=https%3A%2F%2Fperformance-dot-cocoworks-for-ecs.appspot.com%2Fnotifications&domain=forecs.net&state=afafafafafafaf&client_id=X9AoVMjL1aTKCd0brWTy";
		String res = JerseyLineClient.get(url, headerMap, paramMap);
		
		System.out.println(res);
		return res;
	}
	
	public static String getAccessToken(String authorization_code) throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("consumerKey", "X9AoVMjL1aTKCd0brWTy");
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("client_id", "X9AoVMjL1aTKCd0brWTy");
		paramMap.put("code", authorization_code);
		paramMap.put("domain", "forecs.net");
		
		String url = "https://auth.worksmobile.com/ba/kr1oQQGnGLKOf/service/token";
					//+ "?client_id=X9AoVMjL1aTKCd0brWTy&code=dUNhVmE0eDF3OWVNbEFRMQ&domain=forecs.net";
		String res = JerseyLineClient.get(url, headerMap, paramMap);
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = mapper.readValue(res, new TypeReference<Map<String, Object>>(){});
		String service_access_token = (String)map.get("access_token");
		service_access_token = URLEncoder.encode(service_access_token, "UTF-8");
		System.out.println(service_access_token);
		return service_access_token;
	}
	
	public static String getUserInfo(String access_token) throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("consumerKey", "X9AoVMjL1aTKCd0brWTy");
		headerMap.put("Authorization", "Bearer " + access_token);
		
		
		String url = "https://apis.worksmobile.com/kr1oQQGnGLKOf/drive/getUserInfo/v1";
		String res = JerseyLineClient.get(url, headerMap);
		
		System.out.println(res);
		return res;
	}
	
	
	public static String makeServerToken() throws Exception {
		long curr = System.currentTimeMillis();
		
		byte[] encoded = DatatypeConverter.parseBase64Binary(private_key);
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
        
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey pk = kf.generatePrivate(keySpec);
        
//		byte[] bytes = TextCodec.BASE64.decode(private_key);        
//		X509EncodedKeySpec spec =
//	            new X509EncodedKeySpec(bytes);
//	      KeyFactory kf = KeyFactory.getInstance("RSA");
//	      PublicKey pk = kf.generatePublic(spec);
//		
        
		//Key key = KeyStore.get
		String compactJws = Jwts.builder()
				.setHeaderParam("alg", "RS256")
				.setHeaderParam("typ", "JWT")
				.setIssuer(issuer_server_id)
				.setIssuedAt(new Date(curr))
				.setExpiration(new Date(curr+3600000))
				.signWith(SignatureAlgorithm.RS256, pk)
				.compact();
				
		System.out.println(compactJws);
		//verify
		Jwts.parser().setSigningKey(pk).parseClaimsJws(compactJws);
		Jws<Claims> jws = Jwts.parser()
				//.requireSubject("ME")
				//.require("custom", "myCustom")
				.requireIssuer(issuer_server_id)
				.setSigningKey(
						pk
//					TextCodec.BASE64.decode(
//						"Z0ZvtE07BR9Y/dJvj1v0vSghBB5TPbzLsM3xtHbaGvE="
//					)
				)
				.parseClaimsJws(compactJws);
		// -- verified values --
		System.out.println("alg : " + jws.getHeader().get("alg"));
		System.out.println("typ : " + jws.getHeader().get("typ"));
		System.out.println("issuer : " + jws.getBody().get("iss"));
		return compactJws;
	}
	
	public static String makeServerTokenHS256() throws Exception {
		long curr = System.currentTimeMillis();
		
        
		//Key key = KeyStore.get
		String compactJws = Jwts.builder()
				.setHeaderParam("alg", "HS256")
				.setHeaderParam("typ", "JWT")
				.setIssuer(issuer_server_id)
				.setIssuedAt(new Date(curr))
				.setExpiration(new Date(curr+3600000))
				.signWith(SignatureAlgorithm.HS256, "secret")
				.compact();
				
		System.out.println(compactJws);
		//verify
		Jwts.parser().setSigningKey("secret").parseClaimsJws(compactJws);
		Jws<Claims> jws = Jwts.parser()
				//.requireSubject("ME")
				.requireIssuer(issuer_server_id)
				.setSigningKey("secret"
						
//					TextCodec.BASE64.decode(
//						"Z0ZvtE07BR9Y/dJvj1v0vSghBB5TPbzLsM3xtHbaGvE="
//					)
				)
				.parseClaimsJws(compactJws);
		// -- verified values --
		System.out.println("alg : " + jws.getHeader().get("alg"));
		System.out.println("typ : " + jws.getHeader().get("typ"));
		System.out.println("issuer : " + jws.getBody().get("iss"));
		return compactJws;
	}
	
	public static String getAccessTokenForServer(String server_token) throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("consumerKey", "RLdt7AhJZY2ks6FWMhi4");
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("grant_type", "urn:ietf:params:oauth:grant-type:jwt-bearer");
		paramMap.put("assertion", server_token);
		
		String url = "https://authapi.worksmobile.com/b/kr1oQQGnGLKOf/server/token";
					//+ "?grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion="+server_token;
		String res = JerseyLineClient.post(url, headerMap, paramMap, true);
		
		System.out.println(res);
		return res;
	}
	

	public static String getMemberInfo(String server_access_token) throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("consumerKey", "RLdt7AhJZY2ks6FWMhi4");
		headerMap.put("Authorization", "Bearer " + server_access_token);
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		String params = "{\"memberList\":[{\"externalKey\":\"hyeunwoo.shim@forecs.net\"}],\"tenantId\":127121,\"domainId\":127121}";
		//paramMap.put("params", URLEncoder.encode(params, "utf-8"));
		paramMap.put("params", params);
		String url = "https://apis.worksmobile.com/kr1oQQGnGLKOf/admin/getMember";
		//String url = "https://performance-dot-cocoworks-for-ecs.appspot.com/notifications";
		String res = JerseyLineClient.post(url, headerMap, paramMap, true);
		
		System.out.println(res);
		return res;
	}
	
	public static void serviceAPITest() throws Exception {
		String authorization_code = getLineAuthorizationCode();
//		String authorization_code = "OXFjNmFJRVBWOVNNV0lFNA";
		String service_access_token = getAccessToken(authorization_code);
//
		
		
//		String service_access_token = "AAAAu2541J6SUNi8Phprda/ygOr3+j0POEN5jKZZVuWkGbs5UtdPsKuTsiLB+4QVj0pRrfX/iGnurkyYrBbs8+TEyoszwObR0zFK704o/IEdaQesYFtSwEyfmcP/0mPtefKozgKCPY5SBz82Z82RihfG7Oc7xW8+ujYa2/84+82Ak/CrKd9ys/YNzuVyiNqsIAwCMoaennr6f92bihKQlX7zmOZXT1awmHYYTLDBSiHI7nPvg02NIyaWZFi3V2YDv9s+yQ==";
		getUserInfo(service_access_token);
	}
	public static void serverAPITest() throws Exception {
		String server_token = makeServerToken();
		String jsonAccessToken = getAccessTokenForServer(server_token);
		 
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = mapper.readValue(jsonAccessToken, new TypeReference<Map<String, Object>>(){});
		String server_access_token = (String)map.get("access_token");
		//String server_access_token = "AAAA/kpcklvkA+byJN1j+p9LCYObcT+c2VydmVySWQ+jGQ+EPOquTeb8Dphg99erQBB1CI8yrgwCST10NHEm+nFW/xSTpNrsOGJ2y1tyBYlCeodeyQEtB41PVD7kQCzL9a2ps6RvhKUf5w8Em2zt9PwQwHnrVdJTUZkpFG7lpMkqX9PJCnmJ3MulLbn0MqG7FXW/ilRewnX6qLw4+XMkwJRnk578l5PpG0eB3kQ0tnLgQSOSAef1R3cHcUy7Wi9TmzVP5GANaV0YKpwAZWFRwyoCbRGQGQZSxDP4EegzHM14IYfw5GRzjPpaX+kjc5+bbTLvBDRRvVGmY7rvRdAIudTmOtWiixmI0eDXkvi0=";
		getMemberInfo(server_access_token);
	}
}
