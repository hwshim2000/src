package net.forecs.coconut.common.util.rest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpClient;

import com.fasterxml.jackson.databind.ObjectMapper;

@SuppressWarnings("deprecation")
public class ApacheRabbitMQClient {
	@SuppressWarnings("resource")
	public static String get(String urlStr, String username, String password) throws ClientProtocolException, IOException {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		
		try {
			CredentialsProvider provider = new BasicCredentialsProvider();
			UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
			provider.setCredentials(AuthScope.ANY, credentials);
			httpClient.setCredentialsProvider(provider);
			
			HttpGet getRequest = new HttpGet(urlStr);
			getRequest.addHeader("accept", "application/json");
			
			HttpResponse response = httpClient.execute(getRequest);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent()), StandardCharsets.UTF_8));

			String output;
			StringBuilder sb = new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			return sb.toString();
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.getConnectionManager().shutdown();
		}
	}

	@SuppressWarnings("resource")
	public static String post(String urlStr, String username, String password, Map<String, Object> entityMap) throws ClientProtocolException, IOException {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		
		try {
			CredentialsProvider provider = new BasicCredentialsProvider();
			UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
			provider.setCredentials(AuthScope.ANY, credentials);
			httpClient.setCredentialsProvider(provider);
			
			HttpPost postRequest = new HttpPost(urlStr);
			postRequest.addHeader("accept", "application/json");

			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				String entityStr = om.writeValueAsString(entityMap);
				StringEntity input = new StringEntity(entityStr);
				input.setContentType("application/json");
				postRequest.setEntity(input);
			}

			HttpResponse response = httpClient.execute(postRequest);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent()), StandardCharsets.UTF_8));

			StringBuilder sb = new StringBuilder();
			String output;
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}
			
			return sb.toString();
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.getConnectionManager().shutdown();
		}
	}
	
	@SuppressWarnings("resource")
	public static String put(String urlStr, String username, String password, Map<String, Object> entityMap) throws ClientProtocolException, IOException {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		
		try {
			CredentialsProvider provider = new BasicCredentialsProvider();
			UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
			provider.setCredentials(AuthScope.ANY, credentials);
			httpClient.setCredentialsProvider(provider);
			
			HttpPut putRequest = new HttpPut(urlStr);
			
			putRequest.addHeader("accept", "application/json");

			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				String entityStr = om.writeValueAsString(entityMap);
				StringEntity input = new StringEntity(entityStr);
				input.setContentType("application/json");
				putRequest.setEntity(input);
			}

			HttpResponse response = httpClient.execute(putRequest);

			if (response.getStatusLine().getStatusCode() != 204) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent()), StandardCharsets.UTF_8));

			StringBuilder sb = new StringBuilder();
			String output;
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}
			
			return sb.toString();
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.getConnectionManager().shutdown();
		}
	}
	
	@SuppressWarnings("resource")
	public static String delete(String urlStr, String username, String password, String token) throws ClientProtocolException, IOException {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		try {
			CredentialsProvider provider = new BasicCredentialsProvider();
			UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(username, password);
			provider.setCredentials(AuthScope.ANY, credentials);
			httpClient.setCredentialsProvider(provider);
			
			HttpDelete deleteRequest = new HttpDelete(urlStr);
			deleteRequest.addHeader("accept", "application/json");
			
			HttpResponse response = httpClient.execute(deleteRequest);

			if (response.getStatusLine().getStatusCode() != 204) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(response.getEntity().getContent()), StandardCharsets.UTF_8));

			String output;
			StringBuilder sb = new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}

			return sb.toString();
		} catch (ClientProtocolException ex) {
			ex.printStackTrace();
			throw ex;
		} catch (IOException ex) {
			ex.printStackTrace();
			throw ex;
		} finally {
			httpClient.getConnectionManager().shutdown();
		}
	}
}

// ----------------------------------------------------------------------------------------------------
// TODO : 아래코드는 지우지 말것.
// 향후 ApacheHttpClient를 사용하게 될 경우, Deprecated된 라이브러리를 사용하지 않기 위해 아래 임시 활용 소스코드를 테스트하려고 준비해둠
// ----------------------------------------------------------------------------------------------------
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.nio.charset.StandardCharsets;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
//import org.apache.http.Consts;
//import org.apache.http.HttpEntity;
//import org.apache.http.HttpResponse;
//import org.apache.http.ParseException;
//import org.apache.http.auth.AuthScope;
//import org.apache.http.auth.UsernamePasswordCredentials;
//import org.apache.http.client.ClientProtocolException;
//import org.apache.http.client.CredentialsProvider;
//import org.apache.http.client.ResponseHandler;
//import org.apache.http.client.entity.UrlEncodedFormEntity;
//import org.apache.http.client.methods.HttpDelete;
//import org.apache.http.client.methods.HttpGet;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.client.methods.HttpPut;
//import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.BasicCredentialsProvider;
//import org.apache.http.impl.client.CloseableHttpClient;
//import org.apache.http.impl.client.DefaultHttpClient;
//import org.apache.http.impl.client.HttpClients;
//import org.apache.http.message.BasicNameValuePair;
//import org.apache.http.util.EntityUtils;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//class MyJSONResponseHandler implements ResponseHandler<JSONObject>{
//	public JSONObject handleResponse(final HttpResponse response) {
//			int status = response.getStatusLine().getStatusCode();
//			JSONObject returnData = new JSONObject();
//			JSONParser parser = new JSONParser();
//			if (status >= 200 && status < 300) {
//				HttpEntity entity = response.getEntity();
//				try {
//					
//					if(null == entity){
//						returnData.put("status_code", "1");
//						returnData.put("error_message", "null Data Found");
//					} else {
//						returnData = (JSONObject) parser.parse(EntityUtils.toString(entity));
//					}
//				} catch (ParseException | IOException | org.json.simple.parser.ParseException e) {
//					returnData.put("status_code", "1");
//					returnData.put("error_message", e.getMessage());
//				}
//			} else {
//				returnData.put("status_code", "1");
//				returnData.put("error_message", "Unexpected response status: " + status);
//			}
//			
//			return returnData;
//	}
//	
//	public static void main(String[] args) {
//		
//		//Take Input from User for Username and Password
//		String uname = "";
//		String pass = "";
//		
//		String token = "";
//		
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		try {
//			LOG.warning("Enter Username");
//			uname = br.readLine();
//			LOG.warning("Enter Password");
//			pass = br.readLine();
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		
//		
//		// Creates a reference to CloseableHttpClient, which is thread safe
//		CloseableHttpClient httpclient = HttpClients.createDefault();
//		ResponseHandler responseHandler = (ResponseHandler) new MyJSONResponseHandler();
//		
//		try {
//			HttpPost httpost = new HttpPost("http://localhost/httpclient/loginexample.php");
//
//			List params = new ArrayList();
//			params.add(new BasicNameValuePair("username", uname));
//			params.add(new BasicNameValuePair("password", pass));
//			
//			httpost.setEntity(new UrlEncodedFormEntity(params, Consts.UTF_8));
//			
//			JSONObject responseBody = (JSONObject) httpclient.execute(httpost, responseHandler);
//			String statusCode = (String) responseBody.get("status_code");
//			if(statusCode.equalsIgnoreCase("0")){
//				JSONObject data = (JSONObject) responseBody.get("data");
//				token = (String) data.get("token"); // Keep Token for future refferences
//			} 
//
//			LOG.warning(responseBody.get("error_message"));
//		} catch(IOException e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				httpclient.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//
//	}
//}

