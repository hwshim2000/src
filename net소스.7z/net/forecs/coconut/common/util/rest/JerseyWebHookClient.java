package net.forecs.coconut.common.util.rest;

import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import net.forecs.coconut.common.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

public class JerseyWebHookClient {
	private static final Logger LOG = Logger.getLogger(JerseyWebHookClient.class);
	private final static String HEADER_AUTHORIZATION = "Authorization";
//	private final static String HEADER_AUTHORIZATION = "X-ImpTokenHeader";
	
	public static String get(String urlStr, String token) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);
			
			ClientResponse response = webResource
					.header(HEADER_AUTHORIZATION, token)
					.accept("application/json")
					.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

	public static String post(String urlStr, String token, Map<String, Object> entityMap) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);

			String input = null;
			if (entityMap != null) {
				ObjectMapper om = new ObjectMapper();
				input = om.writeValueAsString(entityMap);
			}
			
			ClientResponse response;
			if (input != null) {
				response = webResource
						.header(HEADER_AUTHORIZATION, token)
						.type("application/json")
						.post(ClientResponse.class, input);
			} else {
				response = webResource
						.header(HEADER_AUTHORIZATION, token)
						.type("application/json")
						.post(ClientResponse.class);
			}
			
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String delete(String urlStr, String token) throws Exception {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);
			ClientResponse response = webResource
					.header(HEADER_AUTHORIZATION, token)
					.accept("application/json")
					.delete(ClientResponse.class);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			return output;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	public static int post(String urlStr, Map<String, String> headerMap, MultivaluedMap<String, String> paramMap, String inputData) {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);
			webResource = webResource.queryParams(paramMap);
			
			Builder builder = webResource.accept(MediaType.APPLICATION_JSON);
			for(Map.Entry<String, String> entry : headerMap.entrySet()) {
				builder = builder.header(entry.getKey(), entry.getValue());
			}
			
			ClientResponse response = builder.post(ClientResponse.class, inputData);
			
			int statusCode = response.getStatus();
			
			return statusCode;
		} catch (UniformInterfaceException ex) {
			LOG.warning(ex.getMessage());
			return 901;
		} catch (ClientHandlerException ex) {
			LOG.warning(ex.getMessage());
			return 911;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return 921;
			//ex.printStackTrace();
			//throw ex;
		}
	}
	
	public static int hook(String urlStr, Map<String, String> headerMap, MultivaluedMap<String, String> paramMap, String inputData, String method) {
		try {
			Client client = Client.create();
			WebResource webResource = client.resource(urlStr);

			if ("get".equalsIgnoreCase(method)) {
				paramMap.putSingle("data", inputData);
			}
			webResource = webResource.queryParams(paramMap);
			
			Builder builder = webResource.accept(MediaType.APPLICATION_JSON);
			for(Map.Entry<String, String> entry : headerMap.entrySet()) {
				builder = builder.header(entry.getKey(), entry.getValue());
			}
			
			ClientResponse response = null;
			if ("get".equalsIgnoreCase(method)) {
				response = builder.get(ClientResponse.class);
			} else if ("delete".equalsIgnoreCase(method)) {
				response = builder.delete(ClientResponse.class, inputData);
			} else if ("put".equalsIgnoreCase(method)) {
				response = builder.put(ClientResponse.class, inputData);
			} else {
				response = builder.post(ClientResponse.class, inputData);
			}
			
			int statusCode = response.getStatus();
			return statusCode;
		} catch (UniformInterfaceException ex) {
			LOG.warning(ex.getMessage());
			return 901;
		} catch (ClientHandlerException ex) {
			LOG.warning(ex.getMessage());
			return 911;
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return 921;
		}
	}
}
