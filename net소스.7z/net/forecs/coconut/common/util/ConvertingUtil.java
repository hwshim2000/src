package net.forecs.coconut.common.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.common.Common;

import org.apache.commons.lang.IllegalClassException;

import com.google.appengine.api.datastore.Entity;

public class ConvertingUtil {
	private static final Logger LOG = Logger.getLogger(ConvertingUtil.class);
	public static Entity objectToEntity(Object obj) throws IllegalAccessException, IntrospectionException {
		try {
			if (!obj.getClass().getSuperclass().equals(Base.class) && !obj.getClass().getSuperclass().equals(Common.class)) {
				throw new IllegalClassException(obj.getClass().getName() + " is not supported class.");
			}
			//BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
			Entity entity = new Entity(obj.getClass().getSimpleName());
			
			return objectToEntity(entity, obj);
		} catch (IllegalAccessException ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} catch (IntrospectionException ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		} catch (IllegalClassException ex) {
			LOG.warning(ex.getMessage());
			throw ex;
		}
	}
	
	private static Entity objectToEntity(Entity entity, Object obj) throws IllegalAccessException, IntrospectionException {
		BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
		//Entity entity = new Entity(obj.getClass().getSimpleName());
	
		for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
			if ("key".equals(descriptor.getName()) || "class".equals(descriptor.getName()) || "super".equals(descriptor.getName())) continue;
			Field field = getPersistField(obj.getClass(), descriptor.getName());
			if (field != null) {
				//LOG.warning(field.getName() + ":" + field.getType());
				Object value = field.get(obj);
				if (value != null) {
					if (Collection.class.isAssignableFrom(field.getType())) {
						if (getListGenericType(field).isEnum()) {
							value = enumToStringList(value);
						}
					} else if (value.getClass().isEnum()) {
						value = value.toString();
					} else if (value.getClass().isArray()) {
						value = Arrays.asList((Object[])value);
					} else {
						if (isEmbeddedEntity(field)) {
							entity = objectToEntity(entity, value);
							continue;
						}
					}
				}
				entity.setProperty(field.getName(), value);
			}
		}
		return entity;
	}
	
	private static Field getPersistField(Class<?> clazz, String fieldName) {
		try {
			Field field = getField(clazz, fieldName);
			if (field == null
					|| field.isAnnotationPresent(java.lang.Deprecated.class)
					|| field.isAnnotationPresent(javax.persistence.Transient.class)
					//|| field.isAnnotationPresent(javax.persistence.Embedded.class)
					) { return null; }
			field.setAccessible(true);
			return field;
		} catch (Exception ex) {
			return null;
		}
	}
	
	@SuppressWarnings("unused")
	private static boolean isEmbeddedEntity(Class<?> clazz, String fieldName) {
		Field field = getField(clazz, fieldName);
		
		if (field != null && field.isAnnotationPresent(javax.persistence.Embedded.class)) {
			return true;
		}
		return false;
	}
	private static boolean isEmbeddedEntity(Field field) {
		if (field != null && field.isAnnotationPresent(javax.persistence.Embedded.class)) {
			return true;
		}
		return false;
	}
	
	private static Field getField(Class<?> clazz, String fieldName) {
		try {
			return clazz.getDeclaredField(fieldName);
		} catch (NoSuchFieldException ex) {
			Class<?> superClass = clazz.getSuperclass();
			if (superClass != null) {
				return getField(superClass, fieldName);
			} else {
				return null;
			}
		}
	}

	@SuppressWarnings("unused")
	private static Class<?> getListGenericType(Class<?> clazz, String fieldName)
			throws NoSuchFieldException {
		try {
			Field field = clazz.getDeclaredField(fieldName);
			return getListGenericType(field);
		} catch (NoSuchFieldException ex) {
			throw ex;
		}
	}
	
	private static Class<?> getListGenericType(Field field) {
		ParameterizedType fieldType = (ParameterizedType) field
				.getGenericType();
		Class<?> type = (Class<?>) fieldType.getActualTypeArguments()[0];
		return type;
	}
	private static List<String> enumToStringList(Object enumList) {
		List<String> wdtStr = new ArrayList<String>();
		if (enumList instanceof Collection) {
			@SuppressWarnings({ "rawtypes", "unchecked" })
			Iterator<? extends Enum> itor = ((Collection<? extends Enum>)enumList).iterator();
			while(itor.hasNext()) {
				Object obj = itor.next();
				Class<?> colType = obj.getClass();//Something
				if (colType.isEnum()) {
			    	wdtStr.add(obj.toString());
			    } else {
			    	break;
			    }
			}
		}
		return wdtStr;
	}
	
	@SuppressWarnings("unused")
	@Deprecated
	private static <T extends Base> T entityToObject(Class<T> clazz, Entity entity) throws Exception {
		try {
			Map<String, Object> entityMap = entity.getProperties();
			T obj = clazz.newInstance();
			for(Map.Entry<String, Object> entry : entityMap.entrySet()) {
				Field field = clazz.getField(entry.getKey());
				field.set(obj, entry.getValue());
			}
			
			return obj;
		} catch (Exception ex) {
			throw ex;
		}
	}
	
//	private static <T extends Enum<T>> List<String> toStringList(Class<T> clz) {
//		if (clz)
//	     try {
//	        List<String> res = new LinkedList<String>();
//	        Method getDisplayValue = clz.getMethod("getDisplayValue");
//
//	        for (Object e : clz.getEnumConstants()) {
//	            res.add((String) getDisplayValue.invoke(e));
//
//	        }
//
//	        return res;
//	    } catch (Exception ex) {
//	        throw new RuntimeException(ex);
//	    }
//	}
	
	@SuppressWarnings("unused")
	@Deprecated
	private static boolean isPersistField(Class<?> clazz, String fieldName) {
		try {
			//Field field = clazz.getDeclaredField(fieldName);
			Field field = getField(clazz, fieldName);
			if (field == null
					|| field.isAnnotationPresent(java.lang.Deprecated.class)
					|| field.isAnnotationPresent(javax.persistence.Transient.class)
					) { return false; }
			return true;
			//LOG.warning("IS Deprecated "+field.getName() +" : " +field.isAnnotationPresent(java.lang.Deprecated.class));
			//Annotation[] ann = field.getDeclaredAnnotations(); //do something to these\
			
//			for (Annotation anno : ann) {
//        		LOG.warning("========="+anno.annotationType().toString());
//	        	//LOG.warning(anno.toString());
//	        	if (anno.annotationType().equals(java.lang.Deprecated.class) ||
//	        			anno.annotationType().equals(javax.persistence.Transient.class) ||
//	        			anno.annotationType().equals(com.fasterxml.jackson.annotation.JsonIgnore.class)) {
//	        		LOG.warning("0:"+field.getName());
//	        	} else {
//	        		LOG.warning("1:"+field.getName());
//	        	}
//	        }
			//return isPersistField(ann);
		} catch (Exception ex) {
			return false;
		}
	}
/*	
	public static void test() {
		try {
			List<Tasks> taskList = new ArrayList<Tasks>();
			List<Entity> enList = new ArrayList<Entity>();
			for (int i=0; i < 1; i++) {
				Tasks task = new Tasks();
				task.setKey(KeyUtil.createTaskKey());
				task.setTitle("test title "+i);
				task.setDescription(new Text("desc test" + i));
				taskList.add(task);
				
				enList.add(objectToEntity(task));
			}
			
			List<WeekDayType> wdt = new ArrayList<WeekDayType>();
			wdt.add(WeekDayType.SU);
			wdt.add(WeekDayType.MO);
			Recurrence recurr = new Recurrence();
			recurr.setFrequency(Frequency.DAILY);
			recurr.setInterval(1);
			recurr.setByDays(wdt);
			Events event = new Events();
			
			event.setKey(KeyUtil.createEventKey());
			event.setTitle("event title");
			event.setCreated(new Date());
			event.setRecurrence(recurr);
			event.setRecurrenceYN("Y");
			event.setStartDate(CalendarUtil.toDate("20150101", "yyyyMMdd"));
			event.setEndDate(CalendarUtil.toDate("20150102", "yyyyMMdd"));
			enList.add(objectToEntity(event));
			
			
			Activities activity = new Activities();
			activity.setKey(KeyUtil.createActivityKey());
			activity.setTaskId("test");
			activity.setMsgParams(new String[] { "1", "2", "3" });
			
			enList.add(objectToEntity(activity));
			
			DatastoreService dsService = DatastoreServiceFactory.getDatastoreService();
			//TransactionOptions txo = TransactionOptions.Builder.withXG(true);
			//TransactionOptions txo = TransactionOptions.Builder.withDefaults();
			
			//Transaction tx = dsService.beginTransaction(txo);
			
			List<Key> keyList = dsService.put(enList);
			
			Map<Key, Entity> resultMap = dsService.get(keyList);
			
			for (Entity en : resultMap.values()) {
				LOG.warning(en);
			}
			
			//if (tx.isActive()) { LOG.warning(enList.size() + "  TXXXXXXXXXXXXXX"); tx.commit(); }
		} catch (Exception ex) { ex.printStackTrace();}
	}
	*/
}
