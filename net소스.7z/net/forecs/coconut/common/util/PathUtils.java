package net.forecs.coconut.common.util;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;

import net.forecs.coconut.common.CommonProperty;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.routines.UrlValidator;

public class PathUtils {

	public static String getPath(String url) throws Exception {
		return getPath(new URI(url));
	}
	
	public static String getPath(URI uri) throws Exception {
		return FilenameUtils.getFullPathNoEndSeparator(uri.toString());
		
	}
	
	public static String getFullHost(URL url) {
		String host = String.format("%s://%s%s"
	    		, url.getProtocol()
	    		, url.getHost()
	    		, url.getPort()==80||url.getPort()==-1?"":":"+url.getPort() 
    		);
		return host;
	}
	
	public static String makeAbsolutePath(URL baseUrl, String path) {
		try {
			if (baseUrl == null) { return path; }
			if (path.startsWith("#")) { return path; }
			if (StringUtils.startsWithIgnoreCase(path, "javscript:")) { return path; }
			if (StringUtils.isBlank(path)) { return baseUrl.toString(); }
			if (path.startsWith("//")) { return path; }	// absolutePath;
			if (new URI(path).isAbsolute()) { return path; }
			
			path = StringUtils.replace(path, "\\", "/");
			path = StringUtils.replace(path, "//", "/");
			String host = getFullHost(baseUrl);
			String base = baseUrl.toString();
			String absPath = null;
			
			if (path.startsWith("/")) {
				absPath = host + path;
				
			} else if (path.startsWith("../")) {
				absPath = makeParentPath(FilenameUtils.getFullPathNoEndSeparator(base), path.substring(3)); 
			} else if (path.startsWith("./")) {
				absPath = FilenameUtils.getFullPath(base) + path.substring(2);
			} else {
				absPath = FilenameUtils.getFullPath(base) + path;
			}
			
			UrlValidator uv = new UrlValidator();
			if (uv.isValid(absPath)) {
				return absPath;
			} else {
				return baseUrl.toString();
			}
		} catch (URISyntaxException ex) {
			return path;
		}
	}
	
	private static String makeParentPath(String base, String path) {
		base = FilenameUtils.getFullPathNoEndSeparator(base);
		if (path.startsWith("../")) {
			return makeParentPath(base, path.substring(3)); 
		} else {
			return base+"/"+path;
		}
	}
	public static String getExtension(String path) {
		try {
			URI uri = new URI(path);
			return FilenameUtils.getExtension(uri.getPath());
		} catch (Exception ex) { return null; }
	}
	
	public static String encodeQueryString(String urlString) throws UnsupportedEncodingException, MalformedURLException {
		URL url = new URL(urlString);
		String urlStr = url.toString();
		String[] paths = urlStr.split("\\?");
		if (paths.length != 2) { return urlStr; }
		String[] qrStr = paths[1].split("&");
		if (qrStr.length < 1) { return urlStr; }
		
		String encodedQryStr = paths[0] + "?";
		
		for (int i=0; i < qrStr.length; i++) {
			if (i > 0) { encodedQryStr += "&"; }
			String[] pair = qrStr[i].split("=");
			if (pair.length==2) { encodedQryStr = encodedQryStr + pair[0] + "=" + URLEncoder.encode(URLDecoder.decode(pair[1], CommonProperty.UTF_8), CommonProperty.UTF_8); }
			else { encodedQryStr = encodedQryStr + qrStr[i] + "="; }
			
		}
		//System.out.println(encodedQryStr);
		return encodedQryStr;
	}
	
	public static void main(String[] args) throws Exception {
		String uriStr = "http://static.news.naver.net/image/news/2011/banner_assembly.gif?a=b&c=af";
//		URI baseUri = new URI(uriStr);
//		System.out.println(baseUri.getPath());
//		System.out.println(FilenameUtils.getExtension(baseUri.getPath()));
//		//String path = "/images.png";
//		System.out.println(baseUri.isAbsolute());
//		
//		String host = String.format("%s://%s%s"
//	    		, baseUri.getScheme()
//	    		, baseUri.getHost()
//	    		, baseUri.getPort()==80||baseUri.getPort()==-1?"":":"+baseUri.getPort() 
//    		);
//		System.out.println(baseUri.getPath());
//		System.out.println(baseUri.toString());
//		//System.out.println(baseUri.toURI());
//		System.out.println(host);
		
		//System.out.println(makeAbsolutePath(baseUri, path));
		URL url = new URL(uriStr);
		String	 host = String.format("%s://%s%s"
		    		, url.getProtocol()
		    		, url.getHost()
		    		, url.getPort()==80||url.getPort()==-1?"":":"+url.getPort() 
	    		);
		System.out.println(host);
		System.out.println(url.getPath());
		System.out.println(url.toString());
		System.out.println(URLEncoder.encode(uriStr, CommonProperty.UTF_8));
	}
	
	
}
