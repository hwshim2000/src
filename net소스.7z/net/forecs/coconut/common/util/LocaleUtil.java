package net.forecs.coconut.common.util;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import net.forecs.coconut.endpoint.setting.UserSettingService;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.user.Users;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LocaleUtil {
	public final static Locale DEFAULT_LOCALE = Locale.KOREA;
	
	private final static Map<String, Locale> localeMap;
	static {
		localeMap = new HashMap<String, Locale>();
		localeMap.put("ko_kr", Locale.KOREA);
		localeMap.put("ko-kr", Locale.KOREA);
		localeMap.put("ko", Locale.KOREA);
		localeMap.put("kr", Locale.KOREA);
		localeMap.put("en_us", Locale.US);
		localeMap.put("en-us", Locale.US);
		localeMap.put("en", Locale.US);
		localeMap.put("us",  Locale.US);
		localeMap.put("zh_cn", Locale.CHINA);
		localeMap.put("zh-cn", Locale.CHINA);
		localeMap.put("zh", Locale.CHINA);
		localeMap.put("cn",  Locale.CHINA);
		localeMap.put("zh_tw", Locale.TAIWAN);
		localeMap.put("zh-tw", Locale.TAIWAN);
		localeMap.put("tw",  Locale.TAIWAN);
	}
	
	public static Locale getUserLocale(String userId) {
		UserSetting userSetting = null;
		if (StringUtils.isNotBlank(userId)) {
			userSetting = UserSettingService.getUserLocaleSetting(userId);
		}
		return getUserLocale(userSetting);
	}
	public static Locale getUserLocale(Users user) {
		UserSetting userSetting = null;
		
		if (user != null) {
			userSetting = UserSettingService.getUserLocaleSetting(user.getUserId());
		}
		return getUserLocale(userSetting);
	}
	public static Locale getUserLocale(UserSetting userSetting) {
		if (userSetting != null && userSetting.getValue() != null && userSetting.getValue().getValue() != null) {
			return parseLocale(userSetting.getValue().getValue());
		} else {
			return DEFAULT_LOCALE;
		}
	}

	public static Locale parseLocale(String settings) {
		try {
			JsonFactory factory = new JsonFactory();
			ObjectMapper om = new ObjectMapper(factory);
			
			JsonNode jn = om.readTree(settings);
			
			//LOG.warning(jn.findValue("code").textValue());
        	//LOG.warning(jn.findPath("code"));
        	//LOG.warning(jn.get("general").get("language").get("code").textValue());
        	
			String strLocale = jn.get("general").get("language").get("code").textValue();
			Locale locale = DEFAULT_LOCALE;
			if (StringUtils.isNotEmpty(strLocale)) {
				locale = localeMap.get(strLocale.toLowerCase());
			}
			
			if (locale == null) { locale = DEFAULT_LOCALE; }
			
			return locale;
		} catch (Exception ex) {
			return DEFAULT_LOCALE;
		}
	}
}
