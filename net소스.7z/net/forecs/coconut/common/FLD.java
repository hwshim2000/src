package net.forecs.coconut.common;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.forecs.coconut.common.code.billing.CancelInfo;
import net.forecs.coconut.common.code.billing.Schedule;
import net.forecs.coconut.entity.activity.Activities;
import net.forecs.coconut.entity.activity.Notifications;
import net.forecs.coconut.entity.attachment.Attachments;
import net.forecs.coconut.entity.attachment.AttachmentsMap;
import net.forecs.coconut.entity.attachment.Emoticons;
import net.forecs.coconut.entity.attachment.Images;
import net.forecs.coconut.entity.attachment.Uploads;
import net.forecs.coconut.entity.backup.Backups;
import net.forecs.coconut.entity.billing.Bills;
import net.forecs.coconut.entity.billing.Coupons;
import net.forecs.coconut.entity.billing.Customers;
import net.forecs.coconut.entity.billing.ServiceGrades;
import net.forecs.coconut.entity.billing.Usage;
import net.forecs.coconut.entity.billing.UsageLogs;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.calendar.Calendars;
import net.forecs.coconut.entity.calendar.Events;
import net.forecs.coconut.entity.calendar.Recurrence;
import net.forecs.coconut.entity.channel.ChannelToken;
import net.forecs.coconut.entity.channel.WebHook;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.common.Common;
import net.forecs.coconut.entity.domain.Departments;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.DomainsLog;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.email.AdminEMailNotice;
import net.forecs.coconut.entity.group.Groups;
import net.forecs.coconut.entity.manage.Feedbacks;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.notice.Notice;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.entity.setting.NotificationSettings;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.subscription.Subscriptions;
import net.forecs.coconut.entity.survey.SurveyAnswers;
import net.forecs.coconut.entity.survey.SurveyItems;
import net.forecs.coconut.entity.survey.SurveyQuestions;
import net.forecs.coconut.entity.tasklist.Tasklists;
import net.forecs.coconut.entity.user.GaeUser;
import net.forecs.coconut.entity.user.RegCode;
import net.forecs.coconut.entity.user.UserCounter;
import net.forecs.coconut.entity.user.UserDevices;
import net.forecs.coconut.entity.user.UserProfiles;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskChecklistHistories;
import net.forecs.coconut.entity.workspace.TaskChecklists;
import net.forecs.coconut.entity.workspace.TaskHistories;
import net.forecs.coconut.entity.workspace.TaskLabelMap;
import net.forecs.coconut.entity.workspace.TaskLabels;
import net.forecs.coconut.entity.workspace.TaskTimelineComments;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.search.index.AttachmentIndex;
import net.forecs.coconut.search.index.CommentIndex;
import net.forecs.coconut.search.index.EventIndex;
import net.forecs.coconut.search.index.NoticeIndex;
import net.forecs.coconut.search.index.TaskIndex;
import net.forecs.coconut.search.index.TimelineIndex;

public final class FLD {
	// -------------------------------------
	// --- CUSTOM FIELD(don't overwrite) ---
	public final static String domain = "domain";
	public final static String domainNames = "domainNames";
	public final static String editable = "editable";
	public final static String regCode = "regCode";
	public final static String rememberMe = "rememberMe";
	public final static String limit = "limit";
	public final static String cursor = "cursor";
	public final static String currentPassword = "currentPassword";
	public final static String newPassword = "newPassword";
	public final static String newEmail = "newEmail";
	public final static String birthDay = "birthDay";
	public final static String namespace = "namespace";
	public final static String fromUserType = "fromUserType";
	public final static String toUserType = "toUserType";
	public final static String property = "property";
	public final static String groupQuota = "groupQuota";
	public final static String taskQuota = "taskQuotas";
	public final static String couponCount = "couponCount";
	public final static String includeDefault = "includeDefault";
	public final static String indexKind = "indexKind";
	public final static String alarmDateTimeMillis = "alarmDateTimeMillis";
	public final static String userIdList = "userIdList";
	public final static String targetUserId = "targetUserId";
	public final static String boardIds = "boardIds";
	public final static String cipherText = "cipherText";
	public final static String recurrenceChangeType = "recurrenceChangeType";
	public final static String boardIdList = "boardIdList";
	public final static String targetUsers = "targetUsers";
//	public final static String contentType = "contentType";
	public final static String expiresIn = "expiresIn";
	public final static String parentNoticeCommentId = "parentNoticeCommentId";
	public final static String sortType = "sortType";
	public final static String sortDirection = "sortDirection";
	public final static String assignedStartDate = "assignedStartDate";
	public final static String assignedEndDate = "assignedEndDate";
	public final static String groupIds = "groupIds";
	public final static String searchAreas = "searchAreas";
	public final static String searchStr = "searchStr";
	public final static String settingName = "settingName";
	public final static String parentTaskChecklistCommentId = "parentTaskChecklistCommentId";
	public final static String parentTaskCommentId = "parentTaskCommentId";
	public final static String sourceHistoryId = "sourceHistoryId";
	public final static String targetHistoryId = "targetHistoryId";
	public final static String compareMode = "compareMode";
	public final static String insertedColor = "insertedColor";
	public final static String deletedColor = "deletedColor";
	public final static String taskLabelIds = "taskLabelIds";
	public final static String subscribe = "subscribe";
	public final static String oldAttachmentId = "oldAttachmentId";
	public final static String newAttachmentId = "newAttachmentId";
	public final static String serviceUri = "serviceUri";
	public final static String notificationIdList = "notificationIdList";
	public final static String activityIdList = "activityIdList";
	public final static String userBaseUrl = "userBaseUrl";
	public final static String social_site = "social.site";
	public final static String admin_email = "admin.email";
	public final static String keys = "keys";
	public final static String toAddress = "toAddress";
	public final static String isDefault = "isDefault";
	public final static String isOverwrite = "isOverwrite";
	public final static String activity = "activity";
	public final static String jsonString = "jsonString";
	
	public final static String status = "status";
	public final static String schedules = "schedules";
	public final static String usage = "usage";
	public final static String includeProfile = "includeProfile";
	
	public final static String serviceHost = "serviceHost";
	public final static String loginTimes = "loginTimes";
	
	public final static String encoding = "encoding";
	public final static String options = "options";
	public final static String source = "source";
	public final static String accessDate = "accessDate";
	
	public final static String stageIds = "stageIds";
	
	// for gsuite(deprecated or not used) --------------------------
	public final static String userKey = "userKey";
	public final static String userKeys = "userKeys";
	public final static String gsuiteCustomerId = "gsuiteCustomerId";
	
	public final static String fromTaskStage = "fromTaskStage";
	public final static String toTaskStage = "toTaskStage";
	public final static String taskIds = "taskIds";
	@Deprecated
	public final static String guestId = "guestId";
	
	public final static String prefix = "prefix";
	public final static String googleAccessToken = "googleAccessToken";
	
	public final static String checked = "checked";
	public final static String includeItems = "includeItems";
	public final static String includeAnswers = "includeAnswers";
	public final static String enableTree = "enableTree";
	public final static String makeVirtual = "makeVirtual";
	
	// -------------------------------------
	
	// -------------------------------------
	// --- ENTITY FIELD ---
	// -------------------------------------
	public final static String accessRole = "accessRole";
	public final static String accessToken = "accessToken";
	public final static String accessType = "accessType";
	public final static String active = "active";
	public final static String activeYN = "activeYN";
	public final static String activities = "activities";
	public final static String activityId = "activityId";
	public final static String activityKind = "activityKind";
	public final static String activityType = "activityType";
	public final static String address = "address";
	public final static String addresses = "addresses";
	public final static String admin = "admin";
	public final static String adminEMailNoticeId = "adminEMailNoticeId";
	public final static String agent = "agent";
	public final static String agentCheck = "agentCheck";
	public final static String alarmDateTime = "alarmDateTime";
	public final static String alarmTriggerType = "alarmTriggerType";
	public final static String alarmTriggerValue = "alarmTriggerValue";
	public final static String alarmYN = "alarmYN";
	public final static String allDayYN = "allDayYN";
	public final static String amount = "amount";
	public final static String anniversaryType = "anniversaryType";
	public final static String answer = "answer";
	public final static String answerDate = "answerDate";
	public final static String answerer = "answerer";
	public final static String answers = "answers";
	public final static String archiveYN = "archiveYN";
	public final static String archived = "archived";
	public final static String area = "area";
	public final static String assignMembers = "assignMembers";
	public final static String assignUserIds = "assignUserIds";
	public final static String assignee = "assignee";
	public final static String attachmentBytes = "attachmentBytes";
	public final static String attachmentCount = "attachmentCount";
	public final static String attachmentId = "attachmentId";
	public final static String attachments = "attachments";
	public final static String auth = "auth";
	public final static String authId = "authId";
	public final static String authKind = "authKind";
	public final static String authStatus = "authStatus";
	public final static String avgBytes = "avgBytes";
	public final static String avgUsers = "avgUsers";
	public final static String backupId = "backupId";
	public final static String backupName = "backupName";
	public final static String backupPath = "backupPath";
	public final static String billId = "billId";
	public final static String billd = "billd";
	public final static String birth = "birth";
	public final static String birthday = "birthday";
	public final static String birthdayLeap = "birthdayLeap";
	public final static String blockReason = "blockReason";
	public final static String blockType = "blockType";
	public final static String boardCount = "boardCount";
	public final static String boardCreated = "boardCreated";
	public final static String boardId = "boardId";
	public final static String boardLogo = "boardLogo";
	public final static String boardQuota = "boardQuota";
	public final static String boardTitle = "boardTitle";
	public final static String bucket = "bucket";
	public final static String bulitinIndexBytes = "bulitinIndexBytes";
	public final static String bulitinIndexCount = "bulitinIndexCount";
	public final static String buyer_addr = "buyer_addr";
	public final static String buyer_email = "buyer_email";
	public final static String buyer_name = "buyer_name";
	public final static String buyer_postcode = "buyer_postcode";
	public final static String buyer_tel = "buyer_tel";
	public final static String byDays = "byDays";
	public final static String byHours = "byHours";
	public final static String byMinutes = "byMinutes";
	public final static String byMonthDays = "byMonthDays";
	public final static String byMonths = "byMonths";
	public final static String bySeconds = "bySeconds";
	public final static String bySetPositions = "bySetPositions";
	public final static String byWeekNumbers = "byWeekNumbers";
	public final static String byYearDays = "byYearDays";
	public final static String bytes = "bytes";
	public final static String calendarId = "calendarId";
	public final static String card_name = "card_name";
	public final static String card_number = "card_number";
	public final static String caseInsensitive = "caseInsensitive";
	public final static String category = "category";
	public final static String changePermit = "changePermit";
	public final static String channelKey = "channelKey";
	public final static String channelTokenId = "channelTokenId";
	public final static String chargeable = "chargeable";
	public final static String checkYN = "checkYN";
	public final static String checklistId = "checklistId";
	public final static String checklists = "checklists";
	public final static String children = "children";
	public final static String childs = "childs";
	public final static String city = "city";
	public final static String clientId = "clientId";
	public final static String closeYN = "closeYN";
	public final static String code = "code";
	public final static String color = "color";
	public final static String commentDescription = "commentDescription";
	public final static String commentId = "commentId";
	public final static String commentTitle = "commentTitle";
	public final static String commentType = "commentType";
	public final static String comments = "comments";
	public final static String completeDate = "completeDate";
	public final static String compositeIndexBytes = "compositeIndexBytes";
	public final static String compositeIndexCount = "compositeIndexCount";
	public final static String confirmToken = "confirmToken";
	public final static String confirmYN = "confirmYN";
	public final static String connected = "connected";
	public final static String connectedDate = "connectedDate";
	public final static String contact = "contact";
	public final static String contactMap = "contactMap";
	public final static String content = "content";
	public final static String contentType = "contentType";
	public final static String convertMap = "convertMap";
	public final static String count = "count";
	public final static String couponCode = "couponCode";
	public final static String couponId = "couponId";
	public final static String createBoardAuth = "createBoardAuth";
	public final static String createNoticeAuth = "createNoticeAuth";
	public final static String createScheduleAuth = "createScheduleAuth";
	public final static String createTaskAuth = "createTaskAuth";
	public final static String created = "created";
	public final static String creator = "creator";
	public final static String customer = "customer";
	public final static String customerId = "customerId";
	public final static String customer_uid = "customer_uid";
	public final static String dateRegistered = "dateRegistered";
	public final static String dayOffYN = "dayOffYN";
	public final static String defaultYN = "defaultYN";
	public final static String deleteYN = "deleteYN";
	public final static String deleted = "deleted";
	public final static String department = "department";
	public final static String departmentId = "departmentId";
	public final static String deptCode = "deptCode";
	public final static String depth = "depth";
	public final static String description = "description";
	public final static String disable = "disable";
	public final static String displayInCalendarYN = "displayInCalendarYN";
	public final static String displayYN = "displayYN";
	public final static String domainId = "domainId";
	public final static String domainName = "domainName";
	public final static String domainsLogId = "domainsLogId";
	public final static String downloads = "downloads";
	public final static String dueDate = "dueDate";
	public final static String editChecklistPermission = "editChecklistPermission";
	public final static String editDetailPermission = "editDetailPermission";
	public final static String editableYN = "editableYN";
	public final static String email = "email";
	public final static String emailPushYN = "emailPushYN";
	public final static String emails = "emails";
	public final static String emoticon = "emoticon";
	public final static String emoticonId = "emoticonId";
	public final static String emoticonImages = "emoticonImages";
	public final static String endDate = "endDate";
	public final static String endDateOffset = "endDateOffset";
	public final static String entityBytes = "entityBytes";
	public final static String evalEfforts = "evalEfforts";
	public final static String evalExcellents = "evalExcellents";
	public final static String evalGoods = "evalGoods";
	public final static String event = "event";
	public final static String eventGroupId = "eventGroupId";
	public final static String eventId = "eventId";
	public final static String eventType = "eventType";
	public final static String events = "events";
	public final static String exceptionDates = "exceptionDates";
	public final static String excepts = "excepts";
	public final static String excutionDate = "excutionDate";
	public final static String expirationCheckDays = "expirationCheckDays";
	public final static String expirationDate = "expirationDate";
	public final static String expire = "expire";
	public final static String expireIn = "expireIn";
	public final static String expiry = "expiry";
	public final static String fax = "fax";
	public final static String faxNationCode = "faxNationCode";
	public final static String feedbackId = "feedbackId";
	public final static String fileName = "fileName";
	public final static String filePath = "filePath";
	public final static String fileSize = "fileSize";
	public final static String fileUrl = "fileUrl";
	public final static String forcePasswordChangeYN = "forcePasswordChangeYN";
	public final static String frequency = "frequency";
	public final static String gcmId = "gcmId";
	public final static String gender = "gender";
	public final static String gigaPerUser = "gigaPerUser";
	public final static String groupId = "groupId";
	public final static String gsuiteCustomerID = "gsuiteCustomerID";
	public final static String gsuiteServiceAccount = "gsuiteServiceAccount";
	public final static String guest = "guest";
	public final static String headerFixYN = "headerFixYN";
	public final static String headerMap = "headerMap";
	public final static String hostDomain = "hostDomain";
	public final static String htmlLink = "htmlLink";
	public final static String iamportBill = "iamportBill";
	public final static String icon = "icon";
	public final static String id = "id";
	public final static String image = "image";
	public final static String imageBytes = "imageBytes";
	public final static String imageCount = "imageCount";
	public final static String imageId = "imageId";
	public final static String imageSize = "imageSize";
	public final static String images = "images";
	public final static String imp_uid = "imp_uid";
	public final static String importance = "importance";
	public final static String includeEmpty = "includeEmpty";
	public final static String includeNull = "includeNull";
	public final static String inserted = "inserted";
	public final static String insertedDate = "insertedDate";
	public final static String interval = "interval";
	public final static String issueDate = "issueDate";
	public final static String issueTarget = "issueTarget";
	public final static String issueYN = "issueYN";
	public final static String issuer = "issuer";
	public final static String jobTitle = "jobTitle";
	public final static String jwsAccessToken = "jwsAccessToken";
	public final static String key = "key";
	public final static String kind = "kind";
	public final static String kindId = "kindId";
	public final static String label = "label";
	public final static String labels = "labels";
	public final static String lastCommented = "lastCommented";
	public final static String lastModified = "lastModified";
	public final static String leap = "leap";
	public final static String linkURL = "linkURL";
	public final static String links = "links";
	public final static String local = "local";
	public final static String location = "location";
	public final static String logType = "logType";
	public final static String loginDate = "loginDate";
	public final static String logoutDate = "logoutDate";
	public final static String lowerId = "lowerId";
	public final static String lunarEndDate = "lunarEndDate";
	public final static String lunarRecurrenceDate = "lunarRecurrenceDate";
	public final static String lunarStartDate = "lunarStartDate";
	public final static String mail = "mail";
	public final static String mailMessage = "mailMessage";
	public final static String mailTitle = "mailTitle";
	public final static String manager = "manager";
	public final static String marriedYN = "marriedYN";
	public final static String member = "member";
	public final static String memberAuthId = "memberAuthId";
	public final static String memberId = "memberId";
	public final static String memberIds = "memberIds";
	public final static String memberRequests = "memberRequests";
	public final static String members = "members";
	public final static String memorials = "memorials";
	public final static String mention = "mention";
	public final static String mentionIds = "mentionIds";
	public final static String mentionedUserNames = "mentionedUserNames";
	public final static String merchant_uid = "merchant_uid";
	public final static String message = "message";
	public final static String messengers = "messengers";
	public final static String method = "method";
	public final static String mimeType = "mimeType";
	public final static String mobilePushYN = "mobilePushYN";
	public final static String model = "model";
	public final static String modified = "modified";
	public final static String msgParams = "msgParams";
	public final static String name = "name";
	public final static String nation = "nation";
	public final static String nationCode = "nationCode";
	public final static String nextPageToken = "nextPageToken";
	public final static String nickName = "nickName";
	public final static String note = "note";
	public final static String noticeId = "noticeId";
	public final static String noticeKind = "noticeKind";
	public final static String notification = "notification";
	public final static String notificationId = "notificationId";
	public final static String notificationSettingId = "notificationSettingId";
	public final static String notificationType = "notificationType";
	public final static String notificationUserIds = "notificationUserIds";
	public final static String nuts = "nuts";
	public final static String obj = "obj";
	public final static String objectId = "objectId";
	public final static String online = "online";
	public final static String ordernum = "ordernum";
	public final static String organization = "organization";
	public final static String os = "os";
	public final static String osVersion = "osVersion";
	public final static String owner = "owner";
	public final static String paidStatus = "paidStatus";
	public final static String paramMap = "paramMap";
	public final static String parent = "parent";
	public final static String parentDeptCode = "parentDeptCode";
	public final static String parentId = "parentId";
	public final static String password = "password";
	public final static String passwordHash = "passwordHash";
	public final static String paymentDate = "paymentDate";
	public final static String paymentEnd = "paymentEnd";
	public final static String period = "period";
	public final static String permanentDeleteYN = "permanentDeleteYN";
	public final static String permissions = "permissions";
	public final static String phone = "phone";
	public final static String phoneNationCode = "phoneNationCode";
	public final static String picture = "picture";
	public final static String pictureURL = "pictureURL";
	public final static String post = "post";
	public final static String pricePerGiga = "pricePerGiga";
	public final static String pricePerUser = "pricePerUser";
	public final static String primary = "primary";
	public final static String priority = "priority";
	public final static String progress = "progress";
	public final static String publicSearchRange = "publicSearchRange";
	public final static String pwd_2digit = "pwd_2digit";
	public final static String read = "read";
	public final static String reason = "reason";
	public final static String recurrence = "recurrence";
	public final static String recurrenceDate = "recurrenceDate";
	public final static String recurrenceId = "recurrenceId";
	public final static String recurrenceYN = "recurrenceYN";
	public final static String refObj = "refObj";
	public final static String refresh = "refresh";
	public final static String refreshExpire = "refreshExpire";
	public final static String refreshToken = "refreshToken";
	public final static String refund_account = "refund_account";
	public final static String refund_bank = "refund_bank";
	public final static String refund_holder = "refund_holder";
	public final static String registered = "registered";
	public final static String relations = "relations";
	public final static String requestMembers = "requestMembers";
	public final static String require = "require";
	public final static String restoreRequesetDate = "restoreRequesetDate";
	public final static String restoreRequest = "restoreRequest";
	public final static String restoreRequestUserId = "restoreRequestUserId";
	public final static String restoreResult = "restoreResult";
	public final static String retryCount = "retryCount";
	public final static String retryTerm = "retryTerm";
	public final static String role = "role";
	public final static String roles = "roles";
	public final static String rootNode = "rootNode";
	public final static String salt = "salt";
	public final static String satisfaction = "satisfaction";
	public final static String saveLog = "saveLog";
	public final static String scheduleDate = "scheduleDate";
	public final static String schedule_at = "schedule_at";
	public final static String scopes = "scopes";
	public final static String searchIndexBytes = "searchIndexBytes";
	public final static String searchIndexCount = "searchIndexCount";
	public final static String secretKey = "secretKey";
	public final static String sendDate = "sendDate";
	public final static String sendResult = "sendResult";
	public final static String sequence = "sequence";
	public final static String serviceDays = "serviceDays";
	public final static String serviceEnd = "serviceEnd";
	public final static String serviceGrade = "serviceGrade";
	public final static String serviceGradeId = "serviceGradeId";
	public final static String serviceLevel = "serviceLevel";
	public final static String serviceStart = "serviceStart";
	public final static String serviceType = "serviceType";
	public final static String servingUrl = "servingUrl";
	public final static String settings = "settings";
	public final static String show = "show";
	public final static String showYN = "showYN";
	public final static String site = "site";
	public final static String socialProfiles = "socialProfiles";
	public final static String solarType = "solarType";
	public final static String stackChildren = "stackChildren";
	public final static String stage = "stage";
	public final static String stageId = "stageId";
	public final static String stageOrder = "stageOrder";
	public final static String stageOrdinal = "stageOrdinal";
	public final static String startDate = "startDate";
	public final static String startDateOffset = "startDateOffset";
	public final static String startDayOfWeek = "startDayOfWeek";
	public final static String storageQuota = "storageQuota";
	public final static String subscribedTaskNotification = "subscribedTaskNotification";
	public final static String subscriptionId = "subscriptionId";
	public final static String subscriptionMembers = "subscriptionMembers";
	public final static String summary = "summary";
	public final static String surveyAnswerId = "surveyAnswerId";
	public final static String surveyItemId = "surveyItemId";
	public final static String surveyItems = "surveyItems";
	public final static String surveyKind = "surveyKind";
	public final static String surveyQuestionId = "surveyQuestionId";
	public final static String syncEntity = "syncEntity";
	public final static String tags = "tags";
	public final static String taskChecklistHistoryId = "taskChecklistHistoryId";
	public final static String taskChecklistId = "taskChecklistId";
	public final static String taskChecklists = "taskChecklists";
	public final static String taskHistoryId = "taskHistoryId";
	public final static String taskId = "taskId";
	public final static String taskLabelId = "taskLabelId";
	public final static String taskLabelMapId = "taskLabelMapId";
	public final static String taskName = "taskName";
	public final static String taskNames = "taskNames";
	public final static String taskStage = "taskStage";
	public final static String taskTimelineCommentId = "taskTimelineCommentId";
	public final static String taskTimelineId = "taskTimelineId";
	public final static String taskTitle = "taskTitle";
	public final static String tasklistId = "tasklistId";
	public final static String tasklists = "tasklists";
	public final static String tels = "tels";
	public final static String term = "term";
	public final static String termType = "termType";
	public final static String timeZone = "timeZone";
	public final static String timestamp = "timestamp";
	public final static String title = "title";
	public final static String token = "token";
	public final static String tokenId = "tokenId";
	public final static String tokenType = "tokenType";
	public final static String totBytes = "totBytes";
	public final static String totUsers = "totUsers";
	public final static String totalBytes = "totalBytes";
	public final static String tryCount = "tryCount";
	public final static String type = "type";
	public final static String uid = "uid";
	public final static String until = "until";
	public final static String updated = "updated";
	public final static String updatedDate = "updatedDate";
	public final static String uploadId = "uploadId";
	public final static String uploadType = "uploadType";
	public final static String url = "url";
	public final static String urls = "urls";
	public final static String usageCheckPointsOfBoard = "usageCheckPointsOfBoard";
	public final static String usageCheckPointsOfStorage = "usageCheckPointsOfStorage";
	public final static String usageCheckPointsOfUser = "usageCheckPointsOfUser";
	public final static String usageId = "usageId";
	public final static String usageLogId = "usageLogId";
	public final static String useStorage = "useStorage";
	public final static String useYN = "useYN";
	public final static String usedDate = "usedDate";
	public final static String user = "user";
	public final static String userCount = "userCount";
	public final static String userDeviceId = "userDeviceId";
	public final static String userId = "userId";
	public final static String userName = "userName";
	public final static String userProfileId = "userProfileId";
	public final static String userProfiles = "userProfiles";
	public final static String userQuota = "userQuota";
	public final static String userType = "userType";
	public final static String valid = "valid";
	public final static String validDate = "validDate";
	public final static String value = "value";
	public final static String vat = "vat";
	public final static String visibility = "visibility";
	public final static String webHookId = "webHookId";
	public final static String webPushYN = "webPushYN";
	public final static String weddingday = "weddingday";
	public final static String wiki = "wiki";
	public final static String wikiLockDate = "wikiLockDate";
	public final static String wikiLockUserId = "wikiLockUserId";

	
	public static void main(String[] args) {
		createEntityClassFieldNames();
	}
	
	// =========================================================================
	// ===== Execute once whenever Entity or Index is changed. =================
	// =========================================================================
	private static void createEntityClassFieldNames() {
		Class<?>[] classList = new Class[] {
				// ENTITY
				Activities.class, Attachments.class, AttachmentsMap.class, Images.class,
				Base.class, Backups.class, Boards.class,
				Bills.class, Customers.class, CancelInfo.class, ServiceGrades.class, 
				Common.class, Calendars.class, ChannelToken.class, Coupons.class,
				Domains.class, DomainsLog.class, Departments.class,
				Events.class, Schedule.class,
				Groups.class, GaeUser.class, MemberAuths.class,
				Notice.class, NotificationSettings.class, Notifications.class,
				Subscriptions.class,
				Tasks.class, Tasklists.class, TaskChecklistHistories.class,
				TaskChecklists.class, TaskHistories.class, TaskLabelMap.class, TaskLabels.class,
				TaskTimelineComments.class, TaskTimelines.class,
				Recurrence.class, RegCode.class,
				Users.class, UserProfiles.class, UserSetting.class, Usage.class, UsageLogs.class,
				UserCounter.class, UserDevices.class,
				Auths.class, Tokens.class,
				WebHook.class, Emoticons.class,
				Stages.class, Feedbacks.class,
				
				// INDEX
				AttachmentIndex.class, CommentIndex.class,
				EventIndex.class, NoticeIndex.class,
				TaskIndex.class, TimelineIndex.class,
				//ChecklistHistoryIndex.class,  ChecklistIndex.class, UserIndex.class
				
				Uploads.class,
				
				SurveyQuestions.class, SurveyItems.class, SurveyAnswers.class,
				AdminEMailNotice.class
				// Deprecated classes
//				BoardInvites.class,  BoardLinks.class, TaskTimelineScores.class, NoticeComments.class, TaskComments.class, TaskChecklistComments.class,
			};
		
		Set<String> fieldSet = new HashSet<String>();
		
		try {
			for (Class<?> cls : classList) {
				BeanInfo beanInfo = Introspector.getBeanInfo(cls);
				for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
					if ("class".equals(descriptor.getName()) || "super".equals(descriptor.getName())) continue;
					fieldSet.add(descriptor.getName());
					//System.out.println(descriptor.getName());
				}
			}
		} catch (Exception ex) { System.out.println(ex.getMessage()); }
			
		List<String> fieldList = new ArrayList<String>(fieldSet);
		Collections.sort(fieldList);
		for (String field : fieldList) {
			System.out.println(String.format("\tpublic final static String %s = \"%s\";", field, field));
		}
	}
}
