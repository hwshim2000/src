package net.forecs.coconut.common;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

public class CountNotice {
	@Getter @Setter
	List<CountInfo> CountInfos;
}
