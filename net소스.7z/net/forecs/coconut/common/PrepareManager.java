package net.forecs.coconut.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.forecs.coconut.common.code.PrepareType;
import net.forecs.coconut.common.query.QueryResult;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.entity.workspace.TaskTimelines;
import net.forecs.coconut.entity.workspace.Tasks;
import net.forecs.coconut.user.UserStatus;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.memcache.AsyncMemcacheService;
import com.google.appengine.api.memcache.Expiration;
import com.google.appengine.api.memcache.MemcacheServiceFactory;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;
import com.google.appengine.api.utils.SystemProperty;

public class PrepareManager {
//	private final MemcacheService mcs;
	private final AsyncMemcacheService mcs;
	
	public final static String PREFIX_USER_STATUS = "userStatus";
	public final static String PREFIX_UNARCHIVED_TASKS = "unarchivedTasks";
	public final static String PREFIX_ASSIGNED_MEMBERS = "assignedMembers";
	public final static String PREFIX_UNASSIGNED_MEMBERS = "unassignedMembers";
	public final static String PREFIX_MY_SUBSCRIBED_TASKIDS = "mySubscribedTaskIds";
	private final static String PREFIX_DASHBOARD_TASKTIMELINES = "dashboardTaskTimelines";
	
	private final static int PREPARED_MEMCACHE_TIMES = 60;
	private final static String VERSION = SystemProperty.applicationVersion.get();
	
	Map<String, Object> boardItems;
	
	public PrepareManager(String namespace) {
//		this.mcs = MemcacheServiceFactory.getMemcacheService(namespace);
		this.mcs = MemcacheServiceFactory.getAsyncMemcacheService(namespace);
		boardItems = new HashMap<String, Object>();
	}
	
	public void prepareUserStatus(UserStatus status) {
		if (status != null) {
			mcs.put(createUserStatusMemcacheKey(status.getUser().getUserId()), status, Expiration.byDeltaSeconds(PREPARED_MEMCACHE_TIMES));
		}
	}
	
	public UserStatus getUserStatusFromPreparedMemcache(String userId) throws Exception {
		String usKey = createUserStatusMemcacheKey(userId);
		UserStatus status = (UserStatus)(mcs.get(usKey).get());
		//--> 20160926 사용자 보드 목록을 아래 보드목록 초기화시 사용하기 때문에
		//mcs.delete(usKey);
		//<--
		return status;
	}
	public List<Boards> getUserBoardsFromPreparedMemcache(String userId) throws Exception {
		UserStatus status = getUserStatusFromPreparedMemcache(userId);
		
		List<Boards> boards = null;
		if (status != null) {
			boards = status.getBoards();
			//--> 20160926
			String usKey = createUserStatusMemcacheKey(userId);
			mcs.delete(usKey);
			//<--
		}
		return boards;
	}
	
	@SuppressWarnings("unchecked")
	public void prepareBoardItems(String boardId, String userId, Map<String, Object> boardItems) {
		if (boardItems != null) {
			String utKey = createUnarchivedTasksMemcacheKey(boardId, userId);
			String amKey = createAssignedMembersMemcacheKey(boardId, userId);
			String umKey = createUnassignedMembersMemcacheKey(boardId, userId);
			String mtKey = createMySubscribedTaskIdsMemcacheKey(boardId, userId);
			
			List<Tasks> unarchivedTasks = (List<Tasks>)boardItems.get(PREFIX_UNARCHIVED_TASKS);
			List<Users> assignedMembers = (List<Users>)boardItems.get(PREFIX_ASSIGNED_MEMBERS);
			List<Users> unassignedMembers = (List<Users>)boardItems.get(PREFIX_UNASSIGNED_MEMBERS);
			List<String> mySubscribedTaskIds = (List<String>)boardItems.get(PREFIX_MY_SUBSCRIBED_TASKIDS);
			
			if (unarchivedTasks != null) { mcs.put(utKey, unarchivedTasks, Expiration.byDeltaSeconds(PREPARED_MEMCACHE_TIMES)); }
			if (assignedMembers != null) { mcs.put(amKey, assignedMembers, Expiration.byDeltaSeconds(PREPARED_MEMCACHE_TIMES)); }
			if (unassignedMembers != null) { mcs.put(umKey, unassignedMembers, Expiration.byDeltaSeconds(PREPARED_MEMCACHE_TIMES)); }
			if (mySubscribedTaskIds != null) { mcs.put(mtKey, mySubscribedTaskIds, Expiration.byDeltaSeconds(PREPARED_MEMCACHE_TIMES)); }
		}
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> getBoardItemsFromPreparedMemcache(String boardId, String userId) throws Exception {
		Map<String, Object> items = new HashMap<String, Object>();
		
		String utKey = createUnarchivedTasksMemcacheKey(boardId, userId);
		String amKey = createAssignedMembersMemcacheKey(boardId, userId);
		String umKey = createUnassignedMembersMemcacheKey(boardId, userId);
		String mtKey = createMySubscribedTaskIdsMemcacheKey(boardId, userId);
		
		List<Tasks> unarchivedTasks = (List<Tasks>)(mcs.get(utKey).get());
		List<Users> assignedMembers = (List<Users>)(mcs.get(amKey).get());
		List<Users> unassignedMembers = (List<Users>)(mcs.get(umKey).get());
		List<String> mySubscribedTaskIds = (List<String>)(mcs.get(mtKey).get());
		
		mcs.delete(utKey);
		mcs.delete(amKey);
		mcs.delete(umKey);
		mcs.delete(mtKey);
		
		items.put(PREFIX_UNARCHIVED_TASKS, unarchivedTasks);
		items.put(PREFIX_ASSIGNED_MEMBERS, assignedMembers);
		items.put(PREFIX_UNASSIGNED_MEMBERS, unassignedMembers);
		items.put(PREFIX_MY_SUBSCRIBED_TASKIDS, mySubscribedTaskIds);

		return items;
	}
//	@SuppressWarnings("unchecked")
//	private List<Tasks> getUnarchivedTasks(String boardId, String userId) {
//		String utKey = createUnarchivedTasksMemcacheKey(boardId, userId);
//		return (List<Tasks>)mcs.get(utKey);
//	}
//	@SuppressWarnings("unchecked")
//	private List<Users> getAssignedMembers(String boardId, String userId) {
//		String amKey = createAssignedMembersMemcacheKey(boardId, userId);
//		return (List<Users>)mcs.get(amKey);
//	}
//	@SuppressWarnings("unchecked")
//	private List<String> getMySubscribedTaskIds(String boardId, String userId) {
//		String mtKey = createMySubscribedTaskIdsMemcacheKey(boardId, userId);
//		return (List<String>)mcs.get(mtKey);
//	}
	
	public void prepareMyDashboardTimelines(String userId, QueryResult<TaskTimelines> results)  {
		if (results != null) {
			String dtKey = createDashboardTaskTimelinesMemcacheKey(userId);
			mcs.put(dtKey, results, Expiration.byDeltaSeconds(PREPARED_MEMCACHE_TIMES));
		}
	}
	@SuppressWarnings("unchecked")
	public QueryResult<TaskTimelines> getMyDashboardTimelinesFromMemcache(String userId) throws Exception {
		String dtKey = createDashboardTaskTimelinesMemcacheKey(userId);
		QueryResult<TaskTimelines> results = (QueryResult<TaskTimelines>)(mcs.get(dtKey).get());
		mcs.delete(dtKey);
		return results;
	}
	
	private final static String createUserStatusMemcacheKey(String userId) {
		return String.format("%s-%s-%s", VERSION, PREFIX_USER_STATUS, userId);
	}
	private final static String createUnarchivedTasksMemcacheKey(String boardId, String userId) {
		String id = KeyFactory.stringToKey(userId).getName();
		return String.format("%s-%s-%s-%s", VERSION, PREFIX_UNARCHIVED_TASKS, boardId, id);
	}
	private final static String createAssignedMembersMemcacheKey(String boardId, String userId) {
		String id = KeyFactory.stringToKey(userId).getName();
		return String.format("%s-%s-%s-%s", VERSION, PREFIX_ASSIGNED_MEMBERS, boardId, id);
	}
	private final static String createUnassignedMembersMemcacheKey(String boardId, String userId) {
		String id = KeyFactory.stringToKey(userId).getName();
		return String.format("%s-%s-%s-%s", VERSION, PREFIX_UNASSIGNED_MEMBERS, boardId, id);
	}
	private final static String createMySubscribedTaskIdsMemcacheKey(String boardId, String userId) {
		String id = KeyFactory.stringToKey(userId).getName();
		return String.format("%s-%s-%s-%s", VERSION, PREFIX_MY_SUBSCRIBED_TASKIDS, boardId, id);
	}
	private final static String createDashboardTaskTimelinesMemcacheKey(String userId) {
		String id = KeyFactory.stringToKey(userId).getName();
		return String.format("%s-%s-%s", VERSION, PREFIX_DASHBOARD_TASKTIMELINES, id);
	}
	
	public static void prepare(String domainName, String userId, String boardId, String prepareType) {
		if (StringUtils.isBlank(prepareType) || PrepareType.USERSTATUS.equals(prepareType)) { addUserStatusQueue(domainName, userId); }
		if (StringUtils.isBlank(prepareType) || PrepareType.BOARDS.equals(prepareType)) { addBoardItmesQueue(domainName, userId, boardId); }
		if (StringUtils.isBlank(prepareType) || PrepareType.TASKTIMELINES.equals(prepareType)) { addTaskTimelinesQueue(domainName, userId); }
	}
	
	@SuppressWarnings("unused")
	private void prepare_old(String domainName, String userId, String boardId, String prepareType) {
			Queue queue = QueueFactory.getQueue(CommonProperty.PREPARE_INIT_DATA_QUEUE);
			TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.PREPARE_INIT_DATA_URL);
		
			taskOptions = taskOptions
					.param(PARAM.DOMAINNAME, domainName)
					.param(PARAM.USERID, userId);
			if (StringUtils.isNotBlank(boardId)) {
				taskOptions = taskOptions.param(PARAM.BOARDID, boardId);
			}
			if (StringUtils.isNotBlank(prepareType)) {
				taskOptions = taskOptions.param(PARAM.PREPARETYPE, prepareType);
			}
			taskOptions = taskOptions.method(Method.POST);
	
			queue.add(taskOptions);
	}
	
	public static void addUserStatusQueue(String domainName, String userId) {
		Queue queue = QueueFactory.getQueue(CommonProperty.PREPARE_INIT_DATA_QUEUE);
		TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.PREPARE_INIT_DATA_URL);
	
		taskOptions = taskOptions
				.param(PARAM.DOMAINNAME, domainName)
				.param(PARAM.USERID, userId)
				.param(PARAM.PREPARETYPE, PrepareType.USERSTATUS);
		taskOptions = taskOptions.method(Method.POST);

		queue.add(taskOptions);
	}
	public static void addBoardItmesQueue(String domainName, String userId, String boardId) {
		Queue queue = QueueFactory.getQueue(CommonProperty.PREPARE_INIT_DATA_QUEUE);
		TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.PREPARE_INIT_DATA_URL);
	
		taskOptions = taskOptions
				.param(PARAM.DOMAINNAME, domainName)
				.param(PARAM.USERID, userId)
				.param(PARAM.PREPARETYPE, PrepareType.BOARDS);
		if (StringUtils.isNotBlank(boardId)) {
			taskOptions = taskOptions.param(PARAM.BOARDID, boardId);
		}
		taskOptions = taskOptions.method(Method.POST);

		queue.add(taskOptions);
	}
	public static void addTaskTimelinesQueue(String domainName, String userId) {
		Queue queue = QueueFactory.getQueue(CommonProperty.PREPARE_INIT_DATA_QUEUE);
		TaskOptions taskOptions = TaskOptions.Builder.withUrl(CommonProperty.PREPARE_INIT_DATA_URL);
	
		taskOptions = taskOptions
				.param(PARAM.DOMAINNAME, domainName)
				.param(PARAM.USERID, userId)
				.param(PARAM.PREPARETYPE, PrepareType.TASKTIMELINES);
		taskOptions = taskOptions.method(Method.POST);

		queue.add(taskOptions);
	}
}
