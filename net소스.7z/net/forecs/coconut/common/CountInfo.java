package net.forecs.coconut.common;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

public class CountInfo {

	@Getter @Setter
	private String boardId;
	@Getter @Setter
	private Date checkDate;
	@Getter @Setter
	private Long count;
}
