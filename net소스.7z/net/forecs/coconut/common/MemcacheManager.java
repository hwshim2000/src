package net.forecs.coconut.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import net.forecs.coconut.common.code.EventType;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.ServletUtil;
import net.forecs.coconut.common.util.security.SecurityUtils;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.guice.MainModule;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.appengine.api.NamespaceManager;
import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.memcache.Expiration;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;
import com.google.appengine.api.utils.SystemProperty;

public class MemcacheManager<T, E> {
	//-----------------------------------------------------------------------------------------
	//	•The maximum size of a cached data value is 1 MB (10^6 bytes).
	//	•A key cannot be larger than 250 bytes. In the Python runtime, keys that are strings longer than 250 bytes will be hashed. (Other runtimes behave differently.)
	//	•The "multi" batch operations can have any number of elements. The total size of the call and the total size of the data fetched must not exceed 32 megabytes.
	//	•A memcache key cannot contain a null byte.
	//-----------------------------------------------------------------------------------------
	private static final Logger LOG = Logger.getLogger(MemcacheManager.class.getName());
	private static final String CURSOR_SUFFIX = "_CSR";
	
	private final Class<T> clazz;
	
	private final MemcacheService mcs;
	
	private final String KIND;
	private final String NAMESPACE;
	private final String KEYSET;
	private final String KEYSET_NAME;
	private final static String VERSION;
	//private final static String VERSION = SystemProperty.applicationVersion.get();
//	private final static String VERSION = "";
	private final static int memcacheExpirationTimes = 3600*24;

	static {
		if (MainModule.serviceMode) {
			VERSION = "";	
		} else {
			VERSION = SystemProperty.applicationVersion.get();
		}
	}
	
	public MemcacheManager(Class<T> clazz) {
		this(clazz, null);
	}
	public MemcacheManager(Class<T> clazz, String keySet) {
		this.clazz = clazz;
		this.KIND = clazz.getSimpleName();
		this.NAMESPACE = NamespaceManager.get();
		this.KEYSET = keySet;
		this.KEYSET_NAME = createKeysetName(KIND, KEYSET);
		this.mcs = MemcacheServiceFactory.getMemcacheService(NAMESPACE);
	}
	private static String createKeyName(String kind, String keySet) {
		return String.format("__QRY_%s_%s_%s_KEY__", kind, keySet==null?"":keySet, VERSION);
	}
	private static String createKeysetName(String kind, String keySet) {
		return String.format("__QRY_%s_%s_%s_KEYSET__", kind, keySet==null?"":keySet, VERSION);
	}
	public void setMemcache(String memcacheKey, E objs) {
		setMemcache(memcacheKey, objs, null, memcacheExpirationTimes);
	}
	public void setMemcache(String memcacheKey, E objs, Cursor cursor) {
		setMemcache(memcacheKey, objs, cursor, memcacheExpirationTimes);
	}
//	public void setMemcache(String memcacheKey, E objs, Integer expirationSeconds) {
//		setMemcache(memcacheKey, objs, null, expirationSeconds);
//	}
	public void setMemcache(String memcacheKey, E objs, String cursorString) {
		setMemcache(memcacheKey, objs, cursorString, memcacheExpirationTimes);
	}
	private void setMemcache(String memcacheKey, E objs, Object cursorObj, Integer expirationSeconds) {
		try {
			//if (objs == null || objs.size() == 0) { return ; }
			if (objs == null) { return; }
			if (objs instanceof Collection<?> && ((Collection<?>)objs).size() == 0) { return; }
			if (expirationSeconds != null && expirationSeconds > 0) {
				mcs.put(memcacheKey, objs, Expiration.byDeltaSeconds(expirationSeconds));
				if (cursorObj != null) { mcs.put(memcacheKey+CURSOR_SUFFIX, cursorObj, Expiration.byDeltaSeconds(expirationSeconds+60)); }
			} else {
				mcs.put(memcacheKey, objs);
				if (cursorObj != null) { mcs.put(memcacheKey+CURSOR_SUFFIX, cursorObj); }
			}
			// SYSTEM_HOLIDAY Key set does not call removeAllMemcache function.
			if (!isSystemHolidayType(KEYSET)) {
				addMemcacheKey(memcacheKey);
				if (cursorObj != null) { addMemcacheKey(memcacheKey+CURSOR_SUFFIX); }
			}
		} catch (Exception ex) {
			LOG.warning("[setMemcache] " + ex.getMessage());
		}
	}
	
	private static boolean isSystemHolidayType(String keySet) {
		if (StringUtils.isBlank(keySet)) {
			return false;
		} else if (EventType.SYSTEM_HOLIDAY.toString().equals(keySet)) {
			return true;
		} else {
			return false;
		}
	}
	
	@SuppressWarnings("unchecked")
	public E getMemcache(String memcacheKey) {
		Object obj = mcs.get(memcacheKey);
		
		if (obj == null) { return null; }
		
		if (isAvailableMemcacheKey(memcacheKey) || isSystemHolidayType(KEYSET)) {
			mcs.put(memcacheKey, obj, Expiration.byDeltaSeconds(memcacheExpirationTimes));
			return (E)obj;
		} else {
			mcs.delete(memcacheKey);
			if (mcs.get(memcacheKey+CURSOR_SUFFIX) != null) { mcs.delete(memcacheKey+CURSOR_SUFFIX); }
			return null;
		}
		//return (E)mcs.get(memcacheKey);
	}
	public Cursor getCursor(String memcacheKey) {
		Cursor cursor = (Cursor)mcs.get(memcacheKey+CURSOR_SUFFIX);
		if (cursor != null) {
			mcs.put(memcacheKey+CURSOR_SUFFIX, cursor, Expiration.byDeltaSeconds(memcacheExpirationTimes+60));
		}
		return cursor;
		//return (Cursor)mcs.get(memcacheKey+CURSOR_SUFFIX);
	}
	public String getCursorString(String memcacheKey) {
		String cursor = (String)mcs.get(memcacheKey+CURSOR_SUFFIX);
		if (cursor != null) {
			mcs.put(memcacheKey+CURSOR_SUFFIX, cursor, Expiration.byDeltaSeconds(memcacheExpirationTimes+60));
		}
		return cursor;
		//return (Cursor)mcs.get(memcacheKey+CURSOR_SUFFIX);
	}
	public static void removeAllMemcache(Class<?> clazz) {
		removeAllMemcache(clazz, null, NamespaceManager.get());
	}
	public static void removeAllMemcache(Class<?> clazz, String keySet) {
		removeAllMemcache(clazz, keySet, NamespaceManager.get());
	}
	public static void removeAllMemcache(Class<?> clazz, String keySet, String namespace) {
		try {
			MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(namespace);
			String keysetName = createKeysetName(clazz.getSimpleName(), keySet);
			@SuppressWarnings("unchecked")
			Set<String> memcacheKeys = (Set<String>)mcs.get(keysetName);
			try {
				mcs.delete(keysetName);
			} catch (Exception ex) {
				LOG.warning(ex.getMessage());
			}
			try {
				if (memcacheKeys != null) { 
					mcs.deleteAll(memcacheKeys);
				}
			} catch (Exception ex) { LOG.warning(ex.getMessage()); }
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	private void addMemcacheKey(String memcacheKey) {
		try {
			@SuppressWarnings("unchecked")
			Set<String> memcacheKeys = (Set<String>)mcs.get(KEYSET_NAME);
			if (memcacheKeys == null) { memcacheKeys = new HashSet<String>(); }
			if (!memcacheKeys.contains(memcacheKey)) {
				memcacheKeys.add(memcacheKey);
				mcs.put(KEYSET_NAME, memcacheKeys);
			}
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	public static void removeMemcacheKey(Class<?> clazz, String keySet, String namespace) {
		try {
			MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(namespace);
			String keysetName = createKeysetName(clazz.getSimpleName(), keySet);
			mcs.delete(keysetName);
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
		}
	}
	
	private boolean isAvailableMemcacheKey(String memcacheKey) {
		try {
			@SuppressWarnings("unchecked")
			Set<String> memcacheKeys = (Set<String>)mcs.get(KEYSET_NAME);
			if (memcacheKeys == null) { return false; }
			else { return memcacheKeys.contains(memcacheKey); }
		} catch (Exception ex) {
			LOG.warning(ex.getMessage());
			return false;
		}
	}
	
	public String createMemcacheKey(Object... params) {
		return createMemcacheKey(this.clazz, this.KEYSET, params);
	}
	
	public static String createMemcacheKey(Class<?> clazz, String keySet, Object... params) {
		String memcacheKey = null;
		try {
			ObjectMapper om = new ObjectMapper();
			memcacheKey = String.format("%s%s", createKeyName(clazz.getSimpleName(), keySet), SecurityUtils.getMD5(om.writeValueAsString(params)));
		} catch (Exception ex) { LOG.warning(ex.getMessage());}
		return memcacheKey;
	}
	
	public static String keySet(Collection<String> ids) {
		if (ids != null && ids.size() == 1) { return ids.iterator().next(); }
		return null;
	}
	public static String keySet(String id) {
		if (StringUtils.isNotBlank(id)) { return id; }
		return null;
	}
	
	//================================================================================================
	// Single Entities
	//================================================================================================
	public static void put(String key, Object value) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		mcs.put(versionKey(key), value, Expiration.byDeltaSeconds(memcacheExpirationTimes));
	}
	@SuppressWarnings("unchecked")
	public static <T extends Base> T get(String key) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		return (T)mcs.get(versionKey(key));
	}
	@SuppressWarnings("unchecked")
	public static <T extends Base> Map<String, T> getAll(Collection<String> keys) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		Map<String, Object> objs = mcs.getAll(versionKeys(keys));
		Map<String, T> entities = new HashMap<String, T>();
		for(Map.Entry<String, Object> entry : objs.entrySet()) {
			entities.put(entry.getKey(), (T)entry.getValue());
		}
		return entities;
	}
	public static <T extends Base> void putAll(Map<String, T> valueMap) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		Map<String, T> versionMap = new HashMap<String, T>();
		for(Map.Entry<String, T> entry : valueMap.entrySet()) {
			versionMap.put(versionKey(entry.getKey()), (T)entry.getValue());
		}
		mcs.putAll(versionMap, Expiration.byDeltaSeconds(memcacheExpirationTimes));
	}
	public static boolean delete(String key) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(NamespaceManager.get());
		return mcs.delete(versionKey(key));
	}
	//참고 : key의 길이가 250바이트를 넘을 경우 md5 적용,
	//   : release시에 기존 memcache에 적재되어 있는 값을 쓰지 못하는 경우가 자주 발생시 키마다 새로운 버전 적용
	private static String versionKey(String key) {
//		return key;
//		return SecurityUtils.getMD5(String.format("%s_%s", VERSION, key));
		return String.format("%s_%s", VERSION, key);
	}
	private static Collection<String> versionKeys(Collection<String> keys) {
		Collection<String> versionKeys = new ArrayList<String>();
		for (String key : keys) {
			versionKeys.add(versionKey(key));
		}
		return versionKeys;
	}
	
	public static String createAccessKey(Object obj) throws Exception {
		if (obj instanceof HttpServletRequest){
			return createAccessKey((HttpServletRequest)obj);
		}
		return createAccessKey((String)obj);
	}
	private static String createAccessKey(String objectId) throws Exception {
		if (StringUtils.isBlank(objectId)) {
			throw new Exception("Requires objectId.");
		}
		Key objKey = KeyFactory.stringToKey(objectId);
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(objKey.getNamespace());
		String key = KeyUtil.generateDownloadKey();
		mcs.put(key, objectId, Expiration.byDeltaSeconds(300));
		return key;
	}
	private static String createAccessKey(HttpServletRequest req) throws Exception {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService();
		String key = KeyUtil.generateDownloadKey();
		Map<String, String> validAccessCheckObj = new HashMap<String, String>(4);
		
		String jSsessionId = ServletUtil.getJsessionId(req);
		String userAgent = ServletUtil.getUserAgent(req);
		String remoteAddr = ServletUtil.getRemoteAddr(req);
		
		validAccessCheckObj.put(ServletUtil.USER_AGENT, userAgent);
		validAccessCheckObj.put(ServletUtil.REMOTE_ADDR, remoteAddr);
		validAccessCheckObj.put(ServletUtil.JSESSIONID, jSsessionId);
		
		LOG.warning(String.format("[Key create] %s, %s, %s", jSsessionId, remoteAddr, userAgent));
		
		mcs.put(key, validAccessCheckObj, Expiration.byDeltaSeconds(300));
		return key;
	}
	
	public static boolean isValidAccessKey(String key, Object obj) throws Exception {
		if (obj instanceof HttpServletRequest){
			return isValidAccessKey(key, (HttpServletRequest)obj);
		}
		return isValidAccessKey(key, (String)obj);
	}
	private static boolean isValidAccessKey(String key, String objectId) {
		Key objKey = KeyFactory.stringToKey(objectId);
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService(objKey.getNamespace());
		String savedObjectId = (String)mcs.get(key);
		
		if (StringUtils.isBlank(savedObjectId)) { return false; }
		if (!StringUtils.equals(savedObjectId, objectId)) { return false; }
		
		mcs.delete(key);
		return true;
	}
	private static boolean isValidAccessKey(String key, HttpServletRequest req) {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService();
		@SuppressWarnings("unchecked")
		Map<String, String> validAccessCheckObj = (Map<String, String>)mcs.get(key);
		
		String jSsessionId = ServletUtil.getJsessionId(req);
		String userAgent = ServletUtil.getUserAgent(req);
		String remoteAddr = ServletUtil.getRemoteAddr(req);
		
		LOG.warning(String.format("[Key check] %s, %s, %s", jSsessionId, remoteAddr, userAgent));
		
		if (validAccessCheckObj == null) { return false; }
		if (!StringUtils.equals(validAccessCheckObj.get(ServletUtil.USER_AGENT), userAgent)) { return false; };
		if (!StringUtils.equals(validAccessCheckObj.get(ServletUtil.REMOTE_ADDR), remoteAddr)) { return false; };
		if (!StringUtils.equals(validAccessCheckObj.get(ServletUtil.JSESSIONID), jSsessionId)) { return false; };
		
		mcs.delete(key);
		return true;
	}
	public static void clearAll() {
		MemcacheService mcs = MemcacheServiceFactory.getMemcacheService();
		mcs.clearAll();
	}
	
	//==================================================================================================
	
//	private static List<String> sort(Collection<String> collections) {
//		List<String> list = new ArrayList<String>(collections);
//		Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
//		return list;
//	}
//	@SuppressWarnings("unchecked")
//	private static Object sort(Object obj) {
//		if (!isCollection(obj)) { return obj; }
//		return sort((Collection<String>)obj);
//	}
//	private static boolean isCollection(Object obj) {
//		return obj instanceof Collection<?>;
//	}
//	private static List<Object> sortedObjects(Object... params) {
//		List<Object> objs = new ArrayList<Object>(params.length);
//			
//		for (Object obj : params) {
//			objs.add(sort(obj));
//		}
//		return objs;
//	}
}
