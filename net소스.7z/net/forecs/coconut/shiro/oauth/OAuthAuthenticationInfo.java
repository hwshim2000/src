package net.forecs.coconut.shiro.oauth;

import net.forecs.coconut.shiro.UserAuthType;

import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;

import net.forecs.coconut.common.Logger;


public class OAuthAuthenticationInfo implements AuthenticationInfo {
	private static final long serialVersionUID = 5513045595504311414L;
	static final Logger LOG = Logger.getLogger(OAuthAuthenticationInfo.class.getName());

    public final String authToken;
    private final String principal;
    private final UserAuthType authType;

    public OAuthAuthenticationInfo(String authToken, String principal, UserAuthType authType) {
        this.authToken = authToken;
        this.principal = principal;
        this.authType = authType;
    }

    @Override
    public Object getCredentials() {
        return authToken;
    }

    @Override
    public PrincipalCollection getPrincipals() {
        return new SimplePrincipalCollection(principal, authType.name());
    }
}
