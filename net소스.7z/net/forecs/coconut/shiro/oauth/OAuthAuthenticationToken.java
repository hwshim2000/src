package net.forecs.coconut.shiro.oauth;

import net.forecs.coconut.shiro.UserAuthType;

import com.google.common.base.Preconditions;

import org.apache.shiro.authc.HostAuthenticationToken;
import org.apache.shiro.authc.RememberMeAuthenticationToken;

import net.forecs.coconut.common.Logger;


public class OAuthAuthenticationToken implements HostAuthenticationToken, RememberMeAuthenticationToken {
	private static final long serialVersionUID = 8135751177716692197L;
	static final Logger LOG = Logger.getLogger(OAuthAuthenticationToken.class.getName());

    private final String token;
    private final UserAuthType authType;
    private final String principal;
    private final String host;

    public OAuthAuthenticationToken(String token, UserAuthType authType, String principal, String host) {
        Preconditions.checkNotNull(token, "You have to have an OAuth token to create an authentication token");
        Preconditions.checkNotNull(authType, "You have to specify an OAuth type to create an authentication token");
        Preconditions.checkNotNull(principal, "You have to have a principal (email address) to create an authentication token");

        this.token = token;
        this.authType = authType;
        this.principal = principal;
        this.host = host;
    }

    @Override
    public Object getPrincipal() {
        return principal;
    }

    @Override
    public Object getCredentials() {
        return token;
    }

    @Override
    public boolean isRememberMe() {
        return true;
    }

    @Override
    public String getHost() {
        return host;
    }

    public UserAuthType getAuthType() {
        return authType;
    }
}
