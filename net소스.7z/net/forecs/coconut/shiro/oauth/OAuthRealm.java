package net.forecs.coconut.shiro.oauth;

import net.forecs.coconut.shiro.gae.MemcacheManager;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.realm.AuthenticatingRealm;

import net.forecs.coconut.common.Logger;


public class OAuthRealm extends AuthenticatingRealm {
    static final Logger LOG = Logger.getLogger(OAuthRealm.class.getName());

    public OAuthRealm() {
        super(new MemcacheManager(), new OAuthCredentialsMatcher());
        setAuthenticationTokenClass(OAuthAuthenticationToken.class);        
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        if (token != null && token instanceof OAuthAuthenticationToken) {
            OAuthAuthenticationToken authToken = (OAuthAuthenticationToken)token;
            return new OAuthAuthenticationInfo((String)authToken.getCredentials(), (String)authToken.getPrincipal(), authToken.getAuthType());
        } else {
            return null;
        }
    }
}
