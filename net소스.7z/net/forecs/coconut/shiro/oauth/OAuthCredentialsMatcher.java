package net.forecs.coconut.shiro.oauth;

import com.google.common.base.Preconditions;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.credential.CredentialsMatcher;

import net.forecs.coconut.common.Logger;


public class OAuthCredentialsMatcher implements CredentialsMatcher {
    static final Logger LOG = Logger.getLogger(OAuthCredentialsMatcher.class.getName());

    public OAuthCredentialsMatcher() {}

    @Override
    public boolean doCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) {
        Preconditions.checkNotNull(info);
        Preconditions.checkNotNull(token);

        Object primary = info.getPrincipals().getPrimaryPrincipal();
        return token instanceof OAuthAuthenticationToken && token.getCredentials() != null && token.getPrincipal().equals(primary);
    }
}
