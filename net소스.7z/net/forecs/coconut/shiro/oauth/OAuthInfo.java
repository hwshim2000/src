package net.forecs.coconut.shiro.oauth;

import net.forecs.coconut.shiro.UserAuthType;

import com.google.common.base.Preconditions;

import net.forecs.coconut.common.Logger;


// The info we store when we perform a successful OAuth request with a token.
public class OAuthInfo {
    static final Logger LOG = Logger.getLogger(OAuthInfo.class.getName());

    private final String token;
    private final String email;
    private final String errorString;
    private final UserAuthType userAuthType;

    private OAuthInfo(String token, String email, String errorString, UserAuthType userAuthType) {
        this.token = token;
        this.email = email;
        this.errorString = errorString;
        this.userAuthType = userAuthType;
    }

    public boolean isError() {
        return errorString != null;
    }

    public UserAuthType getUserAuthType() {
        return userAuthType;
    }

    public String getToken() {
        return token;
    }

    public String getEmail() {
        return email;
    }

    public String getErrorString() {
        return errorString;
    }

    public static class Builder {
        private String token;
        private String email;
        private String errorString;
        private UserAuthType authType;

        public Builder(UserAuthType authType) {
            this.authType = authType;
        }
        public Builder token(String token) { this.token = token; return this; }
        public Builder email(String email) { this.email = email; return this; }
        public Builder errorString(String errorString) { this.errorString = errorString; return this; }

        public OAuthInfo build() {
            if (errorString == null) {
                Preconditions.checkNotNull(token, "You cannot have an empty token when there are no errors");
                Preconditions.checkNotNull(email, "You cannot have an empty email address when there are no errors");
                Preconditions.checkNotNull(authType, "You cannot have a null auth type");
            }
            return new OAuthInfo(token, email, errorString, authType);
        }
    }
}
