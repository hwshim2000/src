package net.forecs.coconut.shiro.oauth.provider;

import java.net.MalformedURLException;
import java.net.URL;
import net.forecs.coconut.common.Logger;


class ProviderUtil {
    static final Logger LOG = Logger.getLogger(ProviderUtil.class.getName());

    private ProviderUtil() {
    }

    public static String makeRoot(String fullURL, String redirect) {
        try {
            URL url = new URL(fullURL);
            String portString = (url.getPort() == -1) ? "" : ":" + url.getPort();
            String absRedirect = redirect.startsWith("/") ? redirect : "/" + redirect;
            return url.getProtocol() + "://" + url.getHost() + portString + absRedirect;
        } catch (MalformedURLException e) {
            return fullURL;
        }
    }    
}
