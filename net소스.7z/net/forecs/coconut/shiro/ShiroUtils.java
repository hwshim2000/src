package net.forecs.coconut.shiro;

import java.util.Collection;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Provider;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.security.SsoServiceManager;
import net.forecs.coconut.shiro.gae.DatastoreRealm;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.crypto.RandomNumberGenerator;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.SessionException;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.ByteSource;
import org.apache.shiro.util.SimpleByteSource;

import com.google.appengine.api.NamespaceManager;
import com.google.common.collect.Maps;


public class ShiroUtils extends SecurityUtils {
	private static final Logger LOG = Logger.getLogger(ShiroUtils.class.getName());

	//private static final String HASH_ALGORITHM = Sha256Hash.ALGORITHM_NAME;
	private static final String HASH_ALGORITHM = Md5Hash.ALGORITHM_NAME;
	private static final int HASH_ITERATIONS = 1;

	@Inject
	private static Provider<IUserDao<? extends IUser>> userDaoProvider;

	private static final String ID_DOMAIN_DELIMITER = "@CoCoNut.";

	private static String getDomainUserId(String domainName, String id) {
		if (StringUtils.isEmpty(domainName)) {
			return id;
		} else {
			return id + ID_DOMAIN_DELIMITER + domainName;
		}
	}

	public static void clearCache(String domainName, String id) {
		String domainUserId = getDomainUserId(domainName, id);
		DatastoreRealm.getInstance().clearCache(domainUserId);
	}

	public static boolean isAuthenticated() {
		Subject subject = SecurityUtils.getSubject();
		return subject.isAuthenticated();
	}
	
	public static IUser getCurrentUser() {
		Subject subject = SecurityUtils.getSubject();
		boolean known = subject.isAuthenticated() || subject.isRemembered();
		if (!known) {
			return null;
		}
		
		String id = (String)subject.getPrincipal();
		
		IUser user = findUser(id);
		
		// TODO : dongbu
		//<!-- hyeunwoo.shim : 20161019
		// 만일 동부 유저일 경우, 동부 유저의 google oauth 로그인된 사용자인지 체크
		if (!SsoServiceManager.valid(user)) { logout(); return null; }
		//-->	
		return user;
	}

	public static IUser findUser(String domainUserId) {
		if (StringUtils.isEmpty(domainUserId)) {
            return null;
		}

		String[] params = domainUserId.split(ID_DOMAIN_DELIMITER);
		String id = params[0];
		String prevNamespace = NamespaceManager.get();
		if (1 < params.length) {
			NamespaceManager.set(params[1]);		// Access domain's private namespace to find user
		}
		
//		Users user = CommonService.doFind(Users.class, id);
		IUserDao<? extends IUser> dao = userDaoProvider.get();
		IUser user = dao.findUser(id);
		// Query again by key if concurrency problem happens
		//user = dao.get(user.getObjectId());

		if (1 < params.length) {
			NamespaceManager.set(prevNamespace);	// Restore namespace
		}
		return user;
	}

	public static String generateRegCode(String id) {
        return new Sha256Hash(id, salt(), 63).toHex().substring(0, 10);
    }

	public static ByteSource salt() {
        RandomNumberGenerator generator = new SecureRandomNumberGenerator();
        return generator.nextBytes();
    }

    @SuppressWarnings("unused")
	public static String hash(String password, byte[] salt) {
    	if (password == null) {
    		return null;
    	}

    	SimpleByteSource saltSource = new SimpleByteSource(salt);
    	if (HASH_ALGORITHM == Md5Hash.ALGORITHM_NAME) {
    		return new Md5Hash(password, saltSource, HASH_ITERATIONS).toHex();
    	} else {
    		return new Sha256Hash(password, saltSource, HASH_ITERATIONS).toHex();
    	}
    }

    public static CredentialsMatcher createCredentialsMatcher() {
        HashedCredentialsMatcher matcher = new HashedCredentialsMatcher(HASH_ALGORITHM);
        matcher.setHashIterations(HASH_ITERATIONS);
        matcher.setStoredCredentialsHexEncoded(true);
        return matcher;
    }

	public static void loginWithNewSession(String domainName, String id, String password,
			boolean rememberMe, String host) {
		String domainUserId = getDomainUserId(domainName, id);
        loginWithNewSession(domainUserId, password, rememberMe, host);
	}

	public static void loginWithNewSession(String id, String password, boolean rememberMe, String host) {
        UsernamePasswordToken token = new UsernamePasswordToken(id, password, rememberMe, host);
        loginWithNewSession(token);
	}

	/**
	 * Login and make sure you then have a new session.
	 * This helps prevent session fixation attacks.
	 *
	 * @param token
	 */
	public static void loginWithNewSession(AuthenticationToken token) {
		Subject subject = SecurityUtils.getSubject();
		Session originalSession = subject.getSession();

		Map<Object, Object> attributes = Maps.newLinkedHashMap();
		Collection<Object> keys = originalSession.getAttributeKeys();
		for (Object key : keys) {
			Object value = originalSession.getAttribute(key);
			if (value != null) {
				attributes.put(key, value);
			}
		}

		originalSession.stop();
		subject.login(token);

		Session newSession = subject.getSession();
		for (Map.Entry<Object, Object> entry : attributes.entrySet()) {
			newSession.setAttribute(entry.getKey(), entry.getValue());
		}
	}

	public static void logout() {
		Subject subject = SecurityUtils.getSubject();
		//Session originalSession = subject.getSession();
        try {
        	//originalSession.stop();
            subject.logout();
        } catch (SessionException e) {
            LOG.info("Encountered session exception during logout. This can generally safely be ignored: " + e.getMessage());
        }
	}
}