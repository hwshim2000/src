package net.forecs.coconut.shiro;


public enum UserAuthType {
    COCONUT, GOOGLE, FACEBOOK;
}
