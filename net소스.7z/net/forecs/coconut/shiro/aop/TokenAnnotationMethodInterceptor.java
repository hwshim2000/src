package net.forecs.coconut.shiro.aop;

import org.apache.shiro.aop.AnnotationMethodInterceptor;
import org.apache.shiro.aop.AnnotationResolver;
import org.apache.shiro.aop.MethodInvocation;

import com.google.api.server.spi.response.UnauthorizedException;

public class TokenAnnotationMethodInterceptor extends AnnotationMethodInterceptor {
	public TokenAnnotationMethodInterceptor() {
		super(new TokenAnnotationHandler());
	}
	public TokenAnnotationMethodInterceptor(AnnotationResolver resolver) {
		super(new TokenAnnotationHandler(), resolver);
	}

	@Override
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		assertToken(methodInvocation);
        return methodInvocation.proceed();
	}
	
	public void assertToken(MethodInvocation methodInvocation) throws UnauthorizedException {
		try {
			((TokenAnnotationHandler)getHandler()).assertToken(getAnnotation(methodInvocation), methodInvocation);
		} catch (UnauthorizedException e) {
			if (e.getCause() == null) {
				e.initCause(new UnauthorizedException("Not authorized to invoke method : " + methodInvocation.getMethod()));
			}
            throw e;
		}
	}
}
