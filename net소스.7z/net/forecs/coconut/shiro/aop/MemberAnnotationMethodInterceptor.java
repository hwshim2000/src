package net.forecs.coconut.shiro.aop;

import org.apache.shiro.aop.AnnotationMethodInterceptor;
import org.apache.shiro.aop.AnnotationResolver;
import org.apache.shiro.aop.MethodInvocation;

import com.google.api.server.spi.response.UnauthorizedException;


public class MemberAnnotationMethodInterceptor extends AnnotationMethodInterceptor {
	public MemberAnnotationMethodInterceptor() {
		super(new MemberAnnotationHandler());
	}

	public MemberAnnotationMethodInterceptor(AnnotationResolver resolver) {
		super(new MemberAnnotationHandler(), resolver);
	}

	@Override
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		assertMember(methodInvocation);
        return methodInvocation.proceed();
	}

	public void assertMember(MethodInvocation methodInvocation) throws UnauthorizedException {
		try {
			((MemberAnnotationHandler)getHandler()).assertMember(getAnnotation(methodInvocation), methodInvocation);
		} catch (UnauthorizedException e) {
			if (e.getCause() == null) {
				e.initCause(new UnauthorizedException("Not authorized to invoke method : " + methodInvocation.getMethod()));
			}
            throw e;
		}
	}
}