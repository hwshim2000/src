package net.forecs.coconut.shiro.aop;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import javax.inject.Named;

import net.forecs.coconut.dao.jpa.BaseDao;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.shiro.annotation.RequiresOwner;

import org.apache.shiro.aop.AnnotationHandler;
import org.apache.shiro.aop.MethodInvocation;
import org.datanucleus.util.StringUtils;

import com.google.api.server.spi.response.UnauthorizedException;


public class OwnerAnnotationHandler extends AnnotationHandler {
	public OwnerAnnotationHandler() {
		super(RequiresOwner.class);
	}

	public void assertOwner(Annotation annotation, MethodInvocation methodInvocation) throws UnauthorizedException {
		assert (annotation instanceof RequiresOwner);

		String objectId = ((RequiresOwner)annotation).objectId();
		if (objectId.startsWith("{") && objectId.endsWith("}")) {
			String idNamed = objectId.substring(1, objectId.length() - 1);
			assert !StringUtils.isEmpty(idNamed) : "Invalid property for objectId : " + objectId;

			Object[] args = methodInvocation.getArguments();
			assert (args != null && args.length != 0) : "Parameter is required.";

			objectId = null;

			Method method = methodInvocation.getMethod();
			Annotation[][] annotations = method.getParameterAnnotations();
			for (int i = 0; i < annotations.length; ++i) {
				if (annotations[i].length == 0) {
					continue;
				}

				for (Annotation a : annotations[i]) {
					if ((a instanceof Named) && ((Named)a).value().equals(idNamed)) {
						objectId = (String)methodInvocation.getArguments()[i];
					}
				}
			}

			assert !StringUtils.isEmpty(objectId) : "No parameter is named as " + idNamed;
		}

		Class<? extends Base> clazz = ((RequiresOwner)annotation).clazz();
		BaseDao<? extends Base> dao = new BaseDao<>(clazz);
		Base object = dao.get(objectId);
		if (object != null) {
			Users user = CommonService.getCurrentUser();
			if (user.isAdmin()) { return; }
			if (user.getObjectId().equals(object.getOwner())) {
				return;
			}
		}

		throw new UnauthorizedException("Current user is not the owner of the " + clazz.getSimpleName() + "(objectId=" + objectId + ").");
	}
}