package net.forecs.coconut.shiro.aop;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import javax.inject.Named;

import net.forecs.coconut.common.code.security.Scope;
import net.forecs.coconut.common.util.security.JwtManager;
import net.forecs.coconut.endpoint.security.TokenService;
import net.forecs.coconut.security.TokenContext;
import net.forecs.coconut.shiro.annotation.RequiresToken;

import org.apache.shiro.aop.AnnotationHandler;
import org.apache.shiro.aop.MethodInvocation;
import org.apache.shiro.authz.annotation.Logical;
import org.datanucleus.util.StringUtils;

import com.google.api.server.spi.response.UnauthorizedException;

public class TokenAnnotationHandler extends AnnotationHandler {
	public TokenAnnotationHandler() {
		super(RequiresToken.class);
	}

	public void assertToken(Annotation annotation, MethodInvocation methodInvocation) throws UnauthorizedException {
		assert (annotation instanceof RequiresToken);

		String accessToken = ((RequiresToken)annotation).accessToken();
		if (accessToken.startsWith("{") && accessToken.endsWith("}")) {
			String idNamed = accessToken.substring(1, accessToken.length() - 1);
			assert !StringUtils.isEmpty(idNamed) : "Invalid property for accessToken : " + accessToken;

			Object[] args = methodInvocation.getArguments();
			assert (args != null && args.length != 0) : "Parameter is required.";

			accessToken = null;

			Method method = methodInvocation.getMethod();
			Annotation[][] annotations = method.getParameterAnnotations();
			for (int i = 0; i < annotations.length; ++i) {
				if (annotations[i].length == 0) {
					continue;
				}

				for (Annotation a : annotations[i]) {
					if ((a instanceof Named) && ((Named)a).value().equals(idNamed)) {
						accessToken = (String)methodInvocation.getArguments()[i];
					}
				}
			}

			assert !StringUtils.isEmpty(accessToken) : "No parameter is named as " + idNamed;
		}

		Scope scope = ((RequiresToken)annotation).scope();
		String[] roles =((RequiresToken)annotation).roles();
		Logical logicalRole = ((RequiresToken)annotation).logicalRole();
		String[] permissions = ((RequiresToken)annotation).permissions();
		Logical logicalPermission = ((RequiresToken)annotation).logicalPermission();
		
		try {
			TokenContext tokenContext = TokenContext.getCurrentInstance();
			if (!JwtManager.isJwsTokenType(accessToken)) {
				TokenService.validAccessToken(accessToken, scope, tokenContext);
			} else {
				JwtManager.getManager().validJwsAccessToken(accessToken, scope, tokenContext);
			}
			
			// token이 valid 하다면 token의 domainName을 namespace로 설정한다.
			//NamespaceManager.set(token.getAuth().getDomainName());
			// 위에 설정된 namespace에서 할당된 user의 Object(currentUser)를 찾아 셋팅
			//CommonService.printlnDev("=", 150);
			//CommonService.printlnDev("CURRENT USER", tokenContext.getUser().getDomainName(), tokenContext.getUser().getId(), tokenContext.getUser().getEmail());
			//Users currentUser = CommonService.doFind(Users.class, KeyUtil.createUserKey(token.getAuth().getId()));
			if (TokenService.ENABLE_TOKEN_USER) {
				TokenService.validUserRoles(tokenContext.getUser(), roles, logicalRole);
				TokenService.validUserPermissions(tokenContext.getUser(), permissions, logicalPermission);
			}
			//CommonService.printlnDev("=", 150);

//			// close 안해줘도 request가 완료되면 호출된다.
//			//context.close();
		} catch (Exception ex) {
			throw new UnauthorizedException(ex.getMessage());
		}
	}
}
