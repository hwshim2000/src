package net.forecs.coconut.shiro.aop;

import org.apache.shiro.aop.AnnotationMethodInterceptor;
import org.apache.shiro.aop.AnnotationResolver;
import org.apache.shiro.aop.MethodInvocation;

import com.google.api.server.spi.response.UnauthorizedException;


public class OwnerAnnotationMethodInterceptor extends AnnotationMethodInterceptor {
	public OwnerAnnotationMethodInterceptor() {
		super(new OwnerAnnotationHandler());
	}

	public OwnerAnnotationMethodInterceptor(AnnotationResolver resolver) {
		super(new OwnerAnnotationHandler(), resolver);
	}

	@Override
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		assertOwner(methodInvocation);
        return methodInvocation.proceed();
	}

	public void assertOwner(MethodInvocation methodInvocation) throws UnauthorizedException {
		try {
			((OwnerAnnotationHandler)getHandler()).assertOwner(getAnnotation(methodInvocation), methodInvocation);
		} catch (UnauthorizedException e) {
			if (e.getCause() == null) {
				e.initCause(new UnauthorizedException("Not authorized to invoke method : " + methodInvocation.getMethod()));
			}
            throw e;
		}
	}
}