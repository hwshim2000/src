package net.forecs.coconut.shiro.aop;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import javax.inject.Inject;
import javax.inject.Named;

import net.forecs.coconut.common.code.AuthStatus;
import net.forecs.coconut.endpoint.account.IMemberAuthService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.common.Base;
import net.forecs.coconut.entity.member.MemberAuths;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.shiro.annotation.RequiresMember;
import net.forecs.coconut.user.Role;

import org.apache.shiro.aop.AnnotationHandler;
import org.apache.shiro.aop.MethodInvocation;
import org.datanucleus.util.StringUtils;

import com.google.api.server.spi.response.UnauthorizedException;


public class MemberAnnotationHandler extends AnnotationHandler {
	@Inject
	private IMemberAuthService memberAuthService;
	@Inject
	private IBoardService boardService;

	public MemberAnnotationHandler() {
		super(RequiresMember.class);
	}

	public void assertMember(Annotation annotation, MethodInvocation methodInvocation) throws UnauthorizedException {
		assert (annotation instanceof RequiresMember);

		Object[] args = methodInvocation.getArguments();
		assert (args != null && args.length != 0) : "Parameter is required.";

		final Class<? extends Base> clazz = ((RequiresMember)annotation).clazz();
		String objectId = ((RequiresMember)annotation).objectId();
		if (objectId.startsWith("{") && objectId.endsWith("}")) {
			String idNamed = objectId.substring(1, objectId.length() - 1);
			assert !StringUtils.isEmpty(idNamed) : "Invalid property for objectId : " + objectId;

			objectId = null;

			Method method = methodInvocation.getMethod();
			Annotation[][] annotations = method.getParameterAnnotations();
			for (int i = 0; i < annotations.length; ++i) {
				if (annotations[i].length == 0) {
					continue;
				}

				for (Annotation a : annotations[i]) {
					if ((a instanceof Named) && ((Named)a).value().equals(idNamed)) {
						objectId = (String)args[i];
					}
				}
			}

			assert !StringUtils.isEmpty(objectId) : "No parameter is named as " + idNamed;
		} else {
			assert clazz.isInstance(args[0]) : "The type of entity parameter should be " + clazz.getSimpleName();
			objectId = clazz.cast(args[0]).getObjectId();
		}

		IUser user = ShiroUtils.getCurrentUser();
		//-->
		//if (user.getRoles().contains(Role.SUPER)) {
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		if (Role.SUPER.equals(user.getRole())) {
		//<--
			return;
		}

		String userId = user.getObjectId();

		boolean isMember;
		if (clazz == Boards.class) {
			isMember = boardService.isAvailableMemberAuth(objectId, userId);
		} else {
			MemberAuths auth = memberAuthService.getMemberAuths(objectId, userId);
			isMember = (auth != null) && AuthStatus.ACTIVE.equals(auth.getAuthStatus());
		}
		if (!isMember) {
			throw new UnauthorizedException("Current user("+user.getId()+") is not the member of " + clazz.getSimpleName() + "(objectId=" + objectId + ").");
		}
	}
}
