package net.forecs.coconut.shiro.googlegae;

import org.apache.shiro.authc.HostAuthenticationToken;
import org.apache.shiro.authc.RememberMeAuthenticationToken;


public class GoogleGaeAuthenticationToken implements HostAuthenticationToken, RememberMeAuthenticationToken {
	private static final long serialVersionUID = -6240793800838186739L;
	
	private final String principal;
    private final String host;

    public GoogleGaeAuthenticationToken(String principal, String host) {
        this.principal = principal;
        this.host = host;
    }

    @Override
    public Object getPrincipal() {
        return principal;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public boolean isRememberMe() {
        return true;
    }

    @Override
    public String getHost() {
        return host;
    }
}