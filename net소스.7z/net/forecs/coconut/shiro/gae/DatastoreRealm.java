package net.forecs.coconut.shiro.gae;

import net.forecs.coconut.common.Logger;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.security.SsoServiceManager;
import net.forecs.coconut.shiro.ShiroUtils;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAccount;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.util.SimpleByteSource;

import com.google.common.base.Preconditions;


public class DatastoreRealm extends AuthorizingRealm {
    private static final Logger LOG = Logger.getLogger(DatastoreRealm.class.getName());
    
    public DatastoreRealm() {
        super(new MemcacheManager(), ShiroUtils.createCredentialsMatcher());

        LOG.fine("Creating a new instance of DatastoreRealm");
        //setAuthenticationCachingEnabled(true);
    }

    private static DatastoreRealm sInstance;
    public static DatastoreRealm getInstance() {
    	if (null == sInstance) {
    		sInstance = new DatastoreRealm();
    	}
    	return sInstance;
    }

    public void clearCache(String principal) {
    	clearCache(new SimplePrincipalCollection(principal, getName()));
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        String id = ((UsernamePasswordToken)token).getUsername();
        return doGetAuthenticationInfo(id);
	}

    private AuthenticationInfo doGetAuthenticationInfo(String id) throws AuthenticationException {
		Preconditions.checkNotNull(id, "User ID can't be null");

		LOG.info("Finding authentication info for " + id + " in DB");
		IUser user = ShiroUtils.findUser(id);
		if (user == null) {
			LOG.info("Rejecting " + id);
			return null;
		}

		LOG.info("Found " + id + " in DB");
		//<!-- TODO : dongbu
		// hyeunwoo.shim : 20161019 OauthUser로 로그인한 경우 사용자의 password 대신에 랜덤 password를 사용하기 위해
		String password = SsoServiceManager.getServicePassword(user);
		SimpleAccount account = new SimpleAccount(id, password,
				new SimpleByteSource(user.getSalt()), getName());
		//-->
        
        /*SimpleAccount account = new SimpleAccount(id, user.getPassword(),
        		new SimpleByteSource(user.getSalt()), getName());*/
        account.setRoles(user.getRoles());
        account.setStringPermissions(user.getPermissions());
        return account;
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        Preconditions.checkNotNull(principals, "You can't have a null collection of principals");
 
        String id = (String)getAvailablePrincipal(principals);
        if (id == null) {
            throw new NullPointerException("Can't find a principal in the collection");
		}

        LOG.fine("Finding authorization info for " + id + " in DB");
        IUser user = ShiroUtils.findUser(id);
        if (user == null) {
            return null;
		}

		LOG.fine("Found " + id + " in DB");

        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo(user.getRoles());
        info.setStringPermissions(user.getPermissions());
        return info;
    }

	@Override
	public boolean isPermitted(PrincipalCollection principals, String permission) {
		Preconditions.checkNotNull(principals, "You can't have a null collection of principals");

		String id = (String)getAvailablePrincipal(principals);
        if (id == null) {
            throw new NullPointerException("Can't find a principal in the collection");
        }

        IUser user = ShiroUtils.findUser(id);
        if (user == null) {
            return false;
		}

		LOG.fine("Found " + id + " in DB");

		// TODO : Check instance based permission

		return super.isPermitted(principals, permission);
	}
}