package net.forecs.coconut;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.ServletUtil;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;

import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;


@Singleton
@SuppressWarnings("serial")
public class CoconutServlet extends HttpServlet {
	private static final Logger LOG = Logger.getLogger(CoconutServlet.class.getName());
	
	public static final String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS zzz";
    public static final String LEGACY_FORMAT = "EEE MMM dd hh:mm:ss zzz yyyy";
    private static final TimeZone utc = TimeZone.getTimeZone("UTC");
    private static final SimpleDateFormat legacyFormatter = new SimpleDateFormat(LEGACY_FORMAT);
    private static final SimpleDateFormat isoFormatter = new SimpleDateFormat(ISO_FORMAT);
    static {
        legacyFormatter.setTimeZone(utc);
        isoFormatter.setTimeZone(utc);
    }

    /**
     * Formats the current time in a sortable ISO-8601 UTC format.
     * 
     * @return Current time in ISO-8601 format, e.g. :
     *         "2012-07-03T07:59:09.206 UTC"
     */
    public static String now() {
        return toString(new Date());
    }

    public static String toString(final Date date) {
    	return isoFormatter.format(date);
    }

	public static void main(String[] args) {
		Calendar cal = DatatypeConverter.parseDateTime("2016-12-31T23:59:59.000Z");
		System.out.println(cal.getTime());
		System.out.println(now());
	}
	
	@Inject
	public CoconutServlet() {
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {

		process(req, resp);
	}
	
	public void process(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		getUserInfo(req, resp);
	    getServletInfo(req, resp);
	}
	
	public static void getUserInfo(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		UserService userService = UserServiceFactory.getUserService();
		
	    String thisUrl = req.getRequestURI();

	    User user = userService.getCurrentUser();
	    LOG.warning("ISLOGIN"+ userService.isUserLoggedIn());
	   
	    if (user != null) {
	    	LOG.warning("GDomain:" + user.getAuthDomain());
	    	LOG.warning("GEmail:" + user.getEmail());
	    	LOG.warning("GUser:" + user.getEmail());
	    }
	    resp.setContentType("text/html");
	    if (req.getUserPrincipal() != null) {
	      resp.getWriter().println("<p>Hello, "
	          + req.getUserPrincipal().getName()
	          + "!  You can <a href=\""
	          + userService.createLogoutURL(thisUrl)
	          + "\">sign out</a>.</p>");
	    } else {
	      resp.getWriter().println("<p>Please <a href=\""
	            + userService.createLoginURL(thisUrl)
	            + "\">sign in</a>.</p>");
	    }

	}
	@SuppressWarnings("rawtypes")
	public static void getServletInfo(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
		req.setCharacterEncoding(CommonProperty.UTF_8);;
		
		LOG.warning("================================= QUERY STRING =============================");
		LOG.warning("[QueryString]"+req.getQueryString());
		
		Enumeration hds = req.getHeaderNames();
		if (hds != null) {
			LOG.warning("================================= HEADERS =============================");
			while(hds.hasMoreElements()) {
				Object obj = hds.nextElement();
				String header = (String)obj;
				String value = req.getHeader(header);
				
				LOG.warning("["+ header + "] " + value);
			}
		}
		
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			LOG.warning("================================= COOKIES =============================");
			for(Cookie cookie : cookies) {
				LOG.warning(String.format("[Cookie-%s] %s %s %s %s %d", cookie.getName(), cookie.getValue(), cookie.getDomain(), cookie.getPath(),cookie.getSecure(), cookie.getMaxAge()) );
			}
		}
		
		Enumeration en = req.getParameterNames();
		if (en != null) {
			LOG.warning("=================================PARAMS ==============================");
			while(en.hasMoreElements()) {
				Object obj = en.nextElement();
				String param = (String)obj;
				String value = req.getParameter(param);
				
				LOG.warning("["+ param + "] " + value);
			}
		}
		
		Enumeration enAttr = req.getAttributeNames();
		if (enAttr != null) {
			LOG.warning("=================================ATTRS ===============================");
			while(enAttr.hasMoreElements()) {
				Object obj = enAttr.nextElement();
				String attr = (String)obj;
				Object value = req.getAttribute(attr);
				
				LOG.warning("["+ attr + "] " + value);
			}
		}
		
	    String msg = req.getParameter("item");
	    if (StringUtils.isNotBlank(msg)) {
	    	LOG.warning("=================================ITEMS ===============================");
			JSONObject jObj = new JSONObject(); // this parses the json
			Iterator it = jObj.keys(); //gets all the keys
	
			System.out.println(msg);
			while(it.hasNext())
			{
			    String key = (String)it.next(); // get key
			    Object o = jObj.get(key); // get value
			    LOG.warning(key +" = "+o);
			}
	    }
	    
	    try {
		    LOG.warning("=================================READER ==============================");
		    Map<String, Object> contentsMap = ServletUtil.getContentsMap(req);
		    
		    System.out.println(contentsMap);
	    } catch (Exception ex) {
	    	LOG.warning(ex.getMessage());
	    }
	}
	
	public class DownloadMultipleFiles extends HttpServlet {

		  private static final long serialVersionUID = 3305561818342965462L;

		  public void doGet(HttpServletRequest request, HttpServletResponse response)
		      throws ServletException, IOException {

		    // Set the response type and specify the boundary string
		    response.setContentType("multipart/x-mixed-replace;boundary=END");

		    // Set the content type based on the file type you need to download
		    String contentType = "Content-type: text/rtf";

		    // List of files to be downloaded
		    List<File> files = new ArrayList<File>();
		    files.add(new File("C:/first.txt"));
		    files.add(new File("C:/second.txt"));
		    files.add(new File("C:/third.txt"));

		    ServletOutputStream out = response.getOutputStream();

		    // Print the boundary string
		    out.println();
		    out.println("--END");

		    for (File file : files) {

		      // Get the file
		      FileInputStream fis = null;
		      try {
		        fis = new FileInputStream(file);

		      } catch (FileNotFoundException fnfe) {
		        // If the file does not exists, continue with the next file
		        System.out.println("Couldfind file " + file.getAbsolutePath());
		        continue;
		      }

		      BufferedInputStream fif = new BufferedInputStream(fis);

		      // Print the content type
		      out.println(contentType);
		      out.println("Content-Disposition: attachment; filename=" + file.getName());
		      out.println();

		      System.out.println("Sending " + file.getName());

		      // Write the contents of the file
		      int data = 0;
		      while ((data = fif.read()) != -1) {
		        out.write(data);
		      }
		      fif.close();

		      // Print the boundary string
		      out.println();
		      out.println("--END");
		      out.flush();
		      System.out.println("Finisheding file " + file.getName());
		    }

		    // Print the ending boundary string
		    out.println("--END--");
		    out.flush();
		    out.close();
		  }

		}
	
	public class DownloadMultipleFiles2 extends HttpServlet {

		private static final long serialVersionUID = -7767828383799037391L;

		public void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {

			// Set the content type based to zip
			response.setContentType("Content-type: text/zip");
			response.setHeader("Content-Disposition",
					"attachment; filename=mytest.zip");

			// List of files to be downloaded
			List<File> files = new ArrayList<File>();
			files.add(new File("C:/first.txt"));
			files.add(new File("C:/second.txt"));
			files.add(new File("C:/third.txt"));

			ServletOutputStream out = response.getOutputStream();
			ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(out));

			for (File file : files) {

				System.out.println("Adding " + file.getName());
				zos.putNextEntry(new ZipEntry(file.getName()));

				// Get the file
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(file);

				} catch (FileNotFoundException fnfe) {
					// If the file does not exists, write an error entry instead of
					// file
					// contents
					zos.write(("ERRORld not find file " + file.getName())
							.getBytes());
					zos.closeEntry();
					System.out.println("Couldfind file "
							+ file.getAbsolutePath());
					continue;
				}

				BufferedInputStream fif = new BufferedInputStream(fis);

				// Write the contents of the file
				int data = 0;
				while ((data = fif.read()) != -1) {
					zos.write(data);
				}
				fif.close();

				zos.closeEntry();
				System.out.println("Finishedng file " + file.getName());
			}

			zos.close();
		}
	}
	
//	import com.google.api.services.oauth2.Oauth2;
//	import com.google.api.services.oauth2.model.Tokeninfo;
//
//	private static void test1(String accessToken) throws Exception {
//		if (StringUtils.isBlank(accessToken)) { return; }
//		
//		GoogleCredential credential = new GoogleCredential().setAccessToken( accessToken );
//		Oauth2 oauth2 = new Oauth2.Builder(
//		    UrlFetchTransport.getDefaultInstance(),
//		    JacksonFactory.getDefaultInstance(), credential )
//		    .build();
//		
//		
//		Tokeninfo tokenInfo = oauth2.tokeninfo().setAccessToken( accessToken ).execute();
//
//		if (tokenInfo.containsKey("error")) { 
//			LOG.warning("error");
//			   throw new Exception(tokenInfo.get("error").toString()); 
//			  } 
//			 
//			  if (credential.getExpiresInSeconds() == null) { 
//			   // Set the expiry time if it hasn't already been set. 
//			   int expiresIn = tokenInfo.getExpiresIn(); 
//			   credential.setExpiresInSeconds((long) expiresIn); 
//			   credential.setExpirationTimeMilliseconds(System.currentTimeMillis() + expiresIn * 1000); 
//			  } 
//			 
//			  Pattern p = Pattern.compile("^(\\d*)(.*).apps.googleusercontent.com$"); 
//			  Matcher issuedTo = p.matcher("1073273458742-5mddepucma4lcu4n6kav62jjkg6g7fr7.apps.googleusercontent.com"); 
//			  Matcher localId = p.matcher(tokenInfo.getIssuedTo()); 
//			 
//			  // Make sure the token we got is for our app. 
//			  if (!issuedTo.matches() || !localId.matches() 
//			    || !issuedTo.group(1).equals(localId.group(1))) { 
//			 
//				  LOG.warning("Token's client ID does not match app's.");
//			   throw new Exception( 
//			     "Token's client ID does not match app's.");
//			   
//			  } 
//			 
//			  String userId =  tokenInfo.getUserId(); 
//			  LOG.warning(tokenInfo.toPrettyString());
//			  LOG.warning(userId);
//
//	}
//	
//	private static void test2(String key) throws Exception {
//		if (StringUtils.isBlank(key)) { return; }
//		
//		URL url = new URL("https://www.googleapis.com/userinfo/v2/me?key="+ key);
//
//		System.out.println(key);
//	    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
////	    conn.setRequestProperty("Authorization", "Bearer "+access_token);
////	    conn.setRequestMethod("GET");
////	    conn.setRequestProperty("Accept", "application/json");
//
//	    LOG.warning("111111111111111111111");
//	    LOG.warning(""+conn.getResponseCode());
//	    LOG.warning(conn.getResponseMessage());
//	    if (conn.getResponseCode() != 200) {
//	        throw new RuntimeException("Failed : HTTP error code : "
//	                + conn.getResponseCode());
//	    }
//
//	    LOG.warning("111111111111111111112");
//	    BufferedReader br = new BufferedReader(new InputStreamReader(
//	        (conn.getInputStream())));
//
//	    String output;
//	    LOG.warning("REST call made. Output from Server .... \n");
//	    while ((output = br.readLine()) != null) {
//	    	LOG.warning(output);
//	    }
//
//	    LOG.warning("111111111111111111113");
//	    conn.disconnect();
//
//	}
}