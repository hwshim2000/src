package net.forecs.coconut.guice;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;

import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.dao.IUserDao;
import net.forecs.coconut.dao.jpa.UsersDao;
import net.forecs.coconut.endpoint.account.IMemberAuthService;
import net.forecs.coconut.endpoint.account.IUserDeviceService;
import net.forecs.coconut.endpoint.account.IUserService;
import net.forecs.coconut.endpoint.account.MemberAuthService;
import net.forecs.coconut.endpoint.account.UserDeviceService;
import net.forecs.coconut.endpoint.account.UserService;
import net.forecs.coconut.endpoint.admin.AdminCommonService;
import net.forecs.coconut.endpoint.admin.AdminService;
import net.forecs.coconut.endpoint.admin.BackupService;
import net.forecs.coconut.endpoint.admin.CouponService;
import net.forecs.coconut.endpoint.admin.DataService;
import net.forecs.coconut.endpoint.admin.DomainsLogService;
import net.forecs.coconut.endpoint.admin.EmoticonService;
import net.forecs.coconut.endpoint.admin.GCSService;
import net.forecs.coconut.endpoint.admin.IAdminCommonService;
import net.forecs.coconut.endpoint.admin.IAdminService;
import net.forecs.coconut.endpoint.admin.IBackupService;
import net.forecs.coconut.endpoint.admin.ICouponService;
import net.forecs.coconut.endpoint.admin.IDataService;
import net.forecs.coconut.endpoint.admin.IDomainsLogService;
import net.forecs.coconut.endpoint.admin.IEmoticonService;
import net.forecs.coconut.endpoint.admin.IGCSService;
import net.forecs.coconut.endpoint.admin.IUsageService;
import net.forecs.coconut.endpoint.admin.UsageService;
import net.forecs.coconut.endpoint.billing.BillingService;
import net.forecs.coconut.endpoint.billing.IBillingService;
import net.forecs.coconut.endpoint.board.AlarmService;
import net.forecs.coconut.endpoint.board.BoardService;
import net.forecs.coconut.endpoint.board.IAlarmService;
import net.forecs.coconut.endpoint.board.IBoardService;
import net.forecs.coconut.endpoint.calendar.CalendarService;
import net.forecs.coconut.endpoint.calendar.ICalendarService;
import net.forecs.coconut.endpoint.channel.FirebaseChannel;
import net.forecs.coconut.endpoint.channel.GcmService;
import net.forecs.coconut.endpoint.channel.IGcmService;
import net.forecs.coconut.endpoint.channel.INotificationService;
import net.forecs.coconut.endpoint.channel.ISubscriptionService;
import net.forecs.coconut.endpoint.channel.ISyncService;
import net.forecs.coconut.endpoint.channel.IWebHookService;
import net.forecs.coconut.endpoint.channel.NotificationService;
import net.forecs.coconut.endpoint.channel.SubscriptionService;
import net.forecs.coconut.endpoint.channel.SyncService;
import net.forecs.coconut.endpoint.channel.WebHookService;
import net.forecs.coconut.endpoint.common.ActivityService;
import net.forecs.coconut.endpoint.common.AttachmentMapService;
import net.forecs.coconut.endpoint.common.AttachmentService;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.common.IActivityService;
import net.forecs.coconut.endpoint.common.IAttachmentMapService;
import net.forecs.coconut.endpoint.common.IAttachmentService;
import net.forecs.coconut.endpoint.common.ICommonService;
import net.forecs.coconut.endpoint.common.IImageService;
import net.forecs.coconut.endpoint.common.INoticeService;
import net.forecs.coconut.endpoint.common.ImageService;
import net.forecs.coconut.endpoint.common.NoticeService;
import net.forecs.coconut.endpoint.dashboard.DashboardService;
import net.forecs.coconut.endpoint.dashboard.IDashboardService;
import net.forecs.coconut.endpoint.domain.DepartmentService;
import net.forecs.coconut.endpoint.domain.DomainService;
import net.forecs.coconut.endpoint.domain.GroupService;
import net.forecs.coconut.endpoint.domain.IDepartmentService;
import net.forecs.coconut.endpoint.domain.IDomainService;
import net.forecs.coconut.endpoint.domain.IGroupService;
import net.forecs.coconut.endpoint.domain.IStageService;
import net.forecs.coconut.endpoint.domain.StageService;
import net.forecs.coconut.endpoint.manage.FeedbackService;
import net.forecs.coconut.endpoint.manage.IFeedbackService;
import net.forecs.coconut.endpoint.search.ISearchService;
import net.forecs.coconut.endpoint.search.SearchService;
import net.forecs.coconut.endpoint.security.ITokenService;
import net.forecs.coconut.endpoint.security.TokenService;
import net.forecs.coconut.endpoint.setting.INotificationSettingService;
import net.forecs.coconut.endpoint.setting.IUserSettingService;
import net.forecs.coconut.endpoint.setting.NotificationSettingService;
import net.forecs.coconut.endpoint.setting.UserSettingService;
import net.forecs.coconut.endpoint.survey.ISurveyService;
import net.forecs.coconut.endpoint.survey.SurveyService;
import net.forecs.coconut.endpoint.workspace.ITaskChecklistHistoryService;
import net.forecs.coconut.endpoint.workspace.ITaskChecklistService;
import net.forecs.coconut.endpoint.workspace.ITaskHistoryService;
import net.forecs.coconut.endpoint.workspace.ITaskLabelMapService;
import net.forecs.coconut.endpoint.workspace.ITaskLabelService;
import net.forecs.coconut.endpoint.workspace.ITaskService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineCommentService;
import net.forecs.coconut.endpoint.workspace.ITaskTimelineService;
import net.forecs.coconut.endpoint.workspace.TaskChecklistHistoryService;
import net.forecs.coconut.endpoint.workspace.TaskChecklistService;
import net.forecs.coconut.endpoint.workspace.TaskHistoryService;
import net.forecs.coconut.endpoint.workspace.TaskLabelMapService;
import net.forecs.coconut.endpoint.workspace.TaskLabelService;
import net.forecs.coconut.endpoint.workspace.TaskService;
import net.forecs.coconut.endpoint.workspace.TaskTimelineCommentService;
import net.forecs.coconut.endpoint.workspace.TaskTimelineService;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.freemarker.DocBuilder;
import net.forecs.coconut.servlet.DevDomainFilter;
import net.forecs.coconut.servlet.DomainFilter;
import net.forecs.coconut.servlet.GaeServletSessionFilter;
import net.forecs.coconut.shiro.ShiroUtils;
import net.forecs.coconut.shiro.oauth.provider.FacebookAuth;
import net.forecs.coconut.shiro.oauth.provider.IOAuthProviderInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.guice.web.ShiroWebModule;

import com.google.appengine.api.utils.SystemProperty;
import com.google.appengine.tools.appstats.AppstatsFilter;
import com.google.appengine.tools.appstats.AppstatsServlet;
import com.google.common.base.Charsets;
import com.google.inject.AbstractModule;
import com.google.inject.Scopes;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.googlecode.objectify.cache.AsyncCacheFilter;

import freemarker.template.Configuration;
import freemarker.template.TemplateModelException;


public class MainModule extends AbstractModule {
    private static final Logger LOG = Logger.getLogger(MainModule.class.getName());

    private final String userBaseUrl;
    private final String staticBaseUrl;
    private final static String appType;
   
    public final static boolean serviceMode;
    public final static boolean adminAppType;
    public final static boolean webAppType;
    public final static boolean developmentServer;
    
    static {
    	appType = System.getProperty("appType");
    	serviceMode = isServiceMode();
    	adminAppType = isAdminAppType();
    	webAppType = isWebAppType();
    	developmentServer = isDevelopmentServer();

    	if (serviceMode) {
    		LOG.warning("============================== SERVICE MODE START ===============================");
    		LOG.warning("--- Use common(default) memcache version key.");
    		LOG.warning("--- Use task queue for prepared board items.");
    		LOG.warning("--- Use task queue for notifications.");
    		LOG.warning("=================================================================================");
    	}
    	else {
    		LOG.warning("============================== DEV MODE START ===============================");
    		LOG.warning("--- Not use common(default) memcache version key.");
    		LOG.warning("--- Not use task queue for prepared board items.");
    		LOG.warning("--- Not use task queue for notifications.");
    		LOG.warning("=================================================================================");
    	}
    	
    	if (adminAppType) {
    		LOG.warning("============================== ADMIN APPLICATION SERVICE START ===============================");
    	}
    	
    	if (webAppType) {
    		LOG.warning("============================== WEB APPLICATION SERVICE START ===============================");
    	}
    }

    MainModule(String userBaseUrl, String staticBaseUrl) {
        this.userBaseUrl = userBaseUrl;
        this.staticBaseUrl = staticBaseUrl;
        
    }

    @Override
    protected void configure() {
		bindString("userBaseUrl", userBaseUrl);
		bindString("staticBaseUrl", staticBaseUrl);

		//final String appId = SystemProperty.applicationId.get();
		bindString("admin.email", CommonProperty.SENDER_NOREPLY_EMAIL);

		bindString("social.site", isDevelopmentServer() ? "local" : "live");

    	ShiroWebModule.bindGuiceFilter(binder());
		bind(AsyncCacheFilter.class).in(Scopes.SINGLETON);
		bind(AppstatsServlet.class).in(Scopes.SINGLETON);
		bind(AppstatsFilter.class).in(Scopes.SINGLETON);

		if (isDevelopmentServer()) {
			bind(GaeServletSessionFilter.class).in(Scopes.SINGLETON);
			bind(DevDomainFilter.class).in(Scopes.SINGLETON);
		} else {
			bind(DomainFilter.class).in(Scopes.SINGLETON);
		}

    	bind(new TypeLiteral<IUserDao<? extends IUser>>(){}).to(UsersDao.class);
    	binder().requestStaticInjection(ShiroUtils.class);

		bind(IBoardService.class).to(BoardService.class).in(Scopes.SINGLETON);
		// ************* Unused service ******************
//		bind(IBoardInviteService.class).to(BoardInviteService.class).in(Scopes.SINGLETON);
		bind(ICommonService.class).to(CommonService.class).in(Scopes.SINGLETON);
		bind(IDomainService.class).to(DomainService.class).in(Scopes.SINGLETON);
		bind(IDomainsLogService.class).to(DomainsLogService.class).in(Scopes.SINGLETON);
		bind(IGroupService.class).to(GroupService.class).in(Scopes.SINGLETON);
		
		bind(IStageService.class).to(StageService.class).in(Scopes.SINGLETON);
		
		bind(IMemberAuthService.class).to(MemberAuthService.class).in(Scopes.SINGLETON);
		bind(ITaskService.class).to(TaskService.class).in(Scopes.SINGLETON);
		bind(IUserService.class).to(UserService.class).in(Scopes.SINGLETON);
		bind(IUserDeviceService.class).to(UserDeviceService.class).in(Scopes.SINGLETON);
		bind(INotificationService.class).to(NotificationService.class).in(Scopes.SINGLETON);
		bind(ISubscriptionService.class).to(SubscriptionService.class).in(Scopes.SINGLETON);
//		bind(INoticeCommentService.class).to(NoticeCommentService.class).in(Scopes.SINGLETON);
//		bind(ITasklistService.class).to(TasklistService.class).in(Scopes.SINGLETON);
		bind(ICalendarService.class).to(CalendarService.class).in(Scopes.SINGLETON);
		bind(INoticeService.class).to(NoticeService.class).in(Scopes.SINGLETON);
		bind(IActivityService.class).to(ActivityService.class).in(Scopes.SINGLETON);
		bind(ITaskChecklistService.class).to(TaskChecklistService.class).in(Scopes.SINGLETON);
//		bind(ITaskCommentService.class).to(TaskCommentService.class).in(Scopes.SINGLETON);
//		bind(ITaskChecklistCommentService.class).to(TaskChecklistCommentService.class).in(Scopes.SINGLETON);
		bind(ITaskHistoryService.class).to(TaskHistoryService.class).in(Scopes.SINGLETON);
		bind(ITaskLabelService.class).to(TaskLabelService.class).in(Scopes.SINGLETON);
		bind(ITaskLabelMapService.class).to(TaskLabelMapService.class).in(Scopes.SINGLETON);
		bind(ITaskTimelineCommentService.class).to(TaskTimelineCommentService.class).in(Scopes.SINGLETON);
		bind(ITaskTimelineService.class).to(TaskTimelineService.class).in(Scopes.SINGLETON);
//		bind(ITaskTimelineScoreService.class).to(TaskTimelineScoreService.class).in(Scopes.SINGLETON);
		bind(ITaskChecklistHistoryService.class).to(TaskChecklistHistoryService.class).in(Scopes.SINGLETON);
		bind(IDashboardService.class).to(DashboardService.class).in(Scopes.SINGLETON);
		bind(IAlarmService.class).to(AlarmService.class).in(Scopes.SINGLETON);
		bind(IAttachmentService.class).to(AttachmentService.class).in(Scopes.SINGLETON);
		bind(IAttachmentMapService.class).to(AttachmentMapService.class).in(Scopes.SINGLETON);
		bind(IImageService.class).to(ImageService.class).in(Scopes.SINGLETON);
		bind(ISyncService.class).to(SyncService.class).in(Scopes.SINGLETON);
		bind(ISearchService.class).to(SearchService.class).in(Scopes.SINGLETON);
		bind(IUserSettingService.class).to(UserSettingService.class).in(Scopes.SINGLETON);		
		bind(INotificationSettingService.class).to(NotificationSettingService.class).in(Scopes.SINGLETON);
		//bind(ITaskSettingService.class).to(TaskSettingService.class).in(Scopes.SINGLETON);
		bind(IAdminService.class).to(AdminService.class).in(Scopes.SINGLETON);
		bind(IBillingService.class).to(BillingService.class).in(Scopes.SINGLETON);
		bind(IUsageService.class).to(UsageService.class).in(Scopes.SINGLETON);
		bind(ICouponService.class).to(CouponService.class).in(Scopes.SINGLETON);
		bind(IDataService.class).to(DataService.class).in(Scopes.SINGLETON);
		bind(IBackupService.class).to(BackupService.class).in(Scopes.SINGLETON);
		bind(IAdminCommonService.class).to(AdminCommonService.class).in(Scopes.SINGLETON);
		bind(ITokenService.class).to(TokenService.class).in(Scopes.SINGLETON);
		bind(IEmoticonService.class).to(EmoticonService.class).in(Scopes.SINGLETON);
		bind(IDepartmentService.class).to(DepartmentService.class).in(Scopes.SINGLETON);
		
		bind(IGcmService.class).to(GcmService.class).in(Scopes.SINGLETON);
		bind(IWebHookService.class).to(WebHookService.class).in(Scopes.SINGLETON);
		
		bind(IFeedbackService.class).to(FeedbackService.class).in(Scopes.SINGLETON);
		bind(IGCSService.class).to(GCSService.class).in(Scopes.SINGLETON);
		
		bind(ISurveyService.class).to(SurveyService.class).in(Scopes.SINGLETON);
		
		//bind(IGSuiteService.class).to(GSuiteService.class).in(Scopes.SINGLETON);
		
		bind(IOAuthProviderInfo.class).to(FacebookAuth.class);
		bind(DocBuilder.class).toInstance(createDocBuilder());
		bind(FirebaseChannel.class).toInstance(FirebaseChannel.getInstance());
    }

    private void bindString(String key, String value) {
        bind(String.class).annotatedWith(Names.named(key)).toInstance(value);
    }

    private DocBuilder createDocBuilder() {
        try {
            URL base = getClass().getResource("/ftl/");
            DocBuilder docBuilder = new DocBuilder(base, Locale.getDefault(), Charsets.UTF_8.name());
            Configuration cfg = docBuilder.cfg();
            cfg.setSharedVariable("userBaseUrl", userBaseUrl);
            cfg.setSharedVariable("staticBaseUrl", staticBaseUrl);
            return docBuilder;
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (TemplateModelException e) {
            throw new RuntimeException(e);
        }
    }

	public static boolean isDevelopmentServer() {
        SystemProperty.Environment.Value server = SystemProperty.environment.value();
        return server == SystemProperty.Environment.Value.Development;
//        return false;
    }
	
	private static boolean isServiceMode() {
		if (developmentServer) { return false; }
    	String strServiceMode = System.getProperty("serviceMode");
    	if (StringUtils.equals("1", strServiceMode) || StringUtils.equalsIgnoreCase("true", strServiceMode) || StringUtils.equalsIgnoreCase("on", strServiceMode)) {
    		return true;
    	}
    	return false;
    }
	
    private static boolean isAdminAppType() {
    	if (developmentServer) { return true; }
    	if (StringUtils.equalsIgnoreCase("all", appType)) { return true; }
    	if (StringUtils.equalsIgnoreCase("admin", appType)) { return true; }
    	
    	return false;
    }
    
    private static boolean isWebAppType() {
    	if (developmentServer) { return true; }
    	if (StringUtils.equalsIgnoreCase("admin", appType)) { return false; }
    	if (StringUtils.equalsIgnoreCase("none", appType)) { return false; }
    	
    	return true;
    }
}