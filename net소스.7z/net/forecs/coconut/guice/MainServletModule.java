package net.forecs.coconut.guice;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.forecs.coconut.CoconutServlet;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.servlet.AttachmentDownloadServlet;
import net.forecs.coconut.servlet.DBSchemaDDLServlet;
import net.forecs.coconut.servlet.DevDomainFilter;
import net.forecs.coconut.servlet.DomainFilter;
import net.forecs.coconut.servlet.FreemarkerServlet;
import net.forecs.coconut.servlet.GCSDownloadServlet;
import net.forecs.coconut.servlet.GaeServletSessionFilter;
import net.forecs.coconut.servlet.ImageInfoServlet;
import net.forecs.coconut.servlet.InitServlet;
import net.forecs.coconut.servlet.MailHandlerServlet;
import net.forecs.coconut.servlet.PostDownloadServlet;
import net.forecs.coconut.servlet.SendRegCodeServlet;
import net.forecs.coconut.servlet.calendar.GoogleCalendarServlet;
import net.forecs.coconut.servlet.cron.BackupServlet;
import net.forecs.coconut.servlet.cron.InvokeAlarmExecutorServlet;
import net.forecs.coconut.servlet.cron.RemoveAllUnavailableChannelServlet;
import net.forecs.coconut.servlet.cron.RemoveNotificationServlet;
import net.forecs.coconut.servlet.cron.RemoveUnavailableTokenServlet;
import net.forecs.coconut.servlet.cron.RemoveUploadedTrashFilesServlet;
import net.forecs.coconut.servlet.cron.ScheduledPaymentServlet;
import net.forecs.coconut.servlet.cron.SummarizeBillsServlet;
import net.forecs.coconut.servlet.cron.SurveyUsageServlet;
import net.forecs.coconut.servlet.oauth.DongbuServiceSsoLoginServlet;
import net.forecs.coconut.servlet.queue.AlarmExecuteServlet;
import net.forecs.coconut.servlet.queue.AlarmPushServlet;
import net.forecs.coconut.servlet.queue.AsyncFirebaseMessageServlet;
import net.forecs.coconut.servlet.queue.NotificationExecuteServlet;
import net.forecs.coconut.servlet.queue.PaymentCancelServlet;
import net.forecs.coconut.servlet.queue.PaymentDomainServlet;
import net.forecs.coconut.servlet.queue.PrepareInitDataServlet;
import net.forecs.coconut.servlet.queue.PrepareNotificationServlet;
import net.forecs.coconut.servlet.queue.RecreateIndexServlet;
import net.forecs.coconut.servlet.queue.SendEmailServlet;
import net.forecs.coconut.servlet.queue.SummarizeDomainBillsServlet;
import net.forecs.coconut.servlet.queue.SurveyDomainUsageServlet;
import net.forecs.coconut.servlet.queue.WebHookServlet;
import net.forecs.coconut.servlet.user.DepartmentsDownloadServlet;
import net.forecs.coconut.servlet.user.DepartmentsUploadServlet;
import net.forecs.coconut.servlet.user.ExcelDownloadServlet;
import net.forecs.coconut.servlet.user.ExcelUploadServlet;
import net.forecs.coconut.servlet.user.SendRandomPasswordServlet;
import net.forecs.coconut.servlet.user.SettingsServlet;
import net.forecs.coconut.servlet.user.StatusServlet;
import net.forecs.coconut.servlet.user.UserDeleteServlet;
import net.forecs.coconut.servlet.user.UserListServlet;
import net.forecs.coconut.servlet.user.UserPictureServlet;
import net.forecs.coconut.servlet.user.UserSuspendServlet;

import com.google.api.server.spi.guice.GuiceSystemServiceServletModule;
import com.google.appengine.tools.appstats.AppstatsFilter;
import com.google.appengine.tools.appstats.AppstatsServlet;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.googlecode.objectify.cache.AsyncCacheFilter;


class MainServletModule extends GuiceSystemServiceServletModule  {
    private final String userBaseUrl;
    
    MainServletModule(String userBaseUrl) {
        Preconditions.checkArgument(userBaseUrl != null && !userBaseUrl.endsWith("/"));
        this.userBaseUrl = userBaseUrl;
    }

	@Override
    protected void configureServlets() {
    	super.configureServlets();
    	if (MainModule.developmentServer) {
    		filter("/*").through(GaeServletSessionFilter.class);
    		filter("/*").through(DevDomainFilter.class);
    	} else {
    		filter("/*").through(DomainFilter.class);
    	}
    	
    	filter("/*").through(AsyncCacheFilter.class);
        filter("/*").through(AppstatsFilter.class, map("calculateRpcCosts", "true"));

        // Make sure that the list of service classes is in sync with that in web.xml
		Set<Class<?>> serviceClasses = new HashSet<Class<?>>();
		
		if (MainModule.webAppType) {
	        serviceClasses.add(net.forecs.coconut.endpoint.account.AccountServiceAPI.class);
//	        serviceClasses.add(net.forecs.coconut.endpoint.account.UserDeviceServiceAPI.class);	// moved to userServiceAPI
	        serviceClasses.add(net.forecs.coconut.endpoint.account.UserServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.board.BoardServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.calendar.CalendarServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.channel.SyncServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.channel.GcmAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.common.ActivityServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.common.AttachmentServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.common.ImageServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.common.NoticeServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.dashboard.DashboardServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.domain.DomainServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.domain.GroupServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.domain.DepartmentServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.domain.StageServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.setting.UserSettingServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.search.SearchServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.setting.NotificationSettingServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskChecklistServiceAPI.class);
//	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskCommentServiceAPI.class);
//	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskHistoryServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskLabelServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskTimelineCommentServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskTimelineServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskChecklistHistoryServiceAPI.class);
//	        serviceClasses.add(net.forecs.coconut.endpoint.workspace.TaskChecklistCommentServiceAPI.class);
	
	        serviceClasses.add(net.forecs.coconut.endpoint.billing.BillingServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.survey.SurveyServiceAPI.class);
	        
	        //=============================== 외부 서비스 ============================================
	        //serviceClasses.add(net.forecs.coconut.endpoint.foreign.GSuiteServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.foreign.lineworks.LineworksServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.manage.FeedbackServiceAPI.class);
	        
	        //TODO : 나중에 사용할 계획이 있다면
	    	// ************* Unused service ******************
	        //serviceClasses.add(net.forecs.coconut.endpoint.channel.WebHookServiceAPI.class);
	        //serviceClasses.add(net.forecs.coconut.endpoint.board.BoardInviteServiceAPI.class);
	        //serviceClasses.add(net.forecs.coconut.endpoint.common.NoticeCommentServiceAPI.class);
		}
		
        if (MainModule.adminAppType) {
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.AdminServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.UsageServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.CouponServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.DataServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.BackupServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.security.TokenServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.BillingAdminServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.EmoticonServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.FeedbackAdminServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.NoticeAdminServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.GCSServiceAPI.class);
	        serviceClasses.add(net.forecs.coconut.endpoint.admin.SurveyAdminServiceAPI.class);
        }
        
        if (MainModule.developmentServer) {
        	serviceClasses.add(net.forecs.coconut.endpoint.ServletServiceAPI.class);
        }

        serveGuiceSystemServiceServlet(API.SPI_ROOT+"*", serviceClasses);

		serve(API.APPSTATS_ROOT+"*").with(AppstatsServlet.class);
		serve(API.MAIL_ROOT+"*").with(MailHandlerServlet.class);

		serve("*.ftl").with(FreemarkerServlet.class);

		//serve(userBaseUrl + "/socialLogin").with(OAuthLoginServlet.class);
		//serve(userBaseUrl + "/googleLogin").with(GoogleLoginServlet.class);
		//serve(userBaseUrl + "/tasks/sendRegCode").with(SendRegCodeServlet.class);
		serve(userBaseUrl + CommonProperty.SEND_REG_CODE_URL).with(SendRegCodeServlet.class);
		serve(userBaseUrl + "/status").with(StatusServlet.class);
		serve(userBaseUrl + "/list").with(UserListServlet.class);
		serve(userBaseUrl + "/suspend").with(UserSuspendServlet.class);
		serve(userBaseUrl + "/delete").with(UserDeleteServlet.class);
		serve(userBaseUrl + "/settings").with(SettingsServlet.class);

//		serve(CommonProperty.CHANNEL_CONNETED_URL).with(ChannelConnectedServlet.class);
//		serve(CommonProperty.CHANNEL_DISCONNECTED_URL).with(ChannelDisconnectedServlet.class);

		serve(CommonProperty.CRON_SURVEY_USAGE_URL).with(SurveyUsageServlet.class);
		serve(CommonProperty.CRON_REMOVE_ALL_UNAVAILABLE_CHANNEL_URL).with(RemoveAllUnavailableChannelServlet.class);
		serve(CommonProperty.CRON_INVOKE_ALARM_EXECUTOR_URL).with(InvokeAlarmExecutorServlet.class);
		serve(CommonProperty.CRON_SUMARRIZE_BILLS_URL).with(SummarizeBillsServlet.class);
		serve(CommonProperty.CRON_SCHEDULED_PAYMENT_URL).with(ScheduledPaymentServlet.class);
		serve(CommonProperty.CRON_REMOVE_UNAVAILABLE_ACCESS_TOKEN_URL).with(RemoveUnavailableTokenServlet.class);
		serve(CommonProperty.CRON_REMOVE_UPLOADED_TRASH_FILES_URL).with(RemoveUploadedTrashFilesServlet.class);

		serve(CommonProperty.DEFAULT_EMAIL_SEND_URL).with(SendEmailServlet.class);
//		serve(CommonProperty.INVITATION_EMAIL_SEND_URL).with(InvitationEmailServlet.class);
		//serve(CommonProperty.NOTIFICATION_EMAIL_SEND_URL).with(NotificationEmailServlet.class);
		serve(CommonProperty.NOTIFICATION_EXECUTE_URL).with(NotificationExecuteServlet.class);
		serve(CommonProperty.PREPARE_NOTIFICATION_URL).with(PrepareNotificationServlet.class);
		serve(CommonProperty.ALARM_EXECUTE_URL).with(AlarmExecuteServlet.class);
		serve(CommonProperty.ALARM_PUSH_URL).with(AlarmPushServlet.class);

		// ************* Unused service ******************
		serve(CommonProperty.MY_GOOGLE_CALENDAR_URL).with(GoogleCalendarServlet.class);
		// ************* Unused service ******************
//		serve(CommonProperty.BOARD_INVITATION_URL).with(GuestLinkConfirmServlet.class);

		serve(CommonProperty.DOMAIN_USER_EXCEL_UPLOAD_URL).with(ExcelUploadServlet.class);
		serve(CommonProperty.DOMAIN_USER_EXCEL_DOWNLOAD_URL).with(ExcelDownloadServlet.class);
		serve(CommonProperty.DOMAIN_USER_RANDOM_PASSWORD_URL).with(SendRandomPasswordServlet.class);
		serve(CommonProperty.DOMAIN_DEPARTMENTS_UPLOAD_URL).with(DepartmentsUploadServlet.class);
		serve(CommonProperty.DOMAIN_DEPARTMENTS_DOWNLOAD_URL).with(DepartmentsDownloadServlet.class);

		serve(CommonProperty.BACKUP_URL).with(BackupServlet.class);
		serve(CommonProperty.USER_PICTURE_URL).with(UserPictureServlet.class);
//		serve(CommonProperty.BOARD_LOGO_URL).with(BoardLogoServlet.class);
		//serve(CommonProperty.SENDLOSTID_EMAIL_SEND_URL).with(SendLostIdEmailServlet.class);
		
		serve(CommonProperty.ASYNC_FIREBASE_MESSAGE_SEND_URL).with(AsyncFirebaseMessageServlet.class);
		//serve(CommonProperty.ASYNC_MESSAGE_SEND_URL).with(AsyncMessageServlet.class);
		
		serve(CommonProperty.REMOVE_NOTIFICATION_URL).with(RemoveNotificationServlet.class);
		//serve(CommonProperty.NOTICE_EMAIL_SEND_URL).with(NoticeEmailServlet.class);
		
		serve(CommonProperty.RECREATE_INDEX_URL).with(RecreateIndexServlet.class);
		serve(CommonProperty.SURVEY_DOMAIN_USAGE_URL).with(SurveyDomainUsageServlet.class);
		serve(CommonProperty.SUMARRIZE_DOMAIN_BILLS_URL).with(SummarizeDomainBillsServlet.class);
		serve(CommonProperty.PAYMENT_DOMAIN_URL).with(PaymentDomainServlet.class);
		serve(CommonProperty.PAYMENT_CANCEL_DOMAIN_URL).with(PaymentCancelServlet.class);
		
		
		serve(CommonProperty.WEB_HOOK_URL).with(WebHookServlet.class);
		serve(CommonProperty.PREPARE_INIT_DATA_URL).with(PrepareInitDataServlet.class);
		serve(CommonProperty.INSTANCE_INIT_SERVLET_URL).with(InitServlet.class);
		
		serve(CommonProperty.DONGBU_SERVICE_SSO_LOGIN_URL).with(DongbuServiceSsoLoginServlet.class);
		serve(CommonProperty.TASK_DOWNLOAD_URL).with(PostDownloadServlet.class);
		serve(CommonProperty.ATTACHMENT_DOWNLOAD_URL).with(AttachmentDownloadServlet.class);
		serve(CommonProperty.IMAGE_INFO_URL).with(ImageInfoServlet.class);
		
		serve(CommonProperty.GCS_DOWNLOAD_SERVLET_URL).with(GCSDownloadServlet.class);
		serve("/_ah/database/schemas").with(DBSchemaDDLServlet.class);
		/** test */
//		serve("/sharer/share").with(PostShareServlet.class);	// TODO : testing....
		serve(userBaseUrl + "/coconut").with(CoconutServlet.class);
		//@Deprecated
		//serve(userBaseUrl + "/notifications").with(NotificationServlet.class);
	}
    
    private static Map<String, String> map(String... params) {
		Preconditions.checkNotNull(params);
        Preconditions.checkArgument(params.length % 2 == 0, "You must have even number of map params");

		Map<String, String> map = Maps.newHashMap();
		for (int i = 0; i < params.length; i += 2) {
			map.put(params[i], params[i + 1]);
		}
		return map;
    }
    
//    private static String getVersion() {
//    	String applicationVersion = SystemProperty.applicationVersion.get();
//		String[] versionInfos = applicationVersion.split(":");
//		@SuppressWarnings("unused")
//		String module = "default";
//		String version = null;
//		if (versionInfos.length == 2) {
//			module = versionInfos[0];
//			version = versionInfos[1];
//		} else {
//			version = versionInfos[0];
//		}
//		return version;
//    }
    

}