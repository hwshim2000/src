package net.forecs.coconut.guice;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import net.forecs.coconut.shiro.guice.MainShiroAopModule;
import net.forecs.coconut.shiro.guice.MainShiroWebModule;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.servlet.GuiceServletContextListener;


public class ServletContextListener extends GuiceServletContextListener {
//	private static final Logger LOG = Logger.getLogger(ServletContextListener.class.getName());

	private static final String KEY_USER_BASE_URL = "userBaseUrl";
	private static final String KEY_STATIC_BASE_URL = "staticBaseUrl";

	private ServletContext servletContext;

	// Where we want to serve user management URLs from.
    private String userBaseUrl;

    // Prefix for the URL from which static files are served.
    // Empty string by default. On Google App Engine we'll use static.<app-id>.appspot.com.
    private String staticBaseUrl;

    public ServletContextListener() {
        userBaseUrl = "";
        staticBaseUrl = "";
    }

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
    	servletContext = servletContextEvent.getServletContext();
        if (servletContext != null) {
        	String userBaseUrl = servletContext.getInitParameter(KEY_USER_BASE_URL);
            if (userBaseUrl != null) {
                this.userBaseUrl = userBaseUrl;
            }

			String staticBaseUrl = System.getProperty(KEY_STATIC_BASE_URL);
			if (staticBaseUrl == null) {
				staticBaseUrl = servletContext.getInitParameter(KEY_STATIC_BASE_URL);
			}
            if (staticBaseUrl != null) {
                this.staticBaseUrl = staticBaseUrl;
            }
        }

        super.contextInitialized(servletContextEvent);
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) { 
        servletContext = null; 
    } 

    @Override
    protected Injector getInjector() {
        return Guice.createInjector(new MainShiroWebModule(servletContext),
        		new MainModule(userBaseUrl, staticBaseUrl), new MainServletModule(userBaseUrl),
        		new MainShiroAopModule());
    }
}