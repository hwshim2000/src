package net.forecs.coconut.security;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.Logger;
import net.forecs.coconut.common.util.ServletUtil;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.METHOD;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.guice.MainModule;
import net.forecs.coconut.servlet.MultiReadHttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;

public class SsoServiceManager {
	private static final Logger LOG = Logger.getLogger(SsoServiceManager.class);
    private static final String SSO_INFO_COOKIE_NAME = "ssoInfo";
    private static final int SSO_INFO_COOKIE_EXPIRES = 30*24*60*60;
    private static final String LOGIN_URI = API.ACCOUNT_SERVICE_URI + "." + METHOD.login;
    private static final String SERVICE_LOGIN_URI = API.ACCOUNT_SERVICE_URI + "." + METHOD.serviceLogin;
    private static final Set<String> GoogoleOAuthServiceHosts;
    static {
    	GoogoleOAuthServiceHosts = new HashSet<String>();
    	GoogoleOAuthServiceHosts.add("dongbu");
    }
   
    @Getter @Setter
    private boolean ssoLogin;
	@Getter @Setter
	private String serviceHost;
	@Getter @Setter
	private String domainName;
	@Getter @Setter
	private String email;
	@Getter @Setter
	private String googleAccessToken;
	
	private Long loginTimes;
	private void setLoginTimes(String loginTimes) {
		try {
			if (StringUtils.isBlank(loginTimes)) { this.expiresIn = 0L; }
			else {
				this.loginTimes = Long.parseLong(loginTimes);
			}
		} catch (Exception ex) { }
	}
	@Getter
	private Long expiresIn;
	private void setExpiresIn(String expiresIn) {
		try {
			if (StringUtils.isBlank(expiresIn)) { this.expiresIn = 0L; }
			else {
				this.expiresIn = Long.parseLong(expiresIn);
			}
		} catch (Exception ex) {}
	}
	@Getter @Setter
	private String requestUri;

	@SuppressWarnings("unused")
	private boolean isExpired() {
		if (loginTimes == null || expiresIn == null) { return false; }
		long currentTimes = new Date().getTime();
		long expiresTimes = loginTimes + (expiresIn*1000);
		if (currentTimes < expiresTimes) { return false; }
		return true;
	}
	
	private Map<String, String> ssoInfoMap;

	private void setSsoInfoMap(Map<String, String> ssoInfoMap) {
		if (ssoInfoMap == null) {
			this.ssoInfoMap = new HashMap<String, String>();
		} else {
			this.ssoInfoMap = ssoInfoMap;
		}
	}
	
	private SsoServiceManager() {
		this.serviceHost = null;
		this.domainName = null;
		this.email = null;
		this.googleAccessToken = null;
		this.loginTimes = null;
		this.expiresIn = 0L;
		this.ssoLogin = false;
		this.requestUri = null;
	}
	
    private SsoServiceManager(Map<String, String> ssoInfoMap, String requestUri) {
    	setSsoInfoMap(ssoInfoMap);
    	
    	setServiceHost(this.ssoInfoMap.get(FLD.serviceHost));
    	setDomainName(this.ssoInfoMap.get(FLD.domainName));
    	setEmail(this.ssoInfoMap.get(FLD.email));
    	setGoogleAccessToken(this.ssoInfoMap.get(FLD.googleAccessToken));
    	setLoginTimes(this.ssoInfoMap.get(FLD.loginTimes));
    	setExpiresIn(this.ssoInfoMap.get(FLD.expiresIn));
    	
    	setSsoLogin(StringUtils.isNotBlank(serviceHost));
    	setRequestUri(requestUri);
    }
    
    public static String createServicePassword() {
    	return ServiceLoginContext.create().getRandomPassword();
    }
    
    public static String getServicePassword(IUser user) {
    	return ServiceLoginContext.getServicePassword(user);
    }

    public static boolean valid(IUser user) {
    	SsoServiceManager manager = SsoServiceManager.get();
		// 기본 로그인 URL일 경우에는 valid 체크를 하지 않는다.
		if (StringUtils.equals(LOGIN_URI, manager.getRequestUri())) { return true; }
		// default login 인지 sso 로그인인지 체크
		if (!manager.isSsoLogin()) { return true; }
		// ===============================================================================
		// TODO : 사용자 이메일을 비교해야할 경우
		//if (!StringUtils.equalsIgnoreCase(email, user.getEmail())) { return false; }
		// TODO : 만약, SSO login info에 의해 expires 를 정의해서 사용할 경우
		//if (isExpired()) {
		//	LOG.warning("This session was expired.");
		//	return false;
		//}
		// ===============================================================================
		
		// Dongbu cloud 서비스 일경우에는 Google OAuth login 체크
		if (GoogoleOAuthServiceHosts.contains(manager.getServiceHost())) {
			UserService userService = UserServiceFactory.getUserService();
			User ssoUser = userService.getCurrentUser();
			if (ssoUser == null
					|| !userService.isUserLoggedIn()
					/*|| !StringUtils.equalsIgnoreCase(email, oauthUser.getEmail())*/) {
				if (MainModule.developmentServer) {
					LOG.warning("Development server can't sso check.");
					return true;
				}
				LOG.warning("Sso user not found or logout.");
				return false;
			}
			
			LOG.warning(manager.getServiceHost() + " cloud groupware service sso user("+ssoUser.getEmail()+") login.");
			return true;
		} else {
			// TODO : 만일, 다른 외부 서비스 로그인을 사용한다면, 거기에 맞는 인증 체크 수행
			return false;
		}
	}
	private static SsoServiceManager get() {
		TokenContext context = TokenContext.getCurrentInstance();
		if (context == null) { return new SsoServiceManager(); }
	
		HttpServletRequest req = context.getRequest();
		Map<String, String> ssoInfoMap = getDecodedSsoInfoMap(req);
		
		return new SsoServiceManager(ssoInfoMap, req.getRequestURI());
	}
	
	private static String getEncodedSsoInfo(HttpServletRequest req) {
		Map<String, Object> ssoMap = ServletUtil.getContentsMap(req);
		ssoMap.put(FLD.loginTimes, new Date().getTime());
		String ssoInfo = ServletUtil.contentsMapToString(ssoMap);
		return Base64.encodeBase64String(ssoInfo.getBytes(StandardCharsets.UTF_8));
//		try {
//			return toString(ssoInfo);
//		} catch (Exception ex) { return null; }
	}
	
	private static Map<String, String> getDecodedSsoInfoMap(HttpServletRequest req) {
		String encodedssoInfo = ServletUtil.getCookieValue(SSO_INFO_COOKIE_NAME, req);
	
		String decodedssoInfo = getDecodedSsoInfo(encodedssoInfo);
		return ServletUtil.stringToContentsMap(decodedssoInfo);
	}
	
	private static String getDecodedSsoInfo(String encodedContents) {
		if (StringUtils.isBlank(encodedContents)) { return null; }
		return new String(Base64.decodeBase64(encodedContents), StandardCharsets.UTF_8);
//		try {
//			return (String)fromString(encodedContents);
//		} catch (Exception ex) {
//			return null;
//		}
	}
	
	public static void set(MultiReadHttpServletRequest req, HttpServletResponse res) {
		String requestUri = req.getRequestURI();
		
		if (/*StringUtils.equals("/_ah/api/accountService/v1/account/login", requestUri)||*/
				StringUtils.equals(LOGIN_URI, requestUri)) {
			ServletUtil.reloadCookie(SSO_INFO_COOKIE_NAME, null, 0, res);
		} else if (/*StringUtils.equals("/_ah/api/accountService/v1/account/service/login", requestUri)	||*/
				StringUtils.equals(SERVICE_LOGIN_URI, requestUri)) {
			String encodedContents = getEncodedSsoInfo(req);
			if (StringUtils.isNotEmpty(encodedContents)) {
				ServletUtil.reloadCookie(SSO_INFO_COOKIE_NAME, encodedContents, SSO_INFO_COOKIE_EXPIRES, res);
			}
		} 
	}
	

	
	/** Read the object from Base64 string. */
	@SuppressWarnings("unused")
	private static Object fromString(String s) throws IOException, ClassNotFoundException {
		byte[] data = Base64.decodeBase64(s);
		ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
		Object o = ois.readObject();
		ois.close();
		return o;
	}

	/** Write the object to a Base64 string. */
	@SuppressWarnings("unused")
	private static String toString(Serializable o) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(o);
		oos.close();
		return Base64.encodeBase64String(baos.toByteArray());
	}
}
