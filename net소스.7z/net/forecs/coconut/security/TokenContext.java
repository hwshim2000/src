package net.forecs.coconut.security;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.CommonProperty;
import net.forecs.coconut.common.FLD;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.common.util.ServletUtil;
import net.forecs.coconut.common.util.security.CustomClaims;
import net.forecs.coconut.common.util.security.JwtManager;
import net.forecs.coconut.endpoint.API;
import net.forecs.coconut.endpoint.common.CommonService;
import net.forecs.coconut.endpoint.security.TokenService;
import net.forecs.coconut.entity.security.Auths;
import net.forecs.coconut.entity.security.Tokens;
import net.forecs.coconut.entity.user.Users;
import net.forecs.coconut.servlet.MultiReadHttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.google.appengine.api.NamespaceManager;

public final class TokenContext implements AutoCloseable {
    private static ThreadLocal<TokenContext> instance = new ThreadLocal<>();
    //private static final Logger LOG = Logger.getLogger(TokenContext.class);
    
    private final static Set<String> CONTEXT_TOKEN_URIS;
    private final static int ACCESS_TOKEN_EXPIRES = 365*30*24*60*60;
    static {
    	// TokenContext를 사용할 URI
    	CONTEXT_TOKEN_URIS = new HashSet<String>();
    	CONTEXT_TOKEN_URIS.add(CommonProperty.DONGBU_SERVICE_SSO_LOGIN_URL);	// logout 처리시 이미 존재하는 accessToken이 있다면 삭제하도록 처리
    }
    
    @Getter @Setter
    private HttpServletRequest request;
    @Getter @Setter
    private HttpServletResponse response;
    
    @Getter @Setter
    private String accessToken;
    @Getter @Setter
    private Auths auth;
    @Getter @Setter
    private Users user;
//    @Getter @Setter
//    private Tokens token;
    @Getter @Setter
    private String userAgent;
    @Getter @Setter
    private String remoteAddr;

    private TokenContext(MultiReadHttpServletRequest request, HttpServletResponse response) {
        this.request = request;
        this.response = response;
    }

    public static TokenContext create(MultiReadHttpServletRequest request, HttpServletResponse response) {
    	// TODO : dongbu
    	if (request.getRequestURI().startsWith(API.SPI_ROOT+API.PACKAGE_ROOT)
    			|| CONTEXT_TOKEN_URIS.contains(request.getRequestURI())
    			) {
			TokenContext context = new TokenContext(request, response);
			try {
				if (TokenService.ENABLE_TOKEN_USER) {
					String accessToken = TokenService.retrieveAccessToken(request);
				
					if (StringUtils.isNotBlank(accessToken)) {
						if (!JwtManager.isJwsTokenType(accessToken)) {
							Tokens token = TokenService.getToken(accessToken);
							
							// token이 valid 하다면 token의 domainName을 namespace로 설정한다.
							// 위에 설정된 namespace에서 할당된 user의 Object(currentUser)를 찾아 셋팅
							boolean isValidAccessToken = TokenService.isValidAccessToken(token);
							if (isValidAccessToken) {
								NamespaceManager.set(token.getAuth().getDomainName());
								Users currentUser = CommonService.doFind(Users.class, KeyUtil.createUserKey(token.getAuth().getId()));
								if (CommonService.isValid(currentUser)) {context.setUser(currentUser); }
								if (CommonService.isValid(token.getAuth())) { context.setAuth(token.getAuth());	}
								
	//							context.setToken(token);
		//						if (currentUser != null) {
		//							CommonService.printlnDev("-", 150);
		//							CommonService.printlnDev("TOKEN CONTEXT", "enabled token service");
		//							CommonService.printlnDev("Current User", currentUser.getId(), currentUser.getDomainName(), currentUser.getEmail());
		//							CommonService.printlnDev("-", 150);
		//						}
							}
		//					else {
		//						TokenService.removeAccessToken(token);
		//					}
							
							reloadAccessTokenToCookie(accessToken, isValidAccessToken, token, request, response);
							//analyzeAccessToken(request, response);
						} else {
							CustomClaims cc = JwtManager.getManager().validJwsAccessToken(request, accessToken);
							if (cc != null) {
								NamespaceManager.set(cc.getDomainName());
								Users currentUser = CommonService.doFind(Users.class, KeyUtil.createUserKey(cc.getId()));
								Auths auth = TokenService.getAuthById(cc.getClientId());
								if (CommonService.isValid(currentUser)) { context.setUser(currentUser); }
								if (CommonService.isValid(auth)) { context.setAuth(auth);	}
							}
						}
						context.setAccessToken(accessToken);
						context.setUserAgent(ServletUtil.getUserAgent(request));
						context.setRemoteAddr(ServletUtil.getRemoteAddr(request));
					}
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			instance.set(context);
			return context;
    	}
    	return null;
/*
    	TokenContext context = new TokenContext(request, response);
        instance.set(context);
        return context;
    	*/
    }

    @SuppressWarnings("unused")
	private static void analyzeAccessToken(MultiReadHttpServletRequest request, HttpServletResponse response) {
    	String requestUri = request.getRequestURI();
    	CommonService.printlnDev("=", 200);
		CommonService.printlnDev("requestUri", requestUri);

		ServletUtil.printHeader(request, response);
		ServletUtil.printCookie(request, response);
		//CommonService.println("ContextPath", request.getContextPath());
		ServletUtil.printContentsMap(request, response);
		CommonService.printlnDev("=", 200);
    }
    
    private static void reloadAccessTokenToCookie(String accessToken, boolean isValidAccessToken, Tokens token, MultiReadHttpServletRequest request, HttpServletResponse response) {
		if (StringUtils.isBlank(accessToken)) { return; }
		
		if (isValidAccessToken) {
			Long expires = new Long(ACCESS_TOKEN_EXPIRES);
			if (token != null && token.getExpire() != null) {
				expires = token.getExpire().getTime() - new Date().getTime();
			}
			ServletUtil.reloadCookie(FLD.accessToken, accessToken, expires.intValue(), response);
		} else {
			ServletUtil.reloadCookie(FLD.accessToken, null, 0, response);
		}
	}
   
    public static TokenContext getCurrentInstance() {
    	return instance.get();
    }
    
    public static Users getCurrentUser() {
    	TokenContext context = instance.get();
    	if (context == null) { return null; }
    	return context.getUser();
    }
    public static String getCurrentAcccessToken() {
    	TokenContext context = instance.get();
    	if (context == null) { return null; }
    	return context.getAccessToken();
    }
    
//    public static Tokens getCurrentToken() {
//    	TokenContext context = instance.get();
//    	if (context == null) { return null; }
//    	return context.getToken();
//    }
    
    @Override    
    public void close() {
		//System.out.println("removed token context.");
		instance.remove();
    }

    // ... (add methods here which return/delegate the request/response).    
 
//    private static void reloadAccessToken(MultiReadHttpServletRequest request, HttpServletResponse response) {
//		String accessToken = TokenService.retrieveAccessToken(request);
//		
//		CommonService.println("Retrieve AccessToken", accessToken);
//		if (StringUtils.isNotBlank(accessToken)) {
//			Tokens token = null;
//			try {
//				token = TokenService.validAccessToken(accessToken);
//			} catch (Exception ex) {
//				//LOG.warning("reloadAccessToken:"+ex.getMessage());
//				CommonService.println("reloadAccessToken", ex.getMessage());
//			}
//			if (token != null) {
//				Cookie cookie = SsoServiceManager.reloadCookie(FLD.accessToken, accessToken, 365*30*24*60*60);
//				response.addCookie(cookie);
//			} else {
//				Cookie cookie = SsoServiceManager.reloadCookie(FLD.accessToken, null, 0);
//				response.addCookie(cookie);
//			}
//		}
//	}
//    private static void reloadAccessTokenAll(String accessToken, boolean isValidAccessToken, MultiReadHttpServletRequest request, HttpServletResponse response) {
//		if (StringUtils.isBlank(accessToken)) { return; }
//		
//		List<Cookie> cookies = findCookies(request, FLD.accessToken);
//		if (cookies == null || cookies.size() == 0) {
//			if (isValidAccessToken) {
//				Cookie cookie = reloadCookie(FLD.accessToken, accessToken, 365*30*24*60*60);
//				response.addCookie(cookie);
//			}
//		} else {
//			if (!isValidAccessToken) {
//				for (Cookie cookie : request.getCookies()) {
//					cookie.setValue(null);
//				//	cookie.setMaxAge(0);
//					response.addCookie(cookie);
//				}
//			}
//		}
//	}
}