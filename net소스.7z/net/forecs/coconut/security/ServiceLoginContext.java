package net.forecs.coconut.security;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.common.util.KeyUtil;
import net.forecs.coconut.entity.user.IUser;
import net.forecs.coconut.shiro.ShiroUtils;

public class ServiceLoginContext implements AutoCloseable {
	private static ThreadLocal<ServiceLoginContext> instance = new ThreadLocal<>();

    @Getter @Setter
    private String randomPassword;
    private ServiceLoginContext() {
    }

    private ServiceLoginContext(String randomPassword) {
    	this.randomPassword = randomPassword;
    }

    public static ServiceLoginContext create() {
    	String randomPassword = KeyUtil.generateRandomPassword();
    	ServiceLoginContext context = new ServiceLoginContext(randomPassword);
        instance.set(context);
        return context;
    }

    private static ServiceLoginContext getCurrentInstance() {
        return instance.get();
    }
    
    public static String getServicePassword(IUser user) {
    	try (ServiceLoginContext context = ServiceLoginContext.getCurrentInstance()) {
	    	if (context == null) {
	    		return user.getPassword();
	    	} else {
	    		return ShiroUtils.hash(context.getRandomPassword(), user.getSalt());
	    	}
    	}
    }

    @Override    
    public void close() {
        instance.remove();
    }
}
