package net.forecs.coconut.user;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


public final class Permission {
	// Refer to org.apache.shiro.authz.permission.WildcardPermission for details
	// Permission string has a format as follows
	//		scope[,scope,...]:action[,action,...]:instance[,instance,...]
	public static final String ALL = "*";
	public static final String DIV = ":";
	public static final String AND = ",";

	public static final String SCOPE_DOMAIN = "domain";
	public static final String SCOPE_GROUP = "group";
	public static final String SCOPE_BOARD = "board";
	public static final String SCOPE_TASK = "task";

	public static final String ACTION_CREATE = "create";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_CLOSE = "close";
	public static final String ACTION_ARCHIVE = "archive";

	public static final String ACTION_ASSIGN_MEMBER = "assignMember";
	public static final String ACTION_UNASSIGN_MEMBER = "unassignMember";

	public static final String ACTION_READ = "read";
	public static final String ACTION_WRITE = "write";

	public static final String DOMAIN_ALL = SCOPE_DOMAIN + DIV + ALL;
	public static final String DOMAIN_CREATE = SCOPE_DOMAIN + DIV + ACTION_CREATE;
	public static final String DOMAIN_DELETE = SCOPE_DOMAIN + DIV + ACTION_DELETE;
	public static final String DOMAIN_CREATE_AND_DELETE = SCOPE_DOMAIN + DIV + ACTION_CREATE + AND + ACTION_DELETE;
	public static final String DOMAIN_ASSIGN_MEMBER = SCOPE_DOMAIN + DIV + ACTION_ASSIGN_MEMBER;
	public static final String DOMAIN_UNASSIGN_MEMBER = SCOPE_DOMAIN + DIV + ACTION_UNASSIGN_MEMBER;
	public static final String DOMAIN_MANAGE_MEMBER = SCOPE_DOMAIN + DIV + ACTION_ASSIGN_MEMBER + AND + ACTION_UNASSIGN_MEMBER;
	public static final String DOMAIN_READ = SCOPE_DOMAIN + DIV + ACTION_READ;
	public static final String DOMAIN_WRITE = SCOPE_DOMAIN + DIV + ACTION_WRITE;
	public static final String DOMAIN_READ_AND_WRITE = SCOPE_DOMAIN + DIV + ACTION_READ + AND + ACTION_WRITE;

	public static final String GROUP_ALL = SCOPE_GROUP + DIV + ALL;
	public static final String GROUP_CREATE = SCOPE_GROUP + DIV + ACTION_CREATE;
	public static final String GROUP_DELETE = SCOPE_GROUP + DIV + ACTION_DELETE;
	public static final String GROUP_CREATE_AND_DELETE = SCOPE_GROUP + DIV + ACTION_CREATE + AND + ACTION_DELETE;
	public static final String GROUP_READ = SCOPE_GROUP + DIV + ACTION_READ;
	public static final String GROUP_WRITE = SCOPE_GROUP + DIV + ACTION_WRITE;
	public static final String GROUP_READ_AND_WRITE = SCOPE_GROUP + DIV + ACTION_READ + AND + ACTION_WRITE;

	public static final String BOARD_ALL = SCOPE_BOARD + DIV + ALL;
	public static final String BOARD_CREATE = SCOPE_BOARD + DIV + ACTION_CREATE;
	public static final String BOARD_DELETE = SCOPE_BOARD + DIV + ACTION_DELETE;
	public static final String BOARD_CREATE_AND_DELETE = SCOPE_BOARD + DIV + ACTION_CREATE + AND + ACTION_DELETE;
	public static final String BOARD_ASSIGN_MEMBER = SCOPE_BOARD + DIV + ACTION_ASSIGN_MEMBER;
	public static final String BOARD_UNASSIGN_MEMBER = SCOPE_BOARD + DIV + ACTION_UNASSIGN_MEMBER;
	public static final String BOARD_MANAGE_MEMBER = SCOPE_BOARD + DIV + ACTION_ASSIGN_MEMBER + AND + ACTION_UNASSIGN_MEMBER;
	public static final String BOARD_READ = SCOPE_BOARD + DIV + ACTION_READ;
	public static final String BOARD_WRITE = SCOPE_BOARD + DIV + ACTION_WRITE;
	public static final String BOARD_READ_AND_WRITE = SCOPE_BOARD + DIV + ACTION_READ + AND + ACTION_WRITE;

	public static final String TASK_ALL = SCOPE_TASK + DIV + ALL;
	public static final String TASK_CREATE = SCOPE_TASK + DIV + ACTION_CREATE;
	public static final String TASK_DELETE = SCOPE_TASK + DIV + ACTION_DELETE;
	public static final String TASK_ASSIGN_MEMBER = SCOPE_TASK + DIV + ACTION_ASSIGN_MEMBER;
	public static final String TASK_UNASSIGN_MEMBER = SCOPE_TASK + DIV + ACTION_UNASSIGN_MEMBER;
	public static final String TASK_MANAGE_MEMBER = SCOPE_TASK + DIV + ACTION_ASSIGN_MEMBER + AND + ACTION_UNASSIGN_MEMBER;
	public static final String TASK_READ = SCOPE_TASK + DIV + ACTION_READ;
	public static final String TASK_WRITE = SCOPE_TASK + DIV + ACTION_WRITE;
	public static final String TASK_READ_AND_WRITE = SCOPE_TASK + DIV + ACTION_READ + AND + ACTION_WRITE;

	public static final Set<String> GUEST_PERMISSIONS;
	public static final Set<String> USER_PERMISSIONS;
	public static final Set<String> MEMBER_PERMISSIONS;
	public static final Set<String> MANAGER_PERMISSIONS;
	public static final Set<String> SUPER_PERMISSIONS;
	public static final Set<String> ADMIN_PERMISSIONS;

	public static final Set<String> DEFAULT_PERMISSIONS;

	static {
		HashSet<String> permissions = new HashSet<String>();
		permissions.add(SCOPE_BOARD + AND + SCOPE_TASK + DIV + ACTION_READ);
		GUEST_PERMISSIONS = Collections.unmodifiableSet(permissions);
		USER_PERMISSIONS = Collections.unmodifiableSet(permissions);

		permissions = new HashSet<String>(USER_PERMISSIONS);
		permissions.add(TASK_ALL);
		permissions.add(BOARD_READ_AND_WRITE);
		MEMBER_PERMISSIONS = Collections.unmodifiableSet(permissions);

		permissions = new HashSet<String>(MEMBER_PERMISSIONS);
		permissions.add(BOARD_ALL);
		permissions.add(GROUP_READ_AND_WRITE);
		MANAGER_PERMISSIONS = Collections.unmodifiableSet(permissions);

		permissions = new HashSet<String>(MANAGER_PERMISSIONS);
		permissions.add(GROUP_ALL);
		permissions.add(DOMAIN_READ);
		permissions.add(DOMAIN_MANAGE_MEMBER);
		SUPER_PERMISSIONS = Collections.unmodifiableSet(permissions);

		//-->
		//permissions = new HashSet<String>(MANAGER_PERMISSIONS);
		//permissions.add(GROUP_ALL);
		//permissions.add(DOMAIN_ALL);
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		permissions = new HashSet<String>();
		permissions.add(ALL);
		//<--
		ADMIN_PERMISSIONS = Collections.unmodifiableSet(permissions);

		DEFAULT_PERMISSIONS = USER_PERMISSIONS;
	}

	private Permission() {}

	@SuppressWarnings("deprecation")
	public static Set<String> fromRole(String role) {
		if (Role.ADMIN.equals(role)) {
			return ADMIN_PERMISSIONS;
		}
		//-->
		/*
		if (Role.ADMIN_USER.equals(role)) {
			Set<String> permissions = new HashSet<String>(USER_PERMISSIONS);
			permissions.add(GROUP_ALL);
			permissions.add(DOMAIN_ALL);
			return permissions;
		}
		if (Role.ADMIN_MEMBER.equals(role)) {
			Set<String> permissions = new HashSet<String>(MEMBER_PERMISSIONS);
			permissions.add(GROUP_ALL);
			permissions.add(DOMAIN_ALL);
			return permissions;
		}
		if (Role.ADMIN_SUPER.equals(role)) {
			Set<String> permissions = new HashSet<String>(SUPER_PERMISSIONS);
			permissions.add(GROUP_ALL);
			permissions.add(DOMAIN_ALL);
			return permissions;
		}
		*/
		//--
		// jongwook.yi@forecs.net 2016-03-02 : cocoworks v1.5
		// TODO : Remove this after data migration
		if (Role.ADMIN_USER.equals(role) || Role.ADMIN_MEMBER.equals(role) || Role.ADMIN_SUPER.equals(role)) {
			return ADMIN_PERMISSIONS;
		}
		//<--
		if (Role.SUPER.equals(role)) {
			return SUPER_PERMISSIONS;
		}
		if (Role.MANAGER.equals(role)) {
			return MANAGER_PERMISSIONS;
		}
		if (Role.MEMBER.equals(role)) {
			return MEMBER_PERMISSIONS;
		}
		if (Role.USER.equals(role)) {
			return USER_PERMISSIONS;
		}
		return GUEST_PERMISSIONS;
	}
}