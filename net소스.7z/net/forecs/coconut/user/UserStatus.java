package net.forecs.coconut.user;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import net.forecs.coconut.entity.board.Boards;
import net.forecs.coconut.entity.domain.Domains;
import net.forecs.coconut.entity.domain.Stages;
import net.forecs.coconut.entity.setting.UserSetting;
import net.forecs.coconut.entity.user.Users;


public final class UserStatus implements Serializable {
	private static final long serialVersionUID = -5938864015079389886L;
	
	@Getter @Setter
	private Users user;
	@Getter @Setter
	private Domains domain;
	@Getter @Setter
	private List<UserSetting> userSettings;
	@Getter @Setter
	private List<Users> users;
	@Getter @Setter
	private List<Boards> boards;
	@Getter @Setter
	private List<Stages> stages;
	
	public UserStatus() {
		
	}
}