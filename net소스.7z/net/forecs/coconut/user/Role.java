package net.forecs.coconut.user;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


public final class Role {
	public static final String GUEST = "guest";
	public static final String USER = "user";
	public static final String MEMBER = "member";
	public static final String MANAGER = "manager";
	public static final String SUPER = "super";
	public static final String ADMIN = "admin";
	//--> TODO : Remove this after data migration
	@Deprecated
	public static final String ADMIN_USER = "admin_user";
	@Deprecated
	public static final String ADMIN_MEMBER = "admin_member";
	@Deprecated
	public static final String ADMIN_SUPER = "admin_super";
	//--
	// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
	//<--

	public static final String DEFAULT_ROLE = USER;

	public static final Set<String> GUEST_ROLES;
	public static final Set<String> USER_ROLES;
	public static final Set<String> MEMBER_ROLES;
	public static final Set<String> MANAGER_ROLES;
	public static final Set<String> SUPER_ROLES;
	public static final Set<String> ADMIN_ROLES;

	public static final Set<String> ALL_ROLES;
	public static final Set<String> DEFAULT_ROLES;

	static {
		HashSet<String> roles;

		roles = new HashSet<String>();
		roles.add(GUEST);
		GUEST_ROLES = Collections.unmodifiableSet(roles);

		roles = new HashSet<String>();
		roles.add(USER);
		USER_ROLES = Collections.unmodifiableSet(roles);

		roles = new HashSet<String>(USER_ROLES);
		roles.add(MEMBER);
		MEMBER_ROLES = Collections.unmodifiableSet(roles);

		roles = new HashSet<String>(MEMBER_ROLES);
		roles.add(MANAGER);
		MANAGER_ROLES = Collections.unmodifiableSet(roles);

		roles = new HashSet<String>(MANAGER_ROLES);
		roles.add(SUPER);
		SUPER_ROLES = Collections.unmodifiableSet(roles);

		//-->
		//roles = new HashSet<String>(MANAGER_ROLES);
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		roles = new HashSet<String>(SUPER_ROLES);
		//<--
		roles.add(ADMIN);
		ADMIN_ROLES = Collections.unmodifiableSet(roles);

		//-->
		//roles = new HashSet<String>(SUPER_ROLES);
		//roles.add(ADMIN_USER);
		//roles.add(ADMIN_MEMBER);
		//roles.add(ADMIN);	// manager
		//roles.add(ADMIN_SUPER);
		//ALL_ROLES = Collections.unmodifiableSet(roles);
		//--
		// jongwook.yi@forecs.net 2016-01-12 : cocoworks v1.5
		ALL_ROLES = ADMIN_ROLES;
		//<--
		DEFAULT_ROLES = USER_ROLES;
	}

	private Role() {}

	public static boolean isValid(String role) {
		return ALL_ROLES.contains(role);
	}

	public static boolean isAdmin(Set<String> roles) {
		return (roles != null) && roles.contains(ADMIN);
	}
	public static boolean isSuper(Set<String> roles) {
		return (roles != null) && roles.contains(SUPER);
	}
	public static boolean isManager(Set<String> roles) {
		return (roles != null) && roles.contains(MANAGER);
	}
	public static boolean isMember(Set<String> roles) {
		return (roles != null) && roles.contains(MEMBER);
	}
	public static boolean isUser(Set<String> roles) {
		return (roles != null) && roles.contains(USER);
	}
	//public static boolean isGuest(Set<String> roles) {
	//	return (roles != null) && roles.contains(GUEST);
	//}

	@Deprecated
	public static String fromRoleSet(Set<String> roles) {
		if (isAdmin(roles)) {
			//-->
			/*
			if (isSuper(roles)) {
				return ADMIN_SUPER;
			}
			if (isManager(roles)) {
				return ADMIN;	// manager
			}
			if (isMember(roles)) {
				return ADMIN_MEMBER;
			}
			if (isUser(roles)) {
				return ADMIN_USER;
			}
			*/
			//--
			// jongwook.yi@forecs.net 2016-03-02 : cocoworks v1.5
			//<--
			return ADMIN;
		}
		if (isSuper(roles)) {
			return SUPER;
		}
		if (isManager(roles)) {
			return MANAGER;
		}
		if (isMember(roles)) {
			return MEMBER;
		}
		if (isUser(roles)) {
			return USER;
		}
		return GUEST;
	}

	public static Set<String> toRoleSet(String role) {
		if (ADMIN.equals(role)) {
			return ADMIN_ROLES;
		}
		//-->
		/*
		if (ADMIN_USER.equals(role)) {
			Set<String> roles = new HashSet<String>(USER_ROLES);
			roles.add(ADMIN);
			return roles;
		}
		if (ADMIN_MEMBER.equals(role)) {
			Set<String> roles = new HashSet<String>(MEMBER_ROLES);
			roles.add(ADMIN);
			return roles;
		}
		if (ADMIN_SUPER.equals(role)) {
			Set<String> roles = new HashSet<String>(SUPER_ROLES);
			roles.add(ADMIN);
			return roles;
		}
		*/
		//--
		// jongwook.yi@forecs.net 2016-03-02 : cocoworks v1.5
		// TODO : Remove this after data migration
		if (ADMIN_USER.equals(role) || ADMIN_MEMBER.equals(role) || ADMIN_SUPER.equals(role)) {
			return ADMIN_ROLES;
		}
		//<--
		if (SUPER.equals(role)) {
			return SUPER_ROLES;
		}
		if (MANAGER.equals(role)) {
			return MANAGER_ROLES;
		}
		if (MEMBER.equals(role)) {
			return MEMBER_ROLES;
		}
		if (USER.equals(role)) {
			return USER_ROLES;
		}
		return GUEST_ROLES;
	}
}